# PNEUMA-NATIVE Ω — `AUTH-P3C-DIFFERENTIAL-R1` Independent Tribunal Verification Bundle

## 1. Bundle Scope & Governance Notice
- **Target Gate**: `AUTH-P3C-DIFFERENTIAL-R1` (`F-P3C-02`: Independent Full Internal-State Semantic Differential Verification, `Corrigendum R0` `F-DIFF-P0-01`~`04`, and `Scoped Optimization` `F-DIFF-OPT-01`~`04`).
- **Disposition**: `SUBMITTED_FOR_INDEPENDENT_TRIBUNAL_REVIEW` (final Tribunal acceptance is **not** self-declared prior to Independent Tribunal audit).
- **Complete Self-Contained Dependency Closure**: Includes the entire read-only upstream source tree (`P1`, `P2_DerivationReplay`, `P3_LexicalGrammar`, `P3B_BoundedParser`, `P3C_SemanticNorm`, `P3C_Provenance_R1`) alongside `P3C_Differential_R1` so that external Independent Tribunal hosts can replay the full Lean `v4.33.1` build and `leanchecker --fresh` kernel verification directly from source without missing `../` path dependencies.

## 2. Key Files in This Archive
1. **`dossiers/PNEUMA_P3C_DIFFERENTIAL_R1_READONLY_TRIBUNAL_DOSSIER.md`** — Primary read-only Tribunal verification dossier (`15/15` verbatim source/config/oracle/receipt blocks).
2. **`BROCA_NATIVE_OMEGA_GATE_C1/P3C_Differential_R1/`** — Isolated `Differential R1` Lean 4.33.1 package (`14` source/config/oracle files) + `06_receipts/auth_p3c_differential_r1_verification_receipt.json`.
3. **`BROCA_NATIVE_OMEGA_GATE_C1/{P2_DerivationReplay, P3_LexicalGrammar, P3B_BoundedParser, P3C_SemanticNorm, P3C_Provenance_R1, 00_frozen_reference, 06_receipts}/`** — Unmodified frozen upstream lineage required for clean external host build & `leanchecker --fresh` replay.
4. **`dossiers/{p1..p3c, PNEUMA_P3C_AUTHORITY_RECONCILIATION_R0, PNEUMA_P3C_PROVENANCE_R1}_*.md`** — Complete prior Tribunal dossier lineage (`7` upstream dossiers).
5. **`replay_logs/`** — Captured deterministic CLI outputs (`p3c_differential_r1_runner_stdout.txt`, `forest_inject_wire_dump.tsv`, `semantic_inject_wire_dump.tsv`).
6. **`verify_bundle_integrity.py`**, **`MANIFEST.sha256`**, **`MANIFEST.json`** — Standalone cryptographic integrity and dossier block-parity verifier.

## 3. Step-by-Step External Host Verification Commands

### Step A — Immediate Static Cryptographic & Block-Parity Check (Python 3.9+, No Lean Needed)
```bash
python verify_bundle_integrity.py
```

### Step B — Full External Host Build, Differential Oracle & Fresh Kernel Replay (`Lean v4.33.1` + `Python 3.11+`)
```bash
cd BROCA_NATIVE_OMEGA_GATE_C1/P3C_Differential_R1
lake build
lake exe p3c_differential_r1_runner
python 05_independent_tribunal/independent_r0_semantic_oracle.py --json
lake env lean 05_independent_tribunal/P3CDiffTribunalAudit.lean
lake env leanchecker --fresh P3CDiffTribunalAudit
```
