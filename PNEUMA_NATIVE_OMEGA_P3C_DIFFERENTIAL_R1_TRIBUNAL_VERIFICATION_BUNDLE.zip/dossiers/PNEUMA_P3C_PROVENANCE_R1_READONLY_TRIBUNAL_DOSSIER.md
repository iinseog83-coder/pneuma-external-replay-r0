# PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 Read-Only Independent Tribunal Verification Bundle (`P3C_Provenance_R1`)

> [!IMPORTANT]
> **Read-Only Audit Submission (`AUTH-P3C-PROVENANCE-R1`: `F-P3C-01` Proof-Carrying Semantic Consensus & Public Result Provenance Binding)**
> Official Governance Title: **`PNEUMA-NATIVE Ω`** (`namespace PneumaOmega.P3C.ProvenanceR1`; historical frozen lineage `BROCA-NATIVE Ω`).
> All `13` R1 source/configuration/harness files and the isolated verification receipt (`auth_p3c_provenance_r1_verification_receipt.json`) embedded in Section 6 are **100% verbatim, byte-identical copies** (`14/14` SHA-256 block-parity verified) from `C:\antigravity work\BROCA_NATIVE_OMEGA_GATE_C1\P3C_Provenance_R1\`.
> Zero bytes were written to `Pneuma` (`0` files), `Broca`/`shared` (`6/6` anchors), `DIR`, `P1` (`13/13`), `P2` (`14/14`), `P3-A` (`14/14`), `P3-B` (`14/14`), `P3-C` (`14/14` sources + `12/12` binaries), parent `BROCA_NATIVE_OMEGA_GATE_C1\06_receipts\` (`6/6` receipts), or any prior Tribunal dossier. Termination state: **`FROZEN_AND_STANDBY`**.

---

## 1. Authorization Lineage & `Gate 0` ~ `Gate F` Compliance Summary

| Audit Dimension | Charter Requirement | Verified Evidence |
| :--- | :--- | :--- |
| **`AC-P0-06 §9.A.1 & §9.A.2` Authorization** | Explicit 4-field charter + separate human principal execution directive before any write | Charter pinned all 4 `§9.A.2` fields (`AUTH-P3C-PROVENANCE-R1`, `P3C_Provenance_R1\`, Lean `4.33.1`/Lake `5.0.0`/Python `3.11.8`, scope `F-P3C-01`); zero file writes occurred prior to human explicit directive `"AUTH-P3C-PROVENANCE-R1 승인한다. 위 범위로 진행해."` (`2026-11-23T18:03:22+09:00`). |
| **Gate 0 — Baseline Absorption & Immutability** | Absorb frozen `P3-C` read-only; zero upstream mutation | Pre- and post-build SHA-256 verification passed across `Pneuma` (`0` files), `Broca`/`shared` (`6/6`), `DIR`, `P1` (`13/13`), `P2` (`14/14`), `P3-A` (`14/14`), `P3-B` (`14/14`), `P3-C` (`14/14` sources + `12/12` `.olean`/`.exe`), and parent `06_receipts/` (`6/6`). |
| **Gate A — Explicit Threat Model (`A1`~`A6`)** | Model public `.consensus` forgery, result/context/budget/catalog substitution, failure laundering, & `P4`/`P5` escalation | `ThreatModelAndContext.lean`: exhibits `fabricatePublicOutcomeWithoutExecution` (`public_outcome_allows_unverified_empty_trees`), defines `ProvenanceThreatId` (`A1`~`A6`), 5-field `ProvenanceContext`, `ExecProvenanceSpec`, `DeclarativeConsensusContract`, and `SecurityAssuranceBoundary`. |
| **Gate B — Sealed `CertifiedSemanticConsensus` & Detached Verifier** | `private mk ::` bound to actual `certifySemanticConsensus` execution + whitebox claim verifier + compiler negative probes | `SealedProvenanceGate.lean`: `CertifiedSemanticConsensus (ctx : ProvenanceContext)` (`private mk ::`, zero public mutators, singleton uniqueness `certifiedSemanticConsensus_unique`), `mintCertifiedConsensus`, `verifyUntrustedConsensusClaim`, `verifyForestConsensusPure`; verified by `5/5` external `lake env lean` probes (`PROBE-CTRL-01`, `PROBE-NEG-01a`, `PROBE-NEG-01b`, `PROBE-NEG-02`, `PROBE-NEG-03`). |
| **Gate C — Seven Standalone Machine-Checked Theorems** | `PO-R1-01` ~ `PO-R1-07` (`0` `sorry`, `0` `native_decide`, `0` custom axioms) | `PO_R1_01_To_07.lean`: all 7 obligations proved separately and `#print axioms`-verified (`[propext, Classical.choice, Quot.sound]` only). |
| **Gate D — Symmetric Positive/Adversarial Suite** | `24+` `(PC, CE)` vectors covering all 12 Gate D scenarios mapped to theorem & expected/actual verdicts | `AttackSuiteR1.lean`: `24/24` (`12` `(PC, CE)` pairs) proved via kernel `decide` (`PO_R1_All24AttackVectorsVerified`) + live CLI table output. |
| **Gate E — Reproducible Build, Harness & Fresh Kernel Replay** | `lake build` (`0` warn/err), `#print axioms`, `leanchecker --fresh` (`exit 0`), honest harness classification, receipt JSON | `lake build` (`80/80` jobs, `0` warnings/errors), `provenance_audit_and_probes.py` (`5/5` probes + `120/120` cross-language reference harness claims, `0` mismatches), `lake env leanchecker --fresh P3CProvenanceTribunalAudit` (`exit 0`, `738.03s`), receipt SHA-256 `790E41D1D352C31457281F72BB627E28DD6D3B7DB1B65C7D8F4F39A795D203DD`. |

---

## 2. Mandatory 5-Category Epistemic & Governance Separation (`Gate F`)

### 2.1 Category I — Machine-Checked Theorems (`Proved in Lean 4.33.1 Kernel`)

| Obligation ID | Exported Theorem (`PneumaOmega.P3C.ProvenanceR1.Obligations`) | Machine-Checked Statement Summary | Axiom Footprint |
| :--- | :--- | :--- | :--- |
| **`PO-R1-01`** | `PO_R1_01_ConstructionSoundness` | Every `cert : CertifiedSemanticConsensus ctx` guarantees `certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes = .consensus cert.trees cert.canonical`, `mintCertifiedConsensus ctx = .admitted cert`, and uniqueness `∀ cert', cert' = cert`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-R1-02`** | `PO_R1_02_InputBinding` | Any mismatch in `(catalog, numCfg, scopeEnv, budget, rawBytes)` causes `verifyUntrustedConsensusClaim` to return `.error r`; `exportUntrustedClaim cert₁` is rejected on every `ctx₂ ≠ ctx₁`; even if `claimedCtx` is spoofed to `ctx₂`, acceptance requires `ExecProvenanceSpec ctx₂ cert₁.trees cert₁.canonical`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-R1-03`** | `PO_R1_03_ConsensusPreservation` | Every `cert : CertifiedSemanticConsensus ctx` entails `DeclarativeConsensusContract`: bounded exhaustive `P3-B` parse set, `T ≠ []`, `NoDupTrees`, `TrapPolicyPermitsForest`, `IsCanonicalNorm`, universal `SemEq`, and relative `Denotes` equivalence under `ExtensionalContrastiveWorld W`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-R1-04`** | `PO_R1_04_FailClosed` | Across all 4 non-consensus outcomes (`.ambiguousReadings`, `.semanticExtractionFailure`, `.trapPolicyRejected`, `.upstreamRejected`), `CertifiedSemanticConsensus ctx → False` (uninhabited) AND `verifyUntrustedConsensusClaim ctx cl` rejects every untrusted `cl`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-R1-05`** | `PO_R1_05_NoAuthorityEscalation` | `(P5FinalCertifiedOutput → False)` ∧ `(∀ c, P4ClinicalTruthCert c → False)` ∧ concrete `certG01` holds in extensional clinical world `W_true` (`Denotes W_true`) while failing in `W_false` (`¬ Denotes W_false`). | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-R1-06`** | `PO_R1_06_ReplayFaithfulness` | Exact two-way correspondence: `verifyUntrustedConsensusClaim targetCtx claim = .ok cert ↔ claim = exportUntrustedClaim cert`, and `(∃ cert, verifyUntrustedConsensusClaim targetCtx claim = .ok cert) ↔ (∃ T c, claim = ⟨targetCtx, .consensus T c⟩ ∧ ExecProvenanceSpec targetCtx T c)`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-R1-07`** | `PO_R1_07_ProvenanceNonVacuity` | Constructively exhibits inhabited `certG01`, `certG11`, `certG15a`, `certG15b` via public `mintCertifiedConsensus` (never `private mk`), proves `.ok` replay roundtrip, `certG15a.canonical = certG15b.canonical`, and cross-input rejection `ctxG01 → ctxG11`. | `propext`, `Classical.choice`, `Quot.sound` |

### 2.2 Category II — Deterministic Executed Checks (`Verified on Local Toolchain`)
1. **`lake build` (`80/80` jobs)**: `0` warnings, `0` errors.
2. **`p3c_provenance_r1_runner.exe` (`24/24` vectors)**: `12` symmetric `(PC, CE)` pairs proved both at compile time (`decide`, `0` `native_decide`) and at CLI runtime.
3. **`5/5` External Compiler Encapsulation & Type-Isolation Probes (`lake env lean`)**: Confirmed `PROBE-CTRL-01` (`exit 0`) and exact encapsulation/type-mismatch rejection on `PROBE-NEG-01a`, `PROBE-NEG-01b`, `PROBE-NEG-02`, and `PROBE-NEG-03` (`0` syntax/import errors).
4. **`120/120` Cross-Language Serialized Claim Replay Harness (`Python 3.11.8` ↔ `p3c_provenance_r1_runner.exe --eval-claims-batch`)**: `24` admitted + `96` rejected claims across `A1`~`A5`, `0` mismatches (`SHA-256: E3C93CBBF93E36212D43F72FE9CA2C2FE85CED3DEEF8B0DB7C960B51D520276F`). Explicitly classified as a **Cross-Language Reference Harness** mirroring `verifyUntrustedConsensusClaim`, *not* an independent R0 specification oracle.
5. **`lake env leanchecker --fresh P3CProvenanceTribunalAudit`**: `exit code 0` (`738.03s`), independently replaying all `P2`, `P3-A`, `P3-B`, `P3-C`, and `R1` `.olean` modules in a fresh kernel environment.

### 2.3 Category III — Unverified / Conditional Assumptions (`Explicitly Preserved, Never Overclaimed`)
- **Out-of-Kernel Binary / Memory / Runtime Tampering (`HELD`)**: `CertifiedSemanticConsensus` (`private mk ::`) enforces non-forgery **strictly within well-typed Lean 4 code checked by the Lean compiler/kernel** (`SecurityAssuranceBoundary.verifiedInLeanTypedKernelAPI`). It does **not** protect against out-of-kernel `.olean`/binary patching, foreign-function memory corruption, or untrusted host OS/hardware tampering (`heldOutOfKernelBinaryMemoryRuntimeTamper`), which require external cryptographic/attestation layers outside `R1`.
- **`ExtensionalContrastiveWorld W` Semantic Condition (`RETAINED`)**: `PO_R1_03_ConsensusPreservation` preserves `P3-C`'s exact `ExtensionalContrastiveWorld W` precondition without silent weakening; expanding semantic model coverage belongs to `F-P3C-02` (`HELD`).
- **Frozen Upstream Specification Fidelity**: `R1` binds provenance to frozen `PneumaOmega.P3C.certifySemanticConsensus` and `BrocaOmega.P3B.parseAllBounded`; upstream `R0` items (`F-P3A-01`/`02`, right-censored `G-01` surface, `_FULL_GRAMMAR_SEMANTIC_EQUIVALENCE_HELD`) remain unchanged.

### 2.4 Category IV — External Independent Host Replay Status (`HELD`)
- External independent host re-execution of `P1`, `P2`, `P3-A`, `P3-B`, `P3-C`, and `P3C_Provenance_R1` (`leanchecker --fresh` on a Tribunal-controlled machine) remains **`HELD`** pending external Tribunal replay.

### 2.5 Category V — Upstream Qualification & Downstream Authority Locks (`HELD` / `NOT_AUTHORIZED`)
- **Legacy `P3-C` Governance Status**: Remains **`AUTHORIZATION_QUALIFIED`** per `Authority Reconciliation R0` (NOT retroactively elevated by `R1`).
- **`F-P3C-02` (`Semantic Scope & Contrastive Model Expansion`)**: **`HELD`** (not authorized in `R1`).
- **Downstream & Adjacent Acts (`NOT_AUTHORIZED`)**: `P4` (clinical truth / statistical evidence verification), `P5` (`CertifiedOutput` final admission), `P1-C` (`Int128` fast path), `PNEUMA-FINITE-OPERATOR-R0`, and `PNEUMA Speech & Listener` remain **`NOT_AUTHORIZED`**.

---

## 3. `Gate D` 24-Vector Symmetric `(PC, CE)` Audit Matrix (`12` Pairs)

| Case ID | Polarity | Threat ID | Target Theorem(s) | Expected Verdict | Actual Verdict | Kernel `decide` & CLI |
| :--- | :---: | :--- | :--- | :--- | :--- | :---: |
| `PC-R1-01` | `PC` | `A1_PublicConstructorForgery` | `PO-R1-01 / PO-R1-06 / PO-R1-07` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-01` | `CE` | `A1_PublicConstructorForgery` | `PO-R1-01 / PO-R1-06` | `REJECT:substitutedParseForest` | `REJECT:substitutedParseForest` | `PASS` |
| `PC-R1-02` | `PC` | `A2_ResultSubstitution` | `PO-R1-03 / PO-R1-06 / PO-R1-07` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-02` | `CE` | `A2_ResultSubstitution` | `PO-R1-01 / PO-R1-06` | `REJECT:substitutedCanonicalMeaning & REJECT:substitutedParseForest` | `REJECT:substitutedCanonicalMeaning & REJECT:substitutedParseForest` | `PASS` |
| `PC-R1-03` | `PC` | `A3_InputOrEnvSubstitution` | `PO-R1-02 / PO-R1-06` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-03` | `CE` | `A3_InputOrEnvSubstitution` | `PO-R1-02 / PO-R1-06` | `REJECT:rawBytesMismatch & REJECT:substitutedCanonicalMeaning` | `REJECT:rawBytesMismatch & REJECT:substitutedCanonicalMeaning` | `PASS` |
| `PC-R1-04` | `PC` | `A3_InputOrEnvSubstitution` | `PO-R1-02 / PO-R1-03` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-04` | `CE` | `A3_InputOrEnvSubstitution` | `PO-R1-02 / PO-R1-04` | `REJECT:scopeEnvMismatch & REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)` | `REJECT:scopeEnvMismatch & REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)` | `PASS` |
| `PC-R1-05` | `PC` | `A4_BudgetOrCatalogSubstitution` | `PO-R1-02 / PO-R1-06` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-05` | `CE` | `A4_BudgetOrCatalogSubstitution` | `PO-R1-02 / PO-R1-04` | `REJECT:budgetMismatch & REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow)` | `REJECT:budgetMismatch & REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow)` | `PASS` |
| `PC-R1-06` | `PC` | `A4_BudgetOrCatalogSubstitution` | `PO-R1-02 / PO-R1-06` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-06` | `CE` | `A4_BudgetOrCatalogSubstitution` | `PO-R1-02 / PO-R1-06` | `REJECT:catalogMismatch & REJECT:numCfgMismatch` | `REJECT:catalogMismatch & REJECT:numCfgMismatch` | `PASS` |
| `PC-R1-07` | `PC` | `A5_FailureOutcomeLaundering` | `PO-R1-03 / PO-R1-06` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-07` | `CE` | `A5_FailureOutcomeLaundering` | `PO-R1-04 / PO-R1-06` | `REJECT:forgedConsensusOnAmbiguousInput & REJECT:forgedConsensusOnAmbiguousInput & REJECT:forgedConsensusOnAmbiguousInput` | `REJECT:forgedConsensusOnAmbiguousInput & REJECT:forgedConsensusOnAmbiguousInput & REJECT:forgedConsensusOnAmbiguousInput` | `PASS` |
| `PC-R1-08` | `PC` | `A5_FailureOutcomeLaundering` | `PO-R1-03 / PO-R1-06` | `ADMIT:consensus(trees=1) & ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1) & ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-08` | `CE` | `A5_FailureOutcomeLaundering` | `PO-R1-04 / PO-R1-06` | `REJECT:forgedConsensusOnTrapRejected(whFactivePresuppositionForbidden) & REJECT:forgedConsensusOnTrapRejected(unscopedClauseForbidden)` | `REJECT:forgedConsensusOnTrapRejected(whFactivePresuppositionForbidden) & REJECT:forgedConsensusOnTrapRejected(unscopedClauseForbidden)` | `PASS` |
| `PC-R1-09` | `PC` | `A5_FailureOutcomeLaundering` | `PO-R1-03 / PO-R1-06` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-09` | `CE` | `A5_FailureOutcomeLaundering` | `PO-R1-04 / PO-R1-06` | `REJECT:forgedConsensusOnExtractionFailure(invalidContrastiveAnchor) & REJECT:forgedConsensusOnExtractionFailure(unsupportedReadingAlt) & REJECT:nonConsensusOutcomeSubmitted` | `REJECT:forgedConsensusOnExtractionFailure(invalidContrastiveAnchor) & REJECT:forgedConsensusOnExtractionFailure(unsupportedReadingAlt) & REJECT:nonConsensusOutcomeSubmitted` | `PASS` |
| `PC-R1-10` | `PC` | `A5_FailureOutcomeLaundering` | `PO-R1-03 / PO-R1-06` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-10` | `CE` | `A5_FailureOutcomeLaundering` | `PO-R1-04 / PO-R1-06` | `REJECT:forgedConsensusOnUpstreamRejected(outOfDomain)` | `REJECT:forgedConsensusOnUpstreamRejected(outOfDomain)` | `PASS` |
| `PC-R1-11` | `PC` | `A5_FailureOutcomeLaundering` | `PO-R1-03 / PO-R1-06` | `ADMIT:consensus(trees=1)` | `ADMIT:consensus(trees=1)` | `PASS` |
| `CE-R1-11` | `CE` | `A5_FailureOutcomeLaundering` | `PO-R1-04 / PO-R1-06` | `REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow) & REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)` | `REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow) & REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)` | `PASS` |
| `PC-R1-12` | `PC` | `A6_P4P5AuthorityEscalation` | `PO-R1-03 / PO-R1-05` | `DENOTES_W_TRUE:true(LinguisticConsensusScope)` | `DENOTES_W_TRUE:true(LinguisticConsensusScope)` | `PASS` |
| `CE-R1-12` | `CE` | `A6_P4P5AuthorityEscalation` | `PO-R1-05` | `DENOTES_W_FALSE:false(P4_P5_EscalationBlocked)` | `DENOTES_W_FALSE:false(P4_P5_EscalationBlocked)` | `PASS` |

---

## 4. Verbatim Build, Axiom Audit, Compiler Probe & `leanchecker --fresh` Logs

### 4.1 `lake build` & `#print axioms` Output (`80/80` Jobs, `0` Warnings, `0` Errors)
```text
✔ [73/80] Built P3CProvenanceObligations.PO_R1_01_To_07 (3.4s)
✔ [74/80] Built P3CProvenanceObligations (879ms)
✔ [76/80] Built P3CProvenanceObligations.PO_R1_01_To_07:c.o (833ms)
ℹ [77/80] Built P3CProvenanceTribunalAudit (1.1s)
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:29:0: 'PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_01_ConstructionSoundness' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:30:0: 'PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_02_InputBinding' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:31:0: 'PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_03_ConsensusPreservation' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:32:0: 'PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_04_FailClosed' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:33:0: 'PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_05_NoAuthorityEscalation' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:34:0: 'PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_06_ReplayFaithfulness' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:35:0: 'PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_07_ProvenanceNonVacuity' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:36:0: 'PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_All24AttackVectorsVerified' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:37:0: 'PneumaOmega.P3C.ProvenanceR1.certifiedSemanticConsensus_unique' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:38:0: 'PneumaOmega.P3C.ProvenanceR1.Attacks.verifyClaimPure_error_iff' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3CProvenanceTribunalAudit.lean:39:0: 'PneumaOmega.P3C.ProvenanceR1.Attacks.verifyClaimPure_ok_iff' depends on axioms: [propext, Classical.choice, Quot.sound]
✔ [78/80] Built P3CProvenanceObligations:c.o (1.1s)
✔ [79/80] Built P3CProvenanceTribunalAudit:c.o (481ms)
✔ [80/80] Built p3c_provenance_r1_runner:exe (2.6s)
Build completed successfully (80 jobs).
```

### 4.2 External Compiler Encapsulation & Type-Isolation Probes (`5/5` Passed) + `120/120` Reference Harness
```text
==========================================================================
PNEUMA-NATIVE OMEGA — AUTH-P3C-PROVENANCE-R1 PROBES & CLAIM REPLAY HARNESS
==========================================================================
[PASS] PROBE-CTRL-01 (exit=0) — Positive control: external consumer imports P3CProvenanceObligations and reads certG01.canonical
[PASS] PROBE-NEG-01a (exit=1) — Negative probe A1 (named constructor): external caller cannot invoke private CertifiedSemanticConsensus.mk
       compiler: <TEMP_PROBE>/PROBE_NEG_01a.lean:7:2: error(lean.unknownIdentifier): Unknown constant `PneumaOmega.P3C.ProvenanceR1.CertifiedSemanticConsensus.mk`
[PASS] PROBE-NEG-01b (exit=1) — Negative probe A1 (anonymous constructor): external caller cannot forge CertifiedSemanticConsensus via anonymous ⟨...⟩
       compiler: <TEMP_PROBE>/PROBE_NEG_01b.lean:6:2: error: Invalid `⟨...⟩` notation: Constructor for `PneumaOmega.P3C.ProvenanceR1.CertifiedSemanticConsensus` is marked as private
[PASS] PROBE-NEG-02 (exit=1) — Negative probe A3/A4 (type-indexed input binding): CertifiedSemanticConsensus ctxShortA is rejected where ctxShortB is expected
       compiler: <TEMP_PROBE>/PROBE_NEG_02.lean:12:15: error: Application type mismatch: The argument c has type CertifiedSemanticConsensus ctxShortA but is expected to have type CertifiedSemanticConsensus ctxShortB
[PASS] PROBE-NEG-03 (exit=1) — Negative probe A6 (no P4/P5 authority escalation): CertifiedSemanticConsensus cannot inhabit P5FinalCertifiedOutput
       compiler: <TEMP_PROBE>/PROBE_NEG_03.lean:6:2: error: Type mismatch: certG01 has type CertifiedSemanticConsensus ctxG01 of sort `Type` but is expected to have type P5FinalCertifiedOutput of sort `Prop`
--------------------------------------------------------------------------
Harness Type      : CROSS_LANGUAGE_REFERENCE_HARNESS_NOT_INDEPENDENT_ORACLE
Total TSV Claims  : 120 (admitted=24, rejected=96)
Batch TSV SHA-256 : E3C93CBBF93E36212D43F72FE9CA2C2FE85CED3DEEF8B0DB7C960B51D520276F
Lean-Python Diff  : 0 mismatches
==========================================================================
```

### 4.3 `lake env leanchecker --fresh P3CProvenanceTribunalAudit` Output
```text
LEANCHECKER_EXIT=0 ELAPSED_SEC=738.03
```

---

## 5. SHA-256 Artifact Ledger (`P3C_Provenance_R1` + Unmodified Upstream Baselines)

| Relative Path (`P3C_Provenance_R1\`) | Source / JSON SHA-256 | Compiled `.olean` / `.exe` SHA-256 |
| :--- | :--- | :--- |
| `lean-toolchain` | `3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71` | *(config / harness script)* |
| `lakefile.toml` | `5141FEED4E4F37A4ABBC2EE7E67C43FC28753C88EF3A2902EBD78B1CA0F31BB6` | *(config / harness script)* |
| `lake-manifest.json` | `547241BA6AECB60D9CC286617791FC7B9BD50BE6DAE1FB4FC708BF418320D8C3` | *(config / harness script)* |
| `01_formal_spec/P3CProvenanceSpec.lean` | `67603658E007700E6A70F17B50886CCC5717EADAF8CA2FD46460C6D289281F37` | `CAE2E43E8E04A8C469DEFF4C67BBBB781AD75B460041CD185028BDD8785BC698` |
| `01_formal_spec/P3CProvenanceSpec/ThreatModelAndContext.lean` | `49422ADF1B9D58A41BAFD80017CE9434B67A2A6F78ABED4D0196720E6E19836E` | `8254E51016C84AFDE3744CC9896E6477334248537F0A5686C7116D493F7DB370` |
| `02_detached_checker/P3CProvenanceChecker.lean` | `7652739A9519575C251BCE2DCE9D192D1E79B7603BC0366B9289BA233DC856D3` | `756D295336ABD52FD061EE91F3A47A28D8ADE7FD4231F8BF05D7C330DF95058E` |
| `02_detached_checker/P3CProvenanceChecker/SealedProvenanceGate.lean` | `49DA95B50CE09E31279FD8245D4B1BD7D05E02972239004C70A3A21DEF907805` | `3600A07B6B70C416C6FF566EDF6AEF086D7957828F2B471FC41D6A8C2AA783F6` |
| `03_counterexamples/P3CProvenanceAttacks.lean` | `F36860CE8A75558EC7FF9B1BE2384EB31641FA640A7DC71DE0AFA44102C4AB97` | `0567CBB3836107450B54244D665FA68B5D05AFF257C2D257ADFE2272E3F77E4E` |
| `03_counterexamples/P3CProvenanceAttacks/AttackSuiteR1.lean` | `814543BA4E33532A80E9722309DE80D1CE77E8375F6084FF4BCF41C2A6F55722` | `D7AAE0B9114EED43BC0C39B11DEE62B280FFEA1CD7A6B0DB39192FDC6B44614B` |
| `04_proof_obligations/P3CProvenanceObligations.lean` | `B34E9DD691B31E393C6F64487A5B69481CD6D0B9CA3936F36207FAAE96371F70` | `21BC9AD023591A490053A98313D651FA9A071FE6FD6816F9B37CC0A5B9774B4B` |
| `04_proof_obligations/P3CProvenanceObligations/PO_R1_01_To_07.lean` | `00965D8B81509864ED621E676399DE7917568B22D2B5736E9D468BD02D1A3707` | `E7BFF7CA3759EE63D447BD9AB066F73BABA272C58AD71A6B6C7224FD1D44E47E` |
| `05_independent_tribunal/P3CProvenanceTribunalAudit.lean` | `A0BE882DF80A73EE20D45AB7895FF5FE70D4D7B8FEF281C7E9F659A4AC47705C` | `.olean`: `826A1E966E12E9B37FD24893E005810B006ED8C52B0983FDC8B089D2F5C81FBA`<br>`.exe`: `DEB010B16805B17211B653DADFEC032F79CB698AAFE7B7348343A365C6DB19EA` |
| `05_independent_tribunal/provenance_audit_and_probes.py` | `07677C95A5BDF5BE38E3F711984602047EEF11ED0942DB99ABEF1409497B9494` | *(config / harness script)* |
| `06_receipts/auth_p3c_provenance_r1_verification_receipt.json` | `790E41D1D352C31457281F72BB627E28DD6D3B7DB1B65C7D8F4F39A795D203DD` | *(R1 verification receipt)* |

---

## 6. Verbatim Unmodified Source, Config, Harness & Receipt Files (`14/14` Blocks)

### File 1: `lean-toolchain` (SHA-256: `3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71`)
````text
leanprover/lean4:v4.33.1
````

### File 2: `lakefile.toml` (SHA-256: `5141FEED4E4F37A4ABBC2EE7E67C43FC28753C88EF3A2902EBD78B1CA0F31BB6`)
````toml
name = "pneuma_omega_p3c_provenance_r1"
version = "0.1.0"
defaultTargets = ["P3CProvenanceSpec", "P3CProvenanceChecker", "P3CProvenanceAttacks", "P3CProvenanceObligations", "p3c_provenance_r1_runner"]

[[require]]
name = "broca_omega_gate_c1_p2"
path = "../P2_DerivationReplay"

[[require]]
name = "broca_omega_gate_c1_p3a"
path = "../P3_LexicalGrammar"

[[require]]
name = "broca_omega_gate_c1_p3b"
path = "../P3B_BoundedParser"

[[require]]
name = "pneuma_omega_gate_c1_p3c"
path = "../P3C_SemanticNorm"

[[lean_lib]]
name = "P3CProvenanceSpec"
srcDir = "01_formal_spec"

[[lean_lib]]
name = "P3CProvenanceChecker"
srcDir = "02_detached_checker"

[[lean_lib]]
name = "P3CProvenanceAttacks"
srcDir = "03_counterexamples"

[[lean_lib]]
name = "P3CProvenanceObligations"
srcDir = "04_proof_obligations"

[[lean_exe]]
name = "p3c_provenance_r1_runner"
srcDir = "05_independent_tribunal"
root = "P3CProvenanceTribunalAudit"
````

### File 3: `lake-manifest.json` (SHA-256: `547241BA6AECB60D9CC286617791FC7B9BD50BE6DAE1FB4FC708BF418320D8C3`)
````json
{"version": "1.2.0",
 "packagesDir": ".lake/packages",
 "packages":
 [{"type": "path",
   "scope": "",
   "name": "pneuma_omega_gate_c1_p3c",
   "manifestFile": "lake-manifest.json",
   "inherited": false,
   "dir": "../P3C_SemanticNorm",
   "configFile": "lakefile.toml"},
  {"type": "path",
   "scope": "",
   "name": "broca_omega_gate_c1_p3b",
   "manifestFile": "lake-manifest.json",
   "inherited": false,
   "dir": "../P3B_BoundedParser",
   "configFile": "lakefile.toml"},
  {"type": "path",
   "scope": "",
   "name": "broca_omega_gate_c1_p3a",
   "manifestFile": "lake-manifest.json",
   "inherited": false,
   "dir": "../P3_LexicalGrammar",
   "configFile": "lakefile.toml"},
  {"type": "path",
   "scope": "",
   "name": "broca_omega_gate_c1_p2",
   "manifestFile": "lake-manifest.json",
   "inherited": false,
   "dir": "../P2_DerivationReplay",
   "configFile": "lakefile.toml"}],
 "name": "pneuma_omega_p3c_provenance_r1",
 "lakeDir": ".lake",
 "fixedToolchain": false}
````

### File 4: `01_formal_spec/P3CProvenanceSpec.lean` (SHA-256: `67603658E007700E6A70F17B50886CCC5717EADAF8CA2FD46460C6D289281F37`)
````lean
import P3CProvenanceSpec.ThreatModelAndContext
````

### File 5: `01_formal_spec/P3CProvenanceSpec/ThreatModelAndContext.lean` (SHA-256: `49422ADF1B9D58A41BAFD80017CE9434B67A2A6F78ABED4D0196720E6E19836E`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`F-P3C-01` Threat Model & Context Specification)
  01_formal_spec/P3CProvenanceSpec/ThreatModelAndContext.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`)

  Gate 0 & Gate A Deliverables:
    1. Absorbs frozen `PneumaOmega.P3C` (`SemanticNormOutcome`, `certifySemanticConsensus`,
       `certifySemanticConsensus_sound`) without modifying a single byte of `P1`~`P3-C`.
    2. Explicitly exhibits why `F-P3C-01` arose: `SemanticNormOutcome.consensus` is publicly
       constructible without executing `certifySemanticConsensus` (`untrustedPublicConsensusForgeable`).
    3. Defines the full 5-component `ProvenanceContext` (`catalog`, `numCfg`, `scopeEnv`, `budget`,
       `rawBytes`) with pure `Bool` field comparators and proven `..._iff` equivalence lemmas.
    4. Models all six `Gate A` threat classes (`A1`~`A6`) and explicitly separates in-kernel Lean
       API guarantees from out-of-kernel binary/memory tamper boundaries (`HELD_OUT_OF_KERNEL_RUNTIME`).
    5. Defines algorithm-free declarative provenance & semantic preservation predicates
       (`ExecProvenanceSpec`, `DeclarativeConsensusContract`), keeping `ExtensionalContrastiveWorld`
       explicit and separating `P4` clinical truth / `P5` final admission (`NOT_AUTHORIZED`).
-/
import P3CDetachedChecker

namespace PneumaOmega.P3C.ProvenanceR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C

/-! ### 1. `Gate 0` & `Gate A1` Diagnosis: Public Constructibility of Raw `SemanticNormOutcome.consensus` -/

/--
  Demonstrates `Gate A1` (`F-P3C-01`): In frozen `P3-C`, `SemanticNormOutcome.consensus` is a
  public constructor, so an untrusted caller can fabricate `.consensus T c` on `T = []` or on
  arbitrary unverified `(T, c)` without ever invoking `certifySemanticConsensus`!
-/
def fabricatePublicOutcomeWithoutExecution (T : List ConcreteParseTree) (c : CanonicalMeaning) :
    SemanticNormOutcome :=
  SemanticNormOutcome.consensus T c

theorem public_outcome_allows_unverified_empty_trees (c : CanonicalMeaning) :
    ∃ out : SemanticNormOutcome, out = .consensus [] c :=
  ⟨fabricatePublicOutcomeWithoutExecution [] c, rfl⟩

/-! ### 2. Explicit `Gate A` Threat Taxonomy (`A1` ~ `A6`) & Security-Model Scope Boundary -/

inductive ProvenanceThreatId where
  | A1_PublicConstructorForgery
  | A2_ResultSubstitution
  | A3_InputOrEnvSubstitution
  | A4_BudgetOrCatalogSubstitution
  | A5_FailureOutcomeLaundering
  | A6_P4P5AuthorityEscalation
  deriving DecidableEq, Repr

/--
  Distinguishes what Lean 4 type/proof encapsulation guarantees vs out-of-kernel operational
  threats (`Mandate §Gate B & §4`: never overclaim binary/memory protection from `private mk`!).
-/
inductive SecurityAssuranceBoundary where
  | verifiedInLeanTypedKernelAPI
  | heldOutOfKernelBinaryMemoryRuntimeTamper
  deriving DecidableEq, Repr

/-! ### 3. Full 5-Component Verification Context (`ProvenanceContext`) & Fast `Bool` Equality -/

/--
  Complete input context `i` bound to `PneumaOmega.P3C.certifySemanticConsensus`:
  `(catalog, numCfg, scopeEnv, budget, rawBytes)`.
-/
structure ProvenanceContext where
  catalog  : ClosedEntityCatalog
  numCfg   : NumericGateConfig
  scopeEnv : ScopeEnv
  budget   : ResourceBudget
  rawBytes : List UInt8
  deriving DecidableEq, Repr

/-- Evaluates frozen `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` without duplicating `P3-C`. -/
def runP3COnContext (ctx : ProvenanceContext) : SemanticNormOutcome :=
  certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes

def eqBytesBool : List UInt8 → List UInt8 → Bool
  | [], [] => true
  | b1 :: r1, b2 :: r2 => (b1 == b2) && eqBytesBool r1 r2
  | _, _ => false

theorem eqBytesBool_iff (xs ys : List UInt8) :
    eqBytesBool xs ys = true ↔ xs = ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp [eqBytesBool]
  | cons x rxs ih =>
    cases ys with
    | nil => simp [eqBytesBool]
    | cons y rys =>
      unfold eqBytesBool
      rw [Bool.and_eq_true, beq_iff_eq, ih]
      simp

def eqCatalogEntryBool (e1 e2 : CatalogEntry) : Bool :=
  (e1.sort == e2.sort) && eqStrBool e1.entityId e2.entityId && eqStrBool e1.lexeme e2.lexeme

theorem eqCatalogEntryBool_iff (e1 e2 : CatalogEntry) :
    eqCatalogEntryBool e1 e2 = true ↔ e1 = e2 := by
  cases e1 with
  | mk s1 id1 lx1 =>
    cases e2 with
    | mk s2 id2 lx2 =>
      unfold eqCatalogEntryBool
      dsimp only
      rw [Bool.and_eq_true, Bool.and_eq_true, beq_iff_eq, eqStrBool_iff, eqStrBool_iff]
      constructor
      · rintro ⟨⟨rfl, rfl⟩, rfl⟩; rfl
      · intro h; injection h with hs hid hlx; exact ⟨⟨hs, hid⟩, hlx⟩

def eqCatalogEntriesBool : List CatalogEntry → List CatalogEntry → Bool
  | [], [] => true
  | x :: xs, y :: ys => eqCatalogEntryBool x y && eqCatalogEntriesBool xs ys
  | _, _ => false

theorem eqCatalogEntriesBool_iff (xs ys : List CatalogEntry) :
    eqCatalogEntriesBool xs ys = true ↔ xs = ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp [eqCatalogEntriesBool]
  | cons x rxs ih =>
    cases ys with
    | nil => simp [eqCatalogEntriesBool]
    | cons y rys =>
      unfold eqCatalogEntriesBool
      rw [Bool.and_eq_true, eqCatalogEntryBool_iff, ih]
      simp

def eqCatalogBool (c1 c2 : ClosedEntityCatalog) : Bool :=
  eqCatalogEntriesBool c1.entries c2.entries

theorem eqCatalogBool_iff (c1 c2 : ClosedEntityCatalog) :
    eqCatalogBool c1 c2 = true ↔ c1 = c2 := by
  cases c1 with
  | mk es1 =>
    cases c2 with
    | mk es2 =>
      unfold eqCatalogBool
      dsimp only
      rw [eqCatalogEntriesBool_iff]
      exact ⟨fun h => by rw [h], fun h => by injection h⟩

def eqScopeEnvBool (e1 e2 : ScopeEnv) : Bool :=
  eqStrBool e1.cohortId e2.cohortId &&
  eqStrBool e1.expectedDesignHead e2.expectedDesignHead &&
  (e1.quoteIsolation == e2.quoteIsolation)

theorem eqScopeEnvBool_iff (e1 e2 : ScopeEnv) :
    eqScopeEnvBool e1 e2 = true ↔ e1 = e2 := by
  cases e1 with
  | mk c1 d1 q1 =>
    cases e2 with
    | mk c2 d2 q2 =>
      unfold eqScopeEnvBool
      dsimp only
      rw [Bool.and_eq_true, Bool.and_eq_true, eqStrBool_iff, eqStrBool_iff, beq_iff_eq]
      constructor
      · rintro ⟨⟨rfl, rfl⟩, rfl⟩; rfl
      · intro h; injection h with hc hd hq; exact ⟨⟨hc, hd⟩, hq⟩

def eqBudgetBool (b1 b2 : ResourceBudget) : Bool :=
  (b1.maxBytes == b2.maxBytes) &&
  (b1.maxSteps == b2.maxSteps) &&
  (b1.maxForestNodes == b2.maxForestNodes) &&
  (b1.maxReadings == b2.maxReadings)

theorem eqBudgetBool_iff (b1 b2 : ResourceBudget) :
    eqBudgetBool b1 b2 = true ↔ b1 = b2 := by
  cases b1 with
  | mk mb1 ms1 mn1 mr1 =>
    cases b2 with
    | mk mb2 ms2 mn2 mr2 =>
      unfold eqBudgetBool
      dsimp only
      simp only [Bool.and_eq_true, beq_iff_eq]
      constructor
      · rintro ⟨⟨⟨rfl, rfl⟩, rfl⟩, rfl⟩; rfl
      · intro h; injection h with h1 h2 h3 h4; exact ⟨⟨⟨h1, h2⟩, h3⟩, h4⟩

def eqNumCfgBool (n1 n2 : NumericGateConfig) : Bool :=
  (n1.maxIntDigits == n2.maxIntDigits) &&
  (n1.maxFracDigits == n2.maxFracDigits)

theorem eqNumCfgBool_iff (n1 n2 : NumericGateConfig) :
    eqNumCfgBool n1 n2 = true ↔ n1 = n2 := by
  cases n1 with
  | mk i1 f1 =>
    cases n2 with
    | mk i2 f2 =>
      unfold eqNumCfgBool
      dsimp only
      rw [Bool.and_eq_true, beq_iff_eq, beq_iff_eq]
      constructor
      · rintro ⟨rfl, rfl⟩; rfl
      · intro h; injection h with hi hf; exact ⟨hi, hf⟩

def parseTreeListEqBool : List ConcreteParseTree → List ConcreteParseTree → Bool
  | [], [] => true
  | t1 :: r1, t2 :: r2 => parseTreeEqBool t1 t2 && parseTreeListEqBool r1 r2
  | _, _ => false

theorem parseTreeListEqBool_iff (xs ys : List ConcreteParseTree) :
    parseTreeListEqBool xs ys = true ↔ xs = ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp [parseTreeListEqBool]
  | cons x rxs ih =>
    cases ys with
    | nil => simp [parseTreeListEqBool]
    | cons y rys =>
      unfold parseTreeListEqBool
      rw [Bool.and_eq_true, parseTreeEqBool_iff, ih]
      simp

/-! ### 4. Declarative Provenance & Consensus Contract (`Gate A` / `Gate C`) -/

/--
  **Declarative Execution-Provenance Relation (`ExecProvenanceSpec`)**:
  `T` and `c` are authentically produced by executing frozen `PneumaOmega.P3C.certifySemanticConsensus`
  on the exact 5-component context `ctx`.
-/
def ExecProvenanceSpec (ctx : ProvenanceContext) (T : List ConcreteParseTree) (c : CanonicalMeaning) : Prop :=
  certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes =
    .consensus T c

/--
  **Declarative End-to-End Semantic Consensus Contract (`DeclarativeConsensusContract`)**:
  Conjoins bounded exhaustive parse enumeration (`P3-B`), independent `R0` trap-policy compliance,
  canonical fixed-point normality, universal reading consensus across `T`, and relative model-theoretic
  denotation preservation under `ExtensionalContrastiveWorld W` (`Mandate §PO-R1-03`).
-/
def DeclarativeConsensusContract (ctx : ProvenanceContext)
    (T : List ConcreteParseTree) (c : CanonicalMeaning) : Prop :=
  parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes = .enumerated T ∧
  StrictAsciiDomainSupported ctx.rawBytes ∧
  T ≠ [] ∧
  NoDupTrees T ∧
  (∀ τ : ConcreteParseTree, τ ∈ T ↔
     ValidParse_GFrozen ctx.catalog ctx.numCfg ctx.scopeEnv ctx.rawBytes τ) ∧
  TrapPolicyPermitsForest T ∧
  IsCanonicalNorm (embedCanonical c) ∧
  (∃ pairs : List (ConcreteParseTree × RawSemanticTerm),
     extractAllMeanings ctx.scopeEnv T = .ok pairs ∧
     pairs.map Prod.fst = T ∧
     UniversalConsensus pairs c ∧
     ∀ p ∈ pairs,
       extractRawMeaning ctx.scopeEnv p.1 = .ok p.2 ∧
       SemEq (embedCanonical c) p.2 ∧
       (∀ W : SemanticWorld, ExtensionalContrastiveWorld W →
          (Denotes W (embedCanonical c) ↔ Denotes W p.2)))

/-! ### 5. Downstream `P4` / `P5` Non-Escalation Boundary Interfaces (`A6` / `PO-R1-05`) -/

/--
  Uninhabited / unconstructible `P4` Clinical Fact Authorization Token (`NOT_AUTHORIZED` in `R1`):
  Requires universal empirical truth across admissible clinical evidence models — a property NOT
  entailed by linguistic semantic consensus!
-/
structure P4ClinicalTruthCert (c : CanonicalMeaning) where
  private mk ::
  hNotAuthorizedLock : False
  hUniversalTruth    : ∀ W : SemanticWorld, ExtensionalContrastiveWorld W → Denotes W (embedCanonical c)

/--
  Uninhabited / unconstructible `P5` Final `CertifiedOutput` Admission Token (`NOT_AUTHORIZED` in `R1`):
  Cannot be constructed from `CertifiedSemanticConsensus` without future `P4` + `P5` authorization!
-/
structure P5FinalCertifiedOutput where
  private mk ::
  hNotAuthorizedLock : False

theorem p4ClinicalTruthCert_uninhabited (c : CanonicalMeaning) :
    P4ClinicalTruthCert c → False :=
  fun cert => cert.hNotAuthorizedLock

theorem p5FinalCertifiedOutput_uninhabited :
    P5FinalCertifiedOutput → False :=
  fun cert => cert.hNotAuthorizedLock

end PneumaOmega.P3C.ProvenanceR1
````

### File 6: `02_detached_checker/P3CProvenanceChecker.lean` (SHA-256: `7652739A9519575C251BCE2DCE9D192D1E79B7603BC0366B9289BA233DC856D3`)
````lean
import P3CProvenanceChecker.SealedProvenanceGate
````

### File 7: `02_detached_checker/P3CProvenanceChecker/SealedProvenanceGate.lean` (SHA-256: `49DA95B50CE09E31279FD8245D4B1BD7D05E02972239004C70A3A21DEF907805`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`Gate B` & `Gate C` Sealed Provenance Gate)
  02_detached_checker/P3CProvenanceChecker/SealedProvenanceGate.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`)

  Implements:
    1. `CertifiedSemanticConsensus (ctx : ProvenanceContext)` (`private mk ::`):
       Type-indexed proof-carrying consensus witness whose private constructor is reachable ONLY
       from an actual `.consensus` execution of `PneumaOmega.P3C.certifySemanticConsensus` on `ctx`!
    2. `mintCertifiedConsensus (ctx : ProvenanceContext) : ProvenanceMintOutcome ctx`:
       Total 5-way provenance-minting gate directly wrapping `certifySemanticConsensus` without
       duplicating `P3-C` normalization logic.
    3. `UntrustedConsensusClaim` & `verifyUntrustedConsensusClaim`:
       Detached deterministic whitebox replay verifier blocking all `A1`~`A5` external attacks
       (public `.consensus` forgery, canonical/tree substitution, raw-byte/scopeEnv substitution,
       budget/catalog/numCfg substitution, and failure-outcome laundering) with pinpoint diagnostics.
    4. Core Soundness, Input-Binding, Consensus-Preservation, Fail-Closed, Singleton-Uniqueness,
       Replay-Faithfulness, and Authority-Separation theorems (`PO-R1-01` ~ `PO-R1-06`).
-/
import P3CProvenanceSpec

namespace PneumaOmega.P3C.ProvenanceR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C

/-! ### 1. Sealed Proof-Carrying Semantic Consensus Type (`CertifiedSemanticConsensus` — `Gate B`) -/

/--
  **Sealed Proof-Carrying Semantic Consensus (`CertifiedSemanticConsensus ctx`)**:
  - Indexed by the exact 5-component `ctx : ProvenanceContext` (`catalog`, `numCfg`, `scopeEnv`, `budget`, `rawBytes`).
  - Sealed via `private mk ::` so external callers cannot invoke its constructor directly.
  - Carries the machine-checked execution-provenance witness `hExecProvenance` proving that
    `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` actually returned `.consensus trees canonical`!
  - Zero public mutators exist; moreover `certifiedSemanticConsensus_unique` proves that for any `ctx`,
    at most ONE `CertifiedSemanticConsensus ctx` value exists (`c₁ = c₂`)!
-/
structure CertifiedSemanticConsensus (ctx : ProvenanceContext) where
  private mk ::
  trees           : List ConcreteParseTree
  canonical       : CanonicalMeaning
  hExecProvenance :
    certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes =
      .consensus trees canonical
  deriving DecidableEq

/--
  **Proof-Irrelevant Canonical Uniqueness (`certifiedSemanticConsensus_unique`)**:
  Even if two `CertifiedSemanticConsensus ctx` witnesses exist for the same `ctx`, they are
  provably IDENTICAL (`c₁ = c₂`), preventing any internal field or proof substitution!
-/
theorem certifiedSemanticConsensus_unique {ctx : ProvenanceContext}
    (c₁ c₂ : CertifiedSemanticConsensus ctx) :
    c₁ = c₂ := by
  rcases c₁ with ⟨t1, m1, h1⟩
  rcases c₂ with ⟨t2, m2, h2⟩
  have heq : SemanticNormOutcome.consensus t1 m1 = SemanticNormOutcome.consensus t2 m2 :=
    h1.symm.trans h2
  injection heq with ht hm
  subst t2; subst m2
  rfl

/-! ### 2. Total 5-Way Minting Gate (`mintCertifiedConsensus`) -/

/--
  5-way outcome of `mintCertifiedConsensus ctx`:
  Mints `CertifiedSemanticConsensus ctx` ONLY on `.consensus`, and carries explicit negative
  execution-provenance proofs on all 4 failure branches!
-/
inductive ProvenanceMintOutcome (ctx : ProvenanceContext) where
  | admitted
      (cert : CertifiedSemanticConsensus ctx)
  | rejectedAmbiguous
      (trees   : List ConcreteParseTree)
      (witness : AmbiguityRefutationWitness)
      (hExec   : runP3COnContext ctx = .ambiguousReadings trees witness)
  | rejectedExtractionFailure
      (trees : List ConcreteParseTree)
      (err   : ForestExtractionError)
      (hExec : runP3COnContext ctx = .semanticExtractionFailure trees err)
  | rejectedTrapPolicy
      (trees     : List ConcreteParseTree)
      (candidate : CanonicalMeaning)
      (diag      : TrapPolicyDiag)
      (hExec     : runP3COnContext ctx = .trapPolicyRejected trees candidate diag)
  | rejectedUpstream
      (diag  : UpstreamParseDiag)
      (hExec : runP3COnContext ctx = .upstreamRejected diag)

/--
  **Primary Provenance-Minting Gate (`mintCertifiedConsensus`)**:
  Evaluates frozen `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` and mints the sealed
  `CertifiedSemanticConsensus ctx` iff `.consensus` is genuinely produced.
-/
def mintCertifiedConsensus (ctx : ProvenanceContext) : ProvenanceMintOutcome ctx :=
  match h : certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | .consensus T c                 => .admitted ⟨T, c, h⟩
  | .ambiguousReadings T w         => .rejectedAmbiguous T w h
  | .semanticExtractionFailure T e => .rejectedExtractionFailure T e h
  | .trapPolicyRejected T c d      => .rejectedTrapPolicy T c d h
  | .upstreamRejected d            => .rejectedUpstream d h

/-! ### 3. Detached Whitebox Replay Verifier Against `A1` ~ `A5` Untrusted Claims -/

/--
  Untrusted external claim submitted across a module/serialization boundary (`A1` ~ `A5` surface):
  Pairs a claimed `ProvenanceContext` with a raw public `SemanticNormOutcome`.
-/
structure UntrustedConsensusClaim where
  claimedCtx     : ProvenanceContext
  claimedOutcome : SemanticNormOutcome
  deriving DecidableEq

/-- Exports an authentic `CertifiedSemanticConsensus ctx` to an external claim bundle. -/
def exportUntrustedClaim {ctx : ProvenanceContext} (cert : CertifiedSemanticConsensus ctx) :
    UntrustedConsensusClaim :=
  { claimedCtx     := ctx
    claimedOutcome := .consensus cert.trees cert.canonical }

/-- Pinpoint rejection reasons mapped directly to Threat Vectors `A1` ~ `A5`. -/
inductive ProvenanceRejectReason where
  | rawBytesMismatch                                        -- `A3`: Input string/bytes tampered
  | scopeEnvMismatch                                        -- `A3`: `ScopeEnv` tampered
  | budgetMismatch                                          -- `A4`: `ResourceBudget` tampered
  | catalogMismatch                                         -- `A4`: `ClosedEntityCatalog` tampered
  | numCfgMismatch                                          -- `A4`: `NumericGateConfig` tampered
  | nonConsensusOutcomeSubmitted                            -- `A5`: Non-consensus outcome submitted
  | forgedConsensusOnAmbiguousInput                         -- `A1`/`A5`: Forged `.consensus` on `T1`/`T2`/`T4`
  | forgedConsensusOnExtractionFailure (d : ExtractionFailureDiag) -- `A1`/`A5`: Forged on extraction error
  | forgedConsensusOnTrapRejected      (d : TrapPolicyDiag) -- `A1`/`A5`: Forged on `T3`/`T5`/trap
  | forgedConsensusOnUpstreamRejected  (d : UpstreamParseDiag) -- `A1`/`A5`: Forged on OOD/Overflow/`[]`
  | substitutedCanonicalMeaning                             -- `A2`: Canonical meaning `c' ≠ c` substituted
  | substitutedParseForest                                  -- `A2`: Parse forest `T' ≠ T` substituted
  deriving DecidableEq, Repr

/-- Checks exact 5-field context match (`claimedCtx == targetCtx`) with pinpoint `A3`/`A4` diagnostics. -/
def checkContextMatch (targetCtx claimedCtx : ProvenanceContext) : Option ProvenanceRejectReason :=
  if !eqBytesBool targetCtx.rawBytes claimedCtx.rawBytes then
    some .rawBytesMismatch
  else if !eqScopeEnvBool targetCtx.scopeEnv claimedCtx.scopeEnv then
    some .scopeEnvMismatch
  else if !eqBudgetBool targetCtx.budget claimedCtx.budget then
    some .budgetMismatch
  else if !eqCatalogBool targetCtx.catalog claimedCtx.catalog then
    some .catalogMismatch
  else if !eqNumCfgBool targetCtx.numCfg claimedCtx.numCfg then
    some .numCfgMismatch
  else
    none

theorem checkContextMatch_none_iff (targetCtx claimedCtx : ProvenanceContext) :
    checkContextMatch targetCtx claimedCtx = none ↔ claimedCtx = targetCtx := by
  cases targetCtx with
  | mk cat1 num1 env1 bud1 bs1 =>
    cases claimedCtx with
    | mk cat2 num2 env2 bud2 bs2 =>
      unfold checkContextMatch
      dsimp only
      by_cases hbs : eqBytesBool bs1 bs2 = true
      · rw [hbs]
        by_cases henv : eqScopeEnvBool env1 env2 = true
        · rw [henv]
          by_cases hbud : eqBudgetBool bud1 bud2 = true
          · rw [hbud]
            by_cases hcat : eqCatalogBool cat1 cat2 = true
            · rw [hcat]
              by_cases hnum : eqNumCfgBool num1 num2 = true
              · rw [hnum]
                have e1 := ((eqBytesBool_iff _ _).mp hbs).symm
                have e2 := ((eqScopeEnvBool_iff _ _).mp henv).symm
                have e3 := ((eqBudgetBool_iff _ _).mp hbud).symm
                have e4 := ((eqCatalogBool_iff _ _).mp hcat).symm
                have e5 := ((eqNumCfgBool_iff _ _).mp hnum).symm
                subst bs2; subst env2; subst bud2; subst cat2; subst num2
                simp
              · have hnf : eqNumCfgBool num1 num2 = false := Bool.eq_false_iff.mpr hnum
                rw [hnf]; simp
                rintro _ rfl; exact False.elim (hnum ((eqNumCfgBool_iff _ _).mpr rfl))
            · have hcf : eqCatalogBool cat1 cat2 = false := Bool.eq_false_iff.mpr hcat
              rw [hcf]; simp
              rintro rfl; exact False.elim (hcat ((eqCatalogBool_iff _ _).mpr rfl))
          · have hbf : eqBudgetBool bud1 bud2 = false := Bool.eq_false_iff.mpr hbud
            rw [hbf]; simp
            rintro rfl rfl rfl rfl; exact False.elim (hbud ((eqBudgetBool_iff _ _).mpr rfl))
        · have hef : eqScopeEnvBool env1 env2 = false := Bool.eq_false_iff.mpr henv
          rw [hef]; simp
          rintro rfl rfl rfl; exact False.elim (henv ((eqScopeEnvBool_iff _ _).mpr rfl))
      · have hbsf : eqBytesBool bs1 bs2 = false := Bool.eq_false_iff.mpr hbs
        rw [hbsf]; simp
        rintro rfl rfl rfl rfl rfl
        exact hbs ((eqBytesBool_iff _ _).mpr rfl)

/--
  Pure non-dependent whitebox claim checker (`verifyClaimPure`) for zero-overhead kernel WHNF
  evaluation, paired with the proof-carrying `verifyUntrustedConsensusClaim` gate below.
-/
def verifyClaimPure (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim) :
    Except ProvenanceRejectReason (List ConcreteParseTree × CanonicalMeaning) :=
  match checkContextMatch targetCtx claim.claimedCtx with
  | some reason => .error reason
  | none =>
    match claim.claimedOutcome with
    | .consensus claimedTrees claimedCanon =>
      match certifySemanticConsensus targetCtx.catalog targetCtx.numCfg targetCtx.scopeEnv
              targetCtx.budget targetCtx.rawBytes with
      | .ambiguousReadings _ _           => .error .forgedConsensusOnAmbiguousInput
      | .semanticExtractionFailure _ err => .error (.forgedConsensusOnExtractionFailure err.diag)
      | .trapPolicyRejected _ _ d        => .error (.forgedConsensusOnTrapRejected d)
      | .upstreamRejected d              => .error (.forgedConsensusOnUpstreamRejected d)
      | .consensus actualTrees actualCanon =>
        if !canonicalMeaningEqBool actualCanon claimedCanon then
          .error .substitutedCanonicalMeaning
        else if !parseTreeListEqBool actualTrees claimedTrees then
          .error .substitutedParseForest
        else
          .ok (actualTrees, actualCanon)
    | _ => .error .nonConsensusOutcomeSubmitted

/--
  Forest-level whitebox consensus verifier (`verifyForestConsensusPure`):
  Directly checks an untrusted `(targetForest, claimedCanon)` pair against `P3-C`'s `evalForestPure`,
  pinpointing `forgedConsensusOnExtractionFailure` on malformed/bad-anchor parse trees (`A5c`).
-/
def verifyForestConsensusPure (env : ScopeEnv) (targetForest : List ConcreteParseTree)
    (claimedCanon : CanonicalMeaning) : Except ProvenanceRejectReason CanonicalMeaning :=
  match evalForestPure env targetForest with
  | .ambiguousReadings _ _           => .error .forgedConsensusOnAmbiguousInput
  | .semanticExtractionFailure _ err => .error (.forgedConsensusOnExtractionFailure err.diag)
  | .trapPolicyRejected _ _ d        => .error (.forgedConsensusOnTrapRejected d)
  | .upstreamRejected d              => .error (.forgedConsensusOnUpstreamRejected d)
  | .consensus _ actualCanon =>
    if !canonicalMeaningEqBool actualCanon claimedCanon then
      .error .substitutedCanonicalMeaning
    else
      .ok actualCanon

/--
  **Detached Whitebox Replay Verifier (`verifyUntrustedConsensusClaim` — `Gate B` / `PO-R1-06`)**:
  Independently verifies that `claim.claimedCtx = targetCtx`, recomputes `certifySemanticConsensus`
  on `targetCtx`, verifies exact equality of `claimedCanon` and `claimedTrees`, and returns a
  sealed `CertifiedSemanticConsensus targetCtx` iff every check succeeds!
-/
def verifyUntrustedConsensusClaim (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim) :
    Except ProvenanceRejectReason (CertifiedSemanticConsensus targetCtx) :=
  match checkContextMatch targetCtx claim.claimedCtx with
  | some reason => .error reason
  | none =>
    match claim.claimedOutcome with
    | .consensus claimedTrees claimedCanon =>
      match h : certifySemanticConsensus targetCtx.catalog targetCtx.numCfg targetCtx.scopeEnv
                  targetCtx.budget targetCtx.rawBytes with
      | .ambiguousReadings _ _           => .error .forgedConsensusOnAmbiguousInput
      | .semanticExtractionFailure _ err => .error (.forgedConsensusOnExtractionFailure err.diag)
      | .trapPolicyRejected _ _ d        => .error (.forgedConsensusOnTrapRejected d)
      | .upstreamRejected d              => .error (.forgedConsensusOnUpstreamRejected d)
      | .consensus actualTrees actualCanon =>
        if !canonicalMeaningEqBool actualCanon claimedCanon then
          .error .substitutedCanonicalMeaning
        else if !parseTreeListEqBool actualTrees claimedTrees then
          .error .substitutedParseForest
        else
          .ok ⟨actualTrees, actualCanon, h⟩
    | _ => .error .nonConsensusOutcomeSubmitted

theorem verifyUntrustedConsensusClaim_proj_eq (targetCtx : ProvenanceContext)
    (claim : UntrustedConsensusClaim) :
    (verifyUntrustedConsensusClaim targetCtx claim).map (fun c => (c.trees, c.canonical)) =
      verifyClaimPure targetCtx claim := by
  unfold verifyUntrustedConsensusClaim verifyClaimPure
  cases checkContextMatch targetCtx claim.claimedCtx with
  | some _ => rfl
  | none =>
    cases claim.claimedOutcome with
    | ambiguousReadings _ _ => rfl
    | semanticExtractionFailure _ _ => rfl
    | trapPolicyRejected _ _ _ => rfl
    | upstreamRejected _ => rfl
    | consensus ct cc =>
      dsimp only
      split
      · rename_i _ _ heq; rw [heq]; rfl
      · rename_i _ _ heq; rw [heq]; rfl
      · rename_i _ _ _ heq; rw [heq]; rfl
      · rename_i _ heq; rw [heq]; rfl
      · rename_i atrees acanon heq
        conv => rhs; rw [heq]
        dsimp only
        by_cases hc : (!canonicalMeaningEqBool acanon cc) = true
        · rw [if_pos hc, if_pos hc]; rfl
        · rw [if_neg hc, if_neg hc]
          by_cases ht : (!parseTreeListEqBool atrees ct) = true
          · rw [if_pos ht, if_pos ht]; rfl
          · rw [if_neg ht, if_neg ht]; rfl

/-! ### 4. Core `Gate C` Theorems (`PO-R1-01` ~ `PO-R1-06`) -/

/--
  **Theorem `PO-R1-01` (`construction_soundness`)**:
  Any inhabitant `cert : CertifiedSemanticConsensus ctx` guarantees that executing actual frozen
  `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` returns `.consensus cert.trees cert.canonical`,
  and `mintCertifiedConsensus ctx` returns `.admitted cert`!
-/
theorem construction_soundness (ctx : ProvenanceContext) (cert : CertifiedSemanticConsensus ctx) :
    ExecProvenanceSpec ctx cert.trees cert.canonical ∧
    mintCertifiedConsensus ctx = .admitted cert := by
  refine ⟨cert.hExecProvenance, ?_⟩
  unfold mintCertifiedConsensus
  split
  · rename_i T0 c0 h0
    have heq : CertifiedSemanticConsensus.mk T0 c0 h0 = cert :=
      certifiedSemanticConsensus_unique _ _
    rw [heq]
  · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
  · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
  · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
  · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction

/--
  **Theorem `PO-R1-02a` (`input_binding_replay_rejects_context_mismatch`)**:
  Whenever `claim.claimedCtx ≠ targetCtx` (whether `rawBytes`, `scopeEnv`, `budget`, `catalog`,
  or `numCfg` differs), `verifyUntrustedConsensusClaim targetCtx claim` deterministically REJECTS!
-/
theorem input_binding_replay_rejects_context_mismatch
    (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim)
    (hne : claim.claimedCtx ≠ targetCtx) :
    ∃ reason : ProvenanceRejectReason,
      verifyUntrustedConsensusClaim targetCtx claim = .error reason := by
  unfold verifyUntrustedConsensusClaim
  cases hcm : checkContextMatch targetCtx claim.claimedCtx with
  | some r => exact ⟨r, rfl⟩
  | none =>
    have heq := (checkContextMatch_none_iff targetCtx claim.claimedCtx).mp hcm
    exact False.elim (hne heq)

/--
  **Theorem `PO-R1-03` (`consensus_preservation_sound`)**:
  Every `cert : CertifiedSemanticConsensus ctx` entails the full `DeclarativeConsensusContract`:
  bounded exhaustive `P3-B` parse set, `T ≠ []`, `NoDupTrees`, `TrapPolicyPermitsForest`,
  `IsCanonicalNorm`, universal reading `SemEq` equivalence, AND relative `Denotes` preservation
  under `ExtensionalContrastiveWorld W` (explicitly preserving `ExtensionalContrastiveWorld`!).
-/
theorem consensus_preservation_sound (ctx : ProvenanceContext)
    (cert : CertifiedSemanticConsensus ctx) :
    DeclarativeConsensusContract ctx cert.trees cert.canonical := by
  have ⟨hp, hsup, hne, hnodup, hexact, htrap, hcanon, ⟨pairs, hext, hmap, hcons, hall⟩⟩ :=
    certifySemanticConsensus_sound ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes
      cert.trees cert.canonical cert.hExecProvenance
  refine ⟨hp, hsup, hne, hnodup, hexact, htrap, hcanon, ⟨pairs, hext, hmap, hcons, ?_⟩⟩
  intro p hp_mem
  rcases hall p hp_mem with ⟨hext_p, hsem_p⟩
  refine ⟨hext_p, hsem_p, ?_⟩
  intro W hExtW
  exact semEq_sound_for_denotes hsem_p W hExtW

/--
  **Theorem `PO-R1-04` (`fail_closed_all_non_consensus_outcomes`)**:
  Whenever `certifySemanticConsensus` on `ctx` returns ANY of the 4 non-consensus outcomes
  (`.ambiguousReadings`, `.semanticExtractionFailure`, `.trapPolicyRejected`, `.upstreamRejected`),
  `CertifiedSemanticConsensus ctx` is **mathematically uninhabited (`CertifiedSemanticConsensus ctx → False`)**,
  AND `verifyUntrustedConsensusClaim ctx claim` rejects EVERY untrusted `claim`!
-/
theorem fail_closed_all_non_consensus_outcomes (ctx : ProvenanceContext) :
    ((∀ T w, runP3COnContext ctx = .ambiguousReadings T w →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ T e, runP3COnContext ctx = .semanticExtractionFailure T e →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ T c d, runP3COnContext ctx = .trapPolicyRejected T c d →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ d, runP3COnContext ctx = .upstreamRejected d →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r))) := by
  have helper :
      (∀ T c, runP3COnContext ctx ≠ .consensus T c) →
      (CertifiedSemanticConsensus ctx → False) ∧
      (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r) := by
    intro hno
    refine ⟨?_, ?_⟩
    · intro cert
      exact hno cert.trees cert.canonical cert.hExecProvenance
    · intro cl
      unfold verifyUntrustedConsensusClaim
      cases checkContextMatch ctx cl.claimedCtx with
      | some r => exact ⟨r, rfl⟩
      | none =>
        cases cl.claimedOutcome with
        | ambiguousReadings _ _ => exact ⟨.nonConsensusOutcomeSubmitted, rfl⟩
        | semanticExtractionFailure _ _ => exact ⟨.nonConsensusOutcomeSubmitted, rfl⟩
        | trapPolicyRejected _ _ _ => exact ⟨.nonConsensusOutcomeSubmitted, rfl⟩
        | upstreamRejected _ => exact ⟨.nonConsensusOutcomeSubmitted, rfl⟩
        | consensus ct cc =>
          dsimp only
          split
          · exact ⟨.forgedConsensusOnAmbiguousInput, rfl⟩
          · rename_i err _; exact ⟨.forgedConsensusOnExtractionFailure err.diag, rfl⟩
          · rename_i d _; exact ⟨.forgedConsensusOnTrapRejected d, rfl⟩
          · rename_i d _; exact ⟨.forgedConsensusOnUpstreamRejected d, rfl⟩
          · rename_i atrees acanon hcon
            exact False.elim (hno atrees acanon hcon)
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro T w h; apply helper; intro T' c' hc; rw [h] at hc; contradiction
  · intro T e h; apply helper; intro T' c' hc; rw [h] at hc; contradiction
  · intro T c d h; apply helper; intro T' c' hc; rw [h] at hc; contradiction
  · intro d h; apply helper; intro T' c' hc; rw [h] at hc; contradiction

/--
  **Theorem `PO-R1-05` (`no_authority_escalation_to_P4_or_P5`)**:
  1. `P4ClinicalTruthCert` and `P5FinalCertifiedOutput` remain uninhabited (`NOT_AUTHORIZED`), so
     no function `CertifiedSemanticConsensus ctx → P5FinalCertifiedOutput` can ever produce a `P5` output.
  2. Even for an inhabited `cert : CertifiedSemanticConsensus ctx` whose canonical meaning is a
     descriptive `G-01` incidence claim, there exist extensional clinical worlds `(W_true, W_false)`
     where `Denotes W_true` holds while `¬ Denotes W_false` — proving `CertifiedSemanticConsensus`
     certifies **provenance of linguistic consensus ONLY**, never clinical/empirical truth!
-/
theorem no_authority_escalation_to_P4_or_P5
    (ctx : ProvenanceContext) (cert : CertifiedSemanticConsensus ctx)
    (coh win ev k n pct : String)
    (hCanon : cert.canonical =
      normalizeMeaning (.scopedAtom (.cohortBound coh) "x_init" (.descIncidence win ev k n pct) [])) :
    (P5FinalCertifiedOutput → False) ∧
    (P4ClinicalTruthCert cert.canonical → False) ∧
    (∃ (W_true W_false : SemanticWorld),
       ExtensionalContrastiveWorld W_true ∧
       ExtensionalContrastiveWorld W_false ∧
       Denotes W_true (embedCanonical cert.canonical) ∧
       ¬ Denotes W_false (embedCanonical cert.canonical)) := by
  refine ⟨p5FinalCertifiedOutput_uninhabited, p4ClinicalTruthCert_uninhabited cert.canonical, ?_⟩
  rw [hCanon]
  exact consensus_does_not_certify_empirical_truth coh win ev k n pct

/--
  **Theorem `PO-R1-06` (`replay_faithfulness_iff`)**:
  Exact two-way correspondence between `CertifiedSemanticConsensus` and `verifyUntrustedConsensusClaim`:
  1. **Soundness**: `verifyUntrustedConsensusClaim targetCtx claim = .ok cert` implies
     `claim = exportUntrustedClaim cert`, `ExecProvenanceSpec targetCtx cert.trees cert.canonical`,
     and `mintCertifiedConsensus targetCtx = .admitted cert`.
  2. **Completeness**: For every authentic `cert : CertifiedSemanticConsensus targetCtx`,
     `verifyUntrustedConsensusClaim targetCtx (exportUntrustedClaim cert) = .ok cert`!
-/
theorem replay_faithfulness_iff (targetCtx : ProvenanceContext) :
    (∀ (claim : UntrustedConsensusClaim) (cert : CertifiedSemanticConsensus targetCtx),
       verifyUntrustedConsensusClaim targetCtx claim = .ok cert →
       claim = exportUntrustedClaim cert ∧
       ExecProvenanceSpec targetCtx cert.trees cert.canonical ∧
       mintCertifiedConsensus targetCtx = .admitted cert) ∧
    (∀ (cert : CertifiedSemanticConsensus targetCtx),
       verifyUntrustedConsensusClaim targetCtx (exportUntrustedClaim cert) = .ok cert) := by
  refine ⟨?_, ?_⟩
  · intro claim cert hok
    rcases claim with ⟨cCtx, cOut⟩
    unfold verifyUntrustedConsensusClaim at hok
    dsimp only at hok
    cases hcm : checkContextMatch targetCtx cCtx with
    | some _ => rw [hcm] at hok; contradiction
    | none =>
      rw [hcm] at hok
      have hctx_eq : cCtx = targetCtx := (checkContextMatch_none_iff targetCtx cCtx).mp hcm
      subst cCtx
      cases cOut with
      | ambiguousReadings _ _ => contradiction
      | semanticExtractionFailure _ _ => contradiction
      | trapPolicyRejected _ _ _ => contradiction
      | upstreamRejected _ => contradiction
      | consensus ct cc =>
        dsimp only at hok
        split at hok
        · contradiction
        · contradiction
        · contradiction
        · contradiction
        · rename_i atrees acanon hexec
          by_cases hc : (!canonicalMeaningEqBool acanon cc) = true
          · rw [if_pos hc] at hok; contradiction
          · rw [if_neg hc] at hok
            by_cases ht : (!parseTreeListEqBool atrees ct) = true
            · rw [if_pos ht] at hok; contradiction
            · rw [if_neg ht] at hok
              injection hok with hcert
              subst cert
              have hc_true : canonicalMeaningEqBool acanon cc = true :=
                by cases hb : canonicalMeaningEqBool acanon cc <;> simp_all
              have ht_true : parseTreeListEqBool atrees ct = true :=
                by cases hb : parseTreeListEqBool atrees ct <;> simp_all
              have hcc : acanon = cc := (canonicalMeaningEqBool_iff _ _).mp hc_true
              have hct : atrees = ct := (parseTreeListEqBool_iff _ _).mp ht_true
              subst cc; subst ct
              have ⟨hex, hmint⟩ := construction_soundness targetCtx ⟨atrees, acanon, hexec⟩
              exact ⟨rfl, hex, hmint⟩
  · intro cert
    unfold verifyUntrustedConsensusClaim exportUntrustedClaim
    dsimp only
    have hcm : checkContextMatch targetCtx targetCtx = none :=
      (checkContextMatch_none_iff targetCtx targetCtx).mpr rfl
    rw [hcm]
    dsimp only
    split
    · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
    · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
    · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
    · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
    · rename_i atrees acanon h0
      have heq_out : SemanticNormOutcome.consensus cert.trees cert.canonical =
                     SemanticNormOutcome.consensus atrees acanon :=
        cert.hExecProvenance.symm.trans h0
      injection heq_out with ht hc
      subst atrees; subst acanon
      have hcb : canonicalMeaningEqBool cert.canonical cert.canonical = true :=
        (canonicalMeaningEqBool_iff _ _).mpr rfl
      have htb : parseTreeListEqBool cert.trees cert.trees = true :=
        (parseTreeListEqBool_iff _ _).mpr rfl
      rw [hcb, htb]
      exact congrArg Except.ok (certifiedSemanticConsensus_unique _ _)

end PneumaOmega.P3C.ProvenanceR1
````

### File 8: `03_counterexamples/P3CProvenanceAttacks.lean` (SHA-256: `F36860CE8A75558EC7FF9B1BE2384EB31641FA640A7DC71DE0AFA44102C4AB97`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1
  Root export for `P3CProvenanceAttacks`
-/
import P3CProvenanceAttacks.AttackSuiteR1
````

### File 9: `03_counterexamples/P3CProvenanceAttacks/AttackSuiteR1.lean` (SHA-256: `814543BA4E33532A80E9722309DE80D1CE77E8375F6084FF4BCF41C2A6F55722`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`Gate D` & `PO-R1-07` Positive/Adversarial Attack Suite)
  03_counterexamples/P3CProvenanceAttacks/AttackSuiteR1.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`, zero `native_decide`)

  Implements:
    1. Exact equivalence bridge (`verifyClaimPure_error_iff`, `verifyClaimPure_ok_iff`) linking
       fast kernel `Bool` evaluation to proof-carrying `verifyUntrustedConsensusClaim`.
    2. Constructive non-vacuity extraction (`extractAdmittedCert` via `mintCertifiedConsensus`,
       NEVER invoking `private CertifiedSemanticConsensus.mk`) yielding concrete inhabited
       witnesses `certG01`, `certG11`, `certG15a`, `certG15b`, `certG16` (`PO-R1-07`).
    3. 24-Vector Symmetric `(PC, CE)` Suite (`12` pairs) covering all 12 `Gate D` requirements
       across Threat Classes `A1` ~ `A6`, mapped 1-to-1 to `(caseId, threatId, targetTheorem,
       expectedVerdict, actualVerdict, passed)` and proved via Lean kernel `decide` (`0` `native_decide`).
-/
import P3CProvenanceChecker
import P3CCounterexamples

namespace PneumaOmega.P3C.ProvenanceR1.Attacks

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1

/-! ### 1. Exact Equivalence Bridge Between `verifyClaimPure` and `verifyUntrustedConsensusClaim` -/

theorem verifyClaimPure_error_iff (targetCtx : ProvenanceContext)
    (claim : UntrustedConsensusClaim) (r : ProvenanceRejectReason) :
    verifyClaimPure targetCtx claim = .error r ↔
      verifyUntrustedConsensusClaim targetCtx claim = .error r := by
  rw [← verifyUntrustedConsensusClaim_proj_eq]
  cases verifyUntrustedConsensusClaim targetCtx claim with
  | error e => simp [Except.map]
  | ok c    => simp [Except.map]

theorem verifyClaimPure_ok_iff (targetCtx : ProvenanceContext)
    (claim : UntrustedConsensusClaim) (T : List ConcreteParseTree) (c : CanonicalMeaning) :
    verifyClaimPure targetCtx claim = .ok (T, c) ↔
      ∃ cert : CertifiedSemanticConsensus targetCtx,
        verifyUntrustedConsensusClaim targetCtx claim = .ok cert ∧
        cert.trees = T ∧ cert.canonical = c := by
  rw [← verifyUntrustedConsensusClaim_proj_eq]
  cases verifyUntrustedConsensusClaim targetCtx claim with
  | error e => simp [Except.map]
  | ok cert => simp [Except.map]

/-! ### 2. Canonical `ProvenanceContext` Fixtures Across `G`-Series, `T1`~`T5`, and Edge Inputs -/

def mkStdCtx (env : ScopeEnv) (budget : ResourceBudget) (s : String) : ProvenanceContext :=
  { catalog  := p3cTestCatalog
    numCfg   := frozenR22NumericConfig
    scopeEnv := env
    budget   := budget
    rawBytes := strToAsciiBytes s }

def ctxG01   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG01
def ctxG03   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG03
def ctxG05   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG05
def ctxG07   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG07
def ctxG09   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG09
def ctxG10   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG10
def ctxG11   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG11
def ctxG12   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG12
def ctxG13   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG13
def ctxG14   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG14
def ctxG15a  : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG15a_AB
def ctxG15b  : ProvenanceContext := mkStdCtx envDiscourse defaultParseBudget sG15b_BA
def ctxG16   : ProvenanceContext := mkStdCtx envDiscourse defaultParseBudget sG16

-- Dual-reading traps (`T1`, `T2`, `T4`) -> `AmbiguousReadings`
def ctxT1    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT1_AllNot
def ctxT2    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT2_ConfirmThat
def ctxT4    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT4_BarePlural

-- Single-reading traps (`T3`, `T5`) -> `TrapPolicyRejected`
def ctxT3    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT3_WhWhy
def ctxT5    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT5_Unscoped

-- Contrastive anchor mismatch (`out_mi` vs `out_death`) -> `SemanticExtractionFailure`
def sG16_BadAnchor : String :=
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality."

def ctxG16BadAnchor : ProvenanceContext := mkStdCtx envDiscourse defaultParseBudget sG16_BadAnchor

-- Upstream failure contexts (`OutOfDomain`, `ResourceOverflow`, `Enumerated []`)
def ctxNonAscii : ProvenanceContext :=
  { catalog  := p3cTestCatalog
    numCfg   := frozenR22NumericConfig
    scopeEnv := envAtomic
    budget   := defaultParseBudget
    rawBytes := [0x49, 0x6E, 0x20, 0xC3, 0xA9] }

def ctxT2Overflow : ProvenanceContext :=
  mkStdCtx envAtomic { defaultParseBudget with maxReadings := 1 } sT2_ConfirmThat

def ctxEmptyParse : ProvenanceContext :=
  mkStdCtx envAtomic defaultParseBudget sBadMultiDotG01

-- Tampered contexts for `A3` / `A4` substitution tests
def ctxG16AtomicEnv : ProvenanceContext :=
  { ctxG16 with scopeEnv := envAtomic }

def ctxG16BadDesignEnv : ProvenanceContext :=
  { ctxG16 with scopeEnv := envMismatchedDesign }

def ctxG14TinyBytesBudget : ProvenanceContext :=
  { ctxG14 with budget := { defaultParseBudget with maxBytes := 16 } }

def ctxG03EmptyCatalog : ProvenanceContext :=
  { ctxG03 with catalog := { entries := [] } }

def ctxG03TightNumCfg : ProvenanceContext :=
  { ctxG03 with numCfg := { maxIntDigits := 1, maxFracDigits := 1 } }

/-! ### 3. Concrete Non-Vacuity Witnesses (`PO-R1-07`) via Public `mintCertifiedConsensus` Gate -/

def expectedCanonG11 : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) [])

def expectedCanonG15Conj : CanonicalMeaning :=
  normalizeMeaning (.symConj
    (.scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) [])
    (.scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.existentialPos "sub_hr_sg" "ev_aki")) []))

private theorem isConsensusSingleEq_consensus_eq {T : List ConcreteParseTree}
    {c expected : CanonicalMeaning}
    (h : isConsensusSingleEq (.consensus T c) expected = true) :
    c = expected := by
  unfold isConsensusSingleEq at h
  cases T with
  | nil => contradiction
  | cons t rest =>
    cases rest with
    | nil => exact (canonicalMeaningEqBool_iff c expected).mp h
    | cons _ _ => contradiction

/--
  Extracts a sealed `CertifiedSemanticConsensus ctx` strictly from the public `mintCertifiedConsensus`
  gate given a `decide`-verified consensus check (`NEVER` calling `private CertifiedSemanticConsensus.mk`).
-/
def extractAdmittedCert (ctx : ProvenanceContext) (expected : CanonicalMeaning)
    (hok : isConsensusSingleEq (runP3COnContext ctx) expected = true) :
    CertifiedSemanticConsensus ctx :=
  match mintCertifiedConsensus ctx with
  | .admitted cert => cert
  | .rejectedAmbiguous _ _ hExec =>
    False.elim (by have h1 := hok; unfold isConsensusSingleEq at h1; rw [hExec] at h1; contradiction)
  | .rejectedExtractionFailure _ _ hExec =>
    False.elim (by have h1 := hok; unfold isConsensusSingleEq at h1; rw [hExec] at h1; contradiction)
  | .rejectedTrapPolicy _ _ _ hExec =>
    False.elim (by have h1 := hok; unfold isConsensusSingleEq at h1; rw [hExec] at h1; contradiction)
  | .rejectedUpstream _ hExec =>
    False.elim (by have h1 := hok; unfold isConsensusSingleEq at h1; rw [hExec] at h1; contradiction)

theorem extractAdmittedCert_canonical_eq (ctx : ProvenanceContext) (expected : CanonicalMeaning)
    (hok : isConsensusSingleEq (runP3COnContext ctx) expected = true) :
    (extractAdmittedCert ctx expected hok).canonical = expected := by
  unfold extractAdmittedCert
  split
  · rename_i cert _
    have h1 : isConsensusSingleEq (.consensus cert.trees cert.canonical) expected = true := by
      rw [← cert.hExecProvenance]; exact hok
    exact isConsensusSingleEq_consensus_eq h1
  · rename_i hRun _; exfalso; have h1 := hok; unfold isConsensusSingleEq at h1; rw [hRun] at h1; contradiction
  · rename_i hRun _; exfalso; have h1 := hok; unfold isConsensusSingleEq at h1; rw [hRun] at h1; contradiction
  · rename_i hRun _; exfalso; have h1 := hok; unfold isConsensusSingleEq at h1; rw [hRun] at h1; contradiction
  · rename_i hRun _; exfalso; have h1 := hok; unfold isConsensusSingleEq at h1; rw [hRun] at h1; contradiction

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem ctxG01_consensus_ok : isConsensusSingleEq (runP3COnContext ctxG01) expectedCanonG01 = true := by decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem ctxG11_consensus_ok : isConsensusSingleEq (runP3COnContext ctxG11) expectedCanonG11 = true := by decide

set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in
theorem ctxG15a_consensus_ok : isConsensusSingleEq (runP3COnContext ctxG15a) expectedCanonG15Conj = true := by decide

set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in
theorem ctxG15b_consensus_ok : isConsensusSingleEq (runP3COnContext ctxG15b) expectedCanonG15Conj = true := by decide

/-- Concrete inhabited `CertifiedSemanticConsensus ctxG01` witness (`PO-R1-07`). -/
def certG01 : CertifiedSemanticConsensus ctxG01 :=
  extractAdmittedCert ctxG01 expectedCanonG01 ctxG01_consensus_ok

/-- Concrete inhabited `CertifiedSemanticConsensus ctxG11` witness (`PO-R1-07`). -/
def certG11 : CertifiedSemanticConsensus ctxG11 :=
  extractAdmittedCert ctxG11 expectedCanonG11 ctxG11_consensus_ok

/-- Concrete inhabited `CertifiedSemanticConsensus ctxG15a` witness (`PO-R1-07`). -/
def certG15a : CertifiedSemanticConsensus ctxG15a :=
  extractAdmittedCert ctxG15a expectedCanonG15Conj ctxG15a_consensus_ok

/-- Concrete inhabited `CertifiedSemanticConsensus ctxG15b` witness (`PO-R1-07`). -/
def certG15b : CertifiedSemanticConsensus ctxG15b :=
  extractAdmittedCert ctxG15b expectedCanonG15Conj ctxG15b_consensus_ok

theorem certG01_canonical_eq : certG01.canonical = expectedCanonG01 :=
  extractAdmittedCert_canonical_eq ctxG01 expectedCanonG01 ctxG01_consensus_ok

theorem certG15_paraphrase_convergence : certG15a.canonical = certG15b.canonical := by
  have h1 := extractAdmittedCert_canonical_eq ctxG15a expectedCanonG15Conj ctxG15a_consensus_ok
  have h2 := extractAdmittedCert_canonical_eq ctxG15b expectedCanonG15Conj ctxG15b_consensus_ok
  exact h1.trans h2.symm

/-! ### 4. Deterministic Verdict Formatting & Helpers for 24-Vector `Gate D` Suite -/

def formatRejectReason : ProvenanceRejectReason → String
  | .rawBytesMismatch                        => "REJECT:rawBytesMismatch"
  | .scopeEnvMismatch                        => "REJECT:scopeEnvMismatch"
  | .budgetMismatch                          => "REJECT:budgetMismatch"
  | .catalogMismatch                         => "REJECT:catalogMismatch"
  | .numCfgMismatch                          => "REJECT:numCfgMismatch"
  | .nonConsensusOutcomeSubmitted            => "REJECT:nonConsensusOutcomeSubmitted"
  | .forgedConsensusOnAmbiguousInput         => "REJECT:forgedConsensusOnAmbiguousInput"
  | .forgedConsensusOnExtractionFailure (.invalidContrastiveAnchor _) =>
      "REJECT:forgedConsensusOnExtractionFailure(invalidContrastiveAnchor)"
  | .forgedConsensusOnExtractionFailure (.unsupportedReadingAlt _ _) =>
      "REJECT:forgedConsensusOnExtractionFailure(unsupportedReadingAlt)"
  | .forgedConsensusOnExtractionFailure (.unresolvedAnaphoricScope _ _) =>
      "REJECT:forgedConsensusOnExtractionFailure(unresolvedAnaphoricScope)"
  | .forgedConsensusOnExtractionFailure _    =>
      "REJECT:forgedConsensusOnExtractionFailure(other)"
  | .forgedConsensusOnTrapRejected .whFactivePresuppositionForbidden =>
      "REJECT:forgedConsensusOnTrapRejected(whFactivePresuppositionForbidden)"
  | .forgedConsensusOnTrapRejected .unscopedClauseForbidden =>
      "REJECT:forgedConsensusOnTrapRejected(unscopedClauseForbidden)"
  | .forgedConsensusOnTrapRejected _         =>
      "REJECT:forgedConsensusOnTrapRejected(parserOnlyTrap)"
  | .forgedConsensusOnUpstreamRejected (.outOfDomain _) =>
      "REJECT:forgedConsensusOnUpstreamRejected(outOfDomain)"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow _) =>
      "REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow)"
  | .forgedConsensusOnUpstreamRejected .emptyParseSet =>
      "REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)"
  | .substitutedCanonicalMeaning             => "REJECT:substitutedCanonicalMeaning"
  | .substitutedParseForest                  => "REJECT:substitutedParseForest"

def evalReplayVerdict (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim) : String :=
  match verifyClaimPure targetCtx claim with
  | .ok (trees, _) => "ADMIT:consensus(trees=" ++ toString trees.length ++ ")"
  | .error r       => formatRejectReason r

/-- Mint-then-export roundtrip verdict on a valid `ProvenanceContext` (`PC` path). -/
def evalAuthenticRoundtripVerdict (ctx : ProvenanceContext) : String :=
  match runP3COnContext ctx with
  | .consensus T c => evalReplayVerdict ctx { claimedCtx := ctx, claimedOutcome := .consensus T c }
  | _              => "MINT_FAILED"

/-- Forged `.consensus` claim using `forgedTrees` and `forgedCanon` against `targetCtx`. -/
def evalForgedConsensusVerdict (targetCtx claimedCtx : ProvenanceContext)
    (forgedTrees : List ConcreteParseTree) (forgedCanon : CanonicalMeaning) : String :=
  evalReplayVerdict targetCtx
    { claimedCtx     := claimedCtx
      claimedOutcome := .consensus forgedTrees forgedCanon }

/-- Forest-level consensus provenance verdict (`evalForestPure`-backed `A5c` check). -/
def evalForestVerdict (env : ScopeEnv) (targetForest : List ConcreteParseTree)
    (claimedCanon : CanonicalMeaning) : String :=
  match verifyForestConsensusPure env targetForest claimedCanon with
  | .ok _    => "ADMIT:forestConsensus"
  | .error r => formatRejectReason r

/-! ### 5. The 24 Symmetric `(PC, CE)` `Gate D` Vectors (`12` Pairs Across `A1` ~ `A6`) -/

-- PAIR-R1-01 (`A1`): Authentic `G-01` Mint+Replay vs Public `SemanticNormOutcome.consensus [] c` Forgery
def act_pc01 : String := evalAuthenticRoundtripVerdict ctxG01
def act_ce01 : String :=
  evalReplayVerdict ctxG01
    { claimedCtx     := ctxG01
      claimedOutcome := fabricatePublicOutcomeWithoutExecution [] expectedCanonG01 }

-- PAIR-R1-02 (`A2`): Authentic `G-15b` Mint+Replay (`c_15b = c_15a`) vs Canonical & Forest Substitution
def act_pc02 : String :=
  if isConsensusSingleEq (runP3COnContext ctxG15b) expectedCanonG15Conj then
    evalAuthenticRoundtripVerdict ctxG15b
  else "CANON_MISMATCH"

def act_ce02 : String :=
  match runP3COnContext ctxG15b with
  | .consensus trees15b _ =>
    evalForgedConsensusVerdict ctxG15b ctxG15b trees15b expectedCanonG01 ++ " & " ++
    evalForgedConsensusVerdict ctxG15b ctxG15b [synthTreeG15a_AB] expectedCanonG15Conj
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-03 (`A3a`): Authentic `G-11` Mint+Replay vs Cross-Input `G-01 -> G-11` Reuse & Header Spoofing
def act_pc03 : String := evalAuthenticRoundtripVerdict ctxG11
def act_ce03 : String :=
  match runP3COnContext ctxG01 with
  | .consensus trees01 canon01 =>
    evalForgedConsensusVerdict ctxG11 ctxG01 trees01 canon01 ++ " & " ++
    evalForgedConsensusVerdict ctxG11 ctxG11 trees01 canon01
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-04 (`A3b`): Authentic `G-16` (`envDiscourse`) vs `ScopeEnv` Tampering (`envAtomic` & `envMismatchedDesign`)
def act_pc04 : String := evalAuthenticRoundtripVerdict ctxG16
def act_ce04 : String :=
  match runP3COnContext ctxG16 with
  | .consensus trees16 canon16 =>
    evalForgedConsensusVerdict ctxG16AtomicEnv ctxG16 trees16 canon16 ++ " & " ++
    evalForgedConsensusVerdict ctxG16BadDesignEnv ctxG16BadDesignEnv trees16 canon16
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-05 (`A4a`): Authentic `G-14` (`defaultParseBudget`) vs Reduced `ResourceBudget` (`maxBytes := 16`)
def act_pc05 : String := evalAuthenticRoundtripVerdict ctxG14
def act_ce05 : String :=
  match runP3COnContext ctxG14 with
  | .consensus trees14 canon14 =>
    evalForgedConsensusVerdict ctxG14TinyBytesBudget ctxG14 trees14 canon14 ++ " & " ++
    evalForgedConsensusVerdict ctxG14TinyBytesBudget ctxG14TinyBytesBudget trees14 canon14
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-06 (`A4b`): Authentic `G-03` vs Tampered `ClosedEntityCatalog` & `NumericGateConfig`
def act_pc06 : String := evalAuthenticRoundtripVerdict ctxG03
def act_ce06 : String :=
  match runP3COnContext ctxG03 with
  | .consensus trees03 canon03 =>
    evalForgedConsensusVerdict ctxG03EmptyCatalog ctxG03 trees03 canon03 ++ " & " ++
    evalForgedConsensusVerdict ctxG03TightNumCfg ctxG03 trees03 canon03
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-07 (`A5a`): Authentic `G-09` vs `T1`·`T2`·`T4` `AmbiguousReadings` Forgery Bypass
def act_pc07 : String := evalAuthenticRoundtripVerdict ctxG09
def act_ce07 : String :=
  evalForgedConsensusVerdict ctxT1 ctxT1 [synthTreeG15a_AB] expectedCanonG11 ++ " & " ++
  evalForgedConsensusVerdict ctxT2 ctxT2 [synthTruncatedT2Alt1] expectedCanonG09 ++ " & " ++
  evalForgedConsensusVerdict ctxT4 ctxT4 [synthTreeG15a_AB] expectedCanonG11

-- PAIR-R1-08 (`A5b`): Authentic `G-10` & `G-12` vs `T3` & `T5` `TrapPolicyRejected` Forgery Bypass
def act_pc08 : String :=
  evalAuthenticRoundtripVerdict ctxG10 ++ " & " ++ evalAuthenticRoundtripVerdict ctxG12

def act_ce08 : String :=
  evalForgedConsensusVerdict ctxT3 ctxT3 [synthTruncatedT2Alt1] expectedCanonG10 ++ " & " ++
  evalForgedConsensusVerdict ctxT5 ctxT5 [synthTreeG15a_AB] expectedCanonG11

-- PAIR-R1-09 (`A5c`): Authentic `G-13` vs `SemanticExtractionFailure` (`BadAnchor` & `alt=3`) Disguised as Consensus
def act_pc09 : String := evalAuthenticRoundtripVerdict ctxG13
def act_ce09 : String :=
  evalForestVerdict envDiscourse [synthBadAnchorG16Tree] expectedCanonG09 ++ " & " ++
  evalForestVerdict envAtomic [synthInvalidAlt3Tree] expectedCanonG11 ++ " & " ++
  evalReplayVerdict ctxG13 { claimedCtx := ctxG13, claimedOutcome := evalForestPure envDiscourse [synthBadAnchorG16Tree] }

-- PAIR-R1-10 (`A5d`): Authentic `G-05` vs `UpstreamRejected (.outOfDomain)` (`ctxNonAscii`) Disguised as Consensus
def act_pc10 : String := evalAuthenticRoundtripVerdict ctxG05
def act_ce10 : String :=
  evalForgedConsensusVerdict ctxNonAscii ctxNonAscii [synthTreeG15a_AB] expectedCanonG01

-- PAIR-R1-11 (`A5e`): Authentic `G-07` vs `ResourceOverflow` (`ctxT2Overflow`) & `EmptyParseSet` (`ctxEmptyParse`) Disguise
def act_pc11 : String := evalAuthenticRoundtripVerdict ctxG07
def act_ce11 : String :=
  evalForgedConsensusVerdict ctxT2Overflow ctxT2Overflow [synthTruncatedT2Alt1] expectedCanonG09 ++ " & " ++
  evalForgedConsensusVerdict ctxEmptyParse ctxEmptyParse [synthTreeG15a_AB] expectedCanonG01

-- PAIR-R1-12 (`A6`): Authentic `certG01` Holds in `W_true` vs Fails in `W_false` (No `P4`/`P5` Truth Escalation)
def wClinicalTrue : SemanticWorld :=
  { patientDomain := fun _ _ => [], patientEventHolds := fun _ _ _ => false,
    genericLawHolds := fun _ _ _ => false, eventTimestamp := fun _ _ => 0,
    factTableHolds := fun _ _ => true, presupHolds := fun _ _ => true,
    contrastiveCoheres := fun _ _ _ _ => true }

def wClinicalFalse : SemanticWorld :=
  { patientDomain := fun _ _ => [], patientEventHolds := fun _ _ _ => false,
    genericLawHolds := fun _ _ _ => false, eventTimestamp := fun _ _ => 0,
    factTableHolds := fun _ _ => false, presupHolds := fun _ _ => true,
    contrastiveCoheres := fun _ _ _ _ => true }

def act_pc12 : String :=
  if evalDenotation wClinicalTrue (embedCanonical expectedCanonG01) then
    "DENOTES_W_TRUE:true(LinguisticConsensusScope)"
  else "UNEXPECTED_FALSE"

def act_ce12 : String :=
  if !evalDenotation wClinicalFalse (embedCanonical expectedCanonG01) then
    "DENOTES_W_FALSE:false(P4_P5_EscalationBlocked)"
  else "UNEXPECTED_TRUE"

/-! ### 6. Expected Verdicts & Pure Kernel `decide` Proofs for All 24 Vectors (`0` `native_decide`) -/

def exp_pc01 : String := "ADMIT:consensus(trees=1)"
def exp_ce01 : String := "REJECT:substitutedParseForest"

def exp_pc02 : String := "ADMIT:consensus(trees=1)"
def exp_ce02 : String := "REJECT:substitutedCanonicalMeaning & REJECT:substitutedParseForest"

def exp_pc03 : String := "ADMIT:consensus(trees=1)"
def exp_ce03 : String := "REJECT:rawBytesMismatch & REJECT:substitutedCanonicalMeaning"

def exp_pc04 : String := "ADMIT:consensus(trees=1)"
def exp_ce04 : String := "REJECT:scopeEnvMismatch & REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)"

def exp_pc05 : String := "ADMIT:consensus(trees=1)"
def exp_ce05 : String := "REJECT:budgetMismatch & REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow)"

def exp_pc06 : String := "ADMIT:consensus(trees=1)"
def exp_ce06 : String := "REJECT:catalogMismatch & REJECT:numCfgMismatch"

def exp_pc07 : String := "ADMIT:consensus(trees=1)"
def exp_ce07 : String := "REJECT:forgedConsensusOnAmbiguousInput & REJECT:forgedConsensusOnAmbiguousInput & REJECT:forgedConsensusOnAmbiguousInput"

def exp_pc08 : String := "ADMIT:consensus(trees=1) & ADMIT:consensus(trees=1)"
def exp_ce08 : String := "REJECT:forgedConsensusOnTrapRejected(whFactivePresuppositionForbidden) & REJECT:forgedConsensusOnTrapRejected(unscopedClauseForbidden)"

def exp_pc09 : String := "ADMIT:consensus(trees=1)"
def exp_ce09 : String := "REJECT:forgedConsensusOnExtractionFailure(invalidContrastiveAnchor) & REJECT:forgedConsensusOnExtractionFailure(unsupportedReadingAlt) & REJECT:nonConsensusOutcomeSubmitted"

def exp_pc10 : String := "ADMIT:consensus(trees=1)"
def exp_ce10 : String := "REJECT:forgedConsensusOnUpstreamRejected(outOfDomain)"

def exp_pc11 : String := "ADMIT:consensus(trees=1)"
def exp_ce11 : String := "REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow) & REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)"

def exp_pc12 : String := "DENOTES_W_TRUE:true(LinguisticConsensusScope)"
def exp_ce12 : String := "DENOTES_W_FALSE:false(P4_P5_EscalationBlocked)"

set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc01_ok : eqStrBool act_pc01 exp_pc01 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce01_ok : eqStrBool act_ce01 exp_ce01 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_pc02_ok : eqStrBool act_pc02 exp_pc02 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_ce02_ok : eqStrBool act_ce02 exp_ce02 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc03_ok : eqStrBool act_pc03 exp_pc03 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce03_ok : eqStrBool act_ce03 exp_ce03 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_pc04_ok : eqStrBool act_pc04 exp_pc04 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_ce04_ok : eqStrBool act_ce04 exp_ce04 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc05_ok : eqStrBool act_pc05 exp_pc05 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce05_ok : eqStrBool act_ce05 exp_ce05 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc06_ok : eqStrBool act_pc06 exp_pc06 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce06_ok : eqStrBool act_ce06 exp_ce06 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc07_ok : eqStrBool act_pc07 exp_pc07 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_ce07_ok : eqStrBool act_ce07 exp_ce07 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc08_ok : eqStrBool act_pc08 exp_pc08 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce08_ok : eqStrBool act_ce08 exp_ce08 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_pc09_ok : eqStrBool act_pc09 exp_pc09 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_ce09_ok : eqStrBool act_ce09 exp_ce09 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc10_ok : eqStrBool act_pc10 exp_pc10 = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem r1_ce10_ok : eqStrBool act_ce10 exp_ce10 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc11_ok : eqStrBool act_pc11 exp_pc11 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce11_ok : eqStrBool act_ce11 exp_ce11 = true := by decide
set_option maxRecDepth 16384 in theorem r1_pc12_ok : eqStrBool act_pc12 exp_pc12 = true := by decide
set_option maxRecDepth 16384 in theorem r1_ce12_ok : eqStrBool act_ce12 exp_ce12 = true := by decide

/-! ### 7. Structured 24-Row `Gate D` Audit Table & Master Theorem (`allR1SuiteCases_pass`) -/

structure R1AttackCase where
  caseId          : String
  polarity        : String
  threatId        : ProvenanceThreatId
  targetTheorem   : String
  description     : String
  expectedVerdict : String
  actualVerdict   : String
  deriving Repr

def R1AttackCase.passed (c : R1AttackCase) : Bool :=
  eqStrBool c.actualVerdict c.expectedVerdict

def mkR1Case (cid pol : String) (tid : ProvenanceThreatId) (thm desc exp act : String) : R1AttackCase :=
  { caseId          := cid
    polarity        := pol
    threatId        := tid
    targetTheorem   := thm
    description     := desc
    expectedVerdict := exp
    actualVerdict   := act }

def allR1AttackCases : List R1AttackCase :=
  [ mkR1Case "PC-R1-01" "PC" .A1_PublicConstructorForgery     "PO-R1-01 / PO-R1-06 / PO-R1-07" "Authentic G-01 mintCertifiedConsensus + replay roundtrip" exp_pc01 act_pc01,
    mkR1Case "CE-R1-01" "CE" .A1_PublicConstructorForgery     "PO-R1-01 / PO-R1-06"            "Public SemanticNormOutcome.consensus [] c forgery without P3-C execution" exp_ce01 act_ce01,
    mkR1Case "PC-R1-02" "PC" .A2_ResultSubstitution           "PO-R1-03 / PO-R1-06 / PO-R1-07" "Authentic G-15b discourse mint + paraphrase convergence with G-15a" exp_pc02 act_pc02,
    mkR1Case "CE-R1-02" "CE" .A2_ResultSubstitution           "PO-R1-01 / PO-R1-06"            "Substituted canonical meaning (c_G01) & substituted parse forest ([tau_15a]) on G-15b" exp_ce02 act_ce02,
    mkR1Case "PC-R1-03" "PC" .A3_InputOrEnvSubstitution       "PO-R1-02 / PO-R1-06"            "Authentic G-11 universal-negative mint + replay roundtrip" exp_pc03 act_pc03,
    mkR1Case "CE-R1-03" "CE" .A3_InputOrEnvSubstitution       "PO-R1-02 / PO-R1-06"            "Cross-input G-01 consensus reused on G-11 (rawBytesMismatch & header spoof)" exp_ce03 act_ce03,
    mkR1Case "PC-R1-04" "PC" .A3_InputOrEnvSubstitution       "PO-R1-02 / PO-R1-03"            "Authentic G-16 contrastive discourse mint under envDiscourse" exp_pc04 act_pc04,
    mkR1Case "CE-R1-04" "CE" .A3_InputOrEnvSubstitution       "PO-R1-02 / PO-R1-04"            "G-16 consensus reused under envAtomic & spoofed under envMismatchedDesign" exp_ce04 act_ce04,
    mkR1Case "PC-R1-05" "PC" .A4_BudgetOrCatalogSubstitution  "PO-R1-02 / PO-R1-06"            "Authentic G-14 covariate-adjusted mint under defaultParseBudget" exp_pc05 act_pc05,
    mkR1Case "CE-R1-05" "CE" .A4_BudgetOrCatalogSubstitution  "PO-R1-02 / PO-R1-04"            "G-14 consensus reused under reduced maxBytes=16 budget & spoofed overflow" exp_ce05 act_ce05,
    mkR1Case "PC-R1-06" "PC" .A4_BudgetOrCatalogSubstitution  "PO-R1-02 / PO-R1-06"            "Authentic G-03 unadjusted association mint under p3cTestCatalog" exp_pc06 act_pc06,
    mkR1Case "CE-R1-06" "CE" .A4_BudgetOrCatalogSubstitution  "PO-R1-02 / PO-R1-06"            "G-03 consensus reused under empty catalog & tightened NumericGateConfig" exp_ce06 act_ce06,
    mkR1Case "PC-R1-07" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-09 non-established meta-claim mint + replay" exp_pc07 act_pc07,
    mkR1Case "CE-R1-07" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "Forged consensus on dual-reading traps T1, T2, and T4 (AmbiguousReadings)" exp_ce07 act_ce07,
    mkR1Case "PC-R1-08" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-10 polar-whether & G-12 proper-part mint + replay" exp_pc08 act_pc08,
    mkR1Case "CE-R1-08" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "Forged consensus on single-reading traps T3 (why) & T5 (unscoped)" exp_ce08 act_ce08,
    mkR1Case "PC-R1-09" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-13 existential-positive mint + replay" exp_pc09 act_pc09,
    mkR1Case "CE-R1-09" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "SemanticExtractionFailure (bad anchor & alt=3) disguised as consensus & raw failure submit" exp_ce09 act_ce09,
    mkR1Case "PC-R1-10" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-05 ASCII risk-difference mint + replay" exp_pc10 act_pc10,
    mkR1Case "CE-R1-10" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "Non-ASCII OutOfDomain (0xC3) disguised as consensus" exp_ce10 act_ce10,
    mkR1Case "PC-R1-11" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-07 not-stat-sig mint + replay" exp_pc11 act_pc11,
    mkR1Case "CE-R1-11" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "ResourceOverflow (maxReadings=1 on T2) & Enumerated [] (1..25%) disguised as consensus" exp_ce11 act_ce11,
    mkR1Case "PC-R1-12" "PC" .A6_P4P5AuthorityEscalation      "PO-R1-03 / PO-R1-05"            "Certified G-01 consensus denotes true in extensional clinical world W_true" exp_pc12 act_pc12,
    mkR1Case "CE-R1-12" "CE" .A6_P4P5AuthorityEscalation      "PO-R1-05"                       "Same certified G-01 consensus denotes false in W_false (blocks P4/P5 escalation)" exp_ce12 act_ce12 ]

private theorem r1_list_all_eq_true {α : Type} (p : α → Bool) (xs : List α) :
    xs.all p = true ↔ ∀ x ∈ xs, p x = true := by
  induction xs with
  | nil => simp [List.all]
  | cons a rest ih =>
    simp only [List.all, Bool.and_eq_true, ih]
    constructor
    · rintro ⟨ha, hrest⟩ x hx
      rcases List.mem_cons.mp hx with rfl | hm
      · exact ha
      · exact hrest x hm
    · intro hall
      exact ⟨hall a (List.Mem.head rest), fun x hx => hall x (List.Mem.tail a hx)⟩

theorem allR1AttackCases_pass :
    allR1AttackCases.length = 24 ∧
    ∀ c ∈ allR1AttackCases, c.passed = true ∧ c.actualVerdict = c.expectedVerdict := by
  have hall : ∀ c ∈ allR1AttackCases, c.passed = true := by
    apply (r1_list_all_eq_true R1AttackCase.passed allR1AttackCases).mp
    dsimp only [allR1AttackCases, mkR1Case, R1AttackCase.passed, List.all]
    rw [r1_pc01_ok, r1_ce01_ok, r1_pc02_ok, r1_ce02_ok, r1_pc03_ok, r1_ce03_ok,
        r1_pc04_ok, r1_ce04_ok, r1_pc05_ok, r1_ce05_ok, r1_pc06_ok, r1_ce06_ok,
        r1_pc07_ok, r1_ce07_ok, r1_pc08_ok, r1_ce08_ok, r1_pc09_ok, r1_ce09_ok,
        r1_pc10_ok, r1_ce10_ok, r1_pc11_ok, r1_ce11_ok, r1_pc12_ok, r1_ce12_ok]
    rfl
  refine ⟨rfl, ?_⟩
  intro c hc
  have hp := hall c hc
  exact ⟨hp, (eqStrBool_iff c.actualVerdict c.expectedVerdict).mp hp⟩

end PneumaOmega.P3C.ProvenanceR1.Attacks
````

### File 10: `04_proof_obligations/P3CProvenanceObligations.lean` (SHA-256: `B34E9DD691B31E393C6F64487A5B69481CD6D0B9CA3936F36207FAAE96371F70`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1
  Root export for `P3CProvenanceObligations`
-/
import P3CProvenanceObligations.PO_R1_01_To_07
````

### File 11: `04_proof_obligations/P3CProvenanceObligations/PO_R1_01_To_07.lean` (SHA-256: `00965D8B81509864ED621E676399DE7917568B22D2B5736E9D468BD02D1A3707`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`Gate C`: Canonical Proof Obligations `PO-R1-01` ~ `PO-R1-07`)
  04_proof_obligations/P3CProvenanceObligations/PO_R1_01_To_07.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`, zero `native_decide`)

  Exports the seven standalone machine-checked theorems mandated by `Gate C`:
    - `PO_R1_01_ConstructionSoundness`
    - `PO_R1_02_InputBinding`
    - `PO_R1_03_ConsensusPreservation`
    - `PO_R1_04_FailClosed`
    - `PO_R1_05_NoAuthorityEscalation`
    - `PO_R1_06_ReplayFaithfulness`
    - `PO_R1_07_ProvenanceNonVacuity`
  Plus `PO_R1_All24AttackVectorsVerified` and explicit governance/scope boundary lock `R1GovernanceStatus`.
-/
import P3CProvenanceAttacks

namespace PneumaOmega.P3C.ProvenanceR1.Obligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

/-! ### `PO-R1-01` — Construction Soundness -/

/--
  **`PO-R1-01` (`Construction Soundness`)**:
  Every inhabitant `cert : CertifiedSemanticConsensus ctx` guarantees that executing actual frozen
  `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` produces `.consensus cert.trees cert.canonical`,
  that `mintCertifiedConsensus ctx = .admitted cert`, and that `cert` is the unique witness for `ctx`.
-/
theorem PO_R1_01_ConstructionSoundness (ctx : ProvenanceContext)
    (cert : CertifiedSemanticConsensus ctx) :
    certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes =
      .consensus cert.trees cert.canonical ∧
    mintCertifiedConsensus ctx = .admitted cert ∧
    (∀ cert' : CertifiedSemanticConsensus ctx, cert' = cert) := by
  have ⟨hexec, hmint⟩ := construction_soundness ctx cert
  exact ⟨hexec, hmint, fun cert' => certifiedSemanticConsensus_unique cert' cert⟩

/-! ### `PO-R1-02` — Input Binding (All 5 Context Components + Header-Spoof Protection) -/

/--
  **`PO-R1-02` (`Input Binding`)**:
  1. Any mismatch between `claim.claimedCtx` and `targetCtx` (across `rawBytes`, `scopeEnv`, `budget`,
     `catalog`, or `numCfg`) causes `verifyUntrustedConsensusClaim targetCtx claim` to reject.
  2. In particular, exporting an authentic `cert : CertifiedSemanticConsensus ctx₁` and replaying it
     against ANY distinct `ctx₂ ≠ ctx₁` is deterministically rejected.
  3. Even if an attacker overwrites `claimedCtx := ctx₂` while transplanting `(cert.trees, cert.canonical)`
     from `ctx₁`, `verifyUntrustedConsensusClaim ctx₂` admits ONLY if `certifySemanticConsensus` on `ctx₂`
     itself genuinely produces the exact same `.consensus cert.trees cert.canonical`!
-/
theorem PO_R1_02_InputBinding :
    (∀ (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim),
       claim.claimedCtx ≠ targetCtx →
       ∃ r : ProvenanceRejectReason, verifyUntrustedConsensusClaim targetCtx claim = .error r) ∧
    (∀ {ctx₁ ctx₂ : ProvenanceContext} (cert₁ : CertifiedSemanticConsensus ctx₁),
       ctx₁ ≠ ctx₂ →
       ∃ r : ProvenanceRejectReason,
         verifyUntrustedConsensusClaim ctx₂ (exportUntrustedClaim cert₁) = .error r) ∧
    (∀ {ctx₁ ctx₂ : ProvenanceContext} (cert₁ : CertifiedSemanticConsensus ctx₁)
       (cert₂ : CertifiedSemanticConsensus ctx₂),
       verifyUntrustedConsensusClaim ctx₂
         { claimedCtx := ctx₂, claimedOutcome := .consensus cert₁.trees cert₁.canonical } = .ok cert₂ →
       ExecProvenanceSpec ctx₂ cert₁.trees cert₁.canonical ∧
       cert₂.trees = cert₁.trees ∧
       cert₂.canonical = cert₁.canonical) := by
  refine ⟨input_binding_replay_rejects_context_mismatch, ?_, ?_⟩
  · intro ctx₁ ctx₂ cert₁ hne
    exact input_binding_replay_rejects_context_mismatch ctx₂ (exportUntrustedClaim cert₁) hne
  · intro ctx₁ ctx₂ cert₁ cert₂ hok
    have ⟨hcl, hexec₂, _⟩ := (replay_faithfulness_iff ctx₂).1
      { claimedCtx := ctx₂, claimedOutcome := .consensus cert₁.trees cert₁.canonical } cert₂ hok
    unfold exportUntrustedClaim at hcl
    injection hcl with _ hout
    injection hout with ht hc
    rw [← ht, ← hc] at hexec₂
    exact ⟨hexec₂, ht.symm, hc.symm⟩

/-! ### `PO-R1-03` — Consensus Preservation (Explicitly Retaining `ExtensionalContrastiveWorld`) -/

/--
  **`PO-R1-03` (`Consensus Preservation`)**:
  Every `cert : CertifiedSemanticConsensus ctx` entails the full declarative consensus contract,
  including bounded exhaustive `P3-B` parsing, `TrapPolicyPermitsForest`, `IsCanonicalNorm`,
  universal reading `SemEq`, AND relative `Denotes` preservation across all `W` satisfying
  `ExtensionalContrastiveWorld W` (`Mandate §PO-R1-03`: never dropping `ExtensionalContrastiveWorld`).
-/
theorem PO_R1_03_ConsensusPreservation (ctx : ProvenanceContext)
    (cert : CertifiedSemanticConsensus ctx) :
    DeclarativeConsensusContract ctx cert.trees cert.canonical :=
  consensus_preservation_sound ctx cert

/-! ### `PO-R1-04` — Fail-Closed Across All 4 Non-Consensus Outcomes -/

/--
  **`PO-R1-04` (`Fail-Closed`)**:
  Whenever `certifySemanticConsensus` on `ctx` returns `.ambiguousReadings`,
  `.semanticExtractionFailure`, `.trapPolicyRejected`, or `.upstreamRejected`,
  `CertifiedSemanticConsensus ctx` is uninhabited (`→ False`) AND `verifyUntrustedConsensusClaim ctx`
  rejects EVERY untrusted claim `cl`!
-/
theorem PO_R1_04_FailClosed (ctx : ProvenanceContext) :
    ((∀ T w, runP3COnContext ctx = .ambiguousReadings T w →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ T e, runP3COnContext ctx = .semanticExtractionFailure T e →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ T c d, runP3COnContext ctx = .trapPolicyRejected T c d →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ d, runP3COnContext ctx = .upstreamRejected d →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r))) :=
  fail_closed_all_non_consensus_outcomes ctx

/-! ### `PO-R1-05` — No Authority Escalation to `P4` Clinical Truth or `P5` Final Admission -/

/--
  **`PO-R1-05` (`No Authority Escalation`)**:
  1. `P5FinalCertifiedOutput` and `P4ClinicalTruthCert c` are uninhabited (`NOT_AUTHORIZED`).
  2. Even for our concrete inhabited `certG01 : CertifiedSemanticConsensus ctxG01`, there exist
     two admissible extensional clinical worlds `(W_true, W_false)` such that `certG01.canonical`
     denotes `True` in `W_true` and `False` in `W_false` — proving `CertifiedSemanticConsensus`
     certifies linguistic consensus provenance ONLY, never empirical truth!
-/
theorem PO_R1_05_NoAuthorityEscalation :
    (P5FinalCertifiedOutput → False) ∧
    (∀ c : CanonicalMeaning, P4ClinicalTruthCert c → False) ∧
    (∃ (W_true W_false : SemanticWorld),
       ExtensionalContrastiveWorld W_true ∧
       ExtensionalContrastiveWorld W_false ∧
       Denotes W_true (embedCanonical certG01.canonical) ∧
       ¬ Denotes W_false (embedCanonical certG01.canonical)) := by
  have ⟨hp5, _, hworlds⟩ := no_authority_escalation_to_P4_or_P5 ctxG01 certG01
    "coh_primary" "win_12m" "ev_stroke" "42" "500" "8.4" certG01_canonical_eq
  exact ⟨hp5, p4ClinicalTruthCert_uninhabited, hworlds⟩

/-! ### `PO-R1-06` — Replay Faithfulness (Exact Two-Way Correspondence) -/

/--
  **`PO-R1-06` (`Replay Faithfulness`)**:
  1. For any `cert : CertifiedSemanticConsensus targetCtx`,
     `verifyUntrustedConsensusClaim targetCtx claim = .ok cert ↔ claim = exportUntrustedClaim cert`.
  2. Existential replay characterization: `(∃ cert, verifyUntrustedConsensusClaim targetCtx claim = .ok cert)`
     holds iff `claim = { claimedCtx := targetCtx, claimedOutcome := .consensus T c }` where
     `ExecProvenanceSpec targetCtx T c` holds!
-/
theorem PO_R1_06_ReplayFaithfulness (targetCtx : ProvenanceContext) :
    (∀ (claim : UntrustedConsensusClaim) (cert : CertifiedSemanticConsensus targetCtx),
       verifyUntrustedConsensusClaim targetCtx claim = .ok cert ↔
         claim = exportUntrustedClaim cert) ∧
    (∀ (claim : UntrustedConsensusClaim),
       (∃ cert : CertifiedSemanticConsensus targetCtx,
          verifyUntrustedConsensusClaim targetCtx claim = .ok cert) ↔
       (∃ (T : List ConcreteParseTree) (c : CanonicalMeaning),
          claim = { claimedCtx := targetCtx, claimedOutcome := .consensus T c } ∧
          ExecProvenanceSpec targetCtx T c)) := by
  have ⟨hsound, hcomp⟩ := replay_faithfulness_iff targetCtx
  refine ⟨?_, ?_⟩
  · intro claim cert
    constructor
    · intro hok
      exact (hsound claim cert hok).1
    · intro hcl
      rw [hcl]
      exact hcomp cert
  · intro claim
    constructor
    · rintro ⟨cert, hok⟩
      have ⟨hcl, hexec, _⟩ := hsound claim cert hok
      exact ⟨cert.trees, cert.canonical, hcl, hexec⟩
    · rintro ⟨T, c, hcl, hexec⟩
      cases hm : mintCertifiedConsensus targetCtx with
      | admitted cert =>
        have hcon : SemanticNormOutcome.consensus cert.trees cert.canonical =
                    SemanticNormOutcome.consensus T c :=
          cert.hExecProvenance.symm.trans hexec
        injection hcon with ht hc
        have hexp : claim = exportUntrustedClaim cert := by
          rw [hcl]
          unfold exportUntrustedClaim
          rw [ht, hc]
        refine ⟨cert, ?_⟩
        rw [hexp]
        exact hcomp cert
      | rejectedAmbiguous _ _ h0 =>
        unfold ExecProvenanceSpec at hexec; unfold runP3COnContext at h0
        rw [hexec] at h0; contradiction
      | rejectedExtractionFailure _ _ h0 =>
        unfold ExecProvenanceSpec at hexec; unfold runP3COnContext at h0
        rw [hexec] at h0; contradiction
      | rejectedTrapPolicy _ _ _ h0 =>
        unfold ExecProvenanceSpec at hexec; unfold runP3COnContext at h0
        rw [hexec] at h0; contradiction
      | rejectedUpstream _ h0 =>
        unfold ExecProvenanceSpec at hexec; unfold runP3COnContext at h0
        rw [hexec] at h0; contradiction

/-! ### `PO-R1-07` — Provenance Non-Vacuity on Concrete `G`-Series Witnesses -/

/--
  **`PO-R1-07` (`Provenance Non-Vacuity`)**:
  Concrete `G`-series witnesses (`ctxG01`, `ctxG11`, `ctxG15a`, `ctxG15b`) constructively inhabit
  `CertifiedSemanticConsensus` via the public `mintCertifiedConsensus` gate, round-trip `.ok`
  through `verifyUntrustedConsensusClaim`, exhibit `G-15a`/`G-15b` paraphrase convergence, and
  enforce strict cross-input rejection (`ctxG01 → ctxG11`)!
-/
theorem PO_R1_07_ProvenanceNonVacuity :
    ∃ (c01 : CertifiedSemanticConsensus ctxG01)
      (c11 : CertifiedSemanticConsensus ctxG11)
      (c15a : CertifiedSemanticConsensus ctxG15a)
      (c15b : CertifiedSemanticConsensus ctxG15b),
      mintCertifiedConsensus ctxG01 = .admitted c01 ∧
      mintCertifiedConsensus ctxG11 = .admitted c11 ∧
      mintCertifiedConsensus ctxG15a = .admitted c15a ∧
      mintCertifiedConsensus ctxG15b = .admitted c15b ∧
      verifyUntrustedConsensusClaim ctxG01 (exportUntrustedClaim c01) = .ok c01 ∧
      verifyUntrustedConsensusClaim ctxG15b (exportUntrustedClaim c15b) = .ok c15b ∧
      c01.canonical = expectedCanonG01 ∧
      c15a.canonical = c15b.canonical ∧
      (∃ r : ProvenanceRejectReason,
         verifyUntrustedConsensusClaim ctxG11 (exportUntrustedClaim c01) = .error r) := by
  refine ⟨certG01, certG11, certG15a, certG15b,
          (construction_soundness ctxG01 certG01).2,
          (construction_soundness ctxG11 certG11).2,
          (construction_soundness ctxG15a certG15a).2,
          (construction_soundness ctxG15b certG15b).2,
          (replay_faithfulness_iff ctxG01).2 certG01,
          (replay_faithfulness_iff ctxG15b).2 certG15b,
          certG01_canonical_eq,
          certG15_paraphrase_convergence,
          ?_⟩
  have hne : ctxG01 ≠ ctxG11 := by decide
  exact input_binding_replay_rejects_context_mismatch ctxG11 (exportUntrustedClaim certG01) hne

/-! ### `Gate D` Master Suite Theorem & Explicit Scope/Authority Status Lock -/

theorem PO_R1_All24AttackVectorsVerified :
    allR1AttackCases.length = 24 ∧
    ∀ c ∈ allR1AttackCases, c.passed = true ∧ c.actualVerdict = c.expectedVerdict :=
  allR1AttackCases_pass

/--
  Explicit Governance & Scope Boundary Record (`Mandate §2, §4, & §Gate F`):
  Preserves `P3-C`'s `AUTHORIZATION_QUALIFIED` classification unchanged, keeps `F-P3C-02`
  held for a separate future act, keeps out-of-kernel binary/memory tamper `HELD`, keeps external
  independent host replay `HELD`, and keeps `P4`/`P5` `NOT_AUTHORIZED`.
-/
inductive R1GovernanceStatus where
  | f_p3c_01_scoped_provenance_bound_in_r1
  | legacy_p3c_authorization_qualified_unchanged
  | f_p3c_02_semantic_scope_held
  | out_of_kernel_binary_memory_tamper_held
  | external_independent_host_replay_held
  | p4_p5_authority_not_authorized
  deriving DecidableEq, Repr

end PneumaOmega.P3C.ProvenanceR1.Obligations
````

### File 12: `05_independent_tribunal/P3CProvenanceTribunalAudit.lean` (SHA-256: `A0BE882DF80A73EE20D45AB7895FF5FE70D4D7B8FEF281C7E9F659A4AC47705C`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`Gate E` Tribunal Audit & Serialized Claim Replay CLI)
  05_independent_tribunal/P3CProvenanceTribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`, zero `native_decide`)

  1. Emits `#print axioms` on all exported `PO-R1-01` ~ `PO-R1-07` theorems and bridge lemmas
     (`0` `sorryAx`, `0` `Lean.ofReduceBool`, `0` custom axioms).
  2. Provides CLI executable `p3c_provenance_r1_runner`:
     - Default mode               : executes and displays all 24 symmetric `(PC, CE)` `Gate D`
                                    vectors with `(caseId, threatId, targetTheorem, expected, actual)`.
     - `--export-fixed-json`      : exports JSON array of all 24 `Gate D` vectors.
     - `--eval-claims-batch <tsv>`: evaluates serialized untrusted claim bundles through the actual
                                    proof-carrying `verifyUntrustedConsensusClaim` gate for 1:1
                                    cross-language reference harness verification (`Gate E`).
-/
import P3CProvenanceObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks
open PneumaOmega.P3C.ProvenanceR1.Obligations

/-! ### 1. Kernel Axiom Fingerprint Audit (`#print axioms`) -/

#print axioms PO_R1_01_ConstructionSoundness
#print axioms PO_R1_02_InputBinding
#print axioms PO_R1_03_ConsensusPreservation
#print axioms PO_R1_04_FailClosed
#print axioms PO_R1_05_NoAuthorityEscalation
#print axioms PO_R1_06_ReplayFaithfulness
#print axioms PO_R1_07_ProvenanceNonVacuity
#print axioms PO_R1_All24AttackVectorsVerified
#print axioms certifiedSemanticConsensus_unique
#print axioms verifyClaimPure_error_iff
#print axioms verifyClaimPure_ok_iff

/-! ### 2. Deterministic Serialization for Cross-Language Reference Harness (`Gate E`) -/

private def renderThreatId : ProvenanceThreatId → String
  | .A1_PublicConstructorForgery    => "A1_PublicConstructorForgery"
  | .A2_ResultSubstitution          => "A2_ResultSubstitution"
  | .A3_InputOrEnvSubstitution      => "A3_InputOrEnvSubstitution"
  | .A4_BudgetOrCatalogSubstitution => "A4_BudgetOrCatalogSubstitution"
  | .A5_FailureOutcomeLaundering    => "A5_FailureOutcomeLaundering"
  | .A6_P4P5AuthorityEscalation     => "A6_P4P5AuthorityEscalation"

private def renderBatchReject : ProvenanceRejectReason → String
  | .rawBytesMismatch                                 => "RAW_BYTES_MISMATCH"
  | .scopeEnvMismatch                                 => "SCOPE_ENV_MISMATCH"
  | .budgetMismatch                                   => "BUDGET_MISMATCH"
  | .catalogMismatch                                  => "CATALOG_MISMATCH"
  | .numCfgMismatch                                   => "NUM_CFG_MISMATCH"
  | .nonConsensusOutcomeSubmitted                     => "NON_CONSENSUS_OUTCOME"
  | .forgedConsensusOnAmbiguousInput                  => "FORGED_ON_AMBIGUOUS"
  | .forgedConsensusOnExtractionFailure (.invalidContrastiveAnchor _) =>
      "FORGED_ON_EXTRACTION:BAD_ANCHOR"
  | .forgedConsensusOnExtractionFailure (.unresolvedAnaphoricScope f e) =>
      s!"FORGED_ON_EXTRACTION:ANAPHORA({f}!={e})"
  | .forgedConsensusOnExtractionFailure (.mismatchedScopeCohort f e) =>
      s!"FORGED_ON_EXTRACTION:COHORT({f}!={e})"
  | .forgedConsensusOnExtractionFailure (.unsupportedReadingAlt _ a) =>
      s!"FORGED_ON_EXTRACTION:BAD_ALT({a})"
  | .forgedConsensusOnExtractionFailure (.malformedParseNode _ d) =>
      s!"FORGED_ON_EXTRACTION:MALFORMED({d})"
  | .forgedConsensusOnTrapRejected .whFactivePresuppositionForbidden =>
      "FORGED_ON_TRAP:WH_FACTIVE"
  | .forgedConsensusOnTrapRejected .unscopedClauseForbidden =>
      "FORGED_ON_TRAP:UNSCOPED"
  | .forgedConsensusOnTrapRejected (.parserOnlyTrapProduction _) =>
      "FORGED_ON_TRAP:PARSER_ONLY"
  | .forgedConsensusOnTrapRejected .wrapperTrapEnvelope =>
      "FORGED_ON_TRAP:WRAPPER"
  | .forgedConsensusOnUpstreamRejected .emptyParseSet =>
      "FORGED_ON_UPSTREAM:EMPTY_PARSE_SET"
  | .forgedConsensusOnUpstreamRejected (.outOfDomain .emptyInput) =>
      "FORGED_ON_UPSTREAM:OOD_EMPTY"
  | .forgedConsensusOnUpstreamRejected (.outOfDomain (.nonPrintableAsciiByte b)) =>
      s!"FORGED_ON_UPSTREAM:OOD_BYTE({b.toNat})"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow (.maxBytesExceeded act lim)) =>
      s!"FORGED_ON_UPSTREAM:OVF_BYTES({act}>{lim})"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow (.maxStepsExceeded lim)) =>
      s!"FORGED_ON_UPSTREAM:OVF_STEPS({lim})"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow (.maxForestNodesExceeded lim)) =>
      s!"FORGED_ON_UPSTREAM:OVF_NODES({lim})"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow (.maxReadingsExceeded act lim)) =>
      s!"FORGED_ON_UPSTREAM:OVF_READINGS({act}>{lim})"
  | .substitutedCanonicalMeaning                      => "SUBSTITUTED_CANONICAL_MEANING"
  | .substitutedParseForest                           => "SUBSTITUTED_PARSE_FOREST"

private def hexDigitVal (c : Char) : Option Nat :=
  if ('0' ≤ c) && (c ≤ '9') then some (c.toNat - '0'.toNat)
  else if ('a' ≤ c) && (c ≤ 'f') then some (10 + (c.toNat - 'a'.toNat))
  else if ('A' ≤ c) && (c ≤ 'F') then some (10 + (c.toNat - 'A'.toNat))
  else none

private def decodeHexChars : List Char → Option (List UInt8)
  | [] => some []
  | c1 :: c2 :: rest =>
    match hexDigitVal c1, hexDigitVal c2, decodeHexChars rest with
    | some v1, some v2, some tail => some (UInt8.ofNat (v1 * 16 + v2) :: tail)
    | _, _, _ => none
  | [_] => none

private def stripCR (s : String) : String :=
  String.ofList (s.toList.filter (fun c => c != '\r'))

private def parseNatSimple (s : String) : Nat :=
  s.toNat?.getD 0

private def resolveEnvTag : String → ScopeEnv
  | "discourse"  => envDiscourse
  | "bad_design" => envMismatchedDesign
  | "bad_cohort" => { cohortId := "coh_other", expectedDesignHead := "des_study", quoteIsolation := .sentenceAtomic }
  | _            => envAtomic

private def resolveCatalogTag : String → ClosedEntityCatalog
  | "empty" => { entries := [] }
  | "drop_stroke" =>
      { entries := p3cTestCatalog.entries.filter (fun e => !(e.entityId == "ev_stroke")) }
  | _ => p3cTestCatalog

private def resolveNumCfgTag : String → NumericGateConfig
  | "tight_1_1" => { maxIntDigits := 1, maxFracDigits := 1 }
  | _           => frozenR22NumericConfig

private def resolveRefContext : String → ProvenanceContext
  | "G01"   => ctxG01
  | "G03"   => ctxG03
  | "G05"   => ctxG05
  | "G07"   => ctxG07
  | "G09"   => ctxG09
  | "G10"   => ctxG10
  | "G11"   => ctxG11
  | "G12"   => ctxG12
  | "G14"   => ctxG14
  | "G15a"  => ctxG15a
  | "G15b"  => ctxG15b
  | "G16"   => ctxG16
  | _       => ctxG01

private def buildCtxFromCols (envTag maxBStr maxRStr catTag numTag hexPayload : String) :
    Option ProvenanceContext :=
  match decodeHexChars hexPayload.toList with
  | none => none
  | some rawBytes =>
    some { catalog  := resolveCatalogTag catTag
           numCfg   := resolveNumCfgTag numTag
           scopeEnv := resolveEnvTag envTag
           budget   := { defaultParseBudget with
                           maxBytes    := parseNatSimple maxBStr
                           maxReadings := parseNatSimple maxRStr }
           rawBytes := rawBytes }

private def buildClaimedOutcome (targetCtx : ProvenanceContext) (claimMode refTag : String) :
    SemanticNormOutcome :=
  let refOut := runP3COnContext (resolveRefContext refTag)
  let (refTrees, refCanon) :=
    match refOut with
    | .consensus T c => (T, c)
    | _              => ([], expectedCanonG01)
  match claimMode with
  | "AUTH_FROM_REF"     => .consensus refTrees refCanon
  | "FORGE_EMPTY_TREES" => fabricatePublicOutcomeWithoutExecution [] refCanon
  | "SUBST_CANON_ONLY"  =>
    match runP3COnContext targetCtx with
    | .consensus actualT _ => .consensus actualT refCanon
    | _                    => .consensus [synthTreeG15a_AB] refCanon
  | "SUBST_TREES_SYNTH15A" => .consensus [synthTreeG15a_AB] refCanon
  | "SUBMIT_RAW_TARGET" => runP3COnContext targetCtx
  | _                   => .consensus refTrees refCanon

private def evalClaimBatchLine (line : String) : Option String :=
  let clean := stripCR line
  if clean.isEmpty then none
  else
    match clean.splitOn "\t" with
    | [rowId,
       tEnv, tMaxB, tMaxR, tCat, tNum, tHex,
       cEnv, cMaxB, cMaxR, cCat, cNum, cHex,
       claimMode, refTag] =>
      match buildCtxFromCols tEnv tMaxB tMaxR tCat tNum tHex,
            buildCtxFromCols cEnv cMaxB cMaxR cCat cNum cHex with
      | some targetCtx, some claimedCtx =>
        let out := buildClaimedOutcome targetCtx claimMode refTag
        let claim : UntrustedConsensusClaim := { claimedCtx := claimedCtx, claimedOutcome := out }
        -- Invoke the ACTUAL proof-carrying `verifyUntrustedConsensusClaim` gate:
        match verifyUntrustedConsensusClaim targetCtx claim with
        | .ok cert   => some s!"{rowId}\tADMIT|trees={cert.trees.length}|items={cert.canonical.items.length}"
        | .error err => some s!"{rowId}\tREJECT|{renderBatchReject err}"
      | _, _ => some s!"{rowId}\tERR:INVALID_HEX"
    | _ => some "ERR:MALFORMED_LINE"

private def exportFixedJson : String :=
  let rows := allR1AttackCases.map fun c =>
    s!"  \{\"caseId\": \"{c.caseId}\", \"polarity\": \"{c.polarity}\", \"threatId\": \"{renderThreatId c.threatId}\", \"targetTheorem\": \"{c.targetTheorem}\", \"expectedVerdict\": \"{c.expectedVerdict}\", \"actualVerdict\": \"{c.actualVerdict}\", \"passed\": {c.passed}}"
  "[\n" ++ String.intercalate ",\n" rows ++ "\n]"

def main (args : List String) : IO UInt32 := do
  match args with
  | ["--export-fixed-json"] =>
    IO.println exportFixedJson
    return 0
  | ["--eval-claims-batch", path] =>
    let content ← IO.FS.readFile path
    for line in content.splitOn "\n" do
      match evalClaimBatchLine line with
      | some out => IO.println out
      | none     => pure ()
    return 0
  | _ =>
    IO.println "=========================================================================="
    IO.println "PNEUMA-NATIVE OMEGA — AUTH-P3C-PROVENANCE-R1 (PROOF-CARRYING CONSENSUS)"
    IO.println "Scope     : F-P3C-01 Public Result Provenance Binding (P3C_Provenance_R1)"
    IO.println "Toolchain : Lean 4.33.1 Core (Init + Frozen P2/P3-A/P3-B/P3-C, 0 sorry)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for c in allR1AttackCases do
      let status := if c.passed then "PASS" else "FAIL"
      if c.passed then passCount := passCount + 1
      IO.println s!"[{status}] {c.caseId} | {renderThreatId c.threatId} | {c.targetTheorem} | exp={c.expectedVerdict} | act={c.actualVerdict}"
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"TOTAL R1 GATE-D VECTORS : {passCount}/{allR1AttackCases.length} PASSED"
    if passCount == allR1AttackCases.length then
      return 0
    else
      return 1
````

### File 13: `05_independent_tribunal/provenance_audit_and_probes.py` (SHA-256: `07677C95A5BDF5BE38E3F711984602047EEF11ED0942DB99ABEF1409497B9494`)
````python
#!/usr/bin/env python3
"""
PNEUMA-NATIVE OMEGA — AUTH-P3C-PROVENANCE-R1 (`Gate B`, `Gate D`, `Gate E`)
05_independent_tribunal/provenance_audit_and_probes.py

Honest Engineering Classification (`Mandate §Gate E`):
  - Part 1 (`run_compiler_encapsulation_probes`):
      Executes 5 external `lake env lean` compiler probes in an OS temporary directory
      (zero files written inside any workspace/project directory), verifying:
        * `PROBE-CTRL-01` : Valid R1 consumer via public `mintCertifiedConsensus` (`exit 0`).
        * `PROBE-NEG-01a` : Direct `CertifiedSemanticConsensus.mk` invocation fails with private/unknown error.
        * `PROBE-NEG-01b` : Anonymous constructor `⟨T, c, h⟩ : CertifiedSemanticConsensus ctx` fails outside gate.
        * `PROBE-NEG-02`  : Passing `CertifiedSemanticConsensus ctxG01` where `ctxG11` is expected fails with
                            `Application type mismatch`.
        * `PROBE-NEG-03`  : Passing/constructing `P5FinalCertifiedOutput` from `certG01` fails with type/privacy error.
      Explicitly verifies zero syntax/import errors so failures stem strictly from encapsulation/typing!
  - Part 2 (`run_cross_language_claim_harness`):
      Evaluates 120 serialized untrusted claim bundles through both a clean-room Python 3.11
      reference model of `verifyUntrustedConsensusClaim` and `p3c_provenance_r1_runner.exe --eval-claims-batch`.
      Explicitly classified as a **Cross-Language Reference Harness** (NOT claimed as an independent R0 oracle).
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Tuple

R1_ROOT = Path(__file__).resolve().parent.parent
RUNNER_EXE = R1_ROOT / ".lake" / "build" / "bin" / "p3c_provenance_r1_runner.exe"


# ---------------------------------------------------------------------------
# 1. Canonical Sentence & Reference Fixture Table (Mirroring Frozen `P3-C`)
# ---------------------------------------------------------------------------

SENTENCES: Dict[str, str] = {
    "G01": "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%).",
    "G03": "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92).",
    "G05": "In the primary cohort, the absolute risk difference in myocardial infarction comparing intensive therapy versus standard care was -3.2 percentage points (95% CI -5.1 to -1.3).",
    "G07": "In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (hazard ratio = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = 0.05.",
    "G09": "In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction.",
    "G10": "In the primary cohort, the analysis of Trial-A did not determine whether intensive therapy reduces myocardial infarction.",
    "G11": "In the primary cohort, no diabetic patients developed stroke.",
    "G12": "In the primary cohort, some, but not all, diabetic patients developed stroke.",
    "G14": "In the primary cohort, after adjustment for age and baseline risk, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92).",
    "G15a": "In the primary cohort, no diabetic patients developed stroke. In the primary cohort, at least one high-risk patient developed acute kidney injury.",
    "G15b": "In the primary cohort, at least one high-risk patient developed acute kidney injury. Within this same study, no diabetic patients developed stroke.",
    "G16": "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction.",
    "T1": "In the primary cohort, all diabetic patients did not develop stroke.",
    "T2": "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction.",
    "T3": "In the primary cohort, the analysis of Trial-A did not determine why intensive therapy reduces myocardial infarction.",
    "T4": "In the primary cohort, diabetic patients developed stroke.",
    "T5": "no diabetic patients developed stroke.",
    "G16_BAD_ANCHOR": "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality.",
    "BAD_MULTIDOT": "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (1..25%).",
}

# Canonical item count & canonical group IDs for the 12 valid reference tags:
REF_CANON_GROUP: Dict[str, Tuple[str, int]] = {
    "G01": ("CANON_G01", 1),
    "G03": ("CANON_G03", 1),
    "G05": ("CANON_G05", 1),
    "G07": ("CANON_G07", 1),
    "G09": ("CANON_G09", 1),
    "G10": ("CANON_G10", 1),
    "G11": ("CANON_G11", 1),
    "G12": ("CANON_G12", 1),
    "G14": ("CANON_G14", 1),
    "G15a": ("CANON_G15_CONJ", 2),  # G-15a & G-15b converge to identical 2-item canonical conjunction!
    "G15b": ("CANON_G15_CONJ", 2),
    "G16": ("CANON_G16", 1),
}

DISCOURSE_ONLY_TAGS = {"G15b", "G16", "G16_BAD_ANCHOR"}
ATOMIC_ONLY_TAGS = {"G15a"}
USES_STROKE_TAGS = {"G01", "G11", "G12", "G15a", "G15b", "T1", "T4", "T5"}
MULTI_DIGIT_NUM_TAGS = {"G01", "G03", "G05", "G07", "G14", "G16", "G16_BAD_ANCHOR"}


def ascii_hex(s: str) -> str:
    return s.encode("ascii").hex()


# ---------------------------------------------------------------------------
# 2. Clean-Room Python Reference Model of `verifyUntrustedConsensusClaim`
# ---------------------------------------------------------------------------

def eval_p3c_reference_target(
    env_tag: str,
    max_b: int,
    max_r: int,
    cat_tag: str,
    num_tag: str,
    hex_payload: str,
    tag_hint: str,
) -> Tuple[str, str, int]:
    """
    Returns `(outcome_kind, detail_or_canon_group, item_count)` for our structured 120-vector space.
    """
    raw = bytes.fromhex(hex_payload)
    if len(raw) == 0:
        return ("UPSTREAM", "OOD_EMPTY", 0)
    for b in raw:
        if b < 0x20 or b > 0x7E:
            return ("UPSTREAM", f"OOD_BYTE({b})", 0)
    if len(raw) > max_b:
        return ("UPSTREAM", f"OVF_BYTES({len(raw)}>{max_b})", 0)

    if cat_tag == "empty":
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if cat_tag == "drop_stroke" and tag_hint in USES_STROKE_TAGS:
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if num_tag == "tight_1_1" and tag_hint in MULTI_DIGIT_NUM_TAGS:
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if tag_hint == "BAD_MULTIDOT":
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)

    # Quote-isolation & scope/anchor grammar gates enforced at parse time by P3-B (`DeclarativeParseSpec.lean`):
    if tag_hint in DISCOURSE_ONLY_TAGS and env_tag in {"atomic", "bad_cohort", "bad_design"}:
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if tag_hint in ATOMIC_ONLY_TAGS and env_tag in {"discourse", "bad_design", "bad_cohort"}:
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if tag_hint != "T5" and env_tag == "bad_cohort":
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if tag_hint == "G16_BAD_ANCHOR":
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)

    # Dual-reading traps (`T1`, `T2`, `T4`) have 2 readings in P3-B:
    if tag_hint in {"T1", "T2", "T4"}:
        if max_r < 2:
            return ("UPSTREAM", f"OVF_READINGS(2>{max_r})", 0)
        return ("AMBIGUOUS", "DUAL_READING", 0)

    if max_r < 1:
        return ("UPSTREAM", f"OVF_READINGS(1>{max_r})", 0)

    # Single-reading traps (`T3`, `T5`):
    if tag_hint == "T3":
        return ("TRAP", "WH_FACTIVE", 0)
    if tag_hint == "T5":
        return ("TRAP", "UNSCOPED", 0)

    canon_grp, n_items = REF_CANON_GROUP[tag_hint]
    return ("CONSENSUS", canon_grp, n_items)


def eval_python_reference_row(
    t_env: str, t_max_b: int, t_max_r: int, t_cat: str, t_num: str, t_hex: str, t_tag: str,
    c_env: str, c_max_b: int, c_max_r: int, c_cat: str, c_num: str, c_hex: str,
    claim_mode: str, ref_tag: str,
) -> str:
    # Step 1: 5-field ProvenanceContext match (`checkContextMatch` exact order)
    if t_hex != c_hex:
        return "REJECT|RAW_BYTES_MISMATCH"
    if t_env != c_env:
        return "REJECT|SCOPE_ENV_MISMATCH"
    if (t_max_b != c_max_b) or (t_max_r != c_max_r):
        return "REJECT|BUDGET_MISMATCH"
    if t_cat != c_cat:
        return "REJECT|CATALOG_MISMATCH"
    if t_num != c_num:
        return "REJECT|NUM_CFG_MISMATCH"

    # Step 2: Check claimedOutcome constructor
    t_kind, t_detail, t_items = eval_p3c_reference_target(
        t_env, t_max_b, t_max_r, t_cat, t_num, t_hex, t_tag
    )
    if claim_mode == "SUBMIT_RAW_TARGET":
        if t_kind != "CONSENSUS":
            return "REJECT|NON_CONSENSUS_OUTCOME"
        return f"ADMIT|trees=1|items={t_items}"

    # All other modes submit `.consensus claimedTrees claimedCanon`:
    if t_kind == "AMBIGUOUS":
        return "REJECT|FORGED_ON_AMBIGUOUS"
    if t_kind == "EXTRACTION":
        return f"REJECT|FORGED_ON_EXTRACTION:{t_detail}"
    if t_kind == "TRAP":
        return f"REJECT|FORGED_ON_TRAP:{t_detail}"
    if t_kind == "UPSTREAM":
        return f"REJECT|FORGED_ON_UPSTREAM:{t_detail}"

    # Target genuinely reached `.consensus actualTrees actualCanon`:
    ref_canon_grp, _ = REF_CANON_GROUP[ref_tag]
    if t_detail != ref_canon_grp:
        return "REJECT|SUBSTITUTED_CANONICAL_MEANING"

    if claim_mode == "FORGE_EMPTY_TREES":
        return "REJECT|SUBSTITUTED_PARSE_FOREST"
    if claim_mode == "SUBST_TREES_SYNTH15A":
        # Note: synthTreeG15a_AB has dummy spans `sp0 = (0, 1)`, never equal to real parsed spans!
        return "REJECT|SUBSTITUTED_PARSE_FOREST"
    if claim_mode == "SUBST_CANON_ONLY":
        # `claimedTrees == actualTrees` and `t_detail == ref_canon_grp`:
        return f"ADMIT|trees=1|items={t_items}"
    if claim_mode == "AUTH_FROM_REF":
        # Trees match iff target parse tree == ref parse tree (same sentence & env):
        if t_tag != ref_tag:
            return "REJECT|SUBSTITUTED_PARSE_FOREST"
        return f"ADMIT|trees=1|items={t_items}"

    raise ValueError(f"Unknown claim_mode: {claim_mode}")


# ---------------------------------------------------------------------------
# 3. Build 120 Deterministic Serialized Claim Vectors Across `A1` ~ `A5`
# ---------------------------------------------------------------------------

def generate_120_claim_rows() -> List[Tuple[List[str], str]]:
    rows: List[Tuple[List[str], str]] = []
    idx = 0

    def add_row(
        t_env: str, t_max_b: int, t_max_r: int, t_cat: str, t_num: str, t_hex: str, t_tag: str,
        c_env: str, c_max_b: int, c_max_r: int, c_cat: str, c_num: str, c_hex: str,
        claim_mode: str, ref_tag: str,
    ) -> None:
        nonlocal idx
        idx += 1
        rid = f"R1B-{idx:03d}"
        cols = [
            rid,
            t_env, str(t_max_b), str(t_max_r), t_cat, t_num, t_hex,
            c_env, str(c_max_b), str(c_max_r), c_cat, c_num, c_hex,
            claim_mode, ref_tag,
        ]
        exp = eval_python_reference_row(
            t_env, t_max_b, t_max_r, t_cat, t_num, t_hex, t_tag,
            c_env, c_max_b, c_max_r, c_cat, c_num, c_hex,
            claim_mode, ref_tag,
        )
        rows.append((cols, f"{rid}\t{exp}"))

    valid_tags = ["G01", "G03", "G05", "G07", "G09", "G10", "G11", "G12", "G14", "G15a", "G15b", "G16"]

    # Group 1 (24 rows): Authentic roundtrips across all 12 valid G-series tags x 2 valid budgets
    for tag in valid_tags:
        env = "discourse" if tag in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tag])
        add_row(env, 512, 8, "full", "r22", hx, tag, env, 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tag)
        add_row(env, 420, 4, "full", "r22", hx, tag, env, 420, 4, "full", "r22", hx, "AUTH_FROM_REF", tag)

    # Group 2 (16 rows): `A1` Direct public `.consensus [] c` empty-forest forgery
    for tag in valid_tags:
        env = "discourse" if tag in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tag])
        add_row(env, 512, 8, "full", "r22", hx, tag, env, 512, 8, "full", "r22", hx, "FORGE_EMPTY_TREES", tag)
    for trap_tag in ["T1", "T2", "T3", "T5"]:
        hx = ascii_hex(SENTENCES[trap_tag])
        add_row("atomic", 512, 8, "full", "r22", hx, trap_tag, "atomic", 512, 8, "full", "r22", hx, "FORGE_EMPTY_TREES", "G01")

    # Group 3 (20 rows): `A2` Canonical meaning & parse-forest substitutions (incl. G15a <-> G15b!)
    subst_pairs = [
        ("G01", "G11"), ("G03", "G05"), ("G07", "G09"), ("G09", "G10"), ("G11", "G12"),
        ("G14", "G03"), ("G15a", "G01"), ("G15b", "G01"), ("G16", "G09"), ("G10", "G09"),
    ]
    for tgt, wrong_ref in subst_pairs:
        env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tgt])
        add_row(env, 512, 8, "full", "r22", hx, tgt, env, 512, 8, "full", "r22", hx, "SUBST_CANON_ONLY", wrong_ref)
    # Parse-forest substitutions (including G15a tree transplanted onto G15b despite identical canonical form!):
    add_row("discourse", 512, 8, "full", "r22", ascii_hex(SENTENCES["G15b"]), "G15b",
            "discourse", 512, 8, "full", "r22", ascii_hex(SENTENCES["G15b"]), "AUTH_FROM_REF", "G15a")
    add_row("atomic", 512, 8, "full", "r22", ascii_hex(SENTENCES["G15a"]), "G15a",
            "atomic", 512, 8, "full", "r22", ascii_hex(SENTENCES["G15a"]), "AUTH_FROM_REF", "G15b")
    for tgt in ["G01", "G03", "G09", "G11", "G14", "G15a", "G15b", "G16"]:
        env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tgt])
        add_row(env, 512, 8, "full", "r22", hx, tgt, env, 512, 8, "full", "r22", hx, "SUBST_TREES_SYNTH15A", tgt)

    # Group 4 (20 rows): `A3` Raw-byte & `ScopeEnv` substitution + header-spoofed variants
    byte_swaps = [("G01", "G11"), ("G11", "G01"), ("G03", "G14"), ("G09", "G10"), ("G15b", "G16")]
    for tgt, clm in byte_swaps:
        t_env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        c_env = "discourse" if clm in DISCOURSE_ONLY_TAGS else "atomic"
        t_hx = ascii_hex(SENTENCES[tgt])
        c_hx = ascii_hex(SENTENCES[clm])
        # Direct replay with mismatched claimed bytes:
        add_row(t_env, 512, 8, "full", "r22", t_hx, tgt, c_env, 512, 8, "full", "r22", c_hx, "AUTH_FROM_REF", clm)
        # Header-spoofed replay (`claimedCtx` overwritten to `targetCtx`):
        add_row(t_env, 512, 8, "full", "r22", t_hx, tgt, t_env, 512, 8, "full", "r22", t_hx, "AUTH_FROM_REF", clm)

    # ScopeEnv mismatches & spoofed bad_design / bad_cohort:
    for tgt in ["G01", "G09", "G11", "G15b", "G16"]:
        hx = ascii_hex(SENTENCES[tgt])
        good_env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        alt_env = "atomic" if good_env == "discourse" else "discourse"
        add_row(alt_env, 512, 8, "full", "r22", hx, tgt, good_env, 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
    for tgt in ["G15b", "G16"]:
        hx = ascii_hex(SENTENCES[tgt])
        add_row("bad_design", 512, 8, "full", "r22", hx, tgt, "bad_design", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
    for tgt in ["G01", "G09", "G11"]:
        hx = ascii_hex(SENTENCES[tgt])
        add_row("bad_cohort", 512, 8, "full", "r22", hx, tgt, "bad_cohort", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)

    # Group 5 (20 rows): `A4` Budget, Catalog, and NumericGateConfig mismatches + header-spoofed variants
    for tgt in ["G01", "G03", "G09", "G14", "G16"]:
        env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tgt])
        # Mismatched budget header:
        add_row(env, 16, 8, "full", "r22", hx, tgt, env, 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
        # Spoofed tiny budget header -> OVF_BYTES:
        add_row(env, 16, 8, "full", "r22", hx, tgt, env, 16, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
    for tgt in ["G01", "G11", "G15a"]:
        hx = ascii_hex(SENTENCES[tgt])
        add_row("atomic", 512, 8, "drop_stroke", "r22", hx, tgt, "atomic", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
        add_row("atomic", 512, 8, "drop_stroke", "r22", hx, tgt, "atomic", 512, 8, "drop_stroke", "r22", hx, "AUTH_FROM_REF", tgt)
    for tgt in ["G01", "G03"]:
        hx = ascii_hex(SENTENCES[tgt])
        add_row("atomic", 512, 8, "full", "tight_1_1", hx, tgt, "atomic", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
        add_row("atomic", 512, 8, "full", "tight_1_1", hx, tgt, "atomic", 512, 8, "full", "tight_1_1", hx, "AUTH_FROM_REF", tgt)

    # Group 6 (20 rows): `A5` Failure-outcome laundering (`T1`~`T5`, extraction error, OOD, overflow, empty parse, raw submit)
    for trap_tag, ref_g in [("T1", "G11"), ("T2", "G09"), ("T4", "G11"), ("T3", "G10"), ("T5", "G11")]:
        hx = ascii_hex(SENTENCES[trap_tag])
        add_row("atomic", 512, 8, "full", "r22", hx, trap_tag, "atomic", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", ref_g)
        add_row("atomic", 512, 8, "full", "r22", hx, trap_tag, "atomic", 512, 8, "full", "r22", hx, "SUBMIT_RAW_TARGET", ref_g)

    # Extraction failure (`G16_BAD_ANCHOR`):
    hx_bad_anc = ascii_hex(SENTENCES["G16_BAD_ANCHOR"])
    add_row("discourse", 512, 8, "full", "r22", hx_bad_anc, "G16_BAD_ANCHOR",
            "discourse", 512, 8, "full", "r22", hx_bad_anc, "AUTH_FROM_REF", "G16")
    add_row("discourse", 512, 8, "full", "r22", hx_bad_anc, "G16_BAD_ANCHOR",
            "discourse", 512, 8, "full", "r22", hx_bad_anc, "SUBMIT_RAW_TARGET", "G16")

    # Upstream OutOfDomain (empty, 0xC3 UTF-8, 0x00 NUL, 0x7F DEL):
    for bad_hex in ["", "496e20c3a9", "496e0061", "496e7f61"]:
        add_row("atomic", 512, 8, "full", "r22", bad_hex, "G01",
                "atomic", 512, 8, "full", "r22", bad_hex, "AUTH_FROM_REF", "G01")

    # Upstream ResourceOverflow (`maxReadings=1` on `T1` and `T2`) & EmptyParseSet (`BAD_MULTIDOT`):
    for ovf_tag in ["T1", "T2"]:
        hx = ascii_hex(SENTENCES[ovf_tag])
        add_row("atomic", 512, 1, "full", "r22", hx, ovf_tag,
                "atomic", 512, 1, "full", "r22", hx, "AUTH_FROM_REF", "G09")
    hx_mdot = ascii_hex(SENTENCES["BAD_MULTIDOT"])
    add_row("atomic", 512, 8, "full", "r22", hx_mdot, "BAD_MULTIDOT",
            "atomic", 512, 8, "full", "r22", hx_mdot, "AUTH_FROM_REF", "G01")
    add_row("atomic", 512, 8, "full", "r22", hx_mdot, "BAD_MULTIDOT",
            "atomic", 512, 8, "full", "r22", hx_mdot, "SUBMIT_RAW_TARGET", "G01")

    assert len(rows) == 120, f"Expected 120 rows, got {len(rows)}"
    return rows


# ---------------------------------------------------------------------------
# 4. External Compiler Access-Restriction & Type-Isolation Probes (`Gate B`)
# ---------------------------------------------------------------------------

PROBES = [
    {
        "probeId": "PROBE-CTRL-01",
        "expectExitZero": True,
        "requiredSubstrings": [],
        "forbiddenSubstrings": ["error:"],
        "purpose": "Positive control: external consumer imports P3CProvenanceObligations and reads certG01.canonical",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def validConsumerCanonical : PneumaOmega.P3C.CanonicalMeaning :=
  certG01.canonical
""",
    },
    {
        "probeId": "PROBE-NEG-01a",
        "expectExitZero": False,
        "requiredSubstrings": ["CertifiedSemanticConsensus.mk"],
        "forbiddenSubstrings": ["unknown module prefix", "expected token"],
        "purpose": "Negative probe A1 (named constructor): external caller cannot invoke private CertifiedSemanticConsensus.mk",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def forgeViaNamedMk (h : PneumaOmega.P3C.certifySemanticConsensus ctxG01.catalog ctxG01.numCfg ctxG01.scopeEnv ctxG01.budget ctxG01.rawBytes = .consensus certG01.trees certG01.canonical) :
    CertifiedSemanticConsensus ctxG01 :=
  CertifiedSemanticConsensus.mk certG01.trees certG01.canonical h
""",
    },
    {
        "probeId": "PROBE-NEG-01b",
        "expectExitZero": False,
        "requiredSubstrings": ["private", "CertifiedSemanticConsensus"],
        "forbiddenSubstrings": ["unknown module prefix", "expected token"],
        "purpose": "Negative probe A1 (anonymous constructor): external caller cannot forge CertifiedSemanticConsensus via anonymous ⟨...⟩",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def forgeViaAnonCtor : CertifiedSemanticConsensus ctxG01 :=
  ⟨certG01.trees, certG01.canonical, certG01.hExecProvenance⟩
""",
    },
    {
        "probeId": "PROBE-NEG-02",
        "expectExitZero": False,
        "requiredSubstrings": ["Application type mismatch", "ctxShortA", "ctxShortB"],
        "forbiddenSubstrings": ["unknown module prefix", "expected token", "timeout"],
        "purpose": "Negative probe A3/A4 (type-indexed input binding): CertifiedSemanticConsensus ctxShortA is rejected where ctxShortB is expected",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def ctxShortA : ProvenanceContext := { ctxG03EmptyCatalog with rawBytes := [0x41] }
def ctxShortB : ProvenanceContext := { ctxG03EmptyCatalog with rawBytes := [0x42] }

def consumeBOnly (c : CertifiedSemanticConsensus ctxShortB) : PneumaOmega.P3C.CanonicalMeaning :=
  c.canonical

def illegalCrossInputTransfer (c : CertifiedSemanticConsensus ctxShortA) : PneumaOmega.P3C.CanonicalMeaning :=
  consumeBOnly c
""",
    },
    {
        "probeId": "PROBE-NEG-03",
        "expectExitZero": False,
        "requiredSubstrings": ["Type mismatch", "P5FinalCertifiedOutput", "CertifiedSemanticConsensus"],
        "forbiddenSubstrings": ["unknown module prefix", "expected token"],
        "purpose": "Negative probe A6 (no P4/P5 authority escalation): CertifiedSemanticConsensus cannot inhabit P5FinalCertifiedOutput",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def illegalEscalateToP5 : P5FinalCertifiedOutput :=
  certG01
""",
    },
]


def run_compiler_encapsulation_probes() -> List[Dict[str, object]]:
    results: List[Dict[str, object]] = []
    with tempfile.TemporaryDirectory(prefix="pneuma_r1_probes_") as tmpdir:
        tmp_path = Path(tmpdir)
        for p in PROBES:
            probe_file = tmp_path / f"{p['probeId'].replace('-', '_')}.lean"
            probe_file.write_text(p["code"], encoding="utf-8")
            proc = subprocess.run(
                ["lake", "env", "lean", str(probe_file)],
                cwd=str(R1_ROOT),
                capture_output=True,
                text=True,
                encoding="utf-8",
            )
            combined = (proc.stdout + "\n" + proc.stderr).strip()
            # Mask local temp path and user profile in diagnostic excerpt:
            sanitized = combined.replace(str(probe_file), f"<TEMP_PROBE>/{probe_file.name}")
            user_home = os.path.expanduser("~")
            if user_home:
                sanitized = sanitized.replace(user_home, "<USER_HOME>")

            exit_ok = (proc.returncode == 0) if p["expectExitZero"] else (proc.returncode != 0)
            req_ok = all(sub in sanitized for sub in p["requiredSubstrings"])
            forb_ok = all(sub not in sanitized for sub in p["forbiddenSubstrings"])
            passed = exit_ok and req_ok and forb_ok

            results.append({
                "probeId": p["probeId"],
                "purpose": p["purpose"],
                "expectExitZero": p["expectExitZero"],
                "actualExitCode": proc.returncode,
                "passed": passed,
                "compilerOutput": sanitized,
            })
    return results


def run_cross_language_claim_harness() -> Dict[str, object]:
    rows = generate_120_claim_rows()
    tsv_text = "\n".join("\t".join(cols) for cols, _ in rows) + "\n"
    tsv_sha256 = hashlib.sha256(tsv_text.encode("utf-8")).hexdigest().upper()

    with tempfile.TemporaryDirectory(prefix="pneuma_r1_batch_") as tmpdir:
        tsv_path = Path(tmpdir) / "r1_claims_120.tsv"
        tsv_path.write_text(tsv_text, encoding="utf-8")
        proc = subprocess.run(
            [str(RUNNER_EXE), "--eval-claims-batch", str(tsv_path)],
            cwd=str(R1_ROOT),
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        if proc.returncode != 0:
            raise RuntimeError(f"Runner failed with exit {proc.returncode}: {proc.stderr}")

    lean_lines = [ln.strip() for ln in proc.stdout.splitlines() if ln.strip()]
    if len(lean_lines) != len(rows):
        raise RuntimeError(f"Line count mismatch: Lean={len(lean_lines)} vs Python={len(rows)}")

    mismatches = []
    admit_count = 0
    reject_count = 0
    for idx, ((_, py_expected), lean_actual) in enumerate(zip(rows, lean_lines), start=1):
        if "\tADMIT|" in lean_actual:
            admit_count += 1
        elif "\tREJECT|" in lean_actual:
            reject_count += 1
        if py_expected != lean_actual:
            mismatches.append({
                "index": idx,
                "pythonExpected": py_expected,
                "leanActual": lean_actual,
            })

    return {
        "harnessClassification": "CROSS_LANGUAGE_REFERENCE_HARNESS_NOT_INDEPENDENT_ORACLE",
        "totalClaimVectors": len(rows),
        "admittedVectors": admit_count,
        "rejectedVectors": reject_count,
        "mismatchCount": len(mismatches),
        "batchTsvSha256": tsv_sha256,
        "mismatches": mismatches,
    }


def main() -> int:
    print("==========================================================================")
    print("PNEUMA-NATIVE OMEGA — AUTH-P3C-PROVENANCE-R1 PROBES & CLAIM REPLAY HARNESS")
    print("==========================================================================")

    probe_results = run_compiler_encapsulation_probes()
    all_probes_ok = True
    for pr in probe_results:
        status = "PASS" if pr["passed"] else "FAIL"
        if not pr["passed"]:
            all_probes_ok = False
        print(f"[{status}] {pr['probeId']} (exit={pr['actualExitCode']}) — {pr['purpose']}")
        if pr["compilerOutput"]:
            first_line = pr["compilerOutput"].splitlines()[0]
            print(f"       compiler: {first_line}")

    batch_summary = run_cross_language_claim_harness()
    print("--------------------------------------------------------------------------")
    print(f"Harness Type      : {batch_summary['harnessClassification']}")
    print(f"Total TSV Claims  : {batch_summary['totalClaimVectors']} "
          f"(admitted={batch_summary['admittedVectors']}, rejected={batch_summary['rejectedVectors']})")
    print(f"Batch TSV SHA-256 : {batch_summary['batchTsvSha256']}")
    print(f"Lean-Python Diff  : {batch_summary['mismatchCount']} mismatches")
    print("==========================================================================")

    if "--json" in sys.argv:
        print("JSON_SUMMARY_BEGIN")
        print(json.dumps({"probes": probe_results, "claimHarness": batch_summary}, indent=2))
        print("JSON_SUMMARY_END")

    if (not all_probes_ok) or (batch_summary["mismatchCount"] != 0):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### File 14: `06_receipts/auth_p3c_provenance_r1_verification_receipt.json` (SHA-256: `790E41D1D352C31457281F72BB627E28DD6D3B7DB1B65C7D8F4F39A795D203DD`)
````json
{
  "schema": "PNEUMA_NATIVE_OMEGA_AUTH_P3C_PROVENANCE_R1_RECEIPT_V1",
  "recorded_at": "2026-11-23T19:05:30+09:00",
  "project_governance_title": "PNEUMA-NATIVE OMEGA (Historical Frozen Lineage: BROCA-NATIVE OMEGA)",
  "authorization_gate": "AUTH-P3C-PROVENANCE-R1",
  "authorization_lineage": {
    "ac_p0_06_9a1_human_principal_command": "AUTH-P3C-PROVENANCE-R1 승인한다. 위 범위로 진행해.",
    "ac_p0_06_9a1_timestamp": "2026-11-23T18:03:22+09:00",
    "ac_p0_06_9a2_all_four_fields_pinned_before_write": true,
    "zero_file_writes_prior_to_human_confirmation": true
  },
  "target_scope": "F-P3C-01 Public Result Provenance Binding (Proof-Carrying CertifiedSemanticConsensus, Input/Context Binding Across All 5 Components, Detached Whitebox Claim Verifier, PO-R1-01..PO-R1-07, & Strict P4/P5 Non-Escalation)",
  "isolated_subpackage_root": "C:\\antigravity work\\BROCA_NATIVE_OMEGA_GATE_C1\\P3C_Provenance_R1",
  "lean_namespace": "PneumaOmega.P3C.ProvenanceR1",
  "toolchain": {
    "elan_version": "elan 4.2.4",
    "lean_version": "Lean (version 4.33.1, x86_64-w64-windows-gnu, commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6, Release)",
    "lake_version": "Lake version 5.0.0-src+819816b (Lean version 4.33.1)",
    "python_reference_harness_version": "Python 3.11.8",
    "local_readonly_path_dependencies": [
      "../P2_DerivationReplay",
      "../P3_LexicalGrammar",
      "../P3B_BoundedParser",
      "../P3C_SemanticNorm"
    ],
    "external_network_or_mathlib_dependencies": [],
    "pneuma_finite_operator_r0_dependencies": []
  },
  "verification_commands_executed": [
    {
      "command": "lake build",
      "exit_code": 0,
      "jobs_succeeded": "80/80",
      "warnings": 0,
      "errors": 0
    },
    {
      "command": ".\\.lake\\build\\bin\\p3c_provenance_r1_runner.exe",
      "exit_code": 0,
      "gate_d_vectors_passed": "24/24",
      "symmetric_pc_ce_pairs": "12/12",
      "status_line": "TOTAL R1 GATE-D VECTORS : 24/24 PASSED"
    },
    {
      "command": "python 05_independent_tribunal/provenance_audit_and_probes.py --json",
      "exit_code": 0,
      "compiler_encapsulation_probes_passed": "5/5",
      "probe_ids": [
        "PROBE-CTRL-01",
        "PROBE-NEG-01a",
        "PROBE-NEG-01b",
        "PROBE-NEG-02",
        "PROBE-NEG-03"
      ],
      "harness_classification": "CROSS_LANGUAGE_REFERENCE_HARNESS_NOT_INDEPENDENT_ORACLE",
      "serialized_claim_vectors": "120/120",
      "admitted_claims": 24,
      "rejected_claims": 96,
      "batch_tsv_sha256": "E3C93CBBF93E36212D43F72FE9CA2C2FE85CED3DEEF8B0DB7C960B51D520276F",
      "mismatches": 0
    },
    {
      "command": "lake env leanchecker --fresh P3CProvenanceTribunalAudit",
      "exit_code": 0,
      "r1_project_olean_modules": 9,
      "replayed_upstream_frozen_packages": [
        "P2_DerivationReplay",
        "P3_LexicalGrammar",
        "P3B_BoundedParser",
        "P3C_SemanticNorm"
      ],
      "elapsed_sec": 738.03
    }
  ],
  "axiom_audit": {
    "sorryAx_present": false,
    "ofReduceBool_native_decide_present": false,
    "trustCompiler_present": false,
    "custom_axioms_present": false,
    "unsafe_declarations_present": false,
    "standard_lean_foundational_axioms_only": [
      "propext",
      "Classical.choice",
      "Quot.sound"
    ],
    "audited_theorems": [
      "PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_01_ConstructionSoundness",
      "PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_02_InputBinding",
      "PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_03_ConsensusPreservation",
      "PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_04_FailClosed",
      "PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_05_NoAuthorityEscalation",
      "PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_06_ReplayFaithfulness",
      "PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_07_ProvenanceNonVacuity",
      "PneumaOmega.P3C.ProvenanceR1.Obligations.PO_R1_All24AttackVectorsVerified",
      "PneumaOmega.P3C.ProvenanceR1.certifiedSemanticConsensus_unique",
      "PneumaOmega.P3C.ProvenanceR1.Attacks.verifyClaimPure_error_iff",
      "PneumaOmega.P3C.ProvenanceR1.Attacks.verifyClaimPure_ok_iff"
    ]
  },
  "source_artifact_sha256": {
    "lean-toolchain": "3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71",
    "lakefile.toml": "5141FEED4E4F37A4ABBC2EE7E67C43FC28753C88EF3A2902EBD78B1CA0F31BB6",
    "lake-manifest.json": "547241BA6AECB60D9CC286617791FC7B9BD50BE6DAE1FB4FC708BF418320D8C3",
    "01_formal_spec/P3CProvenanceSpec.lean": "67603658E007700E6A70F17B50886CCC5717EADAF8CA2FD46460C6D289281F37",
    "01_formal_spec/P3CProvenanceSpec/ThreatModelAndContext.lean": "49422ADF1B9D58A41BAFD80017CE9434B67A2A6F78ABED4D0196720E6E19836E",
    "02_detached_checker/P3CProvenanceChecker.lean": "7652739A9519575C251BCE2DCE9D192D1E79B7603BC0366B9289BA233DC856D3",
    "02_detached_checker/P3CProvenanceChecker/SealedProvenanceGate.lean": "49DA95B50CE09E31279FD8245D4B1BD7D05E02972239004C70A3A21DEF907805",
    "03_counterexamples/P3CProvenanceAttacks.lean": "F36860CE8A75558EC7FF9B1BE2384EB31641FA640A7DC71DE0AFA44102C4AB97",
    "03_counterexamples/P3CProvenanceAttacks/AttackSuiteR1.lean": "814543BA4E33532A80E9722309DE80D1CE77E8375F6084FF4BCF41C2A6F55722",
    "04_proof_obligations/P3CProvenanceObligations.lean": "B34E9DD691B31E393C6F64487A5B69481CD6D0B9CA3936F36207FAAE96371F70",
    "04_proof_obligations/P3CProvenanceObligations/PO_R1_01_To_07.lean": "00965D8B81509864ED621E676399DE7917568B22D2B5736E9D468BD02D1A3707",
    "05_independent_tribunal/P3CProvenanceTribunalAudit.lean": "A0BE882DF80A73EE20D45AB7895FF5FE70D4D7B8FEF281C7E9F659A4AC47705C",
    "05_independent_tribunal/provenance_audit_and_probes.py": "07677C95A5BDF5BE38E3F711984602047EEF11ED0942DB99ABEF1409497B9494"
  },
  "compiled_artifact_sha256": {
    "P3CProvenanceSpec/ThreatModelAndContext.olean": "8254E51016C84AFDE3744CC9896E6477334248537F0A5686C7116D493F7DB370",
    "P3CProvenanceSpec.olean": "CAE2E43E8E04A8C469DEFF4C67BBBB781AD75B460041CD185028BDD8785BC698",
    "P3CProvenanceChecker/SealedProvenanceGate.olean": "3600A07B6B70C416C6FF566EDF6AEF086D7957828F2B471FC41D6A8C2AA783F6",
    "P3CProvenanceChecker.olean": "756D295336ABD52FD061EE91F3A47A28D8ADE7FD4231F8BF05D7C330DF95058E",
    "P3CProvenanceAttacks/AttackSuiteR1.olean": "D7AAE0B9114EED43BC0C39B11DEE62B280FFEA1CD7A6B0DB39192FDC6B44614B",
    "P3CProvenanceAttacks.olean": "0567CBB3836107450B54244D665FA68B5D05AFF257C2D257ADFE2272E3F77E4E",
    "P3CProvenanceObligations/PO_R1_01_To_07.olean": "E7BFF7CA3759EE63D447BD9AB066F73BABA272C58AD71A6B6C7224FD1D44E47E",
    "P3CProvenanceObligations.olean": "21BC9AD023591A490053A98313D651FA9A071FE6FD6816F9B37CC0A5B9774B4B",
    "P3CProvenanceTribunalAudit.olean": "826A1E966E12E9B37FD24893E005810B006ED8C52B0983FDC8B089D2F5C81FBA",
    "p3c_provenance_r1_runner.exe": "DEB010B16805B17211B653DADFEC032F79CB698AAFE7B7348343A365C6DB19EA"
  },
  "prior_gate_immutability_verified": {
    "pneuma_workspace_file_count": 0,
    "broca_shared_anchors_unchanged": "6/6",
    "frozen_reference_manifest_sha256": "2FA5C7EC0423A6D404EBBB681E2393B9041C7E02634EB71D4505405162D3C076",
    "parent_06_receipts_untouched": "6/6",
    "auth_c1_dir_receipt_sha256": "036E6543AD43365F9B914259840E0508F920FE24F56AAD45824639B7F480620E",
    "auth_c1_p1_receipt_sha256": "EC53292AD346D0FD17393C00F0DE5AD0832CEB48B09CE2D298A97B8101C5CDAB",
    "auth_c1_p2_receipt_sha256": "5D9BFCD3B3F029AF1B338CB47AC0445FB8707437898B9777A6C771BD40029F3E",
    "auth_c1_p3a_receipt_sha256": "46A80A14CEEF917E133B375B49D4C2CD60FCB91300246920D7A819E556BEC79F",
    "auth_c1_p3b_receipt_sha256": "212FE405EA722F72E11CB65493072F688AC86FFB7E6E47D49F6FAD5CDC58E595",
    "auth_c1_p3c_receipt_sha256": "191AE819B8844BA81B323F1FCA1D1C04591941C52FA9D5E8B14339202C9E79A7",
    "p1_sources_unchanged": "13/13",
    "p2_sources_unchanged": "14/14",
    "p3a_sources_unchanged": "14/14",
    "p3b_sources_unchanged": "14/14",
    "p3c_sources_unchanged": "14/14",
    "p3c_binaries_unchanged": "12/12",
    "p3c_dossier_sha256_unchanged": "B1EF2820F3FCEFA5D85AC938AD9FE7F7428C64E08F4A5C4CD324E951E3AE8A67",
    "p3c_reconciliation_r0_dossier_sha256_unchanged": "EF36A4E34C60B9C45EB7D6977B7FAF912161369F77A655255E2A619EC9017CE6"
  },
  "scope_and_held_locks": {
    "f_p3c_01_scoped_provenance_bound_in_r1": true,
    "legacy_p3c_authorization_qualified_unchanged": true,
    "f_p3c_02_semantic_scope_held": true,
    "out_of_kernel_binary_memory_runtime_tamper_held": true,
    "r1_external_independent_host_replay_held": true,
    "p1_p2_p3a_p3b_p3c_external_replay_held": true,
    "extensional_contrastive_world_assumption_retained": true,
    "pneuma_finite_operator_r0_authorized": false,
    "p1_c_int128_fast_path_authorized": false,
    "p4_clinical_evidence_authorized": false,
    "p5_snapshot_admission_authorized": false,
    "pneuma_speech_and_listener_authorized": false,
    "ancestors_or_p1_to_p3c_modified": false
  }
}
````

