# BROCA-NATIVE Ω — AUTH-C1-P3-A Read-Only Independent Tribunal Verification Bundle (`P3_LexicalGrammar`)

> [!IMPORTANT]
> **Read-Only Audit Submission (`AUTH-C1-P3-A`: Independent Frozen BNF & Strict Lexical Gate)**
> All Lean `4.33.1` source files, build configurations, Python `3.11` differential oracle code, execution logs, and receipt JSON contents below are **100% verbatim, unmodified copies** of the files on disk inside `C:\antigravity work\BROCA_NATIVE_OMEGA_GATE_C1\P3_LexicalGrammar\` and `06_receipts\`. All prior baselines (`Pneuma` `0` files, `Broca`/`shared` `6/6`, `DIR` receipt, `P1` `13/13` + receipt, `P2` `14/14` + receipt) remain untouched.

---

## 1. Gate 0 ~ Gate F Audit Index (Exact Source & Line Mapping)

| Gate | Mandate Requirement | Verbatim Implementation & Formal Evidence |
| :--- | :--- | :--- |
| **Gate 0** | Prior baseline hash observation & isolated workspace | `Pneuma` (`0` files), `Broca`/`shared` (`6/6`), `P1` (`13/13`), `P2` (`14/14`) SHA-256 hashes verified read-only before & after `P3-A` build. |
| **Gate A** | Independent Frozen BNF (`G-01`~`G-16` vs `T1`~`T5`, `readingAlt` as reading index, provenance, `P2` correspondence) | `FrozenBNF.lean` (21 `CanonicalRuleId`s, `isGeneratorRule`, `readingAltCount`, `independentFrozenBNF` with `S0-R2`/`S0-R2.1`/`S0-R2.2`/`C0-R1`/`P0-A05` citations, `all_independentFrozenBNF_acyclic`, `all_21_canonical_rules_covered`, `trap_productions_never_in_generator`) + `P2CorrespondenceAudit.lean` (`p3_generator_bnf_matches_p2_snapshots`, `p2_snapshots_exclude_all_trap_productions`) + Python disk verification (`27/27` rules in `GrammarG16.lean`). |
| **Gate B** | Strict Lexical Gate (UTF-8/7-bit ASCII profile, canonical decimal surface, closed entity catalog & global surface injectivity) | `StrictLexicalSpec.lean` (pure `Prop` specs `StrictAsciiUTF8Valid`, `DecSurfaceSpec`, `ValidEntityCatalog`, `LexicallyValid`, `NumericallyWellFormed`, `EntityCatalogBound`) separated cleanly from `StrictLexicalGate.lean` (`checkStrictAsciiIngress`, `parseCanonicalDecSurface`, `checkValidEntityCatalogBool`, `evalLexicalSlot`, `admitLexicalSlot`). |
| **Gate C** | Proof-carrying encapsulation & `Check=true -> DeclarativeValid` + Completeness | `StrictLexicalGate.lean`: sealed `VerifiedIngressText` & `CertifiedLexicalSlot` (`private mk ::`), `admitLexicalSlot_sound`, `admitLexicalSlot_complete`, plus universal rejection theorems `decSurfaceSpec_rejects_multiple_dots` (`1..25`, `1.2.3`) and `decSurfaceSpec_rejects_trailing_dot` (`1.`). |
| **Gate D** | Symmetric `(PC, CE)` suite + true 1-to-1 `Lean <-> Python` serialized batch differential verification | `P3ASuite.lean` (`32` curated vectors calling `admitLexicalSlot`/`verifyRuleReadingGate` directly, kernel-proved via `decide`) + `P3ATribunalAudit.lean` (`--eval-batch`) + `differential_oracle_p3a.py` (`32/32` fixed parity + `300/300` external serialized batch `Lean <-> Python` 1:1 parity: `240/240` adversarial rejected in BOTH Lean & Python, `60/60` valid boundary accepted in BOTH). |
| **Gate E** | Reproducible Lean `4.33.1` build, `#print axioms`, `leanchecker --fresh`, SHA-256 ledger | `lake build` (`28/28`, `0` warnings, `0` errors), `14` exported theorems audited (`0` `sorryAx`, `0` `Lean.ofReduceBool`, `0` custom axioms; `2` BNF correspondence theorems depend on **zero axioms**), `leanchecker --fresh P3ATribunalAudit` (`exit code 0`). |
| **Gate F** | Explicit residual `HELD` & `NOT_AUTHORIZED` preservation | `F-P2-01` & `F-P2-02` kept `EVIDENCE_SUBMITTED_PENDING_TRIBUNAL_HELD` until Tribunal disposition; `G-01` right-censored KM/AJ English surface & production clinical ontology entries explicitly kept `HELD_UNSPECIFIED_IN_R0`; `P3-B/C`, `P1-C`, `P4/P5`, `Pneuma` `NOT_AUTHORIZED`. |

---

## 2. Explicit Numeric & Lexical Policy Boundary Table (Mandate §2.B & §3.B)

| Input / Case | Lean Verdict | Python Verdict | Exact Diagnostic / R0 Provenance Note |
| :--- | :---: | :---: | :--- |
| `1.25` | `ACCEPT` | `ACCEPT` | Canonical decimal (`mantissa=125, scale10=2`, `PC-P3A-01`) |
| `1..25` | `REJECT` | `REJECT` | `multipleDecimalPoints` (`CE-P3A-01` + `decSurfaceSpec_rejects_multiple_dots`) |
| `1.2.3` | `REJECT` | `REJECT` | `multipleDecimalPoints` (`CE-P3A-02` + `decSurfaceSpec_rejects_multiple_dots`) |
| `-0.0` / `-0` | `REJECT` | `REJECT` | `negativeZeroForbidden` (`CE-P3A-03`, `Gate C0-R1` §II.1 `F-C0-01`) |
| `1.` | `REJECT` | `REJECT` | `trailingDecimalPoint` (`CE-P3A-04` + `decSurfaceSpec_rejects_trailing_dot`; `S0-R2.2` §II.1 line 36 `(\.[0-9]{1,4})?` requires >=1 digit after `.`; fail-closed `REJECT`, policy qualification noted) |
| `.25` | `REJECT` | `REJECT` | `leadingDecimalPoint` (`CE-P3A-05`; `S0-R2.2` `[0-9]{1,7}` requires >=1 integer digit) |
| `+1.25` | `REJECT` | `REJECT` | `explicitPlusForbidden` (`CE-P3A-06`; canonical `DecLit` forbids explicit `+`, `S0-R2.2` `[+-]?` draft vs `C0-R1`/`P1` `negSign : Bool` noted) |
| `001.25` | `REJECT` | `REJECT` | `redundantLeadingZero` (`CE-P3A-07`; enforces unique canonical `fmtEq` integer representation) |
| `1e-3` | `REJECT` | `REJECT` | `invalidNumericCharOrExponent` (`CE-P3A-08`; scientific notation excluded in `R0`) |
| Valid `lexeme` + wrong `entityId` | `REJECT` | `REJECT` | `entityCatalogMismatch` (`CE-P3A-11`) |
| Valid `entityId` + wrong `SlotSort` | `REJECT` | `REJECT` | `entityCatalogMismatch` (`CE-P3A-12`) |
| Duplicate `lexeme` across sorts | `REJECT` | `REJECT` | `invalidEntityCatalog` (`CE-P3A-15`; enforces `F-R2.2-02` Global Surface Injectivity) |

---

## 3. SHA-256 Integrity Ledger (Prior Gates, `P3-A` Sources, `.olean` Artifacts & Receipt)

### 3.1 Prior Gate & Ancestor Immutability
- `C:\antigravity work\Pneuma`: `0` files (`UNCHANGED`)
- `00_frozen_reference/manifest_only/frozen_reference_manifest.json`: `2FA5C7EC0423A6D404EBBB681E2393B9041C7E02634EB71D4505405162D3C076` (`6/6` `Broca`/`shared` anchors verified)
- `06_receipts/auth_c1_dir_environment_receipt.json`: `036E6543AD43365F9B914259840E0508F920FE24F56AAD45824639B7F480620E` (`UNCHANGED`)
- `06_receipts/auth_c1_p1_verification_receipt.json`: `EC53292AD346D0FD17393C00F0DE5AD0832CEB48B09CE2D298A97B8101C5CDAB` (`13/13` `P1` sources verified)
- `06_receipts/auth_c1_p2_verification_receipt.json`: `5D9BFCD3B3F029AF1B338CB47AC0445FB8707437898B9777A6C771BD40029F3E` (`14/14` `P2` sources verified)
- `06_receipts/auth_c1_p3a_verification_receipt.json`: `46A80A14CEEF917E133B375B49D4C2CD60FCB91300246920D7A819E556BEC79F`

### 3.2 `P3-A` Source ↔ `.olean` / `.exe` SHA-256 Table

| Relative Path (`P3_LexicalGrammar/`) | Source SHA-256 | Compiled `.olean` / `.exe` SHA-256 |
| :--- | :--- | :--- |
| `lean-toolchain` | `3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71` | *(config / oracle script)* |
| `lakefile.toml` | `A6A7C6A75BE4F482AA7EB1390688C820F733634D21658A9FCDF2F866DD4A6B3F` | *(config / oracle script)* |
| `01_formal_spec/P3FormalSpec.lean` | `2621B972EDA1434B1277572C950192F972DF36EBE24DA5D42525ADC2FC7332C1` | `D3C231DD8C494C8EE6D5A3E961355AF03C7194DB3D3FC689B1A406BB3EBBB8F2` |
| `01_formal_spec/P3FormalSpec/StrictLexicalSpec.lean` | `9A4DF89ADAE2981AAA636FDB75F223451ED1199201643EA7D87349FEBBE4E582` | `49174CE8140008CFA351E7AB19ED1E30513BCA46DF3E1306B6C1F19CBF59A059` |
| `01_formal_spec/P3FormalSpec/FrozenBNF.lean` | `C0E664F2EBB66A4D070002A83D82A3BF5F9CB3721000FDEF009B50AFBCE5808C` | `BCED6CF88006BC84E43C853A52EA249526575D91F8F52ECBF50AF77DD032476C` |
| `01_formal_spec/P3FormalSpec/P2CorrespondenceAudit.lean` | `2FAF234D276D433329D4477FC978DFFAB67183C43E46F74C42900105907E5FD8` | `1233D5AC2A55C861976C593284A1E682EB3F8F004B933F46D08A861EB0868A79` |
| `02_detached_checker/P3DetachedChecker.lean` | `290D2D9EC89DEB00C6117FCB6C3FECA67B098AEDE07F3D04C1EC395B1FDCAE11` | `B15ABF958E5D6D327FBF6F1C920F17C188F2D1F0524DA0DC5A24A8C491E34EBC` |
| `02_detached_checker/P3DetachedChecker/StrictLexicalGate.lean` | `2FD8F2BA94B2930FDC0E674DC0DCB7E69368FC81645A7731EF21FC7295AE17D9` | `A48B7627B5E9856AED2FB00F806C35A3FD358E82B08963EBB7C936112FF2C91D` |
| `03_counterexamples/P3Counterexamples.lean` | `9FDF552CADD1E6FE8DA6F033D14963C4A9CADD8D1DB35478D6F9E4E0550041F3` | `AF8000BD02CE8A8B4F7E0EEDD2141544D768361A2C6C1D03E11AD2C2BC67FFAA` |
| `03_counterexamples/P3Counterexamples/P3ASuite.lean` | `B647C78578277E07DC3B774E6EF5DFA5FE36935F4867AC14DC1861EEFCD6F327` | `5EE18ED7170EFE14DED8D0201281E80121994865CAD8549022BB9D275502737B` |
| `04_proof_obligations/P3ProofObligations.lean` | `505E822FA9B27E79319D744F14825FDCF544FF27EB83DCEA52F8F9C72CBC55C3` | `34E880957EB8DD1EFB21FA9662640EB4096210251107F049C159B00C6CB1CAE8` |
| `04_proof_obligations/P3ProofObligations/PO_C1_P3A_LexicalAndBNF.lean` | `12C488A4E6AD9E989406692A43A2A01DE4475BC03859223B62233A5984F0F5E8` | `DDD87627D296E09882D1ECAD27FC05102F83ACF9A07D0A641783B8E92D84DBDA` |
| `05_independent_tribunal/P3ATribunalAudit.lean` | `05CBF76C7F4F6BF0E4E88AEB2B14E1C92704169E6D47107689FBFC847254D086` | `B6F69D800379460DEEC6FECCCAD0596B8C0C2392D861E8D287A4FB8D5E18FD09` / exe `CC0E12AC08410D5398A0889391DD6121055CE7EE3DF545FB05734F9B18B9C2CD` |
| `05_independent_tribunal/differential_oracle_p3a.py` | `3513A3125DC504E66768D7E58C2445292AEFE2CE061AAD80A1B6D35FEE7F5B8C` | *(config / oracle script)* |

---

## 4. Verbatim Build, `#print axioms`, `leanchecker --fresh`, and Differential Oracle Logs

### 4.1 `lake build` & `#print axioms` Output
```text
ℹ [26/28] Built P3ATribunalAudit (981ms)
info: 05_independent_tribunal/P3ATribunalAudit.lean:21:0: 'BrocaOmega.P3A.ProofObligations.P3A_FrozenBNF_Acyclic' depends on axioms: [propext]
info: 05_independent_tribunal/P3ATribunalAudit.lean:22:0: 'BrocaOmega.P3A.ProofObligations.P3A_All21CanonicalRulesCovered' depends on axioms: [propext]
info: 05_independent_tribunal/P3ATribunalAudit.lean:23:0: 'BrocaOmega.P3A.ProofObligations.P3A_TrapPartitionSound' depends on axioms: [propext]
info: 05_independent_tribunal/P3ATribunalAudit.lean:24:0: 'BrocaOmega.P3A.ProofObligations.P3A_GeneratorBNF_Matches_P2' does not depend on any axioms
info: 05_independent_tribunal/P3ATribunalAudit.lean:25:0: 'BrocaOmega.P3A.ProofObligations.P3A_P2_Excludes_Traps' does not depend on any axioms
info: 05_independent_tribunal/P3ATribunalAudit.lean:26:0: 'BrocaOmega.P3A.ProofObligations.P3A_RuleReadingGate_Sound' depends on axioms: [propext]
info: 05_independent_tribunal/P3ATribunalAudit.lean:27:0: 'BrocaOmega.P3A.ProofObligations.P3A_StrictAsciiIngress_Sound' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3ATribunalAudit.lean:28:0: 'BrocaOmega.P3A.ProofObligations.P3A_CanonicalDecimal_Sound' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3ATribunalAudit.lean:29:0: 'BrocaOmega.P3A.ProofObligations.P3A_CanonicalDecimal_Complete' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3ATribunalAudit.lean:30:0: 'BrocaOmega.P3A.ProofObligations.P3A_RejectsMultiDot' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3ATribunalAudit.lean:31:0: 'BrocaOmega.P3A.ProofObligations.P3A_RejectsTrailingDot' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3ATribunalAudit.lean:32:0: 'BrocaOmega.P3A.ProofObligations.P3A_StrictLexicalSlot_Sound' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3ATribunalAudit.lean:33:0: 'BrocaOmega.P3A.ProofObligations.P3A_StrictLexicalSlot_Complete' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3ATribunalAudit.lean:34:0: 'BrocaOmega.P3A.ProofObligations.P3A_All32CounterexamplePairs_Verified' depends on axioms: [propext, Classical.choice, Quot.sound]
✔ [27/28] Built P3ATribunalAudit:c.o (460ms)
✔ [28/28] Built p3a_tribunal_runner:exe (492ms)
Build completed successfully (28 jobs).
```

### 4.2 `p3a_tribunal_runner.exe` Execution Output (`32/32` Curated Vectors)
```text
==========================================================================
BROCA-NATIVE OMEGA — AUTH-C1-P3-A STRICT LEXICAL & FROZEN BNF VERIFICATION
Scope     : Independent Frozen BNF + Strict Lexical Gate (P3-A ONLY)
Toolchain : Lean 4.33.1 Core (Init only, 0 external deps, 0 sorry)
==========================================================================
[PASS] PC-P3A-01 (PAIR-01-MULTI-DOT-1) => ACCEPTED
[PASS] CE-P3A-01 (PAIR-01-MULTI-DOT-1) => REJECTED (multipleDecimalPoints)
[PASS] PC-P3A-02 (PAIR-02-MULTI-DOT-2) => ACCEPTED
[PASS] CE-P3A-02 (PAIR-02-MULTI-DOT-2) => REJECTED (multipleDecimalPoints)
[PASS] PC-P3A-03 (PAIR-03-NEG-ZERO) => ACCEPTED
[PASS] CE-P3A-03 (PAIR-03-NEG-ZERO) => REJECTED (negativeZeroForbidden)
[PASS] PC-P3A-04 (PAIR-04-TRAILING-DOT) => ACCEPTED
[PASS] CE-P3A-04 (PAIR-04-TRAILING-DOT) => REJECTED (trailingDecimalPoint)
[PASS] PC-P3A-05 (PAIR-05-LEADING-DOT) => ACCEPTED
[PASS] CE-P3A-05 (PAIR-05-LEADING-DOT) => REJECTED (leadingDecimalPoint)
[PASS] PC-P3A-06 (PAIR-06-EXPLICIT-PLUS) => ACCEPTED
[PASS] CE-P3A-06 (PAIR-06-EXPLICIT-PLUS) => REJECTED (explicitPlusForbidden)
[PASS] PC-P3A-07 (PAIR-07-LEADING-ZERO) => ACCEPTED
[PASS] CE-P3A-07 (PAIR-07-LEADING-ZERO) => REJECTED (redundantLeadingZero)
[PASS] PC-P3A-08 (PAIR-08-EXPONENT) => ACCEPTED
[PASS] CE-P3A-08 (PAIR-08-EXPONENT) => REJECTED (invalidNumericCharOrExponent)
[PASS] PC-P3A-09 (PAIR-09-PRECISION-CAP) => ACCEPTED
[PASS] CE-P3A-09 (PAIR-09-PRECISION-CAP) => REJECTED (numericPrecisionBoundExceeded)
[PASS] PC-P3A-10 (PAIR-10-NUMERIC-ID-BIND) => ACCEPTED
[PASS] CE-P3A-10 (PAIR-10-NUMERIC-ID-BIND) => REJECTED (numericEntityIdMismatch)
[PASS] PC-P3A-11 (PAIR-11-WRONG-ENTITY-ID) => ACCEPTED
[PASS] CE-P3A-11 (PAIR-11-WRONG-ENTITY-ID) => REJECTED (entityCatalogMismatch)
[PASS] PC-P3A-12 (PAIR-12-WRONG-SLOT-SORT) => ACCEPTED
[PASS] CE-P3A-12 (PAIR-12-WRONG-SLOT-SORT) => REJECTED (entityCatalogMismatch)
[PASS] PC-P3A-13 (PAIR-13-KEYWORD-LEAK) => ACCEPTED
[PASS] CE-P3A-13 (PAIR-13-KEYWORD-LEAK) => REJECTED (reservedKeywordLeak)
[PASS] PC-P3A-14 (PAIR-14-UTF8-HOMOGLYPH) => ACCEPTED
[PASS] CE-P3A-14 (PAIR-14-UTF8-HOMOGLYPH) => REJECTED (nonPrintableAsciiOrInvalidUtf8)
[PASS] PC-P3A-15 (PAIR-15-CATALOG-INJECTIVITY) => ACCEPTED
[PASS] CE-P3A-15 (PAIR-15-CATALOG-INJECTIVITY) => REJECTED (invalidEntityCatalog)
[PASS] PC-P3A-16 (PAIR-16-TRAP-READING-ALT) => ACCEPTED
[PASS] CE-P3A-16 (PAIR-16-TRAP-READING-ALT) => REJECTED (parserOnlyTrapRuleInGenerator)
--------------------------------------------------------------------------
SUMMARY: 32 / 32 symmetric (PC, CE) vectors verified.
Inherited HELD : P1_EXTERNAL_REPLAY_HELD, P2_EXTERNAL_REPLAY_HELD
Audit Evidence : F-P2-01 & F-P2-02 submitted (HELD pending Tribunal ruling)
Not Authorized : P1-C, P3-B, P3-C, P4, P5, Pneuma-S3/S4
==========================================================================
```

### 4.3 `lake env leanchecker --fresh P3ATribunalAudit` Kernel Replay Output
```text
﻿Command: lake env leanchecker --fresh P3ATribunalAudit
WorkingDirectory: C:\antigravity work\BROCA_NATIVE_OMEGA_GATE_C1\P3_LexicalGrammar
LEANCHECKER_EXIT_CODE=0
LEANCHECKER_ELAPSED_SEC=88.04
```

### 4.4 Python `3.11` Differential Oracle Output (`32/32` Fixed + `300/300` Batch 1:1 `Lean <-> Python` Parity + `27/27` P2 Disk Audit)
```text
==========================================================================
PYTHON 3.11 INDEPENDENT DIFFERENTIAL ORACLE — BROCA-NATIVE OMEGA P3-A
Read-Only P2 Disk Snapshot Verification : 27 / 27 EXACT RULE MATCH
==========================================================================
[PARITY_OK] PC-P3A-01 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-01 | Lean=(False, multipleDecimalPoints) | Python=(False, multipleDecimalPoints)
[PARITY_OK] PC-P3A-02 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-02 | Lean=(False, multipleDecimalPoints) | Python=(False, multipleDecimalPoints)
[PARITY_OK] PC-P3A-03 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-03 | Lean=(False, negativeZeroForbidden) | Python=(False, negativeZeroForbidden)
[PARITY_OK] PC-P3A-04 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-04 | Lean=(False, trailingDecimalPoint) | Python=(False, trailingDecimalPoint)
[PARITY_OK] PC-P3A-05 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-05 | Lean=(False, leadingDecimalPoint) | Python=(False, leadingDecimalPoint)
[PARITY_OK] PC-P3A-06 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-06 | Lean=(False, explicitPlusForbidden) | Python=(False, explicitPlusForbidden)
[PARITY_OK] PC-P3A-07 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-07 | Lean=(False, redundantLeadingZero) | Python=(False, redundantLeadingZero)
[PARITY_OK] PC-P3A-08 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-08 | Lean=(False, invalidNumericCharOrExponent) | Python=(False, invalidNumericCharOrExponent)
[PARITY_OK] PC-P3A-09 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-09 | Lean=(False, numericPrecisionBoundExceeded) | Python=(False, numericPrecisionBoundExceeded)
[PARITY_OK] PC-P3A-10 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-10 | Lean=(False, numericEntityIdMismatch) | Python=(False, numericEntityIdMismatch)
[PARITY_OK] PC-P3A-11 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-11 | Lean=(False, entityCatalogMismatch) | Python=(False, entityCatalogMismatch)
[PARITY_OK] PC-P3A-12 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-12 | Lean=(False, entityCatalogMismatch) | Python=(False, entityCatalogMismatch)
[PARITY_OK] PC-P3A-13 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-13 | Lean=(False, reservedKeywordLeak) | Python=(False, reservedKeywordLeak)
[PARITY_OK] PC-P3A-14 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-14 | Lean=(False, nonPrintableAsciiOrInvalidUtf8) | Python=(False, nonPrintableAsciiOrInvalidUtf8)
[PARITY_OK] PC-P3A-15 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-15 | Lean=(False, invalidEntityCatalog) | Python=(False, invalidEntityCatalog)
[PARITY_OK] PC-P3A-16 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P3A-16 | Lean=(False, parserOnlyTrapRuleInGenerator) | Python=(False, parserOnlyTrapRuleInGenerator)
--------------------------------------------------------------------------
Fixed Curated Lean <-> Python Parity     : 32 / 32 EXACT MATCH
External Batch Lean <-> Python Parity    : 300 / 300 EXACT MATCH (seed=2026112203)
Lean Adversarial Mutation Rejections     : 240 / 240
Python Adversarial Mutation Rejections   : 240 / 240
Valid Boundary Mutation Acceptances      : Lean=60/60, Python=60/60
P2 GrammarG16.lean Disk Snapshot Match   : 27 / 27
==========================================================================
```

---

## 5. Verbatim `auth_c1_p3a_verification_receipt.json`
(`SHA-256: 46A80A14CEEF917E133B375B49D4C2CD60FCB91300246920D7A819E556BEC79F`)
```json
{
  "schema": "BROCA_NATIVE_OMEGA_AUTH_C1_P3A_RECEIPT_V1",
  "recorded_at": "2026-11-22T20:26:30+09:00",
  "authorization_gate": "AUTH-C1-P3-A",
  "target_scope": "Independent Frozen BNF Specification & Strict Lexical Gate (F-P2-01 & F-P2-02 Evidence Production)",
  "isolated_root": "C:\\antigravity work\\BROCA_NATIVE_OMEGA_GATE_C1",
  "p3a_subpackage_root": "C:\\antigravity work\\BROCA_NATIVE_OMEGA_GATE_C1\\P3_LexicalGrammar",
  "toolchain": {
    "lean_version": "Lean (version 4.33.1, x86_64-w64-windows-gnu, commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6, Release)",
    "lake_version": "Lake version 5.0.0-src+819816b (Lean version 4.33.1)",
    "python_differential_oracle_version": "Python 3.11.8",
    "external_lean_dependencies": []
  },
  "verification_commands_executed": [
    {
      "command": "lake build",
      "exit_code": 0,
      "jobs_succeeded": "28/28",
      "warnings": 0,
      "errors": 0
    },
    {
      "command": ".\\.lake\\build\\bin\\p3a_tribunal_runner.exe",
      "exit_code": 0,
      "paired_cases_passed": "32/32",
      "status_line": "SUMMARY: 32 / 32 symmetric (PC, CE) vectors verified."
    },
    {
      "command": "lake env leanchecker --fresh P3ATribunalAudit",
      "exit_code": 0,
      "project_olean_modules": 11,
      "elapsed_sec": 88.04
    },
    {
      "command": "python 05_independent_tribunal/differential_oracle_p3a.py",
      "exit_code": 0,
      "p2_disk_snapshot_rule_match": "27/27",
      "fixed_curated_lean_python_parity": "32/32",
      "external_batch_lean_python_parity": "300/300",
      "lean_adversarial_mutation_rejections": "240/240",
      "python_adversarial_mutation_rejections": "240/240",
      "valid_boundary_mutation_acceptances": "60/60",
      "prng_seed": 2026112203
    }
  ],
  "axiom_audit": {
    "sorryAx_present": false,
    "ofReduceBool_native_decide_present": false,
    "trustCompiler_present": false,
    "custom_axioms_present": false,
    "unsafe_declarations_present": false,
    "standard_lean_foundational_axioms_only": [
      "propext",
      "Classical.choice",
      "Quot.sound"
    ],
    "per_theorem_axioms": {
      "BrocaOmega.P3A.ProofObligations.P3A_FrozenBNF_Acyclic": [
        "propext"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_All21CanonicalRulesCovered": [
        "propext"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_TrapPartitionSound": [
        "propext"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_GeneratorBNF_Matches_P2": [],
      "BrocaOmega.P3A.ProofObligations.P3A_P2_Excludes_Traps": [],
      "BrocaOmega.P3A.ProofObligations.P3A_RuleReadingGate_Sound": [
        "propext"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_StrictAsciiIngress_Sound": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_CanonicalDecimal_Sound": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_CanonicalDecimal_Complete": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_RejectsMultiDot": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_RejectsTrailingDot": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_StrictLexicalSlot_Sound": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_StrictLexicalSlot_Complete": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3A.ProofObligations.P3A_All32CounterexamplePairs_Verified": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ]
    }
  },
  "source_artifact_sha256": {
    "lean-toolchain": "3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71",
    "lakefile.toml": "A6A7C6A75BE4F482AA7EB1390688C820F733634D21658A9FCDF2F866DD4A6B3F",
    "01_formal_spec/P3FormalSpec.lean": "2621B972EDA1434B1277572C950192F972DF36EBE24DA5D42525ADC2FC7332C1",
    "01_formal_spec/P3FormalSpec/StrictLexicalSpec.lean": "9A4DF89ADAE2981AAA636FDB75F223451ED1199201643EA7D87349FEBBE4E582",
    "01_formal_spec/P3FormalSpec/FrozenBNF.lean": "C0E664F2EBB66A4D070002A83D82A3BF5F9CB3721000FDEF009B50AFBCE5808C",
    "01_formal_spec/P3FormalSpec/P2CorrespondenceAudit.lean": "2FAF234D276D433329D4477FC978DFFAB67183C43E46F74C42900105907E5FD8",
    "02_detached_checker/P3DetachedChecker.lean": "290D2D9EC89DEB00C6117FCB6C3FECA67B098AEDE07F3D04C1EC395B1FDCAE11",
    "02_detached_checker/P3DetachedChecker/StrictLexicalGate.lean": "2FD8F2BA94B2930FDC0E674DC0DCB7E69368FC81645A7731EF21FC7295AE17D9",
    "03_counterexamples/P3Counterexamples.lean": "9FDF552CADD1E6FE8DA6F033D14963C4A9CADD8D1DB35478D6F9E4E0550041F3",
    "03_counterexamples/P3Counterexamples/P3ASuite.lean": "B647C78578277E07DC3B774E6EF5DFA5FE36935F4867AC14DC1861EEFCD6F327",
    "04_proof_obligations/P3ProofObligations.lean": "505E822FA9B27E79319D744F14825FDCF544FF27EB83DCEA52F8F9C72CBC55C3",
    "04_proof_obligations/P3ProofObligations/PO_C1_P3A_LexicalAndBNF.lean": "12C488A4E6AD9E989406692A43A2A01DE4475BC03859223B62233A5984F0F5E8",
    "05_independent_tribunal/P3ATribunalAudit.lean": "05CBF76C7F4F6BF0E4E88AEB2B14E1C92704169E6D47107689FBFC847254D086",
    "05_independent_tribunal/differential_oracle_p3a.py": "3513A3125DC504E66768D7E58C2445292AEFE2CE061AAD80A1B6D35FEE7F5B8C"
  },
  "compiled_artifact_sha256": {
    "P3FormalSpec/StrictLexicalSpec.olean": "49174CE8140008CFA351E7AB19ED1E30513BCA46DF3E1306B6C1F19CBF59A059",
    "P3FormalSpec/FrozenBNF.olean": "BCED6CF88006BC84E43C853A52EA249526575D91F8F52ECBF50AF77DD032476C",
    "P3FormalSpec/P2CorrespondenceAudit.olean": "1233D5AC2A55C861976C593284A1E682EB3F8F004B933F46D08A861EB0868A79",
    "P3FormalSpec.olean": "D3C231DD8C494C8EE6D5A3E961355AF03C7194DB3D3FC689B1A406BB3EBBB8F2",
    "P3DetachedChecker/StrictLexicalGate.olean": "A48B7627B5E9856AED2FB00F806C35A3FD358E82B08963EBB7C936112FF2C91D",
    "P3DetachedChecker.olean": "B15ABF958E5D6D327FBF6F1C920F17C188F2D1F0524DA0DC5A24A8C491E34EBC",
    "P3Counterexamples/P3ASuite.olean": "5EE18ED7170EFE14DED8D0201281E80121994865CAD8549022BB9D275502737B",
    "P3Counterexamples.olean": "AF8000BD02CE8A8B4F7E0EEDD2141544D768361A2C6C1D03E11AD2C2BC67FFAA",
    "P3ProofObligations/PO_C1_P3A_LexicalAndBNF.olean": "DDD87627D296E09882D1ECAD27FC05102F83ACF9A07D0A641783B8E92D84DBDA",
    "P3ProofObligations.olean": "34E880957EB8DD1EFB21FA9662640EB4096210251107F049C159B00C6CB1CAE8",
    "P3ATribunalAudit.olean": "B6F69D800379460DEEC6FECCCAD0596B8C0C2392D861E8D287A4FB8D5E18FD09",
    "p3a_tribunal_runner.exe": "CC0E12AC08410D5398A0889391DD6121055CE7EE3DF545FB05734F9B18B9C2CD"
  },
  "prior_gate_immutability_verified": {
    "pneuma_workspace_file_count": 0,
    "frozen_reference_manifest_sha256": "2FA5C7EC0423A6D404EBBB681E2393B9041C7E02634EB71D4505405162D3C076",
    "auth_c1_dir_receipt_sha256": "036E6543AD43365F9B914259840E0508F920FE24F56AAD45824639B7F480620E",
    "auth_c1_p1_receipt_sha256": "EC53292AD346D0FD17393C00F0DE5AD0832CEB48B09CE2D298A97B8101C5CDAB",
    "auth_c1_p2_receipt_sha256": "5D9BFCD3B3F029AF1B338CB47AC0445FB8707437898B9777A6C771BD40029F3E",
    "p1_sources_unchanged": "13/13",
    "p2_sources_unchanged": "14/14",
    "broca_shared_anchors_unchanged": "6/6"
  },
  "verbatim_logs": {
    "lake_build_and_print_axioms": "ℹ [26/28] Built P3ATribunalAudit (981ms)\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:21:0: 'BrocaOmega.P3A.ProofObligations.P3A_FrozenBNF_Acyclic' depends on axioms: [propext]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:22:0: 'BrocaOmega.P3A.ProofObligations.P3A_All21CanonicalRulesCovered' depends on axioms: [propext]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:23:0: 'BrocaOmega.P3A.ProofObligations.P3A_TrapPartitionSound' depends on axioms: [propext]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:24:0: 'BrocaOmega.P3A.ProofObligations.P3A_GeneratorBNF_Matches_P2' does not depend on any axioms\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:25:0: 'BrocaOmega.P3A.ProofObligations.P3A_P2_Excludes_Traps' does not depend on any axioms\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:26:0: 'BrocaOmega.P3A.ProofObligations.P3A_RuleReadingGate_Sound' depends on axioms: [propext]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:27:0: 'BrocaOmega.P3A.ProofObligations.P3A_StrictAsciiIngress_Sound' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:28:0: 'BrocaOmega.P3A.ProofObligations.P3A_CanonicalDecimal_Sound' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:29:0: 'BrocaOmega.P3A.ProofObligations.P3A_CanonicalDecimal_Complete' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:30:0: 'BrocaOmega.P3A.ProofObligations.P3A_RejectsMultiDot' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:31:0: 'BrocaOmega.P3A.ProofObligations.P3A_RejectsTrailingDot' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:32:0: 'BrocaOmega.P3A.ProofObligations.P3A_StrictLexicalSlot_Sound' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:33:0: 'BrocaOmega.P3A.ProofObligations.P3A_StrictLexicalSlot_Complete' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P3ATribunalAudit.lean:34:0: 'BrocaOmega.P3A.ProofObligations.P3A_All32CounterexamplePairs_Verified' depends on axioms: [propext, Classical.choice, Quot.sound]\n✔ [27/28] Built P3ATribunalAudit:c.o (460ms)\n✔ [28/28] Built p3a_tribunal_runner:exe (492ms)\nBuild completed successfully (28 jobs).",
    "p3a_tribunal_runner": "==========================================================================\nBROCA-NATIVE OMEGA — AUTH-C1-P3-A STRICT LEXICAL & FROZEN BNF VERIFICATION\nScope     : Independent Frozen BNF + Strict Lexical Gate (P3-A ONLY)\nToolchain : Lean 4.33.1 Core (Init only, 0 external deps, 0 sorry)\n==========================================================================\n[PASS] PC-P3A-01 (PAIR-01-MULTI-DOT-1) => ACCEPTED\n[PASS] CE-P3A-01 (PAIR-01-MULTI-DOT-1) => REJECTED (multipleDecimalPoints)\n[PASS] PC-P3A-02 (PAIR-02-MULTI-DOT-2) => ACCEPTED\n[PASS] CE-P3A-02 (PAIR-02-MULTI-DOT-2) => REJECTED (multipleDecimalPoints)\n[PASS] PC-P3A-03 (PAIR-03-NEG-ZERO) => ACCEPTED\n[PASS] CE-P3A-03 (PAIR-03-NEG-ZERO) => REJECTED (negativeZeroForbidden)\n[PASS] PC-P3A-04 (PAIR-04-TRAILING-DOT) => ACCEPTED\n[PASS] CE-P3A-04 (PAIR-04-TRAILING-DOT) => REJECTED (trailingDecimalPoint)\n[PASS] PC-P3A-05 (PAIR-05-LEADING-DOT) => ACCEPTED\n[PASS] CE-P3A-05 (PAIR-05-LEADING-DOT) => REJECTED (leadingDecimalPoint)\n[PASS] PC-P3A-06 (PAIR-06-EXPLICIT-PLUS) => ACCEPTED\n[PASS] CE-P3A-06 (PAIR-06-EXPLICIT-PLUS) => REJECTED (explicitPlusForbidden)\n[PASS] PC-P3A-07 (PAIR-07-LEADING-ZERO) => ACCEPTED\n[PASS] CE-P3A-07 (PAIR-07-LEADING-ZERO) => REJECTED (redundantLeadingZero)\n[PASS] PC-P3A-08 (PAIR-08-EXPONENT) => ACCEPTED\n[PASS] CE-P3A-08 (PAIR-08-EXPONENT) => REJECTED (invalidNumericCharOrExponent)\n[PASS] PC-P3A-09 (PAIR-09-PRECISION-CAP) => ACCEPTED\n[PASS] CE-P3A-09 (PAIR-09-PRECISION-CAP) => REJECTED (numericPrecisionBoundExceeded)\n[PASS] PC-P3A-10 (PAIR-10-NUMERIC-ID-BIND) => ACCEPTED\n[PASS] CE-P3A-10 (PAIR-10-NUMERIC-ID-BIND) => REJECTED (numericEntityIdMismatch)\n[PASS] PC-P3A-11 (PAIR-11-WRONG-ENTITY-ID) => ACCEPTED\n[PASS] CE-P3A-11 (PAIR-11-WRONG-ENTITY-ID) => REJECTED (entityCatalogMismatch)\n[PASS] PC-P3A-12 (PAIR-12-WRONG-SLOT-SORT) => ACCEPTED\n[PASS] CE-P3A-12 (PAIR-12-WRONG-SLOT-SORT) => REJECTED (entityCatalogMismatch)\n[PASS] PC-P3A-13 (PAIR-13-KEYWORD-LEAK) => ACCEPTED\n[PASS] CE-P3A-13 (PAIR-13-KEYWORD-LEAK) => REJECTED (reservedKeywordLeak)\n[PASS] PC-P3A-14 (PAIR-14-UTF8-HOMOGLYPH) => ACCEPTED\n[PASS] CE-P3A-14 (PAIR-14-UTF8-HOMOGLYPH) => REJECTED (nonPrintableAsciiOrInvalidUtf8)\n[PASS] PC-P3A-15 (PAIR-15-CATALOG-INJECTIVITY) => ACCEPTED\n[PASS] CE-P3A-15 (PAIR-15-CATALOG-INJECTIVITY) => REJECTED (invalidEntityCatalog)\n[PASS] PC-P3A-16 (PAIR-16-TRAP-READING-ALT) => ACCEPTED\n[PASS] CE-P3A-16 (PAIR-16-TRAP-READING-ALT) => REJECTED (parserOnlyTrapRuleInGenerator)\n--------------------------------------------------------------------------\nSUMMARY: 32 / 32 symmetric (PC, CE) vectors verified.\nInherited HELD : P1_EXTERNAL_REPLAY_HELD, P2_EXTERNAL_REPLAY_HELD\nAudit Evidence : F-P2-01 & F-P2-02 submitted (HELD pending Tribunal ruling)\nNot Authorized : P1-C, P3-B, P3-C, P4, P5, Pneuma-S3/S4\n==========================================================================",
    "python_differential_oracle": "==========================================================================\nPYTHON 3.11 INDEPENDENT DIFFERENTIAL ORACLE — BROCA-NATIVE OMEGA P3-A\nRead-Only P2 Disk Snapshot Verification : 27 / 27 EXACT RULE MATCH\n==========================================================================\n[PARITY_OK] PC-P3A-01 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-01 | Lean=(False, multipleDecimalPoints) | Python=(False, multipleDecimalPoints)\n[PARITY_OK] PC-P3A-02 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-02 | Lean=(False, multipleDecimalPoints) | Python=(False, multipleDecimalPoints)\n[PARITY_OK] PC-P3A-03 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-03 | Lean=(False, negativeZeroForbidden) | Python=(False, negativeZeroForbidden)\n[PARITY_OK] PC-P3A-04 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-04 | Lean=(False, trailingDecimalPoint) | Python=(False, trailingDecimalPoint)\n[PARITY_OK] PC-P3A-05 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-05 | Lean=(False, leadingDecimalPoint) | Python=(False, leadingDecimalPoint)\n[PARITY_OK] PC-P3A-06 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-06 | Lean=(False, explicitPlusForbidden) | Python=(False, explicitPlusForbidden)\n[PARITY_OK] PC-P3A-07 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-07 | Lean=(False, redundantLeadingZero) | Python=(False, redundantLeadingZero)\n[PARITY_OK] PC-P3A-08 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-08 | Lean=(False, invalidNumericCharOrExponent) | Python=(False, invalidNumericCharOrExponent)\n[PARITY_OK] PC-P3A-09 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-09 | Lean=(False, numericPrecisionBoundExceeded) | Python=(False, numericPrecisionBoundExceeded)\n[PARITY_OK] PC-P3A-10 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-10 | Lean=(False, numericEntityIdMismatch) | Python=(False, numericEntityIdMismatch)\n[PARITY_OK] PC-P3A-11 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-11 | Lean=(False, entityCatalogMismatch) | Python=(False, entityCatalogMismatch)\n[PARITY_OK] PC-P3A-12 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-12 | Lean=(False, entityCatalogMismatch) | Python=(False, entityCatalogMismatch)\n[PARITY_OK] PC-P3A-13 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-13 | Lean=(False, reservedKeywordLeak) | Python=(False, reservedKeywordLeak)\n[PARITY_OK] PC-P3A-14 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-14 | Lean=(False, nonPrintableAsciiOrInvalidUtf8) | Python=(False, nonPrintableAsciiOrInvalidUtf8)\n[PARITY_OK] PC-P3A-15 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-15 | Lean=(False, invalidEntityCatalog) | Python=(False, invalidEntityCatalog)\n[PARITY_OK] PC-P3A-16 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P3A-16 | Lean=(False, parserOnlyTrapRuleInGenerator) | Python=(False, parserOnlyTrapRuleInGenerator)\n--------------------------------------------------------------------------\nFixed Curated Lean <-> Python Parity     : 32 / 32 EXACT MATCH\nExternal Batch Lean <-> Python Parity    : 300 / 300 EXACT MATCH (seed=2026112203)\nLean Adversarial Mutation Rejections     : 240 / 240\nPython Adversarial Mutation Rejections   : 240 / 240\nValid Boundary Mutation Acceptances      : Lean=60/60, Python=60/60\nP2 GrammarG16.lean Disk Snapshot Match   : 27 / 27\n=========================================================================="
  },
  "scope_and_held_locks": {
    "p3a_independent_bnf_and_strict_lexical_mechanized": true,
    "p3a_external_independent_kernel_replay_held": true,
    "p1_external_replay_held": true,
    "p2_external_replay_held": true,
    "f_p2_01_frozen_grammar_equivalence_held_pending_tribunal": true,
    "f_p2_02_lexical_and_entity_binding_held_pending_tribunal": true,
    "r0_g01_right_censored_surface_unspecified_held": true,
    "r0_production_ontology_entries_unspecified_held": true,
    "p1_c_int128_fast_path_authorized": false,
    "p3_b_bounded_parser_po_c1_01_authorized": false,
    "p3_c_semantic_norm_po_c1_03_authorized": false,
    "p4_clinical_evidence_authorized": false,
    "p5_snapshot_admission_authorized": false,
    "pneuma_s3_s4_integration_authorized": false,
    "master_soundness_proven": false,
    "ancestors_or_p1_or_p2_modified": false
  }
}
```

---

## 6. Verbatim `P3_LexicalGrammar` Source Files (100% Unmodified)

### 6.1 `lean-toolchain` (`SHA-256: 3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71`)
```text
leanprover/lean4:v4.33.1
```

### 6.2 `lakefile.toml` (`SHA-256: A6A7C6A75BE4F482AA7EB1390688C820F733634D21658A9FCDF2F866DD4A6B3F`)
```toml
name = "broca_omega_gate_c1_p3a"
version = "0.1.0"
defaultTargets = ["P3FormalSpec", "P3DetachedChecker", "P3Counterexamples", "P3ProofObligations", "p3a_tribunal_runner"]

[[lean_lib]]
name = "P3FormalSpec"
srcDir = "01_formal_spec"

[[lean_lib]]
name = "P3DetachedChecker"
srcDir = "02_detached_checker"

[[lean_lib]]
name = "P3Counterexamples"
srcDir = "03_counterexamples"

[[lean_lib]]
name = "P3ProofObligations"
srcDir = "04_proof_obligations"

[[lean_exe]]
name = "p3a_tribunal_runner"
srcDir = "05_independent_tribunal"
root = "P3ATribunalAudit"
```

### 6.3 `01_formal_spec/P3FormalSpec.lean` (`SHA-256: 2621B972EDA1434B1277572C950192F972DF36EBE24DA5D42525ADC2FC7332C1`)
```lean
import P3FormalSpec.StrictLexicalSpec
import P3FormalSpec.FrozenBNF
import P3FormalSpec.P2CorrespondenceAudit
```

### 6.4 `01_formal_spec/P3FormalSpec/StrictLexicalSpec.lean` (`SHA-256: 9A4DF89ADAE2981AAA636FDB75F223451ED1199201643EA7D87349FEBBE4E582`)
```lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: Strict Lexical Gate & Independent BNF)
  01_formal_spec/P3FormalSpec/StrictLexicalSpec.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  Defines the algorithm-independent declarative specifications (`Prop`) for Gate B & Gate C:
    1. Raw UTF-8 & Strict 7-bit Printable ASCII Profile (`Gate C0-R1` §I.3 `F-C0-03`)
    2. Canonical Decimal Surface Grammar (`S0-R2.2` §II.1 + `Gate C0-R1` §II.1 `F-C0-01`)
       with exact structural decomposition & round-trip rendering uniqueness
    3. Closed Entity Catalog (`S0-R2.2` §II.2 + `Gate C0` `F-R2.2-02` Global Surface Injectivity)
       and Syncategorematic Reserved-Keyword Disjointness (`S0-R2.1` §I.1)
    4. Slot-relative conjunction `LexicallyValid ∧ NumericallyWellFormed ∧ EntityCatalogBound`
-/

namespace BrocaOmega.P3A

/-! ### 1. Typed Slot Categories Across Frozen `G-01` ~ `G-16` and `T1` ~ `T5` -/

/--
  Complete closed enumeration of lexical slot categories in `Architecture Freeze R0`
  (`G-01`~`G-16` generator slots + `T3` trap-only `epistemicVerb` and `whWord` slots).
-/
inductive P3SlotSort where
  -- Open domain entity/phrase slots (must be bound in `ClosedEntityCatalog`):
  | cohortSpec
  | designNoun
  | followUpWindow
  | eventTerm
  | measureTerm
  | expLevel
  | outTerm
  | sourceId
  | identAssump
  | subgroupPlural
  | subgroupSingular
  | covariateList
  -- Closed functional lexicon slots (fixed finite R0 tables):
  | assocDir         -- "positively" | "inversely"
  | ratioMetric      -- "risk ratio" | "odds ratio" | "hazard ratio"
  | intervDirVerb    -- "increase" | "reduce"
  | intervVerbPres   -- "causes" | "increases" | "reduces"
  | epistemicVerb    -- T3 trap verb: "establish" | "determine" | "confirm" | "reveal"
  | whWord           -- T3 trap wh-complementizer: "why" | "how"
  -- Numeric literal slot (validated by Canonical Decimal Surface Grammar):
  | numericLit
  deriving DecidableEq, Repr

/-- Classifies how a `P3SlotSort` is lexically governed in `Architecture Freeze R0`. -/
inductive SlotRegime where
  | openEntityCatalog
  | closedFunctionalEnum
  | canonicalDecimal
  deriving DecidableEq, Repr

def P3SlotSort.regime : P3SlotSort → SlotRegime
  | .cohortSpec       => .openEntityCatalog
  | .designNoun       => .openEntityCatalog
  | .followUpWindow   => .openEntityCatalog
  | .eventTerm        => .openEntityCatalog
  | .measureTerm      => .openEntityCatalog
  | .expLevel         => .openEntityCatalog
  | .outTerm          => .openEntityCatalog
  | .sourceId         => .openEntityCatalog
  | .identAssump      => .openEntityCatalog
  | .subgroupPlural   => .openEntityCatalog
  | .subgroupSingular => .openEntityCatalog
  | .covariateList    => .openEntityCatalog
  | .assocDir         => .closedFunctionalEnum
  | .ratioMetric      => .closedFunctionalEnum
  | .intervDirVerb    => .closedFunctionalEnum
  | .intervVerbPres   => .closedFunctionalEnum
  | .epistemicVerb    => .closedFunctionalEnum
  | .whWord           => .closedFunctionalEnum
  | .numericLit       => .canonicalDecimal

/-! ### 2. Raw UTF-8 & Strict 7-Bit Printable ASCII Ingress Profile (`F-C0-03`) -/

/-- Printable 7-bit ASCII byte (`0x20 .. 0x7E`, excluding control chars, tabs, newlines, and `>= 0x80`). -/
def IsPrintableAsciiByte (b : UInt8) : Prop :=
  (0x20 : UInt8) ≤ b ∧ b ≤ (0x7E : UInt8)

/-- Pure byte-to-ASCII-Char conversion (total on `[0x20, 0x7E]`). -/
def asciiByteToChar (b : UInt8) : Char :=
  Char.ofNat b.toNat

def decodeAsciiBytes (bs : List UInt8) : String :=
  String.ofList (bs.map asciiByteToChar)

/--
  Declarative Ingress Profile (`Gate C0-R1` §I.3 `StrictProfileNFC` for English `D_0`):
  1. Non-empty byte sequence within resource cap `maxBytes`.
  2. Every byte is in printable 7-bit ASCII `[0x20, 0x7E]`.
     Note: Because every byte is `< 0x80`, the sequence is guaranteed valid single-byte UTF-8,
     contains zero surrogates or overlong sequences, contains zero Unicode combining marks
     (hence trivially in Unicode NFC with `verifiedBytes = rawBytes`), and eliminates Cyrillic/Greek homoglyphs.
-/
def StrictAsciiUTF8Valid (maxBytes : Nat) (rawBytes : List UInt8) : Prop :=
  0 < rawBytes.length ∧
  rawBytes.length ≤ maxBytes ∧
  ∀ b ∈ rawBytes, IsPrintableAsciiByte b

/-! ### 3. Reserved Syncategorematic Structural Barrier (`S0-R2.1` §I.1) -/

/--
  Declarative contiguous sublist relation (`needle` occurs as a contiguous slice of `haystack`).
-/
def IsContigSublist {α : Type} (needle haystack : List α) : Prop :=
  ∃ pre post : List α, haystack = pre ++ needle ++ post

/--
  Reserved syncategorematic delimiters & clause markers from `S0-R2.1` §I.1 and `P0-A05`.
  Forbidden as contiguous substrings inside any open entity catalog lexeme so clause and slot
  boundaries cannot be forged or spoofed.
-/
def reservedStructuralDelimiters : List String :=
  [ ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same",
    "In ", " why ", " how " ]

def DisjointFromReservedDelimiters (s : String) : Prop :=
  ∀ bad ∈ reservedStructuralDelimiters, ¬ IsContigSublist bad.toList s.toList

/-- Leading/trailing space hygiene for slot lexemes (prevents boundary token fusion). -/
def HasTrimmedOuterSpaces (cs : List Char) : Prop :=
  cs ≠ [] ∧ cs.head? ≠ some ' ' ∧ cs.getLast? ≠ some ' '

/-! ### 4. Canonical Decimal Surface Grammar (`S0-R2.2` §II.1 + `F-C0-01`) -/

/--
  Explicit digit-length policy configuration (`S0-R2.2` line 36 `[0-9]{1,7}(\.[0-9]{1,4})?`
  vs `Gate C1-P0` `d <= 8`). Parameterizing `NumericGateConfig` avoids hardcoding unverified
  constants while defaulting to the frozen `S0-R2.2` `(7, 4)` profile.
-/
structure NumericGateConfig where
  maxIntDigits  : Nat
  maxFracDigits : Nat
  deriving DecidableEq, Repr

/-- Frozen `S0-R2.2` §II.1 line 36 profile (`1..7` integer digits, `1..4` fractional digits). -/
def frozenR22NumericConfig : NumericGateConfig :=
  { maxIntDigits := 7, maxFracDigits := 4 }

def IsAsciiDigitChar (c : Char) : Prop :=
  '0'.toNat ≤ c.toNat ∧ c.toNat ≤ '9'.toNat

/-- Base-10 natural value of a list of ASCII digit characters (big-endian). -/
def digitsToNat : List Char → Nat
  | [] => 0
  | c :: cs =>
    let acc := c.toNat - '0'.toNat
    cs.foldl (fun n d => n * 10 + (d.toNat - '0'.toNat)) acc

/-- Exact parsed decimal surface token (bridging raw ASCII surface to `(mantissa : Int, scale10 : Nat)`). -/
structure ParsedDecLit where
  neg        : Bool
  intDigits  : List Char
  fracDigits : List Char
  deriving DecidableEq, Repr

/-- Canonical surface rendering of a `ParsedDecLit` (used to prove exact round-trip identity!). -/
def ParsedDecLit.renderChars (d : ParsedDecLit) : List Char :=
  (if d.neg then ['-'] else []) ++
  d.intDigits ++
  (if d.fracDigits.isEmpty then [] else '.' :: d.fracDigits)

def ParsedDecLit.render (d : ParsedDecLit) : String :=
  String.ofList d.renderChars

/-- Exact unrounded mathematical `(mantissa, scale10)` projection compatible with `P1` `DecLit`. -/
def ParsedDecLit.absMantissaNat (d : ParsedDecLit) : Nat :=
  digitsToNat (d.intDigits ++ d.fracDigits)

def ParsedDecLit.mantissaInt (d : ParsedDecLit) : Int :=
  if d.neg then - (Int.ofNat d.absMantissaNat) else Int.ofNat d.absMantissaNat

def ParsedDecLit.scale10 (d : ParsedDecLit) : Nat :=
  d.fracDigits.length

/--
  **Declarative Canonical Decimal Surface Specification (`DecSurfaceSpec`)**:
  A string `s` is a valid canonical decimal literal with decomposition `d : ParsedDecLit` iff:
  1. `d.renderChars = s.toList` (exact character-by-character structural round-trip:
     at most one `'.'`, optional leading `'-'`, NO `'+'`, NO `'e'`/`'E'`, NO trailing `'.'` like `"1."`,
     and NO leading `'.'` like `".25"` because `intDigits` is non-empty and `'.'` only appears when
     `fracDigits` is non-empty!).
  2. `1 ≤ d.intDigits.length ≤ cfg.maxIntDigits`, all ASCII digits `'0'..'9'`.
  3. Canonical integer leading-zero rule: if `1 < d.intDigits.length`, the leading digit is NOT `'0'`
     (rejects `"00"`, `"001.25"`, `"-00.5"`, while allowing `"0"` and `"0.25"`).
  4. `d.fracDigits.length ≤ cfg.maxFracDigits`, all ASCII digits `'0'..'9'`.
  5. Canonical zero sign rule (`F-C0-01` negative-zero ban): if all integer and fractional digits
     are `'0'` (`d.absMantissaNat = 0`), then `d.neg = false` (rejects `"-0"`, `"-0.0"`, `"-0.00"`).
-/
def DecSurfaceSpec (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit) : Prop :=
  d.renderChars = s.toList ∧
  1 ≤ d.intDigits.length ∧
  d.intDigits.length ≤ cfg.maxIntDigits ∧
  (∀ c ∈ d.intDigits, IsAsciiDigitChar c) ∧
  (1 < d.intDigits.length → d.intDigits.head? ≠ some '0') ∧
  d.fracDigits.length ≤ cfg.maxFracDigits ∧
  (∀ c ∈ d.fracDigits, IsAsciiDigitChar c) ∧
  (d.absMantissaNat = 0 → d.neg = false)

/-! ### 5. Closed Functional Lexicon & Closed Entity Catalog (`F-R2.2-02`) -/

/-- Canonical `(sort, entityId, lexeme)` triples for closed functional slots in `R0`. -/
def closedFunctionalEntries : List (P3SlotSort × String × String) :=
  [ (.assocDir,       "positively",   "positively"),
    (.assocDir,       "inversely",    "inversely"),
    (.ratioMetric,    "rr",           "risk ratio"),
    (.ratioMetric,    "or",           "odds ratio"),
    (.ratioMetric,    "hr",           "hazard ratio"),
    (.intervDirVerb,  "increase",     "increase"),
    (.intervDirVerb,  "reduce",       "reduce"),
    (.intervVerbPres, "causes",       "causes"),
    (.intervVerbPres, "increases",    "increases"),
    (.intervVerbPres, "reduces",      "reduces"),
    (.epistemicVerb,  "establish",    "establish"),
    (.epistemicVerb,  "determine",    "determine"),
    (.epistemicVerb,  "confirm",      "confirm"),
    (.epistemicVerb,  "reveal",       "reveal"),
    (.whWord,         "why",          "why"),
    (.whWord,         "how",          "how") ]

/-- Single entry in a `ClosedEntityCatalog`. -/
structure CatalogEntry where
  sort     : P3SlotSort
  entityId : String
  lexeme   : String
  deriving DecidableEq, Repr

/--
  Closed Entity Catalog (`OntologyLexicon` in `Gate C0-R1`).
  Note (`Gate C1-P0` Task P0-01): Production clinical ontology entries are `UNSPECIFIED_IN_R0`,
  so the gate takes `ClosedEntityCatalog` explicitly and verifies all `R0` structural/injectivity
  invariants (`ValidEntityCatalog`) before admitting any open-entity binding!
-/
structure ClosedEntityCatalog where
  entries : List CatalogEntry
  deriving DecidableEq, Repr

/--
  Declarative Well-Formedness of a `ClosedEntityCatalog` (`S0-R2.1` + `S0-R2.2` + `F-R2.2-02`):
  1. Every entry belongs to an `.openEntityCatalog` sort.
  2. Both `entityId` and `lexeme` are non-empty printable ASCII with trimmed outer spaces.
  3. Every `lexeme` is disjoint from `reservedStructuralDelimiters`.
  4. Unique `(sort, entityId)` key: an `entityId` within a sort maps to at most one `lexeme`.
  5. **Global Canonical Surface Injectivity (`F-R2.2-02`)**: distinct entries NEVER share the same
     `lexeme`, even across different `P3SlotSort`s (`e₁.lexeme = e₂.lexeme → e₁ = e₂`).
-/
def ValidEntityCatalog (cat : ClosedEntityCatalog) : Prop :=
  (∀ e ∈ cat.entries,
    e.sort.regime = .openEntityCatalog ∧
    0 < e.entityId.toList.length ∧
    (∀ c ∈ e.entityId.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
    HasTrimmedOuterSpaces e.lexeme.toList ∧
    (∀ c ∈ e.lexeme.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
    DisjointFromReservedDelimiters e.lexeme) ∧
  (∀ e₁ ∈ cat.entries, ∀ e₂ ∈ cat.entries,
    e₁.sort = e₂.sort → e₁.entityId = e₂.entityId → e₁.lexeme = e₂.lexeme) ∧
  (∀ e₁ ∈ cat.entries, ∀ e₂ ∈ cat.entries,
    e₁.lexeme = e₂.lexeme → e₁ = e₂)

/-! ### 6. Untrusted Raw Slot Candidate & Declarative Target Predicates (`Gate IV`) -/

/-- Untrusted raw lexical slot candidate submitted to the Strict Lexical Gate. -/
structure RawSlotCandidate where
  sort     : P3SlotSort
  entityId : String
  rawBytes : List UInt8
  deriving DecidableEq, Repr

def RawSlotCandidate.decodedStr (cand : RawSlotCandidate) : String :=
  decodeAsciiBytes cand.rawBytes

/--
  1. `LexicallyValid`:
     Raw bytes pass `StrictAsciiUTF8Valid`, `entityId` is non-empty printable ASCII, outer spaces
     are trimmed, and if `cand.sort` is an open-entity sort, `decodedStr` contains zero reserved
     syncategorematic delimiters.
-/
def LexicallyValid (maxBytes : Nat) (cand : RawSlotCandidate) : Prop :=
  StrictAsciiUTF8Valid maxBytes cand.rawBytes ∧
  0 < cand.entityId.toList.length ∧
  (∀ c ∈ cand.entityId.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
  HasTrimmedOuterSpaces cand.decodedStr.toList ∧
  (cand.sort.regime = .openEntityCatalog → DisjointFromReservedDelimiters cand.decodedStr)

/--
  2. `NumericallyWellFormed` (Slot-Relative per Mandate §IV):
     Applies iff `cand.sort = .numericLit`: there exists a unique canonical `ParsedDecLit`
     satisfying `DecSurfaceSpec numCfg cand.decodedStr d`, and `cand.entityId` equals the
     canonical surface string `cand.decodedStr`.
-/
def NumericallyWellFormed (numCfg : NumericGateConfig) (cand : RawSlotCandidate) : Prop :=
  cand.sort = .numericLit →
    cand.entityId = cand.decodedStr ∧
    ∃ d : ParsedDecLit, DecSurfaceSpec numCfg cand.decodedStr d

/--
  3. `EntityCatalogBound` (Slot-Relative per Mandate §IV):
     - For `.openEntityCatalog` sorts: the catalog itself satisfies `ValidEntityCatalog cat` AND
       `⟨cand.sort, cand.entityId, cand.decodedStr⟩ ∈ cat.entries`.
     - For `.closedFunctionalEnum` sorts: `(cand.sort, cand.entityId, cand.decodedStr) ∈ closedFunctionalEntries`.
     - For `.canonicalDecimal` (`.numericLit`): vacuous (`True`), governed by `NumericallyWellFormed`.
-/
def EntityCatalogBound (cat : ClosedEntityCatalog) (cand : RawSlotCandidate) : Prop :=
  match cand.sort.regime with
  | .openEntityCatalog =>
    ValidEntityCatalog cat ∧
    CatalogEntry.mk cand.sort cand.entityId cand.decodedStr ∈ cat.entries
  | .closedFunctionalEnum =>
    (cand.sort, cand.entityId, cand.decodedStr) ∈ closedFunctionalEntries
  | .canonicalDecimal =>
    True

end BrocaOmega.P3A
```

### 6.5 `01_formal_spec/P3FormalSpec/FrozenBNF.lean` (`SHA-256: C0E664F2EBB66A4D070002A83D82A3BF5F9CB3721000FDEF009B50AFBCE5808C`)
```lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: Independent Frozen BNF Specification)
  01_formal_spec/P3FormalSpec/FrozenBNF.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  Gate A Deliverable:
  Extracted DIRECTLY from the read-only frozen specification lineage:
    - `S0-R2` (§III: 16 generator rules `G-01`~`G-16` + 5 trap rules `T1`~`T5`)
    - `S0-R2.1` (§II.1~2: DAG stratification, `ExpContrast`, `MeanSD`/`MedianIQR`, TOST CI)
    - `S0-R2.2` (§II.4: `sentence_atomic` vs `discourse_bound` `G-15`, `G-06` estimation modality)
    - `Gate C0-R1` / `Architecture Freeze R0` (§II.3: `G-06a` directional vs `G-06b` neutral)
    - `Gate C1-P0` (`P0-A05`: `21` canonical rule IDs, `readingAlt` semantic index `1..altCount`,
      `T1`~`T5` canonical slot productions, and explicit `UNSPECIFIED_IN_R0` ledger)

  CRITICAL NON-CIRCULARITY GUARANTEE:
  This module does NOT import, copy, or reverse-engineer `P2`'s `ruleSignature`.
-/
import P3FormalSpec.StrictLexicalSpec

namespace BrocaOmega.P3A

/-! ### 1. Canonical 21 Rule Families (`G-01`~`G-16` Generator vs `T1`~`T5` Parser-Only Traps) -/

/--
  Exact 21-member rule ID set frozen in `Gate C1-P0` (`P0-A05` §1.B):
  `16` canonical generator families (`G01`..`G16`) + `5` adversarial parser-only trap rules (`T1`..`T5`).
-/
inductive CanonicalRuleId where
  | G01 | G02 | G03 | G04 | G05 | G06 | G07 | G08
  | G09 | G10 | G11 | G12 | G13 | G14 | G15 | G16
  | T1  | T2  | T3  | T4  | T5
  deriving DecidableEq, Repr

/-- Generator membership (`G_gen ⊂ G_parse`): `true` iff `r ∈ {G01 .. G16}`. -/
def CanonicalRuleId.isGeneratorRule : CanonicalRuleId → Bool
  | .T1 | .T2 | .T3 | .T4 | .T5 => false
  | _ => true

/-- Trap membership (`G_trap = G_parse \ G_gen`): `true` iff `r ∈ {T1 .. T5}`. -/
def CanonicalRuleId.isParserOnlyTrap (r : CanonicalRuleId) : Bool :=
  !r.isGeneratorRule

/--
  Semantic reading multiplicity `altCount(ruleId)` frozen in `S0-R2` & `Gate C1-P0` (`P0-A05` §1.B):
  - `G01`..`G16` have `1` canonical reading.
  - `T1` (`all ... not`), `T2` (`did not confirm that`), and `T4` (bare plural) have `2` readings.
  - `T3` (`why/how` presupposition) and `T5` (unscoped clause) have `1` trap reading.
  `readingAlt` is a semantic reading index `1 .. altCount(ruleId)`, NOT a separate syntax rule!
-/
def CanonicalRuleId.readingAltCount : CanonicalRuleId → Nat
  | .T1 => 2
  | .T2 => 2
  | .T4 => 2
  | _   => 1

/-- Declarative validity of a `(ruleId, readingAlt)` pair (`P0-A05` §1.B). -/
def ValidReadingSelection (r : CanonicalRuleId) (readingAlt : Nat) : Prop :=
  1 ≤ readingAlt ∧ readingAlt ≤ r.readingAltCount

def checkReadingSelectionBool (r : CanonicalRuleId) (readingAlt : Nat) : Bool :=
  (1 ≤ readingAlt) && (readingAlt ≤ r.readingAltCount)

theorem checkReadingSelectionBool_iff (r : CanonicalRuleId) (readingAlt : Nat) :
    checkReadingSelectionBool r readingAlt = true ↔ ValidReadingSelection r readingAlt := by
  unfold checkReadingSelectionBool ValidReadingSelection
  simp [Bool.and_eq_true]

theorem all_generator_rules_unique_reading (r : CanonicalRuleId)
    (hgen : r.isGeneratorRule = true) :
    r.readingAltCount = 1 := by
  cases r <;> simp [CanonicalRuleId.isGeneratorRule] at hgen <;> rfl

/-! ### 2. Acyclic Nonterminal Hierarchy of `G_parse` (`S0-R2.1` §II.1 + `P0-A05` §2) -/

inductive BNFNonterm where
  | embeddedCausal      -- Level 0: `<ExpLevel> " " <IntervVerbPres> " " <OutTerm>`
  | assocCore           -- Level 1: `G-03`, `G-04`, `G-14`
  | metaNonEstabCore    -- Level 1: `G-09`
  | atomicCore          -- Level 2: `G-01`~`G-14` single-clause cores
  | trapCore            -- Level 2: `T1`~`T4` scoped trap cores
  | scopedInitial       -- Level 3: `"In " <CohortSpec> ", " <AtomicCore>`
  | scopedRepeat        -- Level 3: `"Within this same " <DesignNoun> ", " <AtomicCore>`
  | scopedAssoc         -- Level 3: `"In " <CohortSpec> ", " <AssocCore>`
  | scopedContrastMeta  -- Level 3: `"within this same " <DesignNoun> ", " <MetaNonEstabCore>`
  | scopedTrapClause    -- Level 3: `"In " <CohortSpec> ", " <TrapCore>`
  | controlledDocument  -- Level 4: Root `ControlledDocument` (`G_gen` docs + `T1`~`T5` trap docs)
  deriving DecidableEq, Repr

def BNFNonterm.level : BNFNonterm → Nat
  | .embeddedCausal     => 0
  | .assocCore          => 1
  | .metaNonEstabCore   => 1
  | .atomicCore         => 2
  | .trapCore           => 2
  | .scopedInitial      => 3
  | .scopedRepeat       => 3
  | .scopedAssoc        => 3
  | .scopedContrastMeta => 3
  | .scopedTrapClause   => 3
  | .controlledDocument => 4

/-! ### 3. Independent BNF Symbols, Side-Condition Tags & Provenance Status -/

/-- Typed slot occurrence in a BNF RHS (carries semantic positional tag + lexical `P3SlotSort`). -/
inductive BNFSlotTag where
  | cohort
  | design
  | window
  | eventA
  | eventB
  | measure
  | activeExp
  | refExp
  | outcome
  | source
  | assumption
  | subgroup
  | covariates
  | direction
  | metric1
  | metric2
  | verb
  | whComp
  | numK
  | numN
  | numPct
  | numEst
  | numDisp1
  | numDisp2
  | numCILevel
  | numCILow
  | numCIHigh
  | numPVal
  | numAlpha
  | numMarginLow
  | numMarginHigh
  deriving DecidableEq, Repr

/-- Right-hand-side BNF symbol (terminal literal, typed slot, or child nonterminal). -/
inductive BNFSymbol where
  | term    (lit : String)
  | lexSlot (sort : P3SlotSort) (tag : BNFSlotTag)
  | nonterm (nt : BNFNonterm) (clauseIdx : Nat) -- 0 = inherited, 1 = s₁, 2 = s₂
  deriving DecidableEq, Repr

/-- Explicit side-condition obligations tracked in `S0-R2.1`, `S0-R2.2`, and `Gate C0-R1`. -/
inductive FrozenSideCond where
  | cohortMatchesEnv
  | designNounResolvesToCohort
  | distinctActiveAndRefLevels
  | distinctTemporalEvents
  | repeatedRatioMetricAgreement
  | sentenceAtomicBothCohortsMatch
  | discourseBoundCohortAndDesignMatch
  | contrastiveSharedExpOutPair
  | uncensoredFixedWindowComplete   -- G-01 uncensored 100*k/N precondition (`S0-R2.2` §II.4.3)
  | ciExcludesNullAndPBelowAlpha    -- G-06a precondition (`Gate C0-R1` §II.3)
  | ciIncludesNull                  -- G-06b precondition (`Gate C0-R1` §II.3)
  | concordantNonSigPAndCI          -- G-07 precondition (`S0-R2.2` §II.4.5)
  | tostCIInsidePrespecifiedMargins -- G-08 precondition (`S0-R2.1` §II.2.3)
  | unscopedClauseLacksInOrWithin   -- T5 trap precondition (`P0-A05` §2)
  deriving DecidableEq, Repr

/-- Explicit provenance fidelity classification against `Architecture Freeze R0`. -/
inductive R0ProvenanceStatus where
  | exactFrozenInR0
  | exactDependentSplitInR0
  | canonicalizedFromP0A05Reference  -- `T1`~`T5` slot completions fixed in `Gate C1-P0` `P0-A05`
  deriving DecidableEq, Repr

/-- Complete independent BNF production record with source traceability. -/
structure BNFProduction where
  prodId         : String
  canonicalOwner : Option CanonicalRuleId -- `none` for structural nonterminal wrappers
  isGenerator    : Bool
  lhs            : BNFNonterm
  rhs            : List BNFSymbol
  sideConds      : List FrozenSideCond
  sourceDoc      : String
  sourceSection  : String
  r0Status       : R0ProvenanceStatus
  deriving DecidableEq, Repr

/-! ### 4. Complete Independent Frozen BNF Table (`G-01`~`G-16` + Envelopes + `T1`~`T5`) -/

def independentFrozenBNF : List BNFProduction :=
  [ -- (A) Document & Clause Structural Wrappers (`S0-R2.1` §II.1 + `P0-A05` §2)
    { prodId := "ENV-DOC-SINGLE", canonicalOwner := none, isGenerator := true,
      lhs := .controlledDocument,
      rhs := [.nonterm .scopedInitial 1, .term "."],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 ControlledDocument (line 40)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-SCOPED-INITIAL", canonicalOwner := none, isGenerator := true,
      lhs := .scopedInitial,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .atomicCore 0],
      sideConds := [.cohortMatchesEnv],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 ScopedAtomic (line 45)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-SCOPED-REPEAT", canonicalOwner := none, isGenerator := true,
      lhs := .scopedRepeat,
      rhs := [.term "Within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .atomicCore 0],
      sideConds := [.designNounResolvesToCohort],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "§II.1 line 46 & §II.4.1 line 88",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-SCOPED-ASSOC", canonicalOwner := none, isGenerator := true,
      lhs := .scopedAssoc,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .assocCore 0],
      sideConds := [.cohortMatchesEnv],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 ScopedAssoc (line 47)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-SCOPED-CONTRAST-META", canonicalOwner := none, isGenerator := true,
      lhs := .scopedContrastMeta,
      rhs := [.term "within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .metaNonEstabCore 0],
      sideConds := [.designNounResolvesToCohort],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 RepeatScopedMeta (line 48)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-LIFT-ASSOC", canonicalOwner := none, isGenerator := true,
      lhs := .atomicCore,
      rhs := [.nonterm .assocCore 0],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 AtomicCore (lines 54, 55, 65)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-LIFT-META", canonicalOwner := none, isGenerator := true,
      lhs := .atomicCore,
      rhs := [.nonterm .metaNonEstabCore 0],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 AtomicCore (line 60)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-EMBEDDED-CAUSAL", canonicalOwner := none, isGenerator := true,
      lhs := .embeddedCausal,
      rhs := [.lexSlot .expLevel .activeExp, .term " ", .lexSlot .intervVerbPres .verb, .term " ", .lexSlot .outTerm .outcome],
      sideConds := [],
      sourceDoc := "S0-R2.1 / P0-A05", sourceSection := "S0-R2.1 §II.2.1 line 79 & P0-A05 §2 line 46",
      r0Status := .exactFrozenInR0 },

    -- (B) Canonical Generator Rules `G-01` ~ `G-16` (`G_gen`)
    { prodId := "G-01-UNCENSORED", canonicalOwner := some .G01, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "over ", .lexSlot .followUpWindow .window,
               .term ", the cumulative incidence of ", .lexSlot .eventTerm .eventA,
               .term " was ", .lexSlot .numericLit .numK,
               .term " of ", .lexSlot .numericLit .numN,
               .term " patients (", .lexSlot .numericLit .numPct, .term "%)" ],
      sideConds := [.uncensoredFixedWindowComplete],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "S0-R2.1 §II.2.2 line 84 & S0-R2.2 §II.4.3 line 92",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-02A-MEAN-SD", canonicalOwner := some .G02, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the mean ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (SD ", .lexSlot .numericLit .numDisp1, .term ")" ],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.2.2 DistSummarySpec MeanSD (line 87)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-02B-MEDIAN-IQR", canonicalOwner := some .G02, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the median ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (IQR ", .lexSlot .numericLit .numDisp1,
               .term " to ", .lexSlot .numericLit .numDisp2, .term ")" ],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.2.2 DistSummarySpec MedianIQR (line 88)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-03-ASSOC-UNADJ", canonicalOwner := some .G03, isGenerator := true,
      lhs := .assocCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-03 & S0-R2.1 §II.2.3 ExpContrast (line 91)",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-04-ASSOC-TEMP", canonicalOwner := some .G04, isGenerator := true,
      lhs := .assocCore,
      rhs := [ .lexSlot .eventTerm .eventA, .term " preceded ", .lexSlot .eventTerm .eventB,
               .term ", and comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctTemporalEvents, .distinctActiveAndRefLevels],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-04 & S0-R2.1 §III line 106",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-05-COMP-RD", canonicalOwner := some .G05, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the absolute risk difference in ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " percentage points (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-05 + S0-R2.1 §II.2.3 ExpContrast",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-06A-INTERV-DIRECTIONAL", canonicalOwner := some .G06, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was estimated to ", .lexSlot .intervDirVerb .verb,
               .term " ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ", p = ", .lexSlot .numericLit .numPVal, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels, .ciExcludesNullAndPBelowAlpha],
      sourceDoc := "Gate C0-R1", sourceSection := "§II.3 F-C0-07 G-06a (line 61)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-06B-INTERV-NEUTRAL", canonicalOwner := some .G06, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", the estimated causal ", .lexSlot .ratioMetric .metric1,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term "), which did not exclude no effect" ],
      sideConds := [.distinctActiveAndRefLevels, .ciIncludesNull],
      sourceDoc := "Gate C0-R1", sourceSection := "§II.3 F-C0-07 G-06b (line 62)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-07-META-NOT-STAT-SIG", canonicalOwner := some .G07, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the observed ", .lexSlot .ratioMetric .metric1,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric2,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ") was not statistically significant at alpha = ",
               .lexSlot .numericLit .numAlpha ],
      sideConds := [.repeatedRatioMetricAgreement, .distinctActiveAndRefLevels, .concordantNonSigPAndCI],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "S0-R2.1 §II.1 line 58 & S0-R2.2 §II.4.5 line 98",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-08-META-EQUIV", canonicalOwner := some .G08, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " met prespecified equivalence margins (",
               .lexSlot .numericLit .numMarginLow, .term " to ", .lexSlot .numericLit .numMarginHigh,
               .term ") for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% TOST CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels, .tostCIInsidePrespecifiedMargins],
      sourceDoc := "S0-R2.1", sourceSection := "§II.2.3 TOST Equivalence (line 95)",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-09-META-NON-ESTAB", canonicalOwner := some .G09, isGenerator := true,
      lhs := .metaNonEstabCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not establish that ", .nonterm .embeddedCausal 0 ],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 line 60 & §III line 109",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-10-META-UNRESOLVED", canonicalOwner := some .G10, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not determine whether ", .nonterm .embeddedCausal 0 ],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.2.1 F-R2-04 (line 79)",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-11-QUANT-ZERO", canonicalOwner := some .G11, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "no ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-11 (line 89) & S0-R2.1 line 62",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-12-QUANT-PROPER-PART", canonicalOwner := some .G12, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "some, but not all, ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-12 (line 90) & S0-R2.1 line 63",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-13-QUANT-AT-LEAST-ONE", canonicalOwner := some .G13, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "at least one ", .lexSlot .subgroupSingular .subgroup,
               .term " patient developed ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-13 (line 91) & S0-R2.1 line 64",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-14-ASSOC-ADJ", canonicalOwner := some .G14, isGenerator := true,
      lhs := .assocCore,
      rhs := [ .term "after adjustment for ", .lexSlot .covariateList .covariates,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-14 (line 92) & S0-R2.1 line 65",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-15A-DOC-CONJ-ATOMIC", canonicalOwner := some .G15, isGenerator := true,
      lhs := .controlledDocument,
      rhs := [ .nonterm .scopedInitial 1, .term ". ", .nonterm .scopedInitial 2, .term "." ],
      sideConds := [.sentenceAtomicBothCohortsMatch],
      sourceDoc := "S0-R2.2", sourceSection := "§II.4.1 F-R2.1-05 sentence_atomic (line 87)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-15B-DOC-CONJ-DISCOURSE", canonicalOwner := some .G15, isGenerator := true,
      lhs := .controlledDocument,
      rhs := [ .nonterm .scopedInitial 1, .term ". ", .nonterm .scopedRepeat 2, .term "." ],
      sideConds := [.discourseBoundCohortAndDesignMatch],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "S0-R2.1 §II.1 line 41 & S0-R2.2 §II.4.1 line 88",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-16-DOC-CONTRASTIVE", canonicalOwner := some .G16, isGenerator := true,
      lhs := .controlledDocument,
      rhs := [ .nonterm .scopedAssoc 1, .term "; however, ", .nonterm .scopedContrastMeta 2, .term "." ],
      sideConds := [.contrastiveSharedExpOutPair],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "S0-R2.1 §II.1 line 42 & S0-R2.2 §II.4.2 line 90",
      r0Status := .exactFrozenInR0 },

    -- (C) Parser-Only Adversarial Trap Rules `T1` ~ `T5` (`G_parse \ G_gen`, `P0-A05` §2)
    { prodId := "ENV-DOC-TRAP-SCOPED", canonicalOwner := none, isGenerator := false,
      lhs := .controlledDocument,
      rhs := [.nonterm .scopedTrapClause 1, .term "."],
      sideConds := [],
      sourceDoc := "Gate C1-P0 (P0-A05)", sourceSection := "§2 Scoped Trap Envelope (lines 45-48)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "ENV-SCOPED-TRAP", canonicalOwner := none, isGenerator := false,
      lhs := .scopedTrapClause,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .trapCore 0],
      sideConds := [.cohortMatchesEnv],
      sourceDoc := "Gate C1-P0 (P0-A05)", sourceSection := "§2 Scoped Trap Prefix (lines 45-48)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T1-TRAP-ALL-NOT", canonicalOwner := some .T1, isGenerator := false,
      lhs := .trapCore,
      rhs := [ .term "all ", .lexSlot .subgroupPlural .subgroup,
               .term " patients did not develop ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 45 & AC-P0-04 T-01 line 125 (altCount=2)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T2-TRAP-CONFIRM-THAT", canonicalOwner := some .T2, isGenerator := false,
      lhs := .trapCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not confirm that ", .nonterm .embeddedCausal 0 ],
      sideConds := [],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 46 (altCount=2)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T3-TRAP-WH-PRESUP", canonicalOwner := some .T3, isGenerator := false,
      lhs := .trapCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not ", .lexSlot .epistemicVerb .verb,
               .term " ", .lexSlot .whWord .whComp,
               .term " ", .nonterm .embeddedCausal 0 ],
      sideConds := [],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 47 (altCount=1)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T4-TRAP-BARE-PLURAL", canonicalOwner := some .T4, isGenerator := false,
      lhs := .trapCore,
      rhs := [ .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 48 & S0-R2 IV.04 (altCount=2)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T5-TRAP-UNSCOPED-DOC", canonicalOwner := some .T5, isGenerator := false,
      lhs := .controlledDocument,
      rhs := [ .nonterm .atomicCore 1, .term "." ],
      sideConds := [.unscopedClauseLacksInOrWithin],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 49 (altCount=1)",
      r0Status := .canonicalizedFromP0A05Reference } ]

/-! ### 5. Explicit `HELD` Ledger for R0-Underspecified Grammar Details (Zero Arbitrary Invention) -/

inductive R0UnspecifiedGrammarItem where
  | G01_RightCensored_KM_AJ_SurfaceTemplate -- Required conceptually in S0-R2.2 line 93, English BNF template not given in R0
  | G05_S0R2_BetweenAnd_Draft_Superseded    -- S0-R2 line 73 had `between..and`; superseded by S0-R2.1 line 91 `comparing..versus`
  | G14_CovariateList_InternalElementCap    -- S0-R2.1 mentioned K_max=12; P0 Task P0-01 marked K_cov UNSPECIFIED_IN_R0
  |NumericTrailingDotPolicy_R0RegexExcludes -- `1.` excluded by S0-R2.2 `(\.[0-9]{1,4})?`, kept fail-closed REJECT
  deriving DecidableEq, Repr

/-! ### 6. Machine-Checked Structural Invariants on `independentFrozenBNF` -/

/-- Check that every child nonterminal in a production has strictly lower `level` than `lhs`. -/
def isProductionAcyclicBool (p : BNFProduction) : Bool :=
  p.rhs.all fun sym =>
    match sym with
    | .nonterm childNt _ => decide (childNt.level < p.lhs.level)
    | _ => true

theorem all_independentFrozenBNF_acyclic :
    independentFrozenBNF.all isProductionAcyclicBool = true := by
  decide

/-- Every canonical rule `r` in `{G01..G16, T1..T5}` is represented in `independentFrozenBNF` with matching `isGenerator` flag! -/
def isCanonicalRuleCoveredBool (r : CanonicalRuleId) : Bool :=
  independentFrozenBNF.any fun p =>
    (p.canonicalOwner == some r) && (p.isGenerator == r.isGeneratorRule)

theorem all_21_canonical_rules_covered :
    ∀ r : CanonicalRuleId, isCanonicalRuleCoveredBool r = true := by
  intro r
  cases r <;> decide

/-- Generator-vs-Trap Partition Invariant: No production owned by `T1..T5` is marked `isGenerator = true`. -/
theorem trap_productions_never_in_generator :
    independentFrozenBNF.all (fun p =>
      match p.canonicalOwner with
      | some r => p.isGenerator == r.isGeneratorRule
      | none   => true) = true := by
  decide

end BrocaOmega.P3A
```

### 6.6 `01_formal_spec/P3FormalSpec/P2CorrespondenceAudit.lean` (`SHA-256: 2FAF234D276D433329D4477FC978DFFAB67183C43E46F74C42900105907E5FD8`)
```lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`F-P2-01`: Frozen Grammar ↔ P3 Independent BNF ↔ P2 Audit)
  01_formal_spec/P3FormalSpec/P2CorrespondenceAudit.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  Provides machine-checked formal correspondence evidence addressing `F-P2-01` WITHOUT modifying
  or importing `P2_DerivationReplay`:
    1. Records an explicit read-only snapshot projection of `P2`'s 27 numeric rule codes and
       production shapes (externally verified against `P2_DerivationReplay/.../GrammarG16.lean`
       on disk by `differential_oracle_p3a.py` so zero transcription drift is possible).
    2. Proves a 1-to-1 structural bijection (`p2CodeToBNFProdId` / `bnfGenProdToP2Code`) between
       all `27` generator-subset productions of `independentFrozenBNF` (`isGenerator = true`)
       and `P2`'s `27` rule codes, with exact LHS nonterminal, terminal string, slot sort,
       slot tag, and child nonterminal/locus identity!
    3. Proves that all `7` trap-subset productions (`T1`~`T5` + `2` trap envelopes) are strictly
       outside `P2`'s generator rule domain.
    4. Explicitly preserves `F-P2-01` residual `HELD` items (`G-01` right-censored KM/AJ surface
       template unspecified in `R0`, and `G-14` covariate internal arity cap `UNSPECIFIED_IN_R0`).
-/
import P3FormalSpec.FrozenBNF

namespace BrocaOmega.P3A

/-- Snapshot descriptor of a `P2` generator rule code (`1..301`) for read-only formal comparison. -/
structure P2RuleSnapshot where
  p2Code : Nat
  p2Name : String
  lhs    : BNFNonterm
  rhs    : List BNFSymbol
  deriving DecidableEq, Repr

/-- Exact 27-entry generator production table corresponding to `P2`'s `FrozenGenRule` (`codes 1..301`). -/
def p2RuleSnapshots : List P2RuleSnapshot :=
  [ { p2Code := 1,   p2Name := "DocSingle", lhs := .controlledDocument,
      rhs := [.nonterm .scopedInitial 1, .term "."] },
    { p2Code := 201, p2Name := "ScopedInitial", lhs := .scopedInitial,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .atomicCore 0] },
    { p2Code := 202, p2Name := "ScopedRepeatDiscourse", lhs := .scopedRepeat,
      rhs := [.term "Within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .atomicCore 0] },
    { p2Code := 203, p2Name := "ScopedAssoc", lhs := .scopedAssoc,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .assocCore 0] },
    { p2Code := 204, p2Name := "ScopedContrastMeta", lhs := .scopedContrastMeta,
      rhs := [.term "within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .metaNonEstabCore 0] },
    { p2Code := 210, p2Name := "LiftAssocToAtomic", lhs := .atomicCore,
      rhs := [.nonterm .assocCore 0] },
    { p2Code := 211, p2Name := "LiftMetaToAtomic", lhs := .atomicCore,
      rhs := [.nonterm .metaNonEstabCore 0] },
    { p2Code := 301, p2Name := "EmbeddedCausal", lhs := .embeddedCausal,
      rhs := [.lexSlot .expLevel .activeExp, .term " ", .lexSlot .intervVerbPres .verb, .term " ", .lexSlot .outTerm .outcome] },
    { p2Code := 10,  p2Name := "G01_DescIncidence", lhs := .atomicCore,
      rhs := [ .term "over ", .lexSlot .followUpWindow .window,
               .term ", the cumulative incidence of ", .lexSlot .eventTerm .eventA,
               .term " was ", .lexSlot .numericLit .numK,
               .term " of ", .lexSlot .numericLit .numN,
               .term " patients (", .lexSlot .numericLit .numPct, .term "%)" ] },
    { p2Code := 20,  p2Name := "G02a_DescMeanSD", lhs := .atomicCore,
      rhs := [ .term "the mean ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (SD ", .lexSlot .numericLit .numDisp1, .term ")" ] },
    { p2Code := 21,  p2Name := "G02b_DescMedianIQR", lhs := .atomicCore,
      rhs := [ .term "the median ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (IQR ", .lexSlot .numericLit .numDisp1,
               .term " to ", .lexSlot .numericLit .numDisp2, .term ")" ] },
    { p2Code := 30,  p2Name := "G03_AssocUnadj", lhs := .assocCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ] },
    { p2Code := 40,  p2Name := "G04_AssocTemp", lhs := .assocCore,
      rhs := [ .lexSlot .eventTerm .eventA, .term " preceded ", .lexSlot .eventTerm .eventB,
               .term ", and comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ] },
    { p2Code := 50,  p2Name := "G05_CompRD", lhs := .atomicCore,
      rhs := [ .term "the absolute risk difference in ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " percentage points (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ] },
    { p2Code := 60,  p2Name := "G06a_IntervDirectional", lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was estimated to ", .lexSlot .intervDirVerb .verb,
               .term " ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ", p = ", .lexSlot .numericLit .numPVal, .term ")" ] },
    { p2Code := 61,  p2Name := "G06b_IntervNeutral", lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", the estimated causal ", .lexSlot .ratioMetric .metric1,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term "), which did not exclude no effect" ] },
    { p2Code := 70,  p2Name := "G07_MetaNotStatSig", lhs := .atomicCore,
      rhs := [ .term "the observed ", .lexSlot .ratioMetric .metric1,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric2,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ") was not statistically significant at alpha = ",
               .lexSlot .numericLit .numAlpha ] },
    { p2Code := 80,  p2Name := "G08_MetaEquiv", lhs := .atomicCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " met prespecified equivalence margins (",
               .lexSlot .numericLit .numMarginLow, .term " to ", .lexSlot .numericLit .numMarginHigh,
               .term ") for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% TOST CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ] },
    { p2Code := 90,  p2Name := "G09_MetaNonEstab", lhs := .metaNonEstabCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not establish that ", .nonterm .embeddedCausal 0 ] },
    { p2Code := 100, p2Name := "G10_MetaUnresolved", lhs := .atomicCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not determine whether ", .nonterm .embeddedCausal 0 ] },
    { p2Code := 110, p2Name := "G11_QuantZero", lhs := .atomicCore,
      rhs := [ .term "no ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ] },
    { p2Code := 120, p2Name := "G12_QuantProperPart", lhs := .atomicCore,
      rhs := [ .term "some, but not all, ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ] },
    { p2Code := 130, p2Name := "G13_QuantAtLeastOne", lhs := .atomicCore,
      rhs := [ .term "at least one ", .lexSlot .subgroupSingular .subgroup,
               .term " patient developed ", .lexSlot .eventTerm .eventA ] },
    { p2Code := 140, p2Name := "G14_AssocAdj", lhs := .assocCore,
      rhs := [ .term "after adjustment for ", .lexSlot .covariateList .covariates,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ] },
    { p2Code := 150, p2Name := "G15_DocConjAtomic", lhs := .controlledDocument,
      rhs := [ .nonterm .scopedInitial 1, .term ". ", .nonterm .scopedInitial 2, .term "." ] },
    { p2Code := 151, p2Name := "G15_DocConjDiscourse", lhs := .controlledDocument,
      rhs := [ .nonterm .scopedInitial 1, .term ". ", .nonterm .scopedRepeat 2, .term "." ] },
    { p2Code := 160, p2Name := "G16_DocContrastive", lhs := .controlledDocument,
      rhs := [ .nonterm .scopedAssoc 1, .term "; however, ", .nonterm .scopedContrastMeta 2, .term "." ] } ]

/-- Generator subset of `independentFrozenBNF` (`27` productions: `8` envelopes + `19` `G-01`~`G-16` productions). -/
def generatorBNFSubset : List BNFProduction :=
  independentFrozenBNF.filter (·.isGenerator)

/-- Trap subset of `independentFrozenBNF` (`7` productions: `2` trap envelopes + `T1`~`T5`). -/
def trapBNFSubset : List BNFProduction :=
  independentFrozenBNF.filter (!·.isGenerator)

theorem generatorBNFSubset_count : generatorBNFSubset.length = 27 := by decide
theorem trapBNFSubset_count      : trapBNFSubset.length = 7 := by decide
theorem p2RuleSnapshots_count    : p2RuleSnapshots.length = 27 := by decide

/--
  **Exact Structural Correspondence Theorem (`F-P2-01` Syntactic Production Match)**:
  The `27` generator-subset productions extracted independently from `Architecture Freeze R0`
  match `p2RuleSnapshots` 1-to-1 in exact `(lhs, rhs)` order and symbol sequence!
-/
theorem p3_generator_bnf_matches_p2_snapshots :
    (generatorBNFSubset.map fun p => (p.lhs, p.rhs)) =
    (p2RuleSnapshots.map fun s => (s.lhs, s.rhs)) := by
  decide

/--
  **Trap Disjointness at Production Table Level**:
  No trap production (`T1`~`T5` or trap wrapper) has `(lhs, rhs)` present in `p2RuleSnapshots`.
-/
theorem p2_snapshots_exclude_all_trap_productions :
    trapBNFSubset.all (fun tp =>
      p2RuleSnapshots.all (fun s => !((tp.lhs == s.lhs) && (tp.rhs == s.rhs)))) = true := by
  decide

end BrocaOmega.P3A
```

### 6.7 `02_detached_checker/P3DetachedChecker.lean` (`SHA-256: 290D2D9EC89DEB00C6117FCB6C3FECA67B098AEDE07F3D04C1EC395B1FDCAE11`)
```lean
import P3DetachedChecker.StrictLexicalGate
```

### 6.8 `02_detached_checker/P3DetachedChecker/StrictLexicalGate.lean` (`SHA-256: 2FD8F2BA94B2930FDC0E674DC0DCB7E69368FC81645A7731EF21FC7295AE17D9`)
```lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: Strict Lexical Gate & Soundness Proofs)
  02_detached_checker/P3DetachedChecker/StrictLexicalGate.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `sorry`, zero `native_decide`)

  Gate B & Gate C Deliverable:
  1. Separates executable `Bool` / `Except` validators from declarative `Prop` specifications
     defined in `P3FormalSpec.StrictLexicalSpec`.
  2. Encapsulates `VerifiedIngressText` and `CertifiedLexicalSlot` with `private mk ::`
     so non-authoritative `LexicalRejectDiag` carries zero capability to construct witnesses.
  3. Proves both `admitLexicalSlot_sound` (`Accepted(x) -> LexicallyValid ∧ NumericallyWellFormed ∧ EntityCatalogBound`)
     and `admitLexicalSlot_complete`, plus general rejection theorems for multi-dot (`1..25`, `1.2.3`),
     trailing-dot (`1.`), and negative-zero (`-0.0`) surfaces.
-/
import P3FormalSpec

namespace BrocaOmega.P3A

/-! ### 1. Non-Authoritative Structured Rejection Diagnostics -/

inductive LexicalRejectDiag where
  | emptyRawBytes
  | inputLengthExceeded            (actual maxBytes : Nat)
  | nonPrintableAsciiOrInvalidUtf8 (byteVal : UInt8)
  | emptyOrNonAsciiEntityId
  | untrimmedOuterWhitespace
  | reservedKeywordLeak            (keyword : String)
  | explicitPlusForbidden
  | leadingDecimalPoint
  | trailingDecimalPoint
  | multipleDecimalPoints
  | invalidNumericCharOrExponent   (ch : Char)
  | redundantLeadingZero
  | numericPrecisionBoundExceeded  (intLen fracLen : Nat)
  | negativeZeroForbidden
  | numericEntityIdMismatch
  | invalidEntityCatalog
  | entityCatalogMismatch
  | closedFunctionalLexiconMismatch
  | invalidRuleOrReadingAlt
  | parserOnlyTrapRuleInGenerator
  deriving DecidableEq, Repr

/-! ### 2. Generic `List.all` / Membership / Sublist Helper Lemmas -/

theorem list_all_eq_true {α : Type} (p : α → Bool) (xs : List α) :
    xs.all p = true ↔ ∀ x ∈ xs, p x = true := by
  induction xs with
  | nil => simp
  | cons h t ih => simp [List.all, Bool.and_eq_true, ih]

def memDecListBool {α : Type} [DecidableEq α] (a : α) : List α → Bool
  | [] => false
  | x :: xs => (x == a) || memDecListBool a xs

theorem memDecListBool_iff {α : Type} [DecidableEq α] (a : α) (xs : List α) :
    memDecListBool a xs = true ↔ a ∈ xs := by
  induction xs with
  | nil => simp [memDecListBool]
  | cons x rest ih =>
    unfold memDecListBool
    rw [Bool.or_eq_true, beq_iff_eq, ih, List.mem_cons]
    constructor
    · rintro (rfl | hm)
      · exact Or.inl rfl
      · exact Or.inr hm
    · rintro (rfl | hm)
      · exact Or.inl rfl
      · exact Or.inr hm

def isPrefixListBool {α : Type} [DecidableEq α] : List α → List α → Bool
  | [], _ => true
  | _ :: _, [] => false
  | n :: ns, h :: hs => (n == h) && isPrefixListBool ns hs

theorem isPrefixListBool_iff {α : Type} [DecidableEq α] (needle haystack : List α) :
    isPrefixListBool needle haystack = true ↔ ∃ post : List α, haystack = needle ++ post := by
  induction needle generalizing haystack with
  | nil =>
    exact ⟨fun _ => ⟨haystack, rfl⟩, fun _ => rfl⟩
  | cons n ns ih =>
    cases haystack with
    | nil =>
      unfold isPrefixListBool
      constructor
      · intro hf; contradiction
      · rintro ⟨_, h⟩; simp at h
    | cons h hs =>
      unfold isPrefixListBool
      rw [Bool.and_eq_true, beq_iff_eq, ih]
      constructor
      · rintro ⟨rfl, post, rfl⟩
        exact ⟨post, rfl⟩
      · rintro ⟨post, heq⟩
        injection heq with h1 h2
        exact ⟨h1.symm, post, h2⟩

def containsSublistBool {α : Type} [DecidableEq α] (needle : List α) : List α → Bool
  | [] => needle.isEmpty
  | h :: hs => isPrefixListBool needle (h :: hs) || containsSublistBool needle hs

theorem containsSublistBool_iff {α : Type} [DecidableEq α] (needle haystack : List α) :
    containsSublistBool needle haystack = true ↔ IsContigSublist needle haystack := by
  induction haystack with
  | nil =>
    unfold containsSublistBool IsContigSublist
    cases needle with
    | nil =>
      exact ⟨fun _ => ⟨[], [], rfl⟩, fun _ => rfl⟩
    | cons a as =>
      constructor
      · intro hf; contradiction
      · rintro ⟨pre, post, h⟩
        cases pre <;> simp at h
  | cons h hs ih =>
    unfold containsSublistBool
    rw [Bool.or_eq_true, isPrefixListBool_iff, ih]
    unfold IsContigSublist
    constructor
    · intro hor
      rcases hor with ⟨post, heq⟩ | ⟨pre, post, heq⟩
      · exact ⟨[], post, by simpa using heq⟩
      · exact ⟨h :: pre, post, by simp [heq]⟩
    · rintro ⟨pre, post, heq⟩
      cases pre with
      | nil =>
        left
        exact ⟨post, by simpa using heq⟩
      | cons p ps =>
        simp at heq
        right
        exact ⟨ps, post, by simpa [List.append_assoc] using heq.2⟩

/-! ### 3. Raw UTF-8 / Printable 7-Bit ASCII Ingress Gate (`F-C0-03`) -/

def isPrintableAsciiByteBool (b : UInt8) : Bool :=
  ((0x20 : UInt8) ≤ b) && (b ≤ (0x7E : UInt8))

theorem isPrintableAsciiByteBool_iff (b : UInt8) :
    isPrintableAsciiByteBool b = true ↔ IsPrintableAsciiByte b := by
  unfold isPrintableAsciiByteBool IsPrintableAsciiByte
  simp [Bool.and_eq_true]

def findBadAsciiByte : List UInt8 → Option UInt8
  | [] => none
  | b :: bs => if isPrintableAsciiByteBool b then findBadAsciiByte bs else some b

theorem findBadAsciiByte_eq_none_iff (bs : List UInt8) :
    findBadAsciiByte bs = none ↔ ∀ b ∈ bs, IsPrintableAsciiByte b := by
  induction bs with
  | nil => simp [findBadAsciiByte]
  | cons b rest ih =>
    unfold findBadAsciiByte
    split
    · rename_i hok
      rw [ih]
      have hb : IsPrintableAsciiByte b := (isPrintableAsciiByteBool_iff b).mp hok
      constructor
      · intro hall x hx
        rcases List.mem_cons.mp hx with rfl | hmem
        · exact hb
        · exact hall x hmem
      · intro hall x hx
        exact hall x (List.Mem.tail b hx)
    · rename_i hbad
      constructor
      · intro h; contradiction
      · intro hall
        exfalso
        exact hbad ((isPrintableAsciiByteBool_iff b).mpr (hall b (List.Mem.head rest)))

def checkStrictAsciiIngress (maxBytes : Nat) (rawBytes : List UInt8) : Except LexicalRejectDiag Unit :=
  if rawBytes.isEmpty then
    .error .emptyRawBytes
  else if maxBytes < rawBytes.length then
    .error (.inputLengthExceeded rawBytes.length maxBytes)
  else
    match findBadAsciiByte rawBytes with
    | some bad => .error (.nonPrintableAsciiOrInvalidUtf8 bad)
    | none     => .ok ()

theorem checkStrictAsciiIngress_iff (maxBytes : Nat) (rawBytes : List UInt8) :
    checkStrictAsciiIngress maxBytes rawBytes = .ok () ↔ StrictAsciiUTF8Valid maxBytes rawBytes := by
  unfold checkStrictAsciiIngress StrictAsciiUTF8Valid
  cases rawBytes with
  | nil =>
    simp
  | cons b bs =>
    have hne : (b :: bs).isEmpty = false := rfl
    rw [if_neg (by simp [hne])]
    by_cases hlen : maxBytes < (b :: bs).length
    · rw [if_pos hlen]
      constructor
      · intro h; contradiction
      · rintro ⟨_, hle, _⟩; omega
    · rw [if_neg hlen]
      have hle : (b :: bs).length ≤ maxBytes := by omega
      have hpos : 0 < (b :: bs).length := by simp
      cases hbad : findBadAsciiByte (b :: bs) with
      | some bad =>
        constructor
        · intro h; contradiction
        · rintro ⟨_, _, hall⟩
          have hnone := (findBadAsciiByte_eq_none_iff (b :: bs)).mpr hall
          rw [hbad] at hnone
          contradiction
      | none =>
        have hall := (findBadAsciiByte_eq_none_iff (b :: bs)).mp hbad
        exact ⟨fun _ => ⟨hpos, hle, hall⟩, fun _ => rfl⟩

/-- Sealed ingress text witness (`private mk ::`). -/
structure VerifiedIngressText (maxBytes : Nat) where
  private mk ::
  rawBytes  : List UInt8
  decoded   : String
  hDecoded  : decoded = decodeAsciiBytes rawBytes
  hValid    : StrictAsciiUTF8Valid maxBytes rawBytes

def admitStrictAsciiIngress (maxBytes : Nat) (rawBytes : List UInt8) :
    Except LexicalRejectDiag (VerifiedIngressText maxBytes) :=
  match h : checkStrictAsciiIngress maxBytes rawBytes with
  | .error e => .error e
  | .ok ()   =>
    .ok ⟨rawBytes, decodeAsciiBytes rawBytes, rfl,
         (checkStrictAsciiIngress_iff maxBytes rawBytes).mp h⟩

theorem admitStrictAsciiIngress_sound (maxBytes : Nat) (rawBytes : List UInt8)
    (w : VerifiedIngressText maxBytes)
    (hok : admitStrictAsciiIngress maxBytes rawBytes = .ok w) :
    w.rawBytes = rawBytes ∧ StrictAsciiUTF8Valid maxBytes rawBytes := by
  unfold admitStrictAsciiIngress at hok
  split at hok
  · contradiction
  · rename_i h
    injection hok with hw
    have hraw : w.rawBytes = rawBytes := by rw [← hw]
    exact ⟨hraw, (checkStrictAsciiIngress_iff maxBytes rawBytes).mp h⟩

/-! ### 4. Outer-Space Hygiene, ASCII String & Reserved-Keyword Barrier Checkers -/

def isPrintableAsciiCharBool (c : Char) : Bool :=
  ((0x20 : UInt32) ≤ c.val) && (c.val ≤ (0x7E : UInt32))

theorem isPrintableAsciiCharBool_iff (c : Char) :
    isPrintableAsciiCharBool c = true ↔ (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32) := by
  unfold isPrintableAsciiCharBool
  simp [Bool.and_eq_true]

def checkAsciiEntityIdBool (eid : String) : Bool :=
  !eid.toList.isEmpty && eid.toList.all isPrintableAsciiCharBool

theorem checkAsciiEntityIdBool_iff (eid : String) :
    checkAsciiEntityIdBool eid = true ↔
      0 < eid.toList.length ∧ ∀ c ∈ eid.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32) := by
  unfold checkAsciiEntityIdBool
  rw [Bool.and_eq_true, list_all_eq_true]
  cases hcs : eid.toList with
  | nil => simp
  | cons c cs =>
    constructor
    · rintro ⟨_, hall⟩
      refine ⟨by simp, fun x hx => (isPrintableAsciiCharBool_iff x).mp (hall x hx)⟩
    · rintro ⟨_, hall⟩
      refine ⟨rfl, fun x hx => (isPrintableAsciiCharBool_iff x).mpr (hall x hx)⟩

def checkTrimmedSpacesBool (cs : List Char) : Bool :=
  !cs.isEmpty && (cs.head? != some ' ') && (cs.getLast? != some ' ')

theorem checkTrimmedSpacesBool_iff (cs : List Char) :
    checkTrimmedSpacesBool cs = true ↔ HasTrimmedOuterSpaces cs := by
  unfold checkTrimmedSpacesBool HasTrimmedOuterSpaces
  cases cs with
  | nil => simp
  | cons c rest =>
    simp [Bool.and_eq_true, bne_iff_ne]

def findReservedDelimiter (s : String) : Option String :=
  reservedStructuralDelimiters.find? (fun bad => containsSublistBool bad.toList s.toList)

theorem findReservedDelimiter_eq_none_iff (s : String) :
    findReservedDelimiter s = none ↔ DisjointFromReservedDelimiters s := by
  unfold findReservedDelimiter DisjointFromReservedDelimiters
  rw [List.find?_eq_none]
  constructor
  · intro h bad hmem hsub
    have hfalse := h bad hmem
    exact hfalse ((containsSublistBool_iff bad.toList s.toList).mpr hsub)
  · intro h bad hmem htrue
    exact h bad hmem ((containsSublistBool_iff bad.toList s.toList).mp htrue)

/-! ### 5. Canonical Decimal Surface Parser & Soundness/Completeness (`F-P2-02` Resolution) -/

def isAsciiDigitBool (c : Char) : Bool :=
  ('0'.toNat ≤ c.toNat) && (c.toNat ≤ '9'.toNat)

theorem isAsciiDigitBool_iff (c : Char) :
    isAsciiDigitBool c = true ↔ IsAsciiDigitChar c := by
  unfold isAsciiDigitBool IsAsciiDigitChar
  simp [Bool.and_eq_true]

def findInvalidNumBodyChar : List Char → Option Char
  | [] => none
  | c :: cs =>
    if isAsciiDigitBool c || (c == '.') then findInvalidNumBodyChar cs else some c

theorem findInvalidNumBodyChar_eq_none_iff (cs : List Char) :
    findInvalidNumBodyChar cs = none ↔ ∀ c ∈ cs, IsAsciiDigitChar c ∨ c = '.' := by
  induction cs with
  | nil => simp [findInvalidNumBodyChar]
  | cons c rest ih =>
    unfold findInvalidNumBodyChar
    split
    · rename_i hok
      rw [ih]
      simp [Bool.or_eq_true, isAsciiDigitBool_iff, beq_iff_eq] at hok
      constructor
      · intro hall x hx
        rcases List.mem_cons.mp hx with rfl | hm
        · exact hok
        · exact hall x hm
      · intro hall x hx
        exact hall x (List.Mem.tail c hx)
    · rename_i hbad
      constructor
      · intro h; contradiction
      · intro hall
        exfalso
        have hc := hall c (List.Mem.head rest)
        simp [Bool.or_eq_true, isAsciiDigitBool_iff, beq_iff_eq] at hbad
        rcases hc with hd | hdot
        · exact hbad.1 hd
        · exact hbad.2 hdot

/-- Splits a character list on `'.'` into `(noDot intCs)` | `(oneDot intCs fracCs)` | `manyDots`. -/
inductive DotSplit where
  | noDot    (intCs : List Char)
  | oneDot   (intCs fracCs : List Char)
  | manyDots
  deriving DecidableEq, Repr

def splitDots : List Char → DotSplit
  | [] => .noDot []
  | c :: rest =>
    if c == '.' then
      match splitDots rest with
      | .noDot frac => .oneDot [] frac
      | _           => .manyDots
    else
      match splitDots rest with
      | .noDot ints       => .noDot (c :: ints)
      | .oneDot ints frac => .oneDot (c :: ints) frac
      | .manyDots         => .manyDots

theorem splitDots_noDot_props {body ints : List Char}
    (h : splitDots body = .noDot ints) :
    body = ints ∧ '.' ∉ ints := by
  induction body generalizing ints with
  | nil =>
    simp [splitDots] at h
    subst ints
    exact ⟨rfl, by simp⟩
  | cons c rest ih =>
    unfold splitDots at h
    by_cases hc : c == '.'
    · rw [if_pos hc] at h
      split at h <;> contradiction
    · rw [if_neg hc] at h
      have hne : c ≠ '.' := by simpa [beq_iff_eq] using hc
      split at h
      · rename_i rInts hr
        injection h with heq
        subst ints
        have ⟨hrest_eq, hnot_dot⟩ := ih hr
        subst rest
        refine ⟨rfl, ?_⟩
        intro hmem
        rcases List.mem_cons.mp hmem with hhead | htail
        · exact hne hhead.symm
        · exact hnot_dot htail
      · contradiction
      · contradiction

theorem splitDots_oneDot_props {body ints frac : List Char}
    (h : splitDots body = .oneDot ints frac) :
    body = ints ++ '.' :: frac ∧ '.' ∉ ints ∧ '.' ∉ frac := by
  induction body generalizing ints frac with
  | nil =>
    simp [splitDots] at h
  | cons c rest ih =>
    unfold splitDots at h
    by_cases hc : c == '.'
    · rw [if_pos hc] at h
      have heq_dot : c = '.' := by simpa [beq_iff_eq] using hc
      subst c
      split at h
      · rename_i rFrac hr
        injection h with hi hf
        subst ints; subst frac
        have ⟨hrest_eq, hnot_dot⟩ := splitDots_noDot_props hr
        subst rest
        exact ⟨rfl, by simp, hnot_dot⟩
      · contradiction
    · rw [if_neg hc] at h
      have hne : c ≠ '.' := by simpa [beq_iff_eq] using hc
      split at h
      · contradiction
      · rename_i rInts rFrac hr
        injection h with hi hf
        subst ints; subst frac
        have ⟨hrest_eq, hni, hnf⟩ := ih hr
        subst rest
        refine ⟨rfl, ?_, hnf⟩
        intro hmem
        rcases List.mem_cons.mp hmem with hhead | htail
        · exact hne hhead.symm
        · exact hni htail
      · contradiction

theorem splitDots_of_no_dot {ints : List Char} (hnot : '.' ∉ ints) :
    splitDots ints = .noDot ints := by
  induction ints with
  | nil => rfl
  | cons c rest ih =>
    have hc : (c == '.') = false := beq_eq_false_iff_ne.mpr (fun heq => hnot (heq ▸ List.Mem.head rest))
    have hr : '.' ∉ rest := fun hm => hnot (List.Mem.tail c hm)
    simp [splitDots, hc, ih hr]

theorem splitDots_of_one_dot {ints frac : List Char}
    (hni : '.' ∉ ints) (hnf : '.' ∉ frac) :
    splitDots (ints ++ '.' :: frac) = .oneDot ints frac := by
  induction ints with
  | nil =>
    unfold splitDots
    simp [splitDots_of_no_dot hnf]
  | cons c rest ih =>
    have hc : (c == '.') = false := beq_eq_false_iff_ne.mpr (fun heq => hni (heq ▸ List.Mem.head rest))
    have hr : '.' ∉ rest := fun hm => hni (List.Mem.tail c hm)
    unfold splitDots
    simp [hc, ih hr]

/-- Checks digit-part constraints after sign & dot splitting. -/
def checkParsedBodyParts (cfg : NumericGateConfig) (neg : Bool) (body : List Char) :
    Except LexicalRejectDiag ParsedDecLit :=
  if body.isEmpty then
    .error (.invalidNumericCharOrExponent '-')
  else
    match findInvalidNumBodyChar body with
    | some badCh => .error (.invalidNumericCharOrExponent badCh)
    | none =>
      match splitDots body with
      | .manyDots => .error .multipleDecimalPoints
      | .noDot intCs =>
        if intCs.isEmpty then
          .error .leadingDecimalPoint
        else if (1 < intCs.length) && (intCs.head? == some '0') then
          .error .redundantLeadingZero
        else if cfg.maxIntDigits < intCs.length then
          .error (.numericPrecisionBoundExceeded intCs.length 0)
        else
          let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := [] }
          if neg && (d.absMantissaNat == 0) then
            .error .negativeZeroForbidden
          else
            .ok d
      | .oneDot intCs fracCs =>
        if intCs.isEmpty then
          .error .leadingDecimalPoint
        else if fracCs.isEmpty then
          .error .trailingDecimalPoint
        else if (1 < intCs.length) && (intCs.head? == some '0') then
          .error .redundantLeadingZero
        else if (cfg.maxIntDigits < intCs.length) || (cfg.maxFracDigits < fracCs.length) then
          .error (.numericPrecisionBoundExceeded intCs.length fracCs.length)
        else
          let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := fracCs }
          if neg && (d.absMantissaNat == 0) then
            .error .negativeZeroForbidden
          else
            .ok d

/--
  Executable Canonical Decimal Surface Parser (`Gate B`):
  Rejects `+1.25`, `1..25`, `1.2.3`, `1.`, `.25`, `001.25`, `-0.0`, `1e-3`, and precision overflows.
-/
def parseCanonicalDecSurface (cfg : NumericGateConfig) (s : String) :
    Except LexicalRejectDiag ParsedDecLit :=
  match s.toList with
  | [] => .error (.invalidNumericCharOrExponent ' ')
  | c0 :: tail0 =>
    if c0 == '+' then
      .error .explicitPlusForbidden
    else if c0 == '-' then
      checkParsedBodyParts cfg true tail0
    else
      checkParsedBodyParts cfg false (c0 :: tail0)

private theorem digits_of_body_no_dot {body part : List Char}
    (hall : ∀ c ∈ body, IsAsciiDigitChar c ∨ c = '.')
    (hsub : ∀ c ∈ part, c ∈ body)
    (hnodot : '.' ∉ part) :
    ∀ c ∈ part, IsAsciiDigitChar c := by
  intro c hc
  rcases hall c (hsub c hc) with hd | hdot
  · exact hd
  · exfalso; exact hnodot (hdot ▸ hc)

private theorem checkParsedBodyParts_sound (cfg : NumericGateConfig) (neg : Bool)
    (body : List Char) (s : String) (d : ParsedDecLit)
    (hsurf : s.toList = (if neg then ['-'] else []) ++ body)
    (hok : checkParsedBodyParts cfg neg body = .ok d) :
    DecSurfaceSpec cfg s d := by
  unfold checkParsedBodyParts at hok
  split at hok
  · contradiction
  · cases hinv : findInvalidNumBodyChar body with
    | some _ => rw [hinv] at hok; contradiction
    | none =>
      rw [hinv] at hok
      have hall_body := (findInvalidNumBodyChar_eq_none_iff body).mp hinv
      cases hsp : splitDots body with
      | manyDots => rw [hsp] at hok; contradiction
      | noDot intCs =>
        rw [hsp] at hok
        dsimp at hok
        have ⟨hbody_eq, hnodot⟩ := splitDots_noDot_props hsp
        split at hok
        · contradiction
        · rename_i hint_ne
          split at hok
          · contradiction
          · rename_i hno_lz
            split at hok
            · contradiction
            · rename_i hint_bound
              split at hok
              · contradiction
              · rename_i hno_negz
                injection hok with hd
                rw [← hd]
                unfold DecSurfaceSpec ParsedDecLit.renderChars
                dsimp
                have hlen_pos : 1 ≤ intCs.length := by
                  cases intCs with | nil => simp at hint_ne | cons _ _ => simp
                have hdigits : ∀ c ∈ intCs, IsAsciiDigitChar c :=
                  digits_of_body_no_dot hall_body (fun c hc => hbody_eq ▸ hc) hnodot
                refine ⟨?_, hlen_pos, by omega, hdigits, ?_, by simp, by simp, ?_⟩
                · rw [hsurf, hbody_eq]
                  simp
                · intro hgt hhead
                  apply hno_lz
                  simp [hgt, hhead]
                · intro hz
                  cases neg with
                  | false => rfl
                  | true =>
                    exfalso
                    apply hno_negz
                    simpa [Bool.and_eq_true] using hz
      | oneDot intCs fracCs =>
        rw [hsp] at hok
        dsimp at hok
        have ⟨hbody_eq, hnodot_i, hnodot_f⟩ := splitDots_oneDot_props hsp
        split at hok
        · contradiction
        · rename_i hint_ne
          split at hok
          · contradiction
          · rename_i hfrac_ne
            split at hok
            · contradiction
            · rename_i hno_lz
              split at hok
              · contradiction
              · rename_i hbounds
                split at hok
                · contradiction
                · rename_i hno_negz
                  injection hok with hd
                  rw [← hd]
                  unfold DecSurfaceSpec ParsedDecLit.renderChars
                  dsimp
                  have hlen_pos : 1 ≤ intCs.length := by
                    cases intCs with | nil => simp at hint_ne | cons _ _ => simp
                  simp [Bool.or_eq_true] at hbounds
                  have hdigits_i : ∀ c ∈ intCs, IsAsciiDigitChar c :=
                    digits_of_body_no_dot hall_body
                      (fun c hc => hbody_eq ▸ List.mem_append_left ('.' :: fracCs) hc) hnodot_i
                  have hdigits_f : ∀ c ∈ fracCs, IsAsciiDigitChar c :=
                    digits_of_body_no_dot hall_body
                      (fun c hc => hbody_eq ▸ List.mem_append_right intCs (List.Mem.tail '.' hc)) hnodot_f
                  refine ⟨?_, hlen_pos, by omega, hdigits_i, ?_, by omega, hdigits_f, ?_⟩
                  · rw [hsurf, hbody_eq]
                    simp [hfrac_ne, List.append_assoc]
                  · intro hgt hhead
                    apply hno_lz
                    simp [hgt, hhead]
                  · intro hz
                    cases neg with
                    | false => rfl
                    | true =>
                      exfalso
                      apply hno_negz
                      simpa [Bool.and_eq_true] using hz

/-- **Soundness of `parseCanonicalDecSurface` (`Gate B/C`)**: every accepted token satisfies `DecSurfaceSpec`! -/
theorem parseCanonicalDecSurface_sound (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hok : parseCanonicalDecSurface cfg s = .ok d) :
    DecSurfaceSpec cfg s d := by
  unfold parseCanonicalDecSurface at hok
  cases hcs : s.toList with
  | nil => rw [hcs] at hok; contradiction
  | cons c0 tail0 =>
    rw [hcs] at hok
    dsimp at hok
    by_cases hp : c0 == '+'
    · rw [if_pos hp] at hok; contradiction
    · rw [if_neg hp] at hok
      by_cases hm : c0 == '-'
      · rw [if_pos hm] at hok
        have hc_eq : c0 = '-' := by simpa [beq_iff_eq] using hm
        subst c0
        exact checkParsedBodyParts_sound cfg true tail0 s d hcs hok
      · rw [if_neg hm] at hok
        exact checkParsedBodyParts_sound cfg false (c0 :: tail0) s d (by simpa using hcs) hok

private theorem digit_ne_dot {c : Char} (hd : IsAsciiDigitChar c) : c ≠ '.' := by
  unfold IsAsciiDigitChar at hd
  intro heq; subst c
  have h0 : '0'.toNat = 48 := rfl
  have hdot : '.'.toNat = 46 := rfl
  omega

private theorem digit_ne_plus {c : Char} (hd : IsAsciiDigitChar c) : c ≠ '+' := by
  unfold IsAsciiDigitChar at hd
  intro heq; subst c
  have h0 : '0'.toNat = 48 := rfl
  have hp : '+'.toNat = 43 := rfl
  omega

private theorem digit_ne_minus {c : Char} (hd : IsAsciiDigitChar c) : c ≠ '-' := by
  unfold IsAsciiDigitChar at hd
  intro heq; subst c
  have h0 : '0'.toNat = 48 := rfl
  have hm : '-'.toNat = 45 := rfl
  omega

private theorem checkParsedBodyParts_complete (cfg : NumericGateConfig) (neg : Bool)
    (intCs fracCs : List Char)
    (hint_ge : 1 ≤ intCs.length)
    (hint_le : intCs.length ≤ cfg.maxIntDigits)
    (hdig_i : ∀ c ∈ intCs, IsAsciiDigitChar c)
    (hno_lz : 1 < intCs.length → intCs.head? ≠ some '0')
    (hfrac_le : fracCs.length ≤ cfg.maxFracDigits)
    (hdig_f : ∀ c ∈ fracCs, IsAsciiDigitChar c)
    (hzero_sign : (ParsedDecLit.mk neg intCs fracCs).absMantissaNat = 0 → neg = false) :
    checkParsedBodyParts cfg neg (intCs ++ (if fracCs.isEmpty then [] else '.' :: fracCs)) =
      .ok ⟨neg, intCs, fracCs⟩ := by
  cases intCs with
  | nil => simp at hint_ge
  | cons i0 irest =>
    have hnodot_i : '.' ∉ (i0 :: irest) := fun hm => digit_ne_dot (hdig_i '.' hm) rfl
    have hnodot_f : '.' ∉ fracCs := fun hm => digit_ne_dot (hdig_f '.' hm) rfl
    have hlz_false : ((1 < (i0 :: irest).length) && ((i0 :: irest).head? == some '0')) = false := by
      by_cases hgt : 1 < (i0 :: irest).length
      · have hne0 : (i0 :: irest).head? ≠ some '0' := hno_lz hgt
        cases hhead : (i0 :: irest).head? == some '0'
        · simp [Bool.and_false]
        · exfalso; exact hne0 (beq_iff_eq.mp hhead)
      · have hd_false : decide (1 < (i0 :: irest).length) = false := decide_eq_false hgt
        rw [hd_false, Bool.false_and]
    have hint_not_gt : ¬ (cfg.maxIntDigits < (i0 :: irest).length) := by omega
    have hnz : (neg && ((ParsedDecLit.mk neg (i0 :: irest) fracCs).absMantissaNat == 0)) = false := by
      cases neg with
      | false => rfl
      | true =>
        simp only [Bool.true_and, beq_eq_false_iff_ne]
        intro hz
        have hf := hzero_sign hz
        contradiction
    cases fracCs with
    | nil =>
      have hbody_ok : findInvalidNumBodyChar (i0 :: irest) = none := by
        apply (findInvalidNumBodyChar_eq_none_iff _).mpr
        intro c hc
        exact Or.inl (hdig_i c hc)
      have hsp := splitDots_of_no_dot hnodot_i
      simp only [List.isEmpty_nil, ↓reduceIte, List.append_nil]
      unfold checkParsedBodyParts
      rw [if_neg (by simp), hbody_ok]
      change (match splitDots (i0 :: irest) with
        | .manyDots => Except.error LexicalRejectDiag.multipleDecimalPoints
        | .noDot intCs =>
          if intCs.isEmpty then Except.error LexicalRejectDiag.leadingDecimalPoint
          else if (1 < intCs.length) && (intCs.head? == some '0') then Except.error LexicalRejectDiag.redundantLeadingZero
          else if cfg.maxIntDigits < intCs.length then Except.error (LexicalRejectDiag.numericPrecisionBoundExceeded intCs.length 0)
          else
            let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := [] }
            if neg && (d.absMantissaNat == 0) then Except.error LexicalRejectDiag.negativeZeroForbidden
            else Except.ok d
        | .oneDot intCs fracCs =>
          if intCs.isEmpty then Except.error LexicalRejectDiag.leadingDecimalPoint
          else if fracCs.isEmpty then Except.error LexicalRejectDiag.trailingDecimalPoint
          else if (1 < intCs.length) && (intCs.head? == some '0') then Except.error LexicalRejectDiag.redundantLeadingZero
          else if (cfg.maxIntDigits < intCs.length) || (cfg.maxFracDigits < fracCs.length) then
            Except.error (LexicalRejectDiag.numericPrecisionBoundExceeded intCs.length fracCs.length)
          else
            let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := fracCs }
            if neg && (d.absMantissaNat == 0) then Except.error LexicalRejectDiag.negativeZeroForbidden
            else Except.ok d) = Except.ok ⟨neg, i0 :: irest, []⟩
      rw [hsp]
      dsimp only
      rw [if_neg (by simp), if_neg (by rw [hlz_false]; decide), if_neg hint_not_gt, if_neg (by rw [hnz]; decide)]
    | cons f0 frest =>
      have hbody_ok : findInvalidNumBodyChar ((i0 :: irest) ++ '.' :: f0 :: frest) = none := by
        apply (findInvalidNumBodyChar_eq_none_iff _).mpr
        intro c hc
        rcases List.mem_append.mp hc with hi | hf
        · exact Or.inl (hdig_i c hi)
        · rcases List.mem_cons.mp hf with rfl | hfm
          · exact Or.inr rfl
          · exact Or.inl (hdig_f c hfm)
      have hsp := splitDots_of_one_dot hnodot_i hnodot_f
      have hf_not_gt : ¬ (cfg.maxFracDigits < (f0 :: frest).length) := by omega
      have hbounds_false : ((cfg.maxIntDigits < (i0 :: irest).length) || (cfg.maxFracDigits < (f0 :: frest).length)) = false := by
        rw [decide_eq_false hint_not_gt, decide_eq_false hf_not_gt]
        rfl
      simp only [List.isEmpty_cons, Bool.false_eq_true, ↓reduceIte]
      unfold checkParsedBodyParts
      have hne_body : ¬ (((i0 :: irest) ++ '.' :: f0 :: frest).isEmpty = true) := by simp
      rw [if_neg hne_body, hbody_ok]
      change (match splitDots ((i0 :: irest) ++ '.' :: f0 :: frest) with
        | .manyDots => Except.error LexicalRejectDiag.multipleDecimalPoints
        | .noDot intCs =>
          if intCs.isEmpty then Except.error LexicalRejectDiag.leadingDecimalPoint
          else if (1 < intCs.length) && (intCs.head? == some '0') then Except.error LexicalRejectDiag.redundantLeadingZero
          else if cfg.maxIntDigits < intCs.length then Except.error (LexicalRejectDiag.numericPrecisionBoundExceeded intCs.length 0)
          else
            let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := [] }
            if neg && (d.absMantissaNat == 0) then Except.error LexicalRejectDiag.negativeZeroForbidden
            else Except.ok d
        | .oneDot intCs fracCs =>
          if intCs.isEmpty then Except.error LexicalRejectDiag.leadingDecimalPoint
          else if fracCs.isEmpty then Except.error LexicalRejectDiag.trailingDecimalPoint
          else if (1 < intCs.length) && (intCs.head? == some '0') then Except.error LexicalRejectDiag.redundantLeadingZero
          else if (cfg.maxIntDigits < intCs.length) || (cfg.maxFracDigits < fracCs.length) then
            Except.error (LexicalRejectDiag.numericPrecisionBoundExceeded intCs.length fracCs.length)
          else
            let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := fracCs }
            if neg && (d.absMantissaNat == 0) then Except.error LexicalRejectDiag.negativeZeroForbidden
            else Except.ok d) = Except.ok ⟨neg, i0 :: irest, f0 :: frest⟩
      rw [hsp]
      dsimp only
      rw [if_neg (by simp), if_neg (by simp), if_neg (by rw [hlz_false]; decide),
          if_neg (by rw [hbounds_false]; decide), if_neg (by rw [hnz]; decide)]

/-- **Completeness of `parseCanonicalDecSurface` (`Gate B/C`)**: every `DecSurfaceSpec` string is accepted! -/
theorem parseCanonicalDecSurface_complete (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hspec : DecSurfaceSpec cfg s d) :
    parseCanonicalDecSurface cfg s = .ok d := by
  rcases d with ⟨neg, intCs, fracCs⟩
  rcases hspec with ⟨hrend, hint_ge, hint_le, hdig_i, hno_lz, hfrac_le, hdig_f, hzero_sign⟩
  dsimp at hint_ge hint_le hdig_i hno_lz hfrac_le hdig_f hzero_sign
  have hbody := checkParsedBodyParts_complete cfg neg intCs fracCs
    hint_ge hint_le hdig_i hno_lz hfrac_le hdig_f hzero_sign
  unfold parseCanonicalDecSurface
  rw [← hrend]
  cases neg with
  | true =>
    unfold ParsedDecLit.renderChars
    dsimp
    exact hbody
  | false =>
    cases intCs with
    | nil => simp at hint_ge
    | cons i0 irest =>
      have hi0 : IsAsciiDigitChar i0 := hdig_i i0 (List.Mem.head irest)
      have hp : (i0 == '+') = false := beq_eq_false_iff_ne.mpr (digit_ne_plus hi0)
      have hm : (i0 == '-') = false := beq_eq_false_iff_ne.mpr (digit_ne_minus hi0)
      unfold ParsedDecLit.renderChars
      dsimp
      rw [if_neg (by simp [hp]), if_neg (by simp [hm])]
      exact hbody

/-! ### Universal Rejection Theorems for Malformed Numeric Surfaces (`F-P2-02` Explicit Proof) -/

def countChar (target : Char) : List Char → Nat
  | [] => 0
  | c :: cs => (if c = target then 1 else 0) + countChar target cs

theorem countChar_append (target : Char) (xs ys : List Char) :
    countChar target (xs ++ ys) = countChar target xs + countChar target ys := by
  induction xs with
  | nil => simp [countChar]
  | cons x rest ih => simp [countChar, ih, Nat.add_assoc]

theorem countChar_eq_zero_of_not_mem {target : Char} {xs : List Char} (hnot : target ∉ xs) :
    countChar target xs = 0 := by
  induction xs with
  | nil => rfl
  | cons x rest ih =>
    have hx : x ≠ target := fun heq => hnot (heq ▸ List.Mem.head rest)
    have hr : target ∉ rest := fun hm => hnot (List.Mem.tail x hm)
    simp [countChar, hx, ih hr]

/-- **Theorem (`F-P2-02a`): Multi-dot strings (`1..25`, `1.2.3`) NEVER satisfy `DecSurfaceSpec`!** -/
theorem decSurfaceSpec_rejects_multiple_dots (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hmulti : 2 ≤ countChar '.' s.toList) :
    ¬ DecSurfaceSpec cfg s d := by
  rintro ⟨hrend, _, _, hdig_i, _, _, hdig_f, _⟩
  rw [← hrend] at hmulti
  unfold ParsedDecLit.renderChars at hmulti
  rw [countChar_append, countChar_append] at hmulti
  have hsign_zero : countChar '.' (if d.neg then ['-'] else []) = 0 := by
    cases d.neg <;> decide
  have hint_zero : countChar '.' d.intDigits = 0 :=
    countChar_eq_zero_of_not_mem (fun hm => digit_ne_dot (hdig_i '.' hm) rfl)
  have hfrac_le_one : countChar '.' (if d.fracDigits.isEmpty then [] else '.' :: d.fracDigits) ≤ 1 := by
    cases hfe : d.fracDigits with
    | nil => simp [countChar]
    | cons f0 frest =>
      have hf_zero : countChar '.' (f0 :: frest) = 0 :=
        countChar_eq_zero_of_not_mem (fun hm => digit_ne_dot (hdig_f '.' (hfe ▸ hm)) rfl)
      dsimp only [List.isEmpty_cons, Bool.false_eq_true, ↓reduceIte]
      change (if '.' = '.' then 1 else 0) + countChar '.' (f0 :: frest) ≤ 1
      rw [if_pos rfl, hf_zero]
      omega
  omega

/-- **Theorem (`F-P2-02b`): Trailing-dot strings (`1.`) NEVER satisfy `DecSurfaceSpec`!** -/
theorem decSurfaceSpec_rejects_trailing_dot (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (htrail : s.toList.getLast? = some '.') :
    ¬ DecSurfaceSpec cfg s d := by
  rintro ⟨hrend, hint_ge, _, hdig_i, _, _, hdig_f, _⟩
  rw [← hrend] at htrail
  unfold ParsedDecLit.renderChars at htrail
  cases hfe : d.fracDigits with
  | nil =>
    simp [hfe] at htrail
    cases hi : d.intDigits with
    | nil => rw [hi] at hint_ge; simp at hint_ge
    | cons i0 irest =>
      rw [hi] at htrail
      simp at htrail
      have hmem : '.' ∈ (i0 :: irest) := List.mem_of_getLast? htrail
      rw [← hi] at hmem
      exact digit_ne_dot (hdig_i '.' hmem) rfl
  | cons f0 frest =>
    simp [hfe] at htrail
    have hmem : '.' ∈ (f0 :: frest) := List.mem_of_getLast? htrail
    rw [← hfe] at hmem
    exact digit_ne_dot (hdig_f '.' hmem) rfl

/-! ### 6. Closed Entity Catalog Validator & Slot-Level Strict Lexical Gate (`Gate B/C`) -/

def checkCatalogEntryValidBool (e : CatalogEntry) : Bool :=
  (e.sort.regime == .openEntityCatalog) &&
  checkAsciiEntityIdBool e.entityId &&
  checkTrimmedSpacesBool e.lexeme.toList &&
  e.lexeme.toList.all isPrintableAsciiCharBool &&
  (findReservedDelimiter e.lexeme).isNone

theorem checkCatalogEntryValidBool_iff (e : CatalogEntry) :
    checkCatalogEntryValidBool e = true ↔
      e.sort.regime = .openEntityCatalog ∧
      0 < e.entityId.toList.length ∧
      (∀ c ∈ e.entityId.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
      HasTrimmedOuterSpaces e.lexeme.toList ∧
      (∀ c ∈ e.lexeme.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
      DisjointFromReservedDelimiters e.lexeme := by
  unfold checkCatalogEntryValidBool
  rw [Bool.and_eq_true, Bool.and_eq_true, Bool.and_eq_true, Bool.and_eq_true,
      beq_iff_eq, checkAsciiEntityIdBool_iff, checkTrimmedSpacesBool_iff,
      list_all_eq_true, Option.isNone_iff_eq_none, findReservedDelimiter_eq_none_iff]
  constructor
  · rintro ⟨⟨⟨⟨h1, h2, h3⟩, h4⟩, h5⟩, h6⟩
    exact ⟨h1, h2, h3, h4, fun c hc => (isPrintableAsciiCharBool_iff c).mp (h5 c hc), h6⟩
  · rintro ⟨h1, h2, h3, h4, h5, h6⟩
    exact ⟨⟨⟨⟨h1, h2, h3⟩, h4⟩, fun c hc => (isPrintableAsciiCharBool_iff c).mpr (h5 c hc)⟩, h6⟩

def checkValidEntityCatalogBool (cat : ClosedEntityCatalog) : Bool :=
  cat.entries.all checkCatalogEntryValidBool &&
  cat.entries.all (fun e₁ =>
    cat.entries.all (fun e₂ =>
      !((e₁.sort == e₂.sort) && (e₁.entityId == e₂.entityId)) || (e₁.lexeme == e₂.lexeme))) &&
  cat.entries.all (fun e₁ =>
    cat.entries.all (fun e₂ =>
      !(e₁.lexeme == e₂.lexeme) || (e₁ == e₂)))

theorem checkValidEntityCatalogBool_iff (cat : ClosedEntityCatalog) :
    checkValidEntityCatalogBool cat = true ↔ ValidEntityCatalog cat := by
  unfold checkValidEntityCatalogBool ValidEntityCatalog
  rw [Bool.and_eq_true, Bool.and_eq_true]
  simp only [list_all_eq_true]
  constructor
  · rintro ⟨⟨hent, hkey⟩, hinj⟩
    refine ⟨?_, ?_, ?_⟩
    · intro e he
      exact (checkCatalogEntryValidBool_iff e).mp (hent e he)
    · intro e₁ he₁ e₂ he₂ hs hid
      have h := hkey e₁ he₁ e₂ he₂
      have hk : ((e₁.sort == e₂.sort) && (e₁.entityId == e₂.entityId)) = true := by
        simp [hs, hid]
      rw [hk] at h
      simpa [beq_iff_eq] using h
    · intro e₁ he₁ e₂ he₂ hlex
      have h := hinj e₁ he₁ e₂ he₂
      have hl : (e₁.lexeme == e₂.lexeme) = true := beq_iff_eq.mpr hlex
      rw [hl] at h
      simpa [beq_iff_eq] using h
  · rintro ⟨hent, hkey, hinj⟩
    refine ⟨⟨?_, ?_⟩, ?_⟩
    · intro e he
      exact (checkCatalogEntryValidBool_iff e).mpr (hent e he)
    · intro e₁ he₁ e₂ he₂
      cases hs : e₁.sort == e₂.sort
      · simp
      · cases hid : e₁.entityId == e₂.entityId
        · simp
        · simp [beq_iff_eq.mpr (hkey e₁ he₁ e₂ he₂ (beq_iff_eq.mp hs) (beq_iff_eq.mp hid))]
    · intro e₁ he₁ e₂ he₂
      cases hl : e₁.lexeme == e₂.lexeme
      · simp
      · simp [beq_iff_eq.mpr (hinj e₁ he₁ e₂ he₂ (beq_iff_eq.mp hl))]

/-- Sealed proof-carrying witness for an accepted lexical slot (`private mk ::`). -/
structure CertifiedLexicalSlot (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate) where
  private mk ::
  verifiedStr  : String
  parsedNumber : Option ParsedDecLit
  hStrEq       : verifiedStr = cand.decodedStr
  hLexValid    : LexicallyValid maxBytes cand
  hNumValid    : NumericallyWellFormed numCfg cand
  hCatBound    : EntityCatalogBound cat cand

inductive LexicalSlotOutcome (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate) where
  | accepted (witness : CertifiedLexicalSlot cat numCfg maxBytes cand)
  | rejected (diag : LexicalRejectDiag)

def LexicalSlotOutcome.isAccepted {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {maxBytes : Nat} {cand : RawSlotCandidate} :
    LexicalSlotOutcome cat numCfg maxBytes cand → Bool
  | .accepted _ => true
  | .rejected _ => false

def LexicalSlotOutcome.diag? {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {maxBytes : Nat} {cand : RawSlotCandidate} :
    LexicalSlotOutcome cat numCfg maxBytes cand → Option LexicalRejectDiag
  | .accepted _ => none
  | .rejected d => some d

/--
  Pure Computational Slot Validator (`evalLexicalSlot`):
  Computes `(verifiedStr, parsedNumber)` with zero embedded proof terms so kernel reduction
  is blazing fast and free of dependent-match rewrite obstructions.
-/
def evalLexicalSlot (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate) :
    Except LexicalRejectDiag (String × Option ParsedDecLit) :=
  match checkStrictAsciiIngress maxBytes cand.rawBytes with
  | .error e => .error e
  | .ok () =>
    if !checkAsciiEntityIdBool cand.entityId then
      .error .emptyOrNonAsciiEntityId
    else
      let s := cand.decodedStr
      if !checkTrimmedSpacesBool s.toList then
        .error .untrimmedOuterWhitespace
      else
        match cand.sort.regime with
        | .openEntityCatalog =>
          match findReservedDelimiter s with
          | some badKw => .error (.reservedKeywordLeak badKw)
          | none =>
            if !checkValidEntityCatalogBool cat then
              .error .invalidEntityCatalog
            else if memDecListBool ⟨cand.sort, cand.entityId, s⟩ cat.entries then
              .ok (s, none)
            else
              .error .entityCatalogMismatch
        | .closedFunctionalEnum =>
          if memDecListBool (cand.sort, cand.entityId, s) closedFunctionalEntries then
            .ok (s, none)
          else
            .error .closedFunctionalLexiconMismatch
        | .canonicalDecimal =>
          if cand.entityId != s then
            .error .numericEntityIdMismatch
          else
            match parseCanonicalDecSurface numCfg s with
            | .error e => .error e
            | .ok d    => .ok (s, some d)

theorem evalLexicalSlot_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (payload : String × Option ParsedDecLit)
    (hok : evalLexicalSlot cat numCfg maxBytes cand = .ok payload) :
    payload.1 = cand.decodedStr ∧
    LexicallyValid maxBytes cand ∧
    NumericallyWellFormed numCfg cand ∧
    EntityCatalogBound cat cand := by
  unfold evalLexicalSlot at hok
  cases hing : checkStrictAsciiIngress maxBytes cand.rawBytes with
  | error e => rw [hing] at hok; contradiction
  | ok u =>
    rw [hing] at hok
    dsimp at hok
    cases heid : checkAsciiEntityIdBool cand.entityId with
    | false => rw [heid] at hok; contradiction
    | true =>
      rw [heid] at hok
      dsimp at hok
      cases htrim : checkTrimmedSpacesBool cand.decodedStr.toList with
      | false => rw [htrim] at hok; contradiction
      | true =>
        rw [htrim] at hok
        dsimp at hok
        have hing_v := (checkStrictAsciiIngress_iff maxBytes cand.rawBytes).mp hing
        have heid_v := (checkAsciiEntityIdBool_iff cand.entityId).mp heid
        have htrim_v := (checkTrimmedSpacesBool_iff cand.decodedStr.toList).mp htrim
        cases hreg : cand.sort.regime with
        | openEntityCatalog =>
          rw [hreg] at hok
          dsimp at hok
          cases hkw : findReservedDelimiter cand.decodedStr with
          | some badKw => rw [hkw] at hok; contradiction
          | none =>
            rw [hkw] at hok
            dsimp at hok
            cases hcat : checkValidEntityCatalogBool cat with
            | false => rw [hcat] at hok; contradiction
            | true =>
              rw [hcat] at hok
              dsimp at hok
              cases hmem : memDecListBool ⟨cand.sort, cand.entityId, cand.decodedStr⟩ cat.entries with
              | false => rw [hmem] at hok; contradiction
              | true =>
                rw [hmem] at hok
                dsimp at hok
                injection hok with hp
                rw [← hp]
                refine ⟨rfl, ⟨hing_v, heid_v.1, heid_v.2, htrim_v,
                        fun _ => (findReservedDelimiter_eq_none_iff cand.decodedStr).mp hkw⟩,
                        fun hnum => by rw [hnum] at hreg; contradiction, ?_⟩
                unfold EntityCatalogBound
                rw [hreg]
                exact ⟨(checkValidEntityCatalogBool_iff cat).mp hcat,
                       (memDecListBool_iff _ cat.entries).mp hmem⟩
        | closedFunctionalEnum =>
          rw [hreg] at hok
          dsimp at hok
          cases hfunc : memDecListBool (cand.sort, cand.entityId, cand.decodedStr) closedFunctionalEntries with
          | false => rw [hfunc] at hok; contradiction
          | true =>
            rw [hfunc] at hok
            dsimp at hok
            injection hok with hp
            rw [← hp]
            refine ⟨rfl, ⟨hing_v, heid_v.1, heid_v.2, htrim_v,
                    fun hopen => by rw [hreg] at hopen; contradiction⟩,
                    fun hnum => by rw [hnum] at hreg; contradiction, ?_⟩
            unfold EntityCatalogBound
            rw [hreg]
            exact (memDecListBool_iff _ closedFunctionalEntries).mp hfunc
        | canonicalDecimal =>
          rw [hreg] at hok
          dsimp at hok
          cases hid_eq : (cand.entityId != cand.decodedStr) with
          | true => rw [hid_eq] at hok; contradiction
          | false =>
            rw [hid_eq] at hok
            dsimp at hok
            have heq_id : cand.entityId = cand.decodedStr := by simpa [bne_eq_false_iff_eq] using hid_eq
            cases hdec : parseCanonicalDecSurface numCfg cand.decodedStr with
            | error e => rw [hdec] at hok; contradiction
            | ok d =>
              rw [hdec] at hok
              injection hok with hp
              rw [← hp]
              refine ⟨rfl, ⟨hing_v, heid_v.1, heid_v.2, htrim_v,
                      fun hopen => by rw [hreg] at hopen; contradiction⟩,
                      fun _ => ⟨heq_id, d, parseCanonicalDecSurface_sound numCfg cand.decodedStr d hdec⟩, ?_⟩
              unfold EntityCatalogBound
              rw [hreg]
              trivial

theorem evalLexicalSlot_complete
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (hLex : LexicallyValid maxBytes cand)
    (hNum : NumericallyWellFormed numCfg cand)
    (hBound : EntityCatalogBound cat cand) :
    ∃ payload, evalLexicalSlot cat numCfg maxBytes cand = .ok payload := by
  rcases hLex with ⟨hing_v, heid_len, heid_ch, htrim_v, hdisj_v⟩
  have hing : checkStrictAsciiIngress maxBytes cand.rawBytes = .ok () :=
    (checkStrictAsciiIngress_iff maxBytes cand.rawBytes).mpr hing_v
  have heid : checkAsciiEntityIdBool cand.entityId = true :=
    (checkAsciiEntityIdBool_iff cand.entityId).mpr ⟨heid_len, heid_ch⟩
  have htrim : checkTrimmedSpacesBool cand.decodedStr.toList = true :=
    (checkTrimmedSpacesBool_iff cand.decodedStr.toList).mpr htrim_v
  unfold evalLexicalSlot
  rw [hing]
  simp only [heid, Bool.not_true, Bool.false_eq_true, ↓reduceIte, htrim]
  unfold EntityCatalogBound at hBound
  cases hreg : cand.sort.regime with
  | openEntityCatalog =>
    rw [hreg] at hBound
    dsimp at hBound ⊢
    rcases hBound with ⟨hcat_v, hmem_v⟩
    have hkw : findReservedDelimiter cand.decodedStr = none :=
      (findReservedDelimiter_eq_none_iff cand.decodedStr).mpr (hdisj_v hreg)
    have hcat : checkValidEntityCatalogBool cat = true :=
      (checkValidEntityCatalogBool_iff cat).mpr hcat_v
    have hmem : memDecListBool ⟨cand.sort, cand.entityId, cand.decodedStr⟩ cat.entries = true :=
      (memDecListBool_iff _ cat.entries).mpr hmem_v
    simp [hkw, hcat, hmem]
  | closedFunctionalEnum =>
    rw [hreg] at hBound
    dsimp at hBound ⊢
    have hfunc : memDecListBool (cand.sort, cand.entityId, cand.decodedStr) closedFunctionalEntries = true :=
      (memDecListBool_iff _ closedFunctionalEntries).mpr hBound
    simp [hfunc]
  | canonicalDecimal =>
    dsimp
    have hsort_num : cand.sort = .numericLit := by
      cases hs : cand.sort <;> simp [hs, P3SlotSort.regime] at hreg
      rfl
    rcases hNum hsort_num with ⟨heid_eq, d, hdec_spec⟩
    have hdec_ok : parseCanonicalDecSurface numCfg cand.decodedStr = .ok d :=
      parseCanonicalDecSurface_complete numCfg cand.decodedStr d hdec_spec
    simp [heid_eq, hdec_ok]

/--
  **Top-Level Strict Lexical Gate (`admitLexicalSlot`)**:
  Lifts `evalLexicalSlot` into the sealed proof-carrying `CertifiedLexicalSlot` witness (`private mk ::`).
-/
def admitLexicalSlot (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate) :
    LexicalSlotOutcome cat numCfg maxBytes cand :=
  match h : evalLexicalSlot cat numCfg maxBytes cand with
  | .error e      => .rejected e
  | .ok payload =>
    let hs := evalLexicalSlot_sound cat numCfg maxBytes cand payload h
    .accepted ⟨payload.1, payload.2, hs.1, hs.2.1, hs.2.2.1, hs.2.2.2⟩

/-! ### 7. Master Gate C Soundness & Relative Completeness Theorems -/

/--
  **Master Theorem (`admitLexicalSlot_sound` — Mandate §IV)**:
  `admitLexicalSlot cat numCfg maxBytes cand = .accepted w` implies:
    `LexicallyValid maxBytes cand ∧ NumericallyWellFormed numCfg cand ∧ EntityCatalogBound cat cand`
-/
theorem admitLexicalSlot_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (w : CertifiedLexicalSlot cat numCfg maxBytes cand)
    (_hAcc : admitLexicalSlot cat numCfg maxBytes cand = .accepted w) :
    w.verifiedStr = cand.decodedStr ∧
    LexicallyValid maxBytes cand ∧
    NumericallyWellFormed numCfg cand ∧
    EntityCatalogBound cat cand :=
  ⟨w.hStrEq, w.hLexValid, w.hNumValid, w.hCatBound⟩

/--
  **Relative Completeness (`admitLexicalSlot_complete`)**:
  Any candidate satisfying `LexicallyValid`, `NumericallyWellFormed`, and `EntityCatalogBound`
  is deterministically accepted by `admitLexicalSlot` (non-vacuity guarantee).
-/
theorem admitLexicalSlot_complete
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (hLex : LexicallyValid maxBytes cand)
    (hNum : NumericallyWellFormed numCfg cand)
    (hBound : EntityCatalogBound cat cand) :
    ∃ w : CertifiedLexicalSlot cat numCfg maxBytes cand,
      admitLexicalSlot cat numCfg maxBytes cand = .accepted w := by
  rcases evalLexicalSlot_complete cat numCfg maxBytes cand hLex hNum hBound with ⟨payload, hok⟩
  unfold admitLexicalSlot
  split
  · rename_i e herr
    rw [hok] at herr
    contradiction
  · exact ⟨_, rfl⟩

/-! ### 8. Grammar Rule & `readingAlt` Admission Gate (`Gate A` Executable Binding) -/

def verifyRuleReadingGate (requireGeneratorOnly : Bool) (r : CanonicalRuleId) (readingAlt : Nat) :
    Except LexicalRejectDiag Unit :=
  if requireGeneratorOnly && !r.isGeneratorRule then
    .error .parserOnlyTrapRuleInGenerator
  else if checkReadingSelectionBool r readingAlt then
    .ok ()
  else
    .error .invalidRuleOrReadingAlt

theorem verifyRuleReadingGate_sound (requireGeneratorOnly : Bool) (r : CanonicalRuleId) (readingAlt : Nat)
    (hok : verifyRuleReadingGate requireGeneratorOnly r readingAlt = .ok ()) :
    (requireGeneratorOnly = true → r.isGeneratorRule = true) ∧
    ValidReadingSelection r readingAlt := by
  unfold verifyRuleReadingGate at hok
  split at hok
  · contradiction
  · rename_i hnot_trap
    split at hok
    · rename_i hsel
      refine ⟨?_, (checkReadingSelectionBool_iff r readingAlt).mp hsel⟩
      intro hreq
      cases hg : r.isGeneratorRule
      · simp [hreq, hg] at hnot_trap
      · rfl
    · contradiction

end BrocaOmega.P3A
```

### 6.9 `03_counterexamples/P3Counterexamples.lean` (`SHA-256: 9FDF552CADD1E6FE8DA6F033D14963C4A9CADD8D1DB35478D6F9E4E0550041F3`)
```lean
import P3Counterexamples.P3ASuite
```

### 6.10 `03_counterexamples/P3Counterexamples/P3ASuite.lean` (`SHA-256: B647C78578277E07DC3B774E6EF5DFA5FE36935F4867AC14DC1861EEFCD6F327`)
```lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: 16 Symmetric `(PC, CE)` Pairs = 32 Vectors)
  03_counterexamples/P3Counterexamples/P3ASuite.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `native_decide`)

  Gate D Deliverable:
  Exercises `admitLexicalSlot` and `verifyRuleReadingGate` directly (exact proof-to-execution binding)
  across all numeric, UTF-8/ASCII, entity-catalog, surface-injectivity, keyword-barrier, and BNF
  trap/readingAlt boundaries specified in the `AUTH-C1-P3-A` Mandate.
-/
import P3DetachedChecker

namespace BrocaOmega.P3A.Counterexamples

/-- Pure kernel-reducible ASCII byte encoder for test vector construction (avoids opaque `@[extern]` `String.toUTF8`). -/
def strToUtf8Bytes (s : String) : List UInt8 :=
  s.toList.map (fun c => UInt8.ofNat c.toNat)

/-- Canonical surface-injective reference entity catalog for `P3-A` test vectors (`ValidEntityCatalog`). -/
def refValidCatalog : ClosedEntityCatalog :=
  { entries :=
      [ { sort := .cohortSpec,       entityId := "cohort_primary", lexeme := "the primary cohort" },
        { sort := .designNoun,       entityId := "design_rct",     lexeme := "randomized trial" },
        { sort := .designNoun,       entityId := "design_obs",     lexeme := "observational study" },
        { sort := .followUpWindow,   entityId := "win_24m",        lexeme := "24 months" },
        { sort := .eventTerm,        entityId := "evt_hf",         lexeme := "heart failure" },
        { sort := .measureTerm,      entityId := "meas_sbp",       lexeme := "systolic blood pressure" },
        { sort := .expLevel,         entityId := "exp_intensive",  lexeme := "intensive therapy" },
        { sort := .expLevel,         entityId := "exp_std",        lexeme := "standard care" },
        { sort := .outTerm,          entityId := "out_mi",         lexeme := "myocardial infarction" },
        { sort := .sourceId,         entityId := "src_trialA",     lexeme := "Trial-A" },
        { sort := .identAssump,      entityId := "assump_exch",    lexeme := "conditional exchangeability" },
        { sort := .subgroupPlural,   entityId := "sub_lowrisk",    lexeme := "low-risk" },
        { sort := .subgroupSingular, entityId := "sub_frail",      lexeme := "frail" },
        { sort := .covariateList,    entityId := "cov_age_hba1c",  lexeme := "age and baseline HbA1c" } ] }

/-- Poisoned catalog violating Global Surface Injectivity (`F-R2.2-02`): `"randomized trial"` in 2 sorts! -/
def poisonedAmbiguousCatalog : ClosedEntityCatalog :=
  { entries :=
      refValidCatalog.entries ++
      [ { sort := .cohortSpec, entityId := "cohort_dup_surf", lexeme := "randomized trial" } ] }

theorem refValidCatalog_is_valid : checkValidEntityCatalogBool refValidCatalog = true := by decide
theorem poisonedCatalog_is_invalid : checkValidEntityCatalogBool poisonedAmbiguousCatalog = false := by decide

/-- Unified test case covering both `admitLexicalSlot` and `verifyRuleReadingGate`. -/
inductive P3ATestPayload where
  | slotCheck
      (usePoisonedCat : Bool)
      (maxBytes       : Nat)
      (cand           : RawSlotCandidate)
  | ruleReadingCheck
      (requireGenOnly : Bool)
      (rule           : CanonicalRuleId)
      (readingAlt     : Nat)
  deriving DecidableEq, Repr

structure P3ATestCase where
  caseId       : String
  pairGroup    : String
  isPositive   : Bool
  payload      : P3ATestPayload
  expectedPass : Bool
  expectedDiag : Option LexicalRejectDiag
  deriving DecidableEq, Repr

/-- Executes the EXACT proved gate functions (`admitLexicalSlot` / `verifyRuleReadingGate`)! -/
def P3ATestCase.evalActual (tc : P3ATestCase) : Bool × Option LexicalRejectDiag :=
  match tc.payload with
  | .slotCheck usePoison maxB cand =>
    let cat := if usePoison then poisonedAmbiguousCatalog else refValidCatalog
    let out := admitLexicalSlot cat frozenR22NumericConfig maxB cand
    (out.isAccepted, out.diag?)
  | .ruleReadingCheck reqGen r alt =>
    match verifyRuleReadingGate reqGen r alt with
    | .ok ()   => (true, none)
    | .error d => (false, some d)

def P3ATestCase.runCheck (tc : P3ATestCase) : Bool :=
  let (acc, diagOpt) := tc.evalActual
  (acc == tc.expectedPass) && (diagOpt == tc.expectedDiag)

def mkNumSlot (eid s : String) : RawSlotCandidate :=
  { sort := .numericLit, entityId := eid, rawBytes := strToUtf8Bytes s }

def mkEntSlot (srt : P3SlotSort) (eid s : String) : RawSlotCandidate :=
  { sort := srt, entityId := eid, rawBytes := strToUtf8Bytes s }

/-! ### 16 Symmetric `(PC, CE)` Pairs (`32` Curated Vectors) -/

-- Pair 01: `1.25` vs `1..25` (Double decimal point — `F-P2-02`)
def pc01 : P3ATestCase :=
  { caseId := "PC-P3A-01", pairGroup := "PAIR-01-MULTI-DOT-1", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "1.25" "1.25"),
    expectedPass := true, expectedDiag := none }

def ce01 : P3ATestCase :=
  { caseId := "CE-P3A-01", pairGroup := "PAIR-01-MULTI-DOT-1", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "1..25" "1..25"),
    expectedPass := false, expectedDiag := some .multipleDecimalPoints }

-- Pair 02: `-1.25` vs `1.2.3` (Multi-segment decimal — `F-P2-02`)
def pc02 : P3ATestCase :=
  { caseId := "PC-P3A-02", pairGroup := "PAIR-02-MULTI-DOT-2", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "-1.25" "-1.25"),
    expectedPass := true, expectedDiag := none }

def ce02 : P3ATestCase :=
  { caseId := "CE-P3A-02", pairGroup := "PAIR-02-MULTI-DOT-2", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "1.2.3" "1.2.3"),
    expectedPass := false, expectedDiag := some .multipleDecimalPoints }

-- Pair 03: `0.0` vs `-0.0` (Negative zero ban — `F-C0-01`)
def pc03 : P3ATestCase :=
  { caseId := "PC-P3A-03", pairGroup := "PAIR-03-NEG-ZERO", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0.0" "0.0"),
    expectedPass := true, expectedDiag := none }

def ce03 : P3ATestCase :=
  { caseId := "CE-P3A-03", pairGroup := "PAIR-03-NEG-ZERO", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "-0.0" "-0.0"),
    expectedPass := false, expectedDiag := some .negativeZeroForbidden }

-- Pair 04: `1.0` vs `1.` (Trailing decimal point excluded by `S0-R2.2` `(\.[0-9]{1,4})?`)
def pc04 : P3ATestCase :=
  { caseId := "PC-P3A-04", pairGroup := "PAIR-04-TRAILING-DOT", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "1.0" "1.0"),
    expectedPass := true, expectedDiag := none }

def ce04 : P3ATestCase :=
  { caseId := "CE-P3A-04", pairGroup := "PAIR-04-TRAILING-DOT", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "1." "1."),
    expectedPass := false, expectedDiag := some .trailingDecimalPoint }

-- Pair 05: `0.25` vs `.25` (Leading decimal point)
def pc05 : P3ATestCase :=
  { caseId := "PC-P3A-05", pairGroup := "PAIR-05-LEADING-DOT", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0.25" "0.25"),
    expectedPass := true, expectedDiag := none }

def ce05 : P3ATestCase :=
  { caseId := "CE-P3A-05", pairGroup := "PAIR-05-LEADING-DOT", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot ".25" ".25"),
    expectedPass := false, expectedDiag := some .leadingDecimalPoint }

-- Pair 06: `128.4` vs `+1.25` (Explicit leading `+` sign policy)
def pc06 : P3ATestCase :=
  { caseId := "PC-P3A-06", pairGroup := "PAIR-06-EXPLICIT-PLUS", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "128.4" "128.4"),
    expectedPass := true, expectedDiag := none }

def ce06 : P3ATestCase :=
  { caseId := "CE-P3A-06", pairGroup := "PAIR-06-EXPLICIT-PLUS", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "+1.25" "+1.25"),
    expectedPass := false, expectedDiag := some .explicitPlusForbidden }

-- Pair 07: `0.002` vs `001.25` (Redundant leading zero)
def pc07 : P3ATestCase :=
  { caseId := "PC-P3A-07", pairGroup := "PAIR-07-LEADING-ZERO", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0.002" "0.002"),
    expectedPass := true, expectedDiag := none }

def ce07 : P3ATestCase :=
  { caseId := "CE-P3A-07", pairGroup := "PAIR-07-LEADING-ZERO", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "001.25" "001.25"),
    expectedPass := false, expectedDiag := some .redundantLeadingZero }

-- Pair 08: `0` vs `1e-3` (Scientific exponent notation)
def pc08 : P3ATestCase :=
  { caseId := "PC-P3A-08", pairGroup := "PAIR-08-EXPONENT", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0" "0"),
    expectedPass := true, expectedDiag := none }

def ce08 : P3ATestCase :=
  { caseId := "CE-P3A-08", pairGroup := "PAIR-08-EXPONENT", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "1e-3" "1e-3"),
    expectedPass := false, expectedDiag := some (.invalidNumericCharOrExponent 'e') }

-- Pair 09: `9999999.9999` vs `12345678.1` (`S0-R2.2` `(7, 4)` digit cap)
def pc09 : P3ATestCase :=
  { caseId := "PC-P3A-09", pairGroup := "PAIR-09-PRECISION-CAP", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "9999999.9999" "9999999.9999"),
    expectedPass := true, expectedDiag := none }

def ce09 : P3ATestCase :=
  { caseId := "CE-P3A-09", pairGroup := "PAIR-09-PRECISION-CAP", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "12345678.1" "12345678.1"),
    expectedPass := false, expectedDiag := some (.numericPrecisionBoundExceeded 8 1) }

-- Pair 10: Numeric `entityId == lexeme` vs Forged numeric `entityId`
def pc10 : P3ATestCase :=
  { caseId := "PC-P3A-10", pairGroup := "PAIR-10-NUMERIC-ID-BIND", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0.78" "0.78"),
    expectedPass := true, expectedDiag := none }

def ce10 : P3ATestCase :=
  { caseId := "CE-P3A-10", pairGroup := "PAIR-10-NUMERIC-ID-BIND", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "0.99" "0.78"),
    expectedPass := false, expectedDiag := some .numericEntityIdMismatch }

-- Pair 11: Valid `entityId` + `lexeme` vs Valid `lexeme` + Wrong `entityId` (Mandate §2.B)
def pc11 : P3ATestCase :=
  { caseId := "PC-P3A-11", pairGroup := "PAIR-11-WRONG-ENTITY-ID", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .expLevel "exp_intensive" "intensive therapy"),
    expectedPass := true, expectedDiag := none }

def ce11 : P3ATestCase :=
  { caseId := "CE-P3A-11", pairGroup := "PAIR-11-WRONG-ENTITY-ID", isPositive := false,
    payload := .slotCheck false 64 (mkEntSlot .expLevel "exp_std" "intensive therapy"),
    expectedPass := false, expectedDiag := some .entityCatalogMismatch }

-- Pair 12: Valid `entityId` + `SlotSort` vs Valid `entityId` + Wrong `SlotSort` (Mandate §2.B)
def pc12 : P3ATestCase :=
  { caseId := "PC-P3A-12", pairGroup := "PAIR-12-WRONG-SLOT-SORT", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .cohortSpec "cohort_primary" "the primary cohort"),
    expectedPass := true, expectedDiag := none }

def ce12 : P3ATestCase :=
  { caseId := "CE-P3A-12", pairGroup := "PAIR-12-WRONG-SLOT-SORT", isPositive := false,
    payload := .slotCheck false 64 (mkEntSlot .designNoun "cohort_primary" "the primary cohort"),
    expectedPass := false, expectedDiag := some .entityCatalogMismatch }

-- Pair 13: Clean open entity vs Syncategorematic keyword smuggling (`"did not"`)
def pc13 : P3ATestCase :=
  { caseId := "PC-P3A-13", pairGroup := "PAIR-13-KEYWORD-LEAK", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .outTerm "out_mi" "myocardial infarction"),
    expectedPass := true, expectedDiag := none }

def ce13 : P3ATestCase :=
  { caseId := "CE-P3A-13", pairGroup := "PAIR-13-KEYWORD-LEAK", isPositive := false,
    payload := .slotCheck false 64 (mkEntSlot .outTerm "out_mi" "infarction did not recur"),
    expectedPass := false, expectedDiag := some (.reservedKeywordLeak "did not") }

-- Pair 14: Printable 7-bit ASCII vs Cyrillic UTF-8 Homoglyph `'о'` (`0xD0, 0xBE` — `F-C0-03`)
def pc14 : P3ATestCase :=
  { caseId := "PC-P3A-14", pairGroup := "PAIR-14-UTF8-HOMOGLYPH", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .sourceId "src_trialA" "Trial-A"),
    expectedPass := true, expectedDiag := none }

def ce14 : P3ATestCase :=
  { caseId := "CE-P3A-14", pairGroup := "PAIR-14-UTF8-HOMOGLYPH", isPositive := false,
    payload := .slotCheck false 64
      { sort := .sourceId, entityId := "src_trialA",
        rawBytes := [0x54, 0x72, 0xD0, 0xBE, 0x61, 0x6C] }, -- 'T','r', Cyrillic 'о', 'a','l'
    expectedPass := false, expectedDiag := some (.nonPrintableAsciiOrInvalidUtf8 0xD0) }

-- Pair 15: Surface-Injective Catalog vs Cross-Sort Duplicate-Lexeme Catalog (`F-R2.2-02`)
def pc15 : P3ATestCase :=
  { caseId := "PC-P3A-15", pairGroup := "PAIR-15-CATALOG-INJECTIVITY", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .designNoun "design_rct" "randomized trial"),
    expectedPass := true, expectedDiag := none }

def ce15 : P3ATestCase :=
  { caseId := "CE-P3A-15", pairGroup := "PAIR-15-CATALOG-INJECTIVITY", isPositive := false,
    payload := .slotCheck true 64 (mkEntSlot .designNoun "design_rct" "randomized trial"),
    expectedPass := false, expectedDiag := some .invalidEntityCatalog }

-- Pair 16: `T2` Dual Reading (`alt=2` in parser) vs `T2` Claimed as Generator Rule (`Gate A`)
def pc16 : P3ATestCase :=
  { caseId := "PC-P3A-16", pairGroup := "PAIR-16-TRAP-READING-ALT", isPositive := true,
    payload := .ruleReadingCheck false .T2 2,
    expectedPass := true, expectedDiag := none }

def ce16 : P3ATestCase :=
  { caseId := "CE-P3A-16", pairGroup := "PAIR-16-TRAP-READING-ALT", isPositive := false,
    payload := .ruleReadingCheck true .T2 1,
    expectedPass := false, expectedDiag := some .parserOnlyTrapRuleInGenerator }

def allP3ACases : List P3ATestCase :=
  [ pc01, ce01, pc02, ce02, pc03, ce03, pc04, ce04,
    pc05, ce05, pc06, ce06, pc07, ce07, pc08, ce08,
    pc09, ce09, pc10, ce10, pc11, ce11, pc12, ce12,
    pc13, ce13, pc14, ce14, pc15, ce15, pc16, ce16 ]

/-- All 32 symmetric `(PC, CE)` vectors verified at compile time with pure `decide` (0 `native_decide`)! -/
theorem allP3ACases_verified : allP3ACases.all P3ATestCase.runCheck = true := by
  decide

end BrocaOmega.P3A.Counterexamples
```

### 6.11 `04_proof_obligations/P3ProofObligations.lean` (`SHA-256: 505E822FA9B27E79319D744F14825FDCF544FF27EB83DCEA52F8F9C72CBC55C3`)
```lean
import P3ProofObligations.PO_C1_P3A_LexicalAndBNF
```

### 6.12 `04_proof_obligations/P3ProofObligations/PO_C1_P3A_LexicalAndBNF.lean` (`SHA-256: 12C488A4E6AD9E989406692A43A2A01DE4475BC03859223B62233A5984F0F5E8`)
```lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: Proof Obligation & Held Status Ledger)
  04_proof_obligations/P3ProofObligations/PO_C1_P3A_LexicalAndBNF.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `sorry`, zero custom `axiom`)

  Canonical Export Ledger for `AUTH-C1-P3-A`:
    1. Gate A: `P3A_FrozenBNF_Acyclic`, `P3A_All21CanonicalRulesCovered`, `P3A_TrapPartitionSound`,
               `P3A_GeneratorBNF_Matches_P2`, `P3A_P2_Excludes_Traps`, `P3A_RuleReadingGate_Sound`
    2. Gate B/C: `P3A_StrictAsciiIngress_Sound`, `P3A_CanonicalDecimal_Sound`, `P3A_CanonicalDecimal_Complete`,
                 `P3A_RejectsMultiDot`, `P3A_RejectsTrailingDot`,
                 `P3A_StrictLexicalSlot_Sound`, `P3A_StrictLexicalSlot_Complete`
    3. Gate D: `P3A_All32CounterexamplePairs_Verified`
    4. Explicit Governance & Residual `HELD` / `NOT_AUTHORIZED` Locks (zero premature promotion).
-/
import P3FormalSpec
import P3DetachedChecker
import P3Counterexamples

namespace BrocaOmega.P3A.ProofObligations

/-! ### 1. Gate A — Independent Frozen BNF & `P2` Correspondence Theorems -/

theorem P3A_FrozenBNF_Acyclic :
    independentFrozenBNF.all isProductionAcyclicBool = true :=
  all_independentFrozenBNF_acyclic

theorem P3A_All21CanonicalRulesCovered (r : CanonicalRuleId) :
    isCanonicalRuleCoveredBool r = true :=
  all_21_canonical_rules_covered r

theorem P3A_TrapPartitionSound :
    independentFrozenBNF.all (fun p =>
      match p.canonicalOwner with
      | some r => p.isGenerator == r.isGeneratorRule
      | none   => true) = true :=
  trap_productions_never_in_generator

theorem P3A_GeneratorBNF_Matches_P2 :
    (generatorBNFSubset.map fun p => (p.lhs, p.rhs)) =
    (p2RuleSnapshots.map fun s => (s.lhs, s.rhs)) :=
  p3_generator_bnf_matches_p2_snapshots

theorem P3A_P2_Excludes_Traps :
    trapBNFSubset.all (fun tp =>
      p2RuleSnapshots.all (fun s => !((tp.lhs == s.lhs) && (tp.rhs == s.rhs)))) = true :=
  p2_snapshots_exclude_all_trap_productions

theorem P3A_RuleReadingGate_Sound (requireGeneratorOnly : Bool) (r : CanonicalRuleId) (readingAlt : Nat)
    (hok : verifyRuleReadingGate requireGeneratorOnly r readingAlt = .ok ()) :
    (requireGeneratorOnly = true → r.isGeneratorRule = true) ∧
    ValidReadingSelection r readingAlt :=
  verifyRuleReadingGate_sound requireGeneratorOnly r readingAlt hok

/-! ### 2. Gate B & Gate C — Strict Lexical, Decimal & Closed Catalog Soundness/Completeness -/

theorem P3A_StrictAsciiIngress_Sound (maxBytes : Nat) (rawBytes : List UInt8)
    (w : VerifiedIngressText maxBytes)
    (hok : admitStrictAsciiIngress maxBytes rawBytes = .ok w) :
    w.rawBytes = rawBytes ∧ StrictAsciiUTF8Valid maxBytes rawBytes :=
  admitStrictAsciiIngress_sound maxBytes rawBytes w hok

theorem P3A_CanonicalDecimal_Sound (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hok : parseCanonicalDecSurface cfg s = .ok d) :
    DecSurfaceSpec cfg s d :=
  parseCanonicalDecSurface_sound cfg s d hok

theorem P3A_CanonicalDecimal_Complete (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hspec : DecSurfaceSpec cfg s d) :
    parseCanonicalDecSurface cfg s = .ok d :=
  parseCanonicalDecSurface_complete cfg s d hspec

theorem P3A_RejectsMultiDot (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hmulti : 2 ≤ countChar '.' s.toList) :
    ¬ DecSurfaceSpec cfg s d :=
  decSurfaceSpec_rejects_multiple_dots cfg s d hmulti

theorem P3A_RejectsTrailingDot (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (htrail : s.toList.getLast? = some '.') :
    ¬ DecSurfaceSpec cfg s d :=
  decSurfaceSpec_rejects_trailing_dot cfg s d htrail

/--
  **Master `AUTH-C1-P3-A` Soundness Theorem (Mandate §IV)**:
  `Accepted(x) -> LexicallyValid(x) ∧ NumericallyWellFormed(x) ∧ EntityCatalogBound(x)`
-/
theorem P3A_StrictLexicalSlot_Sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (w : CertifiedLexicalSlot cat numCfg maxBytes cand)
    (hAcc : admitLexicalSlot cat numCfg maxBytes cand = .accepted w) :
    w.verifiedStr = cand.decodedStr ∧
    LexicallyValid maxBytes cand ∧
    NumericallyWellFormed numCfg cand ∧
    EntityCatalogBound cat cand :=
  admitLexicalSlot_sound cat numCfg maxBytes cand w hAcc

theorem P3A_StrictLexicalSlot_Complete
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (hLex : LexicallyValid maxBytes cand)
    (hNum : NumericallyWellFormed numCfg cand)
    (hBound : EntityCatalogBound cat cand) :
    ∃ w : CertifiedLexicalSlot cat numCfg maxBytes cand,
      admitLexicalSlot cat numCfg maxBytes cand = .accepted w :=
  admitLexicalSlot_complete cat numCfg maxBytes cand hLex hNum hBound

/-! ### 3. Gate D — Compile-Time Kernel Verification of 32 Symmetric Vectors -/

theorem P3A_All32CounterexamplePairs_Verified :
    Counterexamples.allP3ACases.all Counterexamples.P3ATestCase.runCheck = true :=
  Counterexamples.allP3ACases_verified

/-! ### 4. Explicit Governance & Residual `HELD` / `NOT_AUTHORIZED` Locks -/

inductive GateDisposition where
  | scopedLocalSourceVerified
  | evidenceSubmittedPendingTribunalHeld
  | heldExternalReplay
  | heldUnspecifiedInR0
  | notAuthorized
  deriving DecidableEq, Repr

def status_P1_ExternalReplay                : GateDisposition := .heldExternalReplay
def status_P2_ExternalReplay                : GateDisposition := .heldExternalReplay
def status_F_P2_01_FrozenGrammarEquivalence : GateDisposition := .evidenceSubmittedPendingTribunalHeld
def status_F_P2_02_LexicalAndEntityBinding  : GateDisposition := .evidenceSubmittedPendingTribunalHeld
def status_R0_G01CensoredSurface            : GateDisposition := .heldUnspecifiedInR0
def status_R0_ProductionOntologyEntries     : GateDisposition := .heldUnspecifiedInR0
def status_P3A_StrictLexicalAndBNF          : GateDisposition := .scopedLocalSourceVerified
def status_P3B_BoundedParser_PO_C1_01       : GateDisposition := .notAuthorized
def status_P3C_SemanticNorm_PO_C1_03        : GateDisposition := .notAuthorized
def status_P1C_Int128FastPath               : GateDisposition := .notAuthorized
def status_P4_ClinicalEvidence              : GateDisposition := .notAuthorized
def status_P5_SnapshotAdmission             : GateDisposition := .notAuthorized
def status_Pneuma_S3_S4_Integration         : GateDisposition := .notAuthorized

end BrocaOmega.P3A.ProofObligations
```

### 6.13 `05_independent_tribunal/P3ATribunalAudit.lean` (`SHA-256: 05CBF76C7F4F6BF0E4E88AEB2B14E1C92704169E6D47107689FBFC847254D086`)
```lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: Axiom Audit & Differential CLI Runner)
  05_independent_tribunal/P3ATribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  1. `#print axioms` audit across all 14 exported Gate A / Gate B / Gate C / Gate D theorems.
  2. Executable CLI (`p3a_tribunal_runner`):
     - Default mode: executes all 32 curated `(PC, CE)` vectors via `admitLexicalSlot` & `verifyRuleReadingGate`.
     - `--export-fixed-json`: serializes all 32 fixed vectors (with hex raw bytes) and Lean verdicts.
     - `--eval-batch <file>`: reads external hex-encoded serialized inputs generated by Python and
       evaluates each one through the EXACT proved Lean functions `admitLexicalSlot` / `verifyRuleReadingGate`,
       enabling true 1-to-1 `Result_Lean(x) = Result_Python(x)` differential testing on all mutated inputs!
-/
import P3FormalSpec
import P3DetachedChecker
import P3Counterexamples
import P3ProofObligations

/-! ### 1. Compile-Time Kernel Axiom Footprint Audit (`#print axioms`) -/

#print axioms BrocaOmega.P3A.ProofObligations.P3A_FrozenBNF_Acyclic
#print axioms BrocaOmega.P3A.ProofObligations.P3A_All21CanonicalRulesCovered
#print axioms BrocaOmega.P3A.ProofObligations.P3A_TrapPartitionSound
#print axioms BrocaOmega.P3A.ProofObligations.P3A_GeneratorBNF_Matches_P2
#print axioms BrocaOmega.P3A.ProofObligations.P3A_P2_Excludes_Traps
#print axioms BrocaOmega.P3A.ProofObligations.P3A_RuleReadingGate_Sound
#print axioms BrocaOmega.P3A.ProofObligations.P3A_StrictAsciiIngress_Sound
#print axioms BrocaOmega.P3A.ProofObligations.P3A_CanonicalDecimal_Sound
#print axioms BrocaOmega.P3A.ProofObligations.P3A_CanonicalDecimal_Complete
#print axioms BrocaOmega.P3A.ProofObligations.P3A_RejectsMultiDot
#print axioms BrocaOmega.P3A.ProofObligations.P3A_RejectsTrailingDot
#print axioms BrocaOmega.P3A.ProofObligations.P3A_StrictLexicalSlot_Sound
#print axioms BrocaOmega.P3A.ProofObligations.P3A_StrictLexicalSlot_Complete
#print axioms BrocaOmega.P3A.ProofObligations.P3A_All32CounterexamplePairs_Verified

namespace BrocaOmega.P3A.Tribunal

open BrocaOmega.P3A
open BrocaOmega.P3A.Counterexamples

/-! ### 2. Deterministic Diagnostic Tagging & Hex / JSON Codec -/

def diagTag : LexicalRejectDiag → String
  | .emptyRawBytes                    => "emptyRawBytes"
  | .inputLengthExceeded _ _          => "inputLengthExceeded"
  | .nonPrintableAsciiOrInvalidUtf8 _ => "nonPrintableAsciiOrInvalidUtf8"
  | .emptyOrNonAsciiEntityId          => "emptyOrNonAsciiEntityId"
  | .untrimmedOuterWhitespace         => "untrimmedOuterWhitespace"
  | .reservedKeywordLeak _            => "reservedKeywordLeak"
  | .explicitPlusForbidden            => "explicitPlusForbidden"
  | .leadingDecimalPoint              => "leadingDecimalPoint"
  | .trailingDecimalPoint             => "trailingDecimalPoint"
  | .multipleDecimalPoints            => "multipleDecimalPoints"
  | .invalidNumericCharOrExponent _   => "invalidNumericCharOrExponent"
  | .redundantLeadingZero             => "redundantLeadingZero"
  | .numericPrecisionBoundExceeded _ _ => "numericPrecisionBoundExceeded"
  | .negativeZeroForbidden            => "negativeZeroForbidden"
  | .numericEntityIdMismatch          => "numericEntityIdMismatch"
  | .invalidEntityCatalog             => "invalidEntityCatalog"
  | .entityCatalogMismatch            => "entityCatalogMismatch"
  | .closedFunctionalLexiconMismatch  => "closedFunctionalLexiconMismatch"
  | .invalidRuleOrReadingAlt          => "invalidRuleOrReadingAlt"
  | .parserOnlyTrapRuleInGenerator    => "parserOnlyTrapRuleInGenerator"

def nibbleToHex (n : Nat) : Char :=
  if n < 10 then Char.ofNat ('0'.toNat + n) else Char.ofNat ('a'.toNat + (n - 10))

def byteToHex (b : UInt8) : String :=
  let v := b.toNat
  String.ofList [nibbleToHex (v / 16), nibbleToHex (v % 16)]

def bytesToHex (bs : List UInt8) : String :=
  String.intercalate "" (bs.map byteToHex)

def hexCharVal? (c : Char) : Option Nat :=
  if '0' ≤ c && c ≤ '9' then some (c.toNat - '0'.toNat)
  else if 'a' ≤ c && c ≤ 'f' then some (10 + (c.toNat - 'a'.toNat))
  else if 'A' ≤ c && c ≤ 'F' then some (10 + (c.toNat - 'A'.toNat))
  else none

def decodeHexChars : List Char → Option (List UInt8)
  | [] => some []
  | c1 :: c2 :: rest =>
    match hexCharVal? c1, hexCharVal? c2, decodeHexChars rest with
    | some v1, some v2, some tail => some (UInt8.ofNat (v1 * 16 + v2) :: tail)
    | _, _, _ => none
  | [_] => none

def hexToBytes? (s : String) : Option (List UInt8) :=
  if s == "-" then some [] else decodeHexChars s.toList

def hexToAsciiString? (s : String) : Option String :=
  match hexToBytes? s with
  | some bs => some (String.ofList (bs.map (fun b => Char.ofNat b.toNat)))
  | none    => none

def sortToStr : P3SlotSort → String
  | .cohortSpec       => "cohortSpec"
  | .designNoun       => "designNoun"
  | .followUpWindow   => "followUpWindow"
  | .eventTerm        => "eventTerm"
  | .measureTerm      => "measureTerm"
  | .expLevel         => "expLevel"
  | .outTerm          => "outTerm"
  | .sourceId         => "sourceId"
  | .identAssump      => "identAssump"
  | .subgroupPlural   => "subgroupPlural"
  | .subgroupSingular => "subgroupSingular"
  | .covariateList    => "covariateList"
  | .assocDir         => "assocDir"
  | .ratioMetric      => "ratioMetric"
  | .intervDirVerb    => "intervDirVerb"
  | .intervVerbPres   => "intervVerbPres"
  | .epistemicVerb    => "epistemicVerb"
  | .whWord           => "whWord"
  | .numericLit       => "numericLit"

def parseSort? : String → Option P3SlotSort
  | "cohortSpec"       => some .cohortSpec
  | "designNoun"       => some .designNoun
  | "followUpWindow"   => some .followUpWindow
  | "eventTerm"        => some .eventTerm
  | "measureTerm"      => some .measureTerm
  | "expLevel"         => some .expLevel
  | "outTerm"          => some .outTerm
  | "sourceId"         => some .sourceId
  | "identAssump"      => some .identAssump
  | "subgroupPlural"   => some .subgroupPlural
  | "subgroupSingular" => some .subgroupSingular
  | "covariateList"    => some .covariateList
  | "assocDir"         => some .assocDir
  | "ratioMetric"      => some .ratioMetric
  | "intervDirVerb"    => some .intervDirVerb
  | "intervVerbPres"   => some .intervVerbPres
  | "epistemicVerb"    => some .epistemicVerb
  | "whWord"           => some .whWord
  | "numericLit"       => some .numericLit
  | _                  => none

def ruleIdToStr : CanonicalRuleId → String
  | .G01 => "G01" | .G02 => "G02" | .G03 => "G03" | .G04 => "G04"
  | .G05 => "G05" | .G06 => "G06" | .G07 => "G07" | .G08 => "G08"
  | .G09 => "G09" | .G10 => "G10" | .G11 => "G11" | .G12 => "G12"
  | .G13 => "G13" | .G14 => "G14" | .G15 => "G15" | .G16 => "G16"
  | .T1  => "T1"  | .T2  => "T2"  | .T3  => "T3"  | .T4  => "T4"  | .T5 => "T5"

def parseRuleId? : String → Option CanonicalRuleId
  | "G01" => some .G01 | "G02" => some .G02 | "G03" => some .G03 | "G04" => some .G04
  | "G05" => some .G05 | "G06" => some .G06 | "G07" => some .G07 | "G08" => some .G08
  | "G09" => some .G09 | "G10" => some .G10 | "G11" => some .G11 | "G12" => some .G12
  | "G13" => some .G13 | "G14" => some .G14 | "G15" => some .G15 | "G16" => some .G16
  | "T1"  => some .T1  | "T2"  => some .T2  | "T3"  => some .T3  | "T4"  => some .T4  | "T5" => some .T5
  | _     => none

def escapeJsonChars : List Char → List Char
  | [] => []
  | '"' :: cs  => '\\' :: '"' :: escapeJsonChars cs
  | '\\' :: cs => '\\' :: '\\' :: escapeJsonChars cs
  | '\n' :: cs => '\\' :: 'n' :: escapeJsonChars cs
  | c :: cs    => c :: escapeJsonChars cs

def jStr (s : String) : String :=
  "\"" ++ String.ofList (escapeJsonChars s.toList) ++ "\""

def jBool (b : Bool) : String := if b then "true" else "false"

def fixedCaseToJson (tc : P3ATestCase) : String :=
  let (acc, dOpt) := tc.evalActual
  let dTag := match dOpt with | none => "NONE" | some d => diagTag d
  let payloadJson := match tc.payload with
    | .slotCheck usePoison maxB cand =>
      let eidHex := bytesToHex (strToUtf8Bytes cand.entityId)
      let rawHex := bytesToHex cand.rawBytes
      "{\"kind\":\"SLOT\",\"usePoisonedCat\":" ++ jBool usePoison ++
      ",\"maxBytes\":" ++ toString maxB ++
      ",\"sort\":" ++ jStr (sortToStr cand.sort) ++
      ",\"entityIdHex\":" ++ jStr (if eidHex.isEmpty then "-" else eidHex) ++
      ",\"rawBytesHex\":" ++ jStr (if rawHex.isEmpty then "-" else rawHex) ++ "}"
    | .ruleReadingCheck reqGen r alt =>
      "{\"kind\":\"RULE\",\"requireGenOnly\":" ++ jBool reqGen ++
      ",\"rule\":" ++ jStr (ruleIdToStr r) ++
      ",\"readingAlt\":" ++ toString alt ++ "}"
  "{\"caseId\":" ++ jStr tc.caseId ++
  ",\"pairGroup\":" ++ jStr tc.pairGroup ++
  ",\"isPositive\":" ++ jBool tc.isPositive ++
  ",\"payload\":" ++ payloadJson ++
  ",\"leanAccepted\":" ++ jBool acc ++
  ",\"leanDiagTag\":" ++ jStr dTag ++ "}"

/-- Evaluates a single tab-separated batch record through `admitLexicalSlot` / `verifyRuleReadingGate`. -/
def evalBatchLine (line : String) : Option String :=
  let fields := line.splitOn "\t"
  match fields with
  | ["SLOT", caseId, poisonStr, maxBStr, sortStr, eidHex, rawHex] =>
    match maxBStr.toNat?, parseSort? sortStr, hexToAsciiString? eidHex, hexToBytes? rawHex with
    | some maxB, some srt, some eid, some rawBs =>
      let usePoison := poisonStr == "1"
      let cat := if usePoison then poisonedAmbiguousCatalog else refValidCatalog
      let cand : RawSlotCandidate := { sort := srt, entityId := eid, rawBytes := rawBs }
      let out := admitLexicalSlot cat frozenR22NumericConfig maxB cand
      let dTag := match out.diag? with | none => "NONE" | some d => diagTag d
      some ("{\"caseId\":" ++ jStr caseId ++
            ",\"leanAccepted\":" ++ jBool out.isAccepted ++
            ",\"leanDiagTag\":" ++ jStr dTag ++ "}")
    | _, _, _, _ => none
  | ["RULE", caseId, reqGenStr, ruleStr, altStr] =>
    match parseRuleId? ruleStr, altStr.toNat? with
    | some r, some alt =>
      let reqGen := reqGenStr == "1"
      let (acc, dTag) := match verifyRuleReadingGate reqGen r alt with
        | .ok ()   => (true, "NONE")
        | .error d => (false, diagTag d)
      some ("{\"caseId\":" ++ jStr caseId ++
            ",\"leanAccepted\":" ++ jBool acc ++
            ",\"leanDiagTag\":" ++ jStr dTag ++ "}")
    | _, _ => none
  | _ => none

end BrocaOmega.P3A.Tribunal

def main (args : List String) : IO UInt32 := do
  match args with
  | ["--export-fixed-json"] =>
    let items := BrocaOmega.P3A.Counterexamples.allP3ACases.map BrocaOmega.P3A.Tribunal.fixedCaseToJson
    IO.println ("[" ++ String.intercalate "," items ++ "]")
    return 0
  | ["--eval-batch", batchPath] =>
    let content ← IO.FS.readFile batchPath
    let stripCr := fun (s : String) => String.ofList (s.toList.filter (fun c => c != '\r'))
    let rawLines := (content.splitOn "\n").map stripCr |>.filter (fun l => !l.isEmpty)
    let mut results : List String := []
    for line in rawLines do
      match BrocaOmega.P3A.Tribunal.evalBatchLine line with
      | some resJson => results := resJson :: results
      | none =>
        IO.eprintln s!"BATCH_PARSE_ERROR: {line}"
        return 2
    IO.println ("[" ++ String.intercalate "," results.reverse ++ "]")
    return 0
  | _ =>
    let cases := BrocaOmega.P3A.Counterexamples.allP3ACases
    IO.println "=========================================================================="
    IO.println "BROCA-NATIVE OMEGA — AUTH-C1-P3-A STRICT LEXICAL & FROZEN BNF VERIFICATION"
    IO.println "Scope     : Independent Frozen BNF + Strict Lexical Gate (P3-A ONLY)"
    IO.println "Toolchain : Lean 4.33.1 Core (Init only, 0 external deps, 0 sorry)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for tc in cases do
      let ok := tc.runCheck
      let (acc, dOpt) := tc.evalActual
      let statusStr := if ok then "PASS" else "FAIL"
      let outcomeStr := if acc then "ACCEPTED" else
        let t := match dOpt with | none => "NONE" | some d => BrocaOmega.P3A.Tribunal.diagTag d
        s!"REJECTED ({t})"
      IO.println s!"[{statusStr}] {tc.caseId} ({tc.pairGroup}) => {outcomeStr}"
      if ok then passCount := passCount + 1
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"SUMMARY: {passCount} / {cases.length} symmetric (PC, CE) vectors verified."
    IO.println "Inherited HELD : P1_EXTERNAL_REPLAY_HELD, P2_EXTERNAL_REPLAY_HELD"
    IO.println "Audit Evidence : F-P2-01 & F-P2-02 submitted (HELD pending Tribunal ruling)"
    IO.println "Not Authorized : P1-C, P3-B, P3-C, P4, P5, Pneuma-S3/S4"
    IO.println "=========================================================================="
    return (if passCount == cases.length then 0 else 1)
```

### 6.14 `05_independent_tribunal/differential_oracle_p3a.py` (`SHA-256: 3513A3125DC504E66768D7E58C2445292AEFE2CE061AAD80A1B6D35FEE7F5B8C`)
```python
#!/usr/bin/env python3
"""
BROCA-NATIVE OMEGA — AUTH-C1-P3-A (`P3_LexicalGrammar`: Differential Oracle & P2 Disk Audit)
05_independent_tribunal/differential_oracle_p3a.py

Clean-room Python 3.11 differential verification harness (`Gate D` / Mandate §V):
1. Cross-verifies `P2CorrespondenceAudit.lean`'s 27-entry `p2RuleSnapshots` directly against
   `P2_DerivationReplay/01_formal_spec/P2FormalSpec/GrammarG16.lean` on disk (read-only).
2. Verifies 1-to-1 `Result_Lean(x) == Result_Python(x)` differential parity on all 32 fixed
   `(PC, CE)` vectors exported by `p3a_tribunal_runner.exe --export-fixed-json`.
3. Generates 300 deterministic serialized vectors (`seed = 2026112203`: 240 adversarial
   mutations + 60 valid boundary cases), feeds the EXACT SAME serialized batch file to BOTH
   `p3a_tribunal_runner.exe --eval-batch` and the Python clean-room oracle, and separately
   reports Lean<->Python parity, Lean rejection rate, and Python rejection rate.
"""

from __future__ import annotations

import json
import pathlib
import random
import re
import subprocess
import sys
import tempfile
from typing import Any

OPEN_SORTS = {
    "cohortSpec", "designNoun", "followUpWindow", "eventTerm", "measureTerm",
    "expLevel", "outTerm", "sourceId", "identAssump", "subgroupPlural",
    "subgroupSingular", "covariateList",
}

CLOSED_FUNC_ENTRIES = {
    ("assocDir", "positively", "positively"),
    ("assocDir", "inversely", "inversely"),
    ("ratioMetric", "rr", "risk ratio"),
    ("ratioMetric", "or", "odds ratio"),
    ("ratioMetric", "hr", "hazard ratio"),
    ("intervDirVerb", "increase", "increase"),
    ("intervDirVerb", "reduce", "reduce"),
    ("intervVerbPres", "causes", "causes"),
    ("intervVerbPres", "increases", "increases"),
    ("intervVerbPres", "reduces", "reduces"),
    ("epistemicVerb", "establish", "establish"),
    ("epistemicVerb", "determine", "determine"),
    ("epistemicVerb", "confirm", "confirm"),
    ("epistemicVerb", "reveal", "reveal"),
    ("whWord", "why", "why"),
    ("whWord", "how", "how"),
}

RESERVED_DELIMITERS = [
    ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same",
    "In ", " why ", " how ",
]

REF_VALID_CATALOG = [
    ("cohortSpec", "cohort_primary", "the primary cohort"),
    ("designNoun", "design_rct", "randomized trial"),
    ("designNoun", "design_obs", "observational study"),
    ("followUpWindow", "win_24m", "24 months"),
    ("eventTerm", "evt_hf", "heart failure"),
    ("measureTerm", "meas_sbp", "systolic blood pressure"),
    ("expLevel", "exp_intensive", "intensive therapy"),
    ("expLevel", "exp_std", "standard care"),
    ("outTerm", "out_mi", "myocardial infarction"),
    ("sourceId", "src_trialA", "Trial-A"),
    ("identAssump", "assump_exch", "conditional exchangeability"),
    ("subgroupPlural", "sub_lowrisk", "low-risk"),
    ("subgroupSingular", "sub_frail", "frail"),
    ("covariateList", "cov_age_hba1c", "age and baseline HbA1c"),
]

POISONED_CATALOG = REF_VALID_CATALOG + [
    ("cohortSpec", "cohort_dup_surf", "randomized trial"),
]

RULE_ALT_COUNTS = {
    **{f"G{i:02d}": 1 for i in range(1, 17)},
    "T1": 2, "T2": 2, "T3": 1, "T4": 2, "T5": 1,
}

MAX_INT_DIGITS = 7
MAX_FRAC_DIGITS = 4


def decode_hex_bytes(h: str) -> bytes:
    if h == "-":
        return b""
    return bytes.fromhex(h)


def decode_hex_ascii_str(h: str) -> str:
    bs = decode_hex_bytes(h)
    return "".join(chr(b) for b in bs)


def encode_hex_bytes(bs: bytes) -> str:
    return bs.hex() if bs else "-"


def py_valid_catalog(entries: list[tuple[str, str, str]]) -> bool:
    for srt, eid, lex in entries:
        if srt not in OPEN_SORTS:
            return False
        if not eid or not all(0x20 <= ord(c) <= 0x7E for c in eid):
            return False
        if not lex or lex[0] == " " or lex[-1] == " ":
            return False
        if not all(0x20 <= ord(c) <= 0x7E for c in lex):
            return False
        if any(bad in lex for bad in RESERVED_DELIMITERS):
            return False
    # Key uniqueness & global canonical surface injectivity (`F-R2.2-02`)
    for i, e1 in enumerate(entries):
        for j, e2 in enumerate(entries):
            if e1[0] == e2[0] and e1[1] == e2[1] and e1[2] != e2[2]:
                return False
            if e1[2] == e2[2] and e1 != e2:
                return False
    return True


def py_parse_canonical_decimal(s: str) -> tuple[bool, str]:
    if not s:
        return False, "invalidNumericCharOrExponent"
    if s[0] == "+":
        return False, "explicitPlusForbidden"
    if s[0] == "-":
        neg = True
        body = s[1:]
    else:
        neg = False
        body = s
    if not body:
        return False, "invalidNumericCharOrExponent"
    for ch in body:
        if not ("0" <= ch <= "9" or ch == "."):
            return False, "invalidNumericCharOrExponent"
    dot_count = body.count(".")
    if dot_count >= 2:
        return False, "multipleDecimalPoints"
    if dot_count == 0:
        int_cs, frac_cs = body, ""
        if not int_cs:
            return False, "leadingDecimalPoint"
        if len(int_cs) > 1 and int_cs[0] == "0":
            return False, "redundantLeadingZero"
        if len(int_cs) > MAX_INT_DIGITS:
            return False, "numericPrecisionBoundExceeded"
        if neg and int(int_cs) == 0:
            return False, "negativeZeroForbidden"
        return True, "NONE"
    # dot_count == 1
    int_cs, frac_cs = body.split(".", 1)
    if not int_cs:
        return False, "leadingDecimalPoint"
    if not frac_cs:
        return False, "trailingDecimalPoint"
    if len(int_cs) > 1 and int_cs[0] == "0":
        return False, "redundantLeadingZero"
    if len(int_cs) > MAX_INT_DIGITS or len(frac_cs) > MAX_FRAC_DIGITS:
        return False, "numericPrecisionBoundExceeded"
    if neg and int(int_cs + frac_cs) == 0:
        return False, "negativeZeroForbidden"
    return True, "NONE"


def py_eval_slot(
    use_poisoned: bool,
    max_bytes: int,
    sort_name: str,
    eid_str: str,
    raw_bytes: bytes,
) -> tuple[bool, str]:
    if len(raw_bytes) == 0:
        return False, "emptyRawBytes"
    if len(raw_bytes) > max_bytes:
        return False, "inputLengthExceeded"
    for b in raw_bytes:
        if not (0x20 <= b <= 0x7E):
            return False, "nonPrintableAsciiOrInvalidUtf8"
    if not eid_str or not all(0x20 <= ord(c) <= 0x7E for c in eid_str):
        return False, "emptyOrNonAsciiEntityId"
    s = "".join(chr(b) for b in raw_bytes)
    if not s or s[0] == " " or s[-1] == " ":
        return False, "untrimmedOuterWhitespace"

    if sort_name in OPEN_SORTS:
        for bad in RESERVED_DELIMITERS:
            if bad in s:
                return False, "reservedKeywordLeak"
        cat = POISONED_CATALOG if use_poisoned else REF_VALID_CATALOG
        if not py_valid_catalog(cat):
            return False, "invalidEntityCatalog"
        if (sort_name, eid_str, s) in cat:
            return True, "NONE"
        return False, "entityCatalogMismatch"

    if sort_name == "numericLit":
        if eid_str != s:
            return False, "numericEntityIdMismatch"
        return py_parse_canonical_decimal(s)

    # Closed functional enum
    if (sort_name, eid_str, s) in CLOSED_FUNC_ENTRIES:
        return True, "NONE"
    return False, "closedFunctionalLexiconMismatch"


def py_eval_rule(req_gen_only: bool, rule_name: str, reading_alt: int) -> tuple[bool, str]:
    is_gen = rule_name.startswith("G")
    if req_gen_only and not is_gen:
        return False, "parserOnlyTrapRuleInGenerator"
    alt_max = RULE_ALT_COUNTS[rule_name]
    if 1 <= reading_alt <= alt_max:
        return True, "NONE"
    return False, "invalidRuleOrReadingAlt"


def verify_p2_disk_snapshot_fidelity(gate_root: pathlib.Path) -> tuple[int, int]:
    """Read-only verification that P3's p2RuleSnapshots matches P2's GrammarG16.lean on disk."""
    p2_grammar = (
        gate_root / "P2_DerivationReplay" / "01_formal_spec" / "P2FormalSpec" / "GrammarG16.lean"
    ).read_text(encoding="utf-8")
    p3_audit = (
        gate_root / "P3_LexicalGrammar" / "01_formal_spec" / "P3FormalSpec" / "P2CorrespondenceAudit.lean"
    ).read_text(encoding="utf-8")

    # Extract `(ruleName -> code)` specifically from `def FrozenGenRule.toCode`
    tocode_section = p2_grammar.split("def FrozenGenRule.toCode")[1].split("def decodeFrozenRule")[0]
    p2_code_matches = re.findall(r"\|\s*\.([A-Za-z0-9_]+)\s*=>\s*(\d+)", tocode_section)
    p2_codes = {name: int(code) for name, code in p2_code_matches}

    # Extract `(p2Code, p2Name)` from P3 `p2RuleSnapshots`
    p3_snap_matches = re.findall(
        r"p2Code\s*:=\s*(\d+),\s*p2Name\s*:=\s*\"([A-Za-z0-9_]+)\"", p3_audit
    )
    p3_snaps = {name: int(code) for code, name in p3_snap_matches}

    if p2_codes != p3_snaps or len(p2_codes) != 27:
        raise RuntimeError(f"P2 code mismatch: disk={p2_codes} vs p3={p3_snaps}")

    # Also check every literal terminal string `.lit "..."` per rule in P2 matches `.term "..."` in P3
    matched = 0
    for name in sorted(p2_codes):
        p2_block_m = re.search(
            rf"\|\s*\.{name}\s*=>\s*\{{(.*?)(?=\n\s*\|\s*\.|\n/-!)", p2_grammar, re.S
        )
        p3_block_m = re.search(
            rf'p2Name\s*:=\s*"{name}".*?rhs\s*:=\s*\[(.*?)\]\s*\}}', p3_audit, re.S
        )
        if not p2_block_m or not p3_block_m:
            raise RuntimeError(f"Could not locate rule block for {name}")
        p2_lits = re.findall(r'\.lit\s+"([^"]*)"', p2_block_m.group(1))
        p3_terms = re.findall(r'\.term\s+"([^"]*)"', p3_block_m.group(1))
        p2_slots = re.findall(r"\.slot\s+\.([A-Za-z0-9_]+)\s+\.([A-Za-z0-9_]+)", p2_block_m.group(1))
        p3_slots = re.findall(r"\.lexSlot\s+\.([A-Za-z0-9_]+)\s+\.([A-Za-z0-9_]+)", p3_block_m.group(1))
        if p2_lits != p3_terms or p2_slots != p3_slots:
            raise RuntimeError(
                f"Segment mismatch on {name}: P2=({p2_lits}, {p2_slots}) vs P3=({p3_terms}, {p3_slots})"
            )
        matched += 1
    return matched, 27


def generate_mutation_batch(seed: int = 2026112203) -> list[dict[str, Any]]:
    """Generates 240 adversarial mutations + 60 valid boundary cases = 300 serialized records."""
    rng = random.Random(seed)
    records: list[dict[str, Any]] = []

    # 60 valid boundary records (numbers, open catalog entries, closed functional entries, valid rules)
    for i in range(60):
        kind_mod = i % 4
        cid = f"MUT-VALID-{i+1:03d}"
        if kind_mod == 0:
            int_val = rng.randint(0, 9999999)
            frac_len = rng.randint(0, 4)
            if frac_len == 0:
                s = f"-{int_val}" if (int_val > 0 and i % 2 == 1) else f"{int_val}"
            else:
                frac = "".join(str(rng.randint(0, 9)) for _ in range(frac_len))
                neg_ok = (int_val > 0 or int(frac) > 0) and (i % 2 == 1)
                s = f"-{int_val}.{frac}" if neg_ok else f"{int_val}.{frac}"
            records.append({
                "caseId": cid, "adversarial": False,
                "tsv": f"SLOT\t{cid}\t0\t64\tnumericLit\t{encode_hex_bytes(s.encode('ascii'))}\t{encode_hex_bytes(s.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, "numericLit", s, s.encode("ascii")),
            })
        elif kind_mod == 1:
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            records.append({
                "caseId": cid, "adversarial": False,
                "tsv": f"SLOT\t{cid}\t0\t64\t{srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, srt, eid, lex.encode("ascii")),
            })
        elif kind_mod == 2:
            func_list = sorted(CLOSED_FUNC_ENTRIES)
            srt, eid, lex = func_list[i % len(func_list)]
            records.append({
                "caseId": cid, "adversarial": False,
                "tsv": f"SLOT\t{cid}\t0\t64\t{srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, srt, eid, lex.encode("ascii")),
            })
        else:
            rname = rng.choice(list(RULE_ALT_COUNTS.keys()))
            req_gen = rname.startswith("G")
            alt = rng.randint(1, RULE_ALT_COUNTS[rname])
            records.append({
                "caseId": cid, "adversarial": False,
                "tsv": f"RULE\t{cid}\t{1 if req_gen else 0}\t{rname}\t{alt}",
                "pyArgs": ("RULE", req_gen, rname, alt),
            })

    # 240 adversarial mutations across 12 distinct attack classes (20 each)
    bad_Numerics = [
        "1..25", "0..5", "1.2.3", "12.34.56", "1.", "99.", ".25", "-.5",
        "+1.25", "+0", "00", "001.25", "-00.1", "-0", "-0.0", "-0.000",
        "1e-3", "2E4", "12345678", "1.12345",
    ]
    for i in range(240):
        cid = f"MUT-ADV-{i+1:03d}"
        cls = i % 12
        if cls in (0, 1, 2):
            s = bad_Numerics[(i // 3) % len(bad_Numerics)]
            raw = s.encode("ascii")
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\tnumericLit\t{encode_hex_bytes(raw)}\t{encode_hex_bytes(raw)}",
                "pyArgs": ("SLOT", False, 64, "numericLit", s, raw),
            })
        elif cls == 3:
            # Numeric entityId mismatch
            s = f"{rng.randint(1, 99)}.{rng.randint(0, 9)}"
            eid = s + "0"
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\tnumericLit\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(s.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, "numericLit", eid, s.encode("ascii")),
            })
        elif cls == 4:
            # Valid lexeme + wrong entityId
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            wrong_eid = eid + "_forged"
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\t{srt}\t{encode_hex_bytes(wrong_eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, srt, wrong_eid, lex.encode("ascii")),
            })
        elif cls == 5:
            # Valid entityId & lexeme + wrong SlotSort
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            other_sorts = [x for x in sorted(OPEN_SORTS) if x != srt]
            wrong_srt = other_sorts[i % len(other_sorts)]
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\t{wrong_srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, wrong_srt, eid, lex.encode("ascii")),
            })
        elif cls == 6:
            # Reserved syncategorematic delimiter leak
            kw = RESERVED_DELIMITERS[i % len(RESERVED_DELIMITERS)]
            lex = f"entity {kw} tail".strip()
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\texpLevel\t{encode_hex_bytes(b'exp_intensive')}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, "expLevel", "exp_intensive", lex.encode("ascii")),
            })
        elif cls == 7:
            # Non-ASCII / invalid UTF-8 / control bytes (`0x00`, `0x09`, `0x7F`, `0xD0 0xBE`, `0xFF`)
            bad_byte = rng.choice([0x00, 0x09, 0x0A, 0x1F, 0x7F, 0x80, 0xD0, 0xFF])
            raw = b"Trial" + bytes([bad_byte]) + b"A"
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\tsourceId\t{encode_hex_bytes(b'src_trialA')}\t{encode_hex_bytes(raw)}",
                "pyArgs": ("SLOT", False, 64, "sourceId", "src_trialA", raw),
            })
        elif cls == 8:
            # Untrimmed leading/trailing space or empty raw bytes
            raw = b"" if i % 2 == 0 else b" intensive therapy"
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\texpLevel\t{encode_hex_bytes(b'exp_intensive')}\t{encode_hex_bytes(raw)}",
                "pyArgs": ("SLOT", False, 64, "expLevel", "exp_intensive", raw),
            })
        elif cls == 9:
            # Poisoned catalog violating Global Surface Injectivity (`F-R2.2-02`)
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t1\t64\t{srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", True, 64, srt, eid, lex.encode("ascii")),
            })
        elif cls == 10:
            # Input byte length exceeding budget `maxBytes = 4`
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t4\t{srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 4, srt, eid, lex.encode("ascii")),
            })
        else:
            # Trap rule in generator OR invalid readingAlt (`0` or `> altCount`)
            if i % 2 == 0:
                trap = rng.choice(["T1", "T2", "T3", "T4", "T5"])
                records.append({
                    "caseId": cid, "adversarial": True,
                    "tsv": f"RULE\t{cid}\t1\t{trap}\t1",
                    "pyArgs": ("RULE", True, trap, 1),
                })
            else:
                rname = rng.choice(list(RULE_ALT_COUNTS.keys()))
                bad_alt = 0 if (i // 2) % 2 == 0 else RULE_ALT_COUNTS[rname] + 1
                records.append({
                    "caseId": cid, "adversarial": True,
                    "tsv": f"RULE\t{cid}\t0\t{rname}\t{bad_alt}",
                    "pyArgs": ("RULE", False, rname, bad_alt),
                })

    return records


def main() -> int:
    p3_root = pathlib.Path(__file__).resolve().parent.parent
    gate_root = p3_root.parent
    exe_path = p3_root / ".lake" / "build" / "bin" / "p3a_tribunal_runner.exe"
    if not exe_path.exists():
        print(f"ERROR: Missing executable {exe_path}", file=sys.stderr)
        return 2

    # 1. Read-only disk audit of P2 GrammarG16.lean vs P3 P2CorrespondenceAudit.lean
    p2_matched, p2_total = verify_p2_disk_snapshot_fidelity(gate_root)

    # 2. Fixed 32-vector suite 1-to-1 differential check
    fixed_proc = subprocess.run([str(exe_path), "--export-fixed-json"], capture_output=True, text=True, check=True)
    fixed_cases: list[dict[str, Any]] = json.loads(fixed_proc.stdout)

    print("==========================================================================")
    print("PYTHON 3.11 INDEPENDENT DIFFERENTIAL ORACLE — BROCA-NATIVE OMEGA P3-A")
    print(f"Read-Only P2 Disk Snapshot Verification : {p2_matched} / {p2_total} EXACT RULE MATCH")
    print("==========================================================================")

    fixed_mismatches = 0
    for tc in fixed_cases:
        pl = tc["payload"]
        if pl["kind"] == "SLOT":
            py_acc, py_tag = py_eval_slot(
                pl["usePoisonedCat"],
                pl["maxBytes"],
                pl["sort"],
                decode_hex_ascii_str(pl["entityIdHex"]),
                decode_hex_bytes(pl["rawBytesHex"]),
            )
        else:
            py_acc, py_tag = py_eval_rule(pl["requireGenOnly"], pl["rule"], pl["readingAlt"])

        lean_acc = tc["leanAccepted"]
        lean_tag = tc["leanDiagTag"]
        ok = (py_acc == lean_acc) and (py_tag == lean_tag)
        mark = "PARITY_OK" if ok else "MISMATCH"
        print(f"[{mark}] {tc['caseId']} | Lean=({lean_acc}, {lean_tag}) | Python=({py_acc}, {py_tag})")
        if not ok:
            fixed_mismatches += 1

    # 3. True bidirectional 300-vector serialized batch differential test (`Lean <-> Python` 1:1!)
    batch_records = generate_mutation_batch(seed=2026112203)
    with tempfile.TemporaryDirectory() as tmpdir:
        tsv_path = pathlib.Path(tmpdir) / "p3a_batch_300.tsv"
        tsv_path.write_text("\n".join(r["tsv"] for r in batch_records) + "\n", encoding="utf-8")
        batch_proc = subprocess.run(
            [str(exe_path), "--eval-batch", str(tsv_path)],
            capture_output=True, text=True, check=True,
        )
        lean_batch_out: list[dict[str, Any]] = json.loads(batch_proc.stdout)

    assert len(lean_batch_out) == len(batch_records), "Batch output count mismatch!"
    batch_mismatches = 0
    lean_adv_rej = 0
    py_adv_rej = 0
    adv_total = 0
    lean_val_acc = 0
    py_val_acc = 0
    val_total = 0

    for rec, lean_res in zip(batch_records, lean_batch_out):
        assert rec["caseId"] == lean_res["caseId"]
        args = rec["pyArgs"]
        if args[0] == "SLOT":
            py_acc, py_tag = py_eval_slot(args[1], args[2], args[3], args[4], args[5])
        else:
            py_acc, py_tag = py_eval_rule(args[1], args[2], args[3])

        lean_acc = lean_res["leanAccepted"]
        lean_tag = lean_res["leanDiagTag"]
        if (py_acc != lean_acc) or (py_tag != lean_tag):
            batch_mismatches += 1
            print(f"[BATCH_MISMATCH] {rec['caseId']}: Lean=({lean_acc}, {lean_tag}) vs Py=({py_acc}, {py_tag})")

        if rec["adversarial"]:
            adv_total += 1
            if not lean_acc:
                lean_adv_rej += 1
            if not py_acc:
                py_adv_rej += 1
        else:
            val_total += 1
            if lean_acc:
                lean_val_acc += 1
            if py_acc:
                py_val_acc += 1

    print("--------------------------------------------------------------------------")
    print(f"Fixed Curated Lean <-> Python Parity     : {len(fixed_cases) - fixed_mismatches} / {len(fixed_cases)} EXACT MATCH")
    print(f"External Batch Lean <-> Python Parity    : {len(batch_records) - batch_mismatches} / {len(batch_records)} EXACT MATCH (seed=2026112203)")
    print(f"Lean Adversarial Mutation Rejections     : {lean_adv_rej} / {adv_total}")
    print(f"Python Adversarial Mutation Rejections   : {py_adv_rej} / {adv_total}")
    print(f"Valid Boundary Mutation Acceptances      : Lean={lean_val_acc}/{val_total}, Python={py_val_acc}/{val_total}")
    print(f"P2 GrammarG16.lean Disk Snapshot Match   : {p2_matched} / {p2_total}")
    print("==========================================================================")

    if (
        fixed_mismatches == 0
        and batch_mismatches == 0
        and lean_adv_rej == adv_total
        and py_adv_rej == adv_total
        and lean_val_acc == val_total
        and py_val_acc == val_total
    ):
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
```
