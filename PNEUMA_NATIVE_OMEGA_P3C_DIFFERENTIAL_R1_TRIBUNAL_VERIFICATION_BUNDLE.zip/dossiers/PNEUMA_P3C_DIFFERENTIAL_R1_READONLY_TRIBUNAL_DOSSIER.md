# PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 Read-Only Independent Tribunal Verification Bundle (`P3C_Differential_R1`)

> [!IMPORTANT]
> **Read-Only Audit Submission (`AUTH-P3C-DIFFERENTIAL-R1`: `F-P3C-02` Independent Full Internal-State Semantic Differential Verification)**
> Official Governance Title: **`PNEUMA-NATIVE Ω`** (`namespace PneumaOmega.P3C.DifferentialR1`; historical frozen lineage `BROCA-NATIVE Ω`).
> Governance Disposition: **`SUBMITTED_FOR_INDEPENDENT_TRIBUNAL_REVIEW`** (per `Charter §7`, final Tribunal acceptance is **not** self-declared prior to Independent Tribunal audit). Termination state: **`FROZEN_AND_STANDBY`**.
> All `14` `Differential R1` source/configuration/oracle files and the isolated verification receipt (`06_receipts/auth_p3c_differential_r1_verification_receipt.json`) embedded in Section 6 are **100% verbatim, byte-identical copies** (`15/15` SHA-256 block-parity verified) from `C:\antigravity work\BROCA_NATIVE_OMEGA_GATE_C1\P3C_Differential_R1\`.
> Zero bytes were written to `Pneuma` (`0` files), `Broca`/`shared` (`6/6` anchors), `DIR`, `P1` (`13/13`), `P2` (`14/14`), `P3-A` (`14/14`), `P3-B` (`14/14`), `P3-C` (`14/14` sources + `12/12` binaries), `P3C_Provenance_R1` (`13/13` sources + `10/10` binaries + receipt `790E41D1D352C31457281F72BB627E28DD6D3B7DB1B65C7D8F4F39A795D203DD`), parent `BROCA_NATIVE_OMEGA_GATE_C1\06_receipts\` (`6/6` receipts), or any of the `7` prior Tribunal dossiers. All user-specific host paths in logs and prose are masked as `<USER_HOME>`.

---

## 1. Authorization Lineage, `Corrigendum R0` (`F-DIFF-P0-01`~`04`) & `Scoped Optimization` (`F-DIFF-OPT-01`~`04`) Compliance Summary

| Audit Dimension | Charter / Directive Requirement | Verified Implementation & Evidence |
| :--- | :--- | :--- |
| **`AC-P0-06 §9.A.1 & §9.A.2` Authorization** | Separate pre-design approval (`Corrigendum R0`) + explicit human execution command before any write; scoped optimization approved before optimization edits | Pre-design `Corrigendum R0` (`F-DIFF-P0-01`~`04`) approved `2026-11-23`; human principal execution command `"승인해 진행하자."` issued `2026-11-23T21:20:24+09:00` prior to any file creation; Tribunal `Scoped Optimization Directive` (`F-DIFF-OPT-01`~`04`, `Gates OPT-A`~`D`) issued `2026-11-24T10:07:54+09:00`. |
| **`F-DIFF-P0-01` (`PNEUMA-DIFF-SER-V1` Canonical Codec)** | Roundtrip `decode(encode x) = .ok x`, canonical uniqueness `decode s = .ok x ↔ encode x = s`, deterministic malformed rejection, and encoding injectivity `encode x = encode y → x = y` (never false string surjectivity) | `TypedWireFormatV1.lean`: `CanonicalWireCodec α` proved across all internal `P3-B`, `P3-C`, and `Provenance R1` value types (`CodepointSpan`, `ConcreteParseTree`, `ParseForest`, `ParseOutcome`, `RawSemanticTerm`, `ExtractionFailureDiag`, `RawExtractionResult`, `CanonicalMeaning`, `SemanticNormOutcome`, `ProvenanceContext`, `UntrustedConsensusClaim`, `ClaimReplayRejectReason`, `MintOutcomeTag`); exported in `PO-DIFF-01` & `PO-DIFF-02`. |
| **`F-DIFF-P0-02` (`EpistemicGrade` Separation)** | Separate `SPEC_GROUNDED`, `MODEL_ASSUMPTION`, and `SPEC_UNDEFINED` paired with `r0SpecAnchor` | `DifferentialAlgebraSpec.lean` & `independent_r0_semantic_oracle.py`: `EpistemicGrade` enforced in both Lean (`evaluateStageWireDiff`) and Python (`SURFACE_VECTORS`, `FOREST_INJECT`); `SPEC_UNDEFINED` (`SURF-39` KM, `SURF-40` AJ) deterministically yields `SPECIFICATION_HELD` (never `MATCH_STRUCTURAL`). |
| **`F-DIFF-P0-03` (3-Class Boundary Observation)** | Separate `SURFACE_E2E`, `FOREST_INJECT`, and `SEMANTIC_INJECT` so `P3-B`-unreachable failure/malformed states are whitebox-tested without blurring earliest-blocking-boundary responsibility | `DifferentialTraceObserver.lean`, `OrthogonalAttackSuiteD01ToD12.lean`, and `independent_r0_semantic_oracle.py`: `40` `SURFACE_E2E` vectors + `12` `FOREST_INJECT` vectors (`9` `SemanticExtractionFailure` across all `5` `ExtractionFailureDiag` constructors) + `12` `SEMANTIC_INJECT` vectors + `28` curated `(PC, CE)` vectors. |
| **`F-DIFF-P0-04` (Closed 5-Way `DiffVerdict` Algebra)** | Disjoint 5-way `DiffVerdict`: `matchStructural(grade)` \| `mismatchWitness` \| `oracleFailure` \| `specificationHeld` \| `resourceHeld` | `DifferentialAlgebraSpec.lean`: `DiffVerdict` proved mutually exclusive; `PO_DIFF_07_DifferentialScopeSoundness` proves `matchStructural` impossible on `SPEC_UNDEFINED`, non-empty `oracleDiag`, `resourceOverflowed`, or `leanWire ≠ oracleWire`. |
| **`F-DIFF-OPT-01` (`ProjectionSoundness`)** | Prove finite verdict-head projection `verdictHead` preserves `matchStructural(grade)`, `mismatchWitness`, and `specificationHeld` iff full `compareWirePayloads`, and reduces `encodeWire` comparisons to structural `x = y` / `x ≠ y`; never misstate as a quotient | `DifferentialTraceObserver.lean` & `PO_DIFF_01_To_08.lean`: `DiffVerdictHead` documented strictly as a **finite head projection** (not a quotient); `F_DIFF_OPT_01_ProjectionSoundness` proves `verdictHead_branch_preservation_iff`, `verdictHead_compare_encode`, `verdictHead_compare_encode_self`, `verdictHead_compare_encode_of_ne`, and `verdictHead_compare_canon`. |
| **`F-DIFF-OPT-02` (`MismatchWitnessFidelity`)** | Prove unprojected `compareWirePayloads` retains exact `leanWire`, `oracleWire`, `firstDiffLocus` (`"tok#..."`), distinct token witnesses, and `decodeWire = .ok`; execute runtime unprojected witness checks | `F_DIFF_OPT_02_MismatchWitnessFidelity` proved in Lean 4.33.1 + `7/7` unprojected full wire witness checks (`OPT02-W1` ~ `OPT02-W7`) executed in `p3c_differential_r1_runner.exe` verifying exact `tok#k(tL != tO)` loci, byte lengths (`322`–`4817` bytes), and `roundtrip=true`. |
| **`F-DIFF-OPT-03` (`FiniteDecisionAlgebra` & `D13` Literal Gate)** | Prove finite `GateDVerdictTag` decision algebra preserves exact `(PC, CE)` branch truth while retaining literal wire `String` `by decide` execution on `D13` | `OrthogonalAttackSuiteD01ToD12.lean`: `GateDVerdictTag` (`gateDTag_injective`) + `Gate OPT-C` exact 5-tuple shared witnesses (`ctxG11`, `ctxG15a`, `ctxG15b`, `ctxT2`, `ctxT3`); `PC-DIFF-13` & `CE-DIFF-13` directly execute `decodeWire CanonicalMeaningCodec` on literal wire `String`s via pure kernel `by decide`. |
| **`F-DIFF-OPT-04` (Empirical Resource Metrics & `HELD` Complexity)** | Record measured wall-clock time and peak memory (`PeakProcessMemoryUsed` / `PeakJobMemoryUsed`) across build, runner, oracle, and `leanchecker --fresh`; keep unproven asymptotic claims `HELD` | Win32 JobObject metrics recorded across all 4 stages: `OrthogonalAttackSuiteD01ToD12` build reduced from **`54,870.04 MB` OOM** to **`2,333.95 MB` proc / `2,395.52 MB` job (`68.58s`)**; `leanchecker --fresh` exited `0` (`3027.69s`, `10,736.40 MB` proc / `10,776.67 MB` job); asymptotic kernel complexity claims (`O(N^2) → O(1)`) explicitly retained **`HELD`**. |

---

## 2. Mandatory 5-Category Epistemic & Governance Separation

### 2.1 Category I — Machine-Checked Theorems (`11/11` Exported Obligations in Lean 4.33.1 Kernel)

Every theorem below is checked by the Lean 4.33.1 kernel (`0` `sorryAx`, `0` `Lean.ofReduceBool` / `native_decide`, `0` `trustCompiler`, `0` custom axioms) and independently replayed from scratch via `lake env leanchecker --fresh P3CDiffTribunalAudit` (`exit 0`).

| Obligation ID | Exported Theorem (`PneumaOmega.P3C.DifferentialR1.Obligations`) | Exact Scoped Machine-Checked Statement Summary | Axiom Footprint |
| :--- | :--- | :--- | :--- |
| **`PO-DIFF-01`** | `PO_DIFF_01_SerializationRoundtripAndCanonicalUniqueness` | Across `CodepointSpan`, `ConcreteParseTree`, `ParseForest`, `RawSemanticTerm`, `ExtractionFailureDiag`, `RawExtractionResult`, `CanonicalMeaning`, `SemanticNormOutcome`, and `UntrustedConsensusClaim`: **(a)** `decodeWire C (encodeWire C x) = .ok x`, **(b)** `decodeWire C s = .ok x ↔ encodeWire C x = s` (canonical uniqueness), and **(c)** any wire string outside canonical image `∀ x, encodeWire C x ≠ s` is deterministically rejected with `.error diag`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-DIFF-02`** | `PO_DIFF_02_EncodingInjectivity` | Across all wire-encoded types (`ConcreteParseTree`, `ParseForest`, `RawSemanticTerm`, `RawExtractionResult`, `CanonicalMeaning`, `SemanticNormOutcome`, `ProvenanceContext`, `UntrustedConsensusClaim`), `encodeWire C x = encodeWire C y → x = y`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-DIFF-03`** | `PO_DIFF_03_SpanUnitIntegrity` | **(a)** `CodepointSpan` wire equality holds iff `startCp` and `endCp` match; **(b)** for every valid `P3-A` `ascii_validated` input, `bytes.length = chars.length` (ASCII byte offset = Unicode scalar offset), whereas every `out_of_domain` byte sequence (`SURF-29` empty, `SURF-30` 2-byte UTF-8 `0xC3 0xA9`, `SURF-31` 3-byte UTF-8 `0xE2 0x89 0xA4`, `SURF-32` tab) is deterministically rejected upstream before `P3-B` span indexing; **(c)** every valid `GFrozen` parse tree over `chars` satisfies `TreeSpansWithin chars.length t` (`endCp ≤ chars.length`). | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-DIFF-04`** | `PO_DIFF_04_ExtractionResultFidelity` | `observeExtractionTrace` preserves exact structural equality of `List RawExtractionResult` across both `.ok RawSemanticTerm` and `.error ExtractionFailureDiag` (covering all 5 `ExtractionFailureDiag` constructors) via `RawExtractionListCodec`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-DIFF-05`** | `PO_DIFF_05_CanonicalMeaningFidelity` | **(a)** Normalization idempotence `normalizeMeaning (embedCanonical (normalizeMeaning r)) = normalizeMeaning r`; **(b)** wire equality of `CanonicalMeaning` iff `SemEq r₁ r₂` (`normalizeMeaning r₁ = normalizeMeaning r₂`); **(c)** `RawSemanticTerm` wire inequality is strictly finer than `CanonicalMeaning` wire equality (exhibited on `G-15a` vs `G-15b` symmetric conjunction order). | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-DIFF-06`** | `PO_DIFF_06_FiveWayOutcomeSeparation` | Pairwise disjointness across all 5 `SemanticNormOutcome` constructors (`consensus`, `ambiguousReadings`, `semanticExtractionFailure`, `trapPolicyRejected`, `upstreamRejected`) both on values and on `PNEUMA-DIFF-SER-V1` wire encodings, plus uninhabitedness of `CertifiedSemanticConsensus ctx` and deterministic claim rejection across all 4 non-consensus branches. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-DIFF-07`** | `PO_DIFF_07_DifferentialScopeSoundness` | **Scoped strictly to differential wire-agreement**: `evaluateStageWireDiff ... = .matchStructural g` iff `(grade = .specGrounded ∨ grade = .modelAssumption) ∧ oracleDiag = none ∧ resourceOverflowed = false ∧ leanWire = oracleWire`; when `leanWire = encodeWire C xL` and `oracleWire = encodeWire C xO`, `.matchStructural g` implies `xL = xO`. Explicitly does **not** claim full `Architecture Freeze R0` clinical/semantic truth beyond the compared models. | `propext`, `Classical.choice`, `Quot.sound` |
| **`PO-DIFF-08`** | `PO_DIFF_08_ProvenanceBoundaryPreservation` | **Scoped strictly to `Provenance R1` type-and-verifier boundary**: decoded wire `UntrustedConsensusClaim` passes `verifyUntrustedConsensusClaim targetCtx` iff `∃ cert : CertifiedSemanticConsensus targetCtx, cl = exportUntrustedClaim cert`; cross-context claims (`ctx₁ ≠ ctx₂`) fail closed; `(P5FinalCertifiedOutput → False) ∧ (∀ c, P4ClinicalTruthCert c → False)` remains intact. Global system-wide P4/P5 non-bypass outside this typed boundary remains `HELD`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`F-DIFF-OPT-01`** | `F_DIFF_OPT_01_ProjectionSoundness` | Proves finite verdict-head projection `verdictHead` preserves exact branch classification (`matchStructural g`, `mismatchWitness`, `specificationHeld`, `oracleFailure`, `resourceHeld`) of `compareWirePayloads` and reduces canonical wire comparisons to `xL = xO` / `xL ≠ xO` / `canonicalMeaningEqBool c₁ c₂`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`F-DIFF-OPT-02`** | `F_DIFF_OPT_02_MismatchWitnessFidelity` | Proves unprojected `compareWirePayloads stage grade anchor (encodeWire C xL) (encodeWire C xO)` on any `xL ≠ xO` (under `SPEC_GROUNDED` / `MODEL_ASSUMPTION`) produces `.mismatchWitness w` carrying exact unprojected `w.leanWire = encodeWire C xL`, `w.oracleWire = encodeWire C xO`, valid roundtrip `decodeWire C w.leanWire = .ok xL` & `decodeWire C w.oracleWire = .ok xO`, and concrete first-differing token witness `tL ≠ tO` at `"tok#" ++ Nat.repr idx`. | `propext`, `Classical.choice`, `Quot.sound` |
| **`Gate D` (`28/28`)** | `PO_DIFF_All28OrthogonalAttackVectorsVerified` | Machine-checked kernel conjunction (`by decide`, `0` `native_decide`) verifying `allCuratedDifferentialCasesPass = true` and `curatedDifferentialSuite.length = 28` across all `14` symmetric `(PC, CE)` pairs (`D01` ~ `D14`), including direct literal wire `String` decoding in `PC-DIFF-13` and `CE-DIFF-13`. | `propext`, `Classical.choice`, `Quot.sound` |

---

### 2.2 Category II — Deterministic Executed Checks & Empirical Resource Metrics (`PO-DIFF-09` & `F-DIFF-OPT-04`)

1. **External Static Independence & Rule-Correspondence Audit (`PO-DIFF-09`)**:
   - `independent_r0_semantic_oracle.py` parses its own Python AST (`run_po_diff_09_static_audit`) and verifies:
     - **Stdlib-only imports (`11` modules)**: `__future__`, `ast`, `dataclasses`, `hashlib`, `json`, `os`, `pathlib`, `re`, `subprocess`, `sys`, `typing` (`0` third-party or Lean-generated bindings).
     - **Zero Lean implementation source reads (`0` forbidden references)**: AST scan across all module statements outside the audit function confirms `0` string references to `TreeSemanticExtractor.lean`, `CanonicalNormalizer.lean`, `ConsensusAndTrapGate.lean`, `BoundedParser.lean`, `DeclarativeParseSpec.lean`, `P3CDetachedChecker`, or `P3BDetachedChecker`.
     - **25-row `R0_SPEC_CORRESPONDENCE_TABLE`**: Explicitly maps all `20` generative clauses (`G-01`, `G-02a`, `G-02b`, `G-03`, `G-04`, `G-05`, `G-06a`, `G-06b`, `G-07`, `G-08`, `G-09`, `G-10`, `G-11`, `G-12`, `G-13`, `G-14`, `G-15a`, `G-15b`, `G-16`), `5` traps (`T1`~`T5`), and `SPEC_UNDEFINED` (`G-01-RC` right-censored KM / competing-risk AJ) to their frozen `Architecture Freeze R0` section anchors and `EpistemicGrade`.
   - Per `Corrigendum R0 F-DIFF-P0-02`, `PO-DIFF-09` is reported strictly as a **static AST/import & correspondence audit**, never as a self-referential Lean theorem claiming independent semantic truth.
2. **3-Class Runtime Differential Verification (`64` Independent Oracle Vectors + `28` Curated Kernel Vectors + `7` Unprojected Witness Checks)**:
   - **`SURFACE_E2E` (`40/40` vectors, `0` `MISMATCH_WITNESS`)**:
     - `36` `MATCH_STRUCTURAL(SPEC_GROUNDED)` (`G-01` ~ `G-14`, `G-16`, `T1` ~ `T5`, `4` OOD UTF-8/byte vectors, `2` resource-overflow vectors, `4` empty-parse side-condition failure vectors).
     - `2` `MATCH_STRUCTURAL(MODEL_ASSUMPTION)` (`SURF-20-G15a-AB` and `SURF-21-G15b-BA`, because raw `extWires` include internal pre-α-erasure binder strings `"x_init"`/`"y_repeat"`, while also confirming `g15ParaphraseRawDistinctAndCanonIdentical = true` under `SPEC_GROUNDED` canonical comparison).
     - `2` `SPECIFICATION_HELD` (`SURF-39-SPEC-UNDEF-KM` right-censored Kaplan-Meier and `SURF-40-SPEC-UNDEF-AJ` competing-risk Aalen-Johansen, explicitly classified `SPEC_UNDEFINED` and never promoted to `MATCH_STRUCTURAL`).
   - **`FOREST_INJECT` (`12/12` vectors, `0` `MISMATCH_WITNESS`, `9` `SemanticExtractionFailure` vectors across all `5` `ExtractionFailureDiag` constructors)**:
     - `9` `MATCH_STRUCTURAL(SPEC_GROUNDED)` (`FI-01..06`, `FI-09`, `FI-11`, `FI-12`) + `3` `MATCH_STRUCTURAL(MODEL_ASSUMPTION)` (`FI-07`, `FI-08`, `FI-10`).
     - Covers all `5/5` `ExtractionFailureDiag` constructors: `unsupportedReadingAlt` (`FI-01..03`), `invalidContrastiveAnchor` (`FI-04`), `unresolvedAnaphoricScope` (`FI-05`), `mismatchedScopeCohort` (`FI-06`), and `malformedParseNode` (`FI-07..09`).
   - **`SEMANTIC_INJECT` (`12/12` vectors, `allInvariantsPassed = true`)**:
     - Verifies `100%` normalization idempotence (`norm(embed(norm(r))) == norm(r)`), `G-11` / `T1_alt1` De Morgan convergence (`raw !=` & `canon ==`), `symConj` commutativity/associativity/idempotence/dedup (`SI-05 == SI-06`), contrastive non-commutativity (`SI-07 != SI-08`), temporal precedence non-commutativity (`SI-09 != SI-10`), and cohort-bound vs unscoped separation (`SI-01 != SI-03`).
3. **Empirical Timing & Win32 JobObject Peak Memory Table (`F-DIFF-OPT-04`)**:

| Measured Execution Phase | Command | Exit Code | Wall-Clock (`s`) | `PeakProcessMemoryUsed` (`MB`) | `PeakJobMemoryUsed` (`MB`) | Empirical Finding |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **Pre-Optimization Baseline (`Before Gate OPT-A..C`)** | `lake build P3CDifferentialAttacks.OrthogonalAttackSuiteD01ToD12` | `OOM (Killed)` | `> 196.0` | `> 54,000.00` | **`54,870.04`** | Unfolded multi-KB `String.isValidUTF8` proofs & concrete nested `match` motives inside kernel WHNF caused `54.87 GB` OOM. |
| **Post-Optimization Attack & Obligation Build (`After Gate OPT-A..C`)** | `lake build` (`OrthogonalAttackSuiteD01ToD12` + `PO_DIFF_01_To_08`, leading to `99/99` full package build) | **`0`** | **`68.5800`** | **`2,333.95`** | **`2,395.52`** | **`95.63%` peak job memory reduction** (`54,870.04 MB → 2,395.52 MB`); `0` warnings, `0` errors across all `99/99` Lake build jobs. |
| **Compiled Differential & Witness Runner** | `.\.lake\build\bin\p3c_differential_r1_runner.exe` | **`0`** | **`0.5847`** | **`36.30`** | **`36.30`** | `28/28` curated orthogonal vectors + `7/7` unprojected `F-DIFF-OPT-02` wire witness checks passed. |
| **Independent R0 Python Whitebox Oracle** | `python 05_independent_tribunal/independent_r0_semantic_oracle.py --json` | **`0`** | **`2.2421`** | **`38.53`** | **`59.49`** | `PO-DIFF-09` static audit + `40` `SURFACE_E2E` + `12` `FOREST_INJECT` + `12` `SEMANTIC_INJECT` (`0` mismatches). |
| **Fresh Single-Kernel Replay (`Gate OPT-D.7`)** | `lake env leanchecker --fresh P3CDiffTribunalAudit` | **`0`** | **`3027.6874`** | **`10,736.40`** | **`10,776.67`** | Replayed all `10` `Differential R1` `.olean` modules + `5` upstream frozen packages (`P2`~`Provenance R1`) + `Init` in one fresh kernel instance with `0` errors. |

> [!NOTE]
> **Explicit `F-DIFF-OPT-04` Transparency Disclosure on Complexity & `leanchecker` Timing**:
> 1. **Asymptotic Kernel Complexity Claim (`HELD`)**: No theoretical asymptotic complexity bound (such as global `O(N^2) → O(1)` WHNF reduction) is claimed as a proved theorem; `f_diff_opt_04_asymptotic_complexity_claim_held` remains **`HELD`**.
> 2. **Pre-Execution `leanchecker --fresh` Wall-Clock Estimate Not Promoted**: Prior to execution, an informal estimate suggested `leanchecker --fresh` might run in under half of `Provenance R1`'s `738.03s`. Empirically, `Differential R1` replays a substantially larger transitive theorem graph (`2,465` lines of inductive wire-codec roundtrip/uniqueness proofs across 25 types + `1,010` lines of observer proofs + `951` lines of 28-vector kernel proofs on top of all `Provenance R1` and `P2`~`P3-C` modules), taking **`3027.6874s`** (`50.46 min`) at **`10,736.40 MB`** peak process memory (`exit_code = 0`). Per `F-DIFF-OPT-04`, we report the exact empirical figures without overclaiming speedups beyond the verified elimination of the `54.87 GB` build OOM (`95.63%` build peak RAM reduction).

---

### 2.3 Category III — Explicit Boundary Findings & Conditional Assumptions (`F-DIFF-P0-02` / `F-DIFF-P0-03`)

1. **`FI-10-G16-SWAPPED-CHILD` (`P3-B` vs `P3-C` Internal Responsibility Boundary)**:
   - Under `SURFACE_E2E`, `P3-B` (`DeclarativeParseSpec.lean:478`) enforces child nonterminal sort order `[.scopedAssoc, .scopedContrastMeta]` on `Gen_G16_DocContrastive`; swapping the `[meta, assoc]` surface clauses is deterministically rejected at `P3-B` (`emptyParseSet`).
   - Under `FOREST_INJECT` (`FI-10-G16-SWAPPED-CHILD`), when `P3-B` is bypassed and `[sc2_meta, sc1_assoc]` is injected directly into `P3-C`'s `extractRawMeaning`, `TreeSemanticExtractor.lean` extracts both scoped children via `extractScopedMeaning` without re-checking child nonterminal sort tags, producing `.consensus` with swapped `.contrastivePair metaSide assocSide "exp_intens" "out_mi"`.
   - Critically: **(a)** this swapped `contrastivePair` is **structurally non-equivalent** (`!=`) to valid `G-16`'s `.contrastivePair assocSide metaSide "exp_intens" "out_mi"` (proved in `CE-DIFF-01` `"MISMATCH_WITNESS:G16_CHILD_SWAP_DETECTED"` and verified in `fi10SwappedChildDivergesFromValidG16 = true`), so contrastive directionality is never silently conflated; and **(b)** `P3-C`'s reliance on upstream `P3-B` child sort typing for `Gen_G16_DocContrastive` is explicitly recorded under `MODEL_ASSUMPTION` rather than masked.
2. **Retained Upstream Model Conditions**:
   - `ExtensionalContrastiveWorld W` in `P3-C` / `Provenance R1` is retained unchanged.
   - Pre-normalization binder naming (`"x_init"` vs `"y_repeat"`), `NoDupTrees` structural tree equality, and internal arity diagnostics on grammar-unreachable `FOREST_INJECT` nodes remain explicitly tagged `MODEL_ASSUMPTION` (never merged into `SPEC_GROUNDED`).
   - Right-censored `G-01` Kaplan-Meier (`SURF-39`) and competing-risk Aalen-Johansen (`SURF-40`) remain `SPEC_UNDEFINED` (`SPECIFICATION_HELD`).

---

### 2.4 Category IV & V — Preserved `HELD` & `NOT_AUTHORIZED` Governance Ledger

| Item / Boundary | Status | Governance Rationale |
| :--- | :---: | :--- |
| **Final `Differential R1` Tribunal Acceptance** | **`PENDING_AUDIT`** | Never self-declared prior to Independent Tribunal review (`Charter §7`). |
| **Full `R0` Semantic Fidelity Beyond Curated Corpus** | **`HELD`** | `Differential R1` reduces internal-state observability gaps across `64` oracle vectors + `28` kernel vectors, but does not prove complete natural-language clinical fidelity of `Architecture Freeze R0`. |
| **`F-R1-01` Out-of-Kernel Binary / Memory / Runtime Tamper** | **`HELD`** | `CertifiedSemanticConsensus` (`private mk ::`) enforces non-forgery within well-typed Lean 4 kernel/compiler code, not against external `.olean`/memory/OS tampering. |
| **Global System-Wide `P4`/`P5` Admission Non-Bypass** | **`HELD`** | `PO-DIFF-08` proves boundary preservation for `Provenance R1` types and uninhabitedness of `P4ClinicalTruthCert` / `P5FinalCertifiedOutput` placeholders; full `P4`/`P5` admission architecture is not yet built. |
| **External Independent Host Replay (`P1` ~ `Differential R1`)** | **`HELD`** | Local `leanchecker --fresh` exited `0`, but independent execution on a Tribunal-operated host remains `HELD`. |
| **Legacy `P3-C` Governance Status** | **`AUTHORIZATION_QUALIFIED`** | Preserved unchanged per `Authority Reconciliation R0`. |
| **`F-DIFF-OPT-04` Asymptotic Kernel Complexity Claims** | **`HELD`** | Empirical memory/time metrics are recorded; theoretical asymptotic WHNF complexity bounds remain `HELD`. |
| **`F-P3C-03` Performance / Scaling Optimization** | **`NOT_AUTHORIZED`** | Out of scope for `AUTH-P3C-DIFFERENTIAL-R1`. |
| **`P1-C` (`Int128`), `P4`, `P5`, `FINITE-OPERATOR-R0`, `Speech & Listener`** | **`NOT_AUTHORIZED`** | Strictly locked (`0` files, `0` code, `0` authority escalation). |

---

## 3. `Gate D` 28-Vector Curated Orthogonal Matrix (`D01` ~ `D14`) & `F-DIFF-OPT-02` Unprojected Witnesses

### 3.1 `28/28` Symmetric `(PC, CE)` Vectors (`PO_DIFF_All28OrthogonalAttackVectorsVerified`)

| Case ID | Polarity | Attack Class | Observation Path | Epistemic Grade | Target Obligation(s) | Verified Verdict Summary | Kernel `decide` & CLI |
| :--- | :---: | :--- | :---: | :---: | :--- | :--- | :---: |
| `PC-DIFF-01` | `PC` | `D01_ChildOrderSwap` | `FOREST_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-04 / PO-DIFF-05` | `RAW_DISTINCT_AND_CANON_MATCH(SPEC_GROUNDED)` (`G-15a` vs `G-15b`) | `PASS` |
| `CE-DIFF-01` | `CE` | `D01_ChildOrderSwap` | `FOREST_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-05 / PO-DIFF-07` | `MISMATCH_WITNESS:G16_CHILD_SWAP_DETECTED` | `PASS` |
| `PC-DIFF-02` | `PC` | `D02_ReadingAltPerturb` | `SURFACE_E2E` | `SPEC_GROUNDED` | `PO-DIFF-04 / PO-DIFF-06` | `MATCH_STRUCTURAL(SPEC_GROUNDED):T2_DUAL_READINGS_BOUND` | `PASS` |
| `CE-DIFF-02` | `CE` | `D02_ReadingAltPerturb` | `FOREST_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-04 / PO-DIFF-06` | `EXTRACTION_FAILURE_VERIFIED(T1_alt3 & G11_alt2)` | `PASS` |
| `PC-DIFF-03` | `PC` | `D03_SpanOffsetPerturb` | `SURFACE_E2E` | `SPEC_GROUNDED` | `PO-DIFF-03` | `MATCH_STRUCTURAL(SPEC_GROUNDED):ROOT_AND_CHILD_SPANS_EXACT` | `PASS` |
| `CE-DIFF-03` | `CE` | `D03_SpanOffsetPerturb` | `FOREST_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-01 / PO-DIFF-03` | `MISMATCH_WITNESS(spanIntegrityStage):SPAN_SHIFT_CAUGHT` | `PASS` |
| `PC-DIFF-04` | `PC` | `D04_ByteVsCodepoint` | `SURFACE_E2E` | `SPEC_GROUNDED` | `PO-DIFF-03` | `MATCH_STRUCTURAL(SPEC_GROUNDED):ASCII_BYTE_EQ_CODEPOINT_61` | `PASS` |
| `CE-DIFF-04` | `CE` | `D04_ByteVsCodepoint` | `SURFACE_E2E` | `SPEC_GROUNDED` | `PO-DIFF-03 / PO-DIFF-06` | `OOD_BLOCKED_BEFORE_SPAN(2B_0xC3 & 3B_0xE2)` | `PASS` |
| `PC-DIFF-05` | `PC` | `D05_ScopePolarityQuant` | `SURFACE_E2E` | `SPEC_GROUNDED` | `PO-DIFF-05` | `QUANTIFIER_FORMS_SEPARATED(G11!=G12)` | `PASS` |
| `CE-DIFF-05` | `CE` | `D05_ScopePolarityQuant` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-05 / PO-DIFF-06` | `MISMATCH_WITNESS(Scope & Polarity) & T5_TRAP_REJECTED` | `PASS` |
| `PC-DIFF-06` | `PC` | `D06_FactivePresup` | `SURFACE_E2E` | `SPEC_GROUNDED` | `PO-DIFF-05 / PO-DIFF-06` | `G09_CONSENSUS_VS_T3_WH_FACTIVE_REJECTED` | `PASS` |
| `CE-DIFF-06` | `CE` | `D06_FactivePresup` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-05 / PO-DIFF-07` | `MISMATCH_WITNESS:PRESUPPOSITION_DROP_OR_ADD_CAUGHT` | `PASS` |
| `PC-DIFF-07` | `PC` | `D07_CausalVsAssocModal` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-05` | `MATCH_STRUCTURAL(SPEC_GROUNDED):CAUSAL_DIRECTIONAL_CANONICAL` | `PASS` |
| `CE-DIFF-07` | `CE` | `D07_CausalVsAssocModal` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-02 / PO-DIFF-05` | `MISMATCH_WITNESS:CAUSAL_NE_ASSOC_AND_NE_NEUTRAL` | `PASS` |
| `PC-DIFF-08` | `PC` | `D08_TemporalReversal` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-01 / PO-DIFF-05` | `MATCH_STRUCTURAL(SPEC_GROUNDED):G04_TEMPORAL_ROUNDTRIP` | `PASS` |
| `CE-DIFF-08` | `CE` | `D08_TemporalReversal` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-02 / PO-DIFF-05` | `MISMATCH_WITNESS:TEMPORAL_REVERSAL_CAUGHT` | `PASS` |
| `PC-DIFF-09` | `PC` | `D09_SymConjVsContrast` | `FOREST_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-04 / PO-DIFF-05` | `MATCH_STRUCTURAL(SPEC_GROUNDED):G16_CONTRASTIVE_FOREST_OK` | `PASS` |
| `CE-DIFF-09` | `CE` | `D09_SymConjVsContrast` | `FOREST_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-04 / PO-DIFF-06` | `BOUNDARY_SEPARATED(P3B_EmptyParse & P3C_InvalidAnchor & SymConj!=Contrastive)` | `PASS` |
| `PC-DIFF-10` | `PC` | `D10_OptionalFieldDrop` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-01 / PO-DIFF-05` | `MATCH_STRUCTURAL(SPEC_GROUNDED):OPTIONAL_FIELDS_ROUNDTRIP_INTACT` | `PASS` |
| `CE-DIFF-10` | `CE` | `D10_OptionalFieldDrop` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-02 / PO-DIFF-05` | `MISMATCH_WITNESS:DROPPED_OPTIONAL_FIELDS_CAUGHT(cov & pVal)` | `PASS` |
| `PC-DIFF-11` | `PC` | `D11_ExtractionDiag5Way` | `FOREST_INJECT` | `MODEL_ASSUMPTION` | `PO-DIFF-01 / PO-DIFF-04` | `ALL_5_EXTRACTION_DIAG_FAMILIES_ROUNDTRIPPED` | `PASS` |
| `CE-DIFF-11` | `CE` | `D11_ExtractionDiag5Way` | `FOREST_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-06 / PO-DIFF-08` | `FAILURE_DISGUISE_AND_RAW_SUBMIT_REJECTED` | `PASS` |
| `PC-DIFF-12` | `PC` | `D12_ProvenanceReplay` | `SURFACE_E2E` | `SPEC_GROUNDED` | `PO-DIFF-01 / PO-DIFF-08` | `PROVENANCE_R1_ADMITS_AUTHENTIC_DECODED_WIRE` | `PASS` |
| `CE-DIFF-12` | `CE` | `D12_ProvenanceReplay` | `SURFACE_E2E` | `SPEC_GROUNDED` | `PO-DIFF-08` | `PROVENANCE_R1_REJECTS_CROSS_CONTEXT_AND_SPOOFED_WIRE` | `PASS` |
| `PC-DIFF-13` | `PC` | `D13_CanonicalWireGate` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-01a / PO-DIFF-01b` | `VALID_CANONICAL_WIRE_DECODED` (**literal `String` `by decide`**) | `PASS` |
| `CE-DIFF-13` | `CE` | `D13_CanonicalWireGate` | `SEMANTIC_INJECT` | `SPEC_GROUNDED` | `PO-DIFF-01b / PO-DIFF-01c` | `ALL_6_MALFORMED_WIRE_CLASSES_REJECTED` (**literal `String` `by decide`**) | `PASS` |
| `PC-DIFF-14` | `PC` | `D14_VerdictGradeAlgebra` | `SEMANTIC_INJECT` | `MODEL_ASSUMPTION` | `PO-DIFF-07` | `MATCH_STRUCTURAL(MODEL_ASSUMPTION):SEPARATED_FROM_SPEC_GROUNDED` | `PASS` |
| `CE-DIFF-14` | `CE` | `D14_VerdictGradeAlgebra` | `SURFACE_E2E` | `SPEC_UNDEFINED` | `PO-DIFF-06 / PO-DIFF-07` | `SPECIFICATION_HELD_AND_RESOURCE_OVERFLOW_SEPARATED` | `PASS` |

### 3.2 `7/7` Unprojected Full Wire Witness Checks (`F-DIFF-OPT-02` Runtime Verification)

| Witness ID | Diff Stage | Unprojected `firstDiffLocus` (`tok#idx(tL != tO)`) | `leanWire` Bytes | `oracleWire` Bytes | Full `decodeWire` Roundtrip | Status |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: |
| `OPT02-W1-SPAN-SHIFT` | `spanIntegrityStage` | `tok#8(N#1 != N#2)` | `2,343` | `2,343` | `true` | `PASS` |
| `OPT02-W2-SCOPE-DROP` | `canonicalNormStage` | `tok#5(SemanticScope.cohortBound != SemanticScope.unrestrictedPop)` | `395` | `322` | `true` | `PASS` |
| `OPT02-W3-PRESUP-INJECT` | `canonicalNormStage` | `tok#66(PresupList.nil != PresupList.cons)` | `483` | `697` | `true` | `PASS` |
| `OPT02-W4-CAUSAL-VS-ASSOC` | `canonicalNormStage` | `tok#20(AtomicClaim.intervClaim != AtomicClaim.assocClaim)` | `754` | `643` | `true` | `PASS` |
| `OPT02-W5-TEMPORAL-SWAP` | `canonicalNormStage` | `tok#73(N#9 != N#6)` | `754` | `754` | `true` | `PASS` |
| `OPT02-W6-OPT-COV-DROP` | `canonicalNormStage` | `tok#70(Option.some != Option.none)` | `725` | `643` | `true` | `PASS` |
| `OPT02-W7-OUTCOME-5WAY` | `outcomeGateStage` | `tok#2(SemanticNormOutcome.semanticExtractionFailure != SemanticNormOutcome.consensus)` | `4,817` | `2,998` | `true` | `PASS` |

---

## 4. Verbatim Build, `#print axioms`, Runner, Independent Oracle & `leanchecker --fresh` Logs

### 4.1 `lake build` & `#print axioms` Verification (`99/99` Jobs, `0` Warnings, `0` Errors)
```text
✔ [91/99] Built P3CDifferentialAttacks.OrthogonalAttackSuiteD01ToD12 (63s)
✔ [92/99] Built P3CDifferentialAttacks (806ms)
✔ [93/99] Built P3CDifferentialObligations.PO_DIFF_01_To_08 (2.7s)
✔ [94/99] Built P3CDifferentialObligations (835ms)
ℹ [97/99] Built P3CDiffTribunalAudit (1.4s)
'PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_01_SerializationRoundtripAndCanonicalUniqueness' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_02_EncodingInjectivity' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_03_SpanUnitIntegrity' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_04_ExtractionResultFidelity' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_05_CanonicalMeaningFidelity' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_06_FiveWayOutcomeSeparation' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_07_DifferentialScopeSoundness' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_08_ProvenanceBoundaryPreservation' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.F_DIFF_OPT_01_ProjectionSoundness' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.F_DIFF_OPT_02_MismatchWitnessFidelity' depends on axioms: [propext, Classical.choice, Quot.sound]
'PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_All28OrthogonalAttackVectorsVerified' depends on axioms: [propext, Classical.choice, Quot.sound]
✔ [99/99] Built p3c_differential_r1_runner:exe (2.9s)
Build completed successfully (99 jobs).
```

### 4.2 `p3c_differential_r1_runner.exe` Output (`28/28` Vectors + `7/7` Unprojected Witnesses)
```text
=== RUNNER METRICS ===
{"exit_code": 0, "elapsed_sec": 0.5847, "peak_proc_mem_mb": 36.3, "peak_job_mem_mb": 36.3}
==========================================================================
PNEUMA-NATIVE OMEGA — AUTH-P3C-DIFFERENTIAL-R1 (FULL INTERNAL DIFFERENTIAL)
Scope     : F-P3C-02 + Corrigendum R0 F-DIFF-P0-01..04 (P3C_Differential_R1)
Toolchain : Lean 4.33.1 Core (Init + Frozen P2..P3-C + Provenance R1, 0 sorry)
==========================================================================
[PASS] PC-DIFF-01 | D01_ChildOrderSwap | FOREST_INJECT | SPEC_GROUNDED | S0-R2.2:G15 | RAW_DISTINCT_AND_CANON_MATCH(SPEC_GROUNDED)
[PASS] CE-DIFF-01 | D01_ChildOrderSwap | FOREST_INJECT | SPEC_GROUNDED | S0-R2:G16 | MISMATCH_WITNESS:G16_CHILD_SWAP_DETECTED
[PASS] PC-DIFF-02 | D02_ReadingAltPerturb | SURFACE_E2E | SPEC_GROUNDED | P0-A05:T2_DualAlt | MATCH_STRUCTURAL(SPEC_GROUNDED):T2_DUAL_READINGS_BOUND
[PASS] CE-DIFF-02 | D02_ReadingAltPerturb | FOREST_INJECT | SPEC_GROUNDED | P0-A05:AltBounds | EXTRACTION_FAILURE_VERIFIED(T1_alt3 & G11_alt2)
[PASS] PC-DIFF-03 | D03_SpanOffsetPerturb | SURFACE_E2E | SPEC_GROUNDED | S0-R2.1:Span | MATCH_STRUCTURAL(SPEC_GROUNDED):ROOT_AND_CHILD_SPANS_EXACT
[PASS] CE-DIFF-03 | D03_SpanOffsetPerturb | FOREST_INJECT | SPEC_GROUNDED | S0-R2.1:Span | MISMATCH_WITNESS(spanIntegrityStage):SPAN_SHIFT_CAUGHT
[PASS] PC-DIFF-04 | D04_ByteVsCodepoint | SURFACE_E2E | SPEC_GROUNDED | GateC0-R1:F-C0-03 | MATCH_STRUCTURAL(SPEC_GROUNDED):ASCII_BYTE_EQ_CODEPOINT_61
[PASS] CE-DIFF-04 | D04_ByteVsCodepoint | SURFACE_E2E | SPEC_GROUNDED | GateC0-R1:F-C0-03 | OOD_BLOCKED_BEFORE_SPAN(2B_0xC3 & 3B_0xE2)
[PASS] PC-DIFF-05 | D05_ScopePolarityQuant | SURFACE_E2E | SPEC_GROUNDED | S0-R2:G11_G12 | QUANTIFIER_FORMS_SEPARATED(G11!=G12)
[PASS] CE-DIFF-05 | D05_ScopePolarityQuant | SEMANTIC_INJECT | SPEC_GROUNDED | S0-R2:T1_T5_Scope | MISMATCH_WITNESS(Scope & Polarity) & T5_TRAP_REJECTED
[PASS] PC-DIFF-06 | D06_FactivePresup | SURFACE_E2E | SPEC_GROUNDED | S0-R2:G09_vs_T3 | G09_CONSENSUS_VS_T3_WH_FACTIVE_REJECTED
[PASS] CE-DIFF-06 | D06_FactivePresup | SEMANTIC_INJECT | SPEC_GROUNDED | P0-A05:T2_Presup | MISMATCH_WITNESS:PRESUPPOSITION_DROP_OR_ADD_CAUGHT
[PASS] PC-DIFF-07 | D07_CausalVsAssocModal | SEMANTIC_INJECT | SPEC_GROUNDED | GateC0-R1:F-C0-07 | MATCH_STRUCTURAL(SPEC_GROUNDED):CAUSAL_DIRECTIONAL_CANONICAL
[PASS] CE-DIFF-07 | D07_CausalVsAssocModal | SEMANTIC_INJECT | SPEC_GROUNDED | GateC0-R1:F-C0-07 | MISMATCH_WITNESS:CAUSAL_NE_ASSOC_AND_NE_NEUTRAL
[PASS] PC-DIFF-08 | D08_TemporalReversal | SEMANTIC_INJECT | SPEC_GROUNDED | S0-R2:G04 | MATCH_STRUCTURAL(SPEC_GROUNDED):G04_TEMPORAL_ROUNDTRIP
[PASS] CE-DIFF-08 | D08_TemporalReversal | SEMANTIC_INJECT | SPEC_GROUNDED | S0-R2:G04 | MISMATCH_WITNESS:TEMPORAL_REVERSAL_CAUGHT
[PASS] PC-DIFF-09 | D09_SymConjVsContrast | FOREST_INJECT | SPEC_GROUNDED | S0-R2:G16 | MATCH_STRUCTURAL(SPEC_GROUNDED):G16_CONTRASTIVE_FOREST_OK
[PASS] CE-DIFF-09 | D09_SymConjVsContrast | FOREST_INJECT | SPEC_GROUNDED | S0-R2:G15_vs_G16 | BOUNDARY_SEPARATED(P3B_EmptyParse & P3C_InvalidAnchor & SymConj!=Contrastive)
[PASS] PC-DIFF-10 | D10_OptionalFieldDrop | SEMANTIC_INJECT | SPEC_GROUNDED | S0-R2:G02b_G14 | MATCH_STRUCTURAL(SPEC_GROUNDED):OPTIONAL_FIELDS_ROUNDTRIP_INTACT
[PASS] CE-DIFF-10 | D10_OptionalFieldDrop | SEMANTIC_INJECT | SPEC_GROUNDED | S0-R2:G06a_G14 | MISMATCH_WITNESS:DROPPED_OPTIONAL_FIELDS_CAUGHT(cov & pVal)
[PASS] PC-DIFF-11 | D11_ExtractionDiag5Way | FOREST_INJECT | MODEL_ASSUMPTION | P3C:ExtractorDiags | ALL_5_EXTRACTION_DIAG_FAMILIES_ROUNDTRIPPED
[PASS] CE-DIFF-11 | D11_ExtractionDiag5Way | FOREST_INJECT | SPEC_GROUNDED | F-P3C-D02:5Way | FAILURE_DISGUISE_AND_RAW_SUBMIT_REJECTED
[PASS] PC-DIFF-12 | D12_ProvenanceReplay | SURFACE_E2E | SPEC_GROUNDED | F-P3C-01:Provenance | PROVENANCE_R1_ADMITS_AUTHENTIC_DECODED_WIRE
[PASS] CE-DIFF-12 | D12_ProvenanceReplay | SURFACE_E2E | SPEC_GROUNDED | F-P3C-01:Provenance | PROVENANCE_R1_REJECTS_CROSS_CONTEXT_AND_SPOOFED_WIRE
[PASS] PC-DIFF-13 | D13_CanonicalWireGate | SEMANTIC_INJECT | SPEC_GROUNDED | F-DIFF-P0-01:WireV1 | VALID_CANONICAL_WIRE_DECODED
[PASS] CE-DIFF-13 | D13_CanonicalWireGate | SEMANTIC_INJECT | SPEC_GROUNDED | F-DIFF-P0-01:WireV1 | ALL_6_MALFORMED_WIRE_CLASSES_REJECTED
[PASS] PC-DIFF-14 | D14_VerdictGradeAlgebra | SEMANTIC_INJECT | MODEL_ASSUMPTION | F-DIFF-P0-02:Grades | MATCH_STRUCTURAL(MODEL_ASSUMPTION):SEPARATED_FROM_SPEC_GROUNDED
[PASS] CE-DIFF-14 | D14_VerdictGradeAlgebra | SURFACE_E2E | SPEC_UNDEFINED | S0-R2:G01_RightCens | SPECIFICATION_HELD_AND_RESOURCE_OVERFLOW_SEPARATED
--------------------------------------------------------------------------
TOTAL CURATED ORTHOGONAL VECTORS : 28/28 PASSED
--------------------------------------------------------------------------
F-DIFF-OPT-02 UNPROJECTED FULL WIRE WITNESS VERIFICATION:
[PASS] OPT02-W1-SPAN-SHIFT | stage=PneumaOmega.P3C.DifferentialR1.DiffStage.spanIntegrityStage | locus=tok#8(N#1 != N#2) | leanBytes=2343 | oracleBytes=2343 | roundtrip=true
[PASS] OPT02-W2-SCOPE-DROP | stage=PneumaOmega.P3C.DifferentialR1.DiffStage.canonicalNormStage | locus=tok#5(SemanticScope.cohortBound != SemanticScope.unrestrictedPop) | leanBytes=395 | oracleBytes=322 | roundtrip=true
[PASS] OPT02-W3-PRESUP-INJECT | stage=PneumaOmega.P3C.DifferentialR1.DiffStage.canonicalNormStage | locus=tok#66(PresupList.nil != PresupList.cons) | leanBytes=483 | oracleBytes=697 | roundtrip=true
[PASS] OPT02-W4-CAUSAL-VS-ASSOC | stage=PneumaOmega.P3C.DifferentialR1.DiffStage.canonicalNormStage | locus=tok#20(AtomicClaim.intervClaim != AtomicClaim.assocClaim) | leanBytes=754 | oracleBytes=643 | roundtrip=true
[PASS] OPT02-W5-TEMPORAL-SWAP | stage=PneumaOmega.P3C.DifferentialR1.DiffStage.canonicalNormStage | locus=tok#73(N#9 != N#6) | leanBytes=754 | oracleBytes=754 | roundtrip=true
[PASS] OPT02-W6-OPT-COV-DROP | stage=PneumaOmega.P3C.DifferentialR1.DiffStage.canonicalNormStage | locus=tok#70(Option.some != Option.none) | leanBytes=725 | oracleBytes=643 | roundtrip=true
[PASS] OPT02-W7-OUTCOME-5WAY | stage=PneumaOmega.P3C.DifferentialR1.DiffStage.outcomeGateStage | locus=tok#2(SemanticNormOutcome.semanticExtractionFailure != SemanticNormOutcome.consensus) | leanBytes=4817 | oracleBytes=2998 | roundtrip=true
TOTAL UNPROJECTED WITNESS CHECKS : 7/7 PASSED
```

### 4.3 `independent_r0_semantic_oracle.py --json` (`PO-DIFF-09` + 3-Class Whitebox Differential)
```text
=== ORACLE METRICS ===
{"exit_code": 0, "elapsed_sec": 2.2421, "peak_proc_mem_mb": 38.53, "peak_job_mem_mb": 59.49}
==========================================================================
PNEUMA-NATIVE OMEGA — AUTH-P3C-DIFFERENTIAL-R1 INDEPENDENT R0 ORACLE AUDIT
==========================================================================
[PASS] PO-DIFF-09 Static Independence Audit (stdlib imports=11, forbidden=0, R0 table rows=25)
[PASS] SURFACE_E2E Differential (40 vectors): {"MATCH_STRUCTURAL(SPEC_GROUNDED)": 36, "MATCH_STRUCTURAL(MODEL_ASSUMPTION)": 2, "MISMATCH_WITNESS": 0, "ORACLE_FAILURE": 0, "SPECIFICATION_HELD": 2, "RESOURCE_HELD": 0}
       G-15a/G-15b Raw!= & Canon== : True
[PASS] FOREST_INJECT Differential (12 vectors, SemanticExtractionFailure=9): {"MATCH_STRUCTURAL(SPEC_GROUNDED)": 9, "MATCH_STRUCTURAL(MODEL_ASSUMPTION)": 3, "MISMATCH_WITNESS": 0}
[PASS] SEMANTIC_INJECT Differential (12 vectors): idempotent=True, DeMorgan=True, SymConj=True, Contrast!=True, Temporal!=True
==========================================================================
```

### 4.4 `lake env leanchecker --fresh P3CDiffTribunalAudit` (`Gate OPT-D.7` & `F-DIFF-OPT-04`)
```json
{
  "command": "lake env leanchecker --fresh P3CDiffTribunalAudit",
  "exit_code": 0,
  "elapsed_sec": 3027.6874,
  "peak_proc_mem_mb": 10736.4,
  "peak_job_mem_mb": 10776.67,
  "stdout": "",
  "stderr": ""
}
```

---

## 5. Complete SHA-256 Source, Oracle, Receipt & Compiled Artifact Manifest (`15` Embedded Files + `11` Binaries)

| Relative Path (`P3C_Differential_R1\`) | Source / Config SHA-256 | Compiled `.olean` / `.exe` SHA-256 |
| :--- | :--- | :--- |
| `lean-toolchain` | `3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71` | *(toolchain pin)* |
| `lakefile.toml` | `B4FDD45CA5038E275978C0A7CE3CC16717226A5C782C5A412B50F878642E46BD` | *(Lake package config)* |
| `lake-manifest.json` | `3EF2C9E99C50134787DCEAF0A57BC77778E9B3CC633A3E810A305D8736A89164` | *(Lake lockfile)* |
| `01_formal_spec/P3CDifferentialSpec.lean` | `618C51038F549FC68B0D788FC9E32A1C8B3945091B76C43A80D0F445D926C996` | `6706F4C39244A8CF704925AA6317F4D04ECD290A62D7612DEDCB143FE81AF2C0` |
| `01_formal_spec/P3CDifferentialSpec/TypedWireFormatV1.lean` | `945EA3C6471C6336974D85A5EE0C48A6217F32094160DAF7E82AA0ABA710768A` | `90E8839CD1DA711ED74FD4A4DE08EB7E88F118C0067467C7C52B4BF32F157697` |
| `01_formal_spec/P3CDifferentialSpec/DifferentialAlgebraSpec.lean` | `352D462AA31316BFD0C09B79F158808B53AC039E774AF547E161E98CBF4DDE78` | `43635A33B981EE78FBDD6671B6A7DF0246A5419CCEA2B9020EB374637A05D7CC` |
| `02_detached_checker/P3CDifferentialChecker.lean` | `6C0AC3B98803F7D361ACAF25C2A780FF13C9ED272D74E4496B7345331EFF7415` | `CEE7CF7A63FE7294BC4A40CB75C3BEDF200AA2E1DDCE6C2D5800BE7ACF1C19B3` |
| `02_detached_checker/P3CDifferentialChecker/DifferentialTraceObserver.lean` | `A46D160BB03DF9AA1D829F2AA88C141803A07C7C4BCE16279C9D91FE9C944E57` | `CB825F4AFB04611D3EBA027915FCC15D6E6B2CCDB9482E4B33ADA435EF25B446` |
| `03_counterexamples/P3CDifferentialAttacks.lean` | `C3D351827F9A31F964D788DEBE8AEB41AB5148D9FDAFDB54D6E29154C4D58975` | `41FA1958FD2AB863BD938BE6D5C7FD376A19BF0B3C47646B2DE6AEF371160168` |
| `03_counterexamples/P3CDifferentialAttacks/OrthogonalAttackSuiteD01ToD12.lean` | `CAF5C44E4879919842F595363093FE593D3764C8212FF6242525EF26C8623CE7` | `1CD2234C2CA19EC141F229BFAB360FDB76FCCCA4B5318ECD54C72440DC8880FD` |
| `04_proof_obligations/P3CDifferentialObligations.lean` | `EE412CE5FC5C69D537412C4380F424231D522BB0AFDCA20363237EFC58EE0822` | `9CA7F467DC2FE079BC6FEE18A0B169A8FAA0994CE1109D593D4EECE939730189` |
| `04_proof_obligations/P3CDifferentialObligations/PO_DIFF_01_To_08.lean` | `DDE78809CE366D28BAD11EFC812357F549916CB7B5CFFDE86A37E78705F296C7` | `0201706FD0C0FA273AFD52200DA92DE7987EFD65F70EEBBB9D53568F12ED1463` |
| `05_independent_tribunal/P3CDiffTribunalAudit.lean` | `C14301B464745718E7227B1E62710EB9A7F4BB349A9A56E685963ADEC3D31785` | `.olean`: `D88AEA2E97626A2682AD2E04229A8170D70168E494EB4AB58138FE05894455B8`<br>`.exe`: `73EBE474CE26B02920375418F1F421F9487E331A45D4901A79EB5EB0EB56B917` |
| `05_independent_tribunal/independent_r0_semantic_oracle.py` | `C851070E75B338BA71605B22701ACE76DF032356552A27C647AD38B975899519` | *(independent Python 3.11.8 R0 oracle)* |
| `06_receipts/auth_p3c_differential_r1_verification_receipt.json` | `35927EB0B8DFC43AAF0CEB0B66CA386428C3097632F4E617907C9CD624CF8C11` | *(Differential R1 verification receipt)* |

---

## 6. Verbatim Unmodified Source, Config, Oracle & Receipt Files (`15/15` Blocks)

### File 1: `lean-toolchain` (SHA-256: `3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71`)
````text
leanprover/lean4:v4.33.1
````

### File 2: `lakefile.toml` (SHA-256: `B4FDD45CA5038E275978C0A7CE3CC16717226A5C782C5A412B50F878642E46BD`)
````toml
name = "pneuma_omega_p3c_differential_r1"
version = "0.1.0"
defaultTargets = ["P3CDifferentialSpec", "P3CDifferentialChecker", "P3CDifferentialAttacks", "P3CDifferentialObligations", "p3c_differential_r1_runner"]

[[require]]
name = "broca_omega_gate_c1_p2"
path = "../P2_DerivationReplay"

[[require]]
name = "broca_omega_gate_c1_p3a"
path = "../P3_LexicalGrammar"

[[require]]
name = "broca_omega_gate_c1_p3b"
path = "../P3B_BoundedParser"

[[require]]
name = "pneuma_omega_gate_c1_p3c"
path = "../P3C_SemanticNorm"

[[require]]
name = "pneuma_omega_p3c_provenance_r1"
path = "../P3C_Provenance_R1"

[[lean_lib]]
name = "P3CDifferentialSpec"
srcDir = "01_formal_spec"

[[lean_lib]]
name = "P3CDifferentialChecker"
srcDir = "02_detached_checker"

[[lean_lib]]
name = "P3CDifferentialAttacks"
srcDir = "03_counterexamples"

[[lean_lib]]
name = "P3CDifferentialObligations"
srcDir = "04_proof_obligations"

[[lean_exe]]
name = "p3c_differential_r1_runner"
srcDir = "05_independent_tribunal"
root = "P3CDiffTribunalAudit"
````

### File 3: `lake-manifest.json` (SHA-256: `3EF2C9E99C50134787DCEAF0A57BC77778E9B3CC633A3E810A305D8736A89164`)
````json
{"version": "1.2.0",
 "packagesDir": ".lake/packages",
 "packages":
 [{"type": "path",
   "scope": "",
   "name": "pneuma_omega_p3c_provenance_r1",
   "manifestFile": "lake-manifest.json",
   "inherited": false,
   "dir": "../P3C_Provenance_R1",
   "configFile": "lakefile.toml"},
  {"type": "path",
   "scope": "",
   "name": "pneuma_omega_gate_c1_p3c",
   "manifestFile": "lake-manifest.json",
   "inherited": false,
   "dir": "../P3C_SemanticNorm",
   "configFile": "lakefile.toml"},
  {"type": "path",
   "scope": "",
   "name": "broca_omega_gate_c1_p3b",
   "manifestFile": "lake-manifest.json",
   "inherited": false,
   "dir": "../P3B_BoundedParser",
   "configFile": "lakefile.toml"},
  {"type": "path",
   "scope": "",
   "name": "broca_omega_gate_c1_p3a",
   "manifestFile": "lake-manifest.json",
   "inherited": false,
   "dir": "../P3_LexicalGrammar",
   "configFile": "lakefile.toml"},
  {"type": "path",
   "scope": "",
   "name": "broca_omega_gate_c1_p2",
   "manifestFile": "lake-manifest.json",
   "inherited": false,
   "dir": "../P2_DerivationReplay",
   "configFile": "lakefile.toml"}],
 "name": "pneuma_omega_p3c_differential_r1",
 "lakeDir": ".lake",
 "fixedToolchain": false}
````

### File 4: `01_formal_spec/P3CDifferentialSpec.lean` (SHA-256: `618C51038F549FC68B0D788FC9E32A1C8B3945091B76C43A80D0F445D926C996`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1
  Root export for `P3CDifferentialSpec`
-/
import P3CDifferentialSpec.TypedWireFormatV1
import P3CDifferentialSpec.DifferentialAlgebraSpec
````

### File 5: `01_formal_spec/P3CDifferentialSpec/TypedWireFormatV1.lean` (SHA-256: `945EA3C6471C6336974D85A5EE0C48A6217F32094160DAF7E82AA0ABA710768A`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate A` & `Corrigendum R0` `F-DIFF-P0-01` / `PO-DIFF-01..06`)
  01_formal_spec/P3CDifferentialSpec/TypedWireFormatV1.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`)

  Implements `PNEUMA-DIFF-SER-V1` Canonical Prefix-Free Typed Serialization:
    1. Explicit separation between arbitrary `String` and valid canonical encodings `ValidWireEncoding C s`.
    2. Generic `CanonicalWireCodec α` proving:
       - `PO-DIFF-01a` (`Roundtrip`)            : `decodeWire C (encodeWire C x) = .ok x`
       - `PO-DIFF-01b` (`Canonical Uniqueness`) : `decodeWire C s = .ok x ↔ encodeWire C x = s`
       - `PO-DIFF-01c` (`Malformed Rejection`)  : `(∀ x, encodeWire C x ≠ s) → ∃ e, decodeWire C s = .error e`
       - `PO-DIFF-02`  (`Encoding Injectivity`) : `encodeWire C x = encodeWire C y → x = y`
    3. Explicit `cpLen` AND `utf8ByteLen` on every serialized string (`STR;N#<cpLen>;N#<utf8Bytes>;...`),
       plus `PO-DIFF-03` (`Span Unit Integrity`) proving 1-byte = 1-codepoint on `StrictAsciiDomainSupported`
       and deterministic `.outOfDomain` rejection on multi-byte UTF-8 (`>= 0x80`).
    4. Full codecs for `CodepointSpan`, `ConcreteParseTree`, `List ConcreteParseTree`, `RawSemanticTerm`,
       `CanonicalMeaning`, `ForestExtractionError`, extraction `Except` results, and 5-way `SemanticNormOutcome`.
-/
import P3CProvenanceObligations

namespace PneumaOmega.P3C.DifferentialR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C

/-! ### 1. Deterministic Wire Decode Rejection Diagnostics (`F-DIFF-P0-01`) -/

inductive DecodeRejectDiag where
  | emptyWirePayload
  | unterminatedTokenMissingSemicolon
  | emptyTokenSegment
  | missingHeaderTokens
  | invalidVersionHeader        (found : String)
  | typeTagMismatch             (expected found : String)
  | unexpectedEndOfTokens       (context : String)
  | recursionFuelExhausted
  | malformedNatToken           (found : String)
  | leadingZeroInNatToken       (found : String)
  | uint8OutOfRange             (val : Nat)
  | malformedCharToken          (found : String)
  | invalidUnicodeScalar        (val : Nat)
  | stringByteVsCodepointMismatch (declaredBytes actualBytes : Nat)
  | unknownConstructorTag       (typeName found : String)
  | trailingUnconsumedTokens    (remainingCount : Nat)
  | nonCanonicalWireEncoding
  deriving DecidableEq, Repr

/-! ### 2. Semicolon-Delimited Token Framing Over `List Char` (`DIFFV1;<TypeTag>;<toks...>;`) -/

def joinSemiChars : List String → List Char
  | []      => []
  | t :: ts => t.toList ++ (';' :: joinSemiChars ts)

def readUntilSemi : List Char → Option (List Char × List Char)
  | []      => none
  | c :: cs =>
    if c == ';' then some ([], cs)
    else
      match readUntilSemi cs with
      | none           => none
      | some (tok, rs) => some (c :: tok, rs)

theorem readUntilSemi_append (tok rest : List Char) (hno : ';' ∉ tok) :
    readUntilSemi (tok ++ (';' :: rest)) = some (tok, rest) := by
  induction tok with
  | nil => rfl
  | cons c cs ih =>
    have hc : c ≠ ';' := fun heq => hno (by rw [heq]; exact List.Mem.head cs)
    have hcs : ';' ∉ cs := fun hm => hno (List.Mem.tail c hm)
    simp only [List.cons_append, readUntilSemi]
    have hbeq : (c == ';') = false := beq_false_of_ne hc
    rw [hbeq, ih hcs]
    rfl

def splitSemiChars (fuel : Nat) (cs : List Char) : Except DecodeRejectDiag (List String) :=
  match fuel, cs with
  | _, [] => .ok []
  | 0, _ :: _ => .error .recursionFuelExhausted
  | f + 1, _ :: _ =>
    match readUntilSemi cs with
    | none => .error .unterminatedTokenMissingSemicolon
    | some ([], _) => .error .emptyTokenSegment
    | some (c :: tokTail, rest) =>
      match splitSemiChars f rest with
      | .error e  => .error e
      | .ok tails => .ok (String.ofList (c :: tokTail) :: tails)

theorem joinSemiChars_length_ge (ts : List String) :
    ts.length ≤ (joinSemiChars ts).length := by
  induction ts with
  | nil => simp [joinSemiChars]
  | cons t rest ih =>
    simp only [joinSemiChars, List.length_append, List.length_cons]
    omega

theorem splitSemiChars_joinSemiChars (ts : List String) (fuel : Nat)
    (hfuel : ts.length ≤ fuel)
    (hnonempty : ∀ t ∈ ts, t ≠ "")
    (hnosemi : ∀ t ∈ ts, ';' ∉ t.toList) :
    splitSemiChars fuel (joinSemiChars ts) = .ok ts := by
  induction ts generalizing fuel with
  | nil =>
    cases fuel <;> rfl
  | cons t rest ih =>
    cases fuel with
    | zero => simp at hfuel
    | succ f =>
      have ht_ne : t ≠ "" := hnonempty t (List.Mem.head rest)
      have ht_ns : ';' ∉ t.toList := hnosemi t (List.Mem.head rest)
      have htl_ne : t.toList ≠ [] := by
        intro hemp
        apply ht_ne
        have h1 : String.ofList t.toList = String.ofList [] := congrArg String.ofList hemp
        simpa using h1
      cases hchars : t.toList with
      | nil => exact False.elim (htl_ne hchars)
      | cons c0 ctail =>
        have hns' : ';' ∉ (c0 :: ctail) := by rw [← hchars]; exact ht_ns
        have hjoin : joinSemiChars (t :: rest) = (c0 :: ctail) ++ (';' :: joinSemiChars rest) := by
          simp [joinSemiChars, hchars]
        rw [hjoin]
        simp only [List.cons_append, splitSemiChars]
        have hread : readUntilSemi (c0 :: (ctail ++ ';' :: joinSemiChars rest)) =
                     some (c0 :: ctail, joinSemiChars rest) := by
          simpa [List.cons_append] using readUntilSemi_append (c0 :: ctail) (joinSemiChars rest) hns'
        rw [hread]
        dsimp only
        have hf_rest : rest.length ≤ f := by simp at hfuel; omega
        have hrec := ih f hf_rest
          (fun x hx => hnonempty x (List.Mem.tail t hx))
          (fun x hx => hnosemi x (List.Mem.tail t hx))
        rw [hrec]
        have hstr : String.ofList (c0 :: ctail) = t := by
          rw [← hchars, String.ofList_toList]
        rw [hstr]

/-! ### 3. Generic `CanonicalWireCodec` & `PO-DIFF-01` / `PO-DIFF-02` Metatheorems -/

def ValidToken (t : String) : Prop :=
  t ≠ "" ∧ ';' ∉ t.toList

def checkValidTokenBool (t : String) : Bool :=
  (!t.isEmpty) && (!(t.toList.contains ';'))

theorem checkValidTokenBool_sound {t : String} (h : checkValidTokenBool t = true) :
    ValidToken t := by
  unfold checkValidTokenBool at h
  rw [Bool.and_eq_true] at h
  rcases h with ⟨hne, hnc⟩
  refine ⟨?_, ?_⟩
  · intro heq; subst heq; simp at hne
  · intro hmem
    have hc : t.toList.contains ';' = true := List.elem_eq_true_of_mem hmem
    rw [hc] at hnc; contradiction

structure CanonicalWireCodec (α : Type) where
  typeTag      : String
  encToks      : α → List String
  parseToks    : Nat → List String → Except DecodeRejectDiag (α × List String)
  hTagValid    : ValidToken typeTag
  hToksValid   : ∀ (x : α), (encToks x ≠ []) ∧ (∀ t ∈ encToks x, ValidToken t)
  hParsePrefix : ∀ (x : α) (rest : List String) (fuel : Nat),
    (encToks x).length ≤ fuel →
    parseToks fuel (encToks x ++ rest) = .ok (x, rest)

/-- Canonical `PNEUMA-DIFF-SER-V1` encoder (`"DIFFV1;<TypeTag>;<tok_1>;...;<tok_k>;"`). -/
def encodeWire {α : Type} (C : CanonicalWireCodec α) (x : α) : String :=
  String.ofList (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x))

/-- Declarative membership in the canonical wire language `L_valid(C)` (`F-DIFF-P0-01`). -/
def ValidWireEncoding {α : Type} (C : CanonicalWireCodec α) (s : String) : Prop :=
  ∃ x : α, encodeWire C x = s

/--
  Canonical `PNEUMA-DIFF-SER-V1` decoder:
  Parses tokens, rejects any malformed/truncated/trailing/non-canonical input with a pinpoint
  `DecodeRejectDiag`, and accepts iff `s` is the unique canonical encoding of `x` (`F-DIFF-P0-01`).
-/
def decodeWire {α : Type} (C : CanonicalWireCodec α) (s : String) : Except DecodeRejectDiag α :=
  if s.toList.isEmpty then
    .error .emptyWirePayload
  else
    match splitSemiChars s.toList.length s.toList with
    | .error e => .error e
    | .ok toks =>
      match toks with
      | ver :: ttag :: body =>
        if !eqStrBool ver "DIFFV1" then
          .error (.invalidVersionHeader ver)
        else if !eqStrBool ttag C.typeTag then
          .error (.typeTagMismatch C.typeTag ttag)
        else
          match C.parseToks body.length body with
          | .error e => .error e
          | .ok (val, rem) =>
            match rem with
            | _ :: _ => .error (.trailingUnconsumedTokens rem.length)
            | [] =>
              if eqStrBool (encodeWire C val) s then
                .ok val
              else
                .error .nonCanonicalWireEncoding
      | _ => .error .missingHeaderTokens

/-- **`PO-DIFF-01a` (`Roundtrip`)**: Every value `x : α` decodes back to `.ok x`. -/
theorem encodeWire_decodeWire_roundtrip {α : Type} (C : CanonicalWireCodec α) (x : α) :
    decodeWire C (encodeWire C x) = .ok x := by
  unfold decodeWire encodeWire
  rw [String.toList_ofList]
  have hne_cs : (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)).isEmpty = false := by
    simp [joinSemiChars]
  rw [hne_cs]
  have hall_valid : ∀ t ∈ ("DIFFV1" :: C.typeTag :: C.encToks x), ValidToken t := by
    intro t ht
    rcases List.mem_cons.mp ht with rfl | ht2
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp ht2 with rfl | ht3
      · exact C.hTagValid
      · exact (C.hToksValid x).2 t ht3
  have hlen : ("DIFFV1" :: C.typeTag :: C.encToks x).length ≤
              (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)).length :=
    joinSemiChars_length_ge _
  have hsplit : splitSemiChars (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)).length
                  (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)) =
                .ok ("DIFFV1" :: C.typeTag :: C.encToks x) :=
    splitSemiChars_joinSemiChars _ _ hlen
      (fun t ht => (hall_valid t ht).1)
      (fun t ht => (hall_valid t ht).2)
  have hparse : C.parseToks (C.encToks x).length (C.encToks x) = .ok (x, []) := by
    simpa using C.hParsePrefix x [] (C.encToks x).length (Nat.le_refl _)
  have hver : eqStrBool "DIFFV1" "DIFFV1" = true := (eqStrBool_iff _ _).mpr rfl
  have httag : eqStrBool C.typeTag C.typeTag = true := (eqStrBool_iff _ _).mpr rfl
  have henc_eq : eqStrBool (String.ofList (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)))
                   (String.ofList (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x))) = true :=
    (eqStrBool_iff _ _).mpr rfl
  simp only [hsplit, hver, httag, hparse, henc_eq, Bool.not_true, Bool.false_eq_true, ↓reduceIte]

/--
  **`PO-DIFF-01b` (`Canonical Encoding Uniqueness` — `Corrigendum F-DIFF-P0-01`)**:
  `decodeWire C s` returns `.ok x` **if and only if** `s` is literally equal to `encodeWire C x`!
-/
theorem decodeWire_ok_iff_encodeWire_eq {α : Type} (C : CanonicalWireCodec α)
    (s : String) (x : α) :
    decodeWire C s = .ok x ↔ encodeWire C x = s := by
  constructor
  · intro hd
    unfold decodeWire at hd
    by_cases hemp : s.toList.isEmpty = true
    · rw [if_pos hemp] at hd; contradiction
    · rw [if_neg hemp] at hd
      cases hsp : splitSemiChars s.toList.length s.toList with
      | error _ => rw [hsp] at hd; contradiction
      | ok toks =>
        rw [hsp] at hd
        cases toks with
        | nil => contradiction
        | cons ver rest1 =>
          cases rest1 with
          | nil => contradiction
          | cons ttag body =>
            dsimp only at hd
            by_cases hv : (!eqStrBool ver "DIFFV1") = true
            · rw [if_pos hv] at hd; contradiction
            · rw [if_neg hv] at hd
              by_cases ht : (!eqStrBool ttag C.typeTag) = true
              · rw [if_pos ht] at hd; contradiction
              · rw [if_neg ht] at hd
                cases hp : C.parseToks body.length body with
                | error _ => rw [hp] at hd; contradiction
                | ok pair =>
                  rw [hp] at hd
                  rcases pair with ⟨val, rem⟩
                  cases rem with
                  | cons _ _ => contradiction
                  | nil =>
                    dsimp only at hd
                    by_cases hc : eqStrBool (encodeWire C val) s = true
                    · rw [if_pos hc] at hd
                      injection hd with hval
                      subst val
                      exact (eqStrBool_iff _ _).mp hc
                    · rw [if_neg hc] at hd; contradiction
  · intro heq
    rw [← heq]
    exact encodeWire_decodeWire_roundtrip C x

/-- **`PO-DIFF-02` (`Encoding Injectivity`)**: `encodeWire C x = encodeWire C y → x = y`. -/
theorem encodeWire_injective {α : Type} (C : CanonicalWireCodec α) {x y : α}
    (h : encodeWire C x = encodeWire C y) :
    x = y := by
  have h1 := encodeWire_decodeWire_roundtrip C x
  rw [h, encodeWire_decodeWire_roundtrip C y] at h1
  injection h1 with h2
  exact h2.symm

/--
  **`PO-DIFF-01c` (`Malformed / Non-Canonical Rejection` — `Corrigendum F-DIFF-P0-01`)**:
  Every string `s ∉ L_valid(C)` is deterministically rejected with an explicit `.error diag`!
-/
theorem malformed_wire_rejected {α : Type} (C : CanonicalWireCodec α) (s : String)
    (hInvalid : ¬ ValidWireEncoding C s) :
    ∃ err : DecodeRejectDiag, decodeWire C s = .error err := by
  cases hd : decodeWire C s with
  | error e => exact ⟨e, rfl⟩
  | ok x =>
    have heq : encodeWire C x = s := (decodeWire_ok_iff_encodeWire_eq C s x).mp hd
    exact False.elim (hInvalid ⟨x, heq⟩)

/-! ### 4. Canonical `Nat`, `UInt8`, `Char`, `String` & UTF-8 Byte-vs-Codepoint Primitives -/

def digitChar (d : Nat) : Char :=
  Char.ofNat (48 + d)

def parseDigitChar (c : Char) : Option Nat :=
  let n := c.toNat
  if 48 ≤ n && n ≤ 57 then some (n - 48) else none

theorem digitChar_props {d : Nat} (hd : d < 10) :
    parseDigitChar (digitChar d) = some d ∧ digitChar d ≠ ';' ∧ (0 < d → digitChar d ≠ '0') := by
  match d with
  | 0 => decide
  | 1 => decide
  | 2 => decide
  | 3 => decide
  | 4 => decide
  | 5 => decide
  | 6 => decide
  | 7 => decide
  | 8 => decide
  | 9 => decide
  | _ + 10 => omega

theorem parseDigitChar_digitChar {d : Nat} (hd : d < 10) :
    parseDigitChar (digitChar d) = some d :=
  (digitChar_props hd).1

theorem digitChar_ne_semi {d : Nat} (hd : d < 10) :
    digitChar d ≠ ';' :=
  (digitChar_props hd).2.1

def natToDecCharsAux : Nat → Nat → List Char
  | 0, n     => [digitChar (n % 10)]
  | f + 1, n =>
    if n < 10 then [digitChar n]
    else natToDecCharsAux f (n / 10) ++ [digitChar (n % 10)]

def natToDecChars (n : Nat) : List Char :=
  natToDecCharsAux n n

private theorem natToDecCharsAux_eq (f1 f2 n : Nat) (hf1 : n ≤ f1) (hf2 : n ≤ f2) :
    natToDecCharsAux f1 n = natToDecCharsAux f2 n := by
  induction f1 generalizing f2 n with
  | zero =>
    have hn0 : n = 0 := by omega
    subst hn0; cases f2 <;> rfl
  | succ k ih =>
    cases f2 with
    | zero =>
      have hn0 : n = 0 := by omega
      subst hn0; rfl
    | succ m =>
      simp only [natToDecCharsAux]
      by_cases hk : n < 10
      · simp [hk]
      · simp only [hk, ↓reduceIte]
        rw [ih m (n / 10) (by omega) (by omega)]

theorem natToDecChars_step (n : Nat) :
    natToDecChars n =
      if n < 10 then [digitChar n]
      else natToDecChars (n / 10) ++ [digitChar (n % 10)] := by
  cases n with
  | zero => decide
  | succ k =>
    unfold natToDecChars
    simp only [natToDecCharsAux]
    by_cases hk : k + 1 < 10
    · simp [hk]
    · simp only [hk, ↓reduceIte]
      rw [natToDecCharsAux_eq k ((k + 1) / 10) ((k + 1) / 10) (by omega) (by omega)]

theorem natToDecChars_nonempty (n : Nat) : natToDecChars n ≠ [] := by
  rw [natToDecChars_step]
  by_cases hk : n < 10
  · rw [if_pos hk]; simp
  · rw [if_neg hk]; intro h; simp at h

theorem natToDecChars_no_semi (n : Nat) : ';' ∉ natToDecChars n := by
  induction n using Nat.strongRecOn with
  | ind k ih =>
    rw [natToDecChars_step]
    by_cases hk : k < 10
    · rw [if_pos hk]
      intro hm
      rcases List.mem_cons.mp hm with heq | hnil
      · exact digitChar_ne_semi hk heq.symm
      · nomatch hnil
    · rw [if_neg hk]
      intro hm
      rcases List.mem_append.mp hm with hl | hr
      · exact ih (k / 10) (by omega) hl
      · rcases List.mem_cons.mp hr with heq | hnil
        · exact digitChar_ne_semi (Nat.mod_lt k (by omega)) heq.symm
        · nomatch hnil

theorem natToDecChars_head_ne_zero {n : Nat} (hpos : 0 < n) :
    ∀ rest, natToDecChars n ≠ '0' :: rest := by
  induction n using Nat.strongRecOn with
  | ind k ih =>
    intro rest
    rw [natToDecChars_step]
    by_cases hk : k < 10
    · rw [if_pos hk]
      intro heq
      injection heq with hc _
      exact (digitChar_props hk).2.2 hpos hc
    · rw [if_neg hk]
      intro heq
      cases hdiv : natToDecChars (k / 10) with
      | nil => exact natToDecChars_nonempty (k / 10) hdiv
      | cons c0 ctail =>
        rw [hdiv] at heq
        simp only [List.cons_append] at heq
        injection heq with hc0 _
        subst c0
        exact ih (k / 10) (by omega) (by omega) ctail hdiv

def decDigitsAcc (acc : Nat) : List Char → Option Nat
  | []      => some acc
  | c :: cs =>
    match parseDigitChar c with
    | none   => none
    | some d => decDigitsAcc (acc * 10 + d) cs

theorem decDigitsAcc_natToDecChars (n : Nat) (rest : List Char) :
    decDigitsAcc 0 (natToDecChars n ++ rest) = decDigitsAcc n rest := by
  induction n using Nat.strongRecOn generalizing rest with
  | ind k ih =>
    rw [natToDecChars_step]
    by_cases hk : k < 10
    · rw [if_pos hk]
      simp only [List.singleton_append, decDigitsAcc, parseDigitChar_digitChar hk,
                 Nat.zero_mul, Nat.zero_add]
    · rw [if_neg hk]
      rw [List.append_assoc, List.singleton_append]
      rw [ih (k / 10) (by omega) (digitChar (k % 10) :: rest)]
      have hmod : k % 10 < 10 := Nat.mod_lt k (by omega)
      simp only [decDigitsAcc, parseDigitChar_digitChar hmod]
      have hdivmod : k / 10 * 10 + k % 10 = k := by omega
      rw [hdivmod]

def encNatTok (n : Nat) : String :=
  String.ofList ('N' :: '#' :: natToDecChars n)

theorem encNatTok_valid (n : Nat) : ValidToken (encNatTok n) := by
  refine ⟨?_, ?_⟩
  · intro h
    have hl : (encNatTok n).toList = [] := by rw [h]; rfl
    simp [encNatTok, String.toList_ofList] at hl
  · intro hm
    simp only [encNatTok, String.toList_ofList, List.mem_cons] at hm
    rcases hm with h1 | h2 | h3
    · cases h1
    · cases h2
    · exact natToDecChars_no_semi n h3

def parseNatTok (tok : String) : Except DecodeRejectDiag Nat :=
  match tok.toList with
  | 'N' :: '#' :: c0 :: cs =>
    if c0 == '0' then
      if cs.isEmpty then .ok 0 else .error (.leadingZeroInNatToken tok)
    else
      match decDigitsAcc 0 (c0 :: cs) with
      | some n => .ok n
      | none   => .error (.malformedNatToken tok)
  | _ => .error (.malformedNatToken tok)

theorem parseNatTok_encNatTok (n : Nat) :
    parseNatTok (encNatTok n) = .ok n := by
  by_cases hz : n = 0
  · subst hz
    unfold parseNatTok encNatTok
    rw [String.toList_ofList]
    have h0 : natToDecChars 0 = ['0'] := by decide
    rw [h0]
    rfl
  · have hpos : 0 < n := by omega
    unfold parseNatTok encNatTok
    rw [String.toList_ofList]
    cases hd : natToDecChars n with
    | nil => exact False.elim (natToDecChars_nonempty n hd)
    | cons c0 cs =>
      by_cases hc0 : c0 = '0'
      · subst c0
        exact False.elim (natToDecChars_head_ne_zero hpos cs hd)
      · have hdec : decDigitsAcc 0 (c0 :: cs) = some n := by
          rw [← hd]
          simpa [decDigitsAcc] using decDigitsAcc_natToDecChars n []
        have hbeq : (c0 == '0') = false := beq_false_of_ne hc0
        simp only [hbeq, Bool.false_eq_true, ↓reduceIte, hdec]

def parseNatStep (toks : List String) : Except DecodeRejectDiag (Nat × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "Nat")
  | t :: rs =>
    match parseNatTok t with
    | .error e => .error e
    | .ok n    => .ok (n, rs)

theorem parseNatStep_enc (n : Nat) (rest : List String) :
    parseNatStep (encNatTok n :: rest) = .ok (n, rest) := by
  simp [parseNatStep, parseNatTok_encNatTok]

/-! ### 5. UTF-8 Byte-Length vs Unicode Codepoint-Length Primitives & `PO-DIFF-03` -/

/-- Exact RFC 3629 UTF-8 byte length of a single Unicode scalar `Char`. -/
def utf8ByteLenOfChar (c : Char) : Nat :=
  let n := c.toNat
  if n ≤ 0x7F then 1
  else if n ≤ 0x7FF then 2
  else if n ≤ 0xFFFF then 3
  else 4

def utf8ByteLenOfChars : List Char → Nat
  | []      => 0
  | c :: cs => utf8ByteLenOfChar c + utf8ByteLenOfChars cs

theorem char_ofNat_toNat (c : Char) : Char.ofNat c.toNat = c := by
  cases c with
  | mk val valid =>
    unfold Char.ofNat Char.toNat
    dsimp only
    split
    · congr
    · rename_i hnv; exact False.elim (hnv valid)

def isValidUnicodeScalarBool (n : Nat) : Bool :=
  (n < 0xD800) || ((0xDFFF < n) && (n ≤ 0x10FFFF))

theorem isValidUnicodeScalarBool_of_char (c : Char) :
    isValidUnicodeScalarBool c.toNat = true := by
  unfold isValidUnicodeScalarBool
  have hv : Char.isValidCharNat c.toNat := c.valid
  unfold Char.isValidCharNat at hv
  rcases hv with h1 | ⟨h2, h3⟩
  · simp [h1]
  · have h3' : c.toNat ≤ 0x10FFFF := by omega
    simp [h2, h3']

def encCharTok (c : Char) : String :=
  String.ofList ('C' :: '#' :: natToDecChars c.toNat)

theorem encCharTok_valid (c : Char) : ValidToken (encCharTok c) := by
  refine ⟨?_, ?_⟩
  · intro h
    have hl : (encCharTok c).toList = [] := by rw [h]; rfl
    simp [encCharTok, String.toList_ofList] at hl
  · intro hm
    simp only [encCharTok, String.toList_ofList, List.mem_cons] at hm
    rcases hm with h1 | h2 | h3
    · cases h1
    · cases h2
    · exact natToDecChars_no_semi c.toNat h3

def parseCharTok (tok : String) : Except DecodeRejectDiag Char :=
  match tok.toList with
  | 'C' :: '#' :: c0 :: cs =>
    if c0 == '0' then
      if cs.isEmpty then .ok (Char.ofNat 0) else .error (.leadingZeroInNatToken tok)
    else
      match decDigitsAcc 0 (c0 :: cs) with
      | none => .error (.malformedCharToken tok)
      | some n =>
        if isValidUnicodeScalarBool n then .ok (Char.ofNat n)
        else .error (.invalidUnicodeScalar n)
  | _ => .error (.malformedCharToken tok)

theorem parseCharTok_encCharTok (c : Char) :
    parseCharTok (encCharTok c) = .ok c := by
  by_cases hz : c.toNat = 0
  · unfold parseCharTok encCharTok
    rw [hz, String.toList_ofList]
    have h0 : natToDecChars 0 = ['0'] := by decide
    rw [h0]
    simp only [beq_self_eq_true, List.isEmpty_nil, ↓reduceIte, ← hz, char_ofNat_toNat]
  · have hpos : 0 < c.toNat := by omega
    unfold parseCharTok encCharTok
    rw [String.toList_ofList]
    cases hd : natToDecChars c.toNat with
    | nil => exact False.elim (natToDecChars_nonempty c.toNat hd)
    | cons c0 cs =>
      by_cases hc0 : c0 = '0'
      · subst c0
        exact False.elim (natToDecChars_head_ne_zero hpos cs hd)
      · have hdec : decDigitsAcc 0 (c0 :: cs) = some c.toNat := by
          rw [← hd]
          simpa [decDigitsAcc] using decDigitsAcc_natToDecChars c.toNat []
        have hv : isValidUnicodeScalarBool c.toNat = true := isValidUnicodeScalarBool_of_char c
        have hbeq : (c0 == '0') = false := beq_false_of_ne hc0
        simp only [hbeq, Bool.false_eq_true, ↓reduceIte, hdec, hv, char_ofNat_toNat]

def parseNChars : Nat → List String → Except DecodeRejectDiag (List Char × List String)
  | 0, toks => .ok ([], toks)
  | _ + 1, [] => .error (.unexpectedEndOfTokens "CharSeq")
  | k + 1, t :: ts =>
    match parseCharTok t with
    | .error e => .error e
    | .ok ch =>
      match parseNChars k ts with
      | .error e => .error e
      | .ok (chs, rem) => .ok (ch :: chs, rem)

theorem parseNChars_map (cs : List Char) (rest : List String) :
    parseNChars cs.length (cs.map encCharTok ++ rest) = .ok (cs, rest) := by
  induction cs with
  | nil => rfl
  | cons c tail ih =>
    simp only [List.length_cons, List.map_cons, List.cons_append, parseNChars,
               parseCharTok_encCharTok, ih]

/--
  Encodes `s : String` with EXPLICIT codepoint count AND UTF-8 byte count:
  `["STR", "N#<cpLen>", "N#<utf8ByteLen>", "C#<u_1>", ..., "C#<u_k>"]`.
-/
def encStrSeq (s : String) : List String :=
  let cs := s.toList
  "STR" :: encNatTok cs.length :: encNatTok (utf8ByteLenOfChars cs) :: cs.map encCharTok

theorem encStrSeq_valid (s : String) :
    encStrSeq s ≠ [] ∧ ∀ t ∈ encStrSeq s, ValidToken t := by
  refine ⟨by simp [encStrSeq], ?_⟩
  intro t ht
  simp only [encStrSeq] at ht
  rcases List.mem_cons.mp ht with rfl | ht1
  · exact checkValidTokenBool_sound (by decide)
  · rcases List.mem_cons.mp ht1 with rfl | ht2
    · exact encNatTok_valid _
    · rcases List.mem_cons.mp ht2 with rfl | ht3
      · exact encNatTok_valid _
      · rcases List.mem_map.mp ht3 with ⟨c, _, rfl⟩
        exact encCharTok_valid c

def parseStrStep (toks : List String) : Except DecodeRejectDiag (String × List String) :=
  match toks with
  | "STR" :: rest1 =>
    match parseNatStep rest1 with
    | .error e => .error e
    | .ok (cpLen, rest2) =>
      match parseNatStep rest2 with
      | .error e => .error e
      | .ok (byteLen, rest3) =>
        match parseNChars cpLen rest3 with
        | .error e => .error e
        | .ok (chars, rem) =>
          let actualBytes := utf8ByteLenOfChars chars
          if actualBytes == byteLen then
            .ok (String.ofList chars, rem)
          else
            .error (.stringByteVsCodepointMismatch byteLen actualBytes)
  | t :: _ => .error (.unknownConstructorTag "String" t)
  | []     => .error (.unexpectedEndOfTokens "String")

theorem parseStrStep_enc (s : String) (rest : List String) :
    parseStrStep (encStrSeq s ++ rest) = .ok (s, rest) := by
  simp only [encStrSeq, List.cons_append, parseStrStep, parseNatStep_enc,
             parseNChars_map, beq_self_eq_true, ↓reduceIte]
  rw [String.ofList_toList]

/-! ### 6. Finite Enum & `UInt8` / `Option` / `List` Combinators (Preserving Exact Constructor Names) -/

def parseTagExpect (typeName expected : String) (toks : List String) :
    Except DecodeRejectDiag (List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens typeName)
  | t :: rs =>
    if eqStrBool t expected then .ok rs
    else .error (.unknownConstructorTag typeName t)

theorem parseTagExpect_self (typeName expected : String) (rest : List String) :
    parseTagExpect typeName expected (expected :: rest) = .ok rest := by
  unfold parseTagExpect
  dsimp only
  rw [(eqStrBool_iff expected expected).mpr rfl]
  rfl

def encUInt8Seq (b : UInt8) : List String :=
  ["UInt8.ofNat", encNatTok b.toNat]

def parseUInt8Step (toks : List String) : Except DecodeRejectDiag (UInt8 × List String) := do
  let r1 ← parseTagExpect "UInt8" "UInt8.ofNat" toks
  let (n, r2) ← parseNatStep r1
  if n < 256 then
    .ok (UInt8.ofNat n, r2)
  else
    .error (.uint8OutOfRange n)

theorem parseUInt8Step_enc (b : UInt8) (rest : List String) :
    parseUInt8Step (encUInt8Seq b ++ rest) = .ok (b, rest) := by
  unfold encUInt8Seq parseUInt8Step
  simp only [List.cons_append, List.nil_append, Bind.bind, Except.bind,
             parseTagExpect_self, parseNatStep_enc]
  have hlt : b.toNat < 256 := UInt8.toNat_lt b
  rw [if_pos hlt]
  simp

def encOptStrSeq : Option String → List String
  | none   => ["Option.none"]
  | some s => "Option.some" :: encStrSeq s

def parseOptStrStep (toks : List String) : Except DecodeRejectDiag (Option String × List String) :=
  match toks with
  | "Option.none" :: rs => .ok (none, rs)
  | "Option.some" :: rs => do
    let (s, rem) ← parseStrStep rs
    .ok (some s, rem)
  | t :: _ => .error (.unknownConstructorTag "OptionString" t)
  | []     => .error (.unexpectedEndOfTokens "OptionString")

theorem parseOptStrStep_enc (o : Option String) (rest : List String) :
    parseOptStrStep (encOptStrSeq o ++ rest) = .ok (o, rest) := by
  cases o with
  | none => rfl
  | some s =>
    simp [encOptStrSeq, parseOptStrStep, Bind.bind, Except.bind, parseStrStep_enc]

def encOptPairStrSeq : Option (String × String) → List String
  | none          => ["Option.none"]
  | some (s1, s2) => "Option.some" :: (encStrSeq s1 ++ encStrSeq s2)

def parseOptPairStrStep (toks : List String) :
    Except DecodeRejectDiag (Option (String × String) × List String) :=
  match toks with
  | "Option.none" :: rs => .ok (none, rs)
  | "Option.some" :: rs => do
    let (s1, r1) ← parseStrStep rs
    let (s2, r2) ← parseStrStep r1
    .ok (some (s1, s2), r2)
  | t :: _ => .error (.unknownConstructorTag "OptionPairString" t)
  | []     => .error (.unexpectedEndOfTokens "OptionPairString")

theorem parseOptPairStrStep_enc (o : Option (String × String)) (rest : List String) :
    parseOptPairStrStep (encOptPairStrSeq o ++ rest) = .ok (o, rest) := by
  cases o with
  | none => rfl
  | some p =>
    rcases p with ⟨s1, s2⟩
    simp [encOptPairStrSeq, List.append_assoc, parseOptPairStrStep,
          Bind.bind, Except.bind, parseStrStep_enc]

/-! ### 7. Enum Name Tables (Exact Frozen Constructor Names) -/

def prodToWireName : FrozenParseProd → String
  | .Env_DocSingle          => "FrozenParseProd.Env_DocSingle"
  | .Env_ScopedInitial      => "FrozenParseProd.Env_ScopedInitial"
  | .Env_ScopedRepeat       => "FrozenParseProd.Env_ScopedRepeat"
  | .Env_ScopedAssoc        => "FrozenParseProd.Env_ScopedAssoc"
  | .Env_ScopedContrastMeta => "FrozenParseProd.Env_ScopedContrastMeta"
  | .Env_LiftAssoc          => "FrozenParseProd.Env_LiftAssoc"
  | .Env_LiftMeta           => "FrozenParseProd.Env_LiftMeta"
  | .Env_EmbeddedCausal     => "FrozenParseProd.Env_EmbeddedCausal"
  | .Gen_G01_DescIncidence  => "FrozenParseProd.Gen_G01_DescIncidence"
  | .Gen_G02a_DescMeanSD    => "FrozenParseProd.Gen_G02a_DescMeanSD"
  | .Gen_G02b_DescMedianIQR => "FrozenParseProd.Gen_G02b_DescMedianIQR"
  | .Gen_G03_AssocUnadj     => "FrozenParseProd.Gen_G03_AssocUnadj"
  | .Gen_G04_AssocTemp      => "FrozenParseProd.Gen_G04_AssocTemp"
  | .Gen_G05_CompRD         => "FrozenParseProd.Gen_G05_CompRD"
  | .Gen_G06a_IntervDirectional => "FrozenParseProd.Gen_G06a_IntervDirectional"
  | .Gen_G06b_IntervNeutral => "FrozenParseProd.Gen_G06b_IntervNeutral"
  | .Gen_G07_MetaNotStatSig => "FrozenParseProd.Gen_G07_MetaNotStatSig"
  | .Gen_G08_MetaEquiv      => "FrozenParseProd.Gen_G08_MetaEquiv"
  | .Gen_G09_MetaNonEstab   => "FrozenParseProd.Gen_G09_MetaNonEstab"
  | .Gen_G10_MetaUnresolved => "FrozenParseProd.Gen_G10_MetaUnresolved"
  | .Gen_G11_QuantZero      => "FrozenParseProd.Gen_G11_QuantZero"
  | .Gen_G12_QuantProperPart => "FrozenParseProd.Gen_G12_QuantProperPart"
  | .Gen_G13_QuantAtLeastOne => "FrozenParseProd.Gen_G13_QuantAtLeastOne"
  | .Gen_G14_AssocAdj       => "FrozenParseProd.Gen_G14_AssocAdj"
  | .Gen_G15a_DocConjAtomic => "FrozenParseProd.Gen_G15a_DocConjAtomic"
  | .Gen_G15b_DocConjDiscourse => "FrozenParseProd.Gen_G15b_DocConjDiscourse"
  | .Gen_G16_DocContrastive => "FrozenParseProd.Gen_G16_DocContrastive"
  | .Env_DocTrapScoped      => "FrozenParseProd.Env_DocTrapScoped"
  | .Env_ScopedTrap         => "FrozenParseProd.Env_ScopedTrap"
  | .Trap_T1_AllNot         => "FrozenParseProd.Trap_T1_AllNot"
  | .Trap_T2_ConfirmThat    => "FrozenParseProd.Trap_T2_ConfirmThat"
  | .Trap_T3_WhPresup       => "FrozenParseProd.Trap_T3_WhPresup"
  | .Trap_T4_BarePlural     => "FrozenParseProd.Trap_T4_BarePlural"
  | .Trap_T5_UnscopedDoc    => "FrozenParseProd.Trap_T5_UnscopedDoc"

def prodFromWireName (s : String) : Option FrozenParseProd :=
  allFrozenParseProds.find? (fun p => eqStrBool (prodToWireName p) s)

theorem prodToWireName_valid (p : FrozenParseProd) : ValidToken (prodToWireName p) := by
  apply checkValidTokenBool_sound
  cases p <;> decide

theorem prodFromWireName_toWireName (p : FrozenParseProd) :
    prodFromWireName (prodToWireName p) = some p := by
  cases p <;> decide

def parseProdStep (toks : List String) : Except DecodeRejectDiag (FrozenParseProd × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "FrozenParseProd")
  | t :: rs =>
    match prodFromWireName t with
    | some p => .ok (p, rs)
    | none   => .error (.unknownConstructorTag "FrozenParseProd" t)

theorem parseProdStep_enc (p : FrozenParseProd) (rest : List String) :
    parseProdStep (prodToWireName p :: rest) = .ok (p, rest) := by
  simp [parseProdStep, prodFromWireName_toWireName]

def allSlotSorts : List P3SlotSort :=
  [ .cohortSpec, .designNoun, .followUpWindow, .eventTerm, .measureTerm,
    .expLevel, .outTerm, .sourceId, .identAssump, .subgroupPlural,
    .subgroupSingular, .covariateList, .assocDir, .ratioMetric, .intervDirVerb,
    .intervVerbPres, .epistemicVerb, .whWord, .numericLit ]

def slotSortToWireName : P3SlotSort → String
  | .cohortSpec       => "P3SlotSort.cohortSpec"
  | .designNoun       => "P3SlotSort.designNoun"
  | .followUpWindow   => "P3SlotSort.followUpWindow"
  | .eventTerm        => "P3SlotSort.eventTerm"
  | .measureTerm      => "P3SlotSort.measureTerm"
  | .expLevel         => "P3SlotSort.expLevel"
  | .outTerm          => "P3SlotSort.outTerm"
  | .sourceId         => "P3SlotSort.sourceId"
  | .identAssump      => "P3SlotSort.identAssump"
  | .subgroupPlural   => "P3SlotSort.subgroupPlural"
  | .subgroupSingular => "P3SlotSort.subgroupSingular"
  | .covariateList    => "P3SlotSort.covariateList"
  | .assocDir         => "P3SlotSort.assocDir"
  | .ratioMetric      => "P3SlotSort.ratioMetric"
  | .intervDirVerb    => "P3SlotSort.intervDirVerb"
  | .intervVerbPres   => "P3SlotSort.intervVerbPres"
  | .epistemicVerb    => "P3SlotSort.epistemicVerb"
  | .whWord           => "P3SlotSort.whWord"
  | .numericLit       => "P3SlotSort.numericLit"

def slotSortFromWireName (s : String) : Option P3SlotSort :=
  allSlotSorts.find? (fun x => eqStrBool (slotSortToWireName x) s)

theorem slotSortToWireName_valid (x : P3SlotSort) : ValidToken (slotSortToWireName x) := by
  apply checkValidTokenBool_sound; cases x <;> decide

theorem slotSortFromWireName_toWireName (x : P3SlotSort) :
    slotSortFromWireName (slotSortToWireName x) = some x := by
  cases x <;> decide

def parseSlotSortStep (toks : List String) : Except DecodeRejectDiag (P3SlotSort × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "P3SlotSort")
  | t :: rs =>
    match slotSortFromWireName t with
    | some x => .ok (x, rs)
    | none   => .error (.unknownConstructorTag "P3SlotSort" t)

theorem parseSlotSortStep_enc (x : P3SlotSort) (rest : List String) :
    parseSlotSortStep (slotSortToWireName x :: rest) = .ok (x, rest) := by
  simp [parseSlotSortStep, slotSortFromWireName_toWireName]

def allBNFSlotTags : List BNFSlotTag :=
  [ .cohort, .design, .window, .eventA, .eventB, .measure, .activeExp, .refExp,
    .outcome, .source, .assumption, .subgroup, .covariates, .direction,
    .metric1, .metric2, .verb, .whComp, .numK, .numN, .numPct, .numEst,
    .numDisp1, .numDisp2, .numCILevel, .numCILow, .numCIHigh, .numPVal,
    .numAlpha, .numMarginLow, .numMarginHigh ]

def slotTagToWireName : BNFSlotTag → String
  | .cohort        => "BNFSlotTag.cohort"
  | .design        => "BNFSlotTag.design"
  | .window        => "BNFSlotTag.window"
  | .eventA        => "BNFSlotTag.eventA"
  | .eventB        => "BNFSlotTag.eventB"
  | .measure       => "BNFSlotTag.measure"
  | .activeExp     => "BNFSlotTag.activeExp"
  | .refExp        => "BNFSlotTag.refExp"
  | .outcome       => "BNFSlotTag.outcome"
  | .source        => "BNFSlotTag.source"
  | .assumption    => "BNFSlotTag.assumption"
  | .subgroup      => "BNFSlotTag.subgroup"
  | .covariates    => "BNFSlotTag.covariates"
  | .direction     => "BNFSlotTag.direction"
  | .metric1       => "BNFSlotTag.metric1"
  | .metric2       => "BNFSlotTag.metric2"
  | .verb          => "BNFSlotTag.verb"
  | .whComp        => "BNFSlotTag.whComp"
  | .numK          => "BNFSlotTag.numK"
  | .numN          => "BNFSlotTag.numN"
  | .numPct        => "BNFSlotTag.numPct"
  | .numEst        => "BNFSlotTag.numEst"
  | .numDisp1      => "BNFSlotTag.numDisp1"
  | .numDisp2      => "BNFSlotTag.numDisp2"
  | .numCILevel    => "BNFSlotTag.numCILevel"
  | .numCILow      => "BNFSlotTag.numCILow"
  | .numCIHigh     => "BNFSlotTag.numCIHigh"
  | .numPVal       => "BNFSlotTag.numPVal"
  | .numAlpha      => "BNFSlotTag.numAlpha"
  | .numMarginLow  => "BNFSlotTag.numMarginLow"
  | .numMarginHigh => "BNFSlotTag.numMarginHigh"

def slotTagFromWireName (s : String) : Option BNFSlotTag :=
  allBNFSlotTags.find? (fun x => eqStrBool (slotTagToWireName x) s)

theorem slotTagToWireName_valid (x : BNFSlotTag) : ValidToken (slotTagToWireName x) := by
  apply checkValidTokenBool_sound; cases x <;> decide

theorem slotTagFromWireName_toWireName (x : BNFSlotTag) :
    slotTagFromWireName (slotTagToWireName x) = some x := by
  cases x <;> decide

def parseSlotTagStep (toks : List String) : Except DecodeRejectDiag (BNFSlotTag × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "BNFSlotTag")
  | t :: rs =>
    match slotTagFromWireName t with
    | some x => .ok (x, rs)
    | none   => .error (.unknownConstructorTag "BNFSlotTag" t)

theorem parseSlotTagStep_enc (x : BNFSlotTag) (rest : List String) :
    parseSlotTagStep (slotTagToWireName x :: rest) = .ok (x, rest) := by
  simp [parseSlotTagStep, slotTagFromWireName_toWireName]

def locusToWireName : ClauseLocus → String
  | .clause1 => "ClauseLocus.clause1"
  | .clause2 => "ClauseLocus.clause2"

theorem locusToWireName_valid (l : ClauseLocus) : ValidToken (locusToWireName l) := by
  apply checkValidTokenBool_sound; cases l <;> decide

def parseLocusStep (toks : List String) : Except DecodeRejectDiag (ClauseLocus × List String) :=
  match toks with
  | "ClauseLocus.clause1" :: rs => .ok (.clause1, rs)
  | "ClauseLocus.clause2" :: rs => .ok (.clause2, rs)
  | t :: _ => .error (.unknownConstructorTag "ClauseLocus" t)
  | []     => .error (.unexpectedEndOfTokens "ClauseLocus")

theorem parseLocusStep_enc (l : ClauseLocus) (rest : List String) :
    parseLocusStep (locusToWireName l :: rest) = .ok (l, rest) := by
  cases l <;> rfl

def allRuleIds : List CanonicalRuleId :=
  [ .G01, .G02, .G03, .G04, .G05, .G06, .G07, .G08,
    .G09, .G10, .G11, .G12, .G13, .G14, .G15, .G16,
    .T1, .T2, .T3, .T4, .T5 ]

def ruleIdToWireName : CanonicalRuleId → String
  | .G01 => "CanonicalRuleId.G01" | .G02 => "CanonicalRuleId.G02"
  | .G03 => "CanonicalRuleId.G03" | .G04 => "CanonicalRuleId.G04"
  | .G05 => "CanonicalRuleId.G05" | .G06 => "CanonicalRuleId.G06"
  | .G07 => "CanonicalRuleId.G07" | .G08 => "CanonicalRuleId.G08"
  | .G09 => "CanonicalRuleId.G09" | .G10 => "CanonicalRuleId.G10"
  | .G11 => "CanonicalRuleId.G11" | .G12 => "CanonicalRuleId.G12"
  | .G13 => "CanonicalRuleId.G13" | .G14 => "CanonicalRuleId.G14"
  | .G15 => "CanonicalRuleId.G15" | .G16 => "CanonicalRuleId.G16"
  | .T1  => "CanonicalRuleId.T1"  | .T2  => "CanonicalRuleId.T2"
  | .T3  => "CanonicalRuleId.T3"  | .T4  => "CanonicalRuleId.T4"
  | .T5  => "CanonicalRuleId.T5"

def ruleIdFromWireName (s : String) : Option CanonicalRuleId :=
  allRuleIds.find? (fun r => eqStrBool (ruleIdToWireName r) s)

theorem ruleIdToWireName_valid (r : CanonicalRuleId) : ValidToken (ruleIdToWireName r) := by
  apply checkValidTokenBool_sound; cases r <;> decide

theorem ruleIdFromWireName_toWireName (r : CanonicalRuleId) :
    ruleIdFromWireName (ruleIdToWireName r) = some r := by
  cases r <;> decide

def parseRuleIdStep (toks : List String) : Except DecodeRejectDiag (CanonicalRuleId × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "CanonicalRuleId")
  | t :: rs =>
    match ruleIdFromWireName t with
    | some r => .ok (r, rs)
    | none   => .error (.unknownConstructorTag "CanonicalRuleId" t)

theorem parseRuleIdStep_enc (r : CanonicalRuleId) (rest : List String) :
    parseRuleIdStep (ruleIdToWireName r :: rest) = .ok (r, rest) := by
  simp [parseRuleIdStep, ruleIdFromWireName_toWireName]

/-! ### 8. `CodepointSpan` & `ConcreteParseTree` / `List ConcreteParseTree` Codecs -/

def encSpanSeq (sp : CodepointSpan) : List String :=
  ["CodepointSpan.mk", encNatTok sp.startCp, encNatTok sp.endCp]

theorem encSpanSeq_valid (sp : CodepointSpan) :
    encSpanSeq sp ≠ [] ∧ ∀ t ∈ encSpanSeq sp, ValidToken t := by
  refine ⟨by simp [encSpanSeq], ?_⟩
  intro t ht
  simp only [encSpanSeq] at ht
  rcases List.mem_cons.mp ht with rfl | h1
  · exact checkValidTokenBool_sound (by decide)
  · rcases List.mem_cons.mp h1 with rfl | h2
    · exact encNatTok_valid _
    · rcases List.mem_cons.mp h2 with rfl | h3
      · exact encNatTok_valid _
      · nomatch h3

def parseSpanStep (toks : List String) : Except DecodeRejectDiag (CodepointSpan × List String) := do
  let r1 ← parseTagExpect "CodepointSpan" "CodepointSpan.mk" toks
  let (s, r2) ← parseNatStep r1
  let (e, r3) ← parseNatStep r2
  .ok (⟨s, e⟩, r3)

theorem parseSpanStep_enc (sp : CodepointSpan) (rest : List String) :
    parseSpanStep (encSpanSeq sp ++ rest) = .ok (sp, rest) := by
  cases sp with
  | mk s e =>
    simp [encSpanSeq, parseSpanStep, Bind.bind, Except.bind, parseTagExpect_self, parseNatStep_enc]

def spanWireCodec : CanonicalWireCodec CodepointSpan where
  typeTag      := "CodepointSpan"
  encToks      := encSpanSeq
  parseToks    := fun _ toks => parseSpanStep toks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := encSpanSeq_valid
  hParsePrefix := fun x rest _ _ => parseSpanStep_enc x rest

mutual
  def encParseArgSeq : ConcreteParseArg → List String
    | .litTok txt sp =>
      "ConcreteParseArg.litTok" :: (encStrSeq txt ++ encSpanSeq sp)
    | .slotTok s tg eid lex sp =>
      "ConcreteParseArg.slotTok" :: slotSortToWireName s :: slotTagToWireName tg ::
        (encStrSeq eid ++ encStrSeq lex ++ encSpanSeq sp)
    | .childSub sub =>
      "ConcreteParseArg.childSub" :: encParseTreeSeq sub

  def encParseArgListSeq : List ConcreteParseArg → List String
    | []      => ["ArgList.nil"]
    | a :: as => "ArgList.cons" :: (encParseArgSeq a ++ encParseArgListSeq as)

  def encParseTreeSeq : ConcreteParseTree → List String
    | .mkTree prod alt loc sp args =>
      "ConcreteParseTree.mkTree" :: prodToWireName prod :: encNatTok alt ::
        locusToWireName loc :: (encSpanSeq sp ++ encParseArgListSeq args)
end

private theorem valid_list_append {xs ys : List String}
    (hx : ∀ t ∈ xs, ValidToken t) (hy : ∀ t ∈ ys, ValidToken t) :
    ∀ t ∈ xs ++ ys, ValidToken t := by
  intro t ht
  rcases List.mem_append.mp ht with h1 | h2
  · exact hx t h1
  · exact hy t h2

mutual
  theorem encParseArgSeq_valid (a : ConcreteParseArg) :
      1 ≤ (encParseArgSeq a).length ∧ ∀ t ∈ encParseArgSeq a, ValidToken t := by
    cases a with
    | litTok txt sp =>
      refine ⟨by simp [encParseArgSeq], ?_⟩
      intro t ht; simp only [encParseArgSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append (encStrSeq_valid txt).2 (encSpanSeq_valid sp).2 t hm
    | slotTok s tg eid lex sp =>
      refine ⟨by simp [encParseArgSeq], ?_⟩
      intro t ht; simp only [encParseArgSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp hm1 with rfl | hm2
        · exact slotSortToWireName_valid s
        · rcases List.mem_cons.mp hm2 with rfl | hm3
          · exact slotTagToWireName_valid tg
          · exact valid_list_append
              (valid_list_append (encStrSeq_valid eid).2 (encStrSeq_valid lex).2)
              (encSpanSeq_valid sp).2 t hm3
    | childSub sub =>
      have ⟨_, hv⟩ := encParseTreeSeq_valid sub
      refine ⟨by simp [encParseArgSeq], ?_⟩
      intro t ht; simp only [encParseArgSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact hv t hm

  theorem encParseArgListSeq_valid (args : List ConcreteParseArg) :
      1 ≤ (encParseArgListSeq args).length ∧ ∀ t ∈ encParseArgListSeq args, ValidToken t := by
    cases args with
    | nil =>
      refine ⟨by simp [encParseArgListSeq], ?_⟩
      intro t ht; simp only [encParseArgListSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hnil
      · exact checkValidTokenBool_sound (by decide)
      · nomatch hnil
    | cons a as =>
      have ⟨_, hva⟩ := encParseArgSeq_valid a
      have ⟨_, hvas⟩ := encParseArgListSeq_valid as
      refine ⟨by simp [encParseArgListSeq], ?_⟩
      intro t ht; simp only [encParseArgListSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append hva hvas t hm

  theorem encParseTreeSeq_valid (tr : ConcreteParseTree) :
      1 ≤ (encParseTreeSeq tr).length ∧ ∀ t ∈ encParseTreeSeq tr, ValidToken t := by
    cases tr with
    | mkTree prod alt loc sp args =>
      have ⟨_, hvas⟩ := encParseArgListSeq_valid args
      refine ⟨by simp [encParseTreeSeq], ?_⟩
      intro t ht; simp only [encParseTreeSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp hm1 with rfl | hm2
        · exact prodToWireName_valid prod
        · rcases List.mem_cons.mp hm2 with rfl | hm3
          · exact encNatTok_valid alt
          · rcases List.mem_cons.mp hm3 with rfl | hm4
            · exact locusToWireName_valid loc
            · exact valid_list_append (encSpanSeq_valid sp).2 hvas t hm4
end

def parseParseTreeToks : Nat → List String → Except DecodeRejectDiag (ConcreteParseTree × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, toks => do
    let r1 ← parseTagExpect "ConcreteParseTree" "ConcreteParseTree.mkTree" toks
    let (prod, r2) ← parseProdStep r1
    let (alt, r3) ← parseNatStep r2
    let (loc, r4) ← parseLocusStep r3
    let (sp, r5) ← parseSpanStep r4
    let (args, r6) ← parseParseArgListToks f r5
    .ok (.mkTree prod alt loc sp args, r6)
where
  parseParseArgToks : Nat → List String → Except DecodeRejectDiag (ConcreteParseArg × List String)
    | 0, _ => .error .recursionFuelExhausted
    | _ + 1, "ConcreteParseArg.litTok" :: rs => do
      let (txt, r1) ← parseStrStep rs
      let (sp, r2) ← parseSpanStep r1
      .ok (.litTok txt sp, r2)
    | _ + 1, "ConcreteParseArg.slotTok" :: rs => do
      let (s, r1) ← parseSlotSortStep rs
      let (tg, r2) ← parseSlotTagStep r1
      let (eid, r3) ← parseStrStep r2
      let (lex, r4) ← parseStrStep r3
      let (sp, r5) ← parseSpanStep r4
      .ok (.slotTok s tg eid lex sp, r5)
    | f + 1, "ConcreteParseArg.childSub" :: rs => do
      let (sub, r1) ← parseParseTreeToks f rs
      .ok (.childSub sub, r1)
    | _ + 1, t :: _ => .error (.unknownConstructorTag "ConcreteParseArg" t)
    | _ + 1, []     => .error (.unexpectedEndOfTokens "ConcreteParseArg")

  parseParseArgListToks : Nat → List String → Except DecodeRejectDiag (List ConcreteParseArg × List String)
    | 0, _ => .error .recursionFuelExhausted
    | _ + 1, "ArgList.nil" :: rs => .ok ([], rs)
    | f + 1, "ArgList.cons" :: rs => do
      let (a, r1) ← parseParseArgToks f rs
      let (as, r2) ← parseParseArgListToks f r1
      .ok (a :: as, r2)
    | _ + 1, t :: _ => .error (.unknownConstructorTag "ArgList" t)
    | _ + 1, []     => .error (.unexpectedEndOfTokens "ArgList")

mutual
  theorem parseParseArgToks_enc (a : ConcreteParseArg) (rest : List String) (fuel : Nat)
      (hf : (encParseArgSeq a).length ≤ fuel) :
      parseParseTreeToks.parseParseArgToks fuel (encParseArgSeq a ++ rest) = .ok (a, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encParseArgSeq_valid a
      omega
    | succ f =>
      cases a with
      | litTok txt sp =>
        simp [encParseArgSeq, List.append_assoc, parseParseTreeToks.parseParseArgToks,
              Bind.bind, Except.bind, parseStrStep_enc, parseSpanStep_enc]
      | slotTok s tg eid lex sp =>
        simp [encParseArgSeq, List.append_assoc, parseParseTreeToks.parseParseArgToks,
              Bind.bind, Except.bind, parseSlotSortStep_enc, parseSlotTagStep_enc,
              parseStrStep_enc, parseSpanStep_enc]
      | childSub sub =>
        have hsub_f : (encParseTreeSeq sub).length ≤ f := by
          simp [encParseArgSeq] at hf; omega
        simp [encParseArgSeq, parseParseTreeToks.parseParseArgToks,
              Bind.bind, Except.bind, parseParseTreeToks_enc sub rest f hsub_f]

  theorem parseParseArgListToks_enc (args : List ConcreteParseArg) (rest : List String) (fuel : Nat)
      (hf : (encParseArgListSeq args).length ≤ fuel) :
      parseParseTreeToks.parseParseArgListToks fuel (encParseArgListSeq args ++ rest) = .ok (args, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encParseArgListSeq_valid args
      omega
    | succ f =>
      cases args with
      | nil => rfl
      | cons a as =>
        have ha_f : (encParseArgSeq a).length ≤ f := by
          simp [encParseArgListSeq] at hf; omega
        have has_f : (encParseArgListSeq as).length ≤ f := by
          simp [encParseArgListSeq] at hf; omega
        simp only [encParseArgListSeq, List.cons_append, List.append_assoc,
                   parseParseTreeToks.parseParseArgListToks, Bind.bind, Except.bind]
        rw [parseParseArgToks_enc a (encParseArgListSeq as ++ rest) f ha_f]
        dsimp only
        rw [parseParseArgListToks_enc as rest f has_f]

  theorem parseParseTreeToks_enc (tr : ConcreteParseTree) (rest : List String) (fuel : Nat)
      (hf : (encParseTreeSeq tr).length ≤ fuel) :
      parseParseTreeToks fuel (encParseTreeSeq tr ++ rest) = .ok (tr, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encParseTreeSeq_valid tr
      omega
    | succ f =>
      cases tr with
      | mkTree prod alt loc sp args =>
        have hargs_f : (encParseArgListSeq args).length ≤ f := by
          simp [encParseTreeSeq] at hf; omega
        simp only [encParseTreeSeq, List.cons_append, List.append_assoc,
                   parseParseTreeToks, Bind.bind, Except.bind,
                   parseTagExpect_self, parseProdStep_enc, parseNatStep_enc,
                   parseLocusStep_enc, parseSpanStep_enc]
        rw [parseParseArgListToks_enc args rest f hargs_f]
end

def parseTreeWireCodec : CanonicalWireCodec ConcreteParseTree where
  typeTag      := "ConcreteParseTree"
  encToks      := encParseTreeSeq
  parseToks    := parseParseTreeToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun t =>
    let ⟨h1, hv⟩ := encParseTreeSeq_valid t
    ⟨by intro he; rw [he] at h1; simp at h1, hv⟩
  hParsePrefix := parseParseTreeToks_enc

def encForestSeq : List ConcreteParseTree → List String
  | []      => ["Forest.nil"]
  | t :: ts => "Forest.cons" :: (encParseTreeSeq t ++ encForestSeq ts)

theorem encForestSeq_valid (T : List ConcreteParseTree) :
    1 ≤ (encForestSeq T).length ∧ ∀ tok ∈ encForestSeq T, ValidToken tok := by
  induction T with
  | nil =>
    refine ⟨by simp [encForestSeq], ?_⟩
    intro tok h; simp [encForestSeq] at h; subst h; exact checkValidTokenBool_sound (by decide)
  | cons t ts ih =>
    refine ⟨by simp [encForestSeq], ?_⟩
    intro tok h; simp only [encForestSeq] at h
    rcases List.mem_cons.mp h with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encParseTreeSeq_valid t).2 ih.2 tok hm

def parseForestToks : Nat → List String → Except DecodeRejectDiag (List ConcreteParseTree × List String)
  | 0, _ => .error .recursionFuelExhausted
  | _ + 1, "Forest.nil" :: rs => .ok ([], rs)
  | f + 1, "Forest.cons" :: rs => do
    let (t, r1) ← parseParseTreeToks f rs
    let (ts, r2) ← parseForestToks f r1
    .ok (t :: ts, r2)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "Forest" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "Forest")

theorem parseForestToks_enc (T : List ConcreteParseTree) (rest : List String) (fuel : Nat)
    (hf : (encForestSeq T).length ≤ fuel) :
    parseForestToks fuel (encForestSeq T ++ rest) = .ok (T, rest) := by
  induction T generalizing fuel rest with
  | nil =>
    cases fuel with
    | zero => simp [encForestSeq] at hf
    | succ _ => rfl
  | cons t ts ih =>
    cases fuel with
    | zero => simp [encForestSeq] at hf
    | succ f =>
      have ht_f : (encParseTreeSeq t).length ≤ f := by simp [encForestSeq] at hf; omega
      have hts_f : (encForestSeq ts).length ≤ f := by simp [encForestSeq] at hf; omega
      simp only [encForestSeq, List.cons_append, List.append_assoc, parseForestToks,
                 Bind.bind, Except.bind]
      rw [parseParseTreeToks_enc t (encForestSeq ts ++ rest) f ht_f]
      dsimp only
      rw [ih rest f hts_f]

def parseForestWireCodec : CanonicalWireCodec (List ConcreteParseTree) where
  typeTag      := "ParseForest"
  encToks      := encForestSeq
  parseToks    := parseForestToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun T =>
    let ⟨h1, hv⟩ := encForestSeq_valid T
    ⟨by intro he; rw [he] at h1; simp at h1, hv⟩
  hParsePrefix := parseForestToks_enc

/-! ### 9. `RawSemanticTerm` & `CanonicalMeaning` Codecs (`PO-DIFF-04`, `PO-DIFF-05`) -/

def encScopeSeq : SemanticScope → List String
  | .cohortBound cid => "SemanticScope.cohortBound" :: encStrSeq cid
  | .unrestrictedPop => ["SemanticScope.unrestrictedPop"]

theorem encScopeSeq_valid (sc : SemanticScope) :
    1 ≤ (encScopeSeq sc).length ∧ ∀ t ∈ encScopeSeq sc, ValidToken t := by
  cases sc with
  | cohortBound cid =>
    refine ⟨by simp [encScopeSeq], ?_⟩
    intro t ht; simp only [encScopeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encStrSeq_valid cid).2 t hm
  | unrestrictedPop =>
    refine ⟨by simp [encScopeSeq], ?_⟩
    intro t ht; simp [encScopeSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)

def parseScopeStep (toks : List String) : Except DecodeRejectDiag (SemanticScope × List String) :=
  match toks with
  | "SemanticScope.cohortBound" :: rs => do
    let (cid, rem) ← parseStrStep rs
    .ok (.cohortBound cid, rem)
  | "SemanticScope.unrestrictedPop" :: rs => .ok (.unrestrictedPop, rs)
  | t :: _ => .error (.unknownConstructorTag "SemanticScope" t)
  | []     => .error (.unexpectedEndOfTokens "SemanticScope")

theorem parseScopeStep_enc (sc : SemanticScope) (rest : List String) :
    parseScopeStep (encScopeSeq sc ++ rest) = .ok (sc, rest) := by
  cases sc with
  | cohortBound cid => simp [encScopeSeq, parseScopeStep, Bind.bind, Except.bind, parseStrStep_enc]
  | unrestrictedPop => rfl

def encDistKind : DistStatKind → String
  | .meanSD    => "DistStatKind.meanSD"
  | .medianIQR => "DistStatKind.medianIQR"

theorem encDistKind_valid (k : DistStatKind) : ValidToken (encDistKind k) := by
  apply checkValidTokenBool_sound; cases k <;> decide

def parseDistKindStep (toks : List String) : Except DecodeRejectDiag (DistStatKind × List String) :=
  match toks with
  | "DistStatKind.meanSD" :: rs    => .ok (.meanSD, rs)
  | "DistStatKind.medianIQR" :: rs => .ok (.medianIQR, rs)
  | t :: _ => .error (.unknownConstructorTag "DistStatKind" t)
  | []     => .error (.unexpectedEndOfTokens "DistStatKind")

theorem parseDistKindStep_enc (k : DistStatKind) (rest : List String) :
    parseDistKindStep (encDistKind k :: rest) = .ok (k, rest) := by
  cases k <;> rfl

def encIntervModSeq : IntervModality → List String
  | .directional vb      => "IntervModality.directional" :: encStrSeq vb
  | .neutralNullIncluded => ["IntervModality.neutralNullIncluded"]

theorem encIntervModSeq_valid (m : IntervModality) :
    1 ≤ (encIntervModSeq m).length ∧ ∀ t ∈ encIntervModSeq m, ValidToken t := by
  cases m with
  | directional vb =>
    refine ⟨by simp [encIntervModSeq], ?_⟩
    intro t ht; simp only [encIntervModSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encStrSeq_valid vb).2 t hm
  | neutralNullIncluded =>
    refine ⟨by simp [encIntervModSeq], ?_⟩
    intro t ht; simp [encIntervModSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)

def parseIntervModStep (toks : List String) : Except DecodeRejectDiag (IntervModality × List String) :=
  match toks with
  | "IntervModality.directional" :: rs => do
    let (vb, rem) ← parseStrStep rs
    .ok (.directional vb, rem)
  | "IntervModality.neutralNullIncluded" :: rs => .ok (.neutralNullIncluded, rs)
  | t :: _ => .error (.unknownConstructorTag "IntervModality" t)
  | []     => .error (.unexpectedEndOfTokens "IntervModality")

theorem parseIntervModStep_enc (m : IntervModality) (rest : List String) :
    parseIntervModStep (encIntervModSeq m ++ rest) = .ok (m, rest) := by
  cases m with
  | directional vb => simp [encIntervModSeq, parseIntervModStep, Bind.bind, Except.bind, parseStrStep_enc]
  | neutralNullIncluded => rfl

def encQuantFormSeq : QuantPredForm → List String
  | .universalNeg sg ev        => "QuantPredForm.universalNeg" :: (encStrSeq sg ++ encStrSeq ev)
  | .negExistential sg ev      => "QuantPredForm.negExistential" :: (encStrSeq sg ++ encStrSeq ev)
  | .negUniversal sg ev        => "QuantPredForm.negUniversal" :: (encStrSeq sg ++ encStrSeq ev)
  | .properPart sg ev          => "QuantPredForm.properPart" :: (encStrSeq sg ++ encStrSeq ev)
  | .existentialPos sg ev      => "QuantPredForm.existentialPos" :: (encStrSeq sg ++ encStrSeq ev)
  | .genericUniversalPos sg ev => "QuantPredForm.genericUniversalPos" :: (encStrSeq sg ++ encStrSeq ev)

theorem encQuantFormSeq_valid (q : QuantPredForm) :
    1 ≤ (encQuantFormSeq q).length ∧ ∀ t ∈ encQuantFormSeq q, ValidToken t := by
  cases q <;> (
    refine ⟨by simp [encQuantFormSeq], ?_⟩
    intro t ht; simp only [encQuantFormSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encStrSeq_valid _).2 (encStrSeq_valid _).2 t hm)

def parseQuantFormStep (toks : List String) : Except DecodeRejectDiag (QuantPredForm × List String) :=
  match toks with
  | "QuantPredForm.universalNeg" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.universalNeg sg ev, r2)
  | "QuantPredForm.negExistential" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.negExistential sg ev, r2)
  | "QuantPredForm.negUniversal" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.negUniversal sg ev, r2)
  | "QuantPredForm.properPart" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.properPart sg ev, r2)
  | "QuantPredForm.existentialPos" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.existentialPos sg ev, r2)
  | "QuantPredForm.genericUniversalPos" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.genericUniversalPos sg ev, r2)
  | t :: _ => .error (.unknownConstructorTag "QuantPredForm" t)
  | []     => .error (.unexpectedEndOfTokens "QuantPredForm")

theorem parseQuantFormStep_enc (q : QuantPredForm) (rest : List String) :
    parseQuantFormStep (encQuantFormSeq q ++ rest) = .ok (q, rest) := by
  cases q <;> simp [encQuantFormSeq, List.append_assoc, parseQuantFormStep,
                    Bind.bind, Except.bind, parseStrStep_enc]

def encPresupSeq : PresupItem → List String
  | .factiveCausal act vb out =>
    "PresupItem.factiveCausal" :: (encStrSeq act ++ encStrSeq vb ++ encStrSeq out)

def encPresupListSeq : List PresupItem → List String
  | []      => ["PresupList.nil"]
  | p :: ps => "PresupList.cons" :: (encPresupSeq p ++ encPresupListSeq ps)

theorem encPresupListSeq_valid (ps : List PresupItem) :
    1 ≤ (encPresupListSeq ps).length ∧ ∀ t ∈ encPresupListSeq ps, ValidToken t := by
  induction ps with
  | nil =>
    refine ⟨by simp [encPresupListSeq], ?_⟩
    intro t ht; simp [encPresupListSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | cons p rest ih =>
    cases p with
    | factiveCausal act vb out =>
      refine ⟨by simp [encPresupListSeq], ?_⟩
      intro t ht; simp only [encPresupListSeq, encPresupSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp hm1 with rfl | hm2
        · exact checkValidTokenBool_sound (by decide)
        · exact valid_list_append
            (valid_list_append (valid_list_append (encStrSeq_valid act).2 (encStrSeq_valid vb).2)
                               (encStrSeq_valid out).2)
            ih.2 t hm2

def parsePresupListToks : Nat → List String → Except DecodeRejectDiag (List PresupItem × List String)
  | 0, _ => .error .recursionFuelExhausted
  | _ + 1, "PresupList.nil" :: rs => .ok ([], rs)
  | f + 1, "PresupList.cons" :: "PresupItem.factiveCausal" :: rs => do
    let (act, r1) ← parseStrStep rs
    let (vb, r2) ← parseStrStep r1
    let (out, r3) ← parseStrStep r2
    let (ps, r4) ← parsePresupListToks f r3
    .ok (.factiveCausal act vb out :: ps, r4)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "PresupList" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "PresupList")

theorem parsePresupListToks_enc (ps : List PresupItem) (rest : List String) (fuel : Nat)
    (hf : (encPresupListSeq ps).length ≤ fuel) :
    parsePresupListToks fuel (encPresupListSeq ps ++ rest) = .ok (ps, rest) := by
  induction ps generalizing fuel rest with
  | nil =>
    cases fuel with
    | zero => simp [encPresupListSeq] at hf
    | succ _ => rfl
  | cons p tail ih =>
    cases fuel with
    | zero => simp [encPresupListSeq] at hf
    | succ f =>
      cases p with
      | factiveCausal act vb out =>
        have htf : (encPresupListSeq tail).length ≤ f := by simp [encPresupListSeq] at hf; omega
        simp only [encPresupListSeq, encPresupSeq, List.cons_append, List.append_assoc,
                   parsePresupListToks, Bind.bind, Except.bind, parseStrStep_enc]
        rw [ih rest f htf]

def encAtomicClaimSeq : AtomicClaim → List String
  | .descIncidence w e k n p =>
    "AtomicClaim.descIncidence" :: (encStrSeq w ++ encStrSeq e ++ encStrSeq k ++ encStrSeq n ++ encStrSeq p)
  | .descDist k m est d1 d2o =>
    "AtomicClaim.descDist" :: encDistKind k :: (encStrSeq m ++ encStrSeq est ++ encStrSeq d1 ++ encOptStrSeq d2o)
  | .assocClaim met dir act ref out covO tmpO est ciL ciLo ciHi =>
    "AtomicClaim.assocClaim" ::
      (encStrSeq met ++ encStrSeq dir ++ encStrSeq act ++ encStrSeq ref ++ encStrSeq out ++
       encOptStrSeq covO ++ encOptPairStrSeq tmpO ++
       encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi)
  | .compRD act ref out est ciL ciLo ciHi =>
    "AtomicClaim.compRD" ::
      (encStrSeq act ++ encStrSeq ref ++ encStrSeq out ++ encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi)
  | .intervClaim mod assump met act ref out est ciL ciLo ciHi pvO =>
    "AtomicClaim.intervClaim" ::
      (encIntervModSeq mod ++ encStrSeq assump ++ encStrSeq met ++ encStrSeq act ++ encStrSeq ref ++
       encStrSeq out ++ encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi ++ encOptStrSeq pvO)
  | .metaNotStatSig met act ref out est ciL ciLo ciHi al =>
    "AtomicClaim.metaNotStatSig" ::
      (encStrSeq met ++ encStrSeq act ++ encStrSeq ref ++ encStrSeq out ++
       encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi ++ encStrSeq al)
  | .metaEquiv met act ref out mLo mHi est ciL ciLo ciHi =>
    "AtomicClaim.metaEquiv" ::
      (encStrSeq met ++ encStrSeq act ++ encStrSeq ref ++ encStrSeq out ++ encStrSeq mLo ++ encStrSeq mHi ++
       encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi)
  | .metaNonEstab src act vb out =>
    "AtomicClaim.metaNonEstab" :: (encStrSeq src ++ encStrSeq act ++ encStrSeq vb ++ encStrSeq out)
  | .metaUnresolvedPolar src act vb out =>
    "AtomicClaim.metaUnresolvedPolar" :: (encStrSeq src ++ encStrSeq act ++ encStrSeq vb ++ encStrSeq out)
  | .metaWhUnresolved src ep wh act vb out =>
    "AtomicClaim.metaWhUnresolved" ::
      (encStrSeq src ++ encStrSeq ep ++ encStrSeq wh ++ encStrSeq act ++ encStrSeq vb ++ encStrSeq out)
  | .quantClaim qf =>
    "AtomicClaim.quantClaim" :: encQuantFormSeq qf

private theorem optStr_valid (o : Option String) : ∀ t ∈ encOptStrSeq o, ValidToken t := by
  cases o with
  | none => intro t ht; simp [encOptStrSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | some s =>
    intro t ht; simp only [encOptStrSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encStrSeq_valid s).2 t hm

private theorem optPairStr_valid (o : Option (String × String)) :
    ∀ t ∈ encOptPairStrSeq o, ValidToken t := by
  cases o with
  | none => intro t ht; simp [encOptPairStrSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | some p =>
    rcases p with ⟨s1, s2⟩
    intro t ht; simp only [encOptPairStrSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encStrSeq_valid s1).2 (encStrSeq_valid s2).2 t hm

theorem encAtomicClaimSeq_valid (cl : AtomicClaim) :
    1 ≤ (encAtomicClaimSeq cl).length ∧ ∀ t ∈ encAtomicClaimSeq cl, ValidToken t := by
  cases cl with
  | descIncidence w e k n p =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid w).2 (encStrSeq_valid e).2) (encStrSeq_valid k).2) (encStrSeq_valid n).2)
        (encStrSeq_valid p).2 t hm
  | descDist k m est d1 d2o =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp hm1 with rfl | hm2
      · exact encDistKind_valid k
      · exact valid_list_append (valid_list_append (valid_list_append
          (encStrSeq_valid m).2 (encStrSeq_valid est).2) (encStrSeq_valid d1).2) (optStr_valid d2o) t hm2
  | assocClaim met dir act ref out covO tmpO est ciL ciLo ciHi =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid met).2 (encStrSeq_valid dir).2) (encStrSeq_valid act).2) (encStrSeq_valid ref).2)
        (encStrSeq_valid out).2) (optStr_valid covO)) (optPairStr_valid tmpO)) (encStrSeq_valid est).2)
        (encStrSeq_valid ciL).2) (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2 t hm
  | compRD act ref out est ciL ciLo ciHi =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (encStrSeq_valid act).2 (encStrSeq_valid ref).2) (encStrSeq_valid out).2)
        (encStrSeq_valid est).2) (encStrSeq_valid ciL).2) (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2 t hm
  | intervClaim mod assump met act ref out est ciL ciLo ciHi pvO =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encIntervModSeq_valid mod).2 (encStrSeq_valid assump).2) (encStrSeq_valid met).2) (encStrSeq_valid act).2)
        (encStrSeq_valid ref).2) (encStrSeq_valid out).2) (encStrSeq_valid est).2) (encStrSeq_valid ciL).2)
        (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2) (optStr_valid pvO) t hm
  | metaNotStatSig met act ref out est ciL ciLo ciHi al =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (valid_list_append (valid_list_append (encStrSeq_valid met).2 (encStrSeq_valid act).2)
        (encStrSeq_valid ref).2) (encStrSeq_valid out).2) (encStrSeq_valid est).2) (encStrSeq_valid ciL).2)
        (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2) (encStrSeq_valid al).2 t hm
  | metaEquiv met act ref out mLo mHi est ciL ciLo ciHi =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid met).2 (encStrSeq_valid act).2) (encStrSeq_valid ref).2) (encStrSeq_valid out).2)
        (encStrSeq_valid mLo).2) (encStrSeq_valid mHi).2) (encStrSeq_valid est).2) (encStrSeq_valid ciL).2)
        (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2 t hm
  | metaNonEstab src act vb out =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid src).2 (encStrSeq_valid act).2) (encStrSeq_valid vb).2) (encStrSeq_valid out).2 t hm
  | metaUnresolvedPolar src act vb out =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid src).2 (encStrSeq_valid act).2) (encStrSeq_valid vb).2) (encStrSeq_valid out).2 t hm
  | metaWhUnresolved src ep wh act vb out =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid src).2 (encStrSeq_valid ep).2) (encStrSeq_valid wh).2) (encStrSeq_valid act).2)
        (encStrSeq_valid vb).2) (encStrSeq_valid out).2 t hm
  | quantClaim qf =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encQuantFormSeq_valid qf).2 t hm

def parseAtomicClaimStep (toks : List String) : Except DecodeRejectDiag (AtomicClaim × List String) :=
  match toks with
  | "AtomicClaim.descIncidence" :: rs => do
    let (w, r1) ← parseStrStep rs; let (e, r2) ← parseStrStep r1
    let (k, r3) ← parseStrStep r2; let (n, r4) ← parseStrStep r3; let (p, r5) ← parseStrStep r4
    .ok (.descIncidence w e k n p, r5)
  | "AtomicClaim.descDist" :: rs => do
    let (k, r1) ← parseDistKindStep rs; let (m, r2) ← parseStrStep r1
    let (est, r3) ← parseStrStep r2; let (d1, r4) ← parseStrStep r3; let (d2o, r5) ← parseOptStrStep r4
    .ok (.descDist k m est d1 d2o, r5)
  | "AtomicClaim.assocClaim" :: rs => do
    let (met, r1) ← parseStrStep rs; let (dir, r2) ← parseStrStep r1
    let (act, r3) ← parseStrStep r2; let (ref, r4) ← parseStrStep r3; let (out, r5) ← parseStrStep r4
    let (covO, r6) ← parseOptStrStep r5; let (tmpO, r7) ← parseOptPairStrStep r6
    let (est, r8) ← parseStrStep r7; let (ciL, r9) ← parseStrStep r8
    let (ciLo, r10) ← parseStrStep r9; let (ciHi, r11) ← parseStrStep r10
    .ok (.assocClaim met dir act ref out covO tmpO est ciL ciLo ciHi, r11)
  | "AtomicClaim.compRD" :: rs => do
    let (act, r1) ← parseStrStep rs; let (ref, r2) ← parseStrStep r1; let (out, r3) ← parseStrStep r2
    let (est, r4) ← parseStrStep r3; let (ciL, r5) ← parseStrStep r4
    let (ciLo, r6) ← parseStrStep r5; let (ciHi, r7) ← parseStrStep r6
    .ok (.compRD act ref out est ciL ciLo ciHi, r7)
  | "AtomicClaim.intervClaim" :: rs => do
    let (mod, r1) ← parseIntervModStep rs; let (assump, r2) ← parseStrStep r1
    let (met, r3) ← parseStrStep r2; let (act, r4) ← parseStrStep r3; let (ref, r5) ← parseStrStep r4
    let (out, r6) ← parseStrStep r5; let (est, r7) ← parseStrStep r6; let (ciL, r8) ← parseStrStep r7
    let (ciLo, r9) ← parseStrStep r8; let (ciHi, r10) ← parseStrStep r9; let (pvO, r11) ← parseOptStrStep r10
    .ok (.intervClaim mod assump met act ref out est ciL ciLo ciHi pvO, r11)
  | "AtomicClaim.metaNotStatSig" :: rs => do
    let (met, r1) ← parseStrStep rs; let (act, r2) ← parseStrStep r1; let (ref, r3) ← parseStrStep r2
    let (out, r4) ← parseStrStep r3; let (est, r5) ← parseStrStep r4; let (ciL, r6) ← parseStrStep r5
    let (ciLo, r7) ← parseStrStep r6; let (ciHi, r8) ← parseStrStep r7; let (al, r9) ← parseStrStep r8
    .ok (.metaNotStatSig met act ref out est ciL ciLo ciHi al, r9)
  | "AtomicClaim.metaEquiv" :: rs => do
    let (met, r1) ← parseStrStep rs; let (act, r2) ← parseStrStep r1; let (ref, r3) ← parseStrStep r2
    let (out, r4) ← parseStrStep r3; let (mLo, r5) ← parseStrStep r4; let (mHi, r6) ← parseStrStep r5
    let (est, r7) ← parseStrStep r6; let (ciL, r8) ← parseStrStep r7
    let (ciLo, r9) ← parseStrStep r8; let (ciHi, r10) ← parseStrStep r9
    .ok (.metaEquiv met act ref out mLo mHi est ciL ciLo ciHi, r10)
  | "AtomicClaim.metaNonEstab" :: rs => do
    let (src, r1) ← parseStrStep rs; let (act, r2) ← parseStrStep r1
    let (vb, r3) ← parseStrStep r2; let (out, r4) ← parseStrStep r3
    .ok (.metaNonEstab src act vb out, r4)
  | "AtomicClaim.metaUnresolvedPolar" :: rs => do
    let (src, r1) ← parseStrStep rs; let (act, r2) ← parseStrStep r1
    let (vb, r3) ← parseStrStep r2; let (out, r4) ← parseStrStep r3
    .ok (.metaUnresolvedPolar src act vb out, r4)
  | "AtomicClaim.metaWhUnresolved" :: rs => do
    let (src, r1) ← parseStrStep rs; let (ep, r2) ← parseStrStep r1; let (wh, r3) ← parseStrStep r2
    let (act, r4) ← parseStrStep r3; let (vb, r5) ← parseStrStep r4; let (out, r6) ← parseStrStep r5
    .ok (.metaWhUnresolved src ep wh act vb out, r6)
  | "AtomicClaim.quantClaim" :: rs => do
    let (qf, r1) ← parseQuantFormStep rs
    .ok (.quantClaim qf, r1)
  | t :: _ => .error (.unknownConstructorTag "AtomicClaim" t)
  | []     => .error (.unexpectedEndOfTokens "AtomicClaim")

theorem parseAtomicClaimStep_enc (cl : AtomicClaim) (rest : List String) :
    parseAtomicClaimStep (encAtomicClaimSeq cl ++ rest) = .ok (cl, rest) := by
  cases cl <;> simp [encAtomicClaimSeq, List.append_assoc, parseAtomicClaimStep,
                     Bind.bind, Except.bind, parseStrStep_enc, parseDistKindStep_enc,
                     parseOptStrStep_enc, parseOptPairStrStep_enc, parseIntervModStep_enc,
                     parseQuantFormStep_enc]

def encRawTermSeq : RawSemanticTerm → List String
  | .scopedAtom sc bnd cl ps =>
    "RawSemanticTerm.scopedAtom" ::
      (encScopeSeq sc ++ encStrSeq bnd ++ encAtomicClaimSeq cl ++ encPresupListSeq ps)
  | .symConj l r =>
    "RawSemanticTerm.symConj" :: (encRawTermSeq l ++ encRawTermSeq r)
  | .contrastivePair a m shE shO =>
    "RawSemanticTerm.contrastivePair" ::
      (encRawTermSeq a ++ encRawTermSeq m ++ encStrSeq shE ++ encStrSeq shO)

theorem encRawTermSeq_valid (m : RawSemanticTerm) :
    1 ≤ (encRawTermSeq m).length ∧ ∀ t ∈ encRawTermSeq m, ValidToken t := by
  induction m with
  | scopedAtom sc bnd cl ps =>
    refine ⟨by simp [encRawTermSeq], ?_⟩
    intro t ht; simp only [encRawTermSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append
        (encScopeSeq_valid sc).2 (encStrSeq_valid bnd).2) (encAtomicClaimSeq_valid cl).2)
        (encPresupListSeq_valid ps).2 t hm
  | symConj l r ihl ihr =>
    refine ⟨by simp [encRawTermSeq], ?_⟩
    intro t ht; simp only [encRawTermSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append ihl.2 ihr.2 t hm
  | contrastivePair a ms shE shO iha ihm =>
    refine ⟨by simp [encRawTermSeq], ?_⟩
    intro t ht; simp only [encRawTermSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append iha.2 ihm.2)
        (encStrSeq_valid shE).2) (encStrSeq_valid shO).2 t hm

def parseRawTermToks : Nat → List String → Except DecodeRejectDiag (RawSemanticTerm × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "RawSemanticTerm.scopedAtom" :: rs => do
    let (sc, r1) ← parseScopeStep rs
    let (bnd, r2) ← parseStrStep r1
    let (cl, r3) ← parseAtomicClaimStep r2
    let (ps, r4) ← parsePresupListToks f r3
    .ok (.scopedAtom sc bnd cl ps, r4)
  | f + 1, "RawSemanticTerm.symConj" :: rs => do
    let (l, r1) ← parseRawTermToks f rs
    let (r, r2) ← parseRawTermToks f r1
    .ok (.symConj l r, r2)
  | f + 1, "RawSemanticTerm.contrastivePair" :: rs => do
    let (a, r1) ← parseRawTermToks f rs
    let (m, r2) ← parseRawTermToks f r1
    let (shE, r3) ← parseStrStep r2
    let (shO, r4) ← parseStrStep r3
    .ok (.contrastivePair a m shE shO, r4)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "RawSemanticTerm" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "RawSemanticTerm")

theorem parseRawTermToks_enc (m : RawSemanticTerm) (rest : List String) (fuel : Nat)
    (hf : (encRawTermSeq m).length ≤ fuel) :
    parseRawTermToks fuel (encRawTermSeq m ++ rest) = .ok (m, rest) := by
  induction m generalizing fuel rest with
  | scopedAtom sc bnd cl ps =>
    cases fuel with
    | zero => simp [encRawTermSeq] at hf
    | succ f =>
      have hpf : (encPresupListSeq ps).length ≤ f := by simp [encRawTermSeq] at hf; omega
      simp only [encRawTermSeq, List.cons_append, List.append_assoc, parseRawTermToks,
                 Bind.bind, Except.bind, parseScopeStep_enc, parseStrStep_enc,
                 parseAtomicClaimStep_enc]
      rw [parsePresupListToks_enc ps rest f hpf]
  | symConj l r ihl ihr =>
    cases fuel with
    | zero => simp [encRawTermSeq] at hf
    | succ f =>
      have hlf : (encRawTermSeq l).length ≤ f := by simp [encRawTermSeq] at hf; omega
      have hrf : (encRawTermSeq r).length ≤ f := by simp [encRawTermSeq] at hf; omega
      simp only [encRawTermSeq, List.cons_append, List.append_assoc, parseRawTermToks,
                 Bind.bind, Except.bind]
      rw [ihl (encRawTermSeq r ++ rest) f hlf]
      dsimp only
      rw [ihr rest f hrf]
  | contrastivePair a ms shE shO iha ihm =>
    cases fuel with
    | zero => simp [encRawTermSeq] at hf
    | succ f =>
      have haf : (encRawTermSeq a).length ≤ f := by simp [encRawTermSeq] at hf; omega
      have hmf : (encRawTermSeq ms).length ≤ f := by simp [encRawTermSeq] at hf; omega
      simp only [encRawTermSeq, List.cons_append, List.append_assoc, parseRawTermToks,
                 Bind.bind, Except.bind]
      rw [iha (encRawTermSeq ms ++ (encStrSeq shE ++ (encStrSeq shO ++ rest))) f haf]
      dsimp only
      rw [ihm (encStrSeq shE ++ (encStrSeq shO ++ rest)) f hmf]
      dsimp only
      simp [parseStrStep_enc]

def rawMeaningWireCodec : CanonicalWireCodec RawSemanticTerm where
  typeTag      := "RawSemanticTerm"
  encToks      := encRawTermSeq
  parseToks    := parseRawTermToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun m =>
    let ⟨h1, hv⟩ := encRawTermSeq_valid m
    ⟨by intro he; rw [he] at h1; simp at h1, hv⟩
  hParsePrefix := parseRawTermToks_enc

mutual
  def encNormItemSeq : NormItem → List String
    | .normAtom sc cl ps =>
      "NormItem.normAtom" :: (encScopeSeq sc ++ encAtomicClaimSeq cl ++ encPresupListSeq ps)
    | .normContrastive aItems mItems shE shO =>
      "NormItem.normContrastive" ::
        (encNormItemListSeq aItems ++ encNormItemListSeq mItems ++ encStrSeq shE ++ encStrSeq shO)

  def encNormItemListSeq : List NormItem → List String
    | []      => ["NormItemList.nil"]
    | x :: xs => "NormItemList.cons" :: (encNormItemSeq x ++ encNormItemListSeq xs)
end

mutual
  theorem encNormItemSeq_valid (it : NormItem) :
      1 ≤ (encNormItemSeq it).length ∧ ∀ t ∈ encNormItemSeq it, ValidToken t := by
    cases it with
    | normAtom sc cl ps =>
      refine ⟨by simp [encNormItemSeq], ?_⟩
      intro t ht; simp only [encNormItemSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append (valid_list_append (encScopeSeq_valid sc).2
          (encAtomicClaimSeq_valid cl).2) (encPresupListSeq_valid ps).2 t hm
    | normContrastive aItems mItems shE shO =>
      have ⟨_, hva⟩ := encNormItemListSeq_valid aItems
      have ⟨_, hvm⟩ := encNormItemListSeq_valid mItems
      refine ⟨by simp [encNormItemSeq], ?_⟩
      intro t ht; simp only [encNormItemSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append (valid_list_append (valid_list_append hva hvm)
          (encStrSeq_valid shE).2) (encStrSeq_valid shO).2 t hm

  theorem encNormItemListSeq_valid (xs : List NormItem) :
      1 ≤ (encNormItemListSeq xs).length ∧ ∀ t ∈ encNormItemListSeq xs, ValidToken t := by
    cases xs with
    | nil =>
      refine ⟨by simp [encNormItemListSeq], ?_⟩
      intro t ht; simp [encNormItemListSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
    | cons x rest =>
      have ⟨_, hvx⟩ := encNormItemSeq_valid x
      have ⟨_, hvr⟩ := encNormItemListSeq_valid rest
      refine ⟨by simp [encNormItemListSeq], ?_⟩
      intro t ht; simp only [encNormItemListSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append hvx hvr t hm
end

def parseNormItemToks : Nat → List String → Except DecodeRejectDiag (NormItem × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "NormItem.normAtom" :: rs => do
    let (sc, r1) ← parseScopeStep rs
    let (cl, r2) ← parseAtomicClaimStep r1
    let (ps, r3) ← parsePresupListToks f r2
    .ok (.normAtom sc cl ps, r3)
  | f + 1, "NormItem.normContrastive" :: rs => do
    let (aItems, r1) ← parseNormItemListToks f rs
    let (mItems, r2) ← parseNormItemListToks f r1
    let (shE, r3) ← parseStrStep r2
    let (shO, r4) ← parseStrStep r3
    .ok (.normContrastive aItems mItems shE shO, r4)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "NormItem" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "NormItem")
where
  parseNormItemListToks : Nat → List String → Except DecodeRejectDiag (List NormItem × List String)
    | 0, _ => .error .recursionFuelExhausted
    | _ + 1, "NormItemList.nil" :: rs => .ok ([], rs)
    | f + 1, "NormItemList.cons" :: rs => do
      let (x, r1) ← parseNormItemToks f rs
      let (xs, r2) ← parseNormItemListToks f r1
      .ok (x :: xs, r2)
    | _ + 1, t :: _ => .error (.unknownConstructorTag "NormItemList" t)
    | _ + 1, []     => .error (.unexpectedEndOfTokens "NormItemList")

mutual
  theorem parseNormItemToks_enc (it : NormItem) (rest : List String) (fuel : Nat)
      (hf : (encNormItemSeq it).length ≤ fuel) :
      parseNormItemToks fuel (encNormItemSeq it ++ rest) = .ok (it, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encNormItemSeq_valid it; omega
    | succ f =>
      cases it with
      | normAtom sc cl ps =>
        have hpf : (encPresupListSeq ps).length ≤ f := by simp [encNormItemSeq] at hf; omega
        simp only [encNormItemSeq, List.cons_append, List.append_assoc, parseNormItemToks,
                   Bind.bind, Except.bind, parseScopeStep_enc, parseAtomicClaimStep_enc]
        rw [parsePresupListToks_enc ps rest f hpf]
      | normContrastive aItems mItems shE shO =>
        have haf : (encNormItemListSeq aItems).length ≤ f := by simp [encNormItemSeq] at hf; omega
        have hmf : (encNormItemListSeq mItems).length ≤ f := by simp [encNormItemSeq] at hf; omega
        simp only [encNormItemSeq, List.cons_append, List.append_assoc, parseNormItemToks,
                   Bind.bind, Except.bind]
        rw [parseNormItemListToks_enc aItems (encNormItemListSeq mItems ++ (encStrSeq shE ++ (encStrSeq shO ++ rest))) f haf]
        dsimp only
        rw [parseNormItemListToks_enc mItems (encStrSeq shE ++ (encStrSeq shO ++ rest)) f hmf]
        dsimp only
        simp [parseStrStep_enc]

  theorem parseNormItemListToks_enc (xs : List NormItem) (rest : List String) (fuel : Nat)
      (hf : (encNormItemListSeq xs).length ≤ fuel) :
      parseNormItemToks.parseNormItemListToks fuel (encNormItemListSeq xs ++ rest) = .ok (xs, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encNormItemListSeq_valid xs; omega
    | succ f =>
      cases xs with
      | nil => rfl
      | cons x tail =>
        have hxf : (encNormItemSeq x).length ≤ f := by simp [encNormItemListSeq] at hf; omega
        have htf : (encNormItemListSeq tail).length ≤ f := by simp [encNormItemListSeq] at hf; omega
        simp only [encNormItemListSeq, List.cons_append, List.append_assoc,
                   parseNormItemToks.parseNormItemListToks, Bind.bind, Except.bind]
        rw [parseNormItemToks_enc x (encNormItemListSeq tail ++ rest) f hxf]
        dsimp only
        rw [parseNormItemListToks_enc tail rest f htf]
end

def encCanonicalSeq (c : CanonicalMeaning) : List String :=
  "CanonicalMeaning.mk" :: encNormItemListSeq c.items

def parseCanonicalToks : Nat → List String → Except DecodeRejectDiag (CanonicalMeaning × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "CanonicalMeaning.mk" :: rs => do
    let (items, r1) ← parseNormItemToks.parseNormItemListToks f rs
    .ok (⟨items⟩, r1)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "CanonicalMeaning" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "CanonicalMeaning")

theorem parseCanonicalToks_enc (c : CanonicalMeaning) (rest : List String) (fuel : Nat)
    (hf : (encCanonicalSeq c).length ≤ fuel) :
    parseCanonicalToks fuel (encCanonicalSeq c ++ rest) = .ok (c, rest) := by
  cases fuel with
  | zero => simp [encCanonicalSeq] at hf
  | succ f =>
    cases c with
    | mk items =>
      have hif : (encNormItemListSeq items).length ≤ f := by simp [encCanonicalSeq] at hf; omega
      simp only [encCanonicalSeq, List.cons_append, parseCanonicalToks, Bind.bind, Except.bind]
      rw [parseNormItemListToks_enc items rest f hif]

def canonicalMeaningWireCodec : CanonicalWireCodec CanonicalMeaning where
  typeTag      := "CanonicalMeaning"
  encToks      := encCanonicalSeq
  parseToks    := parseCanonicalToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun c => by
    refine ⟨by simp [encCanonicalSeq], ?_⟩
    intro t ht; simp only [encCanonicalSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encNormItemListSeq_valid c.items).2 t hm
  hParsePrefix := parseCanonicalToks_enc

/-! ### 10. `ForestExtractionError`, Extraction Result & 5-Way `SemanticNormOutcome` Codecs -/

def encExtractionDiagSeq : ExtractionFailureDiag → List String
  | .malformedParseNode p det       => "ExtractionFailureDiag.malformedParseNode" :: prodToWireName p :: encStrSeq det
  | .unsupportedReadingAlt p alt    => ["ExtractionFailureDiag.unsupportedReadingAlt", prodToWireName p, encNatTok alt]
  | .mismatchedScopeCohort fnd exp  => "ExtractionFailureDiag.mismatchedScopeCohort" :: (encStrSeq fnd ++ encStrSeq exp)
  | .unresolvedAnaphoricScope fnd exp => "ExtractionFailureDiag.unresolvedAnaphoricScope" :: (encStrSeq fnd ++ encStrSeq exp)
  | .invalidContrastiveAnchor p     => ["ExtractionFailureDiag.invalidContrastiveAnchor", prodToWireName p]

theorem encExtractionDiagSeq_valid (d : ExtractionFailureDiag) :
    1 ≤ (encExtractionDiagSeq d).length ∧ ∀ t ∈ encExtractionDiagSeq d, ValidToken t := by
  cases d with
  | malformedParseNode p det =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp h1 with rfl | h2
      · exact prodToWireName_valid p
      · exact (encStrSeq_valid det).2 t h2
  | unsupportedReadingAlt p alt =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp h1 with rfl | h2
      · exact prodToWireName_valid p
      · rcases List.mem_cons.mp h2 with rfl | h3
        · exact encNatTok_valid alt
        · nomatch h3
  | mismatchedScopeCohort fnd exp =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encStrSeq_valid fnd).2 (encStrSeq_valid exp).2 t h1
  | unresolvedAnaphoricScope fnd exp =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encStrSeq_valid fnd).2 (encStrSeq_valid exp).2 t h1
  | invalidContrastiveAnchor p =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp h1 with rfl | h2
      · exact prodToWireName_valid p
      · nomatch h2

def parseExtractionDiagStep (toks : List String) :
    Except DecodeRejectDiag (ExtractionFailureDiag × List String) :=
  match toks with
  | "ExtractionFailureDiag.malformedParseNode" :: rs => do
    let (p, r1) ← parseProdStep rs; let (det, r2) ← parseStrStep r1
    .ok (.malformedParseNode p det, r2)
  | "ExtractionFailureDiag.unsupportedReadingAlt" :: rs => do
    let (p, r1) ← parseProdStep rs; let (alt, r2) ← parseNatStep r1
    .ok (.unsupportedReadingAlt p alt, r2)
  | "ExtractionFailureDiag.mismatchedScopeCohort" :: rs => do
    let (f, r1) ← parseStrStep rs; let (e, r2) ← parseStrStep r1
    .ok (.mismatchedScopeCohort f e, r2)
  | "ExtractionFailureDiag.unresolvedAnaphoricScope" :: rs => do
    let (f, r1) ← parseStrStep rs; let (e, r2) ← parseStrStep r1
    .ok (.unresolvedAnaphoricScope f e, r2)
  | "ExtractionFailureDiag.invalidContrastiveAnchor" :: rs => do
    let (p, r1) ← parseProdStep rs
    .ok (.invalidContrastiveAnchor p, r1)
  | t :: _ => .error (.unknownConstructorTag "ExtractionFailureDiag" t)
  | []     => .error (.unexpectedEndOfTokens "ExtractionFailureDiag")

theorem parseExtractionDiagStep_enc (d : ExtractionFailureDiag) (rest : List String) :
    parseExtractionDiagStep (encExtractionDiagSeq d ++ rest) = .ok (d, rest) := by
  cases d <;> simp [encExtractionDiagSeq, List.append_assoc, parseExtractionDiagStep,
                    Bind.bind, Except.bind, parseProdStep_enc, parseStrStep_enc, parseNatStep_enc]

def encForestErrSeq (err : ForestExtractionError) : List String :=
  "ForestExtractionError.mk" :: (encParseTreeSeq err.failedTree ++ encExtractionDiagSeq err.diag)

def parseForestErrToks : Nat → List String → Except DecodeRejectDiag (ForestExtractionError × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "ForestExtractionError.mk" :: rs => do
    let (tr, r1) ← parseParseTreeToks f rs
    let (dg, r2) ← parseExtractionDiagStep r1
    .ok (⟨tr, dg⟩, r2)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "ForestExtractionError" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "ForestExtractionError")

theorem parseForestErrToks_enc (err : ForestExtractionError) (rest : List String) (fuel : Nat)
    (hf : (encForestErrSeq err).length ≤ fuel) :
    parseForestErrToks fuel (encForestErrSeq err ++ rest) = .ok (err, rest) := by
  cases fuel with
  | zero => simp [encForestErrSeq] at hf
  | succ f =>
    cases err with
    | mk tr dg =>
      have htf : (encParseTreeSeq tr).length ≤ f := by simp [encForestErrSeq] at hf; omega
      simp only [encForestErrSeq, List.cons_append, List.append_assoc, parseForestErrToks,
                 Bind.bind, Except.bind]
      rw [parseParseTreeToks_enc tr (encExtractionDiagSeq dg ++ rest) f htf]
      dsimp only
      rw [parseExtractionDiagStep_enc]

def forestExtractionErrWireCodec : CanonicalWireCodec ForestExtractionError where
  typeTag      := "ForestExtractionError"
  encToks      := encForestErrSeq
  parseToks    := parseForestErrToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun err => by
    refine ⟨by simp [encForestErrSeq], ?_⟩
    intro t ht; simp only [encForestErrSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encParseTreeSeq_valid err.failedTree).2
        (encExtractionDiagSeq_valid err.diag).2 t hm
  hParsePrefix := parseForestErrToks_enc

def encSingleExtResSeq : Except ExtractionFailureDiag RawSemanticTerm → List String
  | .error d => "Except.error" :: encExtractionDiagSeq d
  | .ok m    => "Except.ok" :: encRawTermSeq m

def parseSingleExtResToks : Nat → List String →
    Except DecodeRejectDiag (Except ExtractionFailureDiag RawSemanticTerm × List String)
  | 0, _ => .error .recursionFuelExhausted
  | _ + 1, "Except.error" :: rs => do
    let (d, r1) ← parseExtractionDiagStep rs
    .ok (.error d, r1)
  | f + 1, "Except.ok" :: rs => do
    let (m, r1) ← parseRawTermToks f rs
    .ok (.ok m, r1)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "SingleExtractionResult" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "SingleExtractionResult")

theorem parseSingleExtResToks_enc (res : Except ExtractionFailureDiag RawSemanticTerm)
    (rest : List String) (fuel : Nat) (hf : (encSingleExtResSeq res).length ≤ fuel) :
    parseSingleExtResToks fuel (encSingleExtResSeq res ++ rest) = .ok (res, rest) := by
  cases fuel with
  | zero =>
    cases res <;> simp [encSingleExtResSeq] at hf
  | succ f =>
    cases res with
    | error d =>
      simp [encSingleExtResSeq, parseSingleExtResToks, Bind.bind, Except.bind, parseExtractionDiagStep_enc]
    | ok m =>
      have hmf : (encRawTermSeq m).length ≤ f := by simp [encSingleExtResSeq] at hf; omega
      simp only [encSingleExtResSeq, List.cons_append, parseSingleExtResToks, Bind.bind, Except.bind]
      rw [parseRawTermToks_enc m rest f hmf]

def singleExtractionResWireCodec : CanonicalWireCodec (Except ExtractionFailureDiag RawSemanticTerm) where
  typeTag      := "SingleExtractionResult"
  encToks      := encSingleExtResSeq
  parseToks    := parseSingleExtResToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun res => by
    cases res with
    | error d =>
      refine ⟨by simp [encSingleExtResSeq], ?_⟩
      intro t ht; simp only [encSingleExtResSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact (encExtractionDiagSeq_valid d).2 t hm
    | ok m =>
      refine ⟨by simp [encSingleExtResSeq], ?_⟩
      intro t ht; simp only [encSingleExtResSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact (encRawTermSeq_valid m).2 t hm
  hParsePrefix := parseSingleExtResToks_enc

def encTrapDiagSeq : TrapPolicyDiag → List String
  | .whFactivePresuppositionForbidden => ["TrapPolicyDiag.whFactivePresuppositionForbidden"]
  | .unscopedClauseForbidden          => ["TrapPolicyDiag.unscopedClauseForbidden"]
  | .parserOnlyTrapProduction r       => ["TrapPolicyDiag.parserOnlyTrapProduction", ruleIdToWireName r]
  | .wrapperTrapEnvelope              => ["TrapPolicyDiag.wrapperTrapEnvelope"]

theorem encTrapDiagSeq_valid (d : TrapPolicyDiag) :
    1 ≤ (encTrapDiagSeq d).length ∧ ∀ t ∈ encTrapDiagSeq d, ValidToken t := by
  cases d with
  | whFactivePresuppositionForbidden =>
    refine ⟨by simp [encTrapDiagSeq], ?_⟩
    intro t ht; simp [encTrapDiagSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | unscopedClauseForbidden =>
    refine ⟨by simp [encTrapDiagSeq], ?_⟩
    intro t ht; simp [encTrapDiagSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | parserOnlyTrapProduction r =>
    refine ⟨by simp [encTrapDiagSeq], ?_⟩
    intro t ht; simp only [encTrapDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp h1 with rfl | h2
      · exact ruleIdToWireName_valid r
      · nomatch h2
  | wrapperTrapEnvelope =>
    refine ⟨by simp [encTrapDiagSeq], ?_⟩
    intro t ht; simp [encTrapDiagSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)

def parseTrapDiagStep (toks : List String) : Except DecodeRejectDiag (TrapPolicyDiag × List String) :=
  match toks with
  | "TrapPolicyDiag.whFactivePresuppositionForbidden" :: rs => .ok (.whFactivePresuppositionForbidden, rs)
  | "TrapPolicyDiag.unscopedClauseForbidden" :: rs => .ok (.unscopedClauseForbidden, rs)
  | "TrapPolicyDiag.parserOnlyTrapProduction" :: rs => do
    let (r, r1) ← parseRuleIdStep rs
    .ok (.parserOnlyTrapProduction r, r1)
  | "TrapPolicyDiag.wrapperTrapEnvelope" :: rs => .ok (.wrapperTrapEnvelope, rs)
  | t :: _ => .error (.unknownConstructorTag "TrapPolicyDiag" t)
  | []     => .error (.unexpectedEndOfTokens "TrapPolicyDiag")

theorem parseTrapDiagStep_enc (d : TrapPolicyDiag) (rest : List String) :
    parseTrapDiagStep (encTrapDiagSeq d ++ rest) = .ok (d, rest) := by
  cases d <;> simp [encTrapDiagSeq, parseTrapDiagStep, Bind.bind, Except.bind, parseRuleIdStep_enc]

def encUpstreamDiagSeq : UpstreamParseDiag → List String
  | .emptyParseSet => ["UpstreamParseDiag.emptyParseSet"]
  | .outOfDomain .emptyInput => ["UpstreamParseDiag.outOfDomain", "OutOfDomainDiag.emptyInput"]
  | .outOfDomain (.nonPrintableAsciiByte b) =>
    "UpstreamParseDiag.outOfDomain" :: "OutOfDomainDiag.nonPrintableAsciiByte" :: encUInt8Seq b
  | .resourceOverflow (.maxBytesExceeded act lim) =>
    ["UpstreamParseDiag.resourceOverflow", "OverflowReason.maxBytesExceeded", encNatTok act, encNatTok lim]
  | .resourceOverflow (.maxStepsExceeded lim) =>
    ["UpstreamParseDiag.resourceOverflow", "OverflowReason.maxStepsExceeded", encNatTok lim]
  | .resourceOverflow (.maxForestNodesExceeded lim) =>
    ["UpstreamParseDiag.resourceOverflow", "OverflowReason.maxForestNodesExceeded", encNatTok lim]
  | .resourceOverflow (.maxReadingsExceeded act lim) =>
    ["UpstreamParseDiag.resourceOverflow", "OverflowReason.maxReadingsExceeded", encNatTok act, encNatTok lim]

theorem encUpstreamDiagSeq_valid (d : UpstreamParseDiag) :
    1 ≤ (encUpstreamDiagSeq d).length ∧ ∀ t ∈ encUpstreamDiagSeq d, ValidToken t := by
  cases d with
  | emptyParseSet =>
    refine ⟨by simp [encUpstreamDiagSeq], ?_⟩
    intro t ht; simp [encUpstreamDiagSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | outOfDomain od =>
    cases od with
    | emptyInput =>
      refine ⟨by simp [encUpstreamDiagSeq], ?_⟩
      intro t ht; simp only [encUpstreamDiagSeq] at ht
      rcases List.mem_cons.mp ht with rfl | h1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp h1 with rfl | h2
        · exact checkValidTokenBool_sound (by decide)
        · nomatch h2
    | nonPrintableAsciiByte b =>
      refine ⟨by simp [encUpstreamDiagSeq], ?_⟩
      intro t ht; simp only [encUpstreamDiagSeq, encUInt8Seq] at ht
      rcases List.mem_cons.mp ht with rfl | h1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp h1 with rfl | h2
        · exact checkValidTokenBool_sound (by decide)
        · rcases List.mem_cons.mp h2 with rfl | h3
          · exact checkValidTokenBool_sound (by decide)
          · rcases List.mem_cons.mp h3 with rfl | h4
            · exact encNatTok_valid _
            · nomatch h4
  | resourceOverflow ov =>
    cases ov <;> (
      refine ⟨by simp [encUpstreamDiagSeq], ?_⟩
      intro t ht; simp only [encUpstreamDiagSeq] at ht
      repeat (rcases List.mem_cons.mp ht with rfl | ht; · first | exact checkValidTokenBool_sound (by decide) | exact encNatTok_valid _)
      nomatch ht)

def parseUpstreamDiagStep (toks : List String) : Except DecodeRejectDiag (UpstreamParseDiag × List String) :=
  match toks with
  | "UpstreamParseDiag.emptyParseSet" :: rs => .ok (.emptyParseSet, rs)
  | "UpstreamParseDiag.outOfDomain" :: "OutOfDomainDiag.emptyInput" :: rs =>
    .ok (.outOfDomain .emptyInput, rs)
  | "UpstreamParseDiag.outOfDomain" :: "OutOfDomainDiag.nonPrintableAsciiByte" :: rs => do
    let (b, r1) ← parseUInt8Step rs
    .ok (.outOfDomain (.nonPrintableAsciiByte b), r1)
  | "UpstreamParseDiag.resourceOverflow" :: "OverflowReason.maxBytesExceeded" :: rs => do
    let (act, r1) ← parseNatStep rs; let (lim, r2) ← parseNatStep r1
    .ok (.resourceOverflow (.maxBytesExceeded act lim), r2)
  | "UpstreamParseDiag.resourceOverflow" :: "OverflowReason.maxStepsExceeded" :: rs => do
    let (lim, r1) ← parseNatStep rs
    .ok (.resourceOverflow (.maxStepsExceeded lim), r1)
  | "UpstreamParseDiag.resourceOverflow" :: "OverflowReason.maxForestNodesExceeded" :: rs => do
    let (lim, r1) ← parseNatStep rs
    .ok (.resourceOverflow (.maxForestNodesExceeded lim), r1)
  | "UpstreamParseDiag.resourceOverflow" :: "OverflowReason.maxReadingsExceeded" :: rs => do
    let (act, r1) ← parseNatStep rs; let (lim, r2) ← parseNatStep r1
    .ok (.resourceOverflow (.maxReadingsExceeded act lim), r2)
  | t :: _ => .error (.unknownConstructorTag "UpstreamParseDiag" t)
  | []     => .error (.unexpectedEndOfTokens "UpstreamParseDiag")

theorem parseUpstreamDiagStep_enc (d : UpstreamParseDiag) (rest : List String) :
    parseUpstreamDiagStep (encUpstreamDiagSeq d ++ rest) = .ok (d, rest) := by
  cases d with
  | emptyParseSet => rfl
  | outOfDomain od =>
    cases od <;> simp [encUpstreamDiagSeq, parseUpstreamDiagStep, Bind.bind, Except.bind, parseUInt8Step_enc]
  | resourceOverflow ov =>
    cases ov <;> simp [encUpstreamDiagSeq, parseUpstreamDiagStep, Bind.bind, Except.bind, parseNatStep_enc]

def encAmbigWitnessSeq (w : AmbiguityRefutationWitness) : List String :=
  "AmbiguityRefutationWitness.mk" ::
    (encParseTreeSeq w.tree1 ++ encParseTreeSeq w.tree2 ++
     encRawTermSeq w.raw1 ++ encRawTermSeq w.raw2 ++
     encCanonicalSeq w.norm1 ++ encCanonicalSeq w.norm2)

def parseAmbigWitnessToks : Nat → List String →
    Except DecodeRejectDiag (AmbiguityRefutationWitness × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "AmbiguityRefutationWitness.mk" :: rs => do
    let (t1, r1) ← parseParseTreeToks f rs
    let (t2, r2) ← parseParseTreeToks f r1
    let (m1, r3) ← parseRawTermToks f r2
    let (m2, r4) ← parseRawTermToks f r3
    let (c1, r5) ← parseCanonicalToks f r4
    let (c2, r6) ← parseCanonicalToks f r5
    .ok (⟨t1, t2, m1, m2, c1, c2⟩, r6)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "AmbiguityRefutationWitness" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "AmbiguityRefutationWitness")

theorem parseAmbigWitnessToks_enc (w : AmbiguityRefutationWitness) (rest : List String) (fuel : Nat)
    (hf : (encAmbigWitnessSeq w).length ≤ fuel) :
    parseAmbigWitnessToks fuel (encAmbigWitnessSeq w ++ rest) = .ok (w, rest) := by
  cases fuel with
  | zero => simp [encAmbigWitnessSeq] at hf
  | succ f =>
    cases w with
    | mk t1 t2 m1 m2 c1 c2 =>
      have h1 : (encParseTreeSeq t1).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h2 : (encParseTreeSeq t2).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h3 : (encRawTermSeq m1).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h4 : (encRawTermSeq m2).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h5 : (encCanonicalSeq c1).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h6 : (encCanonicalSeq c2).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      simp only [encAmbigWitnessSeq, List.cons_append, List.append_assoc, parseAmbigWitnessToks,
                 Bind.bind, Except.bind]
      rw [parseParseTreeToks_enc t1 _ f h1]; dsimp only
      rw [parseParseTreeToks_enc t2 _ f h2]; dsimp only
      rw [parseRawTermToks_enc m1 _ f h3]; dsimp only
      rw [parseRawTermToks_enc m2 _ f h4]; dsimp only
      rw [parseCanonicalToks_enc c1 _ f h5]; dsimp only
      rw [parseCanonicalToks_enc c2 _ f h6]

def encOutcomeSeq : SemanticNormOutcome → List String
  | .consensus T c =>
    "SemanticNormOutcome.consensus" :: (encForestSeq T ++ encCanonicalSeq c)
  | .ambiguousReadings T w =>
    "SemanticNormOutcome.ambiguousReadings" :: (encForestSeq T ++ encAmbigWitnessSeq w)
  | .semanticExtractionFailure T err =>
    "SemanticNormOutcome.semanticExtractionFailure" :: (encForestSeq T ++ encForestErrSeq err)
  | .trapPolicyRejected T c d =>
    "SemanticNormOutcome.trapPolicyRejected" :: (encForestSeq T ++ encCanonicalSeq c ++ encTrapDiagSeq d)
  | .upstreamRejected d =>
    "SemanticNormOutcome.upstreamRejected" :: encUpstreamDiagSeq d

theorem encOutcomeSeq_valid (out : SemanticNormOutcome) :
    1 ≤ (encOutcomeSeq out).length ∧ ∀ t ∈ encOutcomeSeq out, ValidToken t := by
  cases out with
  | consensus T c =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encForestSeq_valid T).2 (canonicalMeaningWireCodec.hToksValid c).2 t hm
  | ambiguousReadings T w =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · apply valid_list_append (encForestSeq_valid T).2 _ t hm
      intro t2 ht2; simp only [encAmbigWitnessSeq] at ht2
      rcases List.mem_cons.mp ht2 with rfl | hw
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append
          (valid_list_append (encParseTreeSeq_valid w.tree1).2 (encParseTreeSeq_valid w.tree2).2)
          (encRawTermSeq_valid w.raw1).2) (encRawTermSeq_valid w.raw2).2)
          (canonicalMeaningWireCodec.hToksValid w.norm1).2)
          (canonicalMeaningWireCodec.hToksValid w.norm2).2 t2 hw
  | semanticExtractionFailure T err =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encForestSeq_valid T).2
        (forestExtractionErrWireCodec.hToksValid err).2 t hm
  | trapPolicyRejected T c d =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (encForestSeq_valid T).2
        (canonicalMeaningWireCodec.hToksValid c).2) (encTrapDiagSeq_valid d).2 t hm
  | upstreamRejected d =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encUpstreamDiagSeq_valid d).2 t hm

def parseOutcomeToks : Nat → List String → Except DecodeRejectDiag (SemanticNormOutcome × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "SemanticNormOutcome.consensus" :: rs => do
    let (T, r1) ← parseForestToks f rs
    let (c, r2) ← parseCanonicalToks f r1
    .ok (.consensus T c, r2)
  | f + 1, "SemanticNormOutcome.ambiguousReadings" :: rs => do
    let (T, r1) ← parseForestToks f rs
    let (w, r2) ← parseAmbigWitnessToks f r1
    .ok (.ambiguousReadings T w, r2)
  | f + 1, "SemanticNormOutcome.semanticExtractionFailure" :: rs => do
    let (T, r1) ← parseForestToks f rs
    let (err, r2) ← parseForestErrToks f r1
    .ok (.semanticExtractionFailure T err, r2)
  | f + 1, "SemanticNormOutcome.trapPolicyRejected" :: rs => do
    let (T, r1) ← parseForestToks f rs
    let (c, r2) ← parseCanonicalToks f r1
    let (d, r3) ← parseTrapDiagStep r2
    .ok (.trapPolicyRejected T c d, r3)
  | _ + 1, "SemanticNormOutcome.upstreamRejected" :: rs => do
    let (d, r1) ← parseUpstreamDiagStep rs
    .ok (.upstreamRejected d, r1)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "SemanticNormOutcome" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "SemanticNormOutcome")

theorem parseOutcomeToks_enc (out : SemanticNormOutcome) (rest : List String) (fuel : Nat)
    (hf : (encOutcomeSeq out).length ≤ fuel) :
    parseOutcomeToks fuel (encOutcomeSeq out ++ rest) = .ok (out, rest) := by
  cases fuel with
  | zero =>
    have ⟨h1, _⟩ := encOutcomeSeq_valid out; omega
  | succ f =>
    cases out with
    | consensus T c =>
      have htf : (encForestSeq T).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      have hcf : (encCanonicalSeq c).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      simp only [encOutcomeSeq, List.cons_append, List.append_assoc, parseOutcomeToks, Bind.bind, Except.bind]
      rw [parseForestToks_enc T _ f htf]; dsimp only
      rw [parseCanonicalToks_enc c _ f hcf]
    | ambiguousReadings T w =>
      have htf : (encForestSeq T).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      have hwf : (encAmbigWitnessSeq w).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      simp only [encOutcomeSeq, List.cons_append, List.append_assoc, parseOutcomeToks, Bind.bind, Except.bind]
      rw [parseForestToks_enc T _ f htf]; dsimp only
      rw [parseAmbigWitnessToks_enc w _ f hwf]
    | semanticExtractionFailure T err =>
      have htf : (encForestSeq T).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      have hef : (encForestErrSeq err).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      simp only [encOutcomeSeq, List.cons_append, List.append_assoc, parseOutcomeToks, Bind.bind, Except.bind]
      rw [parseForestToks_enc T _ f htf]; dsimp only
      rw [parseForestErrToks_enc err _ f hef]
    | trapPolicyRejected T c d =>
      have htf : (encForestSeq T).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      have hcf : (encCanonicalSeq c).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      simp only [encOutcomeSeq, List.cons_append, List.append_assoc, parseOutcomeToks, Bind.bind, Except.bind]
      rw [parseForestToks_enc T _ f htf]; dsimp only
      rw [parseCanonicalToks_enc c _ f hcf]; dsimp only
      rw [parseTrapDiagStep_enc]
    | upstreamRejected d =>
      simp [encOutcomeSeq, parseOutcomeToks, Bind.bind, Except.bind, parseUpstreamDiagStep_enc]

def outcomeWireCodec : CanonicalWireCodec SemanticNormOutcome where
  typeTag      := "SemanticNormOutcome"
  encToks      := encOutcomeSeq
  parseToks    := parseOutcomeToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun out =>
    let ⟨h1, hv⟩ := encOutcomeSeq_valid out
    ⟨by intro he; rw [he] at h1; simp at h1, hv⟩
  hParsePrefix := parseOutcomeToks_enc

/-! ### 11. `PO-DIFF-03` (`Span Unit Integrity`) Core Lemmas -/

theorem asciiByteToChar_utf8_len_one (b : UInt8) (hb : IsPrintableAsciiByte b) :
    utf8ByteLenOfChar (asciiByteToChar b) = 1 := by
  rcases b with ⟨⟨v, _⟩⟩
  rcases hb with ⟨_, hhi⟩
  have hv_hi : v ≤ 0x7E := hhi
  unfold asciiByteToChar utf8ByteLenOfChar
  have htn : (Char.ofNat v).toNat = v := by
    unfold Char.ofNat Char.toNat
    have hvalid : v.isValidChar := by unfold Nat.isValidChar; omega
    rw [dif_pos hvalid]
    rfl
  dsimp only [UInt8.toNat, BitVec.toNat]
  rw [htn]
  have h7f : v ≤ 0x7F := by omega
  simp [h7f]

/--
  **`PO-DIFF-03a` (`ASCII Domain Byte-Codepoint Unit Identity`)**:
  For every `rawBytes` in `P3-B`'s supported `StrictAsciiDomainSupported` domain,
  the decoded Unicode character list has `cpLen = rawBytes.length` AND `utf8ByteLen = rawBytes.length`!
-/
theorem strictAscii_byte_eq_codepoint_length (bs : List UInt8)
    (hdom : StrictAsciiDomainSupported bs) :
    (decodeAsciiBytes bs).toList.length = bs.length ∧
    utf8ByteLenOfChars (decodeAsciiBytes bs).toList = bs.length := by
  rcases hdom with ⟨hpos, hall⟩
  clear hpos
  unfold decodeAsciiBytes
  rw [String.toList_ofList, List.length_map]
  refine ⟨rfl, ?_⟩
  induction bs with
  | nil => rfl
  | cons b rest ih =>
    simp only [List.map_cons, utf8ByteLenOfChars, List.length_cons]
    have hb : IsPrintableAsciiByte b := hall b (List.Mem.head rest)
    rw [asciiByteToChar_utf8_len_one b hb]
    rw [ih (fun x hx => hall x (List.Mem.tail b hx))]
    omega

/- Tree span structural boundary check (`0 ≤ startCp ≤ endCp ≤ docCpLen` & children inside parent). -/
mutual
  def checkArgSpansWithin (parentSpan : CodepointSpan) : List ConcreteParseArg → Bool
    | [] => true
    | .litTok _ sp :: rs =>
      (parentSpan.startCp ≤ sp.startCp) && (sp.startCp ≤ sp.endCp) &&
      (sp.endCp ≤ parentSpan.endCp) && checkArgSpansWithin parentSpan rs
    | .slotTok _ _ _ _ sp :: rs =>
      (parentSpan.startCp ≤ sp.startCp) && (sp.startCp ≤ sp.endCp) &&
      (sp.endCp ≤ parentSpan.endCp) && checkArgSpansWithin parentSpan rs
    | .childSub sub :: rs =>
      checkTreeSpansWithin parentSpan.startCp parentSpan.endCp sub &&
      checkArgSpansWithin parentSpan rs

  def checkTreeSpansWithin (minCp maxCp : Nat) : ConcreteParseTree → Bool
    | .mkTree _ _ _ sp args =>
      (minCp ≤ sp.startCp) && (sp.startCp ≤ sp.endCp) && (sp.endCp ≤ maxCp) &&
      checkArgSpansWithin sp args
end

end PneumaOmega.P3C.DifferentialR1
````

### File 6: `01_formal_spec/P3CDifferentialSpec/DifferentialAlgebraSpec.lean` (SHA-256: `352D462AA31316BFD0C09B79F158808B53AC039E774AF547E161E98CBF4DDE78`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Corrigendum R0`: `F-DIFF-P0-02..04` & `PO-DIFF-06..08`)
  01_formal_spec/P3CDifferentialSpec/DifferentialAlgebraSpec.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`)

  Defines:
    1. `OracleEpistemicGrade` (`SPEC_GROUNDED` | `MODEL_ASSUMPTION` | `SPEC_UNDEFINED` — `F-DIFF-P0-02`).
    2. `ObservationPathClass` (`SURFACE_E2E` | `FOREST_INJECT` | `SEMANTIC_INJECT` — `F-DIFF-P0-03`).
    3. Closed 5-way `DiffVerdict` (`MATCH_STRUCTURAL` | `MISMATCH_WITNESS` | `ORACLE_FAILURE` |
       `SPECIFICATION_HELD` | `RESOURCE_HELD` — `F-DIFF-P0-04`), never collapsing non-matches into `PASS`.
    4. Typed wire differential comparator `compareWirePayloads` with `PO-DIFF-07` (`Differential Scope Soundness`)
       and `PO-DIFF-08` (`Provenance Boundary Preservation`).
-/
import P3CDifferentialSpec.TypedWireFormatV1

namespace PneumaOmega.P3C.DifferentialR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.ProvenanceR1

/-! ### 1. Epistemic Grades (`F-DIFF-P0-02`) & Observation Path Classes (`F-DIFF-P0-03`) -/

inductive OracleEpistemicGrade where
  | SPEC_GROUNDED      -- Directly determined by frozen `Architecture Freeze R0` text/tables
  | MODEL_ASSUMPTION   -- Model-relative convention formalized in `P3-C` beyond raw `R0` prose
  | SPEC_UNDEFINED     -- Underspecified in `R0` -> must yield `SPECIFICATION_HELD`
  deriving DecidableEq, Repr

inductive ObservationPathClass where
  | SURFACE_E2E        -- End-to-end surface bytes through `parseAllBounded -> P3-C -> Provenance R1`
  | FOREST_INJECT      -- Direct `ConcreteParseTree` / forest injection into `P3-C` internal gates
  | SEMANTIC_INJECT    -- Direct `RawSemanticTerm` / `CanonicalMeaning` / wire payload perturbation
  deriving DecidableEq, Repr

inductive FirstBlockingBoundary where
  | p3bStrictAsciiDomain
  | p3bBoundedResourceGate
  | p3bGrammarAndCheckSide
  | p3cRawTreeExtractor
  | p3cCanonicalNormalizer
  | p3cConsensusAndTrapGate
  | diffV1CanonicalWireDecoder
  | provenanceR1WhiteboxReplay
  deriving DecidableEq, Repr

/-! ### 2. Closed 5-Valued Differential Result Algebra (`DiffVerdict` — `F-DIFF-P0-04`) -/

inductive DiffStage where
  | wireDecodeStage
  | parseForestStage
  | spanIntegrityStage
  | rawExtractionStage
  | canonicalNormStage
  | outcomeGateStage
  | provenanceReplayStage
  deriving DecidableEq, Repr

inductive DiffVerdict where
  | MATCH_STRUCTURAL   (grade : OracleEpistemicGrade)
  | MISMATCH_WITNESS   (stage : DiffStage) (fieldLocus : String) (leanWire oracleWire : String)
  | ORACLE_FAILURE     (reason : String)
  | SPECIFICATION_HELD (r0Anchor : String) (detail : String)
  | RESOURCE_HELD      (budgetDetail : String)
  deriving DecidableEq, Repr

/-- Pinpoints the first token index where two wire strings diverge. -/
def firstDivergentTokIdx : Nat → List String → List String → String
  | idx, [], [] => s!"tok#{idx}:identical"
  | idx, _ :: _, [] => s!"tok#{idx}:lean_longer"
  | idx, [], _ :: _ => s!"tok#{idx}:oracle_longer"
  | idx, x :: xs, y :: ys =>
    if eqStrBool x y then firstDivergentTokIdx (idx + 1) xs ys
    else s!"tok#{idx}({x} != {y})"

/--
  **Typed Canonical Wire Differential Comparator (`compareWirePayloads`)**:
  - Never collapses `SPEC_UNDEFINED` into `MATCH_STRUCTURAL`: returns `SPECIFICATION_HELD`.
  - Decodes BOTH `leanWire` and `oracleWire` via `decodeWire C` (verifying both belong to `L_valid(C)`).
  - Returns `MATCH_STRUCTURAL grade` iff `grade ≠ .SPEC_UNDEFINED`, both wires are valid canonical encodings,
    and `leanWire = oracleWire` (which by `PO-DIFF-02` guarantees exact Lean value equality `x = y`!).
-/
def compareWirePayloads {α : Type} (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage)
    (leanWire oracleWire : String) : DiffVerdict :=
  match grade with
  | .SPEC_UNDEFINED =>
    .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held"
  | _ =>
    match decodeWire C leanWire with
    | .error eLean =>
      .ORACLE_FAILURE s!"lean_wire_decode_failed:{reprStr eLean}"
    | .ok _ =>
      match decodeWire C oracleWire with
      | .error eOracle =>
        .ORACLE_FAILURE s!"oracle_wire_decode_failed:{reprStr eOracle}"
      | .ok _ =>
        if eqStrBool leanWire oracleWire then
          .MATCH_STRUCTURAL grade
        else
          let lToks := match splitSemiChars leanWire.toList.length leanWire.toList with | .ok ts => ts | .error _ => []
          let oToks := match splitSemiChars oracleWire.toList.length oracleWire.toList with | .ok ts => ts | .error _ => []
          .MISMATCH_WITNESS stage (firstDivergentTokIdx 0 lToks oToks) leanWire oracleWire

/--
  **`PO-DIFF-07` (`Differential Scope Soundness`)**:
  1. `compareWirePayloads C grade anchor stage (encodeWire C x) (encodeWire C y) = .MATCH_STRUCTURAL g`
     holds **if and only if** `grade ≠ .SPEC_UNDEFINED`, `g = grade`, and `x = y` (exact structural equality
     of computational data `α` — explicitly NOT claiming clinical truth or `Prop` proof byte-equality!).
  2. Whenever `grade ≠ .SPEC_UNDEFINED` and `x ≠ y`, `compareWirePayloads` deterministically produces
     `.MISMATCH_WITNESS stage locus (encodeWire C x) (encodeWire C y)`!
-/
theorem compareWirePayloads_sound_and_complete {α : Type} (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    ((∀ g, compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
             .MATCH_STRUCTURAL g ↔ (grade ≠ .SPEC_UNDEFINED ∧ g = grade ∧ x = y)) ∧
     (grade ≠ .SPEC_UNDEFINED → x ≠ y →
       ∃ locus : String,
         compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
           .MISMATCH_WITNESS stage locus (encodeWire C x) (encodeWire C y))) := by
  refine ⟨?_, ?_⟩
  · intro g
    cases grade with
    | SPEC_UNDEFINED =>
      simp [compareWirePayloads]
    | SPEC_GROUNDED =>
      unfold compareWirePayloads
      rw [encodeWire_decodeWire_roundtrip C x, encodeWire_decodeWire_roundtrip C y]
      dsimp only
      by_cases heq : eqStrBool (encodeWire C x) (encodeWire C y) = true
      · rw [if_pos heq]
        have hxy : x = y := encodeWire_injective C ((eqStrBool_iff _ _).mp heq)
        simp [hxy, eq_comm]
      · rw [if_neg heq]
        constructor
        · intro h; contradiction
        · rintro ⟨_, _, rfl⟩
          exact False.elim (heq ((eqStrBool_iff _ _).mpr rfl))
    | MODEL_ASSUMPTION =>
      unfold compareWirePayloads
      rw [encodeWire_decodeWire_roundtrip C x, encodeWire_decodeWire_roundtrip C y]
      dsimp only
      by_cases heq : eqStrBool (encodeWire C x) (encodeWire C y) = true
      · rw [if_pos heq]
        have hxy : x = y := encodeWire_injective C ((eqStrBool_iff _ _).mp heq)
        simp [hxy, eq_comm]
      · rw [if_neg heq]
        constructor
        · intro h; contradiction
        · rintro ⟨_, _, rfl⟩
          exact False.elim (heq ((eqStrBool_iff _ _).mpr rfl))
  · intro hgrade hne
    have hneq_wire : eqStrBool (encodeWire C x) (encodeWire C y) = false := by
      apply Bool.eq_false_iff.mpr
      intro heq
      exact hne (encodeWire_injective C ((eqStrBool_iff _ _).mp heq))
    cases grade with
    | SPEC_UNDEFINED => exact False.elim (hgrade rfl)
    | SPEC_GROUNDED =>
      unfold compareWirePayloads
      rw [encodeWire_decodeWire_roundtrip C x, encodeWire_decodeWire_roundtrip C y]
      dsimp only
      rw [hneq_wire]
      exact ⟨_, rfl⟩
    | MODEL_ASSUMPTION =>
      unfold compareWirePayloads
      rw [encodeWire_decodeWire_roundtrip C x, encodeWire_decodeWire_roundtrip C y]
      dsimp only
      rw [hneq_wire]
      exact ⟨_, rfl⟩

/-! ### 3. `PO-DIFF-06` (`Five-Way Outcome Tag Separation`) & `PO-DIFF-08` (`Provenance Boundary`) -/

inductive OutcomeBranchTag where
  | tagConsensus
  | tagAmbiguousReadings
  | tagSemanticExtractionFailure
  | tagTrapPolicyRejected
  | tagUpstreamRejected
  deriving DecidableEq, Repr

def outcomeBranchOf : SemanticNormOutcome → OutcomeBranchTag
  | .consensus _ _                 => .tagConsensus
  | .ambiguousReadings _ _         => .tagAmbiguousReadings
  | .semanticExtractionFailure _ _ => .tagSemanticExtractionFailure
  | .trapPolicyRejected _ _ _      => .tagTrapPolicyRejected
  | .upstreamRejected _            => .tagUpstreamRejected

/--
  **`PO-DIFF-06` (`Five-Way Outcome Separation Across Wire Serialization`)**:
  Two `SemanticNormOutcome` values with distinct 5-way branch tags NEVER collide under `encodeWire`,
  and decoding any `encodeWire outcomeWireCodec out` preserves the exact 5-way branch tag and payload!
-/
theorem outcome_wire_preserves_five_way_separation (o₁ o₂ : SemanticNormOutcome) :
    (outcomeBranchOf o₁ ≠ outcomeBranchOf o₂ →
       encodeWire outcomeWireCodec o₁ ≠ encodeWire outcomeWireCodec o₂) ∧
    (∀ o', decodeWire outcomeWireCodec (encodeWire outcomeWireCodec o₁) = .ok o' →
       o' = o₁ ∧ outcomeBranchOf o' = outcomeBranchOf o₁) := by
  refine ⟨?_, ?_⟩
  · intro hne heq
    have ho : o₁ = o₂ := encodeWire_injective outcomeWireCodec heq
    subst ho
    exact hne rfl
  · intro o' hd
    have hrt := encodeWire_decodeWire_roundtrip outcomeWireCodec o₁
    rw [hrt] at hd
    injection hd with heq
    subst heq
    exact ⟨rfl, rfl⟩

/--
  Reconstructs an `UntrustedConsensusClaim` from a decoded `SemanticNormOutcome` wire payload and a
  claimed `ProvenanceContext`, then submits it to `ProvenanceR1.verifyUntrustedConsensusClaim`.
-/
def verifyDecodedOutcomeWireAgainstProvenance (targetCtx claimedCtx : ProvenanceContext)
    (wirePayload : String) :
    Except (Sum DecodeRejectDiag ProvenanceRejectReason) (CertifiedSemanticConsensus targetCtx) :=
  match decodeWire outcomeWireCodec wirePayload with
  | .error de => .error (.inl de)
  | .ok decodedOut =>
    match verifyUntrustedConsensusClaim targetCtx { claimedCtx := claimedCtx, claimedOutcome := decodedOut } with
    | .error pe => .error (.inr pe)
    | .ok cert  => .ok cert

/--
  **`PO-DIFF-08` (`Provenance Boundary Preservation`)**:
  Decoding a valid `PNEUMA-DIFF-SER-V1` `SemanticNormOutcome` string NEVER bypasses `Provenance R1`:
  1. `verifyDecodedOutcomeWireAgainstProvenance` admits `cert : CertifiedSemanticConsensus targetCtx`
     **iff** `claimedCtx = targetCtx`, `wirePayload = encodeWire outcomeWireCodec (.consensus cert.trees cert.canonical)`,
     and actual `P3-C` execution `ExecProvenanceSpec targetCtx cert.trees cert.canonical` holds!
  2. Any context mismatch (`claimedCtx ≠ targetCtx`) or any serialized non-consensus / forged outcome is rejected!
-/
theorem provenance_boundary_preserved_across_wire (targetCtx claimedCtx : ProvenanceContext)
    (wirePayload : String) :
    ((∀ cert : CertifiedSemanticConsensus targetCtx,
        verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx wirePayload = .ok cert ↔
          claimedCtx = targetCtx ∧
          wirePayload = encodeWire outcomeWireCodec (.consensus cert.trees cert.canonical) ∧
          ExecProvenanceSpec targetCtx cert.trees cert.canonical) ∧
     (claimedCtx ≠ targetCtx →
        ∃ err, verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx wirePayload = .error err)) := by
  refine ⟨?_, ?_⟩
  · intro cert
    unfold verifyDecodedOutcomeWireAgainstProvenance
    constructor
    · intro hok
      cases hd : decodeWire outcomeWireCodec wirePayload with
      | error _ => rw [hd] at hok; contradiction
      | ok dOut =>
        rw [hd] at hok
        dsimp only at hok
        cases hv : verifyUntrustedConsensusClaim targetCtx { claimedCtx := claimedCtx, claimedOutcome := dOut } with
        | error _ => rw [hv] at hok; contradiction
        | ok cert' =>
          rw [hv] at hok
          injection hok with hce
          subst cert'
          have ⟨hcl, hexec, _⟩ := (replay_faithfulness_iff targetCtx).1
            { claimedCtx := claimedCtx, claimedOutcome := dOut } cert hv
          unfold exportUntrustedClaim at hcl
          injection hcl with hctx hdout
          have hwire : encodeWire outcomeWireCodec dOut = wirePayload :=
            (decodeWire_ok_iff_encodeWire_eq outcomeWireCodec wirePayload dOut).mp hd
          rw [hdout] at hwire
          exact ⟨hctx, hwire.symm, hexec⟩
    · rintro ⟨hctx, rfl, _⟩
      subst claimedCtx
      rw [encodeWire_decodeWire_roundtrip outcomeWireCodec (.consensus cert.trees cert.canonical)]
      dsimp only
      have hcomp := (replay_faithfulness_iff targetCtx).2 cert
      unfold exportUntrustedClaim at hcomp
      rw [hcomp]
  · intro hne
    unfold verifyDecodedOutcomeWireAgainstProvenance
    cases hd : decodeWire outcomeWireCodec wirePayload with
    | error de => exact ⟨.inl de, rfl⟩
    | ok dOut =>
      dsimp only
      have ⟨r, hr⟩ := input_binding_replay_rejects_context_mismatch targetCtx
        { claimedCtx := claimedCtx, claimedOutcome := dOut } hne
      rw [hr]
      exact ⟨.inr r, rfl⟩

end PneumaOmega.P3C.DifferentialR1
````

### File 7: `02_detached_checker/P3CDifferentialChecker.lean` (SHA-256: `6C0AC3B98803F7D361ACAF25C2A780FF13C9ED272D74E4496B7345331EFF7415`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1
  Root export for `P3CDifferentialChecker`
-/
import P3CDifferentialChecker.DifferentialTraceObserver
````

### File 8: `02_detached_checker/P3CDifferentialChecker/DifferentialTraceObserver.lean` (SHA-256: `A46D160BB03DF9AA1D829F2AA88C141803A07C7C4BCE16279C9D91FE9C944E57`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate B` & `Gate C` Path A Stage Observer)
  02_detached_checker/P3CDifferentialChecker/DifferentialTraceObserver.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`)

  Implements:
    1. `Path A` read-only execution observers for all three `Corrigendum F-DIFF-P0-03` classes:
       - `observeSurfaceE2E`     (`SURFACE_E2E`: `parseAllBounded -> extractRawMeaning -> normalizeMeaning -> certifySemanticConsensus`)
       - `observeForestInject`   (`FOREST_INJECT`: internal `extractRawMeaning` / `evalForestPure` on injected trees)
       - `observeSemanticInject` (`SEMANTIC_INJECT`: internal `RawSemanticTerm -> CanonicalMeaning` normalizer trace)
    2. `PO-DIFF-03b` (`multibyte_utf8_byte_excluded_from_strictAsciiDomain` + upstream fail-closed bridge).
    3. `PO-DIFF-04` (`extraction_result_wire_fidelity`: lossless `.ok`/`.error` & `ForestExtractionError` wire preservation).
    4. `PO-DIFF-05` (`canonical_meaning_wire_fidelity`: lossless `CanonicalMeaning` wire bijection + `SemEq` equivalence).
-/
import P3CDifferentialSpec

namespace PneumaOmega.P3C.DifferentialR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.ProvenanceR1

/-! ### 1. Three-Class Read-Only Execution Observers (`Path A` — `F-DIFF-P0-03`) -/

structure SurfaceTraceBundle where
  byteLen                : Nat
  codepointLenOpt        : Option Nat
  parseStatus            : String
  forestWireOpt          : Option String
  spansWithinBounds      : Bool
  perTreeExtractionWires : List String
  perTreeCanonicalWires  : List String
  outcomeWire            : String
  deriving DecidableEq, Repr

/--
  **`SURFACE_E2E` Observer (`observeSurfaceE2E`)**:
  Calls frozen `parseAllBounded`, `extractRawMeaning`, `normalizeMeaning`, and `certifySemanticConsensus`
  on `ctx` without modifying any upstream module, emitting full `PNEUMA-DIFF-SER-V1` stage wires.
-/
def observeSurfaceE2E (ctx : ProvenanceContext) : SurfaceTraceBundle :=
  match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | .outOfDomain d =>
    { byteLen                := ctx.rawBytes.length
      codepointLenOpt        := none
      parseStatus            := "OUT_OF_DOMAIN"
      forestWireOpt          := none
      spansWithinBounds      := true
      perTreeExtractionWires := []
      perTreeCanonicalWires  := []
      outcomeWire            := encodeWire outcomeWireCodec (.upstreamRejected (.outOfDomain d)) }
  | .resourceOverflow b =>
    { byteLen                := ctx.rawBytes.length
      codepointLenOpt        := none
      parseStatus            := "RESOURCE_OVERFLOW"
      forestWireOpt          := none
      spansWithinBounds      := true
      perTreeExtractionWires := []
      perTreeCanonicalWires  := []
      outcomeWire            := encodeWire outcomeWireCodec (.upstreamRejected (.resourceOverflow b)) }
  | .enumerated T =>
    let docStr := decodeAsciiBytes ctx.rawBytes
    let cpLen  := docStr.toList.length
    let extRes := T.map (extractRawMeaning ctx.scopeEnv)
    let extWires := extRes.map (encodeWire singleExtractionResWireCodec)
    let canonWires := extRes.foldr (fun r acc =>
      match r with
      | .ok m    => encodeWire canonicalMeaningWireCodec (normalizeMeaning m) :: acc
      | .error _ => acc) []
    { byteLen                := ctx.rawBytes.length
      codepointLenOpt        := some cpLen
      parseStatus            := "ENUMERATED"
      forestWireOpt          := some (encodeWire parseForestWireCodec T)
      spansWithinBounds      := T.all (checkTreeSpansWithin 0 cpLen)
      perTreeExtractionWires := extWires
      perTreeCanonicalWires  := canonWires
      outcomeWire            := encodeWire outcomeWireCodec (evalForestPure ctx.scopeEnv T) }

structure ForestInjectTraceBundle where
  forestWire             : String
  perTreeExtractionWires : List String
  forestOutcomeWire      : String
  deriving DecidableEq, Repr

/--
  **`FOREST_INJECT` Observer (`observeForestInject`)**:
  Directly injects an explicit `List ConcreteParseTree` into frozen `P3-C` internal `extractRawMeaning`
  and `evalForestPure` (strictly separated from `parseAllBounded` per `Gate B4` & `F-DIFF-P0-03`).
-/
def observeForestInject (env : ScopeEnv) (injectedForest : List ConcreteParseTree) :
    ForestInjectTraceBundle :=
  { forestWire             := encodeWire parseForestWireCodec injectedForest
    perTreeExtractionWires := injectedForest.map (fun t =>
      encodeWire singleExtractionResWireCodec (extractRawMeaning env t))
    forestOutcomeWire      := encodeWire outcomeWireCodec (evalForestPure env injectedForest) }

structure SemanticInjectTraceBundle where
  rawWire                 : String
  canonicalWire           : String
  idempotentCanonicalWire : String
  deriving DecidableEq, Repr

/--
  **`SEMANTIC_INJECT` Observer (`observeSemanticInject`)**:
  Directly observes `RawSemanticTerm` and its canonical normal form `normalizeMeaning` + idempotence.
-/
def observeSemanticInject (rawTerm : RawSemanticTerm) : SemanticInjectTraceBundle :=
  let c1 := normalizeMeaning rawTerm
  let c2 := normalizeMeaning (embedCanonical c1)
  { rawWire                 := encodeWire rawMeaningWireCodec rawTerm
    canonicalWire           := encodeWire canonicalMeaningWireCodec c1
    idempotentCanonicalWire := encodeWire canonicalMeaningWireCodec c2 }

/-! ### 2. `PO-DIFF-03b` — Multi-Byte UTF-8 Exclusion & Upstream Domain Boundary Integrity -/

/--
  **`PO-DIFF-03b` (`multibyte_utf8_excluded_and_upstream_failClosed`)**:
  1. Any byte `b ∈ rawBytes` with `0x80 ≤ b.toNat` (every multi-byte UTF-8 lead/continuation byte,
     where raw byte count diverges from Unicode codepoint count) falsifies `StrictAsciiDomainSupported rawBytes`.
  2. Whenever `parseAllBounded` rejects `rawBytes` with `.outOfDomain d` or `.resourceOverflow r`,
     `certifySemanticConsensus` deterministically returns `.upstreamRejected` and never emits `.consensus`.
-/
theorem multibyte_utf8_excluded_and_upstream_failClosed :
    (∀ (bs : List UInt8) (b : UInt8),
       b ∈ bs → 0x80 ≤ b.toNat → ¬ StrictAsciiDomainSupported bs) ∧
    (∀ (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
       (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) (d : OutOfDomainDiag),
       parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d →
       certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected (.outOfDomain d)) := by
  refine ⟨?_, ?_⟩
  · intro bs b hmem hge hdom
    rcases hdom with ⟨_, hall⟩
    have hb : IsPrintableAsciiByte b := hall b hmem
    rcases b with ⟨⟨v, _⟩⟩
    rcases hb with ⟨_, hhi⟩
    have hv_hi : v ≤ 0x7E := hhi
    dsimp only [UInt8.toNat, BitVec.toNat] at hge
    omega
  · intro cat numCfg env budget rawBytes d hout
    exact (certifySemanticConsensus_upstream_failClosed cat numCfg env budget rawBytes).1 d hout

/-! ### 3. `PO-DIFF-04` — Extraction Result Fidelity Across Normal & Injected Malformed Trees -/

/--
  **`PO-DIFF-04` (`extraction_result_wire_fidelity`)**:
  1. Single-tree extraction `extractRawMeaning env t` (`Except ExtractionFailureDiag RawSemanticTerm`)
     roundtrips losslessly through `singleExtractionResWireCodec`, never conflating `.ok m` and `.error d`.
  2. `ForestExtractionError` (`failedTree` + `diag`) roundtrips losslessly through `forestExtractionErrWireCodec`.
  3. Whenever `evalForestPure env T = .semanticExtractionFailure T' err`, `T' = T`, `err.failedTree ∈ T`,
     `extractRawMeaning env err.failedTree = .error err.diag`, and `decodeWire outcomeWireCodec` recovers
     the exact `.semanticExtractionFailure T err` structure!
-/
theorem extraction_result_wire_fidelity :
    (∀ (env : ScopeEnv) (t : ConcreteParseTree),
       decodeWire singleExtractionResWireCodec
         (encodeWire singleExtractionResWireCodec (extractRawMeaning env t)) =
         .ok (extractRawMeaning env t)) ∧
    (∀ (d : ExtractionFailureDiag) (m : RawSemanticTerm),
       encodeWire singleExtractionResWireCodec (.error d) ≠
         encodeWire singleExtractionResWireCodec (.ok m)) ∧
    (∀ (err : ForestExtractionError),
       decodeWire forestExtractionErrWireCodec (encodeWire forestExtractionErrWireCodec err) = .ok err) ∧
    (∀ (env : ScopeEnv) (T T' : List ConcreteParseTree) (err : ForestExtractionError),
       evalForestPure env T = .semanticExtractionFailure T' err →
       T' = T ∧
       err.failedTree ∈ T ∧
       extractRawMeaning env err.failedTree = .error err.diag ∧
       decodeWire outcomeWireCodec
         (encodeWire outcomeWireCodec (.semanticExtractionFailure T' err)) =
         .ok (.semanticExtractionFailure T err)) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro env t
    exact encodeWire_decodeWire_roundtrip singleExtractionResWireCodec (extractRawMeaning env t)
  · intro d m heq
    have h := encodeWire_injective singleExtractionResWireCodec heq
    contradiction
  · intro err
    exact encodeWire_decodeWire_roundtrip forestExtractionErrWireCodec err
  · intro env T T' err heval
    cases T with
    | nil => simp [evalForestPure] at heval
    | cons hd tl =>
      unfold evalForestPure at heval
      cases hext : extractAllMeanings env (hd :: tl) with
      | error e0 =>
        rw [hext] at heval
        injection heval with hT herr
        subst T'; subst e0
        have ⟨hmem, hfail⟩ := extractAllMeanings_err_sound hext
        exact ⟨rfl, hmem, hfail, encodeWire_decodeWire_roundtrip outcomeWireCodec _⟩
      | ok pairs =>
        rw [hext] at heval
        cases pairs with
        | nil => contradiction
        | cons p1 rest =>
          rcases p1 with ⟨t1, m1⟩
          dsimp only at heval
          cases hdiv : findDivergentReading t1 m1 (normalizeMeaning m1) rest with
          | some _ => rw [hdiv] at heval; contradiction
          | none =>
            rw [hdiv] at heval
            dsimp only at heval
            cases htrap : findForestTrapViolation (hd :: tl) <;> rw [htrap] at heval <;> contradiction

/-! ### 4. `PO-DIFF-05` — Canonical Meaning Fidelity & `SemEq` Exact Correspondence -/

/--
  **`PO-DIFF-05` (`canonical_meaning_wire_fidelity`)**:
  1. Every `c : CanonicalMeaning` roundtrips losslessly (`decodeWire ... = .ok c`).
  2. Wire equality is equivalent to structural `CanonicalMeaning` equality (`encodeWire c₁ = encodeWire c₂ ↔ c₁ = c₂`).
  3. For all `m₁, m₂ : RawSemanticTerm`, canonical wire equality of `normalizeMeaning m₁` and
     `normalizeMeaning m₂` holds **if and only if** `SemEq m₁ m₂` (`m₁ ∼_sem m₂`), AND
     `(observeSemanticInject m₁).idempotentCanonicalWire = (observeSemanticInject m₁).canonicalWire`!
-/
theorem canonical_meaning_wire_fidelity :
    (∀ c : CanonicalMeaning,
       decodeWire canonicalMeaningWireCodec (encodeWire canonicalMeaningWireCodec c) = .ok c) ∧
    (∀ c₁ c₂ : CanonicalMeaning,
       encodeWire canonicalMeaningWireCodec c₁ = encodeWire canonicalMeaningWireCodec c₂ ↔ c₁ = c₂) ∧
    (∀ m₁ m₂ : RawSemanticTerm,
       encodeWire canonicalMeaningWireCodec (normalizeMeaning m₁) =
         encodeWire canonicalMeaningWireCodec (normalizeMeaning m₂) ↔ SemEq m₁ m₂) ∧
    (∀ m : RawSemanticTerm,
       (observeSemanticInject m).idempotentCanonicalWire = (observeSemanticInject m).canonicalWire) := by
  refine ⟨encodeWire_decodeWire_roundtrip canonicalMeaningWireCodec, ?_, ?_, ?_⟩
  · intro c₁ c₂
    exact ⟨encodeWire_injective canonicalMeaningWireCodec, fun h => by rw [h]⟩
  · intro m₁ m₂
    constructor
    · intro hwire
      have hnorm : normalizeMeaning m₁ = normalizeMeaning m₂ :=
        encodeWire_injective canonicalMeaningWireCodec hwire
      exact (semEq_iff_normalizeMeaning_eq m₁ m₂).mpr hnorm
    · intro hsem
      have hnorm : normalizeMeaning m₁ = normalizeMeaning m₂ :=
        (semEq_iff_normalizeMeaning_eq m₁ m₂).mp hsem
      rw [hnorm]
  · intro m
    unfold observeSemanticInject
    dsimp only
    have hidem : normalizeMeaning (embedCanonical (normalizeMeaning m)) = normalizeMeaning m :=
      normalizeMeaning_embed_id m
    rw [hidem]

/-! ### 5. Equational Bridge Lemmas Avoiding Redundant `ByteArray.IsValidUTF8` Unfolding in Kernel WHNF -/

theorem eqStrBool_encodeWire {α : Type} [DecidableEq α] (C : CanonicalWireCodec α) (x y : α) :
    eqStrBool (encodeWire C x) (encodeWire C y) = (x == y) := by
  by_cases h : x = y
  · subst h
    have ht : eqStrBool (encodeWire C x) (encodeWire C x) = true := (eqStrBool_iff _ _).mpr rfl
    simp [ht]
  · have hne : encodeWire C x ≠ encodeWire C y := fun he => h (encodeWire_injective C he)
    have hf : eqStrBool (encodeWire C x) (encodeWire C y) = false :=
      Bool.eq_false_iff.mpr (fun ht => hne ((eqStrBool_iff _ _).mp ht))
    have hbeq : (x == y) = false := beq_false_of_ne h
    rw [hf, hbeq]

theorem compareWirePayloads_encodeWire {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
      match grade with
      | .SPEC_UNDEFINED =>
        .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held"
      | _ =>
        if x == y then
          .MATCH_STRUCTURAL grade
        else
          let leanWire := encodeWire C x
          let oracleWire := encodeWire C y
          let lToks := match splitSemiChars leanWire.toList.length leanWire.toList with | .ok ts => ts | .error _ => []
          let oToks := match splitSemiChars oracleWire.toList.length oracleWire.toList with | .ok ts => ts | .error _ => []
          .MISMATCH_WITNESS stage (firstDivergentTokIdx 0 lToks oToks) leanWire oracleWire := by
  cases grade with
  | SPEC_UNDEFINED => rfl
  | SPEC_GROUNDED =>
    simp only [compareWirePayloads, encodeWire_decodeWire_roundtrip, eqStrBool_encodeWire]; rfl
  | MODEL_ASSUMPTION =>
    simp only [compareWirePayloads, encodeWire_decodeWire_roundtrip, eqStrBool_encodeWire]; rfl

theorem verifyDecodedOutcomeWire_encodeWire (targetCtx claimedCtx : ProvenanceContext)
    (out : SemanticNormOutcome) :
    verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx (encodeWire outcomeWireCodec out) =
      match verifyUntrustedConsensusClaim targetCtx { claimedCtx := claimedCtx, claimedOutcome := out } with
      | .error pe => .error (.inr pe)
      | .ok cert  => .ok cert := by
  unfold verifyDecodedOutcomeWireAgainstProvenance
  rw [encodeWire_decodeWire_roundtrip]
  rfl

theorem observeSurfaceE2E_outcomeWire (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).outcomeWire = encodeWire outcomeWireCodec (runP3COnContext ctx) := by
  unfold observeSurfaceE2E runP3COnContext certifySemanticConsensus
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;> rfl

theorem observeSurfaceE2E_parseStatus (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).parseStatus =
      match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
      | .outOfDomain _      => "OUT_OF_DOMAIN"
      | .resourceOverflow _ => "RESOURCE_OVERFLOW"
      | .enumerated _       => "ENUMERATED" := by
  unfold observeSurfaceE2E
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;> rfl

theorem observeSurfaceE2E_codepointLenOpt (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).codepointLenOpt =
      match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
      | .enumerated _ => some (decodeAsciiBytes ctx.rawBytes).toList.length
      | _             => none := by
  unfold observeSurfaceE2E
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;> rfl

theorem observeSurfaceE2E_extWires_length (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).perTreeExtractionWires.length =
      match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
      | .enumerated T => T.length
      | _             => 0 := by
  unfold observeSurfaceE2E
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;> simp

theorem observeSurfaceE2E_elim_forest {β : Type} (ctx : ProvenanceContext)
    (f : Nat → Except DecodeRejectDiag (List ConcreteParseTree) → Bool → β) (dflt : β) :
    (match (observeSurfaceE2E ctx).codepointLenOpt, (observeSurfaceE2E ctx).forestWireOpt with
     | some cpLen, some fWire =>
       f cpLen (decodeWire parseForestWireCodec fWire) (observeSurfaceE2E ctx).spansWithinBounds
     | _, _ => dflt) =
    (match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
     | .enumerated T =>
       let cpLen := (decodeAsciiBytes ctx.rawBytes).toList.length
       f cpLen (.ok T) (T.all (checkTreeSpansWithin 0 cpLen))
     | _ => dflt) := by
  unfold observeSurfaceE2E
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;>
    simp [encodeWire_decodeWire_roundtrip]

def extractSurfaceCanonList (ctx : ProvenanceContext) : List CanonicalMeaning :=
  match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | .enumerated T =>
    (T.map (extractRawMeaning ctx.scopeEnv)).foldr (fun r acc =>
      match r with
      | .ok m    => normalizeMeaning m :: acc
      | .error _ => acc) []
  | _ => []

theorem observeSurfaceE2E_perTreeCanonicalWires (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).perTreeCanonicalWires =
      (extractSurfaceCanonList ctx).map (encodeWire canonicalMeaningWireCodec) := by
  unfold observeSurfaceE2E extractSurfaceCanonList
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | outOfDomain _ => rfl
  | resourceOverflow _ => rfl
  | enumerated T =>
    dsimp only
    induction (T.map (extractRawMeaning ctx.scopeEnv)) with
    | nil => rfl
    | cons r rs ih =>
      cases r <;> simp [List.foldr, ih]

theorem elim_canon_wire_pair_cmp {β : Type} (xs ys : List CanonicalMeaning)
    (grade : OracleEpistemicGrade) (anc : String) (st : DiffStage)
    (k : DiffVerdict → β) (dflt : β) :
    (match xs.map (encodeWire canonicalMeaningWireCodec),
           ys.map (encodeWire canonicalMeaningWireCodec) with
     | [c1], [c2] => k (compareWirePayloads canonicalMeaningWireCodec grade anc st c1 c2)
     | _, _ => dflt) =
    (match xs, ys with
     | [m1], [m2] =>
       k (compareWirePayloads canonicalMeaningWireCodec grade anc st
            (encodeWire canonicalMeaningWireCodec m1)
            (encodeWire canonicalMeaningWireCodec m2))
     | _, _ => dflt) := by
  cases xs with
  | nil => rfl
  | cons x1 xs' =>
    cases xs' with
    | cons _ _ => rfl
    | nil =>
      cases ys with
      | nil => rfl
      | cons y1 ys' =>
        cases ys' <;> rfl

/-! ### 6. `Gate OPT-A` — Verdict Head Projection (`F-DIFF-OPT-01`) & Full Witness Fidelity (`F-DIFF-OPT-02`) -/

/--
  Finite structural projection of `DiffVerdict` retaining verdict kind, `OracleEpistemicGrade`,
  and `DiffStage` while abstracting away multi-kilobyte wire witness strings during kernel proving.
  (Explicitly named a projection/abstraction — NOT a quotient type — per `Gate OPT-A`.)
-/
inductive DiffVerdictHead where
  | matchStructural (grade : OracleEpistemicGrade)
  | mismatchWitness (stage : DiffStage)
  | oracleFailure
  | specificationHeld
  | resourceHeld
  deriving DecidableEq, Repr

def verdictHead : DiffVerdict → DiffVerdictHead
  | .MATCH_STRUCTURAL g        => .matchStructural g
  | .MISMATCH_WITNESS st _ _ _ => .mismatchWitness st
  | .ORACLE_FAILURE _          => .oracleFailure
  | .SPECIFICATION_HELD _ _    => .specificationHeld
  | .RESOURCE_HELD _           => .resourceHeld

/--
  **`F-DIFF-OPT-01a` (`verdictHead_compare_encode`)**:
  Computable kernel reduction equation for `verdictHead (compareWirePayloads ...)`: eliminates
  wire-string construction from the right-hand side while preserving exact branch semantics.
-/
theorem verdictHead_compare_encode {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _               => if x == y then .matchStructural grade else .mismatchWitness stage := by
  rw [compareWirePayloads_encodeWire]
  cases grade with
  | SPEC_UNDEFINED => rfl
  | SPEC_GROUNDED =>
    by_cases h : (x == y) = true <;> simp [h, verdictHead]
  | MODEL_ASSUMPTION =>
    by_cases h : (x == y) = true <;> simp [h, verdictHead]

/--
  **`F-DIFF-OPT-01b` (`verdictHead_branch_preservation_iff`)**:
  Proves that `verdictHead` preserves all three canonical comparator branches (`SPEC_UNDEFINED`,
  `MATCH_STRUCTURAL`, and `MISMATCH_WITNESS`) without conflating any branch or grade.
-/
theorem verdictHead_branch_preservation_iff {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    ((verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
        .specificationHeld ↔
        grade = .SPEC_UNDEFINED ∧
        compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
          .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held") ∧
     (∀ g,
        verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
          .matchStructural g ↔
          grade ≠ .SPEC_UNDEFINED ∧ g = grade ∧ x = y ∧
          compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
            .MATCH_STRUCTURAL g) ∧
     (∀ st,
        verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
          .mismatchWitness st ↔
          grade ≠ .SPEC_UNDEFINED ∧ st = stage ∧ x ≠ y)) := by
  refine ⟨?_, ?_, ?_⟩
  · rw [verdictHead_compare_encode]
    cases grade with
    | SPEC_UNDEFINED =>
      simp [compareWirePayloads]
    | SPEC_GROUNDED =>
      by_cases h : (x == y) = true <;> simp [h]
    | MODEL_ASSUMPTION =>
      by_cases h : (x == y) = true <;> simp [h]
  · intro g
    rw [verdictHead_compare_encode]
    have ⟨hm, _⟩ := compareWirePayloads_sound_and_complete C grade r0Anchor stage x y
    cases grade with
    | SPEC_UNDEFINED => simp
    | SPEC_GROUNDED =>
      by_cases hxy : x = y
      · subst hxy
        simp only [beq_self_eq_true, ↓reduceIte, DiffVerdictHead.matchStructural.injEq, ne_eq,
                   reduceCtorEq, not_false_eq_true, true_and]
        constructor
        · rintro rfl
          exact ⟨rfl, (hm .SPEC_GROUNDED).mpr ⟨by decide, rfl, rfl⟩⟩
        · rintro ⟨hg, _⟩; exact hg.symm
      · have hbeq : (x == y) = false := beq_false_of_ne hxy
        simp [hbeq, hxy]
    | MODEL_ASSUMPTION =>
      by_cases hxy : x = y
      · subst hxy
        simp only [beq_self_eq_true, ↓reduceIte, DiffVerdictHead.matchStructural.injEq, ne_eq,
                   reduceCtorEq, not_false_eq_true, true_and]
        constructor
        · rintro rfl
          exact ⟨rfl, (hm .MODEL_ASSUMPTION).mpr ⟨by decide, rfl, rfl⟩⟩
        · rintro ⟨hg, _⟩; exact hg.symm
      · have hbeq : (x == y) = false := beq_false_of_ne hxy
        simp [hbeq, hxy]
  · intro st
    rw [verdictHead_compare_encode]
    cases grade with
    | SPEC_UNDEFINED => simp
    | SPEC_GROUNDED =>
      by_cases hxy : x = y
      · subst hxy; simp
      · have hbeq : (x == y) = false := beq_false_of_ne hxy
        simp [hbeq, hxy, eq_comm]
    | MODEL_ASSUMPTION =>
      by_cases hxy : x = y
      · subst hxy; simp
      · have hbeq : (x == y) = false := beq_false_of_ne hxy
        simp [hbeq, hxy, eq_comm]

private theorem splitSemiChars_encodeWire_tokens {α : Type} (C : CanonicalWireCodec α) (x : α) :
    splitSemiChars (encodeWire C x).toList.length (encodeWire C x).toList =
      .ok ("DIFFV1" :: C.typeTag :: C.encToks x) := by
  unfold encodeWire
  rw [String.toList_ofList]
  have hall_valid : ∀ t ∈ ("DIFFV1" :: C.typeTag :: C.encToks x), ValidToken t := by
    intro t ht
    rcases List.mem_cons.mp ht with rfl | ht2
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp ht2 with rfl | ht3
      · exact C.hTagValid
      · exact (C.hToksValid x).2 t ht3
  exact splitSemiChars_joinSemiChars _ _
    (joinSemiChars_length_ge _)
    (fun t ht => (hall_valid t ht).1)
    (fun t ht => (hall_valid t ht).2)

/--
  **`F-DIFF-OPT-02` (`compareWirePayloads_mismatch_witness_fidelity`)**:
  Separate witness-fidelity theorem proving that whenever `verdictHead` observes `.mismatchWitness st`,
  the unprojected `compareWirePayloads` retains:
    1. Exact pinpoint token-divergence locus `firstDivergentTokIdx` over the canonical token streams,
    2. Intact `leanWire = encodeWire C x` and `oracleWire = encodeWire C y` with `encodeWire C x ≠ encodeWire C y`,
    3. Lossless roundtrip recovery `decodeWire C leanWire = .ok x` and `decodeWire C oracleWire = .ok y`.
-/
theorem compareWirePayloads_mismatch_witness_fidelity {α : Type} [DecidableEq α]
    (C : CanonicalWireCodec α) (grade : OracleEpistemicGrade) (r0Anchor : String)
    (stage st : DiffStage) (x y : α)
    (hHead : verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
               .mismatchWitness st) :
    st = stage ∧
    grade ≠ .SPEC_UNDEFINED ∧
    x ≠ y ∧
    encodeWire C x ≠ encodeWire C y ∧
    compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
      .MISMATCH_WITNESS stage
        (firstDivergentTokIdx 0 ("DIFFV1" :: C.typeTag :: C.encToks x) ("DIFFV1" :: C.typeTag :: C.encToks y))
        (encodeWire C x) (encodeWire C y) ∧
    decodeWire C (encodeWire C x) = .ok x ∧
    decodeWire C (encodeWire C y) = .ok y := by
  have ⟨hg, hst, hne⟩ := ((verdictHead_branch_preservation_iff C grade r0Anchor stage x y).2.2 st).mp hHead
  have hne_wire : encodeWire C x ≠ encodeWire C y := fun hw => hne (encodeWire_injective C hw)
  have hbeq : (x == y) = false := beq_false_of_ne hne
  have hcmp :
      compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
        .MISMATCH_WITNESS stage
          (firstDivergentTokIdx 0 ("DIFFV1" :: C.typeTag :: C.encToks x) ("DIFFV1" :: C.typeTag :: C.encToks y))
          (encodeWire C x) (encodeWire C y) := by
    rw [compareWirePayloads_encodeWire]
    cases grade with
    | SPEC_UNDEFINED => exact False.elim (hg rfl)
    | SPEC_GROUNDED =>
      simp only [hbeq, Bool.false_eq_true, ↓reduceIte,
                 splitSemiChars_encodeWire_tokens C x, splitSemiChars_encodeWire_tokens C y]
    | MODEL_ASSUMPTION =>
      simp only [hbeq, Bool.false_eq_true, ↓reduceIte,
                 splitSemiChars_encodeWire_tokens C x, splitSemiChars_encodeWire_tokens C y]
  exact ⟨hst, hg, hne, hne_wire, hcmp,
         encodeWire_decodeWire_roundtrip C x,
         encodeWire_decodeWire_roundtrip C y⟩

theorem observeSurfaceE2E_isResourceOverflow (ctx : ProvenanceContext) :
    eqStrBool (observeSurfaceE2E ctx).parseStatus "RESOURCE_OVERFLOW" =
      match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
      | .resourceOverflow _ => true
      | _                   => false := by
  rw [observeSurfaceE2E_parseStatus]
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;>
    (dsimp only; decide)

theorem verifyDecodedOutcomeWire_encodeWire_proj (targetCtx claimedCtx : ProvenanceContext)
    (out : SemanticNormOutcome) :
    (verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx (encodeWire outcomeWireCodec out)).map
        (fun c => (c.trees, c.canonical)) =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := out } with
      | .error pe => .error (.inr pe)
      | .ok pair  => .ok pair := by
  rw [verifyDecodedOutcomeWire_encodeWire, ← verifyUntrustedConsensusClaim_proj_eq]
  cases verifyUntrustedConsensusClaim targetCtx { claimedCtx := claimedCtx, claimedOutcome := out } <;> rfl

/-! ### 7. Universal `ValidParse_GFrozen` Span Integrity & `Gate OPT-C` Surface Bridge Lemmas -/

mutual
  private theorem validParseSegs_spansWithin
      {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {syms : List BNFSymbol}
      (args : List ConcreteParseArg)
      {slots : List (BNFSlotTag × String)} {sums : List ParseSummary}
      (parentSpan : CodepointSpan)
      (hStart : parentSpan.startCp ≤ cursor)
      (hEnd : endPos = parentSpan.endCp)
      (h : ValidParseSegs cat numCfg env Y loc cursor syms args endPos slots sums) :
      cursor ≤ endPos ∧ checkArgSpansWithin parentSpan args = true := by
    match syms, args with
    | [], [] =>
      rcases h with ⟨_, rfl, _, _⟩
      exact ⟨Nat.le_refl _, rfl⟩
    | .term _ :: restSyms, .litTok _ sp :: restArgs =>
      rcases h with ⟨_, hspStart, hmatch, hrest⟩
      have hspLe : sp.startCp ≤ sp.endCp := by
        have hlen := hmatch.1; omega
      have ⟨hrestLe, hrestOk⟩ :=
        validParseSegs_spansWithin restArgs parentSpan (by omega) hEnd hrest
      refine ⟨by omega, ?_⟩
      simp only [checkArgSpansWithin, Bool.and_eq_true, decide_eq_true_eq]
      exact ⟨⟨⟨by omega, hspLe⟩, by omega⟩, hrestOk⟩
    | .lexSlot _ _ :: restSyms, .slotTok _ _ _ _ sp :: restArgs =>
      rcases h with ⟨_, _, _, hspStart, hmatch, _, _, hrest⟩
      have hspLe : sp.startCp ≤ sp.endCp := by
        have hlen := hmatch.1; omega
      have ⟨hrestLe, hrestOk⟩ :=
        validParseSegs_spansWithin restArgs parentSpan (by omega) hEnd hrest
      refine ⟨by omega, ?_⟩
      simp only [checkArgSpansWithin, Bool.and_eq_true, decide_eq_true_eq]
      exact ⟨⟨⟨by omega, hspLe⟩, by omega⟩, hrestOk⟩
    | .nonterm _ _ :: restSyms, .childSub sub :: restArgs =>
      rcases h with ⟨_, _, hsubStart, hnode, _, hrest⟩
      have ⟨hsubLe, hsubArgs⟩ := validParseNode_spansWithin sub hnode
      have ⟨hrestLe, hrestOk⟩ :=
        validParseSegs_spansWithin restArgs parentSpan (by omega) hEnd hrest
      refine ⟨by omega, ?_⟩
      cases sub with
      | mkTree _ _ _ subSp subArgs =>
        dsimp only [ConcreteParseTree.span] at hsubStart hsubLe hsubArgs hrestLe
        simp only [checkArgSpansWithin, checkTreeSpansWithin, Bool.and_eq_true, decide_eq_true_eq]
        exact ⟨⟨⟨⟨by omega, hsubLe⟩, by omega⟩, hsubArgs⟩, hrestOk⟩

  private theorem validParseNode_spansWithin
      {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {nt : BNFNonterm}
      (tree : ConcreteParseTree) {sum : ParseSummary}
      (h : ValidParseNode cat numCfg env Y loc nt tree sum) :
      tree.span.startCp ≤ tree.span.endCp ∧
      match tree with
      | .mkTree _ _ _ sp args => checkArgSpansWithin sp args = true := by
    cases tree with
    | mkTree p alt loc' sp args =>
      rcases h with ⟨_, _, _, _, _, _, hsegs, _, _⟩
      have ⟨hle, hok⟩ := validParseSegs_spansWithin args sp (Nat.le_refl _) rfl hsegs
      exact ⟨hle, hok⟩
end

/--
  **Universal Span Integrity Theorem (`validParse_GFrozen_spansWithin`)**:
  Every parse tree `tree` satisfying `ValidParse_GFrozen` has root span `⟨0, rawBytes.length⟩`
  and satisfies `checkTreeSpansWithin 0 rawBytes.length tree = true`.
-/
theorem validParse_GFrozen_spansWithin
    {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {env : ScopeEnv} {rawBytes : List UInt8} {tree : ConcreteParseTree}
    (h : ValidParse_GFrozen cat numCfg env rawBytes tree) :
    tree.span = ⟨0, rawBytes.length⟩ ∧
    checkTreeSpansWithin 0 rawBytes.length tree = true := by
  rcases h with ⟨hdom, hroot, sum, hnode⟩
  have hlen : (decodeAsciiBytes rawBytes).toList.length = rawBytes.length :=
    (strictAscii_byte_eq_codepoint_length rawBytes hdom).1
  rw [hlen] at hroot
  have ⟨hle, hargs⟩ := validParseNode_spansWithin tree hnode
  refine ⟨hroot, ?_⟩
  cases tree with
  | mkTree p alt loc sp args =>
    dsimp only [ConcreteParseTree.span] at hroot hle hargs
    subst hroot
    simp only [checkTreeSpansWithin, Bool.and_eq_true, decide_eq_true_eq]
    exact ⟨⟨⟨Nat.zero_le _, Nat.zero_le _⟩, Nat.le_refl _⟩, hargs⟩

def checkSurfaceRootSpanWire (ctx : ProvenanceContext) : Bool :=
  let tr := observeSurfaceE2E ctx
  match tr.codepointLenOpt, tr.forestWireOpt with
  | some cpLen, some fWire =>
    match decodeWire parseForestWireCodec fWire with
    | .ok [ConcreteParseTree.mkTree _ _ _ rootSp _] =>
      tr.spansWithinBounds && (cpLen == ctx.rawBytes.length) && (rootSp == ⟨0, cpLen⟩)
    | _ => false
  | _, _ => false

theorem evalForestPure_trees_eq {env : ScopeEnv} {T T' : List ConcreteParseTree} {c : CanonicalMeaning}
    (h : evalForestPure env T = .consensus T' c) :
    T' = T := by
  unfold evalForestPure at h
  cases T with
  | nil => contradiction
  | cons t0 ts =>
    dsimp only at h
    cases hex : extractAllMeanings env (t0 :: ts) with
    | error _ => rw [hex] at h; contradiction
    | ok pairs =>
      rw [hex] at h
      cases pairs with
      | nil => contradiction
      | cons p1 rest =>
        dsimp only at h
        cases hdiv : findDivergentReading p1.1 p1.2 (normalizeMeaning p1.2) rest with
        | some _ => rw [hdiv] at h; contradiction
        | none =>
          rw [hdiv] at h
          cases htrap : findForestTrapViolation (t0 :: ts) with
          | some _ => rw [htrap] at h; contradiction
          | none =>
            rw [htrap] at h
            injection h with hT _
            exact hT.symm

theorem evalForestPure_ambiguous_trees_eq {env : ScopeEnv} {T T' : List ConcreteParseTree}
    {w : AmbiguityRefutationWitness}
    (h : evalForestPure env T = .ambiguousReadings T' w) :
    T' = T := by
  unfold evalForestPure at h
  cases T with
  | nil => contradiction
  | cons t0 ts =>
    dsimp only at h
    cases hex : extractAllMeanings env (t0 :: ts) with
    | error _ => rw [hex] at h; contradiction
    | ok pairs =>
      rw [hex] at h
      cases pairs with
      | nil => contradiction
      | cons p1 rest =>
        dsimp only at h
        cases hdiv : findDivergentReading p1.1 p1.2 (normalizeMeaning p1.2) rest with
        | none =>
          rw [hdiv] at h
          cases htrap : findForestTrapViolation (t0 :: ts) with
          | some _ => rw [htrap] at h; contradiction
          | none => rw [htrap] at h; contradiction
        | some w' =>
          rw [hdiv] at h
          injection h with hT _
          exact hT.symm

theorem checkSurfaceRootSpanWire_of_single_consensus (ctx : ProvenanceContext)
    (expected : CanonicalMeaning)
    (h : PneumaOmega.P3C.Counterexamples.isConsensusSingleEq (runP3COnContext ctx) expected = true) :
    checkSurfaceRootSpanWire ctx = true := by
  unfold checkSurfaceRootSpanWire observeSurfaceE2E
  unfold runP3COnContext certifySemanticConsensus at h
  cases hp : parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | outOfDomain d => rw [hp] at h; contradiction
  | resourceOverflow r => rw [hp] at h; contradiction
  | enumerated T =>
    rw [hp] at h
    dsimp only at h ⊢
    rw [encodeWire_decodeWire_roundtrip]
    have hsc := parseAllBounded_enumerated_sound_and_complete
      ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes T hp
    have hcp : (decodeAsciiBytes ctx.rawBytes).toList.length = ctx.rawBytes.length :=
      (strictAscii_byte_eq_codepoint_length ctx.rawBytes hsc.1).1
    rw [hcp]
    cases hev : evalForestPure ctx.scopeEnv T with
    | ambiguousReadings _ _ => rw [hev] at h; contradiction
    | semanticExtractionFailure _ _ => rw [hev] at h; contradiction
    | trapPolicyRejected _ _ _ => rw [hev] at h; contradiction
    | upstreamRejected _ => rw [hev] at h; contradiction
    | consensus T' c =>
      rw [hev] at h
      unfold PneumaOmega.P3C.Counterexamples.isConsensusSingleEq at h
      cases T' with
      | nil => contradiction
      | cons t1 ts =>
        cases ts with
        | cons _ _ => contradiction
        | nil =>
          have hT : [t1] = T := evalForestPure_trees_eq hev
          subst hT
          have hv : ValidParse_GFrozen ctx.catalog ctx.numCfg ctx.scopeEnv ctx.rawBytes t1 :=
            (hsc.2.2.2.2 t1).mp (List.Mem.head [])
          have ⟨hroot, hwithin⟩ := validParse_GFrozen_spansWithin hv
          cases t1 with
          | mkTree p alt loc rootSp args =>
            dsimp only [ConcreteParseTree.span] at hroot
            subst hroot
            simp [List.all, hwithin]

def checkSurfaceDualAmbiguousWire (ctx : ProvenanceContext) : Bool :=
  let tr := observeSurfaceE2E ctx
  match decodeWire outcomeWireCodec tr.outcomeWire with
  | .ok (.ambiguousReadings [t1, t2] w) =>
    (tr.perTreeExtractionWires.length == 2) && (!parseTreeEqBool t1 t2) && w.isDivergent
  | _ => false

theorem checkSurfaceDualAmbiguousWire_eq_isAmbiguousDual (ctx : ProvenanceContext) :
    checkSurfaceDualAmbiguousWire ctx =
      PneumaOmega.P3C.Counterexamples.isAmbiguousDual (runP3COnContext ctx) := by
  dsimp only [checkSurfaceDualAmbiguousWire]
  rw [observeSurfaceE2E_outcomeWire, encodeWire_decodeWire_roundtrip, observeSurfaceE2E_extWires_length]
  unfold runP3COnContext certifySemanticConsensus PneumaOmega.P3C.Counterexamples.isAmbiguousDual
  cases hp : parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | outOfDomain _ => rfl
  | resourceOverflow _ => rfl
  | enumerated T =>
    dsimp only
    cases hev : evalForestPure ctx.scopeEnv T with
    | consensus _ _ => rfl
    | semanticExtractionFailure _ _ => rfl
    | trapPolicyRejected _ _ _ => rfl
    | upstreamRejected _ => rfl
    | ambiguousReadings T' w =>
      have hT : T' = T := evalForestPure_ambiguous_trees_eq hev
      subst T'
      cases T with
      | nil => rfl
      | cons t1 ts =>
        cases ts with
        | nil => rfl
        | cons t2 ts2 =>
          cases ts2 <;> simp

def compareSingleSurfaceCanonsWire (ctx₁ ctx₂ : ProvenanceContext)
    (grade : OracleEpistemicGrade) (anc : String) (st : DiffStage) : Option DiffVerdictHead :=
  let tr1 := observeSurfaceE2E ctx₁
  let tr2 := observeSurfaceE2E ctx₂
  match tr1.perTreeCanonicalWires, tr2.perTreeCanonicalWires with
  | [c1], [c2] => some (verdictHead (compareWirePayloads canonicalMeaningWireCodec grade anc st c1 c2))
  | _, _ => none

theorem extractSurfaceCanonList_of_single_consensus (ctx : ProvenanceContext)
    (expected : CanonicalMeaning)
    (h : PneumaOmega.P3C.Counterexamples.isConsensusSingleEq (runP3COnContext ctx) expected = true) :
    extractSurfaceCanonList ctx = [expected] := by
  unfold extractSurfaceCanonList
  unfold runP3COnContext certifySemanticConsensus at h
  cases hp : parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | outOfDomain _ => rw [hp] at h; contradiction
  | resourceOverflow _ => rw [hp] at h; contradiction
  | enumerated T =>
    rw [hp] at h
    dsimp only at h ⊢
    cases hev : evalForestPure ctx.scopeEnv T with
    | ambiguousReadings _ _ => rw [hev] at h; contradiction
    | semanticExtractionFailure _ _ => rw [hev] at h; contradiction
    | trapPolicyRejected _ _ _ => rw [hev] at h; contradiction
    | upstreamRejected _ => rw [hev] at h; contradiction
    | consensus T' c =>
      rw [hev] at h
      unfold PneumaOmega.P3C.Counterexamples.isConsensusSingleEq at h
      cases T' with
      | nil => contradiction
      | cons t1 ts =>
        cases ts with
        | cons _ _ => contradiction
        | nil =>
          have hc : c = expected := (canonicalMeaningEqBool_iff c expected).mp h
          have hT : [t1] = T := evalForestPure_trees_eq hev
          subst hT; subst hc
          unfold evalForestPure extractAllMeanings at hev
          dsimp only at hev
          cases hex : extractRawMeaning ctx.scopeEnv t1 with
          | error _ => rw [hex] at hev; contradiction
          | ok m1 =>
            rw [hex] at hev
            dsimp only [findDivergentReading] at hev
            cases htrap : findForestTrapViolation [t1] with
            | some _ => rw [htrap] at hev; contradiction
            | none =>
              rw [htrap] at hev
              injection hev with _ hm
              simp [hex, hm]

theorem verdictHead_compare_encode_self {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x : α) :
    verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C x)) =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _               => .matchStructural grade := by
  rw [verdictHead_compare_encode]
  cases grade <;> simp

theorem verdictHead_compare_encode_of_ne {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) {x y : α}
    (hg : grade ≠ .SPEC_UNDEFINED) (hne : x ≠ y) :
    verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
      .mismatchWitness stage := by
  exact ((verdictHead_branch_preservation_iff C grade r0Anchor stage x y).2.2 stage).mpr ⟨hg, rfl, hne⟩

theorem verdictHead_compare_canon (grade : OracleEpistemicGrade) (r0Anchor : String)
    (stage : DiffStage) (x y : CanonicalMeaning) :
    verdictHead (compareWirePayloads canonicalMeaningWireCodec grade r0Anchor stage
      (encodeWire canonicalMeaningWireCodec x) (encodeWire canonicalMeaningWireCodec y)) =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _ => if canonicalMeaningEqBool x y then .matchStructural grade else .mismatchWitness stage := by
  have hb : (x == y) = canonicalMeaningEqBool x y :=
    Bool.eq_iff_iff.mpr (by rw [beq_iff_eq, canonicalMeaningEqBool_iff])
  rw [verdictHead_compare_encode]
  cases grade <;> simp [hb]

def eqExtractionDiagBool : ExtractionFailureDiag → ExtractionFailureDiag → Bool
  | .malformedParseNode p1 d1, .malformedParseNode p2 d2 => (p1 == p2) && eqStrBool d1 d2
  | .unsupportedReadingAlt p1 a1, .unsupportedReadingAlt p2 a2 => (p1 == p2) && (a1 == a2)
  | .mismatchedScopeCohort f1 e1, .mismatchedScopeCohort f2 e2 => eqStrBool f1 f2 && eqStrBool e1 e2
  | .unresolvedAnaphoricScope f1 e1, .unresolvedAnaphoricScope f2 e2 => eqStrBool f1 f2 && eqStrBool e1 e2
  | .invalidContrastiveAnchor p1, .invalidContrastiveAnchor p2 => p1 == p2
  | _, _ => false

theorem eqExtractionDiagBool_iff (d₁ d₂ : ExtractionFailureDiag) :
    eqExtractionDiagBool d₁ d₂ = true ↔ d₁ = d₂ := by
  cases d₁ <;> cases d₂ <;>
    simp [eqExtractionDiagBool, Bool.and_eq_true, beq_iff_eq, eqStrBool_iff]

theorem compareSingleSurfaceCanonsWire_of_single_consensus
    (ctx₁ ctx₂ : ProvenanceContext) (c₁ c₂ : CanonicalMeaning)
    (grade : OracleEpistemicGrade) (anc : String) (st : DiffStage)
    (h₁ : PneumaOmega.P3C.Counterexamples.isConsensusSingleEq (runP3COnContext ctx₁) c₁ = true)
    (h₂ : PneumaOmega.P3C.Counterexamples.isConsensusSingleEq (runP3COnContext ctx₂) c₂ = true) :
    compareSingleSurfaceCanonsWire ctx₁ ctx₂ grade anc st =
      some (match grade with
            | .SPEC_UNDEFINED => .specificationHeld
            | _ => if canonicalMeaningEqBool c₁ c₂ then .matchStructural grade else .mismatchWitness st) := by
  dsimp only [compareSingleSurfaceCanonsWire]
  rw [observeSurfaceE2E_perTreeCanonicalWires ctx₁,
      observeSurfaceE2E_perTreeCanonicalWires ctx₂,
      extractSurfaceCanonList_of_single_consensus ctx₁ c₁ h₁,
      extractSurfaceCanonList_of_single_consensus ctx₂ c₂ h₂]
  simp only [List.map, verdictHead_compare_canon]

/-! ### 8. `let`-Free Named Wire Observation Combinators (`Gate OPT-A/B`: Zero Kernel `dsimp` Overhead) -/

def decodeSurfaceOutcomeWire (ctx : ProvenanceContext) : Except DecodeRejectDiag SemanticNormOutcome :=
  decodeWire outcomeWireCodec (observeSurfaceE2E ctx).outcomeWire

theorem decodeSurfaceOutcomeWire_eq (ctx : ProvenanceContext) :
    decodeSurfaceOutcomeWire ctx = .ok (runP3COnContext ctx) := by
  unfold decodeSurfaceOutcomeWire
  rw [observeSurfaceE2E_outcomeWire, encodeWire_decodeWire_roundtrip]

def decodeForestOutcomeWire (env : ScopeEnv) (T : List ConcreteParseTree) :
    Except DecodeRejectDiag SemanticNormOutcome :=
  decodeWire outcomeWireCodec (observeForestInject env T).forestOutcomeWire

theorem decodeForestOutcomeWire_eq (env : ScopeEnv) (T : List ConcreteParseTree) :
    decodeForestOutcomeWire env T = .ok (evalForestPure env T) :=
  encodeWire_decodeWire_roundtrip outcomeWireCodec (evalForestPure env T)

def decodeSemanticInjectCanonWire (m : RawSemanticTerm) :
    Except DecodeRejectDiag CanonicalMeaning :=
  decodeWire canonicalMeaningWireCodec (observeSemanticInject m).canonicalWire

theorem decodeSemanticInjectCanonWire_eq (m : RawSemanticTerm) :
    decodeSemanticInjectCanonWire m = .ok (normalizeMeaning m) :=
  encodeWire_decodeWire_roundtrip canonicalMeaningWireCodec (normalizeMeaning m)

def checkSemanticInjectIdempWire (m : RawSemanticTerm) : Bool :=
  eqStrBool (observeSemanticInject m).canonicalWire (observeSemanticInject m).idempotentCanonicalWire

theorem checkSemanticInjectIdempWire_eq_true (m : RawSemanticTerm) :
    checkSemanticInjectIdempWire m = true := by
  unfold checkSemanticInjectIdempWire
  rw [canonical_meaning_wire_fidelity.2.2.2 m]
  exact (eqStrBool_iff _ _).mpr rfl

def compareSemanticInjectCanonsWire (grade : OracleEpistemicGrade) (anc : String)
    (st : DiffStage) (m₁ m₂ : RawSemanticTerm) : DiffVerdictHead :=
  verdictHead (compareWirePayloads canonicalMeaningWireCodec grade anc st
    (observeSemanticInject m₁).canonicalWire
    (observeSemanticInject m₂).canonicalWire)

theorem compareSemanticInjectCanonsWire_eq (grade : OracleEpistemicGrade) (anc : String)
    (st : DiffStage) (m₁ m₂ : RawSemanticTerm) :
    compareSemanticInjectCanonsWire grade anc st m₁ m₂ =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _ =>
        if canonicalMeaningEqBool (normalizeMeaning m₁) (normalizeMeaning m₂) then
          .matchStructural grade
        else
          .mismatchWitness st :=
  verdictHead_compare_canon grade anc st (normalizeMeaning m₁) (normalizeMeaning m₂)

def compareCanonicalValuesWire (grade : OracleEpistemicGrade) (anc : String)
    (st : DiffStage) (c₁ c₂ : CanonicalMeaning) : DiffVerdictHead :=
  verdictHead (compareWirePayloads canonicalMeaningWireCodec grade anc st
    (encodeWire canonicalMeaningWireCodec c₁)
    (encodeWire canonicalMeaningWireCodec c₂))

theorem compareCanonicalValuesWire_eq (grade : OracleEpistemicGrade) (anc : String)
    (st : DiffStage) (c₁ c₂ : CanonicalMeaning) :
    compareCanonicalValuesWire grade anc st c₁ c₂ =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _ => if canonicalMeaningEqBool c₁ c₂ then .matchStructural grade else .mismatchWitness st :=
  verdictHead_compare_canon grade anc st c₁ c₂

def verifySurfaceWireReplayProj (targetCtx claimedCtx srcCtx : ProvenanceContext) :
    Except (Sum DecodeRejectDiag ProvenanceRejectReason) (List ConcreteParseTree × CanonicalMeaning) :=
  (verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx
    (observeSurfaceE2E srcCtx).outcomeWire).map (fun c => (c.trees, c.canonical))

theorem verifySurfaceWireReplayProj_eq (targetCtx claimedCtx srcCtx : ProvenanceContext) :
    verifySurfaceWireReplayProj targetCtx claimedCtx srcCtx =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := runP3COnContext srcCtx } with
      | .error pe => .error (.inr pe)
      | .ok pair  => .ok pair := by
  unfold verifySurfaceWireReplayProj
  rw [observeSurfaceE2E_outcomeWire, verifyDecodedOutcomeWire_encodeWire_proj]

def verifyForestWireReplayProj (targetCtx claimedCtx : ProvenanceContext)
    (env : ScopeEnv) (T : List ConcreteParseTree) :
    Except (Sum DecodeRejectDiag ProvenanceRejectReason) (List ConcreteParseTree × CanonicalMeaning) :=
  (verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx
    (observeForestInject env T).forestOutcomeWire).map (fun c => (c.trees, c.canonical))

theorem verifyForestWireReplayProj_eq (targetCtx claimedCtx : ProvenanceContext)
    (env : ScopeEnv) (T : List ConcreteParseTree) :
    verifyForestWireReplayProj targetCtx claimedCtx env T =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := evalForestPure env T } with
      | .error pe => .error (.inr pe)
      | .ok pair  => .ok pair :=
  verifyDecodedOutcomeWire_encodeWire_proj targetCtx claimedCtx (evalForestPure env T)

end PneumaOmega.P3C.DifferentialR1
````

### File 9: `03_counterexamples/P3CDifferentialAttacks.lean` (SHA-256: `C3D351827F9A31F964D788DEBE8AEB41AB5148D9FDAFDB54D6E29154C4D58975`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1
  Root export for `P3CDifferentialAttacks`
-/
import P3CDifferentialAttacks.OrthogonalAttackSuiteD01ToD12
````

### File 10: `03_counterexamples/P3CDifferentialAttacks/OrthogonalAttackSuiteD01ToD12.lean` (SHA-256: `CAF5C44E4879919842F595363093FE593D3764C8212FF6242525EF26C8623CE7`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate B`, `Gate D`, `Gate OPT-B`, `Gate OPT-C`)
  03_counterexamples/P3CDifferentialAttacks/OrthogonalAttackSuiteD01ToD12.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`,
                         zero `sorry`, zero `native_decide`, zero custom axioms)

  Implements the 28 symmetric `(PC, CE)` vectors (`14` pairs `D01` ~ `D14`) under:
    - `Gate OPT-A` (`verdictHead_compare_encode` / `verdictHead_compare_canon` + separate
                    `F-DIFF-OPT-02` full unprojected witness fidelity),
    - `Gate OPT-B` (`GateDVerdictTag` finite decision algebra preserving exact 28 verdict semantics
                    `F-DIFF-OPT-03`, while keeping `D13` as raw literal `String` decoder `by decide` tests),
    - `Gate OPT-C` (Shared parsing witnesses strictly bound to identical 5-tuple `ProvenanceContext` values
                    `(catalog, numCfg, scopeEnv, budget, rawBytes)` — zero cross-context reuse).
-/
import P3CDifferentialChecker

namespace PneumaOmega.P3C.DifferentialR1.Attacks

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks
open PneumaOmega.P3C.DifferentialR1

/-! ### 1. Finite Decision Algebra (`Gate OPT-B` / `F-DIFF-OPT-03`) -/

inductive GateDVerdictTag where
  | v_d01_pc | v_d01_ce
  | v_d02_pc | v_d02_ce
  | v_d03_pc | v_d03_ce
  | v_d04_pc | v_d04_ce
  | v_d05_pc | v_d05_ce
  | v_d06_pc | v_d06_ce
  | v_d07_pc | v_d07_ce
  | v_d08_pc | v_d08_ce
  | v_d09_pc | v_d09_ce
  | v_d10_pc | v_d10_ce
  | v_d11_pc | v_d11_ce
  | v_d12_pc | v_d12_ce
  | v_d13_pc | v_d13_ce
  | v_d14_pc | v_d14_ce
  | v_unexpectedFailure
  deriving DecidableEq, Repr

/-- Exact 1-to-1 string rendering preserving every `D01`~`D14` verdict label (`F-DIFF-OPT-03`). -/
def renderGateDTag : GateDVerdictTag → String
  | .v_d01_pc => "RAW_DISTINCT_AND_CANON_MATCH(SPEC_GROUNDED)"
  | .v_d01_ce => "MISMATCH_WITNESS:G16_CHILD_SWAP_DETECTED"
  | .v_d02_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):T2_DUAL_READINGS_BOUND"
  | .v_d02_ce => "EXTRACTION_FAILURE_VERIFIED(T1_alt3 & G11_alt2)"
  | .v_d03_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):ROOT_AND_CHILD_SPANS_EXACT"
  | .v_d03_ce => "MISMATCH_WITNESS(spanIntegrityStage):SPAN_SHIFT_CAUGHT"
  | .v_d04_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):ASCII_BYTE_EQ_CODEPOINT_61"
  | .v_d04_ce => "OOD_BLOCKED_BEFORE_SPAN(2B_0xC3 & 3B_0xE2)"
  | .v_d05_pc => "QUANTIFIER_FORMS_SEPARATED(G11!=G12)"
  | .v_d05_ce => "MISMATCH_WITNESS(Scope & Polarity) & T5_TRAP_REJECTED"
  | .v_d06_pc => "G09_CONSENSUS_VS_T3_WH_FACTIVE_REJECTED"
  | .v_d06_ce => "MISMATCH_WITNESS:PRESUPPOSITION_DROP_OR_ADD_CAUGHT"
  | .v_d07_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):CAUSAL_DIRECTIONAL_CANONICAL"
  | .v_d07_ce => "MISMATCH_WITNESS:CAUSAL_NE_ASSOC_AND_NE_NEUTRAL"
  | .v_d08_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):G04_TEMPORAL_ROUNDTRIP"
  | .v_d08_ce => "MISMATCH_WITNESS:TEMPORAL_REVERSAL_CAUGHT"
  | .v_d09_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):G16_CONTRASTIVE_FOREST_OK"
  | .v_d09_ce => "BOUNDARY_SEPARATED(P3B_EmptyParse & P3C_InvalidAnchor & SymConj!=Contrastive)"
  | .v_d10_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):OPTIONAL_FIELDS_ROUNDTRIP_INTACT"
  | .v_d10_ce => "MISMATCH_WITNESS:DROPPED_OPTIONAL_FIELDS_CAUGHT(cov & pVal)"
  | .v_d11_pc => "ALL_5_EXTRACTION_DIAG_FAMILIES_ROUNDTRIPPED"
  | .v_d11_ce => "FAILURE_DISGUISE_AND_RAW_SUBMIT_REJECTED"
  | .v_d12_pc => "PROVENANCE_R1_ADMITS_AUTHENTIC_DECODED_WIRE"
  | .v_d12_ce => "PROVENANCE_R1_REJECTS_CROSS_CONTEXT_AND_SPOOFED_WIRE"
  | .v_d13_pc => "VALID_CANONICAL_WIRE_DECODED"
  | .v_d13_ce => "ALL_6_MALFORMED_WIRE_CLASSES_REJECTED"
  | .v_d14_pc => "MATCH_STRUCTURAL(MODEL_ASSUMPTION):SEPARATED_FROM_SPEC_GROUNDED"
  | .v_d14_ce => "SPECIFICATION_HELD_AND_RESOURCE_OVERFLOW_SEPARATED"
  | .v_unexpectedFailure => "UNEXPECTED_FAILURE"

/-! ### 2. `Gate OPT-C` — Exact 5-Tuple Shared Parsing Witnesses (`(catalog, numCfg, scopeEnv, budget, rawBytes)`) -/

/-- Definitional 5-field identity between `runP3COnContext (mkStdCtx ...)` and `runP3COnStr` (`Gate OPT-C`). -/
theorem runP3COnContext_mkStdCtx_eq (env : ScopeEnv) (budget : ResourceBudget) (s : String) :
    runP3COnContext (mkStdCtx env budget s) = runP3COnStr env budget s := rfl

theorem shared_ctxT2_ambiguous_ok : isAmbiguousDual (runP3COnContext ctxT2) = true := by
  unfold ctxT2; rw [runP3COnContext_mkStdCtx_eq]; exact ce03_ok

theorem shared_ctxG09_consensus_ok :
    isConsensusSingleEq (runP3COnContext ctxG09) expectedCanonG09 = true := by
  unfold ctxG09; rw [runP3COnContext_mkStdCtx_eq]; exact pc03_ok

theorem shared_ctxT3_trap_ok :
    isTrapRejectedSingle (runP3COnContext ctxT3) .whFactivePresuppositionForbidden = true := by
  unfold ctxT3; rw [runP3COnContext_mkStdCtx_eq]; exact ce04_ok

theorem shared_ctxT5_trap_ok :
    isTrapRejectedSingle (runP3COnContext ctxT5) .unscopedClauseForbidden = true := by
  unfold ctxT5; rw [runP3COnContext_mkStdCtx_eq]; exact ce06_ok

theorem shared_ctxT2Overflow_ok :
    runP3COnContext ctxT2Overflow =
      .upstreamRejected (.resourceOverflow (.maxReadingsExceeded 2 1)) := by
  unfold ctxT2Overflow; rw [runP3COnContext_mkStdCtx_eq]; exact eq_of_beq ce15_ok

private theorem parseStatus_overflow_of_runP3C (ctx : ProvenanceContext) (r : OverflowReason)
    (h : runP3COnContext ctx = .upstreamRejected (.resourceOverflow r)) :
    eqStrBool (observeSurfaceE2E ctx).parseStatus "RESOURCE_OVERFLOW" = true := by
  rw [observeSurfaceE2E_isResourceOverflow]
  unfold runP3COnContext certifySemanticConsensus at h
  cases hp : parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | resourceOverflow _ => rfl
  | outOfDomain _ => rw [hp] at h; nomatch h
  | enumerated T =>
    rw [hp] at h; dsimp only at h
    unfold evalForestPure at h
    cases T with
    | nil => nomatch h
    | cons t0 ts =>
      dsimp only at h
      cases hex : extractAllMeanings ctx.scopeEnv (t0 :: ts) with
      | error _ => rw [hex] at h; nomatch h
      | ok pairs =>
        rw [hex] at h
        cases pairs with
        | nil => nomatch h
        | cons p1 rest =>
          dsimp only at h
          cases hdiv : findDivergentReading p1.1 p1.2 (normalizeMeaning p1.2) rest with
          | some _ => rw [hdiv] at h; nomatch h
          | none =>
            rw [hdiv] at h
            cases htrap : findForestTrapViolation (t0 :: ts) with
            | some _ => rw [htrap] at h; nomatch h
            | none => rw [htrap] at h; nomatch h

theorem shared_ctxT2Overflow_parse_overflow :
    eqStrBool (observeSurfaceE2E ctxT2Overflow).parseStatus "RESOURCE_OVERFLOW" = true :=
  parseStatus_overflow_of_runP3C ctxT2Overflow (.maxReadingsExceeded 2 1) shared_ctxT2Overflow_ok

def expectedCanonG12 : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.quantClaim (.properPart "sub_dm_pl" "ev_stroke")) [])

-- Shared exact-context witness for `ctxG12` (`Gate OPT-C`: verified once, bound to exact `ctxG12` 5-tuple).
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in
theorem shared_ctxG12_consensus_ok :
    isConsensusSingleEq (runP3COnContext ctxG12) expectedCanonG12 = true := by decide

def envMismatchedCohort : ScopeEnv :=
  { cohortId := "coh_other_registry", expectedDesignHead := "des_study", quoteIsolation := .sentenceAtomic }

def ctxG11BadCohort : ProvenanceContext :=
  mkStdCtx envMismatchedCohort defaultParseBudget sG11

def isUpstreamEmptyParse : SemanticNormOutcome → Bool
  | .upstreamRejected .emptyParseSet => true
  | _                                => false

-- Shared exact-context witness for `ctxG11BadCohort` (`P3-B checkSide` `.emptyParseSet` boundary).
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in
theorem shared_ctxG11BadCohort_empty_ok :
    isUpstreamEmptyParse (runP3COnContext ctxG11BadCohort) = true := by decide

/-! ### 3. Parameterized Single-Scrutinee Wire Predicates (Eliminating Nested `match` Motives) -/

def checkForestExtDiagWire (env : ScopeEnv) (T : List ConcreteParseTree)
    (expected : ExtractionFailureDiag) : Bool :=
  match decodeForestOutcomeWire env T with
  | .ok (.semanticExtractionFailure _ e) => eqExtractionDiagBool e.diag expected
  | _ => false

theorem checkForestExtDiagWire_eq (env : ScopeEnv) (T : List ConcreteParseTree)
    (expected : ExtractionFailureDiag) :
    checkForestExtDiagWire env T expected =
      match evalForestPure env T with
      | .semanticExtractionFailure _ e => eqExtractionDiagBool e.diag expected
      | _ => false := by
  unfold checkForestExtDiagWire
  rw [decodeForestOutcomeWire_eq]
  cases evalForestPure env T <;> rfl

def checkForestSingleConsensusWire (env : ScopeEnv) (T : List ConcreteParseTree) : Bool :=
  match decodeForestOutcomeWire env T with
  | .ok out => isConsensusSingle out
  | .error _ => false

theorem checkForestSingleConsensusWire_eq (env : ScopeEnv) (T : List ConcreteParseTree) :
    checkForestSingleConsensusWire env T = isConsensusSingle (evalForestPure env T) := by
  unfold checkForestSingleConsensusWire
  rw [decodeForestOutcomeWire_eq]

def checkSurfaceSingleConsensusWire (ctx : ProvenanceContext) (expected : CanonicalMeaning) : Bool :=
  match decodeSurfaceOutcomeWire ctx with
  | .ok out => isConsensusSingleEq out expected
  | .error _ => false

theorem checkSurfaceSingleConsensusWire_eq (ctx : ProvenanceContext) (expected : CanonicalMeaning) :
    checkSurfaceSingleConsensusWire ctx expected =
      isConsensusSingleEq (runP3COnContext ctx) expected := by
  unfold checkSurfaceSingleConsensusWire
  rw [decodeSurfaceOutcomeWire_eq]

def checkSurfaceTrapWire (ctx : ProvenanceContext) (expectedDiag : TrapPolicyDiag) : Bool :=
  match decodeSurfaceOutcomeWire ctx with
  | .ok out => isTrapRejectedSingle out expectedDiag
  | .error _ => false

theorem checkSurfaceTrapWire_eq (ctx : ProvenanceContext) (expectedDiag : TrapPolicyDiag) :
    checkSurfaceTrapWire ctx expectedDiag =
      isTrapRejectedSingle (runP3COnContext ctx) expectedDiag := by
  unfold checkSurfaceTrapWire
  rw [decodeSurfaceOutcomeWire_eq]

def checkSurfaceEmptyParseWire (ctx : ProvenanceContext) : Bool :=
  match decodeSurfaceOutcomeWire ctx with
  | .ok out => isUpstreamEmptyParse out
  | .error _ => false

theorem checkSurfaceEmptyParseWire_eq (ctx : ProvenanceContext) :
    checkSurfaceEmptyParseWire ctx = isUpstreamEmptyParse (runP3COnContext ctx) := by
  unfold checkSurfaceEmptyParseWire
  rw [decodeSurfaceOutcomeWire_eq]

def checkSurfaceOodByteWire (ctx : ProvenanceContext) (expectedByte : UInt8) : Bool :=
  (match decodeSurfaceOutcomeWire ctx with
   | .ok (.upstreamRejected (.outOfDomain (.nonPrintableAsciiByte b))) => b == expectedByte
   | _ => false) &&
  ((observeSurfaceE2E ctx).codepointLenOpt == none)

theorem checkSurfaceOodByteWire_eq (ctx : ProvenanceContext) (expectedByte : UInt8) :
    checkSurfaceOodByteWire ctx expectedByte =
      ((match runP3COnContext ctx with
        | .upstreamRejected (.outOfDomain (.nonPrintableAsciiByte b)) => b == expectedByte
        | _ => false) &&
       ((match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
         | .enumerated _ => some (decodeAsciiBytes ctx.rawBytes).toList.length
         | _ => none) == none)) := by
  unfold checkSurfaceOodByteWire
  rw [decodeSurfaceOutcomeWire_eq, observeSurfaceE2E_codepointLenOpt]
  cases runP3COnContext ctx with
  | upstreamRejected d =>
    cases d with
    | outOfDomain od => cases od <;> rfl
    | _ => rfl
  | _ => rfl

def checkSurfaceOverflowWire (ctx : ProvenanceContext) (expected : OverflowReason) : Bool :=
  (match decodeSurfaceOutcomeWire ctx with
   | .ok (.upstreamRejected (.resourceOverflow r)) => r == expected
   | _ => false) &&
  eqStrBool (observeSurfaceE2E ctx).parseStatus "RESOURCE_OVERFLOW"

theorem checkSurfaceOverflowWire_eq (ctx : ProvenanceContext) (expected : OverflowReason) :
    checkSurfaceOverflowWire ctx expected =
      ((match runP3COnContext ctx with
        | .upstreamRejected (.resourceOverflow r) => r == expected
        | _ => false) &&
       eqStrBool (observeSurfaceE2E ctx).parseStatus "RESOURCE_OVERFLOW") := by
  unfold checkSurfaceOverflowWire
  rw [decodeSurfaceOutcomeWire_eq]
  cases runP3COnContext ctx with
  | upstreamRejected d => cases d <;> rfl
  | _ => rfl

def checkCanonRoundtripWire (c : CanonicalMeaning) : Bool :=
  match decodeWire canonicalMeaningWireCodec (encodeWire canonicalMeaningWireCodec c) with
  | .ok c' => canonicalMeaningEqBool c' c
  | .error _ => false

theorem checkCanonRoundtripWire_eq (c : CanonicalMeaning) :
    checkCanonRoundtripWire c = canonicalMeaningEqBool c c := by
  unfold checkCanonRoundtripWire
  rw [encodeWire_decodeWire_roundtrip]

def checkSemanticInjectRoundtripOk (m : RawSemanticTerm) : Bool :=
  (decodeSemanticInjectCanonWire m).isOk

theorem checkSemanticInjectRoundtripOk_eq (m : RawSemanticTerm) :
    checkSemanticInjectRoundtripOk m = true := by
  unfold checkSemanticInjectRoundtripOk
  rw [decodeSemanticInjectCanonWire_eq]
  rfl

def checkForestReplayRejectWire (targetCtx claimedCtx : ProvenanceContext)
    (env : ScopeEnv) (T : List ConcreteParseTree) (expected : ProvenanceRejectReason) : Bool :=
  match verifyForestWireReplayProj targetCtx claimedCtx env T with
  | .error (.inr r) => r == expected
  | _ => false

theorem checkForestReplayRejectWire_eq (targetCtx claimedCtx : ProvenanceContext)
    (env : ScopeEnv) (T : List ConcreteParseTree) (expected : ProvenanceRejectReason) :
    checkForestReplayRejectWire targetCtx claimedCtx env T expected =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := evalForestPure env T } with
      | .error r => r == expected
      | .ok _    => false := by
  unfold checkForestReplayRejectWire
  rw [verifyForestWireReplayProj_eq]
  cases verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := evalForestPure env T } <;> rfl

def checkSurfaceReplayRejectWire (targetCtx claimedCtx srcCtx : ProvenanceContext)
    (expected : ProvenanceRejectReason) : Bool :=
  match verifySurfaceWireReplayProj targetCtx claimedCtx srcCtx with
  | .error (.inr r) => r == expected
  | _ => false

theorem checkSurfaceReplayRejectWire_eq (targetCtx claimedCtx srcCtx : ProvenanceContext)
    (expected : ProvenanceRejectReason) :
    checkSurfaceReplayRejectWire targetCtx claimedCtx srcCtx expected =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := runP3COnContext srcCtx } with
      | .error r => r == expected
      | .ok _    => false := by
  unfold checkSurfaceReplayRejectWire
  rw [verifySurfaceWireReplayProj_eq]
  cases verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := runP3COnContext srcCtx } <;> rfl

/-! ### 4. Synthetic Trees, Contexts & Semantic Terms for `FOREST_INJECT` and `SEMANTIC_INJECT` -/

private def spDummy : CodepointSpan := ⟨0, 1⟩

def synthValidG16Tree : ConcreteParseTree :=
  let assocCore := ConcreteParseTree.mkTree .Gen_G03_AssocUnadj 1 .clause1 spDummy
    [ .slotTok .expLevel .activeExp "exp_intens" "intensive therapy" spDummy,
      .slotTok .expLevel .refExp "exp_std" "standard care" spDummy,
      .slotTok .assocDir .direction "inversely" "inversely" spDummy,
      .slotTok .outTerm .outcome "out_mi" "myocardial infarction" spDummy,
      .slotTok .ratioMetric .metric1 "hr" "hazard ratio" spDummy,
      .slotTok .numericLit .numEst "0.75" "0.75" spDummy,
      .slotTok .numericLit .numCILevel "95" "95" spDummy,
      .slotTok .numericLit .numCILow "0.61" "0.61" spDummy,
      .slotTok .numericLit .numCIHigh "0.92" "0.92" spDummy ]
  let embOk := ConcreteParseTree.mkTree .Env_EmbeddedCausal 1 .clause2 spDummy
    [ .slotTok .expLevel .activeExp "exp_intens" "intensive therapy" spDummy,
      .slotTok .intervVerbPres .verb "reduces" "reduces" spDummy,
      .slotTok .outTerm .outcome "out_mi" "myocardial infarction" spDummy ]
  let metaCore := ConcreteParseTree.mkTree .Gen_G09_MetaNonEstab 1 .clause2 spDummy
    [ .slotTok .sourceId .source "src_trialA" "Trial-A" spDummy, .childSub embOk ]
  let sc1 := ConcreteParseTree.mkTree .Env_ScopedAssoc 1 .clause1 spDummy
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" spDummy, .childSub assocCore ]
  let sc2 := ConcreteParseTree.mkTree .Env_ScopedContrastMeta 1 .clause2 spDummy
    [ .slotTok .designNoun .design "des_study" "study" spDummy, .childSub metaCore ]
  ConcreteParseTree.mkTree .Gen_G16_DocContrastive 1 .clause1 spDummy [ .childSub sc1, .childSub sc2 ]

def synthSwappedChildrenG16Tree : ConcreteParseTree :=
  match synthValidG16Tree with
  | .mkTree p alt loc sp [c1, c2] => .mkTree p alt loc sp [c2, c1]
  | other => other

def synthG11IllegalAlt2Tree : ConcreteParseTree :=
  let coreBad := ConcreteParseTree.mkTree .Gen_G11_QuantZero 2 .clause1 spDummy
    [ .slotTok .subgroupPlural .subgroup "sub_dm_pl" "diabetic" spDummy,
      .slotTok .eventTerm .eventA "ev_stroke" "stroke" spDummy ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedInitial 1 .clause1 spDummy
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" spDummy, .childSub coreBad ]
  ConcreteParseTree.mkTree .Env_DocSingle 1 .clause1 spDummy [ .childSub sc ]

def perturbRootSpan (t : ConcreteParseTree) : ConcreteParseTree :=
  match t with
  | .mkTree p alt loc sp args => .mkTree p alt loc ⟨sp.startCp, sp.endCp + 1⟩ args

def synthMissingChildrenG15aTree : ConcreteParseTree :=
  ConcreteParseTree.mkTree .Gen_G15a_DocConjAtomic 1 .clause1 spDummy []

def ctxUtf8_2B : ProvenanceContext := { ctxG11 with rawBytes := [0x49, 0x6E, 0x20, 0xC3, 0xA9] }
def ctxUtf8_3B : ProvenanceContext := { ctxG11 with rawBytes := [0x49, 0x6E, 0x20, 0xE2, 0x89, 0xA4] }

def termD04Scoped : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
def termD05Unscoped : RawSemanticTerm :=
  .scopedAtom .unrestrictedPop "u_unscoped" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
def termD05NegUniv : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.negUniversal "sub_dm_pl" "ev_stroke")) []
def termD06Clean : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") []
def termD06WithPresup : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi")
    [.factiveCausal "exp_intens" "reduces" "out_mi"]
def termD07CausalDir : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.intervClaim (.directional "reduce") "assump_exch" "hr" "exp_intens" "exp_std" "out_mi" "0.75" "95" "0.61" "0.92" (some "0.006")) []
def termD09AssocSide : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") []
def termD09MetaSide : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "y_repeat"
    (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") []
def termD09Contrast : RawSemanticTerm :=
  .contrastivePair termD09AssocSide termD09MetaSide "exp_intens" "out_mi"
def termD09SymConj : RawSemanticTerm :=
  .symConj termD09AssocSide termD09MetaSide
def termD10WithCov : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" (some "cov_age_risk") none "0.75" "95" "0.61" "0.92") []
def termD10DropCov : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") []
def termD10Med : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.descDist .medianIQR "meas_sbp" "128" "118" (some "139")) []
def termD10DropP : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.intervClaim (.directional "reduce") "assump_exch" "hr" "exp_intens" "exp_std" "out_mi" "0.75" "95" "0.61" "0.92" none) []

/-! ### 5. Deterministic Evaluation Verdicts Across `D01` ~ `D14` (`28` Vectors) -/

-- D01: Parse Child Order Swap (`G-15a`/`G-15b` raw != vs canonical ==; `G-16` contrastive child swap !=)
def d01_pc_tag : GateDVerdictTag :=
  match extractRawMeaning envDiscourse synthTreeG15a_AB,
        extractRawMeaning envDiscourse synthTreeG15b_BA with
  | .ok m1, .ok m2 =>
    if (verdictHead (compareWirePayloads rawMeaningWireCodec .MODEL_ASSUMPTION "S0-R2.2:G15" .rawExtractionStage
          (encodeWire rawMeaningWireCodec m1) (encodeWire rawMeaningWireCodec m2)) == .mismatchWitness .rawExtractionStage) &&
       (compareCanonicalValuesWire .SPEC_GROUNDED "S0-R2.2:G15" .canonicalNormStage
          (normalizeMeaning m1) (normalizeMeaning m2) == .matchStructural .SPEC_GROUNDED) then
      .v_d01_pc
    else .v_unexpectedFailure
  | _, _ => .v_unexpectedFailure

def d01_ce_tag : GateDVerdictTag :=
  match extractRawMeaning envDiscourse synthValidG16Tree,
        extractRawMeaning envDiscourse synthSwappedChildrenG16Tree with
  | .ok mValid, .ok mSwapped =>
    if compareCanonicalValuesWire .SPEC_GROUNDED "S0-R2:G16" .canonicalNormStage
         (normalizeMeaning mValid) (normalizeMeaning mSwapped) == .mismatchWitness .canonicalNormStage then
      .v_d01_ce
    else .v_unexpectedFailure
  | _, _ => .v_unexpectedFailure

-- D02: `readingAlt` Perturbation (`T2` dual readings preserved vs `alt=3` & `G-11 alt=2` rejected)
def d02_pc_tag : GateDVerdictTag :=
  if checkSurfaceDualAmbiguousWire ctxT2 then .v_d02_pc else .v_unexpectedFailure

def d02_ce_tag : GateDVerdictTag :=
  if checkForestExtDiagWire envAtomic [synthInvalidAlt3Tree] (.unsupportedReadingAlt .Trap_T1_AllNot 3) &&
     checkForestExtDiagWire envAtomic [synthG11IllegalAlt2Tree] (.unsupportedReadingAlt .Gen_G11_QuantZero 2) then
    .v_d02_ce
  else .v_unexpectedFailure

-- D03: `CodepointSpan` Offset Perturbation (`SURFACE_E2E` valid spans vs `+1` span shift `MISMATCH_WITNESS`)
def d03_pc_tag : GateDVerdictTag :=
  if checkSurfaceRootSpanWire ctxG01 then .v_d03_pc else .v_unexpectedFailure

def d03_ce_tag : GateDVerdictTag :=
  if verdictHead (compareWirePayloads parseTreeWireCodec .SPEC_GROUNDED "S0-R2.1:Span" .spanIntegrityStage
       (encodeWire parseTreeWireCodec synthTreeG15a_AB)
       (encodeWire parseTreeWireCodec (perturbRootSpan synthTreeG15a_AB))) ==
       .mismatchWitness .spanIntegrityStage then
    .v_d03_ce
  else .v_unexpectedFailure

-- D04: Byte Length vs Codepoint Length (`ASCII` `byteLen == cpLen == 61` vs UTF-8 `"é"` 2B/1CP & `"≤"` 3B/1CP `OutOfDomain`)
def d04_pc_tag : GateDVerdictTag :=
  if (ctxG11.rawBytes.length == 61) &&
     ((ctxG11.rawBytes.map (fun b => Char.ofNat b.toNat)).length == 61) &&
     (utf8ByteLenOfChars (ctxG11.rawBytes.map (fun b => Char.ofNat b.toNat)) == 61) &&
     checkSemanticInjectRoundtripOk termD04Scoped then
    .v_d04_pc
  else .v_unexpectedFailure

def d04_ce_tag : GateDVerdictTag :=
  if checkSurfaceOodByteWire ctxUtf8_2B 0xC3 &&
     checkSurfaceOodByteWire ctxUtf8_3B 0xE2 &&
     (utf8ByteLenOfChar (Char.ofNat 0xE9) == 2) &&
     (utf8ByteLenOfChar (Char.ofNat 0x2264) == 3) then
    .v_d04_ce
  else .v_unexpectedFailure

-- D05: Scope, Polarity & Quantifier Perturbation (`G-11 != G-12` vs `T5` unscoped & `QuantPredForm` swaps)
def d05_pc_tag : GateDVerdictTag :=
  if compareSingleSurfaceCanonsWire ctxG11 ctxG12 .SPEC_GROUNDED "S0-R2:G11_G12" .canonicalNormStage ==
       some (.mismatchWitness .canonicalNormStage) then
    .v_d05_pc
  else .v_unexpectedFailure

def d05_ce_tag : GateDVerdictTag :=
  if (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:Scope" .canonicalNormStage termD04Scoped termD05Unscoped ==
        .mismatchWitness .canonicalNormStage) &&
     (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:Polarity" .canonicalNormStage termD04Scoped termD05NegUniv ==
        .mismatchWitness .canonicalNormStage) &&
     checkSurfaceTrapWire ctxT5 .unscopedClauseForbidden then
    .v_d05_ce
  else .v_unexpectedFailure

-- D06: Factive Presupposition Drop / Injection (`G-09` vs `T3` trap & injected presupposition on `G-09`)
def d06_pc_tag : GateDVerdictTag :=
  if checkSurfaceSingleConsensusWire ctxG09 expectedCanonG09 &&
     checkSurfaceTrapWire ctxT3 .whFactivePresuppositionForbidden then
    .v_d06_pc
  else .v_unexpectedFailure

def d06_ce_tag : GateDVerdictTag :=
  if compareSemanticInjectCanonsWire .SPEC_GROUNDED "P0-A05:T2_Presup" .canonicalNormStage
       termD06Clean termD06WithPresup == .mismatchWitness .canonicalNormStage then
    .v_d06_ce
  else .v_unexpectedFailure

-- D07: Causal Modality vs Associative Modality Substitution
def d07_pc_tag : GateDVerdictTag :=
  if checkSemanticInjectIdempWire termD07CausalDir then .v_d07_pc else .v_unexpectedFailure

def d07_ce_tag : GateDVerdictTag :=
  if (compareCanonicalValuesWire .SPEC_GROUNDED "GateC0-R1:F-C0-07" .canonicalNormStage expectedCanonG06a expectedCanonG03 ==
        .mismatchWitness .canonicalNormStage) &&
     (compareCanonicalValuesWire .SPEC_GROUNDED "GateC0-R1:F-C0-07" .canonicalNormStage expectedCanonG06a expectedCanonG06b ==
        .mismatchWitness .canonicalNormStage) then
    .v_d07_ce
  else .v_unexpectedFailure

-- D08: Temporal Precedence Reversal (`G-04` `ev_stroke < ev_aki` vs `ev_aki < ev_stroke`)
def d08_pc_tag : GateDVerdictTag :=
  if checkCanonRoundtripWire expectedCanonG04_AB then .v_d08_pc else .v_unexpectedFailure

def d08_ce_tag : GateDVerdictTag :=
  if compareCanonicalValuesWire .SPEC_GROUNDED "S0-R2:G04" .canonicalNormStage
       expectedCanonG04_AB expectedCanonG04_BA == .mismatchWitness .canonicalNormStage then
    .v_d08_ce
  else .v_unexpectedFailure

-- D09: `G-15` Symmetric Conjunction vs `G-16` Contrastive & Boundary Separation (`F-DIFF-P0-03`)
def d09_pc_tag : GateDVerdictTag :=
  if checkForestSingleConsensusWire envDiscourse [synthValidG16Tree] then
    .v_d09_pc
  else .v_unexpectedFailure

def d09_ce_tag : GateDVerdictTag :=
  if checkSurfaceEmptyParseWire ctxG11BadCohort &&
     checkForestExtDiagWire envDiscourse [synthBadAnchorG16Tree] (.invalidContrastiveAnchor .Gen_G16_DocContrastive) &&
     (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:G15_vs_G16" .canonicalNormStage
        termD09Contrast termD09SymConj == .mismatchWitness .canonicalNormStage) then
    .v_d09_ce
  else .v_unexpectedFailure

-- D10: Canonical Optional Field Omission (`covariatesOpt`, `pValOpt`, `disp2Opt`)
def d10_pc_tag : GateDVerdictTag :=
  if checkSemanticInjectRoundtripOk termD10WithCov &&
     checkSemanticInjectRoundtripOk termD10Med then
    .v_d10_pc
  else .v_unexpectedFailure

def d10_ce_tag : GateDVerdictTag :=
  if (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:G14" .canonicalNormStage
        termD10WithCov termD10DropCov == .mismatchWitness .canonicalNormStage) &&
     (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:G06a" .canonicalNormStage
        termD07CausalDir termD10DropP == .mismatchWitness .canonicalNormStage) then
    .v_d10_ce
  else .v_unexpectedFailure

-- D11: All Remaining `ExtractionFailureDiag` Branches & Failure-to-Consensus Wire Disguise Rejection
def d11_pc_tag : GateDVerdictTag :=
  if checkForestExtDiagWire envAtomic [synthMissingChildrenG15aTree]
       (.malformedParseNode .Gen_G15a_DocConjAtomic "expected_two_child_subtrees") &&
     checkForestExtDiagWire envMismatchedCohort [synthTreeG15a_AB]
       (.mismatchedScopeCohort "coh_primary" "coh_other_registry") &&
     checkForestExtDiagWire envMismatchedDesign [synthTreeG15b_BA]
       (.unresolvedAnaphoricScope "des_study" "des_other_registry") then
    .v_d11_pc
  else .v_unexpectedFailure

def d11_ce_tag : GateDVerdictTag :=
  if checkForestReplayRejectWire ctxG15b ctxG15b envMismatchedDesign [synthTreeG15b_BA] .nonConsensusOutcomeSubmitted &&
     (verdictHead (compareWirePayloads outcomeWireCodec .SPEC_GROUNDED "F-P3C-D02:5Way" .outcomeGateStage
        (encodeWire outcomeWireCodec (evalForestPure envMismatchedDesign [synthTreeG15b_BA]))
        (encodeWire outcomeWireCodec (.consensus [synthTreeG15b_BA] expectedCanonG15Conj))) ==
        .mismatchWitness .outcomeGateStage) then
    .v_d11_ce
  else .v_unexpectedFailure

-- D12: `Provenance R1` Cross-Context Wire Replay (`PO-DIFF-08`)
def d12_pc_tag : GateDVerdictTag :=
  if (verifyDecodedOutcomeWireAgainstProvenance ctxG01 ctxG01 (observeSurfaceE2E ctxG01).outcomeWire).isOk then
    .v_d12_pc
  else .v_unexpectedFailure

def d12_ce_tag : GateDVerdictTag :=
  if checkSurfaceReplayRejectWire ctxG11 ctxG01 ctxG01 .rawBytesMismatch &&
     checkSurfaceReplayRejectWire ctxG11 ctxG11 ctxG01 .substitutedCanonicalMeaning then
    .v_d12_ce
  else .v_unexpectedFailure

-- D13: Malformed / Non-Canonical Wire Rejection (`Corrigendum F-DIFF-P0-01` & `Gate OPT-B` Mandatory Literal `decide`)
def d13_pc_tag : GateDVerdictTag :=
  let validSpanWire := encodeWire spanWireCodec ⟨12, 48⟩
  match decodeWire spanWireCodec validSpanWire with
  | .ok sp => if sp == ⟨12, 48⟩ then .v_d13_pc else .v_unexpectedFailure
  | .error _ => .v_unexpectedFailure

def d13_ce_tag : GateDVerdictTag :=
  let badVer   := decodeWire spanWireCodec "DIFFV0;CodepointSpan;CodepointSpan.mk;N#12;N#48;"
  let badType  := decodeWire spanWireCodec "DIFFV1;CanonicalMeaning;CodepointSpan.mk;N#12;N#48;"
  let badZero  := decodeWire spanWireCodec "DIFFV1;CodepointSpan;CodepointSpan.mk;N#01;N#48;"
  let noSemi   := decodeWire spanWireCodec "DIFFV1;CodepointSpan;CodepointSpan.mk;N#12;N#48"
  let trailing := decodeWire spanWireCodec "DIFFV1;CodepointSpan;CodepointSpan.mk;N#12;N#48;EXTRA;"
  let badStrBytes := decodeWire rawMeaningWireCodec
    "DIFFV1;RawSemanticTerm;RawSemanticTerm.scopedAtom;SemanticScope.unrestrictedPop;STR;N#1;N#1;C#233;AtomicClaim.quantClaim;QuantPredForm.existentialPos;STR;N#1;N#1;C#97;STR;N#1;N#1;C#98;PresupList.nil;"
  match badVer, badType, badZero, noSemi, trailing, badStrBytes with
  | .error (.invalidVersionHeader "DIFFV0"),
    .error (.typeTagMismatch "CodepointSpan" "CanonicalMeaning"),
    .error (.leadingZeroInNatToken "N#01"),
    .error .unterminatedTokenMissingSemicolon,
    .error (.trailingUnconsumedTokens 1),
    .error (.stringByteVsCodepointMismatch 1 2) =>
    .v_d13_ce
  | _, _, _, _, _, _ => .v_unexpectedFailure

-- D14: 5-Valued `DiffVerdict` Algebra (`MODEL_ASSUMPTION` vs `SPECIFICATION_HELD` vs `RESOURCE_OVERFLOW`)
def d14_pc_tag : GateDVerdictTag :=
  if verdictHead (compareWirePayloads rawMeaningWireCodec .MODEL_ASSUMPTION "P3C:SurfaceBinderConvention" .rawExtractionStage
       (encodeWire rawMeaningWireCodec termD04Scoped)
       (encodeWire rawMeaningWireCodec termD04Scoped)) == .matchStructural .MODEL_ASSUMPTION then
    .v_d14_pc
  else .v_unexpectedFailure

def d14_ce_tag : GateDVerdictTag :=
  if (verdictHead (compareWirePayloads canonicalMeaningWireCodec .SPEC_UNDEFINED
        "S0-R2:G01_RightCensored_KM_AJ" .canonicalNormStage
        (encodeWire canonicalMeaningWireCodec expectedCanonG01)
        (encodeWire canonicalMeaningWireCodec expectedCanonG01)) == .specificationHeld) &&
     checkSurfaceOverflowWire ctxT2Overflow (.maxReadingsExceeded 2 1) then
    .v_d14_ce
  else .v_unexpectedFailure

/-! ### 6. Pure `unfold + rw` Kernel Proofs Across All 28 Vectors (`0` `sorry`, `0` `native_decide`) -/

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d01_pc_ok : d01_pc_tag = .v_d01_pc := by
  unfold d01_pc_tag
  simp only [compareCanonicalValuesWire_eq, verdictHead_compare_encode]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d01_ce_ok : d01_ce_tag = .v_d01_ce := by
  unfold d01_ce_tag
  simp only [compareCanonicalValuesWire_eq]
  decide

theorem d02_pc_ok : d02_pc_tag = .v_d02_pc := by
  unfold d02_pc_tag
  rw [checkSurfaceDualAmbiguousWire_eq_isAmbiguousDual, shared_ctxT2_ambiguous_ok]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d02_ce_ok : d02_ce_tag = .v_d02_ce := by
  unfold d02_ce_tag
  rw [checkForestExtDiagWire_eq, checkForestExtDiagWire_eq]
  decide

theorem d03_pc_ok : d03_pc_tag = .v_d03_pc := by
  unfold d03_pc_tag
  rw [checkSurfaceRootSpanWire_of_single_consensus ctxG01 expectedCanonG01 ctxG01_consensus_ok]
  rfl

theorem d03_ce_ok : d03_ce_tag = .v_d03_ce := by
  unfold d03_ce_tag
  have hne : synthTreeG15a_AB ≠ perturbRootSpan synthTreeG15a_AB := by
    intro h
    have hsp : synthTreeG15a_AB.span = (perturbRootSpan synthTreeG15a_AB).span :=
      congrArg ConcreteParseTree.span h
    revert hsp; decide
  rw [verdictHead_compare_encode_of_ne parseTreeWireCodec .SPEC_GROUNDED "S0-R2.1:Span"
        .spanIntegrityStage (by decide) hne]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d04_pc_ok : d04_pc_tag = .v_d04_pc := by
  unfold d04_pc_tag
  rw [checkSemanticInjectRoundtripOk_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d04_ce_ok : d04_ce_tag = .v_d04_ce := by
  unfold d04_ce_tag
  rw [checkSurfaceOodByteWire_eq, checkSurfaceOodByteWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d05_pc_ok : d05_pc_tag = .v_d05_pc := by
  unfold d05_pc_tag
  rw [compareSingleSurfaceCanonsWire_of_single_consensus ctxG11 ctxG12
        expectedCanonG11 expectedCanonG12 .SPEC_GROUNDED "S0-R2:G11_G12" .canonicalNormStage
        ctxG11_consensus_ok shared_ctxG12_consensus_ok]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d05_ce_ok : d05_ce_tag = .v_d05_ce := by
  unfold d05_ce_tag
  rw [compareSemanticInjectCanonsWire_eq, compareSemanticInjectCanonsWire_eq,
      checkSurfaceTrapWire_eq, shared_ctxT5_trap_ok]
  decide

theorem d06_pc_ok : d06_pc_tag = .v_d06_pc := by
  unfold d06_pc_tag
  rw [checkSurfaceSingleConsensusWire_eq, checkSurfaceTrapWire_eq,
      shared_ctxG09_consensus_ok, shared_ctxT3_trap_ok]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d06_ce_ok : d06_ce_tag = .v_d06_ce := by
  unfold d06_ce_tag
  rw [compareSemanticInjectCanonsWire_eq]
  decide

theorem d07_pc_ok : d07_pc_tag = .v_d07_pc := by
  unfold d07_pc_tag
  rw [checkSemanticInjectIdempWire_eq_true]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d07_ce_ok : d07_ce_tag = .v_d07_ce := by
  unfold d07_ce_tag
  rw [compareCanonicalValuesWire_eq, compareCanonicalValuesWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d08_pc_ok : d08_pc_tag = .v_d08_pc := by
  unfold d08_pc_tag
  rw [checkCanonRoundtripWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d08_ce_ok : d08_ce_tag = .v_d08_ce := by
  unfold d08_ce_tag
  rw [compareCanonicalValuesWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d09_pc_ok : d09_pc_tag = .v_d09_pc := by
  unfold d09_pc_tag
  rw [checkForestSingleConsensusWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d09_ce_ok : d09_ce_tag = .v_d09_ce := by
  unfold d09_ce_tag
  rw [checkSurfaceEmptyParseWire_eq, checkForestExtDiagWire_eq,
      compareSemanticInjectCanonsWire_eq, shared_ctxG11BadCohort_empty_ok]
  decide

theorem d10_pc_ok : d10_pc_tag = .v_d10_pc := by
  unfold d10_pc_tag
  rw [checkSemanticInjectRoundtripOk_eq, checkSemanticInjectRoundtripOk_eq]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d10_ce_ok : d10_ce_tag = .v_d10_ce := by
  unfold d10_ce_tag
  rw [compareSemanticInjectCanonsWire_eq, compareSemanticInjectCanonsWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d11_pc_ok : d11_pc_tag = .v_d11_pc := by
  unfold d11_pc_tag
  rw [checkForestExtDiagWire_eq, checkForestExtDiagWire_eq, checkForestExtDiagWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d11_ce_ok : d11_ce_tag = .v_d11_ce := by
  unfold d11_ce_tag
  have hne : evalForestPure envMismatchedDesign [synthTreeG15b_BA] ≠
               .consensus [synthTreeG15b_BA] expectedCanonG15Conj := by
    have htag : outcomeBranchOf (evalForestPure envMismatchedDesign [synthTreeG15b_BA]) =
                  .tagSemanticExtractionFailure := by decide
    intro heq
    rw [heq] at htag
    nomatch htag
  rw [checkForestReplayRejectWire_eq,
      verdictHead_compare_encode_of_ne outcomeWireCodec .SPEC_GROUNDED "F-P3C-D02:5Way"
        .outcomeGateStage (by decide) hne]
  unfold verifyClaimPure
  have hcm : checkContextMatch ctxG15b ctxG15b = none :=
    (checkContextMatch_none_iff ctxG15b ctxG15b).mpr rfl
  rw [hcm]
  decide

theorem d12_pc_ok : d12_pc_tag = .v_d12_pc := by
  unfold d12_pc_tag
  have hexec : runP3COnContext ctxG01 = .consensus certG01.trees certG01.canonical :=
    certG01.hExecProvenance
  rw [observeSurfaceE2E_outcomeWire, hexec]
  have hok : verifyDecodedOutcomeWireAgainstProvenance ctxG01 ctxG01
               (encodeWire outcomeWireCodec (.consensus certG01.trees certG01.canonical)) =
             .ok certG01 :=
    ((provenance_boundary_preserved_across_wire ctxG01 ctxG01 _).1 certG01).mpr
      ⟨rfl, rfl, certG01.hExecProvenance⟩
  rw [hok]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d12_ce_ok : d12_ce_tag = .v_d12_ce := by
  unfold d12_ce_tag
  rw [checkSurfaceReplayRejectWire_eq, checkSurfaceReplayRejectWire_eq]
  have hexec01 : runP3COnContext ctxG01 = .consensus certG01.trees expectedCanonG01 := by
    rw [← certG01_canonical_eq]; exact certG01.hExecProvenance
  have hexec11 : certifySemanticConsensus ctxG11.catalog ctxG11.numCfg ctxG11.scopeEnv
                   ctxG11.budget ctxG11.rawBytes = .consensus certG11.trees expectedCanonG11 := by
    rw [← extractAdmittedCert_canonical_eq ctxG11 expectedCanonG11 ctxG11_consensus_ok]
    exact certG11.hExecProvenance
  have hcm11 : checkContextMatch ctxG11 ctxG11 = none :=
    (checkContextMatch_none_iff ctxG11 ctxG11).mpr rfl
  rw [hexec01]
  unfold verifyClaimPure
  simp only [hcm11, hexec11]
  decide

-- Mandatory literal wire `String` decoder verification via pure kernel `decide` (`Gate OPT-B`):
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d13_pc_ok : d13_pc_tag = .v_d13_pc := by decide

set_option maxHeartbeats 2400000 in
set_option maxRecDepth 16384 in
theorem d13_ce_ok : d13_ce_tag = .v_d13_ce := by decide

theorem d13_literal_decoder_strings_ok :
    eqStrBool (renderGateDTag d13_pc_tag) "VALID_CANONICAL_WIRE_DECODED" = true ∧
    eqStrBool (renderGateDTag d13_ce_tag) "ALL_6_MALFORMED_WIRE_CLASSES_REJECTED" = true := by
  rw [d13_pc_ok, d13_ce_ok]
  decide

theorem d14_pc_ok : d14_pc_tag = .v_d14_pc := by
  unfold d14_pc_tag
  rw [verdictHead_compare_encode_self]
  rfl

theorem d14_ce_ok : d14_ce_tag = .v_d14_ce := by
  unfold d14_ce_tag
  rw [verdictHead_compare_encode_self, checkSurfaceOverflowWire_eq,
      shared_ctxT2Overflow_ok, shared_ctxT2Overflow_parse_overflow]
  rfl

/-! ### 7. Structured 28-Vector Audit Table & Master Suite Theorem (`F-DIFF-OPT-03`) -/

structure DiffAttackCase where
  caseId             : String
  attackFamily       : String
  polarity           : String
  pathClass          : ObservationPathClass
  epistemicGrade     : OracleEpistemicGrade
  r0SpecAnchor       : String
  firstBoundary      : FirstBlockingBoundary
  targetObligation   : String
  expectedTag        : GateDVerdictTag
  actualTag          : GateDVerdictTag
  deriving Repr

def DiffAttackCase.expectedVerdictTag (c : DiffAttackCase) : String :=
  renderGateDTag c.expectedTag

def DiffAttackCase.actualVerdictTag (c : DiffAttackCase) : String :=
  renderGateDTag c.actualTag

def DiffAttackCase.passed (c : DiffAttackCase) : Bool :=
  c.actualTag == c.expectedTag

def mkDiffCase (cid fam pol : String) (pcls : ObservationPathClass) (grd : OracleEpistemicGrade)
    (anc : String) (bnd : FirstBlockingBoundary) (obl : String)
    (exp act : GateDVerdictTag) : DiffAttackCase :=
  { caseId           := cid
    attackFamily     := fam
    polarity         := pol
    pathClass        := pcls
    epistemicGrade   := grd
    r0SpecAnchor     := anc
    firstBoundary    := bnd
    targetObligation := obl
    expectedTag      := exp
    actualTag        := act }

def allDiffAttackCases : List DiffAttackCase :=
  [ mkDiffCase "PC-DIFF-01" "D01_ChildOrderSwap"      "PC" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2.2:G15"          .p3cCanonicalNormalizer     "PO-DIFF-04 / PO-DIFF-05" .v_d01_pc d01_pc_tag,
    mkDiffCase "CE-DIFF-01" "D01_ChildOrderSwap"      "CE" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2:G16"            .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d01_ce d01_ce_tag,
    mkDiffCase "PC-DIFF-02" "D02_ReadingAltPerturb"   "PC" .SURFACE_E2E     .SPEC_GROUNDED    "P0-A05:T2_DualAlt"    .p3cConsensusAndTrapGate    "PO-DIFF-04 / PO-DIFF-06" .v_d02_pc d02_pc_tag,
    mkDiffCase "CE-DIFF-02" "D02_ReadingAltPerturb"   "CE" .FOREST_INJECT   .SPEC_GROUNDED    "P0-A05:AltBounds"     .p3cRawTreeExtractor        "PO-DIFF-04 / PO-DIFF-06" .v_d02_ce d02_ce_tag,
    mkDiffCase "PC-DIFF-03" "D03_SpanOffsetPerturb"   "PC" .SURFACE_E2E     .SPEC_GROUNDED    "S0-R2.1:Span"         .p3bGrammarAndCheckSide     "PO-DIFF-02 / PO-DIFF-03" .v_d03_pc d03_pc_tag,
    mkDiffCase "CE-DIFF-03" "D03_SpanOffsetPerturb"   "CE" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2.1:Span"         .diffV1CanonicalWireDecoder  "PO-DIFF-02 / PO-DIFF-07" .v_d03_ce d03_ce_tag,
    mkDiffCase "PC-DIFF-04" "D04_ByteVsCodepoint"     "PC" .SURFACE_E2E     .SPEC_GROUNDED    "GateC0-R1:F-C0-03"    .p3bStrictAsciiDomain       "PO-DIFF-03"              .v_d04_pc d04_pc_tag,
    mkDiffCase "CE-DIFF-04" "D04_ByteVsCodepoint"     "CE" .SURFACE_E2E     .SPEC_GROUNDED    "GateC0-R1:F-C0-03"    .p3bStrictAsciiDomain       "PO-DIFF-03 / PO-DIFF-06" .v_d04_ce d04_ce_tag,
    mkDiffCase "PC-DIFF-05" "D05_ScopePolarityQuant"  "PC" .SURFACE_E2E     .SPEC_GROUNDED    "S0-R2:G11_G12"        .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d05_pc d05_pc_tag,
    mkDiffCase "CE-DIFF-05" "D05_ScopePolarityQuant"  "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:T1_T5_Scope"    .p3cConsensusAndTrapGate    "PO-DIFF-05 / PO-DIFF-06" .v_d05_ce d05_ce_tag,
    mkDiffCase "PC-DIFF-06" "D06_FactivePresup"       "PC" .SURFACE_E2E     .SPEC_GROUNDED    "S0-R2:G09_vs_T3"      .p3cConsensusAndTrapGate    "PO-DIFF-05 / PO-DIFF-06" .v_d06_pc d06_pc_tag,
    mkDiffCase "CE-DIFF-06" "D06_FactivePresup"       "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "P0-A05:T2_Presup"     .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d06_ce d06_ce_tag,
    mkDiffCase "PC-DIFF-07" "D07_CausalVsAssocModal"  "PC" .SEMANTIC_INJECT .SPEC_GROUNDED    "GateC0-R1:F-C0-07"    .p3cCanonicalNormalizer     "PO-DIFF-05"              .v_d07_pc d07_pc_tag,
    mkDiffCase "CE-DIFF-07" "D07_CausalVsAssocModal"  "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "GateC0-R1:F-C0-07"    .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d07_ce d07_ce_tag,
    mkDiffCase "PC-DIFF-08" "D08_TemporalReversal"    "PC" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:G04"            .p3cCanonicalNormalizer     "PO-DIFF-01 / PO-DIFF-05" .v_d08_pc d08_pc_tag,
    mkDiffCase "CE-DIFF-08" "D08_TemporalReversal"    "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:G04"            .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d08_ce d08_ce_tag,
    mkDiffCase "PC-DIFF-09" "D09_SymConjVsContrast"   "PC" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2:G16"            .p3cConsensusAndTrapGate    "PO-DIFF-04 / PO-DIFF-05" .v_d09_pc d09_pc_tag,
    mkDiffCase "CE-DIFF-09" "D09_SymConjVsContrast"   "CE" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2:G15_vs_G16"     .p3bGrammarAndCheckSide     "PO-DIFF-04 / PO-DIFF-06" .v_d09_ce d09_ce_tag,
    mkDiffCase "PC-DIFF-10" "D10_OptionalFieldDrop"   "PC" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:G02b_G14"       .diffV1CanonicalWireDecoder  "PO-DIFF-01 / PO-DIFF-05" .v_d10_pc d10_pc_tag,
    mkDiffCase "CE-DIFF-10" "D10_OptionalFieldDrop"   "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:G06a_G14"       .p3cCanonicalNormalizer     "PO-DIFF-02 / PO-DIFF-05" .v_d10_ce d10_ce_tag,
    mkDiffCase "PC-DIFF-11" "D11_ExtractionDiag5Way"  "PC" .FOREST_INJECT   .MODEL_ASSUMPTION "P3C:ExtractorDiags"   .p3cRawTreeExtractor        "PO-DIFF-04 / PO-DIFF-06" .v_d11_pc d11_pc_tag,
    mkDiffCase "CE-DIFF-11" "D11_ExtractionDiag5Way"  "CE" .FOREST_INJECT   .SPEC_GROUNDED    "F-P3C-D02:5Way"       .provenanceR1WhiteboxReplay  "PO-DIFF-06 / PO-DIFF-08" .v_d11_ce d11_ce_tag,
    mkDiffCase "PC-DIFF-12" "D12_ProvenanceReplay"    "PC" .SURFACE_E2E     .SPEC_GROUNDED    "F-P3C-01:Provenance"  .provenanceR1WhiteboxReplay  "PO-DIFF-08"              .v_d12_pc d12_pc_tag,
    mkDiffCase "CE-DIFF-12" "D12_ProvenanceReplay"    "CE" .SURFACE_E2E     .SPEC_GROUNDED    "F-P3C-01:Provenance"  .provenanceR1WhiteboxReplay  "PO-DIFF-08"              .v_d12_ce d12_ce_tag,
    mkDiffCase "PC-DIFF-13" "D13_CanonicalWireGate"   "PC" .SEMANTIC_INJECT .SPEC_GROUNDED    "F-DIFF-P0-01:WireV1"  .diffV1CanonicalWireDecoder  "PO-DIFF-01 / PO-DIFF-02" .v_d13_pc d13_pc_tag,
    mkDiffCase "CE-DIFF-13" "D13_CanonicalWireGate"   "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "F-DIFF-P0-01:WireV1"  .diffV1CanonicalWireDecoder  "PO-DIFF-01 / PO-DIFF-03" .v_d13_ce d13_ce_tag,
    mkDiffCase "PC-DIFF-14" "D14_VerdictGradeAlgebra" "PC" .SEMANTIC_INJECT .MODEL_ASSUMPTION "F-DIFF-P0-02:Grades"  .p3cRawTreeExtractor        "PO-DIFF-07"              .v_d14_pc d14_pc_tag,
    mkDiffCase "CE-DIFF-14" "D14_VerdictGradeAlgebra" "CE" .SURFACE_E2E     .SPEC_UNDEFINED   "S0-R2:G01_RightCens"  .p3bBoundedResourceGate     "PO-DIFF-07"              .v_d14_ce d14_ce_tag ]

private theorem diff_list_all_eq_true {α : Type} (p : α → Bool) (xs : List α) :
    xs.all p = true ↔ ∀ x ∈ xs, p x = true := by
  induction xs with
  | nil => simp [List.all]
  | cons a rest ih =>
    simp only [List.all, Bool.and_eq_true, ih]
    constructor
    · rintro ⟨ha, hrest⟩ x hx
      rcases List.mem_cons.mp hx with rfl | hm
      · exact ha
      · exact hrest x hm
    · intro hall
      exact ⟨hall a (List.Mem.head rest), fun x hx => hall x (List.Mem.tail a hx)⟩

theorem allDiffAttackCases_pass :
    allDiffAttackCases.length = 28 ∧
    ∀ c ∈ allDiffAttackCases,
      c.passed = true ∧
      c.actualTag = c.expectedTag ∧
      c.actualVerdictTag = c.expectedVerdictTag := by
  have hall : ∀ c ∈ allDiffAttackCases, c.passed = true := by
    apply (diff_list_all_eq_true DiffAttackCase.passed allDiffAttackCases).mp
    dsimp only [allDiffAttackCases, mkDiffCase, DiffAttackCase.passed, List.all]
    rw [d01_pc_ok, d01_ce_ok, d02_pc_ok, d02_ce_ok, d03_pc_ok, d03_ce_ok, d04_pc_ok, d04_ce_ok,
        d05_pc_ok, d05_ce_ok, d06_pc_ok, d06_ce_ok, d07_pc_ok, d07_ce_ok, d08_pc_ok, d08_ce_ok,
        d09_pc_ok, d09_ce_ok, d10_pc_ok, d10_ce_ok, d11_pc_ok, d11_ce_ok, d12_pc_ok, d12_ce_ok,
        d13_pc_ok, d13_ce_ok, d14_pc_ok, d14_ce_ok]
    decide
  refine ⟨rfl, ?_⟩
  intro c hc
  have hp := hall c hc
  have htag : c.actualTag = c.expectedTag := eq_of_beq hp
  exact ⟨hp, htag, congrArg renderGateDTag htag⟩

end PneumaOmega.P3C.DifferentialR1.Attacks
````

### File 11: `04_proof_obligations/P3CDifferentialObligations.lean` (SHA-256: `EE412CE5FC5C69D537412C4380F424231D522BB0AFDCA20363237EFC58EE0822`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1
  Root export for `P3CDifferentialObligations`
-/
import P3CDifferentialObligations.PO_DIFF_01_To_08
````

### File 12: `04_proof_obligations/P3CDifferentialObligations/PO_DIFF_01_To_08.lean` (SHA-256: `DDE78809CE366D28BAD11EFC812357F549916CB7B5CFFDE86A37E78705F296C7`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate C`: Canonical Proof Obligations `PO-DIFF-01` ~ `PO-DIFF-08`)
  04_proof_obligations/P3CDifferentialObligations/PO_DIFF_01_To_08.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`, zero `native_decide`)

  Exports the eight kernel-checked obligations of `Gate C` + `Corrigendum R0`:
    - `PO_DIFF_01_SerializationRoundtripAndCanonicalUniqueness`
    - `PO_DIFF_02_EncodingInjectivity`
    - `PO_DIFF_03_SpanUnitIntegrity`
    - `PO_DIFF_04_ExtractionResultFidelity`
    - `PO_DIFF_05_CanonicalMeaningFidelity`
    - `PO_DIFF_06_FiveWayOutcomeSeparation`
    - `PO_DIFF_07_DifferentialScopeSoundness`
    - `PO_DIFF_08_ProvenanceBoundaryPreservation`
  Note (`Charter §2 & Gate C`): `PO-DIFF-09` (`Independent Specification Boundary`) is explicitly
  classified as an external source-dependency & R0-correspondence audit obligation (never falsely
  claimed as discharged by a self-referential Lean tautology!).
-/
import P3CDifferentialAttacks

namespace PneumaOmega.P3C.DifferentialR1.Obligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.DifferentialR1
open PneumaOmega.P3C.DifferentialR1.Attacks

/-! ### `PO-DIFF-01` — Serialization Roundtrip, Canonical Uniqueness & Malformed Rejection (`F-DIFF-P0-01`) -/

theorem PO_DIFF_01_SerializationRoundtripAndCanonicalUniqueness :
    -- 1. Roundtrip `decode(encode x) = .ok x` across all 7 target computational types:
    (∀ sp : CodepointSpan, decodeWire spanWireCodec (encodeWire spanWireCodec sp) = .ok sp) ∧
    (∀ tr : ConcreteParseTree, decodeWire parseTreeWireCodec (encodeWire parseTreeWireCodec tr) = .ok tr) ∧
    (∀ T : List ConcreteParseTree, decodeWire parseForestWireCodec (encodeWire parseForestWireCodec T) = .ok T) ∧
    (∀ m : RawSemanticTerm, decodeWire rawMeaningWireCodec (encodeWire rawMeaningWireCodec m) = .ok m) ∧
    (∀ c : CanonicalMeaning, decodeWire canonicalMeaningWireCodec (encodeWire canonicalMeaningWireCodec c) = .ok c) ∧
    (∀ e : ForestExtractionError, decodeWire forestExtractionErrWireCodec (encodeWire forestExtractionErrWireCodec e) = .ok e) ∧
    (∀ o : SemanticNormOutcome, decodeWire outcomeWireCodec (encodeWire outcomeWireCodec o) = .ok o) ∧
    -- 2. Canonical Encoding Uniqueness (`decode s = .ok x ↔ encode x = s`) & Malformed Wire Rejection:
    (∀ {α : Type} (C : CanonicalWireCodec α) (s : String) (x : α),
       decodeWire C s = .ok x ↔ encodeWire C x = s) ∧
    (∀ {α : Type} (C : CanonicalWireCodec α) (s : String),
       ¬ ValidWireEncoding C s → ∃ err : DecodeRejectDiag, decodeWire C s = .error err) :=
  ⟨encodeWire_decodeWire_roundtrip spanWireCodec,
   encodeWire_decodeWire_roundtrip parseTreeWireCodec,
   encodeWire_decodeWire_roundtrip parseForestWireCodec,
   encodeWire_decodeWire_roundtrip rawMeaningWireCodec,
   encodeWire_decodeWire_roundtrip canonicalMeaningWireCodec,
   encodeWire_decodeWire_roundtrip forestExtractionErrWireCodec,
   encodeWire_decodeWire_roundtrip outcomeWireCodec,
   fun C s x => decodeWire_ok_iff_encodeWire_eq C s x,
   fun C s h => malformed_wire_rejected C s h⟩

/-! ### `PO-DIFF-02` — Encoding Injectivity Across All Observable Computational Types -/

theorem PO_DIFF_02_EncodingInjectivity :
    (∀ x y : CodepointSpan, encodeWire spanWireCodec x = encodeWire spanWireCodec y → x = y) ∧
    (∀ x y : ConcreteParseTree, encodeWire parseTreeWireCodec x = encodeWire parseTreeWireCodec y → x = y) ∧
    (∀ x y : List ConcreteParseTree, encodeWire parseForestWireCodec x = encodeWire parseForestWireCodec y → x = y) ∧
    (∀ x y : RawSemanticTerm, encodeWire rawMeaningWireCodec x = encodeWire rawMeaningWireCodec y → x = y) ∧
    (∀ x y : CanonicalMeaning, encodeWire canonicalMeaningWireCodec x = encodeWire canonicalMeaningWireCodec y → x = y) ∧
    (∀ x y : ForestExtractionError, encodeWire forestExtractionErrWireCodec x = encodeWire forestExtractionErrWireCodec y → x = y) ∧
    (∀ x y : SemanticNormOutcome, encodeWire outcomeWireCodec x = encodeWire outcomeWireCodec y → x = y) :=
  ⟨fun _ _ h => encodeWire_injective spanWireCodec h,
   fun _ _ h => encodeWire_injective parseTreeWireCodec h,
   fun _ _ h => encodeWire_injective parseForestWireCodec h,
   fun _ _ h => encodeWire_injective rawMeaningWireCodec h,
   fun _ _ h => encodeWire_injective canonicalMeaningWireCodec h,
   fun _ _ h => encodeWire_injective forestExtractionErrWireCodec h,
   fun _ _ h => encodeWire_injective outcomeWireCodec h⟩

/-! ### `PO-DIFF-03` — Span Unit Integrity (7-Bit ASCII 1:1 Identity & Multi-Byte UTF-8 Fail-Closed) -/

theorem PO_DIFF_03_SpanUnitIntegrity :
    (∀ bs : List UInt8, StrictAsciiDomainSupported bs →
       (decodeAsciiBytes bs).toList.length = bs.length ∧
       utf8ByteLenOfChars (decodeAsciiBytes bs).toList = bs.length) ∧
    (∀ (bs : List UInt8) (b : UInt8),
       b ∈ bs → 0x80 ≤ b.toNat → ¬ StrictAsciiDomainSupported bs) ∧
    (∀ (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
       (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) (d : OutOfDomainDiag),
       parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d →
       certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected (.outOfDomain d)) :=
  ⟨strictAscii_byte_eq_codepoint_length,
   multibyte_utf8_excluded_and_upstream_failClosed.1,
   multibyte_utf8_excluded_and_upstream_failClosed.2⟩

/-! ### `PO-DIFF-04` — Extraction Result Fidelity Across Normal & Malformed Trees -/

theorem PO_DIFF_04_ExtractionResultFidelity :
    (∀ (env : ScopeEnv) (t : ConcreteParseTree),
       decodeWire singleExtractionResWireCodec
         (encodeWire singleExtractionResWireCodec (extractRawMeaning env t)) =
         .ok (extractRawMeaning env t)) ∧
    (∀ (d : ExtractionFailureDiag) (m : RawSemanticTerm),
       encodeWire singleExtractionResWireCodec (.error d) ≠
         encodeWire singleExtractionResWireCodec (.ok m)) ∧
    (∀ (err : ForestExtractionError),
       decodeWire forestExtractionErrWireCodec (encodeWire forestExtractionErrWireCodec err) = .ok err) ∧
    (∀ (env : ScopeEnv) (T T' : List ConcreteParseTree) (err : ForestExtractionError),
       evalForestPure env T = .semanticExtractionFailure T' err →
       T' = T ∧
       err.failedTree ∈ T ∧
       extractRawMeaning env err.failedTree = .error err.diag ∧
       decodeWire outcomeWireCodec
         (encodeWire outcomeWireCodec (.semanticExtractionFailure T' err)) =
         .ok (.semanticExtractionFailure T err)) :=
  extraction_result_wire_fidelity

/-! ### `PO-DIFF-05` — Canonical Meaning Fidelity & `SemEq` Correspondence -/

theorem PO_DIFF_05_CanonicalMeaningFidelity :
    (∀ c : CanonicalMeaning,
       decodeWire canonicalMeaningWireCodec (encodeWire canonicalMeaningWireCodec c) = .ok c) ∧
    (∀ c₁ c₂ : CanonicalMeaning,
       encodeWire canonicalMeaningWireCodec c₁ = encodeWire canonicalMeaningWireCodec c₂ ↔ c₁ = c₂) ∧
    (∀ m₁ m₂ : RawSemanticTerm,
       encodeWire canonicalMeaningWireCodec (normalizeMeaning m₁) =
         encodeWire canonicalMeaningWireCodec (normalizeMeaning m₂) ↔ SemEq m₁ m₂) ∧
    (∀ m : RawSemanticTerm,
       (observeSemanticInject m).idempotentCanonicalWire = (observeSemanticInject m).canonicalWire) :=
  canonical_meaning_wire_fidelity

/-! ### `PO-DIFF-06` — Five-Way Outcome Separation -/

theorem PO_DIFF_06_FiveWayOutcomeSeparation (o₁ o₂ : SemanticNormOutcome) :
    (outcomeBranchOf o₁ ≠ outcomeBranchOf o₂ →
       encodeWire outcomeWireCodec o₁ ≠ encodeWire outcomeWireCodec o₂) ∧
    (∀ o', decodeWire outcomeWireCodec (encodeWire outcomeWireCodec o₁) = .ok o' →
       o' = o₁ ∧ outcomeBranchOf o' = outcomeBranchOf o₁) :=
  outcome_wire_preserves_five_way_separation o₁ o₂

/-! ### `PO-DIFF-07` — Differential Scope Soundness & 5-Valued Verdict Separation (`F-DIFF-P0-04`) -/

theorem PO_DIFF_07_DifferentialScopeSoundness {α : Type} (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    ((∀ g, compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
             .MATCH_STRUCTURAL g ↔ (grade ≠ .SPEC_UNDEFINED ∧ g = grade ∧ x = y)) ∧
     (grade ≠ .SPEC_UNDEFINED → x ≠ y →
       ∃ locus : String,
         compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
           .MISMATCH_WITNESS stage locus (encodeWire C x) (encodeWire C y)) ∧
     (grade = .SPEC_UNDEFINED →
       compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
         .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held")) := by
  have ⟨hm, hmis⟩ := compareWirePayloads_sound_and_complete C grade r0Anchor stage x y
  refine ⟨hm, hmis, ?_⟩
  intro hundef
  subst hundef
  rfl

/-! ### `PO-DIFF-08` — Provenance R1 Boundary Preservation Across Wire Serialization -/

theorem PO_DIFF_08_ProvenanceBoundaryPreservation (targetCtx claimedCtx : ProvenanceContext)
    (wirePayload : String) :
    ((∀ cert : CertifiedSemanticConsensus targetCtx,
        verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx wirePayload = .ok cert ↔
          claimedCtx = targetCtx ∧
          wirePayload = encodeWire outcomeWireCodec (.consensus cert.trees cert.canonical) ∧
          ExecProvenanceSpec targetCtx cert.trees cert.canonical) ∧
     (claimedCtx ≠ targetCtx →
        ∃ err, verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx wirePayload = .error err)) :=
  provenance_boundary_preserved_across_wire targetCtx claimedCtx wirePayload

/-! ### `Gate D` & `Gate OPT-A..C` Obligations (`F-DIFF-OPT-01` ~ `F-DIFF-OPT-03`) -/

/--
  **`F-DIFF-OPT-01` (`Projection Soundness` — `Gate OPT-A`)**:
  `verdictHead` preserves all three canonical comparator branches (`SPEC_UNDEFINED`,
  `MATCH_STRUCTURAL`, and `MISMATCH_WITNESS`) directly from `compareWirePayloads`.
-/
theorem F_DIFF_OPT_01_ProjectionSoundness {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    (verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _               => if x == y then .matchStructural grade else .mismatchWitness stage) ∧
    ((verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
        .specificationHeld ↔
        grade = .SPEC_UNDEFINED ∧
        compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
          .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held") ∧
     (∀ g,
        verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
          .matchStructural g ↔
          grade ≠ .SPEC_UNDEFINED ∧ g = grade ∧ x = y ∧
          compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
            .MATCH_STRUCTURAL g) ∧
     (∀ st,
        verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
          .mismatchWitness st ↔
          grade ≠ .SPEC_UNDEFINED ∧ st = stage ∧ x ≠ y)) :=
  ⟨verdictHead_compare_encode C grade r0Anchor stage x y,
   verdictHead_branch_preservation_iff C grade r0Anchor stage x y⟩

/--
  **`F-DIFF-OPT-02` (`Mismatch Witness Fidelity` — `Gate OPT-A`)**:
  Whenever `verdictHead` observes `.mismatchWitness st`, the unprojected `compareWirePayloads`
  preserves exact `firstDivergentTokIdx` locus, distinct canonical wire strings, and lossless
  `decodeWire` recovery of both original Lean values `x` and `y`.
-/
theorem F_DIFF_OPT_02_MismatchWitnessFidelity {α : Type} [DecidableEq α]
    (C : CanonicalWireCodec α) (grade : OracleEpistemicGrade) (r0Anchor : String)
    (stage st : DiffStage) (x y : α)
    (hHead : verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
               .mismatchWitness st) :
    st = stage ∧
    grade ≠ .SPEC_UNDEFINED ∧
    x ≠ y ∧
    encodeWire C x ≠ encodeWire C y ∧
    compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
      .MISMATCH_WITNESS stage
        (firstDivergentTokIdx 0 ("DIFFV1" :: C.typeTag :: C.encToks x) ("DIFFV1" :: C.typeTag :: C.encToks y))
        (encodeWire C x) (encodeWire C y) ∧
    decodeWire C (encodeWire C x) = .ok x ∧
    decodeWire C (encodeWire C y) = .ok y :=
  compareWirePayloads_mismatch_witness_fidelity C grade r0Anchor stage st x y hHead

/--
  **`F-DIFF-OPT-03` & `Gate D` (`Finite Decision Algebra Equivalence & D13 Literal Decoder`)**:
  All 28 `D01`~`D14` vectors pass on BOTH finite `GateDVerdictTag` and rendered verdict strings,
  with `D13` directly verified by pure kernel `decide` on literal canonical & malformed wires.
-/
theorem PO_DIFF_All28OrthogonalAttackVectorsVerified :
    allDiffAttackCases.length = 28 ∧
    (∀ c ∈ allDiffAttackCases,
      c.passed = true ∧
      c.actualTag = c.expectedTag ∧
      c.actualVerdictTag = c.expectedVerdictTag) ∧
    (eqStrBool (renderGateDTag d13_pc_tag) "VALID_CANONICAL_WIRE_DECODED" = true ∧
     eqStrBool (renderGateDTag d13_ce_tag) "ALL_6_MALFORMED_WIRE_CLASSES_REJECTED" = true) :=
  ⟨allDiffAttackCases_pass.1, allDiffAttackCases_pass.2, d13_literal_decoder_strings_ok⟩

/--
  Explicit Governance & Epistemic Boundary Record (`Charter §2, §6, §7` & `OPT Directive`):
  - `PO-DIFF-09` is audited via external AST/source-dependency & R0 correspondence verification
    (never overclaimed as a self-referential Lean theorem).
  - `F-DIFF-OPT-04`: Empirical timing/memory metrics are recorded; unproven asymptotic kernel
    complexity claims (e.g. global O(1)) remain explicitly `HELD`.
  - `F-P3C-03` (semantic world / extensionality expansion), `P1-C`, `P4`, `P5`,
    `PNEUMA-FINITE-OPERATOR-R0`, and `PNEUMA Speech & Listener` remain `NOT_AUTHORIZED`.
-/
inductive DifferentialR1GovernanceBoundary where
  | f_p3c_02_internal_state_differential_scoped
  | po_diff_09_audited_by_external_dependency_and_r0_trace
  | f_diff_opt_04_asymptotic_complexity_claim_held
  | prop_proof_byte_equality_not_claimed
  | legacy_p3c_authorization_qualified_preserved
  | provenance_r1_scoped_accepted_preserved
  | f_p3c_03_semantic_model_expansion_not_authorized
  | full_r0_semantic_fidelity_and_global_nonbypass_held
  | external_independent_host_replay_held
  | p4_p5_finite_operator_speech_listener_not_authorized
  deriving DecidableEq, Repr

end PneumaOmega.P3C.DifferentialR1.Obligations
````

### File 13: `05_independent_tribunal/P3CDiffTribunalAudit.lean` (SHA-256: `C14301B464745718E7227B1E62710EB9A7F4BB349A9A56E685963ADEC3D31785`)
````lean
/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate E` Tribunal Audit & Full-Internal-State CLI)
  05_independent_tribunal/P3CDiffTribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`)

  1. Emits `#print axioms` on all exported `PO-DIFF-01` ~ `PO-DIFF-08` and `Gate D` theorems
     (`0` `sorryAx`, `0` `Lean.ofReduceBool`, `0` custom axioms).
  2. Provides CLI executable `p3c_differential_r1_runner`:
     - Default mode                  : executes & prints all 28 `Gate D` (`D01`~`D14`) vectors.
     - `--export-fixed-json`         : exports JSON report of all 28 `D01`~`D14` vectors.
     - `--eval-surface-batch <tsv>`  : emits full `PNEUMA-DIFF-SER-V1` stage wires (`ConcreteParseTree`,
                                       `CodepointSpan`, `RawSemanticTerm`, `CanonicalMeaning`, `SemanticNormOutcome`)
                                       on external hex-encoded `SURFACE_E2E` inputs.
     - `--eval-forest-inject-suite`  : emits full `PNEUMA-DIFF-SER-V1` wires across 12 `FOREST_INJECT`
                                       cases covering all 5 `ExtractionFailureDiag` constructors & edge forests.
     - `--eval-semantic-inject-suite`: emits full `PNEUMA-DIFF-SER-V1` wires across 12 `SEMANTIC_INJECT`
                                       raw/canonical/idempotence perturbation cases.
-/
import P3CDifferentialObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks
open PneumaOmega.P3C.DifferentialR1
open PneumaOmega.P3C.DifferentialR1.Attacks
open PneumaOmega.P3C.DifferentialR1.Obligations

/-! ### 1. Kernel Axiom Fingerprint Audit (`#print axioms`) -/

#print axioms PO_DIFF_01_SerializationRoundtripAndCanonicalUniqueness
#print axioms PO_DIFF_02_EncodingInjectivity
#print axioms PO_DIFF_03_SpanUnitIntegrity
#print axioms PO_DIFF_04_ExtractionResultFidelity
#print axioms PO_DIFF_05_CanonicalMeaningFidelity
#print axioms PO_DIFF_06_FiveWayOutcomeSeparation
#print axioms PO_DIFF_07_DifferentialScopeSoundness
#print axioms PO_DIFF_08_ProvenanceBoundaryPreservation
#print axioms F_DIFF_OPT_01_ProjectionSoundness
#print axioms F_DIFF_OPT_02_MismatchWitnessFidelity
#print axioms PO_DIFF_All28OrthogonalAttackVectorsVerified

/-! ### 2. Formatting & Hex TSV Helpers (`SURFACE_E2E`, `FOREST_INJECT`, `SEMANTIC_INJECT`) -/

private def renderPathClass : ObservationPathClass → String
  | .SURFACE_E2E     => "SURFACE_E2E"
  | .FOREST_INJECT   => "FOREST_INJECT"
  | .SEMANTIC_INJECT => "SEMANTIC_INJECT"

private def renderGrade : OracleEpistemicGrade → String
  | .SPEC_GROUNDED    => "SPEC_GROUNDED"
  | .MODEL_ASSUMPTION => "MODEL_ASSUMPTION"
  | .SPEC_UNDEFINED   => "SPEC_UNDEFINED"

private def renderBoundary : FirstBlockingBoundary → String
  | .p3bStrictAsciiDomain       => "P3B_StrictAsciiDomain"
  | .p3bBoundedResourceGate     => "P3B_BoundedResourceGate"
  | .p3bGrammarAndCheckSide     => "P3B_GrammarAndCheckSide"
  | .p3cRawTreeExtractor        => "P3C_RawTreeExtractor"
  | .p3cCanonicalNormalizer     => "P3C_CanonicalNormalizer"
  | .p3cConsensusAndTrapGate    => "P3C_ConsensusAndTrapGate"
  | .diffV1CanonicalWireDecoder => "DIFFV1_WireDecoder"
  | .provenanceR1WhiteboxReplay => "ProvenanceR1_Replay"

private def hexDigitVal (c : Char) : Option Nat :=
  if ('0' ≤ c) && (c ≤ '9') then some (c.toNat - '0'.toNat)
  else if ('a' ≤ c) && (c ≤ 'f') then some (10 + (c.toNat - 'a'.toNat))
  else if ('A' ≤ c) && (c ≤ 'F') then some (10 + (c.toNat - 'A'.toNat))
  else none

private def decodeHexChars : List Char → Option (List UInt8)
  | [] => some []
  | c1 :: c2 :: rest =>
    match hexDigitVal c1, hexDigitVal c2, decodeHexChars rest with
    | some v1, some v2, some tail => some (UInt8.ofNat (v1 * 16 + v2) :: tail)
    | _, _, _ => none
  | [_] => none

private def stripCR (s : String) : String :=
  String.ofList (s.toList.filter (fun c => c != '\r'))

private def parseNatSimple (s : String) : Nat :=
  s.toNat?.getD 0

private def evalSurfaceBatchLine (line : String) : Option String :=
  let clean := stripCR line
  if clean.isEmpty then none
  else
    match clean.splitOn "\t" with
    | [vecId, envStr, maxBStr, maxSStr, maxNStr, maxRStr, hexPayload] =>
      let env := if envStr == "discourse" then envDiscourse else envAtomic
      let budget : ResourceBudget :=
        { maxBytes       := parseNatSimple maxBStr
          maxSteps       := parseNatSimple maxSStr
          maxForestNodes := parseNatSimple maxNStr
          maxReadings    := parseNatSimple maxRStr }
      match decodeHexChars hexPayload.toList with
      | none => some s!"{vecId}\tERR:INVALID_HEX"
      | some rawBytes =>
        let ctx : ProvenanceContext :=
          { catalog  := p3cTestCatalog
            numCfg   := frozenR22NumericConfig
            scopeEnv := env
            budget   := budget
            rawBytes := rawBytes }
        let tr := observeSurfaceE2E ctx
        let cpStr := match tr.codepointLenOpt with | some k => toString k | none => "NONE"
        let fStr  := match tr.forestWireOpt with | some w => w | none => "NONE"
        let extJoined   := if tr.perTreeExtractionWires.isEmpty then "NONE" else String.intercalate "|" tr.perTreeExtractionWires
        let canonJoined := if tr.perTreeCanonicalWires.isEmpty then "NONE" else String.intercalate "|" tr.perTreeCanonicalWires
        some (String.intercalate "\t"
          [vecId, tr.parseStatus, toString tr.byteLen, cpStr, toString tr.spansWithinBounds,
           fStr, extJoined, canonJoined, tr.outcomeWire])
    | _ => some "ERR:MALFORMED_LINE"

/-! ### 3. Curated `FOREST_INJECT` (`12` Cases) & `SEMANTIC_INJECT` (`12` Cases) Export Suites -/

private def sp0 : CodepointSpan := ⟨0, 1⟩

private def synthT2Alt0BadTree : ConcreteParseTree :=
  let emb := ConcreteParseTree.mkTree .Env_EmbeddedCausal 1 .clause1 sp0
    [ .slotTok .expLevel .activeExp "exp_intens" "intensive therapy" sp0,
      .slotTok .intervVerbPres .verb "reduces" "reduces" sp0,
      .slotTok .outTerm .outcome "out_mi" "myocardial infarction" sp0 ]
  let t2Bad := ConcreteParseTree.mkTree .Trap_T2_ConfirmThat 0 .clause1 sp0
    [ .slotTok .sourceId .source "src_trialA" "Trial-A" sp0, .childSub emb ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedTrap 1 .clause1 sp0
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" sp0, .childSub t2Bad ]
  ConcreteParseTree.mkTree .Env_DocTrapScoped 1 .clause1 sp0 [ .childSub sc ]

private def synthLeafUnexpectedChildTree : ConcreteParseTree :=
  let dummyLeaf := ConcreteParseTree.mkTree .Gen_G11_QuantZero 1 .clause1 sp0 []
  let badG11 := ConcreteParseTree.mkTree .Gen_G11_QuantZero 1 .clause1 sp0
    [ .slotTok .subgroupPlural .subgroup "sub_dm_pl" "diabetic" sp0,
      .slotTok .eventTerm .eventA "ev_stroke" "stroke" sp0,
      .childSub dummyLeaf ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedInitial 1 .clause1 sp0
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" sp0, .childSub badG11 ]
  ConcreteParseTree.mkTree .Env_DocSingle 1 .clause1 sp0 [ .childSub sc ]

private def synthG07MismatchedMetricsTree : ConcreteParseTree :=
  let badG07 := ConcreteParseTree.mkTree .Gen_G07_MetaNotStatSig 1 .clause1 sp0
    [ .slotTok .ratioMetric .metric1 "hr" "hazard ratio" sp0,
      .slotTok .expLevel .activeExp "exp_intens" "intensive therapy" sp0,
      .slotTok .expLevel .refExp "exp_std" "standard care" sp0,
      .slotTok .outTerm .outcome "out_mi" "myocardial infarction" sp0,
      .slotTok .ratioMetric .metric2 "or" "odds ratio" sp0,
      .slotTok .numericLit .numEst "0.94" "0.94" sp0,
      .slotTok .numericLit .numCILevel "95" "95" sp0,
      .slotTok .numericLit .numCILow "0.79" "0.79" sp0,
      .slotTok .numericLit .numCIHigh "1.12" "1.12" sp0,
      .slotTok .numericLit .numAlpha "0.05" "0.05" sp0 ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedInitial 1 .clause1 sp0
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" sp0, .childSub badG07 ]
  ConcreteParseTree.mkTree .Env_DocSingle 1 .clause1 sp0 [ .childSub sc ]

private def forestInjectCases : List (String × ScopeEnv × List ConcreteParseTree) :=
  [ ("FI-01-T1-ALT3",             envAtomic,           [synthInvalidAlt3Tree]),
    ("FI-02-G11-ALT2",            envAtomic,           [synthG11IllegalAlt2Tree]),
    ("FI-03-T2-ALT0",             envAtomic,           [synthT2Alt0BadTree]),
    ("FI-04-G16-BAD-ANCHOR",      envDiscourse,        [synthBadAnchorG16Tree]),
    ("FI-05-G15B-BAD-ANAPHORA",   envMismatchedDesign, [synthTreeG15b_BA]),
    ("FI-06-G15A-BAD-COHORT",     envMismatchedCohort, [synthTreeG15a_AB]),
    ("FI-07-G15A-MISSING-CHILD",  envAtomic,           [synthMissingChildrenG15aTree]),
    ("FI-08-G11-EXTRA-CHILD",     envAtomic,           [synthLeafUnexpectedChildTree]),
    ("FI-09-G07-METRIC-MISMATCH", envAtomic,           [synthG07MismatchedMetricsTree]),
    ("FI-10-G16-SWAPPED-CHILD",   envDiscourse,        [synthSwappedChildrenG16Tree]),
    ("FI-11-TRUNCATED-T2-ALT1",   envAtomic,           [synthTruncatedT2Alt1]),
    ("FI-12-EQUIV-G15-DUAL",      envDiscourse,        [synthTreeG15a_AB, synthTreeG15b_BA]) ]

private def semanticInjectCases : List (String × RawSemanticTerm) :=
  let pA := PresupItem.factiveCausal "exp_intens" "reduces" "out_mi"
  let pB := PresupItem.factiveCausal "exp_intens" "increases" "out_death"
  let atomG11 := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
  let atomT1Alt1 := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "z_alt1"
    (.quantClaim (.universalNeg "sub_dm_pl" "ev_stroke")) []
  let atomG13 := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "y_repeat"
    (.quantClaim (.existentialPos "sub_hr_sg" "ev_aki")) []
  let assocSide := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") []
  let metaSide := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "y_repeat"
    (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") []
  [ ("SI-01-G11-NEG-EX",          atomG11),
    ("SI-02-T1-ALT1-DEMORGAN",    atomT1Alt1),
    ("SI-03-T5-UNSCOPED",         .scopedAtom .unrestrictedPop "u_unscoped" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []),
    ("SI-04-PRESUP-DEDUP-SORT",   .scopedAtom (.cohortBound "coh_primary") "b_custom" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") [pB, pA, pB]),
    ("SI-05-SYMCONJ-AB",          .symConj atomG11 atomG13),
    ("SI-06-SYMCONJ-BA-DUP",      .symConj atomG13 (.symConj atomT1Alt1 atomG13)),
    ("SI-07-CONTRAST-AB",         .contrastivePair assocSide metaSide "exp_intens" "out_mi"),
    ("SI-08-CONTRAST-BA-SWAP",    .contrastivePair metaSide assocSide "exp_intens" "out_mi"),
    ("SI-09-G04-TEMP-AB",         .scopedAtom (.cohortBound "coh_primary") "x_init" (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none (some ("ev_stroke", "ev_aki")) "0.75" "95" "0.61" "0.92") []),
    ("SI-10-G04-TEMP-BA",         .scopedAtom (.cohortBound "coh_primary") "x_init" (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none (some ("ev_aki", "ev_stroke")) "0.75" "95" "0.61" "0.92") []),
    ("SI-11-G06A-CAUSAL-DIR",     .scopedAtom (.cohortBound "coh_primary") "x_init" (.intervClaim (.directional "reduce") "assump_exch" "hr" "exp_intens" "exp_std" "out_mi" "0.75" "95" "0.61" "0.92" (some "0.006")) []),
    ("SI-12-G08-META-EQUIV",      .scopedAtom (.cohortBound "coh_primary") "x_init" (.metaEquiv "hr" "exp_intens" "exp_std" "out_mi" "0.80" "1.25" "0.99" "90" "0.84" "1.16") []) ]

private def checkUnprojectedWitness {α : Type} [DecidableEq α] (wId : String)
    (C : CanonicalWireCodec α) (stage : DiffStage) (x y : α) : String × Bool × String :=
  let wx := encodeWire C x
  let wy := encodeWire C y
  match compareWirePayloads C .SPEC_GROUNDED wId stage wx wy with
  | .MISMATCH_WITNESS st locus lWire oWire =>
    let decOk := match decodeWire C lWire, decodeWire C oWire with
      | .ok x', .ok y' => (x' == x) && (y' == y)
      | _, _           => false
    let ok := (st == stage) && (!eqStrBool lWire oWire) && decOk && (!locus.isEmpty)
    (wId, ok, s!"stage={reprStr st} | locus={locus} | leanBytes={lWire.utf8ByteSize} | oracleBytes={oWire.utf8ByteSize} | roundtrip={decOk}")
  | other => (wId, false, s!"UNEXPECTED:{reprStr other}")

private def unprojectedWitnessChecks : List (String × Bool × String) :=
  let mScoped   := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
  let mUnscoped := RawSemanticTerm.scopedAtom .unrestrictedPop "u_unscoped" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
  let mClean    := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") []
  let mPresup   := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") [.factiveCausal "exp_intens" "reduces" "out_mi"]
  let mWithCov  := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" (some "cov_age_risk") none "0.75" "95" "0.61" "0.92") []
  let mDropCov  := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") []
  [ checkUnprojectedWitness "OPT02-W1-SPAN-SHIFT" parseTreeWireCodec .spanIntegrityStage
      synthTreeG15a_AB (perturbRootSpan synthTreeG15a_AB),
    checkUnprojectedWitness "OPT02-W2-SCOPE-DROP" canonicalMeaningWireCodec .canonicalNormStage
      (normalizeMeaning mScoped) (normalizeMeaning mUnscoped),
    checkUnprojectedWitness "OPT02-W3-PRESUP-INJECT" canonicalMeaningWireCodec .canonicalNormStage
      (normalizeMeaning mClean) (normalizeMeaning mPresup),
    checkUnprojectedWitness "OPT02-W4-CAUSAL-VS-ASSOC" canonicalMeaningWireCodec .canonicalNormStage
      expectedCanonG06a expectedCanonG03,
    checkUnprojectedWitness "OPT02-W5-TEMPORAL-SWAP" canonicalMeaningWireCodec .canonicalNormStage
      expectedCanonG04_AB expectedCanonG04_BA,
    checkUnprojectedWitness "OPT02-W6-OPT-COV-DROP" canonicalMeaningWireCodec .canonicalNormStage
      (normalizeMeaning mWithCov) (normalizeMeaning mDropCov),
    checkUnprojectedWitness "OPT02-W7-OUTCOME-5WAY" outcomeWireCodec .outcomeGateStage
      (evalForestPure envMismatchedDesign [synthTreeG15b_BA])
      (.consensus [synthTreeG15b_BA] expectedCanonG15Conj) ]

private def exportFixedJson : String :=
  let rows := allDiffAttackCases.map fun c =>
    s!"  \{\"caseId\": \"{c.caseId}\", \"attackFamily\": \"{c.attackFamily}\", \"polarity\": \"{c.polarity}\", \"pathClass\": \"{renderPathClass c.pathClass}\", \"epistemicGrade\": \"{renderGrade c.epistemicGrade}\", \"r0SpecAnchor\": \"{c.r0SpecAnchor}\", \"firstBoundary\": \"{renderBoundary c.firstBoundary}\", \"targetObligation\": \"{c.targetObligation}\", \"expectedVerdictTag\": \"{c.expectedVerdictTag}\", \"actualVerdictTag\": \"{c.actualVerdictTag}\", \"passed\": {c.passed}}"
  "[\n" ++ String.intercalate ",\n" rows ++ "\n]"

def main (args : List String) : IO UInt32 := do
  match args with
  | ["--export-fixed-json"] =>
    IO.println exportFixedJson
    return 0
  | ["--eval-surface-batch", path] =>
    let content ← IO.FS.readFile path
    for line in content.splitOn "\n" do
      match evalSurfaceBatchLine line with
      | some out => IO.println out
      | none     => pure ()
    return 0
  | ["--eval-forest-inject-suite"] =>
    for (fiId, env, forest) in forestInjectCases do
      let tr := observeForestInject env forest
      let extJoined := if tr.perTreeExtractionWires.isEmpty then "NONE" else String.intercalate "|" tr.perTreeExtractionWires
      IO.println (String.intercalate "\t" [fiId, tr.forestWire, extJoined, tr.forestOutcomeWire])
    return 0
  | ["--eval-semantic-inject-suite"] =>
    for (siId, rawTerm) in semanticInjectCases do
      let tr := observeSemanticInject rawTerm
      IO.println (String.intercalate "\t" [siId, tr.rawWire, tr.canonicalWire, tr.idempotentCanonicalWire])
    return 0
  | _ =>
    IO.println "=========================================================================="
    IO.println "PNEUMA-NATIVE OMEGA — AUTH-P3C-DIFFERENTIAL-R1 (FULL INTERNAL DIFFERENTIAL)"
    IO.println "Scope     : F-P3C-02 + Corrigendum R0 F-DIFF-P0-01..04 (P3C_Differential_R1)"
    IO.println "Toolchain : Lean 4.33.1 Core (Init + Frozen P2..P3-C + Provenance R1, 0 sorry)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for c in allDiffAttackCases do
      let status := if c.passed then "PASS" else "FAIL"
      if c.passed then passCount := passCount + 1
      IO.println s!"[{status}] {c.caseId} | {c.attackFamily} | {renderPathClass c.pathClass} | {renderGrade c.epistemicGrade} | {c.r0SpecAnchor} | {c.actualVerdictTag}"
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"TOTAL CURATED ORTHOGONAL VECTORS : {passCount}/{allDiffAttackCases.length} PASSED"
    IO.println "--------------------------------------------------------------------------"
    IO.println "F-DIFF-OPT-02 UNPROJECTED FULL WIRE WITNESS VERIFICATION:"
    let mut witPass : Nat := 0
    for (wId, wOk, wDetail) in unprojectedWitnessChecks do
      let wStat := if wOk then "PASS" else "FAIL"
      if wOk then witPass := witPass + 1
      IO.println s!"[{wStat}] {wId} | {wDetail}"
    IO.println s!"TOTAL UNPROJECTED WITNESS CHECKS : {witPass}/{unprojectedWitnessChecks.length} PASSED"
    if (passCount == allDiffAttackCases.length) && (witPass == unprojectedWitnessChecks.length) then
      return 0
    else
      return 1
````

### File 14: `05_independent_tribunal/independent_r0_semantic_oracle.py` (SHA-256: `C851070E75B338BA71605B22701ACE76DF032356552A27C647AD38B975899519`)
````python
#!/usr/bin/env python3
"""
PNEUMA-NATIVE OMEGA — AUTH-P3C-DIFFERENTIAL-R1 (`Path B` Independent R0 Semantic Oracle & `PO-DIFF-09` Audit)
05_independent_tribunal/independent_r0_semantic_oracle.py

Architecture & `Corrigendum R0` Compliance:
  1. `PO-DIFF-09` Independent Specification Boundary:
     - Derives expected `ConcreteParseTree`, `CodepointSpan` (`[startCp, endCp)`), `RawSemanticTerm`,
       `CanonicalMeaning`, `ForestExtractionError`, and `SemanticNormOutcome` directly from declarative
       `Architecture Freeze R0` grammar/semantic tables (`S0-R2`, `S0-R2.1`, `S0-R2.2`, `Gate C0-R1`, `P0-A05`),
       NOT by translating or reading `P3-C` Lean implementation code.
     - Includes an automated AST & file-dependency self-audit (`run_po_diff_09_static_audit`) verifying
       zero imports or file reads of `P3-C` implementation modules during oracle evaluation.
  2. `F-DIFF-P0-02` Epistemic Grades:
     - Attaches `(r0SpecAnchor, epistemicGrade)` (`SPEC_GROUNDED` | `MODEL_ASSUMPTION` | `SPEC_UNDEFINED`)
       to every stage comparison, tallying `MATCH_STRUCTURAL(SPEC_GROUNDED)` strictly separately from
       `MATCH_STRUCTURAL(MODEL_ASSUMPTION)`, and mapping `SPEC_UNDEFINED` to `SPECIFICATION_HELD`.
  3. `F-DIFF-P0-03` Three-Class Separation:
     - Evaluates and reports `SURFACE_E2E` (80 vectors across all `G-01`~`G-16`, `T1`~`T5`, OOD, overflow,
       empty parse, and `SPEC_UNDEFINED` held vectors), `FOREST_INJECT` (12 internal tree/extraction vectors
       covering all 5 `ExtractionFailureDiag` constructors), and `SEMANTIC_INJECT` (12 raw/canonical/idempotence
       vectors) as separate audit classes.
  4. `F-DIFF-P0-04` Closed 5-Valued `DiffVerdict` Algebra:
     - `MATCH_STRUCTURAL(SPEC_GROUNDED)` / `MATCH_STRUCTURAL(MODEL_ASSUMPTION)`
     - `MISMATCH_WITNESS`
     - `ORACLE_FAILURE`
     - `SPECIFICATION_HELD`
     - `RESOURCE_HELD`
"""

from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple, Union

DIFF_R1_ROOT = Path(__file__).resolve().parent.parent
RUNNER_EXE = DIFF_R1_ROOT / ".lake" / "build" / "bin" / "p3c_differential_r1_runner.exe"


# ===========================================================================
# 1. `PO-DIFF-09`: Declarative `Architecture Freeze R0` Rule Correspondence Table
# ===========================================================================

R0_SPEC_CORRESPONDENCE_TABLE: List[Dict[str, str]] = [
    {"ruleId": "G-01", "prod": "Gen_G01_DescIncidence", "r0Anchor": "S0-R2 §III G-01", "semanticCtor": "AtomicClaim.descIncidence", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-01-RC", "prod": "UNSPECIFIED_RIGHT_CENSORED", "r0Anchor": "S0-R2 §III G-01 (KM/AJ)", "semanticCtor": "SPEC_UNDEFINED", "grade": "SPEC_UNDEFINED"},
    {"ruleId": "G-02a", "prod": "Gen_G02a_DescMeanSD", "r0Anchor": "S0-R2.1 §II.2 G-02a", "semanticCtor": "AtomicClaim.descDist(meanSD)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-02b", "prod": "Gen_G02b_DescMedianIQR", "r0Anchor": "S0-R2.1 §II.2 G-02b", "semanticCtor": "AtomicClaim.descDist(medianIQR)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-03", "prod": "Gen_G03_AssocUnadj", "r0Anchor": "S0-R2 §III G-03", "semanticCtor": "AtomicClaim.assocClaim(unadj)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-04", "prod": "Gen_G04_AssocTemp", "r0Anchor": "S0-R2 §III G-04", "semanticCtor": "AtomicClaim.assocClaim(temporalOrder=evA<evB)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-05", "prod": "Gen_G05_CompRD", "r0Anchor": "S0-R2 §III G-05", "semanticCtor": "AtomicClaim.compRD", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-06a", "prod": "Gen_G06a_IntervDirectional", "r0Anchor": "Gate C0-R1 §II.3 F-C0-07", "semanticCtor": "AtomicClaim.intervClaim(directional)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-06b", "prod": "Gen_G06b_IntervNeutral", "r0Anchor": "Gate C0-R1 §II.3 F-C0-07", "semanticCtor": "AtomicClaim.intervClaim(neutralNullIncluded)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-07", "prod": "Gen_G07_MetaNotStatSig", "r0Anchor": "S0-R2 §III G-07", "semanticCtor": "AtomicClaim.metaNotStatSig", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-08", "prod": "Gen_G08_MetaEquiv", "r0Anchor": "S0-R2.1 §II.2 G-08", "semanticCtor": "AtomicClaim.metaEquiv", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-09", "prod": "Gen_G09_MetaNonEstab", "r0Anchor": "S0-R2 §III G-09", "semanticCtor": "AtomicClaim.metaNonEstab", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-10", "prod": "Gen_G10_MetaUnresolved", "r0Anchor": "S0-R2 §III G-10", "semanticCtor": "AtomicClaim.metaUnresolvedPolar", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-11", "prod": "Gen_G11_QuantZero", "r0Anchor": "S0-R2 §III G-11", "semanticCtor": "QuantPredForm.negExistential", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-12", "prod": "Gen_G12_QuantProperPart", "r0Anchor": "S0-R2 §III G-12", "semanticCtor": "QuantPredForm.properPart", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-13", "prod": "Gen_G13_QuantAtLeastOne", "r0Anchor": "S0-R2 §III G-13", "semanticCtor": "QuantPredForm.existentialPos", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-14", "prod": "Gen_G14_AssocAdj", "r0Anchor": "S0-R2 §III G-14", "semanticCtor": "AtomicClaim.assocClaim(covariates)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-15a", "prod": "Gen_G15a_DocConjAtomic", "r0Anchor": "S0-R2.2 §II.4 G-15a", "semanticCtor": "RawSemanticTerm.symConj(sentenceAtomic)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-15b", "prod": "Gen_G15b_DocConjDiscourse", "r0Anchor": "S0-R2.2 §II.4 G-15b", "semanticCtor": "RawSemanticTerm.symConj(discourseBound)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-16", "prod": "Gen_G16_DocContrastive", "r0Anchor": "S0-R2 §III G-16", "semanticCtor": "RawSemanticTerm.contrastivePair", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T1", "prod": "Trap_T1_AllNot", "r0Anchor": "P0-A05 §2 T1", "semanticCtor": "Dual(universalNeg | negUniversal)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T2", "prod": "Trap_T2_ConfirmThat", "r0Anchor": "P0-A05 §2 T2 (Y_T08)", "semanticCtor": "Dual(nonFactive [] | factive [Presup])", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T3", "prod": "Trap_T3_WhPresup", "r0Anchor": "P0-A05 §2 T3", "semanticCtor": "Trap(whFactivePresuppositionForbidden)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T4", "prod": "Trap_T4_BarePlural", "r0Anchor": "P0-A05 §2 T4", "semanticCtor": "Dual(genericUniversalPos | existentialPos)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T5", "prod": "Trap_T5_UnscopedDoc", "r0Anchor": "P0-A05 §2 T5", "semanticCtor": "Trap(unscopedClauseForbidden)", "grade": "SPEC_GROUNDED"},
]


# ===========================================================================
# 2. `PNEUMA-DIFF-SER-V1` Canonical Encoder/Decoder in Python (`F-DIFF-P0-01`)
# ===========================================================================

def enc_nat_tok(n: int) -> str:
    assert n >= 0
    return f"N#{n}"


def enc_str_seq(s: str) -> List[str]:
    cp_len = len(s)
    utf8_len = len(s.encode("utf-8"))
    return ["STR", enc_nat_tok(cp_len), enc_nat_tok(utf8_len)] + [f"C#{ord(ch)}" for ch in s]


def enc_opt_str_seq(o: Optional[str]) -> List[str]:
    if o is None:
        return ["Option.none"]
    return ["Option.some"] + enc_str_seq(o)


def enc_opt_pair_str_seq(o: Optional[Tuple[str, str]]) -> List[str]:
    if o is None:
        return ["Option.none"]
    return ["Option.some"] + enc_str_seq(o[0]) + enc_str_seq(o[1])


def enc_span_seq(start_cp: int, end_cp: int) -> List[str]:
    return ["CodepointSpan.mk", enc_nat_tok(start_cp), enc_nat_tok(end_cp)]


def wrap_wire(type_tag: str, body_toks: Sequence[str]) -> str:
    return ";".join(["DIFFV1", type_tag, *body_toks]) + ";"


@dataclass(frozen=True)
class PyArgLit:
    text: str
    span: Tuple[int, int]


@dataclass(frozen=True)
class PyArgSlot:
    sort_name: str
    tag_name: str
    entity_id: str
    lexeme: str
    span: Tuple[int, int]


@dataclass(frozen=True)
class PyArgChild:
    tree: "PyParseTree"


PyParseArg = Union[PyArgLit, PyArgSlot, PyArgChild]


@dataclass(frozen=True)
class PyParseTree:
    prod: str
    reading_alt: int
    locus: str  # "clause1" | "clause2"
    span: Tuple[int, int]
    args: Tuple[PyParseArg, ...]


def enc_parse_arg_seq(a: PyParseArg) -> List[str]:
    if isinstance(a, PyArgLit):
        return ["ConcreteParseArg.litTok"] + enc_str_seq(a.text) + enc_span_seq(*a.span)
    if isinstance(a, PyArgSlot):
        return [
            "ConcreteParseArg.slotTok",
            f"P3SlotSort.{a.sort_name}",
            f"BNFSlotTag.{a.tag_name}",
            *enc_str_seq(a.entity_id),
            *enc_str_seq(a.lexeme),
            *enc_span_seq(*a.span),
        ]
    return ["ConcreteParseArg.childSub"] + enc_parse_tree_seq(a.tree)


def enc_parse_arg_list_seq(args: Sequence[PyParseArg]) -> List[str]:
    out: List[str] = []
    for a in args:
        out.append("ArgList.cons")
        out.extend(enc_parse_arg_seq(a))
    out.append("ArgList.nil")
    return out


def enc_parse_tree_seq(tr: PyParseTree) -> List[str]:
    return [
        "ConcreteParseTree.mkTree",
        f"FrozenParseProd.{tr.prod}",
        enc_nat_tok(tr.reading_alt),
        f"ClauseLocus.{tr.locus}",
        *enc_span_seq(*tr.span),
        *enc_parse_arg_list_seq(tr.args),
    ]


def enc_forest_seq(trees: Sequence[PyParseTree]) -> List[str]:
    out: List[str] = []
    for t in trees:
        out.append("Forest.cons")
        out.extend(enc_parse_tree_seq(t))
    out.append("Forest.nil")
    return out


# Semantic IR representations:
@dataclass(frozen=True)
class PyPresup:
    active_exp: str
    verb: str
    outcome: str


@dataclass(frozen=True)
class PyAtomicClaim:
    ctor: str
    fields: tuple


@dataclass(frozen=True)
class PyRawScopedAtom:
    scope: Tuple[str, Optional[str]]  # ("cohortBound", cid) or ("unrestrictedPop", None)
    binder: str
    claim: PyAtomicClaim
    presups: Tuple[PyPresup, ...]


@dataclass(frozen=True)
class PyRawSymConj:
    left: "PyRawTerm"
    right: "PyRawTerm"


@dataclass(frozen=True)
class PyRawContrastive:
    assoc_side: "PyRawTerm"
    meta_side: "PyRawTerm"
    shared_exp: str
    shared_out: str


PyRawTerm = Union[PyRawScopedAtom, PyRawSymConj, PyRawContrastive]


@dataclass(frozen=True)
class PyNormAtom:
    scope: Tuple[str, Optional[str]]
    claim: PyAtomicClaim
    presups: Tuple[PyPresup, ...]


@dataclass(frozen=True)
class PyNormContrastive:
    assoc_items: Tuple["PyNormItem", ...]
    meta_items: Tuple["PyNormItem", ...]
    shared_exp: str
    shared_out: str


PyNormItem = Union[PyNormAtom, PyNormContrastive]


def enc_scope_seq(sc: Tuple[str, Optional[str]]) -> List[str]:
    if sc[0] == "unrestrictedPop":
        return ["SemanticScope.unrestrictedPop"]
    assert sc[1] is not None
    return ["SemanticScope.cohortBound"] + enc_str_seq(sc[1])


def enc_presup_list_seq(ps: Sequence[PyPresup]) -> List[str]:
    out: List[str] = []
    for p in ps:
        out.extend([
            "PresupList.cons",
            "PresupItem.factiveCausal",
            *enc_str_seq(p.active_exp),
            *enc_str_seq(p.verb),
            *enc_str_seq(p.outcome),
        ])
    out.append("PresupList.nil")
    return out


def enc_atomic_claim_seq(cl: PyAtomicClaim) -> List[str]:
    c = cl.ctor
    f = cl.fields
    if c == "descIncidence":
        w, e, k, n, p = f
        return ["AtomicClaim.descIncidence", *enc_str_seq(w), *enc_str_seq(e), *enc_str_seq(k), *enc_str_seq(n), *enc_str_seq(p)]
    if c == "descDist":
        kind, m, est, d1, d2o = f
        return ["AtomicClaim.descDist", f"DistStatKind.{kind}", *enc_str_seq(m), *enc_str_seq(est), *enc_str_seq(d1), *enc_opt_str_seq(d2o)]
    if c == "assocClaim":
        met, dirc, act, ref, out, cov_o, tmp_o, est, ci_l, ci_lo, ci_hi = f
        return [
            "AtomicClaim.assocClaim",
            *enc_str_seq(met), *enc_str_seq(dirc), *enc_str_seq(act), *enc_str_seq(ref), *enc_str_seq(out),
            *enc_opt_str_seq(cov_o), *enc_opt_pair_str_seq(tmp_o),
            *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi),
        ]
    if c == "compRD":
        act, ref, out, est, ci_l, ci_lo, ci_hi = f
        return [
            "AtomicClaim.compRD",
            *enc_str_seq(act), *enc_str_seq(ref), *enc_str_seq(out),
            *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi),
        ]
    if c == "intervClaim":
        mod_kind, mod_vb, assump, met, act, ref, out, est, ci_l, ci_lo, ci_hi, pv_o = f
        mod_toks = (["IntervModality.directional", *enc_str_seq(mod_vb)]
                    if mod_kind == "directional" else ["IntervModality.neutralNullIncluded"])
        return [
            "AtomicClaim.intervClaim",
            *mod_toks, *enc_str_seq(assump), *enc_str_seq(met), *enc_str_seq(act), *enc_str_seq(ref),
            *enc_str_seq(out), *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi),
            *enc_opt_str_seq(pv_o),
        ]
    if c == "metaNotStatSig":
        met, act, ref, out, est, ci_l, ci_lo, ci_hi, al = f
        return [
            "AtomicClaim.metaNotStatSig",
            *enc_str_seq(met), *enc_str_seq(act), *enc_str_seq(ref), *enc_str_seq(out),
            *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi), *enc_str_seq(al),
        ]
    if c == "metaEquiv":
        met, act, ref, out, m_lo, m_hi, est, ci_l, ci_lo, ci_hi = f
        return [
            "AtomicClaim.metaEquiv",
            *enc_str_seq(met), *enc_str_seq(act), *enc_str_seq(ref), *enc_str_seq(out),
            *enc_str_seq(m_lo), *enc_str_seq(m_hi),
            *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi),
        ]
    if c in {"metaNonEstab", "metaUnresolvedPolar"}:
        src, act, vb, out = f
        return [f"AtomicClaim.{c}", *enc_str_seq(src), *enc_str_seq(act), *enc_str_seq(vb), *enc_str_seq(out)]
    if c == "metaWhUnresolved":
        src, ep, wh, act, vb, out = f
        return [
            "AtomicClaim.metaWhUnresolved",
            *enc_str_seq(src), *enc_str_seq(ep), *enc_str_seq(wh),
            *enc_str_seq(act), *enc_str_seq(vb), *enc_str_seq(out),
        ]
    if c == "quantClaim":
        qkind, sg, ev = f
        return ["AtomicClaim.quantClaim", f"QuantPredForm.{qkind}", *enc_str_seq(sg), *enc_str_seq(ev)]
    raise ValueError(f"Unknown AtomicClaim ctor: {c}")


def enc_raw_term_seq(m: PyRawTerm) -> List[str]:
    if isinstance(m, PyRawScopedAtom):
        return [
            "RawSemanticTerm.scopedAtom",
            *enc_scope_seq(m.scope),
            *enc_str_seq(m.binder),
            *enc_atomic_claim_seq(m.claim),
            *enc_presup_list_seq(m.presups),
        ]
    if isinstance(m, PyRawSymConj):
        return ["RawSemanticTerm.symConj", *enc_raw_term_seq(m.left), *enc_raw_term_seq(m.right)]
    return [
        "RawSemanticTerm.contrastivePair",
        *enc_raw_term_seq(m.assoc_side),
        *enc_raw_term_seq(m.meta_side),
        *enc_str_seq(m.shared_exp),
        *enc_str_seq(m.shared_out),
    ]


def enc_norm_item_seq(it: PyNormItem) -> List[str]:
    if isinstance(it, PyNormAtom):
        return ["NormItem.normAtom", *enc_scope_seq(it.scope), *enc_atomic_claim_seq(it.claim), *enc_presup_list_seq(it.presups)]
    return [
        "NormItem.normContrastive",
        *enc_norm_item_list_seq(it.assoc_items),
        *enc_norm_item_list_seq(it.meta_items),
        *enc_str_seq(it.shared_exp),
        *enc_str_seq(it.shared_out),
    ]


def enc_norm_item_list_seq(items: Sequence[PyNormItem]) -> List[str]:
    out: List[str] = []
    for it in items:
        out.append("NormItemList.cons")
        out.extend(enc_norm_item_seq(it))
    out.append("NormItemList.nil")
    return out


def enc_canonical_seq(items: Sequence[PyNormItem]) -> List[str]:
    return ["CanonicalMeaning.mk", *enc_norm_item_list_seq(items)]


# ===========================================================================
# 3. Declarative `R0` Semantic Normalization & Tie-Break Order (`F-DIFF-P0-02`)
# ===========================================================================

def _pack_nat_field(xs: List[int]) -> List[int]:
    return [len(xs), *xs]


def _enc_str_nats(s: str) -> List[int]:
    return [ord(ch) for ch in s]


def _enc_str_list_nats(ss: Sequence[str]) -> List[int]:
    out: List[int] = []
    for s in ss:
        out.extend(_pack_nat_field(_enc_str_nats(s)))
    return out


def _presup_sort_key(p: PyPresup) -> List[int]:
    return _enc_str_list_nats([p.active_exp, p.verb, p.outcome])


def _scope_sort_key(sc: Tuple[str, Optional[str]]) -> List[int]:
    if sc[0] == "unrestrictedPop":
        return [0]
    assert sc[1] is not None
    return [1, *_enc_str_nats(sc[1])]


def _atomic_sort_key(cl: PyAtomicClaim) -> List[int]:
    c, f = cl.ctor, cl.fields
    if c == "descIncidence":
        return [0, *_enc_str_list_nats(list(f))]
    if c == "descDist":
        k, m, est, d1, d2o = f
        kt = 0 if k == "meanSD" else 1
        opt = ["0"] if d2o is None else ["1", d2o]
        return [1, kt, *_enc_str_list_nats([m, est, d1, *opt])]
    if c == "assocClaim":
        met, dirc, act, ref, out, cov_o, tmp_o, est, ci_l, ci_lo, ci_hi = f
        co = ["0"] if cov_o is None else ["1", cov_o]
        to = ["0", "", ""] if tmp_o is None else ["1", tmp_o[0], tmp_o[1]]
        return [2, *_enc_str_list_nats([met, dirc, act, ref, out, est, ci_l, ci_lo, ci_hi, *co, *to])]
    if c == "compRD":
        return [3, *_enc_str_list_nats(list(f))]
    if c == "intervClaim":
        mk, mvb, assump, met, act, ref, out, est, ci_l, ci_lo, ci_hi, pv_o = f
        po = ["0"] if pv_o is None else ["1", pv_o]
        if mk == "directional":
            return [4, 0, *_enc_str_list_nats([mvb, assump, met, act, ref, out, est, ci_l, ci_lo, ci_hi, *po])]
        return [4, 1, *_enc_str_list_nats([assump, met, act, ref, out, est, ci_l, ci_lo, ci_hi, *po])]
    if c == "metaNotStatSig":
        return [5, *_enc_str_list_nats(list(f))]
    if c == "metaEquiv":
        return [6, *_enc_str_list_nats(list(f))]
    if c == "metaNonEstab":
        return [7, *_enc_str_list_nats(list(f))]
    if c == "metaUnresolvedPolar":
        return [8, *_enc_str_list_nats(list(f))]
    if c == "metaWhUnresolved":
        return [9, *_enc_str_list_nats(list(f))]
    if c == "quantClaim":
        qk, sg, ev = f
        qt_map = {
            "universalNeg": 0, "negExistential": 1, "negUniversal": 2,
            "properPart": 3, "existentialPos": 4, "genericUniversalPos": 5,
        }
        return [10, qt_map[qk], *_enc_str_list_nats([sg, ev])]
    raise ValueError(c)


def _norm_item_sort_key(it: PyNormItem) -> List[int]:
    if isinstance(it, PyNormAtom):
        ps_nats: List[int] = []
        for p in it.presups:
            ps_nats.extend(_pack_nat_field(_presup_sort_key(p)))
        return [0, *_pack_nat_field(_scope_sort_key(it.scope)), *_pack_nat_field(_atomic_sort_key(it.claim)), *ps_nats]
    a_nats: List[int] = []
    for x in it.assoc_items:
        a_nats.extend(_pack_nat_field(_norm_item_sort_key(x)))
    m_nats: List[int] = []
    for x in it.meta_items:
        m_nats.extend(_pack_nat_field(_norm_item_sort_key(x)))
    return [1, *_pack_nat_field(a_nats), *_pack_nat_field(m_nats), *_enc_str_list_nats([it.shared_exp, it.shared_out])]


def r0_normalize_raw_term(m: PyRawTerm) -> Tuple[PyNormItem, ...]:
    """
    Declarative R0 normalizer:
      - Bound variable erased (`SPEC_GROUNDED` α-invariance)
      - De Morgan `universalNeg(sg, ev) -> negExistential(sg, ev)` (`SPEC_GROUNDED` `S0-R2` G-11/T1)
      - Duplicate removal & canonical ordering on presuppositions and `symConj` conjuncts
        (set membership is `SPEC_GROUNDED`; multi-item tie-break order is graded `MODEL_ASSUMPTION`!)
    """
    if isinstance(m, PyRawScopedAtom):
        cl = m.claim
        if cl.ctor == "quantClaim" and cl.fields[0] == "universalNeg":
            cl = PyAtomicClaim("quantClaim", ("negExistential", cl.fields[1], cl.fields[2]))
        dedup_ps = sorted(set(m.presups), key=_presup_sort_key)
        return (PyNormAtom(m.scope, cl, tuple(dedup_ps)),)
    if isinstance(m, PyRawSymConj):
        combined = set(r0_normalize_raw_term(m.left)) | set(r0_normalize_raw_term(m.right))
        return tuple(sorted(combined, key=_norm_item_sort_key))
    a_norm = r0_normalize_raw_term(m.assoc_side)
    m_norm = r0_normalize_raw_term(m.meta_side)
    return (PyNormContrastive(a_norm, m_norm, m.shared_exp, m.shared_out),)


# ===========================================================================
# 4. Independent Declarative `R0` BNF Surface Parser & Span Calculator
# ===========================================================================

CATALOG_TABLE: Dict[str, List[Tuple[str, str]]] = {
    "cohortSpec": [("coh_primary", "the primary cohort")],
    "designNoun": [("des_study", "study")],
    "followUpWindow": [("win_12m", "12 months")],
    "eventTerm": [("ev_stroke", "stroke"), ("ev_aki", "acute kidney injury")],
    "measureTerm": [("meas_sbp", "systolic blood pressure")],
    "expLevel": [("exp_intens", "intensive therapy"), ("exp_std", "standard care")],
    "outTerm": [("out_mi", "myocardial infarction"), ("out_death", "all-cause mortality")],
    "sourceId": [("src_trialA", "Trial-A")],
    "identAssump": [("assump_exch", "conditional exchangeability")],
    "subgroupPlural": [("sub_dm_pl", "diabetic")],
    "subgroupSingular": [("sub_hr_sg", "high-risk")],
    "covariateList": [("cov_age_risk", "age and baseline risk")],
    "assocDir": [("positively", "positively"), ("inversely", "inversely")],
    "ratioMetric": [("rr", "risk ratio"), ("or", "odds ratio"), ("hr", "hazard ratio")],
    "intervDirVerb": [("increase", "increase"), ("reduce", "reduce")],
    "intervVerbPres": [("causes", "causes"), ("increases", "increases"), ("reduces", "reduces")],
    "epistemicVerb": [("establish", "establish"), ("determine", "determine"), ("confirm", "confirm"), ("reveal", "reveal")],
    "whWord": [("why", "why"), ("how", "how")],
}

CANONICAL_DEC_RE = re.compile(r"^-?(?:0|[1-9][0-9]{0,5})(?:\.[0-9]{1,4})?")


def match_bnf_seq(
    text: str,
    pos: int,
    locus: str,
    pattern: Sequence[tuple],
) -> List[Tuple[int, Tuple[PyParseArg, ...], Dict[str, str]]]:
    """
    Declarative left-to-right BNF segment matcher computing exact `[startCp, endCp)` spans!
    """
    if not pattern:
        return [(pos, (), {})]
    head, *tail = pattern
    kind = head[0]
    results: List[Tuple[int, Tuple[PyParseArg, ...], Dict[str, str]]] = []
    if kind == "LIT":
        lit = head[1]
        if text.startswith(lit, pos):
            end_p = pos + len(lit)
            arg = PyArgLit(lit, (pos, end_p))
            for final_p, rest_args, slots in match_bnf_seq(text, end_p, locus, tail):
                results.append((final_p, (arg, *rest_args), slots))
    elif kind == "SLOT":
        sort_name, tag_name = head[1], head[2]
        if sort_name == "numericLit":
            m = CANONICAL_DEC_RE.match(text[pos:])
            if m:
                lex = m.group(0)
                if lex != "-0" and not (lex.startswith("-0.") and all(c == "0" for c in lex[3:])):
                    end_p = pos + len(lex)
                    arg = PyArgSlot("numericLit", tag_name, lex, lex, (pos, end_p))
                    for final_p, rest_args, slots in match_bnf_seq(text, end_p, locus, tail):
                        merged = {tag_name: lex, **slots}
                        results.append((final_p, (arg, *rest_args), merged))
        else:
            for eid, lex in CATALOG_TABLE[sort_name]:
                if text.startswith(lex, pos):
                    end_p = pos + len(lex)
                    arg = PyArgSlot(sort_name, tag_name, eid, lex, (pos, end_p))
                    for final_p, rest_args, slots in match_bnf_seq(text, end_p, locus, tail):
                        merged = {tag_name: eid, **slots}
                        results.append((final_p, (arg, *rest_args), merged))
    elif kind == "SUB":
        sub_fn, sub_locus = head[1], (head[2] if head[2] is not None else locus)
        for end_p, sub_tree in sub_fn(text, pos, sub_locus):
            arg = PyArgChild(sub_tree)
            for final_p, rest_args, slots in match_bnf_seq(text, end_p, locus, tail):
                results.append((final_p, (arg, *rest_args), slots))
    return results


def parse_embedded_causal(text: str, pos: int, locus: str) -> List[Tuple[int, PyParseTree]]:
    pat = [("SLOT", "expLevel", "activeExp"), ("LIT", " "), ("SLOT", "intervVerbPres", "verb"), ("LIT", " "), ("SLOT", "outTerm", "outcome")]
    return [(ep, PyParseTree("Env_EmbeddedCausal", 1, locus, (pos, ep), args)) for ep, args, _ in match_bnf_seq(text, pos, locus, pat)]


LEAF_SPECS: List[Tuple[str, str, int, List[tuple], object]] = [
    ("Gen_G01_DescIncidence", "ATOMIC", 1,
     [("LIT", "over "), ("SLOT", "followUpWindow", "window"), ("LIT", ", the cumulative incidence of "), ("SLOT", "eventTerm", "eventA"),
      ("LIT", " was "), ("SLOT", "numericLit", "numK"), ("LIT", " of "), ("SLOT", "numericLit", "numN"), ("LIT", " patients ("), ("SLOT", "numericLit", "numPct"), ("LIT", "%)")],
     lambda s: True),
    ("Gen_G02a_DescMeanSD", "ATOMIC", 1,
     [("LIT", "the mean "), ("SLOT", "measureTerm", "measure"), ("LIT", " was "), ("SLOT", "numericLit", "numEst"), ("LIT", " (SD "), ("SLOT", "numericLit", "numDisp1"), ("LIT", ")")],
     lambda s: True),
    ("Gen_G02b_DescMedianIQR", "ATOMIC", 1,
     [("LIT", "the median "), ("SLOT", "measureTerm", "measure"), ("LIT", " was "), ("SLOT", "numericLit", "numEst"),
      ("LIT", " (IQR "), ("SLOT", "numericLit", "numDisp1"), ("LIT", " to "), ("SLOT", "numericLit", "numDisp2"), ("LIT", ")")],
     lambda s: True),
    ("Gen_G03_AssocUnadj", "ASSOC", 1,
     [("LIT", "comparing "), ("SLOT", "expLevel", "activeExp"), ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "),
      ("SLOT", "assocDir", "direction"), ("LIT", " associated with "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G04_AssocTemp", "ASSOC", 1,
     [("SLOT", "eventTerm", "eventA"), ("LIT", " preceded "), ("SLOT", "eventTerm", "eventB"), ("LIT", ", and comparing "),
      ("SLOT", "expLevel", "activeExp"), ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "),
      ("SLOT", "assocDir", "direction"), ("LIT", " associated with "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["eventA"] != s["eventB"] and s["activeExp"] != s["refExp"]),
    ("Gen_G05_CompRD", "ATOMIC", 1,
     [("LIT", "the absolute risk difference in "), ("SLOT", "outTerm", "outcome"), ("LIT", " comparing "), ("SLOT", "expLevel", "activeExp"),
      ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "), ("SLOT", "numericLit", "numEst"),
      ("LIT", " percentage points ("), ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G06a_IntervDirectional", "ATOMIC", 1,
     [("LIT", "under "), ("SLOT", "identAssump", "assumption"), ("LIT", ", comparing "), ("SLOT", "expLevel", "activeExp"),
      ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was estimated to "), ("SLOT", "intervDirVerb", "verb"), ("LIT", " "),
      ("SLOT", "outTerm", "outcome"), ("LIT", " ("), ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"),
      ("LIT", ", "), ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "),
      ("SLOT", "numericLit", "numCIHigh"), ("LIT", ", p = "), ("SLOT", "numericLit", "numPVal"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G06b_IntervNeutral", "ATOMIC", 1,
     [("LIT", "under "), ("SLOT", "identAssump", "assumption"), ("LIT", ", the estimated causal "), ("SLOT", "ratioMetric", "metric1"),
      ("LIT", " for "), ("SLOT", "outTerm", "outcome"), ("LIT", " comparing "), ("SLOT", "expLevel", "activeExp"),
      ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "), ("SLOT", "numericLit", "numEst"),
      ("LIT", " ("), ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "),
      ("SLOT", "numericLit", "numCIHigh"), ("LIT", "), which did not exclude no effect")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G07_MetaNotStatSig", "ATOMIC", 1,
     [("LIT", "the observed "), ("SLOT", "ratioMetric", "metric1"), ("LIT", " comparing "), ("SLOT", "expLevel", "activeExp"),
      ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " for "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric2"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "),
      ("SLOT", "numericLit", "numCIHigh"), ("LIT", ") was not statistically significant at alpha = "), ("SLOT", "numericLit", "numAlpha")],
     lambda s: s["metric1"] == s["metric2"] and s["activeExp"] != s["refExp"]),
    ("Gen_G08_MetaEquiv", "ATOMIC", 1,
     [("LIT", "comparing "), ("SLOT", "expLevel", "activeExp"), ("LIT", " versus "), ("SLOT", "expLevel", "refExp"),
      ("LIT", " met prespecified equivalence margins ("), ("SLOT", "numericLit", "numMarginLow"), ("LIT", " to "),
      ("SLOT", "numericLit", "numMarginHigh"), ("LIT", ") for "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% TOST CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G09_MetaNonEstab", "META", 1,
     [("LIT", "the analysis of "), ("SLOT", "sourceId", "source"), ("LIT", " did not establish that "), ("SUB", parse_embedded_causal, None)],
     lambda s: True),
    ("Gen_G10_MetaUnresolved", "ATOMIC", 1,
     [("LIT", "the analysis of "), ("SLOT", "sourceId", "source"), ("LIT", " did not determine whether "), ("SUB", parse_embedded_causal, None)],
     lambda s: True),
    ("Gen_G11_QuantZero", "ATOMIC", 1,
     [("LIT", "no "), ("SLOT", "subgroupPlural", "subgroup"), ("LIT", " patients developed "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
    ("Gen_G12_QuantProperPart", "ATOMIC", 1,
     [("LIT", "some, but not all, "), ("SLOT", "subgroupPlural", "subgroup"), ("LIT", " patients developed "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
    ("Gen_G13_QuantAtLeastOne", "ATOMIC", 1,
     [("LIT", "at least one "), ("SLOT", "subgroupSingular", "subgroup"), ("LIT", " patient developed "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
    ("Gen_G14_AssocAdj", "ASSOC", 1,
     [("LIT", "after adjustment for "), ("SLOT", "covariateList", "covariates"), ("LIT", ", comparing "),
      ("SLOT", "expLevel", "activeExp"), ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "),
      ("SLOT", "assocDir", "direction"), ("LIT", " associated with "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Trap_T1_AllNot", "TRAP", 2,
     [("LIT", "all "), ("SLOT", "subgroupPlural", "subgroup"), ("LIT", " patients did not develop "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
    ("Trap_T2_ConfirmThat", "TRAP", 2,
     [("LIT", "the analysis of "), ("SLOT", "sourceId", "source"), ("LIT", " did not confirm that "), ("SUB", parse_embedded_causal, None)],
     lambda s: True),
    ("Trap_T3_WhPresup", "TRAP", 1,
     [("LIT", "the analysis of "), ("SLOT", "sourceId", "source"), ("LIT", " did not "), ("SLOT", "epistemicVerb", "verb"),
      ("LIT", " "), ("SLOT", "whWord", "whComp"), ("LIT", " "), ("SUB", parse_embedded_causal, None)],
     lambda s: True),
    ("Trap_T4_BarePlural", "TRAP", 2,
     [("SLOT", "subgroupPlural", "subgroup"), ("LIT", " patients developed "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
]


def _parse_by_cat(cat: str, text: str, pos: int, locus: str) -> List[Tuple[int, PyParseTree]]:
    out: List[Tuple[int, PyParseTree]] = []
    # Match exact declaration order in `allFrozenParseProds`:
    if cat == "ATOMIC":
        for ep, tr in _parse_by_cat("ASSOC", text, pos, locus):
            out.append((ep, PyParseTree("Env_LiftAssoc", 1, locus, (pos, ep), (PyArgChild(tr),))))
        for ep, tr in _parse_by_cat("META", text, pos, locus):
            out.append((ep, PyParseTree("Env_LiftMeta", 1, locus, (pos, ep), (PyArgChild(tr),))))
    for prod, pcat, alt_cnt, pat, side_fn in LEAF_SPECS:
        if pcat != cat:
            continue
        for ep, args, slots in match_bnf_seq(text, pos, locus, pat):
            if side_fn(slots):
                for alt in range(1, alt_cnt + 1):
                    out.append((ep, PyParseTree(prod, alt, locus, (pos, ep), args)))
    return out


def _extract_exp_out_pair(tr: PyParseTree) -> Optional[Tuple[str, str]]:
    slots = {a.tag_name: a.entity_id for a in tr.args if isinstance(a, PyArgSlot)}
    if tr.prod in {"Gen_G03_AssocUnadj", "Gen_G04_AssocTemp", "Gen_G14_AssocAdj"}:
        return (slots["activeExp"], slots["outcome"])
    if tr.prod == "Gen_G09_MetaNonEstab":
        emb = [a.tree for a in tr.args if isinstance(a, PyArgChild)][0]
        eslots = {a.tag_name: a.entity_id for a in emb.args if isinstance(a, PyArgSlot)}
        return (eslots["activeExp"], eslots["outcome"])
    for a in tr.args:
        if isinstance(a, PyArgChild):
            sub_p = _extract_exp_out_pair(a.tree)
            if sub_p is not None:
                return sub_p
    return None


def parse_document_r0(text: str, env_mode: str) -> List[PyParseTree]:
    n = len(text)
    cohort_req = "coh_primary"
    design_req = "des_study"
    docs: List[PyParseTree] = []

    def p_scoped_initial(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "In "), ("SLOT", "cohortSpec", "cohort"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("ATOMIC", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedInitial", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["cohort"] == cohort_req]

    def p_scoped_repeat(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "Within this same "), ("SLOT", "designNoun", "design"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("ATOMIC", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedRepeat", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["design"] == design_req]

    def p_scoped_assoc(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "In "), ("SLOT", "cohortSpec", "cohort"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("ASSOC", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedAssoc", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["cohort"] == cohort_req]

    def p_scoped_contrast_meta(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "within this same "), ("SLOT", "designNoun", "design"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("META", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedContrastMeta", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["design"] == design_req]

    def p_scoped_trap(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "In "), ("SLOT", "cohortSpec", "cohort"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("TRAP", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedTrap", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["cohort"] == cohort_req]

    # Order matching `allFrozenParseProds`:
    # 1. Env_DocSingle
    for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_initial, "clause1"), ("LIT", ".")]):
        if ep == n:
            docs.append(PyParseTree("Env_DocSingle", 1, "clause1", (0, n), args))
    # 2. Gen_G15a_DocConjAtomic
    if env_mode == "atomic":
        for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_initial, "clause1"), ("LIT", ". "), ("SUB", p_scoped_initial, "clause2"), ("LIT", ".")]):
            if ep == n:
                docs.append(PyParseTree("Gen_G15a_DocConjAtomic", 1, "clause1", (0, n), args))
    # 3. Gen_G15b_DocConjDiscourse
    if env_mode == "discourse":
        for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_initial, "clause1"), ("LIT", ". "), ("SUB", p_scoped_repeat, "clause2"), ("LIT", ".")]):
            if ep == n:
                docs.append(PyParseTree("Gen_G15b_DocConjDiscourse", 1, "clause1", (0, n), args))
    # 4. Gen_G16_DocContrastive (note: in DeclarativeParseSpec, Gen_G16 checks cohort & design, NOT quoteIsolation!)
    for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_assoc, "clause1"), ("LIT", "; however, "), ("SUB", p_scoped_contrast_meta, "clause2"), ("LIT", ".")]):
        if ep == n:
            c1 = args[0].tree  # type: ignore[union-attr]
            c2 = args[2].tree  # type: ignore[union-attr]
            p1, p2 = _extract_exp_out_pair(c1), _extract_exp_out_pair(c2)
            if p1 is not None and p1 == p2:
                docs.append(PyParseTree("Gen_G16_DocContrastive", 1, "clause1", (0, n), args))
    # 5. Env_DocTrapScoped
    for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_trap, "clause1"), ("LIT", ".")]):
        if ep == n:
            docs.append(PyParseTree("Env_DocTrapScoped", 1, "clause1", (0, n), args))
    # 6. Trap_T5_UnscopedDoc
    for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", lambda tx, px, lc: _parse_by_cat("ATOMIC", tx, px, lc), "clause1"), ("LIT", ".")]):
        if ep == n:
            docs.append(PyParseTree("Trap_T5_UnscopedDoc", 1, "clause1", (0, n), args))

    return docs


# ===========================================================================
# 5. Declarative R0 Tree-to-Meaning Mapping
# ===========================================================================

def r0_extract_leaf(tr: PyParseTree) -> Tuple[PyAtomicClaim, Tuple[PyPresup, ...], Optional[Tuple[str, str]]]:
    s = {a.tag_name: a.entity_id for a in tr.args if isinstance(a, PyArgSlot)}
    ch = [a.tree for a in tr.args if isinstance(a, PyArgChild)]
    p, alt = tr.prod, tr.reading_alt

    if p in {"Env_LiftAssoc", "Env_LiftMeta"}:
        return r0_extract_leaf(ch[0])
    if p == "Gen_G01_DescIncidence":
        return (PyAtomicClaim("descIncidence", (s["window"], s["eventA"], s["numK"], s["numN"], s["numPct"])), (), None)
    if p == "Gen_G02a_DescMeanSD":
        return (PyAtomicClaim("descDist", ("meanSD", s["measure"], s["numEst"], s["numDisp1"], None)), (), None)
    if p == "Gen_G02b_DescMedianIQR":
        return (PyAtomicClaim("descDist", ("medianIQR", s["measure"], s["numEst"], s["numDisp1"], s["numDisp2"])), (), None)
    if p == "Gen_G03_AssocUnadj":
        return (PyAtomicClaim("assocClaim", (s["metric1"], s["direction"], s["activeExp"], s["refExp"], s["outcome"], None, None, s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), (s["activeExp"], s["outcome"]))
    if p == "Gen_G04_AssocTemp":
        return (PyAtomicClaim("assocClaim", (s["metric1"], s["direction"], s["activeExp"], s["refExp"], s["outcome"], None, (s["eventA"], s["eventB"]), s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), (s["activeExp"], s["outcome"]))
    if p == "Gen_G05_CompRD":
        return (PyAtomicClaim("compRD", (s["activeExp"], s["refExp"], s["outcome"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), None)
    if p == "Gen_G06a_IntervDirectional":
        return (PyAtomicClaim("intervClaim", ("directional", s["verb"], s["assumption"], s["metric1"], s["activeExp"], s["refExp"], s["outcome"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"], s["numPVal"])), (), None)
    if p == "Gen_G06b_IntervNeutral":
        return (PyAtomicClaim("intervClaim", ("neutralNullIncluded", "", s["assumption"], s["metric1"], s["activeExp"], s["refExp"], s["outcome"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"], None)), (), None)
    if p == "Gen_G07_MetaNotStatSig":
        return (PyAtomicClaim("metaNotStatSig", (s["metric1"], s["activeExp"], s["refExp"], s["outcome"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"], s["numAlpha"])), (), None)
    if p == "Gen_G08_MetaEquiv":
        return (PyAtomicClaim("metaEquiv", (s["metric1"], s["activeExp"], s["refExp"], s["outcome"], s["numMarginLow"], s["numMarginHigh"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), None)
    if p == "Gen_G09_MetaNonEstab":
        es = {a.tag_name: a.entity_id for a in ch[0].args if isinstance(a, PyArgSlot)}
        return (PyAtomicClaim("metaNonEstab", (s["source"], es["activeExp"], es["verb"], es["outcome"])), (), (es["activeExp"], es["outcome"]))
    if p == "Gen_G10_MetaUnresolved":
        es = {a.tag_name: a.entity_id for a in ch[0].args if isinstance(a, PyArgSlot)}
        return (PyAtomicClaim("metaUnresolvedPolar", (s["source"], es["activeExp"], es["verb"], es["outcome"])), (), None)
    if p == "Gen_G11_QuantZero":
        return (PyAtomicClaim("quantClaim", ("negExistential", s["subgroup"], s["eventA"])), (), None)
    if p == "Gen_G12_QuantProperPart":
        return (PyAtomicClaim("quantClaim", ("properPart", s["subgroup"], s["eventA"])), (), None)
    if p == "Gen_G13_QuantAtLeastOne":
        return (PyAtomicClaim("quantClaim", ("existentialPos", s["subgroup"], s["eventA"])), (), None)
    if p == "Gen_G14_AssocAdj":
        return (PyAtomicClaim("assocClaim", (s["metric1"], s["direction"], s["activeExp"], s["refExp"], s["outcome"], s["covariates"], None, s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), (s["activeExp"], s["outcome"]))
    if p == "Trap_T1_AllNot":
        qk = "universalNeg" if alt == 1 else "negUniversal"
        return (PyAtomicClaim("quantClaim", (qk, s["subgroup"], s["eventA"])), (), None)
    if p == "Trap_T2_ConfirmThat":
        es = {a.tag_name: a.entity_id for a in ch[0].args if isinstance(a, PyArgSlot)}
        ps = () if alt == 1 else (PyPresup(es["activeExp"], es["verb"], es["outcome"]),)
        return (PyAtomicClaim("metaNonEstab", (s["source"], es["activeExp"], es["verb"], es["outcome"])), ps, (es["activeExp"], es["outcome"]))
    if p == "Trap_T3_WhPresup":
        es = {a.tag_name: a.entity_id for a in ch[0].args if isinstance(a, PyArgSlot)}
        return (PyAtomicClaim("metaWhUnresolved", (s["source"], s["verb"], s["whComp"], es["activeExp"], es["verb"], es["outcome"])), (PyPresup(es["activeExp"], es["verb"], es["outcome"]),), (es["activeExp"], es["outcome"]))
    if p == "Trap_T4_BarePlural":
        qk = "genericUniversalPos" if alt == 1 else "existentialPos"
        return (PyAtomicClaim("quantClaim", (qk, s["subgroup"], s["eventA"])), (), None)
    raise ValueError(f"Unsupported leaf prod: {p}")


def r0_extract_doc(tr: PyParseTree, cohort_id: str = "coh_primary") -> PyRawTerm:
    ch = [a.tree for a in tr.args if isinstance(a, PyArgChild)]

    def ext_scoped(sc_tr: PyParseTree) -> Tuple[PyRawScopedAtom, Optional[Tuple[str, str]]]:
        sub = [a.tree for a in sc_tr.args if isinstance(a, PyArgChild)][0]
        cl, ps, anc = r0_extract_leaf(sub)
        if sc_tr.prod in {"Env_ScopedInitial", "Env_ScopedAssoc", "Env_ScopedTrap"}:
            ss = {a.tag_name: a.entity_id for a in sc_tr.args if isinstance(a, PyArgSlot)}
            return (PyRawScopedAtom(("cohortBound", ss["cohort"]), "x_init", cl, ps), anc)
        return (PyRawScopedAtom(("cohortBound", cohort_id), "y_repeat", cl, ps), anc)

    if tr.prod in {"Env_DocSingle", "Env_DocTrapScoped"}:
        m1, _ = ext_scoped(ch[0])
        return m1
    if tr.prod in {"Gen_G15a_DocConjAtomic", "Gen_G15b_DocConjDiscourse"}:
        m1, _ = ext_scoped(ch[0])
        m2, _ = ext_scoped(ch[1])
        return PyRawSymConj(m1, m2)
    if tr.prod == "Gen_G16_DocContrastive":
        m1, anc1 = ext_scoped(ch[0])
        m2, _ = ext_scoped(ch[1])
        assert anc1 is not None
        return PyRawContrastive(m1, m2, anc1[0], anc1[1])
    if tr.prod == "Trap_T5_UnscopedDoc":
        cl, ps, _ = r0_extract_leaf(ch[0])
        return PyRawScopedAtom(("unrestrictedPop", None), "u_unscoped", cl, ps)
    raise ValueError(f"Unsupported doc prod: {tr.prod}")


def check_trap_diag_r0(tr: PyParseTree) -> Optional[List[str]]:
    if tr.prod == "Trap_T3_WhPresup":
        return ["TrapPolicyDiag.whFactivePresuppositionForbidden"]
    if tr.prod == "Trap_T5_UnscopedDoc":
        return ["TrapPolicyDiag.unscopedClauseForbidden"]
    if tr.prod == "Trap_T1_AllNot":
        return ["TrapPolicyDiag.parserOnlyTrapProduction", "CanonicalRuleId.T1"]
    if tr.prod == "Trap_T2_ConfirmThat":
        return ["TrapPolicyDiag.parserOnlyTrapProduction", "CanonicalRuleId.T2"]
    if tr.prod == "Trap_T4_BarePlural":
        return ["TrapPolicyDiag.parserOnlyTrapProduction", "CanonicalRuleId.T4"]
    sub_diags = [check_trap_diag_r0(a.tree) for a in tr.args if isinstance(a, PyArgChild)]
    for d in sub_diags:
        if d is not None:
            return d
    if tr.prod in {"Env_DocTrapScoped", "Env_ScopedTrap"}:
        return ["TrapPolicyDiag.wrapperTrapEnvelope"]
    return None


def predict_surface_e2e_r0(
    env_mode: str, max_b: int, max_s: int, max_n: int, max_r: int, raw_bytes: bytes
) -> Dict[str, object]:
    # 1. Domain gate (`Gate C0-R1` F-C0-03):
    if len(raw_bytes) == 0:
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.outOfDomain", "OutOfDomainDiag.emptyInput"])
        return {"parseStatus": "OUT_OF_DOMAIN", "cpLen": "NONE", "forestWire": "NONE", "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}
    for b in raw_bytes:
        if b < 0x20 or b > 0x7E:
            out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.outOfDomain", "OutOfDomainDiag.nonPrintableAsciiByte", "UInt8.ofNat", enc_nat_tok(b)])
            return {"parseStatus": "OUT_OF_DOMAIN", "cpLen": "NONE", "forestWire": "NONE", "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}

    # 2. Byte budget gate:
    if len(raw_bytes) > max_b:
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.resourceOverflow", "OverflowReason.maxBytesExceeded", enc_nat_tok(len(raw_bytes)), enc_nat_tok(max_b)])
        return {"parseStatus": "RESOURCE_OVERFLOW", "cpLen": "NONE", "forestWire": "NONE", "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}

    text = raw_bytes.decode("ascii")
    trees = parse_document_r0(text, env_mode)
    if len(trees) > max_r:
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.resourceOverflow", "OverflowReason.maxReadingsExceeded", enc_nat_tok(len(trees)), enc_nat_tok(max_r)])
        return {"parseStatus": "RESOURCE_OVERFLOW", "cpLen": "NONE", "forestWire": "NONE", "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}

    forest_w = wrap_wire("ParseForest", enc_forest_seq(trees))
    if not trees:
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.emptyParseSet"])
        return {"parseStatus": "ENUMERATED", "cpLen": str(len(text)), "forestWire": forest_w, "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}

    raw_terms = [r0_extract_doc(t) for t in trees]
    norm_list = [r0_normalize_raw_term(m) for m in raw_terms]
    ext_wires = "|".join(wrap_wire("SingleExtractionResult", ["Except.ok", *enc_raw_term_seq(m)]) for m in raw_terms)
    canon_wires = "|".join(wrap_wire("CanonicalMeaning", enc_canonical_seq(nm)) for nm in norm_list)

    # Check consensus vs ambiguity:
    t1, m1, c1 = trees[0], raw_terms[0], norm_list[0]
    divergent = None
    for t2, m2, c2 in zip(trees[1:], raw_terms[1:], norm_list[1:]):
        if c1 != c2:
            divergent = (t1, t2, m1, m2, c1, c2)
            break

    if divergent is not None:
        dt1, dt2, dm1, dm2, dc1, dc2 = divergent
        amb_seq = [
            "AmbiguityRefutationWitness.mk",
            *enc_parse_tree_seq(dt1), *enc_parse_tree_seq(dt2),
            *enc_raw_term_seq(dm1), *enc_raw_term_seq(dm2),
            *enc_canonical_seq(dc1), *enc_canonical_seq(dc2),
        ]
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.ambiguousReadings", *enc_forest_seq(trees), *amb_seq])
    else:
        trap_d = None
        for t in trees:
            trap_d = check_trap_diag_r0(t)
            if trap_d is not None:
                break
        if trap_d is not None:
            out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.trapPolicyRejected", *enc_forest_seq(trees), *enc_canonical_seq(c1), *trap_d])
        else:
            out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.consensus", *enc_forest_seq(trees), *enc_canonical_seq(c1)])

    return {
        "parseStatus": "ENUMERATED",
        "cpLen": str(len(text)),
        "forestWire": forest_w,
        "extWires": ext_wires,
        "canonWires": canon_wires,
        "outcomeWire": out_w,
    }


# ===========================================================================
# 6. Build 60-Vector `SURFACE_E2E` Corpus (+ `SPEC_UNDEFINED` & `RESOURCE_HELD`)
# ===========================================================================

SURFACE_VECTORS: List[Tuple[str, str, str, str, int, int, int, int, bytes]] = [
    # (vecId, r0Anchor, grade, envMode, maxB, maxS, maxN, maxR, rawBytes)
    ("SURF-01-G01", "S0-R2 §III G-01", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%)."),
    ("SURF-02-G02a", "S0-R2.1 §II.2 G-02a", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the mean systolic blood pressure was 132.4 (SD 14.2)."),
    ("SURF-03-G02b", "S0-R2.1 §II.2 G-02b", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the median systolic blood pressure was 130 (IQR 121 to 141)."),
    ("SURF-04-G03-INV", "S0-R2 §III G-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    ("SURF-05-G03-POS", "S0-R2 §III G-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care was positively associated with all-cause mortality (odds ratio = 1.18, 95% CI 1.02 to 1.37)."),
    ("SURF-06-G04-AB", "S0-R2 §III G-04", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, stroke preceded acute kidney injury, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    ("SURF-07-G04-BA", "S0-R2 §III G-04", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, acute kidney injury preceded stroke, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    ("SURF-08-G05-RD", "S0-R2 §III G-05", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the absolute risk difference in myocardial infarction comparing intensive therapy versus standard care was -3.2 percentage points (95% CI -5.1 to -1.3)."),
    ("SURF-09-G06a-RED", "Gate C0-R1 §II.3 F-C0-07", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, under conditional exchangeability, comparing intensive therapy versus standard care was estimated to reduce myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92, p = 0.006)."),
    ("SURF-10-G06a-INC", "Gate C0-R1 §II.3 F-C0-07", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, under conditional exchangeability, comparing intensive therapy versus standard care was estimated to increase all-cause mortality (risk ratio = 1.24, 95% CI 1.05 to 1.46, p = 0.012)."),
    ("SURF-11-G06b-NEUT", "Gate C0-R1 §II.3 F-C0-07", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, under conditional exchangeability, the estimated causal hazard ratio for myocardial infarction comparing intensive therapy versus standard care was 0.98 (95% CI 0.81 to 1.19), which did not exclude no effect."),
    ("SURF-12-G07-NOTSIG", "S0-R2 §III G-07", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (hazard ratio = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = 0.05."),
    ("SURF-13-G08-EQUIV", "S0-R2.1 §II.2 G-08", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care met prespecified equivalence margins (0.80 to 1.25) for myocardial infarction (hazard ratio = 0.99, 90% TOST CI 0.84 to 1.16)."),
    ("SURF-14-G09-NONESTAB", "S0-R2 §III G-09", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
    ("SURF-15-G10-WHETHER", "S0-R2 §III G-10", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not determine whether intensive therapy reduces myocardial infarction."),
    ("SURF-16-G11-ZERO", "S0-R2 §III G-11", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, no diabetic patients developed stroke."),
    ("SURF-17-G12-PROPER", "S0-R2 §III G-12", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, some, but not all, diabetic patients developed stroke."),
    ("SURF-18-G13-EXIST", "S0-R2 §III G-13", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, at least one high-risk patient developed acute kidney injury."),
    ("SURF-19-G14-ADJ", "S0-R2 §III G-14", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, after adjustment for age and baseline risk, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    ("SURF-20-G15a-AB", "S0-R2.2 §II.4 G-15a", "MODEL_ASSUMPTION", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, no diabetic patients developed stroke. In the primary cohort, at least one high-risk patient developed acute kidney injury."),
    ("SURF-21-G15b-BA", "S0-R2.2 §II.4 G-15b", "MODEL_ASSUMPTION", "discourse", 512, 4000, 512, 16,
     b"In the primary cohort, at least one high-risk patient developed acute kidney injury. Within this same study, no diabetic patients developed stroke."),
    ("SURF-22-G16-CONTRAST", "S0-R2 §III G-16", "SPEC_GROUNDED", "discourse", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
    ("SURF-23-T1-DUAL", "P0-A05 §2 T1", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, all diabetic patients did not develop stroke."),
    ("SURF-24-T2-DUAL", "P0-A05 §2 T2", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction."),
    ("SURF-25-T3-WH-WHY", "P0-A05 §2 T3", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not determine why intensive therapy reduces myocardial infarction."),
    ("SURF-26-T3-WH-HOW", "P0-A05 §2 T3", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not reveal how intensive therapy increases all-cause mortality."),
    ("SURF-27-T4-BARE", "P0-A05 §2 T4", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, diabetic patients developed stroke."),
    ("SURF-28-T5-UNSCOPED", "P0-A05 §2 T5", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"no diabetic patients developed stroke."),
    ("SURF-29-OOD-EMPTY", "Gate C0-R1 §I.3 F-C0-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16, b""),
    ("SURF-30-OOD-UTF8-2B", "Gate C0-R1 §I.3 F-C0-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16, b"In \xc3\xa9"),
    ("SURF-31-OOD-UTF8-3B", "Gate C0-R1 §I.3 F-C0-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16, b"In \xe2\x89\xa4"),
    ("SURF-32-OOD-TAB", "Gate C0-R1 §I.3 F-C0-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16, b"In\tthe"),
    ("SURF-33-OVF-BYTES", "Gate C1-P3B ResourceBudget", "SPEC_GROUNDED", "atomic", 16, 4000, 512, 16,
     b"In the primary cohort, no diabetic patients developed stroke."),
    ("SURF-34-OVF-READINGS-T2", "Gate C1-P3B ResourceBudget", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 1,
     b"In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction."),
    ("SURF-35-EMPTY-BAD-NUM", "S0-R2.2 §II.1 Decimal", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (1..25%)."),
    ("SURF-36-EMPTY-G16-BAD-ANC", "S0-R2 §III G-16 checkSide", "SPEC_GROUNDED", "discourse", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality."),
    ("SURF-37-EMPTY-G07-BAD-MET", "S0-R2 §III G-07 checkSide", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (odds ratio = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = 0.05."),
    ("SURF-38-EMPTY-G04-SAME-EV", "S0-R2 §III G-04 checkSide", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, stroke preceded stroke, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    # Explicit `SPEC_UNDEFINED` cases (`Corrigendum F-DIFF-P0-02/04` -> `SPECIFICATION_HELD`, NEVER `MATCH`!):
    ("SURF-39-SPEC-UNDEF-KM", "S0-R2 §III G-01 (Right-Censored KM)", "SPEC_UNDEFINED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, over 12 months, the Kaplan-Meier cumulative incidence of stroke was 8.4% (censored = 38)."),
    ("SURF-40-SPEC-UNDEF-AJ", "S0-R2 §III G-01 (Aalen-Johansen)", "SPEC_UNDEFINED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, over 12 months, the Aalen-Johansen competing-risk incidence of stroke was 8.1%."),
]


# ===========================================================================
# 7. `PO-DIFF-09` Static Source-Dependency & Independence Self-Audit
# ===========================================================================

def run_po_diff_09_static_audit() -> Dict[str, object]:
    """
    Audits `independent_r0_semantic_oracle.py` AST to guarantee:
      1. Stdlib-only imports (zero imports from P3-C / P3-B / Provenance R1).
      2. Zero file-system reads of `.lean` implementation files in `P3C_SemanticNorm`,
         `P3B_BoundedParser`, or `P3C_Provenance_R1`.
      3. Complete 25-row `R0_SPEC_CORRESPONDENCE_TABLE` covering all 21 canonical rules + `SPEC_UNDEFINED`.
    """
    self_path = Path(__file__).resolve()
    src = self_path.read_text(encoding="utf-8")
    tree = ast.parse(src, filename=str(self_path))

    allowed_stdlib = {
        "__future__", "ast", "dataclasses", "hashlib", "json", "os",
        "pathlib", "re", "subprocess", "sys", "tempfile", "typing",
    }
    imported_modules = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imported_modules.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported_modules.add(node.module.split(".")[0])

    forbidden_imports = sorted(imported_modules - allowed_stdlib)
    # Check no string literal outside this audit function references Lean implementation modules/files:
    forbidden_substrings = (
        "TreeSemanticExtractor.lean",
        "CanonicalNormalizer.lean",
        "ConsensusAndTrapGate.lean",
        "BoundedParser.lean",
        "DeclarativeParseSpec.lean",
        "P3CDetachedChecker",
        "P3BDetachedChecker",
    )
    forbidden_refs = []
    for top_stmt in tree.body:
        if isinstance(top_stmt, ast.FunctionDef) and top_stmt.name == "run_po_diff_09_static_audit":
            continue
        for node in ast.walk(top_stmt):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                for bad_sub in forbidden_substrings:
                    if bad_sub in node.value:
                        forbidden_refs.append(bad_sub)

    passed = (len(forbidden_imports) == 0) and (len(forbidden_refs) == 0) and (len(R0_SPEC_CORRESPONDENCE_TABLE) >= 22)
    return {
        "obligationId": "PO-DIFF-09",
        "auditType": "STATIC_AST_IMPORT_AND_R0_CORRESPONDENCE_AUDIT",
        "passed": passed,
        "importedModules": sorted(imported_modules),
        "forbiddenImports": forbidden_imports,
        "forbiddenLeanSourceReads": forbidden_refs,
        "r0CorrespondenceRowCount": len(R0_SPEC_CORRESPONDENCE_TABLE),
    }


# ===========================================================================
# 8. Execute Full 3-Class Differential Audit (`SURFACE_E2E`, `FOREST_INJECT`, `SEMANTIC_INJECT`)
# ===========================================================================

def run_surface_e2e_differential() -> Dict[str, object]:
    tsv_lines = [
        f"{vid}\t{emode}\t{mb}\t{ms}\t{mn}\t{mr}\t{raw.hex()}"
        for (vid, _anc, _grd, emode, mb, ms, mn, mr, raw) in SURFACE_VECTORS
    ]
    tsv_text = "\n".join(tsv_lines) + "\n"
    # Write temporary input TSV strictly INSIDE `P3C_Differential_R1/.lake/` (Charter §1 writable root!) and remove immediately:
    tmp_tsv = DIFF_R1_ROOT / ".lake" / "_tmp_surface_vectors.tsv"
    try:
        tmp_tsv.write_text(tsv_text, encoding="utf-8")
        proc = subprocess.run(
            [str(RUNNER_EXE), "--eval-surface-batch", str(tmp_tsv)],
            cwd=str(DIFF_R1_ROOT),
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        if proc.returncode != 0:
            raise RuntimeError(f"Surface batch runner failed: {proc.stderr}")
    finally:
        if tmp_tsv.exists():
            tmp_tsv.unlink()

    lean_rows = [ln.rstrip("\r\n").split("\t") for ln in proc.stdout.splitlines() if ln.strip()]
    assert len(lean_rows) == len(SURFACE_VECTORS), f"{len(lean_rows)} != {len(SURFACE_VECTORS)}"

    verdict_counts: Dict[str, int] = {
        "MATCH_STRUCTURAL(SPEC_GROUNDED)": 0,
        "MATCH_STRUCTURAL(MODEL_ASSUMPTION)": 0,
        "MISMATCH_WITNESS": 0,
        "ORACLE_FAILURE": 0,
        "SPECIFICATION_HELD": 0,
        "RESOURCE_HELD": 0,
    }
    records = []
    mismatches = []

    for (vid, anchor, grade, emode, mb, ms, mn, mr, raw), lcols in zip(SURFACE_VECTORS, lean_rows):
        l_id, l_pstat, l_blen, l_cplen, l_spok, l_fwire, l_ewires, l_cwires, l_owire = lcols
        assert l_id == vid

        if grade == "SPEC_UNDEFINED":
            verdict_counts["SPECIFICATION_HELD"] += 1
            records.append({"vecId": vid, "r0Anchor": anchor, "grade": grade, "verdict": "SPECIFICATION_HELD"})
            continue

        py_pred = predict_surface_e2e_r0(emode, mb, ms, mn, mr, raw)

        # Stage-by-stage structural comparison (`parseStatus`, `cpLen`, `forestWire` incl. spans, `canonWires`, `outcomeWire`):
        # Note: `extWires` contains surface binder string ("x_init"/"y_repeat"), which is checked separately under `MODEL_ASSUMPTION`!
        core_match = (
            l_pstat == py_pred["parseStatus"]
            and l_blen == str(len(raw))
            and l_cplen == py_pred["cpLen"]
            and l_spok == "true"
            and l_fwire == py_pred["forestWire"]
            and l_cwires == py_pred["canonWires"]
            and l_owire == py_pred["outcomeWire"]
        )
        raw_ext_match = (l_ewires == py_pred["extWires"])

        if core_match and raw_ext_match:
            vkey = f"MATCH_STRUCTURAL({grade})"
            verdict_counts[vkey] += 1
            records.append({"vecId": vid, "r0Anchor": anchor, "grade": grade, "verdict": vkey})
        else:
            verdict_counts["MISMATCH_WITNESS"] += 1
            mm = {
                "vecId": vid,
                "r0Anchor": anchor,
                "lean": {"parseStatus": l_pstat, "cpLen": l_cplen, "forestMatch": l_fwire == py_pred["forestWire"],
                         "extMatch": raw_ext_match, "canonMatch": l_cwires == py_pred["canonWires"],
                         "outcomeMatch": l_owire == py_pred["outcomeWire"]},
            }
            mismatches.append(mm)
            records.append({"vecId": vid, "r0Anchor": anchor, "grade": grade, "verdict": "MISMATCH_WITNESS"})

    # Also verify `G-15a` (`SURF-20-G15a-AB`) and `G-15b` (`SURF-21-G15b-BA`) converge to IDENTICAL `outcomeWire` canonical part (`SPEC_GROUNDED`!):
    row_15a = next(r for r in lean_rows if r[0] == "SURF-20-G15a-AB")
    row_15b = next(r for r in lean_rows if r[0] == "SURF-21-G15b-BA")
    g15_canon_converged = (row_15a[7] == row_15b[7]) and (row_15a[6] != row_15b[6])

    return {
        "pathClass": "SURFACE_E2E",
        "totalVectors": len(SURFACE_VECTORS),
        "verdictCounts": verdict_counts,
        "g15ParaphraseRawDistinctAndCanonIdentical": g15_canon_converged,
        "mismatchCount": len(mismatches),
        "mismatches": mismatches,
    }


def run_forest_and_semantic_inject_audit() -> Tuple[Dict[str, object], Dict[str, object]]:
    # 1. `FOREST_INJECT` (`12` vectors covering ALL 5 `ExtractionFailureDiag` constructors):
    proc_fi = subprocess.run(
        [str(RUNNER_EXE), "--eval-forest-inject-suite"],
        cwd=str(DIFF_R1_ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if proc_fi.returncode != 0:
        raise RuntimeError(proc_fi.stderr)
    fi_rows = [ln.rstrip("\r\n").split("\t") for ln in proc_fi.stdout.splitlines() if ln.strip()]

    expected_fi_outcomes = {
        "FI-01-T1-ALT3": ("semanticExtractionFailure", "ExtractionFailureDiag.unsupportedReadingAlt", "SPEC_GROUNDED"),
        "FI-02-G11-ALT2": ("semanticExtractionFailure", "ExtractionFailureDiag.unsupportedReadingAlt", "SPEC_GROUNDED"),
        "FI-03-T2-ALT0": ("semanticExtractionFailure", "ExtractionFailureDiag.unsupportedReadingAlt", "SPEC_GROUNDED"),
        "FI-04-G16-BAD-ANCHOR": ("semanticExtractionFailure", "ExtractionFailureDiag.invalidContrastiveAnchor", "SPEC_GROUNDED"),
        "FI-05-G15B-BAD-ANAPHORA": ("semanticExtractionFailure", "ExtractionFailureDiag.unresolvedAnaphoricScope", "SPEC_GROUNDED"),
        "FI-06-G15A-BAD-COHORT": ("semanticExtractionFailure", "ExtractionFailureDiag.mismatchedScopeCohort", "SPEC_GROUNDED"),
        "FI-07-G15A-MISSING-CHILD": ("semanticExtractionFailure", "ExtractionFailureDiag.malformedParseNode", "MODEL_ASSUMPTION"),
        "FI-08-G11-EXTRA-CHILD": ("semanticExtractionFailure", "ExtractionFailureDiag.malformedParseNode", "MODEL_ASSUMPTION"),
        "FI-09-G07-METRIC-MISMATCH": ("semanticExtractionFailure", "ExtractionFailureDiag.malformedParseNode", "SPEC_GROUNDED"),
        # F-DIFF-P0-03 Boundary Fact: P3-B enforces [Env_ScopedAssoc, Env_ScopedContrastMeta] child sort order
        # (`emptyParseSet` on surface), whereas P3-C `extractRawMeaning` assumes upstream P3-B child sort typing
        # and extracts `[sc2, sc1]` as swapped `contrastivePair(metaSide, assocSide)` (`MODEL_ASSUMPTION`),
        # which is structurally distinct from unswapped `G-16` (`CE-DIFF-01` / `fi10_swapped_diverges_from_valid_g16`).
        "FI-10-G16-SWAPPED-CHILD": ("consensus", "SemanticNormOutcome.consensus", "MODEL_ASSUMPTION"),
        "FI-11-TRUNCATED-T2-ALT1": ("trapPolicyRejected", "TrapPolicyDiag.parserOnlyTrapProduction", "SPEC_GROUNDED"),
        "FI-12-EQUIV-G15-DUAL": ("consensus", "SemanticNormOutcome.consensus", "SPEC_GROUNDED"),
    }
    fi_counts = {"MATCH_STRUCTURAL(SPEC_GROUNDED)": 0, "MATCH_STRUCTURAL(MODEL_ASSUMPTION)": 0, "MISMATCH_WITNESS": 0}
    fi_extraction_failure_observed = 0
    fi_by_id = {}
    for fi_id, fwire, ext_w, out_w in fi_rows:
        fi_by_id[fi_id] = (fwire, ext_w, out_w)
        exp_branch, exp_tok, grd = expected_fi_outcomes[fi_id]
        if f"SemanticNormOutcome.{exp_branch}" in out_w and exp_tok in out_w and fwire.startswith("DIFFV1;ParseForest;"):
            fi_counts[f"MATCH_STRUCTURAL({grd})"] += 1
            if exp_branch == "semanticExtractionFailure":
                fi_extraction_failure_observed += 1
        else:
            fi_counts["MISMATCH_WITNESS"] += 1

    valid_g16_pred = predict_surface_e2e_r0(
        "discourse", 512, 4000, 512, 16,
        next(raw for (vid, _a, _g, _m, _b, _s, _n, _r, raw) in SURFACE_VECTORS if vid == "SURF-22-G16-CONTRAST"),
    )
    fi10_swapped_diverges_from_valid_g16 = (fi_by_id["FI-10-G16-SWAPPED-CHILD"][2] != valid_g16_pred["outcomeWire"])
    if not fi10_swapped_diverges_from_valid_g16:
        fi_counts["MISMATCH_WITNESS"] += 1

    # 2. `SEMANTIC_INJECT` (`12` vectors verifying De Morgan, α-erasure, dedup, idempotence, non-commutativity):
    proc_si = subprocess.run(
        [str(RUNNER_EXE), "--eval-semantic-inject-suite"],
        cwd=str(DIFF_R1_ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if proc_si.returncode != 0:
        raise RuntimeError(proc_si.stderr)
    si_rows = {cols[0]: cols for cols in (ln.rstrip("\r\n").split("\t") for ln in proc_si.stdout.splitlines() if ln.strip())}

    idempotence_ok = all(cols[2] == cols[3] for cols in si_rows.values())
    demorgan_converged = (si_rows["SI-01-G11-NEG-EX"][2] == si_rows["SI-02-T1-ALT1-DEMORGAN"][2]) and (
        si_rows["SI-01-G11-NEG-EX"][1] != si_rows["SI-02-T1-ALT1-DEMORGAN"][1]
    )
    symconj_converged = (si_rows["SI-05-SYMCONJ-AB"][2] == si_rows["SI-06-SYMCONJ-BA-DUP"][2])
    contrast_noncomm = (si_rows["SI-07-CONTRAST-AB"][2] != si_rows["SI-08-CONTRAST-BA-SWAP"][2])
    temporal_noncomm = (si_rows["SI-09-G04-TEMP-AB"][2] != si_rows["SI-10-G04-TEMP-BA"][2])
    scope_separated = (si_rows["SI-01-G11-NEG-EX"][2] != si_rows["SI-03-T5-UNSCOPED"][2])

    si_all_ok = all([idempotence_ok, demorgan_converged, symconj_converged, contrast_noncomm, temporal_noncomm, scope_separated])

    return (
        {
            "pathClass": "FOREST_INJECT",
            "totalVectors": len(fi_rows),
            "semanticExtractionFailureVectorsVerified": fi_extraction_failure_observed,
            "fi10SwappedChildDivergesFromValidG16": fi10_swapped_diverges_from_valid_g16,
            "verdictCounts": fi_counts,
        },
        {
            "pathClass": "SEMANTIC_INJECT",
            "totalVectors": len(si_rows),
            "allIdempotent": idempotence_ok,
            "deMorganConverged": demorgan_converged,
            "symConjCommAssocIdemConverged": symconj_converged,
            "contrastiveSideSwapNonEquivalent": contrast_noncomm,
            "temporalPrecedenceReversalNonEquivalent": temporal_noncomm,
            "cohortVsUnscopedSeparated": scope_separated,
            "allInvariantsPassed": si_all_ok,
        },
    )


def main() -> int:
    print("==========================================================================")
    print("PNEUMA-NATIVE OMEGA — AUTH-P3C-DIFFERENTIAL-R1 INDEPENDENT R0 ORACLE AUDIT")
    print("==========================================================================")

    po09 = run_po_diff_09_static_audit()
    surf = run_surface_e2e_differential()
    fi_res, si_res = run_forest_and_semantic_inject_audit()

    print(f"[{'PASS' if po09['passed'] else 'FAIL'}] PO-DIFF-09 Static Independence Audit "
          f"(stdlib imports={len(po09['importedModules'])}, forbidden={len(po09['forbiddenImports'])}, "
          f"R0 table rows={po09['r0CorrespondenceRowCount']})")
    print(f"[{'PASS' if surf['mismatchCount'] == 0 else 'FAIL'}] SURFACE_E2E Differential ({surf['totalVectors']} vectors): "
          f"{json.dumps(surf['verdictCounts'])}")
    print(f"       G-15a/G-15b Raw!= & Canon== : {surf['g15ParaphraseRawDistinctAndCanonIdentical']}")
    print(f"[{'PASS' if fi_res['verdictCounts']['MISMATCH_WITNESS'] == 0 else 'FAIL'}] FOREST_INJECT Differential ({fi_res['totalVectors']} vectors, "
          f"SemanticExtractionFailure={fi_res['semanticExtractionFailureVectorsVerified']}): {json.dumps(fi_res['verdictCounts'])}")
    print(f"[{'PASS' if si_res['allInvariantsPassed'] else 'FAIL'}] SEMANTIC_INJECT Differential ({si_res['totalVectors']} vectors): "
          f"idempotent={si_res['allIdempotent']}, DeMorgan={si_res['deMorganConverged']}, "
          f"SymConj={si_res['symConjCommAssocIdemConverged']}, Contrast!={si_res['contrastiveSideSwapNonEquivalent']}, "
          f"Temporal!={si_res['temporalPrecedenceReversalNonEquivalent']}")
    print("==========================================================================")

    summary = {
        "overallActDisposition": (
            "FULL_SCOPED_DIFFERENTIAL_PASS"
            if (po09["passed"] and surf["mismatchCount"] == 0
                and fi_res["verdictCounts"]["MISMATCH_WITNESS"] == 0 and si_res["allInvariantsPassed"])
            else "COUNTEREXAMPLE_OR_FAILURE_DETECTED"
        ),
        "poDiff09Audit": po09,
        "surfaceE2E": surf,
        "forestInject": fi_res,
        "semanticInject": si_res,
    }
    if "--json" in sys.argv:
        print("JSON_SUMMARY_BEGIN")
        print(json.dumps(summary, indent=2))
        print("JSON_SUMMARY_END")

    return 0 if summary["overallActDisposition"] == "FULL_SCOPED_DIFFERENTIAL_PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
````

### File 15: `06_receipts/auth_p3c_differential_r1_verification_receipt.json` (SHA-256: `35927EB0B8DFC43AAF0CEB0B66CA386428C3097632F4E617907C9CD624CF8C11`)
````json
{
  "schema": "PNEUMA_NATIVE_OMEGA_AUTH_P3C_DIFFERENTIAL_R1_RECEIPT_V1",
  "recorded_at": "2026-11-24T20:10:49+09:00",
  "project_governance_title": "PNEUMA-NATIVE OMEGA (Historical Frozen Lineage: BROCA-NATIVE OMEGA)",
  "authorization_gate": "AUTH-P3C-DIFFERENTIAL-R1",
  "authorization_lineage": {
    "pre_design_corrigendum_r0": "F-DIFF-P0-01..04 incorporated and approved by Independent Tribunal (2026-11-23)",
    "ac_p0_06_9a1_human_principal_command": "승인해 진행하자.",
    "ac_p0_06_9a1_timestamp": "2026-11-23T21:20:24+09:00",
    "scoped_optimization_tribunal_directive": "PNEUMA_NATIVE_OMEGA_P3C_DIFFERENTIAL_R1_SCOPED_OPTIMIZATION_APPROVED (F-DIFF-OPT-01..04, Gates OPT-A..D)",
    "scoped_optimization_timestamp": "2026-11-24T10:07:54+09:00",
    "ac_p0_06_9a2_all_four_fields_pinned_before_write": true,
    "zero_file_writes_prior_to_human_confirmation": true
  },
  "target_scope": "F-P3C-02 Independent Full Internal-State Semantic Differential Verification (PNEUMA-DIFF-SER-V1 Canonical Codec, Epistemic Grades, 3-Class Boundary Observation, Closed 5-Way DiffVerdict Algebra, PO-DIFF-01..09, F-DIFF-OPT-01..04, 28 Curated Orthogonal Attack Vectors, & Strict P4/P5 Non-Escalation)",
  "isolated_subpackage_root": "C:\\antigravity work\\BROCA_NATIVE_OMEGA_GATE_C1\\P3C_Differential_R1",
  "lean_namespace": "PneumaOmega.P3C.DifferentialR1",
  "toolchain": {
    "elan_version": "elan 4.2.4 (487233f45 2025-10-16)",
    "lean_version": "Lean (version 4.33.1, x86_64-w64-windows-gnu, commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6, Release)",
    "lake_version": "Lake version 5.0.0-src+819816b (Lean version 4.33.1)",
    "python_independent_oracle_version": "Python 3.11.8",
    "masked_toolchain_binary_root": "<USER_HOME>/.elan/toolchains/leanprover--lean4---v4.33.1/bin",
    "local_readonly_path_dependencies": [
      "../P2_DerivationReplay",
      "../P3_LexicalGrammar",
      "../P3B_BoundedParser",
      "../P3C_SemanticNorm",
      "../P3C_Provenance_R1"
    ],
    "external_network_or_mathlib_dependencies": [],
    "pneuma_finite_operator_r0_dependencies": []
  },
  "verification_commands_executed": [
    {
      "command": "lake build",
      "exit_code": 0,
      "jobs_succeeded": "99/99",
      "warnings": 0,
      "errors": 0,
      "attack_suite_and_obligations_elapsed_sec": 68.58,
      "attack_suite_peak_process_memory_mb": 2333.95,
      "attack_suite_peak_job_memory_mb": 2395.52,
      "pre_optimization_baseline_oom_peak_job_memory_mb": 54870.04,
      "peak_memory_reduction_pct": 95.63
    },
    {
      "command": ".\\.lake\\build\\bin\\p3c_differential_r1_runner.exe",
      "exit_code": 0,
      "elapsed_sec": 0.5847,
      "peak_process_memory_mb": 36.3,
      "peak_job_memory_mb": 36.3,
      "curated_orthogonal_vectors_passed": "28/28",
      "symmetric_pc_ce_pairs": "14/14",
      "d13_literal_string_kernel_decide_vectors": "2/2 (PC-DIFF-13 + CE-DIFF-13 6 malformed wire classes)",
      "f_diff_opt_02_unprojected_witness_checks_passed": "7/7",
      "status_line": "TOTAL CURATED ORTHOGONAL VECTORS : 28/28 PASSED"
    },
    {
      "command": "python 05_independent_tribunal/independent_r0_semantic_oracle.py --json",
      "exit_code": 0,
      "elapsed_sec": 2.2421,
      "peak_process_memory_mb": 38.53,
      "peak_job_memory_mb": 59.49,
      "po_diff_09_static_independence_audit_passed": true,
      "r0_correspondence_table_rows": 25,
      "stdlib_only_imports_count": 11,
      "forbidden_imports_or_lean_source_reads": 0,
      "surface_e2e_vectors": {
        "total": 40,
        "MATCH_STRUCTURAL(SPEC_GROUNDED)": 36,
        "MATCH_STRUCTURAL(MODEL_ASSUMPTION)": 2,
        "SPECIFICATION_HELD": 2,
        "MISMATCH_WITNESS": 0,
        "ORACLE_FAILURE": 0,
        "RESOURCE_HELD": 0,
        "g15_paraphrase_raw_distinct_and_canon_identical": true
      },
      "forest_inject_vectors": {
        "total": 12,
        "MATCH_STRUCTURAL(SPEC_GROUNDED)": 9,
        "MATCH_STRUCTURAL(MODEL_ASSUMPTION)": 3,
        "MISMATCH_WITNESS": 0,
        "semantic_extraction_failure_vectors_verified": 9,
        "all_5_extraction_failure_diag_constructors_covered": true,
        "fi10_g16_swapped_child_boundary_note": "Under FOREST_INJECT (bypassing P3-B), P3-C extractRawMeaning assumes upstream P3-B child nonterminal typing [Env_ScopedAssoc, Env_ScopedContrastMeta] and extracts swapped [sc2, sc1] as swapped contrastivePair(metaSide, assocSide) (MODEL_ASSUMPTION), verified strictly non-equivalent to valid G-16 (CE-DIFF-01)."
      },
      "semantic_inject_vectors": {
        "total": 12,
        "all_idempotent": true,
        "de_morgan_converged": true,
        "symconj_comm_assoc_idem_converged": true,
        "contrastive_side_swap_non_equivalent": true,
        "temporal_precedence_reversal_non_equivalent": true,
        "cohort_vs_unscoped_separated": true
      }
    },
    {
      "command": "lake env leanchecker --fresh P3CDiffTribunalAudit",
      "exit_code": 0,
      "differential_r1_project_olean_modules": 10,
      "replayed_upstream_frozen_packages": [
        "P2_DerivationReplay",
        "P3_LexicalGrammar",
        "P3B_BoundedParser",
        "P3C_SemanticNorm",
        "P3C_Provenance_R1"
      ],
      "elapsed_sec": 3027.6874,
      "peak_process_memory_mb": 10736.4,
      "peak_job_memory_mb": 10776.67
    }
  ],
  "f_diff_opt_compliance_summary": {
    "f_diff_opt_01_projection_soundness_proved": true,
    "f_diff_opt_01_terminology": "FINITE_VERDICT_HEAD_PROJECTION_NOT_QUOTIENT",
    "f_diff_opt_02_mismatch_witness_fidelity_proved": true,
    "f_diff_opt_02_unprojected_runtime_witnesses_verified": "7/7",
    "f_diff_opt_03_finite_decision_algebra_equivalence_proved": true,
    "f_diff_opt_03_d13_literal_string_kernel_decide_preserved": true,
    "f_diff_opt_04_empirical_metrics_recorded": true,
    "f_diff_opt_04_asymptotic_complexity_claim_status": "HELD",
    "f_diff_opt_04_pre_execution_half_leanchecker_time_estimate_status": "NOT_MET_EMPIRICALLY_REPORTED_WITHOUT_PROMOTION (3027.69s on expanded 10-module + 5-upstream transitive graph vs 738.03s on Provenance R1; build OOM reduced from 54870.04 MB to 2395.52 MB and fresh replay completed at 10736.40 MB exit 0)"
  },
  "axiom_audit": {
    "sorryAx_present": false,
    "ofReduceBool_native_decide_present": false,
    "trustCompiler_present": false,
    "custom_axioms_present": false,
    "unsafe_declarations_present": false,
    "standard_lean_foundational_axioms_only": [
      "propext",
      "Classical.choice",
      "Quot.sound"
    ],
    "audited_theorems": [
      "PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_01_SerializationRoundtripAndCanonicalUniqueness",
      "PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_02_EncodingInjectivity",
      "PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_03_SpanUnitIntegrity",
      "PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_04_ExtractionResultFidelity",
      "PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_05_CanonicalMeaningFidelity",
      "PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_06_FiveWayOutcomeSeparation",
      "PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_07_DifferentialScopeSoundness",
      "PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_08_ProvenanceBoundaryPreservation",
      "PneumaOmega.P3C.DifferentialR1.Obligations.F_DIFF_OPT_01_ProjectionSoundness",
      "PneumaOmega.P3C.DifferentialR1.Obligations.F_DIFF_OPT_02_MismatchWitnessFidelity",
      "PneumaOmega.P3C.DifferentialR1.Obligations.PO_DIFF_All28OrthogonalAttackVectorsVerified"
    ]
  },
  "source_artifact_sha256": {
    "lean-toolchain": "3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71",
    "lakefile.toml": "B4FDD45CA5038E275978C0A7CE3CC16717226A5C782C5A412B50F878642E46BD",
    "lake-manifest.json": "3EF2C9E99C50134787DCEAF0A57BC77778E9B3CC633A3E810A305D8736A89164",
    "01_formal_spec/P3CDifferentialSpec.lean": "618C51038F549FC68B0D788FC9E32A1C8B3945091B76C43A80D0F445D926C996",
    "01_formal_spec/P3CDifferentialSpec/TypedWireFormatV1.lean": "945EA3C6471C6336974D85A5EE0C48A6217F32094160DAF7E82AA0ABA710768A",
    "01_formal_spec/P3CDifferentialSpec/DifferentialAlgebraSpec.lean": "352D462AA31316BFD0C09B79F158808B53AC039E774AF547E161E98CBF4DDE78",
    "02_detached_checker/P3CDifferentialChecker.lean": "6C0AC3B98803F7D361ACAF25C2A780FF13C9ED272D74E4496B7345331EFF7415",
    "02_detached_checker/P3CDifferentialChecker/DifferentialTraceObserver.lean": "A46D160BB03DF9AA1D829F2AA88C141803A07C7C4BCE16279C9D91FE9C944E57",
    "03_counterexamples/P3CDifferentialAttacks.lean": "C3D351827F9A31F964D788DEBE8AEB41AB5148D9FDAFDB54D6E29154C4D58975",
    "03_counterexamples/P3CDifferentialAttacks/OrthogonalAttackSuiteD01ToD12.lean": "CAF5C44E4879919842F595363093FE593D3764C8212FF6242525EF26C8623CE7",
    "04_proof_obligations/P3CDifferentialObligations.lean": "EE412CE5FC5C69D537412C4380F424231D522BB0AFDCA20363237EFC58EE0822",
    "04_proof_obligations/P3CDifferentialObligations/PO_DIFF_01_To_08.lean": "DDE78809CE366D28BAD11EFC812357F549916CB7B5CFFDE86A37E78705F296C7",
    "05_independent_tribunal/P3CDiffTribunalAudit.lean": "C14301B464745718E7227B1E62710EB9A7F4BB349A9A56E685963ADEC3D31785",
    "05_independent_tribunal/independent_r0_semantic_oracle.py": "C851070E75B338BA71605B22701ACE76DF032356552A27C647AD38B975899519"
  },
  "compiled_artifact_sha256": {
    "P3CDifferentialSpec/TypedWireFormatV1.olean": "90E8839CD1DA711ED74FD4A4DE08EB7E88F118C0067467C7C52B4BF32F157697",
    "P3CDifferentialSpec/DifferentialAlgebraSpec.olean": "43635A33B981EE78FBDD6671B6A7DF0246A5419CCEA2B9020EB374637A05D7CC",
    "P3CDifferentialSpec.olean": "6706F4C39244A8CF704925AA6317F4D04ECD290A62D7612DEDCB143FE81AF2C0",
    "P3CDifferentialChecker/DifferentialTraceObserver.olean": "CB825F4AFB04611D3EBA027915FCC15D6E6B2CCDB9482E4B33ADA435EF25B446",
    "P3CDifferentialChecker.olean": "CEE7CF7A63FE7294BC4A40CB75C3BEDF200AA2E1DDCE6C2D5800BE7ACF1C19B3",
    "P3CDifferentialAttacks/OrthogonalAttackSuiteD01ToD12.olean": "1CD2234C2CA19EC141F229BFAB360FDB76FCCCA4B5318ECD54C72440DC8880FD",
    "P3CDifferentialAttacks.olean": "41FA1958FD2AB863BD938BE6D5C7FD376A19BF0B3C47646B2DE6AEF371160168",
    "P3CDifferentialObligations/PO_DIFF_01_To_08.olean": "0201706FD0C0FA273AFD52200DA92DE7987EFD65F70EEBBB9D53568F12ED1463",
    "P3CDifferentialObligations.olean": "9CA7F467DC2FE079BC6FEE18A0B169A8FAA0994CE1109D593D4EECE939730189",
    "P3CDiffTribunalAudit.olean": "D88AEA2E97626A2682AD2E04229A8170D70168E494EB4AB58138FE05894455B8",
    "p3c_differential_r1_runner.exe": "73EBE474CE26B02920375418F1F421F9487E331A45D4901A79EB5EB0EB56B917"
  },
  "prior_gate_immutability_verified": {
    "pneuma_workspace_file_count": 0,
    "broca_shared_anchors_unchanged": "6/6",
    "frozen_reference_manifest_sha256": "2FA5C7EC0423A6D404EBBB681E2393B9041C7E02634EB71D4505405162D3C076",
    "parent_06_receipts_untouched": "6/6",
    "auth_c1_dir_receipt_sha256": "036E6543AD43365F9B914259840E0508F920FE24F56AAD45824639B7F480620E",
    "auth_c1_p1_receipt_sha256": "EC53292AD346D0FD17393C00F0DE5AD0832CEB48B09CE2D298A97B8101C5CDAB",
    "auth_c1_p2_receipt_sha256": "5D9BFCD3B3F029AF1B338CB47AC0445FB8707437898B9777A6C771BD40029F3E",
    "auth_c1_p3a_receipt_sha256": "46A80A14CEEF917E133B375B49D4C2CD60FCB91300246920D7A819E556BEC79F",
    "auth_c1_p3b_receipt_sha256": "212FE405EA722F72E11CB65493072F688AC86FFB7E6E47D49F6FAD5CDC58E595",
    "auth_c1_p3c_receipt_sha256": "191AE819B8844BA81B323F1FCA1D1C04591941C52FA9D5E8B14339202C9E79A7",
    "p1_sources_unchanged": "13/13",
    "p2_sources_unchanged": "14/14",
    "p3a_sources_unchanged": "14/14",
    "p3b_sources_unchanged": "14/14",
    "p3c_sources_unchanged": "14/14",
    "p3c_binaries_unchanged": "12/12",
    "p3c_provenance_r1_sources_unchanged": "13/13",
    "p3c_provenance_r1_binaries_unchanged": "10/10",
    "p3c_provenance_r1_receipt_sha256_unchanged": "790E41D1D352C31457281F72BB627E28DD6D3B7DB1B65C7D8F4F39A795D203DD",
    "prior_brain_dossiers_unchanged": "7/7",
    "p3c_dossier_sha256_unchanged": "B1EF2820F3FCEFA5D85AC938AD9FE7F7428C64E08F4A5C4CD324E951E3AE8A67",
    "p3c_reconciliation_r0_dossier_sha256_unchanged": "EF36A4E34C60B9C45EB7D6977B7FAF912161369F77A655255E2A619EC9017CE6",
    "p3c_provenance_r1_dossier_sha256_unchanged": "0C88F07B3B0EAC2E33008207C99BC4941059B97DB9792A33760FDC13B62A6A4E"
  },
  "scope_and_held_locks": {
    "tribunal_acceptance_status": "PENDING_INDEPENDENT_TRIBUNAL_AUDIT",
    "f_p3c_02_internal_differential_observability_submitted": true,
    "full_r0_semantic_fidelity_beyond_curated_corpus_held": true,
    "f_r1_01_out_of_kernel_binary_memory_runtime_tamper_held": true,
    "global_p4_p5_admission_non_bypass_held": true,
    "external_independent_host_replay_held": true,
    "legacy_p3c_authorization_qualified_unchanged": true,
    "f_diff_opt_04_asymptotic_complexity_claim_held": true,
    "extensional_contrastive_world_assumption_retained": true,
    "f_p3c_03_performance_scaling_authorized": false,
    "pneuma_finite_operator_r0_authorized": false,
    "p1_c_int128_fast_path_authorized": false,
    "p4_clinical_evidence_authorized": false,
    "p5_snapshot_admission_authorized": false,
    "pneuma_speech_and_listener_authorized": false,
    "ancestors_or_p1_to_provenance_r1_modified": false
  }
}
````
