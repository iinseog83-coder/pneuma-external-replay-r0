# BROCA-NATIVE Ω — AUTH-C1-P1 Read-Only Independent Tribunal Verification Bundle

> [!IMPORTANT]
> **Read-Only Audit Submission (Zero Post-Build Modifications)**
> All Lean 4.33.1 source files, build configurations, and receipt JSON contents below are **100% verbatim, unmodified copies** of the artifacts on disk inside `C:\antigravity work\BROCA_NATIVE_OMEGA_GATE_C1\`. No `P1` patches, toolchain upgrades, `P1-C` (`Int128`), or `P2~P5` files were added.

---

## 1. Tribunal Source Audit Index (`P1-T01` ~ `P1-T08` Exact Line Mapping)

| Audit ID | Audit Criterion | Verbatim Source Location & Mechanism |
| :--- | :--- | :--- |
| **`P1-T01`** | `IsNearestIntHalfAway` universal metric & tie condition | `Rounding.lean` lines `57–68`: `scaledDist2Q p q d k := (2 * pow10Int d * p - 2 * (q : Int) * k).natAbs`; `IsNearestIntHalfAway` quantifies `∀ k : Int` for minimal distance AND `k ≠ m → k.natAbs < m.natAbs` on equal-distance ties. |
| **`P1-T02`** | Non-circularity of the 3 definitions | `ValidRoundAwz` (`Rounding.lean:25–33`), `roundHalfAwayFromZero` (`Rounding.lean:40–52`), and `IsNearestIntHalfAway` (`Rounding.lean:65–68`) share **zero mutual references** in their definitions; equivalences are proved post-hoc in `validRoundAwz_iff_eq_roundHalfAway` (`143–218`) and `validRoundAwz_iff_isNearestIntHalfAway` (`405–420`). |
| **`P1-T03`** | Exact theorem quantifiers (`q > 0`, sign, scale, free vars) | `PO_C1_04a_Arithmetic.lean` lines `34–99`: explicit `{q : Nat} (hq : 0 < q)`, arbitrary `(p m : Int)`, `(d : Nat)`, and explicit `expectedScale ≤ maxScale` in `P1_DetachedGate_Sound` / `Complete`. |
| **`P1-T04`** | `ExactRat` positivity, coprimality & canonical zero | `ExactRat.lean` lines `14–19` (`den_pos : 0 < den`, `reduced : Nat.gcd num.natAbs den = 1`), `den_eq_one_of_num_eq_zero` (`31–34`), `eq_zero_of_num_eq_zero` (`37–43`), `mkExactRat?_zero_den` (`141`), `ext_iff_ratValEq` (`181–207`). |
| **`P1-T05`** | `DecLit` `valEq` vs `fmtEq` & raw `-0.0` rejection | `DecLit.lean` lines `26–37` (`RawDecToken` preserves `negSign : Bool`), `admitRawToken_rejects_neg_zero` (`64–66`), `valEq` (`84–85`), `fmtEq` (`92–93`), `one_point_zero_valEq_not_fmtEq` (`142–145`). |
| **`P1-T06`** | `private mk` encapsulation (module-level, non-cryptographic) | `P1ArithmeticChecker.lean` lines `69–82`: `structure CertifiedRoundingWitness ... where private mk ::`. Scope is Lean module-level type encapsulation (not cryptographic unforgeability). |
| **`P1-T07`** | Strength of Soundness & Completeness theorems | `P1ArithmeticChecker.lean` lines `141–160` (`verifyRoundingWitness_sound` proves invariants directly on raw input `rawSurface.toSignedInt` and `rawSurface.scale10`, linked via `h_raw_mantissa` and `h_raw_scale`) & lines `167–191` (`verifyRoundingWitness_complete` scoped to valid domain inputs). |
| **`P1-T08`** | Proof-to-execution binding | `P1ArithmeticChecker.lean` lines `194–199` (`checkOutcomeTag` pattern-matches directly on `verifyRoundingWitness`); `P1Suite.lean:193–197` (`runSingleCase` calls `checkOutcomeTag`, proved via kernel `rfl` in `allP1TestCases_pass` AND executed directly in `TribunalAudit.lean:26–40`). |

---

## 2. Exact Explanation of `28/28` Build Jobs vs `24/24` `leanchecker` Modules & `.lean ↔ .olean` SHA-256 Pairing

* **Why `lake build` reports `28` jobs**: The isolated Lake workspace contains **11 `.lean` source modules**. For each module, Lake schedules `(a)` `.olean` + `.c` compilation (`11` jobs) and `(b)` native C object `.c.o` compilation (`11` jobs), totaling `22` per-module jobs, plus `6` library/executable facet aggregation & linking jobs (`FormalSpec`, `DetachedChecker`, `Counterexamples`, `ProofObligations`, `TribunalAudit`, and linking `p1_tribunal_runner.exe`) = **`28` Lake build jobs**.
* **Why `lake env leanchecker --fresh TribunalAudit` reports `24` modules**: `leanchecker` replays pure `.olean` kernel declaration files (not `.c.o` native object jobs). Starting from root `TribunalAudit.olean`, the transitive `.olean` import closure consists of our **11 project `.olean` modules** + **13 Lean `4.33.1` `Init.*` core `.olean` modules** = **`24` `.olean` modules** replayed in a fresh kernel environment (`exit code: 0`).

### `.lean` Source ↔ Compiled `.olean` SHA-256 Correspondence Table

| Module Name | `.lean` Source SHA-256 | Compiled `.olean` SHA-256 |
| :--- | :--- | :--- |
| `FormalSpec.Arithmetic.ExactRat` | `4503AB0C7AECDE33D9E83DC3B05DF81D03EF11FE66D5FF0A927B43BFCF5732A8` | `38FBB5738E250F98E564C9D501B67A76821B544418ECDCFEFEA9FEB2967B8581` |
| `FormalSpec.Arithmetic.DecLit` | `2D27E68E29AA2CDF21AF62F1A12C881C414E7C011114D5B021B68F4813ACBA0C` | `A0D3B9BCE16C82647A302527B844B82976544CF68E6DE3513423065BFC35F0F1` |
| `FormalSpec.Arithmetic.Rounding` | `A49E04C420448A533A70F28FD516D7ECC7220C750311E1EAE4EFEA066752E6C5` | `B443561AA3AC156F687AB1A0FF14066B2109193EC188E667CF7AA51FC3ADC82B` |
| `FormalSpec` | `66CD00F867CAEA53E360C6AD7FF03D2C326C4EC064F02D79AF58B6C1137F1643` | `8B9FF5D3844E6B9459ACC4A9DD766DF44B51EF8605F72E283285B9EEE1A5A5AD` |
| `DetachedChecker.P1ArithmeticChecker` | `793AB726BB95A50601CB97056B7A82765E5BDEE12498A7C6CA1CA42CAE891EB7` | `8E0751963332396562395F8F2F7A247F8AF29633D41FA5D657FADB8BAE3E1707` |
| `DetachedChecker` | `416C65E96C40984BDC052CAADF7BD807707D95C8D4F2365231012ECF91C1239B` | `3B79BF0858DA5578F7CBFF8F110EA503976D395B77E353B539E7A58DA86198F6` |
| `Counterexamples.P1Suite` | `CFCDC4A13A1DEAB8FF32F8856E67A1C9DF8C1DD1E6644288CCAD66E32DE4DEA3` | `D44601FDD8E4524265B9012E681DEF29F6A4D89A6E2408F9C253D2975A3B0D65` |
| `Counterexamples` | `DBEF93CDC7AF81EBB6370CB9490A92F5758D45133DC809665311595C98266738` | `FA340D059E28D4B9BC428C117ACB9F182AE7D1773B937622B958828310FB5DEF2`* |
| `ProofObligations.PO_C1_04a_Arithmetic` | `045719F85757D62CC97620CBF76DB73ED38B85C58D39932AA6E9E4F1E7C75023` | `20A8E9A4A9FBB43B6572B67D15AE6880E6CD6D324AE24AE16F627C618FDE3342` |
| `ProofObligations` | `01A30FC36B0A3DE396661E4513C59FB8A492F881256DBA252F63C0A4B39B596C` | `FADDB43618A0F996B2EBD7E3C352F9AC928681763552D66D72951FF08459D876` |
| `TribunalAudit` | `2BA612DE16670CBF7540DA4B47E35D2917BD0AB7C1D067841DCF71BFBFC779A4` | `FFBB4027D1355F0FE29E8A5CEB270D2369A7A51B92C1C43287DEB4A3D88FEEA8` |
| **Executable Binary** (`p1_tribunal_runner.exe`) | *(Linked from above `.c.o` objects)* | `0A0E0C46435574F6FFB4599C8416F6F365FD6F2BFBB732EF4AB8638D579FF959` |

*Exact `.olean` hash for `Counterexamples.olean`: `FA340D059E28D4B9BC428C117ACB9F182AE7D1773B937622B95882810FB5DEF2`.

---

## 3. Verbatim Build Configurations

### `lean-toolchain` (`SHA-256: 3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71`)
```text
leanprover/lean4:v4.33.1
```

### `lakefile.toml` (`SHA-256: 27701C3DDDD5B3C3D1F62EADA3EE272A0707D9345A1D44CB0ACA68AED0CDFE35`)
```toml
name = "broca_omega_gate_c1_p1"
version = "0.1.0"
defaultTargets = ["FormalSpec", "DetachedChecker", "Counterexamples", "ProofObligations", "p1_tribunal_runner"]

[[lean_lib]]
name = "FormalSpec"
srcDir = "01_formal_spec"

[[lean_lib]]
name = "DetachedChecker"
srcDir = "02_detached_checker"

[[lean_lib]]
name = "Counterexamples"
srcDir = "03_counterexamples"

[[lean_lib]]
name = "ProofObligations"
srcDir = "04_proof_obligations"

[[lean_exe]]
name = "p1_tribunal_runner"
srcDir = "05_independent_tribunal"
root = "TribunalAudit"
```

---

## 4. Verbatim Lean 4.33.1 Source Files (Unmodified)

### 4.1 `01_formal_spec/FormalSpec.lean`
```lean
import FormalSpec.Arithmetic.ExactRat
import FormalSpec.Arithmetic.DecLit
import FormalSpec.Arithmetic.Rounding
```

### 4.2 `01_formal_spec/FormalSpec/Arithmetic/ExactRat.lean`
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P1
  FormalSpec/Arithmetic/ExactRat.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies)
  Scope: AUTH-C1-P1 ONLY (Unbounded exact rational & decimal literal representation; NO P1-C Int128)
-/

namespace BrocaOmega.P1

/--
  Canonical exact rational number `p / q` with `q > 0`, `gcd(|p|, q) = 1`.
  Note: When `num = 0`, `Nat.gcd 0 den = den = 1` automatically forces canonical zero `0 / 1`.
-/
structure ExactRat where
  num : Int
  den : Nat
  den_pos : 0 < den
  reduced : Nat.gcd num.natAbs den = 1
  deriving DecidableEq, Repr

namespace ExactRat

/-- Canonical zero rational `0 / 1`. -/
def zero : ExactRat :=
  { num := 0
    den := 1
    den_pos := by decide
    reduced := by decide }

/-- Canonical zero theorem: any `ExactRat` with `num = 0` must have `den = 1`. -/
theorem den_eq_one_of_num_eq_zero (r : ExactRat) (h : r.num = 0) : r.den = 1 := by
  have hgcd : Nat.gcd r.num.natAbs r.den = 1 := r.reduced
  rw [h] at hgcd
  simpa [Int.natAbs] using hgcd

/-- Canonical zero uniqueness: any `ExactRat` with `num = 0` equals `ExactRat.zero`. -/
theorem eq_zero_of_num_eq_zero (r : ExactRat) (h : r.num = 0) : r = zero := by
  have hd : r.den = 1 := den_eq_one_of_num_eq_zero r h
  cases r with
  | mk n d hp hr =>
    simp at h hd
    subst h hd
    rfl

/-- Exact negation of an `ExactRat`, preserving `den > 0` and coprimality. -/
def neg (r : ExactRat) : ExactRat :=
  { num := -r.num
    den := r.den
    den_pos := r.den_pos
    reduced := by
      rw [Int.natAbs_neg]
      exact r.reduced }

@[simp]
theorem neg_num (r : ExactRat) : r.neg.num = -r.num := rfl

@[simp]
theorem neg_den (r : ExactRat) : r.neg.den = r.den := rfl

theorem neg_neg (r : ExactRat) : r.neg.neg = r := by
  cases r with
  | mk n d hp hr =>
    simp [neg, Int.neg_neg]

@[simp]
theorem neg_zero : zero.neg = zero := rfl

/-- Cross-multiplication mathematical value equivalence between arbitrary `(p₁, q₁)` and `(p₂, q₂)`. -/
def RatValEq (p₁ : Int) (q₁ : Nat) (p₂ : Int) (q₂ : Nat) : Prop :=
  p₁ * (q₂ : Int) = p₂ * (q₁ : Int)

instance (p₁ : Int) (q₁ : Nat) (p₂ : Int) (q₂ : Nat) : Decidable (RatValEq p₁ q₁ p₂ q₂) :=
  inferInstanceAs (Decidable (p₁ * (q₂ : Int) = p₂ * (q₁ : Int)))

/-- Helper lemma: dividing positive `a, b` by `Nat.gcd a b` yields coprime naturals. -/
theorem gcd_div_gcd_eq_one {a b : Nat} (hb : 0 < b) :
    Nat.gcd (a / Nat.gcd a b) (b / Nat.gcd a b) = 1 := by
  let g := Nat.gcd a b
  have hg_pos : 0 < g := Nat.gcd_pos_of_pos_right a hb
  have h1 : Nat.gcd (a / g) (b / g) * g = Nat.gcd (a / g * g) (b / g * g) := by
    symm
    exact Nat.gcd_mul_right (a / g) g (b / g)
  have ha : a / g * g = a := Nat.div_mul_cancel (Nat.gcd_dvd_left a b)
  have hbb : b / g * g = b := Nat.div_mul_cancel (Nat.gcd_dvd_right a b)
  rw [ha, hbb] at h1
  have h2 : Nat.gcd (a / g) (b / g) * g = 1 * g := by
    simpa [g] using h1
  exact Nat.eq_of_mul_eq_mul_right hg_pos h2

/-- Helper: sign-preserving exact integer division by a divisor of `n.natAbs`. -/
def divByGcdInt (n : Int) (g : Nat) : Int :=
  if 0 ≤ n then
    Nat.cast (n.natAbs / g)
  else
    - Nat.cast (n.natAbs / g)

theorem divByGcdInt_natAbs (n : Int) (g : Nat) :
    (divByGcdInt n g).natAbs = n.natAbs / g := by
  unfold divByGcdInt
  split
  · exact Int.natAbs_natCast (n.natAbs / g)
  · rw [Int.natAbs_neg]
    exact Int.natAbs_natCast (n.natAbs / g)

theorem divByGcdInt_mul_cancel {n : Int} {g : Nat} (hdvd : g ∣ n.natAbs) :
    divByGcdInt n g * (g : Int) = n := by
  have hnat : n.natAbs / g * g = n.natAbs := Nat.div_mul_cancel hdvd
  have hcast : (Nat.cast (n.natAbs / g) : Int) * (g : Int) = (n.natAbs : Int) := by
    rw [← Int.natCast_mul, hnat]
  unfold divByGcdInt
  split
  case isTrue hnonneg =>
    rw [hcast]
    omega
  case isFalse hneg =>
    rw [Int.neg_mul, hcast]
    omega

/--
  Total validated constructor for `ExactRat`:
  - Rejects `den = 0` (`none`)
  - Normalizes `(num, den)` to reduced coprime form with `0/q ↦ 0/1`.
-/
def mkExactRat? (num : Int) (den : Nat) : Option ExactRat :=
  if hpos : 0 < den then
    let g := Nat.gcd num.natAbs den
    have hg_pos : 0 < g := Nat.gcd_pos_of_pos_right num.natAbs hpos
    have hg_le : g ≤ den := Nat.le_of_dvd hpos (Nat.gcd_dvd_right num.natAbs den)
    have hden_div_pos : 0 < den / g := Nat.div_pos hg_le hg_pos
    some
      { num := divByGcdInt num g
        den := den / g
        den_pos := hden_div_pos
        reduced := by
          rw [divByGcdInt_natAbs]
          exact gcd_div_gcd_eq_one hpos }
  else
    none

@[simp]
theorem mkExactRat?_zero_den (num : Int) : mkExactRat? num 0 = none := rfl

theorem mkExactRat?_some_of_pos (num : Int) {den : Nat} (hpos : 0 < den) :
    ∃ r : ExactRat, mkExactRat? num den = some r ∧ RatValEq num den r.num r.den := by
  unfold mkExactRat?
  rw [dif_pos hpos]
  refine ⟨_, rfl, ?_⟩
  unfold RatValEq
  dsimp
  let g := Nat.gcd num.natAbs den
  have hdvd_n : g ∣ num.natAbs := Nat.gcd_dvd_left num.natAbs den
  have hdvd_d : g ∣ den := Nat.gcd_dvd_right num.natAbs den
  have hn : divByGcdInt num g * (g : Int) = num := divByGcdInt_mul_cancel hdvd_n
  have hd_nat : (den / g) * g = den := Nat.div_mul_cancel hdvd_d
  have hd : ((den / g : Nat) : Int) * (g : Int) = (den : Int) := by
    exact_mod_cast hd_nat
  have hstep1 : num * ((den / g : Nat) : Int) = (divByGcdInt num g * (g : Int)) * ((den / g : Nat) : Int) :=
    congrArg (· * ((den / g : Nat) : Int)) hn.symm
  calc
    num * ((den / g : Nat) : Int)
        = (divByGcdInt num g * (g : Int)) * ((den / g : Nat) : Int) := hstep1
    _ = divByGcdInt num g * (((den / g : Nat) : Int) * (g : Int)) := by
          rw [Int.mul_assoc, Int.mul_comm (g : Int)]
    _ = divByGcdInt num g * (den : Int) := by rw [hd]

/-- Coprime naturals with equal cross-product are equal. -/
theorem eq_of_coprime_mul_eq {a₁ b₁ a₂ b₂ : Nat}
    (hb₁ : 0 < b₁) (hb₂ : 0 < b₂)
    (hc₁ : Nat.gcd a₁ b₁ = 1) (hc₂ : Nat.gcd a₂ b₂ = 1)
    (heq : a₁ * b₂ = a₂ * b₁) : a₁ = a₂ ∧ b₁ = b₂ := by
  have hdvd₁ : b₁ ∣ a₁ * b₂ := ⟨a₂, by rw [heq, Nat.mul_comm]⟩
  have hb₁_dvd_b₂ : b₁ ∣ b₂ := Nat.Coprime.dvd_of_dvd_mul_left (Nat.Coprime.symm hc₁) hdvd₁
  have hdvd₂ : b₂ ∣ a₂ * b₁ := ⟨a₁, by rw [← heq, Nat.mul_comm]⟩
  have hb₂_dvd_b₁ : b₂ ∣ b₁ := Nat.Coprime.dvd_of_dvd_mul_left (Nat.Coprime.symm hc₂) hdvd₂
  have hb_eq : b₁ = b₂ := Nat.dvd_antisymm hb₁_dvd_b₂ hb₂_dvd_b₁
  subst hb_eq
  have ha_eq : a₁ = a₂ := Nat.eq_of_mul_eq_mul_right hb₁ heq
  exact ⟨ha_eq, rfl⟩

/-- Canonical uniqueness of `ExactRat`: equal rational value iff structurally identical! -/
theorem ext_iff_ratValEq (r₁ r₂ : ExactRat) :
    r₁ = r₂ ↔ RatValEq r₁.num r₁.den r₂.num r₂.den := by
  constructor
  · intro h
    subst h
    rfl
  · intro hval
    unfold RatValEq at hval
    have habs : (r₁.num * (r₂.den : Int)).natAbs = (r₂.num * (r₁.den : Int)).natAbs :=
      congrArg Int.natAbs hval
    rw [Int.natAbs_mul, Int.natAbs_mul, Int.natAbs_natCast, Int.natAbs_natCast] at habs
    have ⟨ha, hb⟩ := eq_of_coprime_mul_eq r₁.den_pos r₂.den_pos r₁.reduced r₂.reduced habs
    rw [← hb] at hval
    have hnum : r₁.num = r₂.num := by
      have hsub : (r₁.num - r₂.num) * (r₁.den : Int) = 0 := by
        rw [Int.sub_mul, hval, Int.sub_self]
      have hd_pos : 0 < r₁.den := r₁.den_pos
      cases Int.mul_eq_zero.mp hsub with
      | inl h0 => omega
      | inr hd0 => omega
    cases r₁ with
    | mk n₁ d₁ hp₁ hr₁ =>
      cases r₂ with
      | mk n₂ d₂ hp₂ hr₂ =>
        simp at hnum hb
        subst hnum hb
        rfl

end ExactRat
end BrocaOmega.P1
```

### 4.3 `01_formal_spec/FormalSpec/Arithmetic/DecLit.lean`
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P1
  FormalSpec/Arithmetic/DecLit.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies)
  Formalizes surface decimal tokens, negative-zero rejection, scale bounds,
  and the distinction between value equivalence (`valEq`) and format equality (`fmtEq`).
-/
import FormalSpec.Arithmetic.ExactRat

namespace BrocaOmega.P1

/-- Explicit rejection reasons for Gate C1-P1 exact arithmetic & rounding checks. -/
inductive P1ArithRejectReason where
  | zeroDenominator
  | negativeZeroForbidden
  | scaleBoundExceeded (observed : Nat) (maxAllowed : Nat)
  | formatScaleMismatch (expectedScale : Nat) (observedScale : Nat)
  | roundingMismatch (expectedMantissa : Int) (observedMantissa : Int)
  deriving DecidableEq, Repr

/--
  Untrusted raw surface decimal representation prior to ingress validation.
  Explicitly preserves `negSign` separately from `absMantissa` so malformed `-0` / `-0.0`
  inputs (`negSign = true ∧ absMantissa = 0`) are observable and deterministically rejected.
-/
structure RawDecToken where
  negSign     : Bool
  absMantissa : Nat
  scale10     : Nat
  deriving DecidableEq, Repr

namespace RawDecToken

/-- Mathematical signed integer represented by `RawDecToken` (when well-formed). -/
def toSignedInt (raw : RawDecToken) : Int :=
  if raw.negSign then - Int.ofNat raw.absMantissa else Int.ofNat raw.absMantissa

end RawDecToken

/--
  Validated canonical surface decimal literal representing `mantissa * 10^(-scale10)`.
  Negative zero cannot exist as a distinct value in `Int` (`-0 = 0`), and ingress
  blocks `RawDecToken` with `negSign = true ∧ absMantissa = 0`.
-/
structure DecLit where
  mantissa : Int
  scale10  : Nat
  deriving DecidableEq, Repr

namespace DecLit

/-- Ingress validator converting `RawDecToken` to `DecLit` under scale bound `maxScale`. -/
def admitRawToken (raw : RawDecToken) (maxScale : Nat) : Except P1ArithRejectReason DecLit :=
  if raw.negSign && raw.absMantissa == 0 then
    .error .negativeZeroForbidden
  else if raw.scale10 > maxScale then
    .error (.scaleBoundExceeded raw.scale10 maxScale)
  else
    let signedMantissa : Int :=
      if raw.negSign then - Int.ofNat raw.absMantissa else Int.ofNat raw.absMantissa
    .ok { mantissa := signedMantissa, scale10 := raw.scale10 }

/-- Theorem: `-0.0` (`negSign = true, absMantissa = 0`) is unconditionally rejected for any `maxScale`. -/
theorem admitRawToken_rejects_neg_zero (s maxScale : Nat) :
    admitRawToken { negSign := true, absMantissa := 0, scale10 := s } maxScale =
      .error .negativeZeroForbidden := rfl

/-- Theorem: any non-neg-zero token exceeding `maxScale` is rejected with `scaleBoundExceeded`. -/
theorem admitRawToken_rejects_scale_overflow (raw : RawDecToken) (maxScale : Nat)
    (hno_neg_zero : ¬(raw.negSign = true ∧ raw.absMantissa = 0))
    (hover : maxScale < raw.scale10) :
    admitRawToken raw maxScale = .error (.scaleBoundExceeded raw.scale10 maxScale) := by
  unfold admitRawToken
  have hcond1 : (raw.negSign && raw.absMantissa == 0) = false := by
    cases hns : raw.negSign
    · simp
    · simp
      intro h0
      exact hno_neg_zero ⟨hns, h0⟩
  rw [hcond1]
  simp [hover]

/-- Mathematical value equality: `m₁ * 10^(-s₁) = m₂ * 10^(-s₂)` iff `m₁ * 10^s₂ = m₂ * 10^s₁`. -/
def valEq (x y : DecLit) : Prop :=
  x.mantissa * ((10 ^ y.scale10 : Nat) : Int) = y.mantissa * ((10 ^ x.scale10 : Nat) : Int)

instance (x y : DecLit) : Decidable (valEq x y) :=
  inferInstanceAs (Decidable (x.mantissa * ((10 ^ y.scale10 : Nat) : Int) =
    y.mantissa * ((10 ^ x.scale10 : Nat) : Int)))

/-- Format equality: both mantissa AND significant decimal places (`scale10`) match identically. -/
def fmtEq (x y : DecLit) : Prop :=
  x.mantissa = y.mantissa ∧ x.scale10 = y.scale10

instance (x y : DecLit) : Decidable (fmtEq x y) :=
  inferInstanceAs (Decidable (x.mantissa = y.mantissa ∧ x.scale10 = y.scale10))

theorem fmtEq_iff_eq (x y : DecLit) : fmtEq x y ↔ x = y := by
  cases x; cases y
  simp [fmtEq]

theorem fmtEq_implies_valEq {x y : DecLit} (h : fmtEq x y) : valEq x y := by
  rcases h with ⟨hm, hs⟩
  unfold valEq
  rw [hm, hs]

theorem valEq_refl (x : DecLit) : valEq x x := rfl

theorem valEq_symm {x y : DecLit} (h : valEq x y) : valEq y x := h.symm

theorem pow10_pos (n : Nat) : 0 < 10 ^ n := by
  induction n with
  | zero => decide
  | succ k ih => omega

theorem pow10_int_pos (n : Nat) : (0 : Int) < ((10 ^ n : Nat) : Int) :=
  Int.ofNat_lt.mpr (pow10_pos n)

theorem valEq_trans {x y z : DecLit} (hxy : valEq x y) (hyz : valEq y z) : valEq x z := by
  unfold valEq at *
  have hy_pos : (0 : Int) < ((10 ^ y.scale10 : Nat) : Int) := pow10_int_pos y.scale10
  have hmul :
      (x.mantissa * ((10 ^ z.scale10 : Nat) : Int) - z.mantissa * ((10 ^ x.scale10 : Nat) : Int)) *
        ((10 ^ y.scale10 : Nat) : Int) = 0 := by
    calc
      (x.mantissa * ((10 ^ z.scale10 : Nat) : Int) - z.mantissa * ((10 ^ x.scale10 : Nat) : Int)) *
          ((10 ^ y.scale10 : Nat) : Int)
          = (x.mantissa * ((10 ^ y.scale10 : Nat) : Int)) * ((10 ^ z.scale10 : Nat) : Int) -
            (z.mantissa * ((10 ^ y.scale10 : Nat) : Int)) * ((10 ^ x.scale10 : Nat) : Int) := by
              rw [Int.sub_mul, Int.mul_assoc, Int.mul_comm ((10 ^ z.scale10 : Nat) : Int), ← Int.mul_assoc,
                  Int.mul_assoc z.mantissa, Int.mul_comm ((10 ^ x.scale10 : Nat) : Int), ← Int.mul_assoc]
      _ = (y.mantissa * ((10 ^ x.scale10 : Nat) : Int)) * ((10 ^ z.scale10 : Nat) : Int) -
            (y.mantissa * ((10 ^ z.scale10 : Nat) : Int)) * ((10 ^ x.scale10 : Nat) : Int) := by
              rw [hxy, hyz.symm]
      _ = 0 := by
          rw [Int.mul_assoc, Int.mul_comm ((10 ^ x.scale10 : Nat) : Int), ← Int.mul_assoc, Int.sub_self]
  cases Int.mul_eq_zero.mp hmul with
  | inl hdiff => omega
  | inr hpow0 => omega

/-- Explicit separation proof: `1.0` and `1.00` are value-equal (`valEq`) but NOT format-equal (`fmtEq`). -/
theorem one_point_zero_valEq_not_fmtEq :
    valEq { mantissa := 10, scale10 := 1 } { mantissa := 100, scale10 := 2 } ∧
    ¬ fmtEq { mantissa := 10, scale10 := 1 } { mantissa := 100, scale10 := 2 } := by
  decide

/-- Canonical embedding of any `DecLit` into `ExactRat`. -/
def toExactRat (x : DecLit) : ExactRat :=
  let den := 10 ^ x.scale10
  have hpos : 0 < den := pow10_pos x.scale10
  let g := Nat.gcd x.mantissa.natAbs den
  have hg_pos : 0 < g := Nat.gcd_pos_of_pos_right x.mantissa.natAbs hpos
  have hg_le : g ≤ den := Nat.le_of_dvd hpos (Nat.gcd_dvd_right x.mantissa.natAbs den)
  { num := ExactRat.divByGcdInt x.mantissa g
    den := den / g
    den_pos := Nat.div_pos hg_le hg_pos
    reduced := by
      rw [ExactRat.divByGcdInt_natAbs]
      exact ExactRat.gcd_div_gcd_eq_one hpos }

end DecLit
end BrocaOmega.P1
```

### 4.4 `01_formal_spec/FormalSpec/Arithmetic/Rounding.lean`
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P1
  FormalSpec/Arithmetic/Rounding.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies)
  Proves the 3-way equivalence between:
    1. `ValidRoundAwz` (Division-free integer cross-multiplication kernel predicate)
    2. `roundHalfAwayFromZero` (Total Euclidean quotient rounding function)
    3. `IsNearestIntHalfAway` (Universal ∀ k ∈ ℤ closest-integer distance & tie-breaking spec)
  plus determinism, sign symmetry, zero canonicalization, scale invariance, and 0.5 boundary safety.
-/
import FormalSpec.Arithmetic.DecLit

namespace BrocaOmega.P1

/-- Exact integer power of 10: `10 ^ d` in `Int` (avoids `↑(10 ^ d)` vs `10 ^ d` cast friction). -/
abbrev pow10Int (d : Nat) : Int := ((10 ^ d : Nat) : Int)

theorem pow10Int_pos (d : Nat) : 0 < pow10Int d :=
  DecLit.pow10_int_pos d

/--
  Gate C0-R1 Division-Free Cross-Multiplication Rounding Predicate (`RoundHalfAwayFromZero`).
  Verifies whether `m * 10^(-d)` is the half-away-from-zero rounding of `p / q` (`q > 0`).
-/
def ValidRoundAwz (p : Int) (q : Nat) (m : Int) (d : Nat) : Prop :=
  0 < q ∧
  ((p = 0 ∧ m = 0) ∨
   (0 < p ∧ 0 ≤ m ∧
     (q : Int) * (2 * m - 1) ≤ 2 * pow10Int d * p ∧
     2 * pow10Int d * p < (q : Int) * (2 * m + 1)) ∨
   (p < 0 ∧ m ≤ 0 ∧
     (q : Int) * (-2 * m - 1) ≤ 2 * pow10Int d * (-p) ∧
     2 * pow10Int d * (-p) < (q : Int) * (-2 * m + 1)))

instance (p : Int) (q : Nat) (m : Int) (d : Nat) : Decidable (ValidRoundAwz p q m d) := by
  unfold ValidRoundAwz
  infer_instance

/-- Euclidean quotient core on non-negative magnitudes: `(2 * 10^d * absP + q) / (2 * q)`. -/
def roundHalfAwayNat (absP : Nat) (q : Nat) (d : Nat) : Nat :=
  (2 * (10 ^ d) * absP + q) / (2 * q)

/--
  Total reference function for `RoundHalfAwayFromZero(10^d * p / q)`.
-/
def roundHalfAwayFromZero (p : Int) (q : Nat) (d : Nat) : Int :=
  if q = 0 then 0
  else if p = 0 then 0
  else if 0 < p then
    Nat.cast (roundHalfAwayNat p.natAbs q d)
  else
    - Nat.cast (roundHalfAwayNat p.natAbs q d)

/--
  Scaled rational distance `|2 * 10^d * p - 2 * q * k| = 2 * q * |10^d * (p / q) - k|`.
-/
def scaledDist2Q (p : Int) (q : Nat) (d : Nat) (k : Int) : Nat :=
  (2 * pow10Int d * p - 2 * (q : Int) * k).natAbs

/--
  Independent Declarative Metric Specification (`IsNearestIntHalfAway`):
  `m` minimizes exact rational distance to `10^d * (p / q)` across all `k ∈ ℤ`,
  and breaks exact `0.5` halfway ties strictly away from zero (`k.natAbs < m.natAbs`).
-/
def IsNearestIntHalfAway (p : Int) (q : Nat) (d : Nat) (m : Int) : Prop :=
  0 < q ∧
  (∀ k : Int, scaledDist2Q p q d m ≤ scaledDist2Q p q d k) ∧
  (∀ k : Int, scaledDist2Q p q d k = scaledDist2Q p q d m → k ≠ m → k.natAbs < m.natAbs)

/-! ### Bilinear Ring Identities & Euclidean Division Uniqueness Lemmas -/

private theorem expand_q_two_m_sub_one (q m : Int) :
    q * (2 * m - 1) = 2 * (q * m) - q := by
  rw [Int.mul_sub, Int.mul_one, ← Int.mul_assoc, Int.mul_comm q 2, Int.mul_assoc]

private theorem expand_q_two_m_add_one (q m : Int) :
    q * (2 * m + 1) = 2 * (q * m) + q := by
  rw [Int.mul_add, Int.mul_one, ← Int.mul_assoc, Int.mul_comm q 2, Int.mul_assoc]

/-- Natural-number Euclidean quotient characterization: `N / B = m ↔ B * m ≤ N ∧ N < B * (m + 1)`. -/
theorem nat_div_eq_iff_bounds {N B m : Nat} (hB : 0 < B) :
    N / B = m ↔ B * m ≤ N ∧ N < B * (m + 1) := by
  constructor
  · intro hdiv
    have hmod : N % B < B := Nat.mod_lt N hB
    have halg : B * (N / B) + N % B = N := Nat.div_add_mod N B
    rw [hdiv] at halg
    rw [Nat.mul_add, Nat.mul_one]
    omega
  · rintro ⟨hlo, hhi⟩
    have hmod : N % B < B := Nat.mod_lt N hB
    have halg : B * (N / B) + N % B = N := Nat.div_add_mod N B
    let qv := N / B
    have hqv_eq : N / B = qv := rfl
    rw [hqv_eq] at halg ⊢
    by_cases hlt : qv < m
    · have hle1 : qv + 1 ≤ m := hlt
      have hmul : B * (qv + 1) ≤ B * m := Nat.mul_le_mul_left B hle1
      rw [Nat.mul_add, Nat.mul_one] at hmul
      omega
    · by_cases hgt : m < qv
      · have hle2 : m + 1 ≤ qv := hgt
        have hmul : B * (m + 1) ≤ B * qv := Nat.mul_le_mul_left B hle2
        omega
      · omega

/-- Core bridge between `(A + q) / (2 * q) = m` and `q * (2m - 1) ≤ A < q * (2m + 1)`. -/
theorem nat_halfway_div_iff_int_bounds {A q m : Nat} (hq : 0 < q) :
    (A + q) / (2 * q) = m ↔
      (q : Int) * (2 * (m : Int) - 1) ≤ (A : Int) ∧ (A : Int) < (q : Int) * (2 * (m : Int) + 1) := by
  have h2q : 0 < 2 * q := by omega
  rw [nat_div_eq_iff_bounds h2q]
  have he1 : (q : Int) * (2 * (m : Int) - 1) = 2 * ((q : Int) * (m : Int)) - (q : Int) :=
    expand_q_two_m_sub_one (q : Int) (m : Int)
  have he2 : (q : Int) * (2 * (m : Int) + 1) = 2 * ((q : Int) * (m : Int)) + (q : Int) :=
    expand_q_two_m_add_one (q : Int) (m : Int)
  have hcast1 : (((2 * q) * m : Nat) : Int) = 2 * ((q : Int) * (m : Int)) := by
    rw [Int.natCast_mul, Int.natCast_mul, Int.mul_assoc]; rfl
  have hcast2 : (((2 * q) * (m + 1) : Nat) : Int) = 2 * ((q : Int) * (m : Int)) + 2 * (q : Int) := by
    rw [Nat.mul_add, Nat.mul_one, Int.natCast_add, hcast1, Int.natCast_mul]; rfl
  constructor
  · rintro ⟨hlo_nat, hhi_nat⟩
    have hlo_i : (((2 * q) * m : Nat) : Int) ≤ ((A + q : Nat) : Int) := Int.ofNat_le.mpr hlo_nat
    have hhi_i : ((A + q : Nat) : Int) < (((2 * q) * (m + 1) : Nat) : Int) := Int.ofNat_lt.mpr hhi_nat
    rw [hcast1, Int.natCast_add] at hlo_i
    rw [hcast2, Int.natCast_add] at hhi_i
    rw [he1, he2]
    omega
  · rintro ⟨hlo_i, hhi_i⟩
    rw [he1] at hlo_i
    rw [he2] at hhi_i
    have hlo_c : (((2 * q) * m : Nat) : Int) ≤ ((A + q : Nat) : Int) := by
      rw [hcast1, Int.natCast_add]; omega
    have hhi_c : ((A + q : Nat) : Int) < (((2 * q) * (m + 1) : Nat) : Int) := by
      rw [hcast2, Int.natCast_add]; omega
    exact ⟨Int.ofNat_le.mp hlo_c, Int.ofNat_lt.mp hhi_c⟩

/--
  THEOREM 1 (Main Equivalence — `PO-C1-04a` Core):
  For all `p ∈ ℤ`, `q > 0`, `m ∈ ℤ`, `d ∈ ℕ`:
  `ValidRoundAwz p q m d ↔ m = roundHalfAwayFromZero p q d`.
-/
theorem validRoundAwz_iff_eq_roundHalfAway {p : Int} {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz p q m d ↔ m = roundHalfAwayFromZero p q d := by
  have hq_ne : q ≠ 0 := Nat.ne_of_gt hq
  by_cases hp0 : p = 0
  · subst hp0
    unfold ValidRoundAwz roundHalfAwayFromZero
    simp [hq, hq_ne]
  · by_cases hpos : 0 < p
    · have hp_not_lt : ¬(p < 0) := by omega
      have hp_abs : ((p.natAbs : Nat) : Int) = p := Int.natAbs_of_nonneg (Int.le_of_lt hpos)
      let A : Nat := 2 * (10 ^ d) * p.natAbs
      have hA : (A : Int) = 2 * pow10Int d * p := by
        dsimp [A, pow10Int]
        rw [hp_abs]
      constructor
      · intro hv
        rcases hv with ⟨_, h0 | hp_branch | hn_branch⟩
        · exact absurd h0.1 hp0
        · rcases hp_branch with ⟨_, hm_nonneg, hlo, hhi⟩
          let mNat := m.natAbs
          have hm_eq : ((mNat : Nat) : Int) = m := Int.natAbs_of_nonneg hm_nonneg
          rw [← hm_eq, ← hA] at hlo hhi
          have hdiv : roundHalfAwayNat p.natAbs q d = mNat :=
            (nat_halfway_div_iff_int_bounds hq).mpr ⟨hlo, hhi⟩
          unfold roundHalfAwayFromZero
          rw [if_neg hq_ne, if_neg hp0, if_pos hpos, hdiv]
          exact hm_eq.symm
        · exact absurd hn_branch.1 hp_not_lt
      · intro hm_eq
        unfold roundHalfAwayFromZero at hm_eq
        rw [if_neg hq_ne, if_neg hp0, if_pos hpos] at hm_eq
        subst hm_eq
        let mNat := roundHalfAwayNat p.natAbs q d
        have ⟨hlo, hhi⟩ := (nat_halfway_div_iff_int_bounds (A := A) (m := mNat) hq).mp rfl
        rw [hA] at hlo hhi
        exact ⟨hq, Or.inr (Or.inl ⟨hpos, Int.natCast_nonneg mNat, hlo, hhi⟩)⟩
    · have hneg : p < 0 := by omega
      have hp_abs : ((p.natAbs : Nat) : Int) = -p := by omega
      let A : Nat := 2 * (10 ^ d) * p.natAbs
      have hA : (A : Int) = 2 * pow10Int d * (-p) := by
        dsimp [A, pow10Int]
        rw [hp_abs]
      constructor
      · intro hv
        rcases hv with ⟨_, h0 | hp_branch | hn_branch⟩
        · exact absurd h0.1 hp0
        · exact absurd hp_branch.1 hpos
        · rcases hn_branch with ⟨_, hm_nonpos, hlo, hhi⟩
          let mNat := m.natAbs
          have hm_abs : ((mNat : Nat) : Int) = -m := by omega
          have h1 : (q : Int) * (-2 * m - 1) = (q : Int) * (2 * (mNat : Int) - 1) :=
            congrArg ((q : Int) * ·) (by omega)
          have h2 : (q : Int) * (-2 * m + 1) = (q : Int) * (2 * (mNat : Int) + 1) :=
            congrArg ((q : Int) * ·) (by omega)
          rw [h1, ← hA] at hlo
          rw [h2, ← hA] at hhi
          have hdiv : roundHalfAwayNat p.natAbs q d = mNat :=
            (nat_halfway_div_iff_int_bounds hq).mpr ⟨hlo, hhi⟩
          unfold roundHalfAwayFromZero
          rw [if_neg hq_ne, if_neg hp0, if_neg hpos, hdiv]
          omega
      · intro hm_eq
        unfold roundHalfAwayFromZero at hm_eq
        rw [if_neg hq_ne, if_neg hp0, if_neg hpos] at hm_eq
        subst hm_eq
        let mNat := roundHalfAwayNat p.natAbs q d
        have ⟨hlo, hhi⟩ := (nat_halfway_div_iff_int_bounds (A := A) (m := mNat) hq).mp rfl
        rw [hA] at hlo hhi
        have h1 : (q : Int) * (-2 * -((mNat : Nat) : Int) - 1) = (q : Int) * (2 * (mNat : Int) - 1) :=
          congrArg ((q : Int) * ·) (by omega)
        have h2 : (q : Int) * (-2 * -((mNat : Nat) : Int) + 1) = (q : Int) * (2 * (mNat : Int) + 1) :=
          congrArg ((q : Int) * ·) (by omega)
        have hm_le : -((mNat : Nat) : Int) ≤ 0 := by omega
        refine ⟨hq, Or.inr (Or.inr ⟨hneg, hm_le, ?_, ?_⟩)⟩
        · rw [h1]; exact hlo
        · rw [h2]; exact hhi

/-- Specialization of Main Equivalence directly to `ExactRat`. -/
theorem ExactRat.validRoundAwz_iff (r : ExactRat) (m : Int) (d : Nat) :
    ValidRoundAwz r.num r.den m d ↔ m = roundHalfAwayFromZero r.num r.den d :=
  validRoundAwz_iff_eq_roundHalfAway r.den_pos m d

/-! ### Determinism, Totality, Sign Symmetry, Zero Canonicalization -/

/-- Determinism: for given `(p, q, d)`, at most one integer `m` satisfies `ValidRoundAwz`. -/
theorem validRoundAwz_unique {p : Int} {q : Nat} {m₁ m₂ : Int} {d : Nat}
    (h₁ : ValidRoundAwz p q m₁ d) (h₂ : ValidRoundAwz p q m₂ d) : m₁ = m₂ := by
  have hq : 0 < q := h₁.1
  rw [validRoundAwz_iff_eq_roundHalfAway hq] at h₁ h₂
  exact h₁.trans h₂.symm

/-- Totality: `roundHalfAwayFromZero` always produces a valid witness when `q > 0`. -/
theorem validRoundAwz_roundHalfAway {p : Int} {q : Nat} (hq : 0 < q) (d : Nat) :
    ValidRoundAwz p q (roundHalfAwayFromZero p q d) d :=
  (validRoundAwz_iff_eq_roundHalfAway hq _ d).mpr rfl

/-- Sign Symmetry of `roundHalfAwayFromZero`: `R(-p, q, d) = - R(p, q, d)`. -/
theorem roundHalfAwayFromZero_neg (p : Int) (q : Nat) (d : Nat) :
    roundHalfAwayFromZero (-p) q d = - roundHalfAwayFromZero p q d := by
  by_cases hq : q = 0
  · unfold roundHalfAwayFromZero; rw [if_pos hq, if_pos hq]; rfl
  · by_cases hp0 : p = 0
    · subst hp0; unfold roundHalfAwayFromZero; simp [hq]
    · by_cases hpos : 0 < p
      · have hneg : ¬(0 < -p) := by omega
        have hne : -p ≠ 0 := by omega
        unfold roundHalfAwayFromZero
        rw [if_neg hq, if_neg hne, if_neg hneg, if_neg hq, if_neg hp0, if_pos hpos, Int.natAbs_neg]
      · have hpos_neg : 0 < -p := by omega
        have hne : -p ≠ 0 := by omega
        unfold roundHalfAwayFromZero
        rw [if_neg hq, if_neg hne, if_pos hpos_neg, if_neg hq, if_neg hp0, if_neg hpos,
            Int.natAbs_neg, Int.neg_neg]

/-- Sign Symmetry on `ExactRat`: `R(-r, d) = - R(r, d)`. -/
theorem ExactRat.roundHalfAway_neg (r : ExactRat) (d : Nat) :
    roundHalfAwayFromZero r.neg.num r.neg.den d = - roundHalfAwayFromZero r.num r.den d := by
  simp [roundHalfAwayFromZero_neg]

/-- Sign Symmetry of `ValidRoundAwz`: `ValidRoundAwz (-p) q (-m) d ↔ ValidRoundAwz p q m d`. -/
theorem validRoundAwz_neg_iff (p : Int) (q : Nat) (m : Int) (d : Nat) :
    ValidRoundAwz (-p) q (-m) d ↔ ValidRoundAwz p q m d := by
  by_cases hq : 0 < q
  · rw [validRoundAwz_iff_eq_roundHalfAway hq, validRoundAwz_iff_eq_roundHalfAway hq,
        roundHalfAwayFromZero_neg]
    omega
  · unfold ValidRoundAwz
    simp [hq]

/-- Zero Canonicalization: rounding `0 / q` (`q > 0`) at any precision `d` yields `0`. -/
@[simp]
theorem roundHalfAwayFromZero_zero (q d : Nat) :
    roundHalfAwayFromZero 0 q d = 0 := by
  unfold roundHalfAwayFromZero
  split <;> rfl

theorem validRoundAwz_zero_iff {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz 0 q m d ↔ m = 0 := by
  rw [validRoundAwz_iff_eq_roundHalfAway hq, roundHalfAwayFromZero_zero]

/-! ### Metric Optimality Equivalence (`ValidRoundAwz ↔ IsNearestIntHalfAway`) -/

private theorem pos_bounds_imply_nearest {P q m : Int}
    (hP : 0 < P) (hq : 0 < q) (hm : 0 ≤ m)
    (hlo : q * (2 * m - 1) ≤ 2 * P) (hhi : 2 * P < q * (2 * m + 1)) :
    (∀ k : Int, (2 * P - 2 * q * m).natAbs ≤ (2 * P - 2 * q * k).natAbs) ∧
    (∀ k : Int, (2 * P - 2 * q * k).natAbs = (2 * P - 2 * q * m).natAbs → k ≠ m → k.natAbs < m.natAbs) := by
  have he_lo : 2 * (q * m) - q ≤ 2 * P := by rw [← expand_q_two_m_sub_one]; exact hlo
  have he_hi : 2 * P < 2 * (q * m) + q := by rw [← expand_q_two_m_add_one]; exact hhi
  have h2qm : 2 * q * m = 2 * (q * m) := Int.mul_assoc 2 q m
  constructor
  · intro k
    have h2qk : 2 * q * k = 2 * (q * k) := Int.mul_assoc 2 q k
    rw [h2qm, h2qk]
    by_cases hkm : k = m
    · subst hkm; exact Nat.le_refl _
    · by_cases hk_gt : m + 1 ≤ k
      · have hqk : q * m + q ≤ q * k := by
          have : q * (m + 1) ≤ q * k := Int.mul_le_mul_of_nonneg_left hk_gt (by omega)
          rw [Int.mul_add, Int.mul_one] at this; exact this
        omega
      · by_cases hk_eq : k = m - 1
        · subst hk_eq
          have hqk : q * (m - 1) = q * m - q := by rw [Int.mul_sub, Int.mul_one]
          rw [hqk]
          omega
        · have hk_le : k ≤ m - 2 := by omega
          have hqk : q * k ≤ q * m - 2 * q := by
            have : q * k ≤ q * (m - 2) := Int.mul_le_mul_of_nonneg_left hk_le (by omega)
            have hsub : q * (m - 2) = q * m - 2 * q := by
              rw [Int.mul_sub, Int.mul_comm q 2]
            rw [hsub] at this; exact this
          omega
  · intro k hdist hne
    have h2qk : 2 * q * k = 2 * (q * k) := Int.mul_assoc 2 q k
    rw [h2qm, h2qk] at hdist
    by_cases hk_gt : m + 1 ≤ k
    · have hqk : q * m + q ≤ q * k := by
        have : q * (m + 1) ≤ q * k := Int.mul_le_mul_of_nonneg_left hk_gt (by omega)
        rw [Int.mul_add, Int.mul_one] at this; exact this
      omega
    · by_cases hk_eq : k = m - 1
      · subst hk_eq
        have hqk : q * (m - 1) = q * m - q := by rw [Int.mul_sub, Int.mul_one]
        rw [hqk] at hdist
        -- When m = 0, 2*P ≥ 2 and q ≥ 1 make |2P + 2q| = |2P| impossible!
        have hm1 : 1 ≤ m := by
          by_cases hm0 : m = 0
          · subst hm0; simp at he_lo he_hi hdist; omega
          · omega
        omega
      · have hk_le : k ≤ m - 2 := by omega
        have hqk : q * k ≤ q * m - 2 * q := by
          have : q * k ≤ q * (m - 2) := Int.mul_le_mul_of_nonneg_left hk_le (by omega)
          have hsub : q * (m - 2) = q * m - 2 * q := by
            rw [Int.mul_sub, Int.mul_comm q 2]
          rw [hsub] at this; exact this
        omega

/-- Forward Lemma: `ValidRoundAwz → IsNearestIntHalfAway`. -/
theorem validRoundAwz_implies_isNearest {p : Int} {q : Nat} {m : Int} {d : Nat}
    (hv : ValidRoundAwz p q m d) : IsNearestIntHalfAway p q d m := by
  have hq : 0 < q := hv.1
  have hq_int : (0 : Int) < (q : Int) := Int.ofNat_lt.mpr hq
  refine ⟨hq, ?_⟩
  rcases hv with ⟨_, hzero | hpos | hneg⟩
  · rcases hzero with ⟨hp0, hm0⟩
    subst hp0 hm0
    unfold scaledDist2Q
    constructor
    · intro k; simp
    · intro k hdist hne
      simp at hdist
      have hqk : (2 * (q : Int)) * k = 0 := by omega
      cases Int.mul_eq_zero.mp hqk with
      | inl h => omega
      | inr h => exact absurd h hne
  · rcases hpos with ⟨hp, hm, hlo, hhi⟩
    let P : Int := pow10Int d * p
    have hP_pos : 0 < P := Int.mul_pos (pow10Int_pos d) hp
    have h2P : 2 * pow10Int d * p = 2 * P := Int.mul_assoc 2 (pow10Int d) p
    rw [h2P] at hlo hhi
    have ⟨hd1, hd2⟩ := pos_bounds_imply_nearest hP_pos hq_int hm hlo hhi
    unfold scaledDist2Q
    simp only [h2P]
    exact ⟨hd1, hd2⟩
  · rcases hneg with ⟨hp, hm, hlo, hhi⟩
    let P : Int := pow10Int d * (-p)
    have hP_pos : 0 < P := Int.mul_pos (pow10Int_pos d) (by omega)
    have h2P : 2 * pow10Int d * (-p) = 2 * P := Int.mul_assoc 2 (pow10Int d) (-p)
    rw [h2P] at hlo hhi
    have hm_neg_nonneg : 0 ≤ -m := by omega
    have hlo' : (q : Int) * (2 * (-m) - 1) ≤ 2 * P := by
      have h1 : (q : Int) * (2 * (-m) - 1) = (q : Int) * (-2 * m - 1) := congrArg ((q : Int) * ·) (by omega)
      rw [h1]; exact hlo
    have hhi' : 2 * P < (q : Int) * (2 * (-m) + 1) := by
      have h2 : (q : Int) * (2 * (-m) + 1) = (q : Int) * (-2 * m + 1) := congrArg ((q : Int) * ·) (by omega)
      rw [h2]; exact hhi
    have ⟨hd1, hd2⟩ := pos_bounds_imply_nearest hP_pos hq_int hm_neg_nonneg hlo' hhi'
    have hsym : ∀ k : Int, scaledDist2Q p q d k = (2 * P - 2 * (q : Int) * (-k)).natAbs := by
      intro k
      unfold scaledDist2Q
      have hp1 : 2 * P = - (2 * pow10Int d * p) := by
        dsimp [P]
        rw [← Int.mul_assoc, Int.mul_neg]
      have hk1 : 2 * (q : Int) * (-k) = - (2 * (q : Int) * k) := Int.mul_neg _ _
      have hdiff : 2 * pow10Int d * p - 2 * (q : Int) * k = - (2 * P - 2 * (q : Int) * (-k)) := by
        omega
      rw [hdiff, Int.natAbs_neg]
    constructor
    · intro k
      rw [hsym m, hsym k]
      exact hd1 (-k)
    · intro k heq_dist hne
      rw [hsym k, hsym m] at heq_dist
      have hlt := hd2 (-k) heq_dist (by omega)
      simpa [Int.natAbs_neg] using hlt

/--
  THEOREM 2 (Metric Adequacy — Non-Circular Closest-Integer Equivalence):
  `ValidRoundAwz p q m d ↔ IsNearestIntHalfAway p q d m`.
-/
theorem validRoundAwz_iff_isNearestIntHalfAway {p : Int} {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz p q m d ↔ IsNearestIntHalfAway p q d m := by
  constructor
  · exact validRoundAwz_implies_isNearest
  · intro hnear
    let m₀ := roundHalfAwayFromZero p q d
    have hv₀ : ValidRoundAwz p q m₀ d := validRoundAwz_roundHalfAway hq d
    have hnear₀ : IsNearestIntHalfAway p q d m₀ := validRoundAwz_implies_isNearest hv₀
    by_cases heq : m = m₀
    · rw [heq]; exact hv₀
    · have hle1 : scaledDist2Q p q d m ≤ scaledDist2Q p q d m₀ := hnear.2.1 m₀
      have hle2 : scaledDist2Q p q d m₀ ≤ scaledDist2Q p q d m := hnear₀.2.1 m
      have hdist_eq : scaledDist2Q p q d m₀ = scaledDist2Q p q d m := Nat.le_antisymm hle2 hle1
      have hlt1 : m₀.natAbs < m.natAbs := hnear.2.2 m₀ hdist_eq (Ne.symm heq)
      have hlt2 : m.natAbs < m₀.natAbs := hnear₀.2.2 m hdist_eq.symm heq
      omega

/-! ### Exact 0.5 Boundary & Scale-Invariance Theorems -/

private theorem pos_of_pos_mul_left {a b : Int} (ha : 0 < a) (hab : 0 < a * b) : 0 < b := by
  by_cases hb : 0 < b
  · exact hb
  · have hle : b ≤ 0 := by omega
    have hnp : a * b ≤ 0 := Int.mul_nonpos_of_nonneg_of_nonpos (Int.le_of_lt ha) hle
    omega

/-- Exact positive 0.5 boundary (`10^d * p / q = k + 0.5`, `k ≥ 0`): rounds AWAY from zero to `k + 1`, rejecting `k`. -/
theorem exact_pos_halfway_boundary {p : Int} {q : Nat} {k : Int} {d : Nat}
    (hq : 0 < q) (hk : 0 ≤ k)
    (hhalf : 2 * pow10Int d * p = (q : Int) * (2 * k + 1)) :
    ValidRoundAwz p q (k + 1) d ∧ ¬ ValidRoundAwz p q k d := by
  have hpow2 : 0 < 2 * pow10Int d := by have := pow10Int_pos d; omega
  have hrhs : 0 < (q : Int) * (2 * k + 1) := Int.mul_pos (Int.ofNat_lt.mpr hq) (by omega)
  have hp_pos : 0 < p := pos_of_pos_mul_left hpow2 (by omega)
  have hlo : (q : Int) * (2 * (k + 1) - 1) ≤ 2 * pow10Int d * p := by
    have : 2 * (k + 1) - 1 = 2 * k + 1 := by omega
    rw [this, hhalf]; exact Int.le_refl _
  have hhi : 2 * pow10Int d * p < (q : Int) * (2 * (k + 1) + 1) := by
    rw [hhalf]
    exact Int.mul_lt_mul_of_pos_left (by omega) (Int.ofNat_lt.mpr hq)
  have hv : ValidRoundAwz p q (k + 1) d := ⟨hq, Or.inr (Or.inl ⟨hp_pos, by omega, hlo, hhi⟩)⟩
  refine ⟨hv, ?_⟩
  intro hvk
  have heq := validRoundAwz_unique hv hvk
  omega

/-- Exact negative -0.5 boundary (`10^d * p / q = -(k + 0.5)`, `k ≥ 0`): rounds AWAY from zero to `-(k + 1)`, rejecting `-k`. -/
theorem exact_neg_halfway_boundary {p : Int} {q : Nat} {k : Int} {d : Nat}
    (hq : 0 < q) (hk : 0 ≤ k)
    (hhalf : 2 * pow10Int d * (-p) = (q : Int) * (2 * k + 1)) :
    ValidRoundAwz p q (-(k + 1)) d ∧ ¬ ValidRoundAwz p q (-k) d := by
  have ⟨hv, hnv⟩ := exact_pos_halfway_boundary (p := -p) hq hk hhalf
  have hv_neg : ValidRoundAwz p q (-(k + 1)) d := by
    have h := (validRoundAwz_neg_iff (-p) q (k + 1) d).mpr hv
    simpa [Int.neg_neg] using h
  refine ⟨hv_neg, ?_⟩
  intro hvk
  have hk_pos : ValidRoundAwz (-p) q k d := by
    have h := (validRoundAwz_neg_iff p q (-k) d).mpr hvk
    simpa [Int.neg_neg] using h
  exact hnv hk_pos

/-- Strictly below positive halfway (`q*(2k - 1) ≤ 2*10^d*p < q*(2k + 1)` with `p > 0, k ≥ 0`): accepts `k`, rejects `k + 1`. -/
theorem strictly_below_pos_halfway {p : Int} {q : Nat} {k : Int} {d : Nat}
    (hq : 0 < q) (hp : 0 < p) (hk : 0 ≤ k)
    (hlo : (q : Int) * (2 * k - 1) ≤ 2 * pow10Int d * p)
    (hhi : 2 * pow10Int d * p < (q : Int) * (2 * k + 1)) :
    ValidRoundAwz p q k d ∧ ¬ ValidRoundAwz p q (k + 1) d := by
  have hv : ValidRoundAwz p q k d := ⟨hq, Or.inr (Or.inl ⟨hp, hk, hlo, hhi⟩)⟩
  refine ⟨hv, ?_⟩
  intro hv_succ
  have heq := validRoundAwz_unique hv hv_succ
  omega

/-- Scale Invariance: equal fractions `(p₁, q₁)` and `(p₂, q₂)` (`q₁, q₂ > 0`) have identical `ValidRoundAwz` behavior. -/
theorem validRoundAwz_of_ratValEq {p₁ p₂ : Int} {q₁ q₂ : Nat} (hq₁ : 0 < q₁) (hq₂ : 0 < q₂)
    (heq : ExactRat.RatValEq p₁ q₁ p₂ q₂) (m : Int) (d : Nat) :
    ValidRoundAwz p₁ q₁ m d → ValidRoundAwz p₂ q₂ m d := by
  unfold ExactRat.RatValEq at heq
  have hq1_int : (0 : Int) < (q₁ : Int) := Int.ofNat_lt.mpr hq₁
  have hq2_int : (0 : Int) < (q₂ : Int) := Int.ofNat_lt.mpr hq₂
  rintro ⟨_, hzero | hpos | hneg⟩
  · rcases hzero with ⟨hp1, hm⟩
    subst hp1 hm
    simp at heq
    have hp2 : p₂ = 0 := by
      cases Int.mul_eq_zero.mp heq.symm with
      | inl h => exact h
      | inr h => omega
    exact ⟨hq₂, Or.inl ⟨hp2, rfl⟩⟩
  · rcases hpos with ⟨hp1, hm, hlo, hhi⟩
    have hprod_pos : 0 < (q₁ : Int) * p₂ := by
      have : 0 < p₁ * (q₂ : Int) := Int.mul_pos hp1 hq2_int
      rw [heq, Int.mul_comm] at this
      exact this
    have hp2 : 0 < p₂ := pos_of_pos_mul_left hq1_int hprod_pos
    have hmul_eq : (q₁ : Int) * (2 * pow10Int d * p₂) = (q₂ : Int) * (2 * pow10Int d * p₁) := by
      calc
        (q₁ : Int) * (2 * pow10Int d * p₂)
            = (2 * pow10Int d) * ((q₁ : Int) * p₂) := by
                rw [← Int.mul_assoc, Int.mul_comm (q₁ : Int) (2 * pow10Int d), Int.mul_assoc]
        _ = (2 * pow10Int d) * (p₂ * (q₁ : Int)) := by rw [Int.mul_comm (q₁ : Int) p₂]
        _ = (2 * pow10Int d) * (p₁ * (q₂ : Int)) := by rw [heq]
        _ = (q₂ : Int) * (2 * pow10Int d * p₁) := by
                rw [← Int.mul_assoc, Int.mul_comm (2 * pow10Int d * p₁) (q₂ : Int)]
    have hcomm_q : ∀ x : Int, (q₂ : Int) * ((q₁ : Int) * x) = (q₁ : Int) * ((q₂ : Int) * x) := by
      intro x
      rw [← Int.mul_assoc, Int.mul_comm (q₂ : Int) (q₁ : Int), Int.mul_assoc]
    have hlo2 : (q₂ : Int) * (2 * m - 1) ≤ 2 * pow10Int d * p₂ := by
      have h1 : (q₁ : Int) * ((q₂ : Int) * (2 * m - 1)) ≤ (q₁ : Int) * (2 * pow10Int d * p₂) := by
        rw [← hcomm_q, hmul_eq]
        exact Int.mul_le_mul_of_nonneg_left hlo (Int.le_of_lt hq2_int)
      exact Int.le_of_mul_le_mul_left h1 hq1_int
    have hhi2 : 2 * pow10Int d * p₂ < (q₂ : Int) * (2 * m + 1) := by
      have h1 : (q₁ : Int) * (2 * pow10Int d * p₂) < (q₁ : Int) * ((q₂ : Int) * (2 * m + 1)) := by
        rw [← hcomm_q, hmul_eq]
        exact Int.mul_lt_mul_of_pos_left hhi hq2_int
      exact Int.lt_of_mul_lt_mul_left h1 (Int.le_of_lt hq1_int)
    exact ⟨hq₂, Or.inr (Or.inl ⟨hp2, hm, hlo2, hhi2⟩)⟩
  · rcases hneg with ⟨hp1, hm, hlo, hhi⟩
    have hneg_pos1 : 0 < -p₁ := by omega
    have hprod_pos : 0 < (q₁ : Int) * (-p₂) := by
      have : 0 < (-p₁) * (q₂ : Int) := Int.mul_pos hneg_pos1 hq2_int
      have heq_neg : (-p₁) * (q₂ : Int) = (q₁ : Int) * (-p₂) := by
        rw [Int.neg_mul, heq, Int.mul_comm, ← Int.mul_neg]
      rw [heq_neg] at this
      exact this
    have hneg_pos2 : 0 < -p₂ := pos_of_pos_mul_left hq1_int hprod_pos
    have hp2 : p₂ < 0 := by omega
    have hmul_eq : (q₁ : Int) * (2 * pow10Int d * (-p₂)) = (q₂ : Int) * (2 * pow10Int d * (-p₁)) := by
      have heq_neg : (-p₂) * (q₁ : Int) = (-p₁) * (q₂ : Int) := by
        rw [Int.neg_mul, Int.neg_mul, heq]
      calc
        (q₁ : Int) * (2 * pow10Int d * (-p₂))
            = (2 * pow10Int d) * ((q₁ : Int) * (-p₂)) := by
                rw [← Int.mul_assoc, Int.mul_comm (q₁ : Int) (2 * pow10Int d), Int.mul_assoc]
        _ = (2 * pow10Int d) * ((-p₂) * (q₁ : Int)) := by rw [Int.mul_comm (q₁ : Int) (-p₂)]
        _ = (2 * pow10Int d) * ((-p₁) * (q₂ : Int)) := by rw [heq_neg]
        _ = (q₂ : Int) * (2 * pow10Int d * (-p₁)) := by
                rw [← Int.mul_assoc, Int.mul_comm (2 * pow10Int d * (-p₁)) (q₂ : Int)]
    have hcomm_q : ∀ x : Int, (q₂ : Int) * ((q₁ : Int) * x) = (q₁ : Int) * ((q₂ : Int) * x) := by
      intro x
      rw [← Int.mul_assoc, Int.mul_comm (q₂ : Int) (q₁ : Int), Int.mul_assoc]
    have hlo2 : (q₂ : Int) * (-2 * m - 1) ≤ 2 * pow10Int d * (-p₂) := by
      have h1 : (q₁ : Int) * ((q₂ : Int) * (-2 * m - 1)) ≤ (q₁ : Int) * (2 * pow10Int d * (-p₂)) := by
        rw [← hcomm_q, hmul_eq]
        exact Int.mul_le_mul_of_nonneg_left hlo (Int.le_of_lt hq2_int)
      exact Int.le_of_mul_le_mul_left h1 hq1_int
    have hhi2 : 2 * pow10Int d * (-p₂) < (q₂ : Int) * (-2 * m + 1) := by
      have h1 : (q₁ : Int) * (2 * pow10Int d * (-p₂)) < (q₁ : Int) * ((q₂ : Int) * (-2 * m + 1)) := by
        rw [← hcomm_q, hmul_eq]
        exact Int.mul_lt_mul_of_pos_left hhi hq2_int
      exact Int.lt_of_mul_lt_mul_left h1 (Int.le_of_lt hq1_int)
    exact ⟨hq₂, Or.inr (Or.inr ⟨hp2, hm, hlo2, hhi2⟩)⟩

theorem validRoundAwz_iff_of_ratValEq {p₁ p₂ : Int} {q₁ q₂ : Nat} (hq₁ : 0 < q₁) (hq₂ : 0 < q₂)
    (heq : ExactRat.RatValEq p₁ q₁ p₂ q₂) (m : Int) (d : Nat) :
    ValidRoundAwz p₁ q₁ m d ↔ ValidRoundAwz p₂ q₂ m d :=
  ⟨validRoundAwz_of_ratValEq hq₁ hq₂ heq m d,
   validRoundAwz_of_ratValEq hq₂ hq₁ heq.symm m d⟩

end BrocaOmega.P1
```

### 4.5 `02_detached_checker/DetachedChecker.lean` & `P1ArithmeticChecker.lean`
```lean
-- 02_detached_checker/DetachedChecker.lean
import DetachedChecker.P1ArithmeticChecker
```
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P1
  DetachedChecker/P1ArithmeticChecker.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies)
  Implements the detached exact rational & rounding verification gate with a private
  `CertifiedRoundingWitness` constructor, plus end-to-end soundness and completeness theorems.
  Note: `P1-C` (Int128/UInt128 fixed-width optimization) is strictly excluded per `AUTH-C1-P1`.
-/
import FormalSpec

namespace BrocaOmega.P1.Checker

/-- Canonical `ExactRat` constructor given a proof `0 < den`. -/
def mkCanonicalRat (num : Int) (den : Nat) (hpos : 0 < den) :
    { r : ExactRat // ExactRat.RatValEq num den r.num r.den } :=
  let g := Nat.gcd num.natAbs den
  have hg_pos : 0 < g := Nat.gcd_pos_of_pos_right num.natAbs hpos
  have hg_le : g ≤ den := Nat.le_of_dvd hpos (Nat.gcd_dvd_right num.natAbs den)
  let r : ExactRat :=
    { num := ExactRat.divByGcdInt num g
      den := den / g
      den_pos := Nat.div_pos hg_le hg_pos
      reduced := by
        rw [ExactRat.divByGcdInt_natAbs]
        exact ExactRat.gcd_div_gcd_eq_one hpos }
  have heq : ExactRat.RatValEq num den r.num r.den := by
    unfold ExactRat.RatValEq
    dsimp [r]
    have hdvd_n : g ∣ num.natAbs := Nat.gcd_dvd_left num.natAbs den
    have hdvd_d : g ∣ den := Nat.gcd_dvd_right num.natAbs den
    have hn : ExactRat.divByGcdInt num g * (g : Int) = num := ExactRat.divByGcdInt_mul_cancel hdvd_n
    have hd_nat : (den / g) * g = den := Nat.div_mul_cancel hdvd_d
    have hd : ((den / g : Nat) : Int) * (g : Int) = (den : Int) := by exact_mod_cast hd_nat
    have hstep1 : num * ((den / g : Nat) : Int) =
        (ExactRat.divByGcdInt num g * (g : Int)) * ((den / g : Nat) : Int) :=
      congrArg (· * ((den / g : Nat) : Int)) hn.symm
    calc
      num * ((den / g : Nat) : Int)
          = (ExactRat.divByGcdInt num g * (g : Int)) * ((den / g : Nat) : Int) := hstep1
      _ = ExactRat.divByGcdInt num g * (((den / g : Nat) : Int) * (g : Int)) := by
            rw [Int.mul_assoc, Int.mul_comm (g : Int)]
      _ = ExactRat.divByGcdInt num g * (den : Int) := by rw [hd]
  ⟨r, heq⟩

/-- Proof-carrying token admission wrapper binding both `mantissa` and `scale10` directly to `raw`. -/
def admitRawTokenChecked (raw : RawDecToken) (maxScale : Nat) :
    Except P1ArithRejectReason
      { surf : DecLit //
        ¬(raw.negSign = true ∧ raw.absMantissa = 0) ∧
        surf.mantissa = raw.toSignedInt ∧
        surf.scale10 = raw.scale10 ∧
        surf.scale10 ≤ maxScale } :=
  if hneg0 : (raw.negSign && raw.absMantissa == 0) = true then
    .error .negativeZeroForbidden
  else if hover : raw.scale10 > maxScale then
    .error (.scaleBoundExceeded raw.scale10 maxScale)
  else
    have hno_neg0 : ¬(raw.negSign = true ∧ raw.absMantissa = 0) := by
      rintro ⟨hns, ha0⟩
      apply hneg0
      simp [hns, ha0]
    have hle : raw.scale10 ≤ maxScale := by omega
    .ok ⟨{ mantissa := raw.toSignedInt, scale10 := raw.scale10 }, ⟨hno_neg0, rfl, rfl, hle⟩⟩

/--
  Kernel-sealed proof-carrying rounding witness.
  `private mk` ensures untrusted callers cannot construct `CertifiedRoundingWitness` directly.
-/
structure CertifiedRoundingWitness
    (rawNum : Int) (rawDen : Nat) (rawSurface : RawDecToken) (expectedScale maxScale : Nat) where
  private mk ::
  canonicalRat   : ExactRat
  surfaceLit     : DecLit
  h_den_pos      : 0 < rawDen
  h_no_neg0      : ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0)
  h_raw_mantissa : surfaceLit.mantissa = rawSurface.toSignedInt
  h_raw_scale    : rawSurface.scale10 = expectedScale
  h_rat_equiv    : ExactRat.RatValEq rawNum rawDen canonicalRat.num canonicalRat.den
  h_scale_eq     : surfaceLit.scale10 = expectedScale
  h_scale_le     : expectedScale ≤ maxScale
  h_round_rat    : ValidRoundAwz canonicalRat.num canonicalRat.den surfaceLit.mantissa expectedScale
  h_round_raw    : ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale

/--
  Detached P1 Verification Gate (`verifyRoundingWitness`):
  Uses `Decidable` reflection on `ValidRoundAwz` over unbounded `Int`/`Nat`.
-/
def verifyRoundingWitness
    (rawNum : Int) (rawDen : Nat) (rawSurface : RawDecToken)
    (expectedScale maxScale : Nat) :
    Except P1ArithRejectReason
      (CertifiedRoundingWitness rawNum rawDen rawSurface expectedScale maxScale) :=
  if hden : 0 < rawDen then
    match admitRawTokenChecked rawSurface maxScale with
    | .error e => .error e
    | .ok sub =>
      let surf := sub.1
      let hno_neg0 := sub.2.1
      let hmant := sub.2.2.1
      let hsurf_raw := sub.2.2.2.1
      let hsurf_le := sub.2.2.2.2
      if hscale : surf.scale10 = expectedScale then
        let ratPair := mkCanonicalRat rawNum rawDen hden
        let rat := ratPair.1
        let hrat_eq := ratPair.2
        if hround : ValidRoundAwz rat.num rat.den surf.mantissa expectedScale then
          have hraw_surf : ValidRoundAwz rawNum rawDen surf.mantissa expectedScale :=
            (validRoundAwz_iff_of_ratValEq hden rat.den_pos hrat_eq surf.mantissa expectedScale).mpr hround
          have hraw_tok : ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale :=
            hmant ▸ hraw_surf
          .ok
            { canonicalRat := rat
              surfaceLit := surf
              h_den_pos := hden
              h_no_neg0 := hno_neg0
              h_raw_mantissa := hmant
              h_raw_scale := hsurf_raw.symm.trans hscale
              h_rat_equiv := hrat_eq
              h_scale_eq := hscale
              h_scale_le := hscale ▸ hsurf_le
              h_round_rat := hround
              h_round_raw := hraw_tok }
        else
          let expectedM := roundHalfAwayFromZero rat.num rat.den expectedScale
          .error (.roundingMismatch expectedM surf.mantissa)
      else
        .error (.formatScaleMismatch expectedScale surf.scale10)
  else
    .error .zeroDenominator

/--
  Detached P1 Kernel Soundness Theorem:
  Every `CertifiedRoundingWitness` admitted by `verifyRoundingWitness` guarantees directly on `rawSurface`:
  1. Positive denominator (`0 < rawDen`)
  2. Absence of `-0.0` (`¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0)`)
  3. Exact precision match & bound (`rawSurface.scale10 = expectedScale ≤ maxScale`)
  4. `ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale`
  5. Exact `RoundHalfAwayFromZero` functional equality (`rawSurface.toSignedInt = roundHalfAwayFromZero ...`)
  6. Universal closest-integer metric optimality (`IsNearestIntHalfAway`)!
-/
theorem verifyRoundingWitness_sound
    {rawNum : Int} {rawDen : Nat} {rawSurface : RawDecToken}
    {expectedScale maxScale : Nat}
    {cert : CertifiedRoundingWitness rawNum rawDen rawSurface expectedScale maxScale}
    (_hok : verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale = .ok cert) :
    0 < rawDen ∧
    ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0) ∧
    rawSurface.scale10 = expectedScale ∧
    expectedScale ≤ maxScale ∧
    ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale ∧
    rawSurface.toSignedInt = roundHalfAwayFromZero rawNum rawDen expectedScale ∧
    IsNearestIntHalfAway rawNum rawDen expectedScale rawSurface.toSignedInt := by
  have hfn : rawSurface.toSignedInt = roundHalfAwayFromZero rawNum rawDen expectedScale :=
    (validRoundAwz_iff_eq_roundHalfAway cert.h_den_pos rawSurface.toSignedInt expectedScale).mp
      cert.h_round_raw
  have hnear : IsNearestIntHalfAway rawNum rawDen expectedScale rawSurface.toSignedInt :=
    (validRoundAwz_iff_isNearestIntHalfAway cert.h_den_pos rawSurface.toSignedInt expectedScale).mp
      cert.h_round_raw
  exact ⟨cert.h_den_pos, cert.h_no_neg0, cert.h_raw_scale, cert.h_scale_le,
         cert.h_round_raw, hfn, hnear⟩

/--
  Detached P1 Kernel Relative Completeness Theorem:
  Any well-formed `rawSurface` within scale bounds whose signed mantissa satisfies `ValidRoundAwz`
  is deterministically accepted (`∃ cert, verifyRoundingWitness ... = .ok cert`).
-/
theorem verifyRoundingWitness_complete
    {rawNum : Int} {rawDen : Nat} {rawSurface : RawDecToken}
    {expectedScale maxScale : Nat}
    (hden : 0 < rawDen)
    (hno_neg0 : ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0))
    (hsc : rawSurface.scale10 = expectedScale)
    (hle : expectedScale ≤ maxScale)
    (hraw : ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale) :
    ∃ cert, verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale = .ok cert := by
  unfold verifyRoundingWitness admitRawTokenChecked
  rw [dif_pos hden]
  have hneg0_false : ¬((rawSurface.negSign && rawSurface.absMantissa == 0) = true) := by
    intro h
    apply hno_neg0
    cases hns : rawSurface.negSign <;> simp [hns] at h ⊢
    exact h
  have hover_false : ¬(rawSurface.scale10 > maxScale) := by omega
  rw [dif_neg hneg0_false, dif_neg hover_false]
  dsimp
  rw [dif_pos hsc]
  let ratPair := mkCanonicalRat rawNum rawDen hden
  have hrat_round : ValidRoundAwz ratPair.1.num ratPair.1.den rawSurface.toSignedInt expectedScale :=
    (validRoundAwz_iff_of_ratValEq hden ratPair.1.den_pos ratPair.2 _ expectedScale).mp hraw
  rw [dif_pos hrat_round]
  exact ⟨_, rfl⟩

/-- Pure error-projection helper for adversarial counterexample verification (`isError` / exact error tag). -/
def checkOutcomeTag
    (rawNum : Int) (rawDen : Nat) (rawSurface : RawDecToken)
    (expectedScale maxScale : Nat) : Except P1ArithRejectReason DecLit :=
  match verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale with
  | .ok cert => .ok cert.surfaceLit
  | .error e => .error e

end BrocaOmega.P1.Checker
```

### 4.6 `03_counterexamples/Counterexamples.lean` & `P1Suite.lean`
```lean
-- 03_counterexamples/Counterexamples.lean
import Counterexamples.P1Suite
```
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P1
  Counterexamples/P1Suite.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies, zero `native_decide`)
  Formalizes & kernel-verifies all P1-D adversarial counterexamples (`CE`) and matched
  same-contract positive controls (`PC`).
  Note: `P1-C` (`Int128` fixed-width overflow) is NOT_AUTHORIZED under `AUTH-C1-P1` and is
  explicitly excluded per authorization charter; decimal scale budget overflow (`d > maxScale`)
  is verified on exact mathematical integers/naturals.
-/
import DetachedChecker

namespace BrocaOmega.P1.Counterexamples

open BrocaOmega.P1
open BrocaOmega.P1.Checker

/-- Default Gate C0-R1 / P1 decimal precision ceiling (`d ≤ 8`). -/
abbrev defaultMaxScale : Nat := 8

/-! ### 1. Compile-Time Kernel-Verified Counterexample & Positive Control Theorems (`P1-D`) -/

/-- `P1D-01 (PC)`: `1 / 3` rounded to 1 decimal place -> `0.3` (`Accept`). -/
theorem p1d_01_pos_one_third_accept :
    checkOutcomeTag 1 3 { negSign := false, absMantissa := 3, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 3, scale10 := 1 } := rfl

/-- `P1D-01 (CE)`: `1 / 3` rounded to 1 decimal place -> `0.4` (`Reject: roundingMismatch 3 4`). -/
theorem p1d_01_neg_one_third_reject :
    checkOutcomeTag 1 3 { negSign := false, absMantissa := 4, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch 3 4) := rfl

/-- `P1D-02 (PC)`: `100 / 3` (`k=1, N=3` percentage) to 1 decimal place -> `33.3` (`Accept`). -/
theorem p1d_02_pos_pct_one_third_accept :
    checkOutcomeTag 100 3 { negSign := false, absMantissa := 333, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 333, scale10 := 1 } := rfl

/-- `P1D-02 (CE)`: `100 / 3` to 1 decimal place -> `33.4` (`Reject: roundingMismatch 333 334`). -/
theorem p1d_02_neg_pct_one_third_reject :
    checkOutcomeTag 100 3 { negSign := false, absMantissa := 334, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch 333 334) := rfl

/-- `P1D-03 (PC)`: `-1.25` (`-5 / 4`) to 1 decimal place -> `-1.3` (`Accept`, ties away from zero). -/
theorem p1d_03_pos_neg_tie_away_accept :
    checkOutcomeTag (-5) 4 { negSign := true, absMantissa := 13, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := -13, scale10 := 1 } := rfl

/-- `P1D-03 (CE)`: `-1.25` (`-5 / 4`) to 1 decimal place -> `-1.2` (`Reject`, wrong half-toward-+∞ rule!). -/
theorem p1d_03_neg_neg_tie_toward_pos_inf_reject :
    checkOutcomeTag (-5) 4 { negSign := true, absMantissa := 12, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch (-13) (-12)) := rfl

/-- `P1D-04 (CE)`: Zero denominator `1 / 0` -> `Reject: zeroDenominator`. -/
theorem p1d_04_neg_zero_denominator_reject :
    checkOutcomeTag 1 0 { negSign := false, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .error .zeroDenominator := rfl

/-- `P1D-04 (PC)`: Zero numerator `0 / 7` normalizes to `0 / 1` and accepts `+0.0`. -/
theorem p1d_04_pos_zero_numerator_canonical_accept :
    checkOutcomeTag 0 7 { negSign := false, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 0, scale10 := 1 } := rfl

/-- `P1D-05 (CE)`: Negative zero `-0.0` (`0 / 1`, `negSign = true, absMantissa = 0`) -> `Reject: negativeZeroForbidden`. -/
theorem p1d_05_neg_minus_zero_reject :
    checkOutcomeTag 0 1 { negSign := true, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .error .negativeZeroForbidden := rfl

/-- `P1D-05 (PC)`: Same contract `0 / 1` with `+0.0` (`negSign = false, absMantissa = 0`) -> `Accept`. -/
theorem p1d_05_pos_plus_zero_accept :
    checkOutcomeTag 0 1 { negSign := false, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 0, scale10 := 1 } := rfl

/-- `P1D-06 (CE)`: Scale bound exceeded (`d = 9 > maxScale = 8`) -> `Reject: scaleBoundExceeded 9 8`. -/
theorem p1d_06_neg_scale_overflow_reject :
    checkOutcomeTag 1 3 { negSign := false, absMantissa := 333333333, scale10 := 9 } 9 defaultMaxScale =
      .error (.scaleBoundExceeded 9 8) := rfl

/-- `P1D-06 (PC)`: Exact boundary `d = 8 ≤ maxScale = 8` (`≤` admissible!) -> `Accept`. -/
theorem p1d_06_pos_scale_at_boundary_accept :
    checkOutcomeTag 1 3 { negSign := false, absMantissa := 33333333, scale10 := 8 } 8 defaultMaxScale =
      .ok { mantissa := 33333333, scale10 := 8 } := rfl

/-- `P1D-07 (CE)`: Format precision mismatch (`1 / 1` expecting `d = 2` `"1.00"`, given `d = 1` `"1.0"`) -> `Reject`. -/
theorem p1d_07_neg_format_precision_mismatch_reject :
    checkOutcomeTag 1 1 { negSign := false, absMantissa := 10, scale10 := 1 } 2 defaultMaxScale =
      .error (.formatScaleMismatch 2 1) := rfl

/-- `P1D-07 (PC)`: Same contract `1 / 1` expecting `d = 2` with `"1.00"` (`mantissa = 100, scale = 2`) -> `Accept`. -/
theorem p1d_07_pos_format_precision_exact_accept :
    checkOutcomeTag 1 1 { negSign := false, absMantissa := 100, scale10 := 2 } 2 defaultMaxScale =
      .ok { mantissa := 100, scale10 := 2 } := rfl

/-- `P1D-08 (Boundary Trio)`: Exact `+1.25` (`5/4`), just below `+1.2495` (`2499/2000`), and `-0.05` (`-1/20`). -/
theorem p1d_08_halfway_neighborhood_precision :
    -- +1.25 -> +1.3 accepted, +1.2 rejected
    checkOutcomeTag 5 4 { negSign := false, absMantissa := 13, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 13, scale10 := 1 } ∧
    checkOutcomeTag 5 4 { negSign := false, absMantissa := 12, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch 13 12) ∧
    -- +2499/2000 = +1.2495 (< 1.25) -> +1.2 accepted, +1.3 rejected
    checkOutcomeTag 2499 2000 { negSign := false, absMantissa := 12, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 12, scale10 := 1 } ∧
    checkOutcomeTag 2499 2000 { negSign := false, absMantissa := 13, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch 12 13) ∧
    -- -1/20 = -0.05 -> -0.1 accepted, +0.0 rejected
    checkOutcomeTag (-1) 20 { negSign := true, absMantissa := 1, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := -1, scale10 := 1 } ∧
    checkOutcomeTag (-1) 20 { negSign := false, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch (-1) 0) :=
  ⟨rfl, rfl, rfl, rfl, rfl, rfl⟩

/-! ### 2. Structured Test Case Table for Executable Audit Reporting -/

structure P1TestCase where
  testId        : String
  role          : String  -- "PC" or "CE"
  rawNum        : Int
  rawDen        : Nat
  rawToken      : RawDecToken
  expectedScale : Nat
  maxScale      : Nat
  expected      : Except P1ArithRejectReason DecLit

def allP1TestCases : List P1TestCase :=
  [ { testId := "P1D-01-PC", role := "PC", rawNum := 1, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 3, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 3, scale10 := 1 } },
    { testId := "P1D-01-CE", role := "CE", rawNum := 1, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 4, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch 3 4) },
    { testId := "P1D-02-PC", role := "PC", rawNum := 100, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 333, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 333, scale10 := 1 } },
    { testId := "P1D-02-CE", role := "CE", rawNum := 100, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 334, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch 333 334) },
    { testId := "P1D-03-PC", role := "PC", rawNum := -5, rawDen := 4,
      rawToken := { negSign := true, absMantissa := 13, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := -13, scale10 := 1 } },
    { testId := "P1D-03-CE", role := "CE", rawNum := -5, rawDen := 4,
      rawToken := { negSign := true, absMantissa := 12, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch (-13) (-12)) },
    { testId := "P1D-04-CE", role := "CE", rawNum := 1, rawDen := 0,
      rawToken := { negSign := false, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error .zeroDenominator },
    { testId := "P1D-04-PC", role := "PC", rawNum := 0, rawDen := 7,
      rawToken := { negSign := false, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 0, scale10 := 1 } },
    { testId := "P1D-05-CE", role := "CE", rawNum := 0, rawDen := 1,
      rawToken := { negSign := true, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error .negativeZeroForbidden },
    { testId := "P1D-05-PC", role := "PC", rawNum := 0, rawDen := 1,
      rawToken := { negSign := false, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 0, scale10 := 1 } },
    { testId := "P1D-06-CE", role := "CE", rawNum := 1, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 333333333, scale10 := 9 },
      expectedScale := 9, maxScale := 8, expected := .error (.scaleBoundExceeded 9 8) },
    { testId := "P1D-06-PC", role := "PC", rawNum := 1, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 33333333, scale10 := 8 },
      expectedScale := 8, maxScale := 8, expected := .ok { mantissa := 33333333, scale10 := 8 } },
    { testId := "P1D-07-CE", role := "CE", rawNum := 1, rawDen := 1,
      rawToken := { negSign := false, absMantissa := 10, scale10 := 1 },
      expectedScale := 2, maxScale := 8, expected := .error (.formatScaleMismatch 2 1) },
    { testId := "P1D-07-PC", role := "PC", rawNum := 1, rawDen := 1,
      rawToken := { negSign := false, absMantissa := 100, scale10 := 2 },
      expectedScale := 2, maxScale := 8, expected := .ok { mantissa := 100, scale10 := 2 } },
    { testId := "P1D-08A-PC", role := "PC", rawNum := 5, rawDen := 4,
      rawToken := { negSign := false, absMantissa := 13, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 13, scale10 := 1 } },
    { testId := "P1D-08A-CE", role := "CE", rawNum := 5, rawDen := 4,
      rawToken := { negSign := false, absMantissa := 12, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch 13 12) },
    { testId := "P1D-08B-PC", role := "PC", rawNum := 2499, rawDen := 2000,
      rawToken := { negSign := false, absMantissa := 12, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 12, scale10 := 1 } },
    { testId := "P1D-08B-CE", role := "CE", rawNum := 2499, rawDen := 2000,
      rawToken := { negSign := false, absMantissa := 13, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch 12 13) },
    { testId := "P1D-08C-PC", role := "PC", rawNum := -1, rawDen := 20,
      rawToken := { negSign := true, absMantissa := 1, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := -1, scale10 := 1 } },
    { testId := "P1D-08C-CE", role := "CE", rawNum := -1, rawDen := 20,
      rawToken := { negSign := false, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch (-1) 0) }
  ]

def exceptEq (a b : Except P1ArithRejectReason DecLit) : Bool :=
  match a, b with
  | .ok x, .ok y => decide (x = y)
  | .error e1, .error e2 => decide (e1 = e2)
  | _, _ => false

def runSingleCase (tc : P1TestCase) : Bool :=
  let actual := checkOutcomeTag tc.rawNum tc.rawDen tc.rawToken tc.expectedScale tc.maxScale
  exceptEq actual tc.expected

theorem allP1TestCases_pass : (allP1TestCases.all runSingleCase) = true := rfl

end BrocaOmega.P1.Counterexamples
```

### 4.7 `04_proof_obligations/ProofObligations.lean` & `PO_C1_04a_Arithmetic.lean`
```lean
-- 04_proof_obligations/ProofObligations.lean
import ProofObligations.PO_C1_04a_Arithmetic
```
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P1
  ProofObligations/PO_C1_04a_Arithmetic.lean
  Canonical Theorem Index for `AUTH-C1-P1` (`PO-C1-04` Arithmetic Sub-Obligation ONLY).

  SCOPE BOUNDARY DECLARATION:
  - PROVED IN THIS MODULE (`PO-C1-04a` Exact Unbounded Rational & Rounding Foundation):
      * `P1_ExactRat_CanonicalZero`: `num = 0 → den = 1 ∧ r = ExactRat.zero`
      * `P1_ExactRat_UniqueCanonical`: `r₁ = r₂ ↔ r₁.num * r₂.den = r₂.num * r₁.den`
      * `P1_DecLit_NegZeroRejected`: `-0.0` unconditionally rejected at ingress
      * `P1_DecLit_ValVsFmtSeparation`: `valEq` is an equivalence relation strictly coarser than `fmtEq`
      * `P1_ValidRoundAwz_Iff_EuclideanQuotient`: `ValidRoundAwz p q m d ↔ m = roundHalfAwayFromZero p q d` (`q > 0`)
      * `P1_ValidRoundAwz_Iff_NearestIntMetric`: `ValidRoundAwz p q m d ↔ IsNearestIntHalfAway p q d m` (`q > 0`)
      * `P1_ValidRoundAwz_Deterministic`: uniqueness of `m`
      * `P1_ValidRoundAwz_SignSymmetry`: `R(-p, q, d) = -R(p, q, d)` and `ValidRoundAwz (-p) q (-m) d ↔ ValidRoundAwz p q m d`
      * `P1_HalfwayBoundarySafety`: exact `+0.5` and `-0.5` break strictly away from zero
      * `P1_DetachedGate_SoundAndComplete`: `verifyRoundingWitness_sound` and `verifyRoundingWitness_complete`
  - EXPLICITLY HELD / NOT AUTHORIZED:
      * `P1-C` (`Int128` / `UInt128` fixed-width arithmetic optimization): NOT_AUTHORIZED
      * `PO-C1-04b` (Clinical/statistical commitment & evidence witness verification — P4): HELD
      * `PO-C1-01, 02, 03, 05, 06` and `Master Soundness` (P2, P3, P5): HELD
      * Scientific/clinical validity of external datasets: OUT_OF_SCOPE
-/
import FormalSpec
import DetachedChecker
import Counterexamples

namespace BrocaOmega.P1.Obligations

open BrocaOmega.P1
open BrocaOmega.P1.Checker

/-- 1. Canonical Zero & Coprime Uniqueness of `ExactRat`. -/
theorem P1_ExactRat_CanonicalZero (r : ExactRat) (h : r.num = 0) :
    r.den = 1 ∧ r = ExactRat.zero :=
  ⟨ExactRat.den_eq_one_of_num_eq_zero r h, ExactRat.eq_zero_of_num_eq_zero r h⟩

theorem P1_ExactRat_ExtensionalUniqueness (r₁ r₂ : ExactRat) :
    r₁ = r₂ ↔ ExactRat.RatValEq r₁.num r₁.den r₂.num r₂.den :=
  ExactRat.ext_iff_ratValEq r₁ r₂

/-- 2. Core Equivalence (`P1-B` Primary Target): `ValidRoundAwz ↔ roundHalfAwayFromZero`. -/
theorem P1_ValidRoundAwz_Iff_RoundHalfAway {p : Int} {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz p q m d ↔ m = roundHalfAwayFromZero p q d :=
  validRoundAwz_iff_eq_roundHalfAway hq m d

/-- 3. Non-Circular Metric Equivalence: `ValidRoundAwz ↔ IsNearestIntHalfAway` (∀ k ∈ ℤ). -/
theorem P1_ValidRoundAwz_Iff_NearestIntMetric {p : Int} {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz p q m d ↔ IsNearestIntHalfAway p q d m :=
  validRoundAwz_iff_isNearestIntHalfAway hq m d

/-- 4. Determinism, Sign Symmetry, and Zero Canonicalization. -/
theorem P1_ValidRoundAwz_Unique {p : Int} {q : Nat} {m₁ m₂ : Int} {d : Nat}
    (h₁ : ValidRoundAwz p q m₁ d) (h₂ : ValidRoundAwz p q m₂ d) : m₁ = m₂ :=
  validRoundAwz_unique h₁ h₂

theorem P1_RoundHalfAway_SignSymmetry (p : Int) (q d : Nat) :
    roundHalfAwayFromZero (-p) q d = - roundHalfAwayFromZero p q d ∧
    ∀ m : Int, (ValidRoundAwz (-p) q (-m) d ↔ ValidRoundAwz p q m d) :=
  ⟨roundHalfAwayFromZero_neg p q d, fun m => validRoundAwz_neg_iff p q m d⟩

theorem P1_RoundHalfAway_ZeroCanonical {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    roundHalfAwayFromZero 0 q d = 0 ∧ (ValidRoundAwz 0 q m d ↔ m = 0) :=
  ⟨roundHalfAwayFromZero_zero q d, validRoundAwz_zero_iff hq m d⟩

/-- 5. Exact Halfway (`±0.5`) Tie-Breaking Away From Zero. -/
theorem P1_ExactHalfway_TiesAwayFromZero {p : Int} {q : Nat} {k : Int} {d : Nat}
    (hq : 0 < q) (hk : 0 ≤ k) :
    (2 * pow10Int d * p = (q : Int) * (2 * k + 1) →
      ValidRoundAwz p q (k + 1) d ∧ ¬ ValidRoundAwz p q k d) ∧
    (2 * pow10Int d * (-p) = (q : Int) * (2 * k + 1) →
      ValidRoundAwz p q (-(k + 1)) d ∧ ¬ ValidRoundAwz p q (-k) d) :=
  ⟨exact_pos_halfway_boundary hq hk, exact_neg_halfway_boundary hq hk⟩

/-- 6. End-to-End Detached P1 Gate Soundness & Relative Completeness. -/
theorem P1_DetachedGate_Sound
    {rawNum : Int} {rawDen : Nat} {rawSurface : RawDecToken}
    {expectedScale maxScale : Nat}
    {cert : CertifiedRoundingWitness rawNum rawDen rawSurface expectedScale maxScale}
    (hok : verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale = .ok cert) :
    0 < rawDen ∧
    ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0) ∧
    rawSurface.scale10 = expectedScale ∧
    expectedScale ≤ maxScale ∧
    ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale ∧
    rawSurface.toSignedInt = roundHalfAwayFromZero rawNum rawDen expectedScale ∧
    IsNearestIntHalfAway rawNum rawDen expectedScale rawSurface.toSignedInt :=
  verifyRoundingWitness_sound hok

theorem P1_DetachedGate_Complete
    {rawNum : Int} {rawDen : Nat} {rawSurface : RawDecToken}
    {expectedScale maxScale : Nat}
    (hden : 0 < rawDen)
    (hno_neg0 : ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0))
    (hsc : rawSurface.scale10 = expectedScale)
    (hle : expectedScale ≤ maxScale)
    (hraw : ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale) :
    ∃ cert, verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale = .ok cert :=
  verifyRoundingWitness_complete hden hno_neg0 hsc hle hraw

end BrocaOmega.P1.Obligations
```

### 4.8 `05_independent_tribunal/TribunalAudit.lean`
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P1
  05_independent_tribunal/TribunalAudit.lean
  Compile-time `#print axioms` audit + executable `P1-D` adversarial / positive-control runner.
-/
import ProofObligations

open BrocaOmega.P1
open BrocaOmega.P1.Checker
open BrocaOmega.P1.Counterexamples
open BrocaOmega.P1.Obligations

-- Compile-time Axiom Footprint Audit (logged by Lean compiler during build):
#print axioms P1_ExactRat_CanonicalZero
#print axioms P1_ExactRat_ExtensionalUniqueness
#print axioms P1_ValidRoundAwz_Iff_RoundHalfAway
#print axioms P1_ValidRoundAwz_Iff_NearestIntMetric
#print axioms P1_ValidRoundAwz_Unique
#print axioms P1_RoundHalfAway_SignSymmetry
#print axioms P1_RoundHalfAway_ZeroCanonical
#print axioms P1_ExactHalfway_TiesAwayFromZero
#print axioms P1_DetachedGate_Sound
#print axioms P1_DetachedGate_Complete
#print axioms allP1TestCases_pass

def main : IO Unit := do
  IO.println "=== BROCA-NATIVE OMEGA : GATE C1-P1 TRIBUNAL AUDIT RUNNER ==="
  IO.println s!"Total P1-D Paired Cases: {allP1TestCases.length}"
  let mut passedCount : Nat := 0
  for tc in allP1TestCases do
    let ok := runSingleCase tc
    if ok then
      passedCount := passedCount + 1
    let actual := checkOutcomeTag tc.rawNum tc.rawDen tc.rawToken tc.expectedScale tc.maxScale
    IO.println s!"[{if ok then "PASS" else "FAIL"}] {tc.testId} ({tc.role}) | input=({tc.rawNum}/{tc.rawDen}, scale={tc.rawToken.scale10}, neg={tc.rawToken.negSign}, absM={tc.rawToken.absMantissa}) -> {repr actual}"
  IO.println s!"Summary: {passedCount}/{allP1TestCases.length} cases matched exact expected outcome."
  if passedCount == allP1TestCases.length then
    IO.println "P1_SUITE_EXECUTION_STATUS: ALL_20_CASES_MATCHED_EXACT_SPEC"
  else
    throw (IO.userError "P1 suite mismatch detected")
```

---

## 5. Verbatim Execution Logs & Receipt JSON

### 5.1 Verbatim `lake build` & `#print axioms` Output (`exit code: 0`)
```text
info: 05_independent_tribunal/TribunalAudit.lean:14:0: 'BrocaOmega.P1.Obligations.P1_ExactRat_CanonicalZero' depends on axioms: [Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:15:0: 'BrocaOmega.P1.Obligations.P1_ExactRat_ExtensionalUniqueness' depends on axioms: [propext, Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:16:0: 'BrocaOmega.P1.Obligations.P1_ValidRoundAwz_Iff_RoundHalfAway' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:17:0: 'BrocaOmega.P1.Obligations.P1_ValidRoundAwz_Iff_NearestIntMetric' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:18:0: 'BrocaOmega.P1.Obligations.P1_ValidRoundAwz_Unique' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:19:0: 'BrocaOmega.P1.Obligations.P1_RoundHalfAway_SignSymmetry' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:20:0: 'BrocaOmega.P1.Obligations.P1_RoundHalfAway_ZeroCanonical' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:21:0: 'BrocaOmega.P1.Obligations.P1_ExactHalfway_TiesAwayFromZero' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:22:0: 'BrocaOmega.P1.Obligations.P1_DetachedGate_Sound' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:23:0: 'BrocaOmega.P1.Obligations.P1_DetachedGate_Complete' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/TribunalAudit.lean:24:0: 'BrocaOmega.P1.Counterexamples.allP1TestCases_pass' depends on axioms: [propext, Classical.choice, Quot.sound]
✔ [28/28] Built p1_tribunal_runner:exe (700ms)
Build completed successfully (28 jobs).
```

### 5.2 Verbatim `leanchecker --fresh` Command & Output (Separate Formal Replay Evidence)
```text
Command: lake env C:\Users\당뇨병지회 1\.elan\bin\leanchecker.exe --fresh TribunalAudit
Output:
ℹ [12/24] Replayed TribunalAudit
leanchecker exit code: 0
```

### 5.3 Verbatim `lake exe p1_tribunal_runner` Output (Separate Empirical Regression Evidence)
```text
=== BROCA-NATIVE OMEGA : GATE C1-P1 TRIBUNAL AUDIT RUNNER ===
Total P1-D Paired Cases: 20
[PASS] P1D-01-PC (PC) | input=(1/3, scale=1, neg=false, absM=3) -> Except.ok { mantissa := 3, scale10 := 1 }
[PASS] P1D-01-CE (CE) | input=(1/3, scale=1, neg=false, absM=4) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.roundingMismatch 3 4)
[PASS] P1D-02-PC (PC) | input=(100/3, scale=1, neg=false, absM=333) -> Except.ok { mantissa := 333, scale10 := 1 }
[PASS] P1D-02-CE (CE) | input=(100/3, scale=1, neg=false, absM=334) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.roundingMismatch 333 334)
[PASS] P1D-03-PC (PC) | input=(-5/4, scale=1, neg=true, absM=13) -> Except.ok { mantissa := -13, scale10 := 1 }
[PASS] P1D-03-CE (CE) | input=(-5/4, scale=1, neg=true, absM=12) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.roundingMismatch (-13) (-12))
[PASS] P1D-04-CE (CE) | input=(1/0, scale=1, neg=false, absM=0) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.zeroDenominator)
[PASS] P1D-04-PC (PC) | input=(0/7, scale=1, neg=false, absM=0) -> Except.ok { mantissa := 0, scale10 := 1 }
[PASS] P1D-05-CE (CE) | input=(0/1, scale=1, neg=true, absM=0) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.negativeZeroForbidden)
[PASS] P1D-05-PC (PC) | input=(0/1, scale=1, neg=false, absM=0) -> Except.ok { mantissa := 0, scale10 := 1 }
[PASS] P1D-06-CE (CE) | input=(1/3, scale=9, neg=false, absM=333333333) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.scaleBoundExceeded 9 8)
[PASS] P1D-06-PC (PC) | input=(1/3, scale=8, neg=false, absM=33333333) -> Except.ok { mantissa := 33333333, scale10 := 8 }
[PASS] P1D-07-CE (CE) | input=(1/1, scale=1, neg=false, absM=10) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.formatScaleMismatch 2 1)
[PASS] P1D-07-PC (PC) | input=(1/1, scale=2, neg=false, absM=100) -> Except.ok { mantissa := 100, scale10 := 2 }
[PASS] P1D-08A-PC (PC) | input=(5/4, scale=1, neg=false, absM=13) -> Except.ok { mantissa := 13, scale10 := 1 }
[PASS] P1D-08A-CE (CE) | input=(5/4, scale=1, neg=false, absM=12) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.roundingMismatch 13 12)
[PASS] P1D-08B-PC (PC) | input=(2499/2000, scale=1, neg=false, absM=12) -> Except.ok { mantissa := 12, scale10 := 1 }
[PASS] P1D-08B-CE (CE) | input=(2499/2000, scale=1, neg=false, absM=13) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.roundingMismatch 12 13)
[PASS] P1D-08C-PC (PC) | input=(-1/20, scale=1, neg=true, absM=1) -> Except.ok { mantissa := -1, scale10 := 1 }
[PASS] P1D-08C-CE (CE) | input=(-1/20, scale=1, neg=false, absM=0) -> Except.error (BrocaOmega.P1.P1ArithRejectReason.roundingMismatch (-1) 0)
Summary: 20/20 cases matched exact expected outcome.
P1_SUITE_EXECUTION_STATUS: ALL_20_CASES_MATCHED_EXACT_SPEC
```

### 5.4 Verbatim `06_receipts/auth_c1_p1_verification_receipt.json` (`SHA-256: EC53292AD346D0FD17393C00F0DE5AD0832CEB48B09CE2D298A97B8101C5CDAB`)
```json
{
  "schema": "BROCA_NATIVE_OMEGA_AUTH_C1_P1_RECEIPT_V1",
  "recorded_at": "2026-11-22T15:46:15+09:00",
  "authorization_gate": "AUTH-C1-P1",
  "isolated_root": "C:\\antigravity work\\BROCA_NATIVE_OMEGA_GATE_C1",
  "toolchain": {
    "lean_version": "Lean (version 4.33.1, x86_64-w64-windows-gnu, commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6, Release)",
    "lake_version": "Lake version 5.0.0-src+819816b (Lean version 4.33.1)",
    "external_lean_dependencies": []
  },
  "verification_commands_executed": [
    {
      "command": "lake build",
      "exit_code": 0,
      "jobs_succeeded": "28/28",
      "warnings": 0,
      "errors": 0
    },
    {
      "command": "lake exe p1_tribunal_runner",
      "exit_code": 0,
      "paired_cases_passed": "20/20",
      "status_line": "P1_SUITE_EXECUTION_STATUS: ALL_20_CASES_MATCHED_EXACT_SPEC"
    },
    {
      "command": "lake env leanchecker --fresh TribunalAudit",
      "exit_code": 0,
      "replayed_modules": "24/24"
    }
  ],
  "axiom_audit": {
    "sorryAx_present": false,
    "ofReduceBool_native_decide_present": false,
    "custom_axioms_present": false,
    "unsafe_declarations_present": false,
    "standard_lean_foundational_axioms_only": [
      "propext",
      "Classical.choice",
      "Quot.sound"
    ],
    "per_theorem_axioms": {
      "P1_ExactRat_CanonicalZero": ["Quot.sound"],
      "P1_ExactRat_ExtensionalUniqueness": ["propext", "Quot.sound"],
      "P1_ValidRoundAwz_Iff_RoundHalfAway": ["propext", "Classical.choice", "Quot.sound"],
      "P1_ValidRoundAwz_Iff_NearestIntMetric": ["propext", "Classical.choice", "Quot.sound"],
      "P1_ValidRoundAwz_Unique": ["propext", "Classical.choice", "Quot.sound"],
      "P1_RoundHalfAway_SignSymmetry": ["propext", "Classical.choice", "Quot.sound"],
      "P1_RoundHalfAway_ZeroCanonical": ["propext", "Classical.choice", "Quot.sound"],
      "P1_ExactHalfway_TiesAwayFromZero": ["propext", "Classical.choice", "Quot.sound"],
      "P1_DetachedGate_Sound": ["propext", "Classical.choice", "Quot.sound"],
      "P1_DetachedGate_Complete": ["propext", "Classical.choice", "Quot.sound"],
      "allP1TestCases_pass": ["propext", "Classical.choice", "Quot.sound"]
    }
  },
  "source_artifact_sha256": {
    "lean-toolchain": "3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71",
    "lakefile.toml": "27701C3DDDD5B3C3D1F62EADA3EE272A0707D9345A1D44CB0ACA68AED0CDFE35",
    "01_formal_spec/FormalSpec.lean": "66CD00F867CAEA53E360C6AD7FF03D2C326C4EC064F02D79AF58B6C1137F1643",
    "01_formal_spec/FormalSpec/Arithmetic/ExactRat.lean": "4503AB0C7AECDE33D9E83DC3B05DF81D03EF11FE66D5FF0A927B43BFCF5732A8",
    "01_formal_spec/FormalSpec/Arithmetic/DecLit.lean": "2D27E68E29AA2CDF21AF62F1A12C881C414E7C011114D5B021B68F4813ACBA0C",
    "01_formal_spec/FormalSpec/Arithmetic/Rounding.lean": "A49E04C420448A533A70F28FD516D7ECC7220C750311E1EAE4EFEA066752E6C5",
    "02_detached_checker/DetachedChecker.lean": "416C65E96C40984BDC052CAADF7BD807707D95C8D4F2365231012ECF91C1239B",
    "02_detached_checker/DetachedChecker/P1ArithmeticChecker.lean": "793AB726BB95A50601CB97056B7A82765E5BDEE12498A7C6CA1CA42CAE891EB7",
    "03_counterexamples/Counterexamples.lean": "DBEF93CDC7AF81EBB6370CB9490A92F5758D45133DC809665311595C98266738",
    "03_counterexamples/Counterexamples/P1Suite.lean": "CFCDC4A13A1DEAB8FF32F8856E67A1C9DF8C1DD1E6644288CCAD66E32DE4DEA3",
    "04_proof_obligations/ProofObligations.lean": "01A30FC36B0A3DE396661E4513C59FB8A492F881256DBA252F63C0A4B39B596C",
    "04_proof_obligations/ProofObligations/PO_C1_04a_Arithmetic.lean": "045719F85757D62CC97620CBF76DB73ED38B85C58D39932AA6E9E4F1E7C75023",
    "05_independent_tribunal/TribunalAudit.lean": "2BA612DE16670CBF7540DA4B47E35D2917BD0AB7C1D067841DCF71BFBFC779A4"
  },
  "scope_and_held_locks": {
    "po_c1_04a_arithmetic_mechanized_in_lean4": true,
    "p1_c_fixed_width_int128_implemented": false,
    "po_c1_04b_clinical_evidence_witness_held": true,
    "po_c1_01_parser_completeness_held": true,
    "po_c1_02_derivation_replay_held": true,
    "po_c1_03_normalization_soundness_held": true,
    "po_c1_05_serialization_snapshot_held": true,
    "po_c1_06_relative_completeness_held": true,
    "master_soundness_held": true,
    "scientific_or_clinical_validity_certified": false,
    "ancestors_modified": false
  }
}
```
