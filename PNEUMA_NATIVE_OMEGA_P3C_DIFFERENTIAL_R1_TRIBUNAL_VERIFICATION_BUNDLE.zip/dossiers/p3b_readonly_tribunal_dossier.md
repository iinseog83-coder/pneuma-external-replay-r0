# BROCA-NATIVE Ω — AUTH-C1-P3-B Read-Only Independent Tribunal Verification Bundle (`P3B_BoundedParser`)

> [!IMPORTANT]
> **Read-Only Audit Submission (`AUTH-C1-P3-B`: `PO-C1-01` Bounded Exhaustive Parser + `BridgeSound` / `ProjectionFaithful` + `F-P3A-01` Full Grammar Correspondence)**
> All Lean `4.33.1` source files (`11` modules), build configurations (`lean-toolchain`, `lakefile.toml`), Python `3.11` clean-room differential oracle (`differential_oracle_p3b.py`), execution logs, and receipt JSON contents (`auth_c1_p3b_verification_receipt.json`) below are **100% verbatim, unmodified copies** of the files on disk inside `C:\antigravity work\BROCA_NATIVE_OMEGA_GATE_C1\P3B_BoundedParser\` and `06_receipts\`. All prior baselines (`Pneuma` `0` files, `Broca`/`shared` `6/6`, `DIR` receipt, `P1` `13/13` + receipt, `P2` `14/14` + receipt, `P3-A` `14/14` + receipt) remain bit-for-bit untouched.

---

## 1. Gate 0 ~ Gate F Audit Index (Exact Source & Theorem Mapping)

| Gate | Mandate Requirement | Verbatim Implementation & Formal Evidence |
| :--- | :--- | :--- |
| **Gate 0** | Prior baseline immutability & isolated workspace | `Pneuma` (`0` files), `Broca`/`shared` (`6/6`), `DIR` receipt, `P1` (`13/13` + receipt), `P2` (`14/14` + receipt), `P3-A` (`14/14` + receipt) verified bit-for-bit before & after `P3-B` build. |
| **Gate A** | Algorithm-independent `ValidParse_GFrozen` + **`F-P3A-01`** full interleaved correspondence on actual frozen `P2` & `P3-A` | `DeclarativeParseSpec.lean` (`34` productions = `27` generator `G-01`~`G-16` + `7` parser-only traps `T1`~`T5` across `21` canonical rule IDs; `ConcreteParseTree` carrying explicit `readingAlt` `1..altCount`; `frozenProdSig_child_level_lt`; `ValidParse_GFrozen`) + `FullGrammarCorrespondence.lean` (`f_p3a_01_p2_ruleSignature_matches_p3b_interleaved`, `f_p3a_01_p3b_matches_p3a_independentFrozenBNF`, `f_p3a_01_universal_sidecond_equivalence`, `f_p3a_01_universal_intrinsicObls_equivalence`, `fromP2Rule_mkSum_eq_mapP2Summary`). |
| **Gate B** | Bounded exhaustive parser `parseAllBounded` with formal `ResourceBudget` & strict 3-way result | `BoundedParser.lean`: `ResourceBudget` (`maxBytes`, `maxSteps`, `maxForestNodes`, `maxReadings`), `BoundedParseResult` (`.enumerated T` \| `.outOfDomain d` \| `.resourceOverflow b`), deterministic duplicate-free `dedupTrees` (`NoDupTrees`) preserving `[alt=1, alt=2]` on `T1`, `T2`, `T4`. |
| **Gate C** | **`PO-C1-01`** Formal Soundness, Bounded Exhaustive Completeness, Non-Vacuity & `ResourceOverflow` Fail-Closed | `BoundedParser.lean` + `P3BSuite.lean`: `parseAllBounded_terminates`, `parseAllBounded_outOfDomain_sound` (`¬ StrictAsciiDomainSupported` only — never conflated with `¬ValidParse`), `parseAllBounded_enumerated_sound_and_complete` (`∀ τ, τ ∈ T ↔ ValidParse_GFrozen ... τ`), `parseAllBounded_empty_sound`, `resourceOverflow_failClosed`, `nonvacuous_G01_enumerated` (`\|T\| = 1`), `nonvacuous_T2_two_distinct_readings` (`\|T\| = 2`, `t1 ≠ t2`, `alt=1` & `alt=2`). |
| **Gate D** | **`BridgeSound`** + **`ProjectionFaithful`** directly importing actual frozen `P3-A` & `P2` | `LexicalReplayBridge.lean`: directly imports `BrocaOmega.P3A.CertifiedLexicalSlot`, `BrocaOmega.P3A.admitLexicalSlot`, `BrocaOmega.P2.UntrustedDerivCert`, `BrocaOmega.P2.replayDerivation`; restricts `lowerToP2Cert` to `LexicallyCertifiedDerivTree`; defines & proves `ProjectionFaithful` (`lowerToP2Cert_projectionFaithful`, `checkProjectionFaithfulBool_iff`), `BridgeSound`, `BridgeSound_mem_enumerated_forest`, and `verifyBridgedDerivation_sound`. |
| **Gate E** | `28` kernel-proved `(PC, CE)` vectors + `250` external batch 1:1 `Lean ↔ Python` parity + `#print axioms` + `leanchecker --fresh` | `P3BSuite.lean` (`allP3BCases_verified`: `28/28` via pure `decide`, `0` `native_decide`) + `differential_oracle_p3b.py` (`28/28` fixed + `250/250` external TSV batch `Result_Lean(x) == Result_Python(x)`, `0` mismatches) + `lake build` (`54/54`, `0` warnings) + `#print axioms` (`20/20` theorems clean) + `leanchecker --fresh P3BTribunalAudit` (`exit code 0` in `395.38s`). |
| **Gate F** | Explicit preservation of `HELD` & `NOT_AUTHORIZED` boundaries + `FROZEN_AND_STANDBY` | `F-P3A-01` & `F-P3A-02` marked `EVIDENCE_SUBMITTED_PENDING_TRIBUNAL_HELD` pending Tribunal disposition; `P1/P2/P3A/P3B` external independent kernel replay `HELD`; `R0` unspecified items (`G-01` right-censored surface, production clinical ontology entries) `HELD_UNSPECIFIED_IN_R0`; `P1-C`, `P3-C`, `P4`, `P5`, `Pneuma` `NOT_AUTHORIZED`. |

---

## 2. Formal 3-State Parser Contract & Bridge Tamper Matrix

| Scenario / Input Class | Lean Verdict | Python Verdict | Proved Semantic Guarantee |
| :--- | :---: | :---: | :--- |
| Valid `G-01` ~ `G-16` generator sentence within budget | `.enumerated [τ]` | `ENUM:1:Gxx:alt1:gen` | `NoDupTrees [τ]` ∧ `(τ' ∈ [τ] ↔ ValidParse_GFrozen ... τ')` |
| Mandatory `T2` (`"did not confirm that"`, `Y_T08`) within budget | `.enumerated [τ₁, τ₂]` | `ENUM:2:T2:alt1:trap,T2:alt2:trap` | `\|T\| = 2` ∧ `τ₁ ≠ τ₂` ∧ `alt=1` & `alt=2` preserved without extra rule IDs |
| `T2` (`Y_T08`) under tight `budget.maxReadings = 1` | `.resourceOverflow (.maxReadingsExceeded 2 1)` | `OVF:maxReadingsExceeded:2:1` | Fail-closed (`admitBoundedParse = .error`), NEVER truncates `[τ₁, τ₂]` to `[τ₁]` |
| Valid ASCII input exceeding `maxBytes` / `maxSteps` / `maxForestNodes` | `.resourceOverflow (...)` | `OVF:...` | Fail-closed, NEVER conflated with `.outOfDomain` or `.enumerated []` |
| In-domain ASCII input with grammar, `P3-A` numeric (`1..25`), or side-condition error | `.enumerated []` | `ENUM:0:` | `StrictAsciiDomainSupported rawBytes ∧ ∀ τ, ¬ ValidParse_GFrozen ... τ` |
| Empty input `[]` or non-7-bit-ASCII byte (`0x00..0x1F`, `0x7F..0xFF`) | `.outOfDomain d` | `OOD:...` | `¬ StrictAsciiDomainSupported rawBytes` (makes no unproved grammar claim outside domain) |
| Bridge bypass attempt: `1..25` multi-dot numeric in `UntrustedDerivCert` | `REJECT` (`slotLexicalRejected 3 multipleDecimalPoints`) | *(matched)* | Blocked at `BrocaOmega.P3A.admitLexicalSlot` before `lowerToP2Cert` |
| Bridge bypass attempt: spoofed `entityId` (`"ev_aki"` on `"stroke"`) | `REJECT` (`slotLexicalRejected 3 entityCatalogMismatch`) | *(matched)* | Blocked by `P3-A` `ClosedEntityCatalog` binding before `P2` replay |
| Bridge tamper attempt: span/hierarchy/obligation drift between `x` and `π` | `REJECT` (`checkProjectionFaithfulBool = false`) | *(matched)* | Blocked by `ProjectionFaithful` structural & span-sequence check |

---

## 3. SHA-256 Integrity Ledger (Prior Gates, `P3-B` Sources, `.olean` Artifacts & Receipt)

### 3.1 Prior Gate & Ancestor Immutability (`Gate 0` Verified Pre & Post Build)
- `C:\antigravity work\Pneuma`: `0` files (`UNCHANGED`)
- `00_frozen_reference/manifest_only/frozen_reference_manifest.json`: `2FA5C7EC0423A6D404EBBB681E2393B9041C7E02634EB71D4505405162D3C076` (`6/6` `Broca`/`shared` anchors verified)
- `06_receipts/auth_c1_dir_environment_receipt.json`: `036E6543AD43365F9B914259840E0508F920FE24F56AAD45824639B7F480620E` (`UNCHANGED`)
- `06_receipts/auth_c1_p1_verification_receipt.json`: `EC53292AD346D0FD17393C00F0DE5AD0832CEB48B09CE2D298A97B8101C5CDAB` (`13/13` `P1` sources verified)
- `06_receipts/auth_c1_p2_verification_receipt.json`: `5D9BFCD3B3F029AF1B338CB47AC0445FB8707437898B9777A6C771BD40029F3E` (`14/14` `P2` sources verified)
- `06_receipts/auth_c1_p3a_verification_receipt.json`: `46A80A14CEEF917E133B375B49D4C2CD60FCB91300246920D7A819E556BEC79F` (`14/14` `P3-A` sources verified)
- `06_receipts/auth_c1_p3b_verification_receipt.json`: `212FE405EA722F72E11CB65493072F688AC86FFB7E6E47D49F6FAD5CDC58E595`

### 3.2 `P3-B` Source ↔ `.olean` / `.exe` SHA-256 Table (`14/14` Source & Config Blocks)

| Relative Path (`P3B_BoundedParser/`) | Source SHA-256 | Compiled `.olean` / `.exe` SHA-256 |
| :--- | :--- | :--- |
| `lean-toolchain` | `3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71` | *(config / oracle script)* |
| `lakefile.toml` | `5566CAF6C914C2C57B772DAAEBE24CDF9A80F7357FD9A70B78E986EC81ED5A71` | *(config / oracle script)* |
| `01_formal_spec/P3BFormalSpec.lean` | `53612302FE6918F9B399E74D6A4CFFEF5F19BC7561C46A3082E7925E9A47A307` | `17FA2EF13C33A9F8E27F8F29242ACA74BDB7B600D20CBF2F4DEBAAFF25EEE335` |
| `01_formal_spec/P3BFormalSpec/DeclarativeParseSpec.lean` | `078605A7D221C0F6027DE0071D94A97EF616B40DD98E617DA893371C771C645D` | `124E26B1399449F696A3BE3DFC41C3CBF1FD5F04F0A1473B5D8ACA71BF008038` |
| `01_formal_spec/P3BFormalSpec/FullGrammarCorrespondence.lean` | `AAAF8848771BF2A1E2D28D361BA51F911B81A70E98A14DBA53A6E5707C6B7557` | `CF6C77F4A1A0A74ACB184CFA7223D94322D7BAB3067B907FF505F2A551021116` |
| `02_detached_checker/P3BDetachedChecker.lean` | `18434566A21C37331F2375995E5B82EA4DD4D47AD4F7FC7D1F09A9E7A13218CE` | `B07127D2769704D21D8C9C98D746A3EE653C7B20D12F6C44B4625D833348FBAB` |
| `02_detached_checker/P3BDetachedChecker/BoundedParser.lean` | `1E5668016B5B74CA27A036D833DC106C9A4AF720CE978138683139591051D391` | `71702629DA8F4CDEA4DEE42C01FE4F27C54590A88DF4E1E2DBCE64B1F0F51C95` |
| `02_detached_checker/P3BDetachedChecker/LexicalReplayBridge.lean` | `4737425A39DA8570B5B7779D944A6B8760521116855BA65ED4AA52B43CA0E79C` | `9A8D6C88CEE0C9E70646D646DD753B58AED255668E9B9E25FA25BDF04B06E885` |
| `03_counterexamples/P3BCounterexamples.lean` | `575E0CE7C3DA45B03F380EFA708D58DEED51B06F72922CC1E1AB989CE717F592` | `ADA3FCF8875F73C6889B820F96233F937D90522B461ED94513B396889C451053` |
| `03_counterexamples/P3BCounterexamples/P3BSuite.lean` | `28DBABEEC365916CC8973A85D89EAB516F660C6C66DFAB0139F23F1BF207B3F0` | `FE7E993E4767CA06ED1156957FB0B2AC4997400AFD59B19E97821870439B5E6D` |
| `04_proof_obligations/P3BProofObligations.lean` | `CFC70A41A3D0DE67A539C36875A0811E50C967041E08C080F48F50ED0309CEB1` | `11E9F985E9D518A3D0556CAD212FFCEF744FAE6F12EC6001522646794FE62966` |
| `04_proof_obligations/P3BProofObligations/PO_C1_01_And_Bridge.lean` | `D0A39693AE96EB34234C8459D7873508688064C305A2C0B789E199CC8F040F11` | `56F82A640D9E3B595491BF767D2A6BA6FCC7F33059DEA2234A957900776B0723` |
| `05_independent_tribunal/P3BTribunalAudit.lean` | `E0F1D27419BE36D02375B26155BA5AD0F9D2385FF2AC1B9F4A444CDF28A8496A` | `D35DBBB8EF62651D4094A262C8004016CF1D38C3D70625208F49879F36DE4244` / exe `3D99D849C7B3E120608EECA1E1F988C2E6D7E73BA101F7B2D4DB4B905B003FAB` |
| `05_independent_tribunal/differential_oracle_p3b.py` | `EF3E734346B3D6F673173777F23BFF4EFDB3D2B0730E8E5A09E34B38296F2CED` | *(config / oracle script)* |

---

## 4. Verbatim Build, `#print axioms`, `leanchecker --fresh`, Runner, and Differential Oracle Logs

### 4.1 `lake build` & `#print axioms` Output (`54/54` Jobs, `0` Warnings, `0` Errors)
```text
✔ [42/54] Built P3BCounterexamples.P3BSuite (372s)
✔ [43/54] Built P3BCounterexamples.P3BSuite:c.o (810ms)
✔ [44/54] Built P3BCounterexamples (861ms)
✔ [46/54] Built P3BProofObligations.PO_C1_01_And_Bridge (1.0s)
✔ [47/54] Built P3BCounterexamples:c.o (949ms)
✔ [48/54] Built P3BProofObligations (904ms)
✔ [50/54] Built P3BProofObligations.PO_C1_01_And_Bridge:c.o (852ms)
✔ [51/54] Built P3BProofObligations:c.o (1.1s)
ℹ [52/54] Built P3BTribunalAudit (1.1s)
info: 05_independent_tribunal/P3BTribunalAudit.lean:23:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_InterleavedGrammarEq' depends on axioms: [propext]
info: 05_independent_tribunal/P3BTribunalAudit.lean:24:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_MatchesP3AFrozenBNF' depends on axioms: [propext]
info: 05_independent_tribunal/P3BTribunalAudit.lean:25:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalSideCondEq' depends on axioms: [propext]
info: 05_independent_tribunal/P3BTribunalAudit.lean:26:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalIntrinsicOblsEq' depends on axioms: [propext, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:27:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalSummaryEq' depends on axioms: [propext]
info: 05_independent_tribunal/P3BTribunalAudit.lean:28:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_FrozenParseGrammarAcyclic' depends on axioms: [propext]
info: 05_independent_tribunal/P3BTribunalAudit.lean:29:0: 'BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserTerminates' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:30:0: 'BrocaOmega.P3B.ProofObligations.PO_C1_01_OutOfDomainBoundarySound' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:31:0: 'BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserSoundness' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:32:0: 'BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserExhaustiveCompleteness' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:33:0: 'BrocaOmega.P3B.ProofObligations.PO_C1_01_EnumeratedEmptySound' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:34:0: 'BrocaOmega.P3B.ProofObligations.PO_C1_01_ResourceOverflowFailClosed' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:35:0: 'BrocaOmega.P3B.ProofObligations.PO_C1_01_NonVacuous_G01_Witness' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:36:0: 'BrocaOmega.P3B.ProofObligations.PO_C1_01_NonVacuous_T2_DualReadings' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:37:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_LowerToP2Cert_ProjectionFaithful' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:38:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_ProjectionFaithful_CheckerIff' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:39:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_BridgeSound' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:40:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_BridgeSound_MemEnumeratedForest' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:41:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_VerifyBridgedDerivation_Sound' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P3BTribunalAudit.lean:42:0: 'BrocaOmega.P3B.ProofObligations.PO_P3B_All28CounterexampleVectors_Verified' depends on axioms: [propext, Classical.choice, Quot.sound]
✔ [53/54] Built P3BTribunalAudit:c.o (381ms)
✔ [54/54] Built p3b_tribunal_runner:exe (1.6s)
Build completed successfully (54 jobs).
```

### 4.2 `p3b_tribunal_runner.exe` Execution Output (`28/28` Curated Vectors)
```text
==========================================================================
BROCA-NATIVE OMEGA — AUTH-C1-P3-B BOUNDED PARSER & BRIDGE VERIFICATION
Scope     : PO-C1-01 Bounded Exhaustive Parser + BridgeSound + F-P3A-01
Toolchain : Lean 4.33.1 Core (Init + Frozen P2/P3-A, 0 sorry, 0 ofReduceBool)
==========================================================================
[PASS] PC-P3B-01 (PAIR-01-G01-PARSE) => ENUMERATED_1(G01:alt1)
[PASS] CE-P3B-01 (PAIR-01-G01-PARSE) => ENUMERATED_0
[PASS] PC-P3B-02 (PAIR-02-G03-SIDECOND) => ENUMERATED_1(G03:alt1)
[PASS] CE-P3B-02 (PAIR-02-G03-SIDECOND) => ENUMERATED_0
[PASS] PC-P3B-03 (PAIR-03-G09-VS-GRAMMAR) => ENUMERATED_1(G09:alt1)
[PASS] CE-P3B-03 (PAIR-03-G09-VS-GRAMMAR) => ENUMERATED_0
[PASS] PC-P3B-04 (PAIR-04-G15-DISCOURSE) => ENUMERATED_1(G15:alt1)
[PASS] CE-P3B-04 (PAIR-04-G15-DISCOURSE) => ENUMERATED_0
[PASS] PC-P3B-05 (PAIR-05-G16-CONTRAST) => ENUMERATED_1(G16:alt1)
[PASS] CE-P3B-05 (PAIR-05-G16-CONTRAST) => ENUMERATED_0
[PASS] PC-P3B-06 (PAIR-06-T2-DUAL-READING) => ENUMERATED_2(T2:alt1,T2:alt2)
[PASS] CE-P3B-06 (PAIR-06-T2-DUAL-READING) => OVERFLOW(maxReadingsExceeded:2>1)
[PASS] PC-P3B-07 (PAIR-07-T1-AND-MAXBYTES) => ENUMERATED_2(T1:alt1,T1:alt2)
[PASS] CE-P3B-07 (PAIR-07-T1-AND-MAXBYTES) => OVERFLOW(maxBytesExceeded:68>20)
[PASS] PC-P3B-08 (PAIR-08-T3-AND-MAXSTEPS) => ENUMERATED_1(T3:alt1)
[PASS] CE-P3B-08 (PAIR-08-T3-AND-MAXSTEPS) => OVERFLOW(maxStepsExceeded:5)
[PASS] PC-P3B-09 (PAIR-09-T4-AND-MAXNODES) => ENUMERATED_2(T4:alt1,T4:alt2)
[PASS] CE-P3B-09 (PAIR-09-T4-AND-MAXNODES) => OVERFLOW(maxForestNodesExceeded:1)
[PASS] PC-P3B-10 (PAIR-10-T5-AND-DOMAIN-EMPTY) => ENUMERATED_1(T5:alt1)
[PASS] CE-P3B-10 (PAIR-10-T5-AND-DOMAIN-EMPTY) => OUT_OF_DOMAIN(emptyInput)
[PASS] PC-P3B-11 (PAIR-11-DOMAIN-NONASCII) => ENUMERATED_1(G11:alt1)
[PASS] CE-P3B-11 (PAIR-11-DOMAIN-NONASCII) => OUT_OF_DOMAIN(nonPrintableAsciiByte:195)
[PASS] PC-P3B-12 (PAIR-12-BRIDGE-MULTIDOT) => BRIDGE_ACCEPTED
[PASS] CE-P3B-12 (PAIR-12-BRIDGE-MULTIDOT) => BRIDGE_REJECTED(slotLexicalRejected:multipleDecimalPoints)
[PASS] PC-P3B-13 (PAIR-13-BRIDGE-ENTITY-SPOOF) => BRIDGE_ACCEPTED
[PASS] CE-P3B-13 (PAIR-13-BRIDGE-ENTITY-SPOOF) => BRIDGE_REJECTED(slotLexicalRejected:entityCatalogMismatch)
[PASS] PC-P3B-14 (PAIR-14-PROJECTION-AND-TRAP) => PROJECTION_FAITHFUL_VERIFIED
[PASS] CE-P3B-14 (PAIR-14-PROJECTION-AND-TRAP) => BRIDGE_REJECTED(forgedOrTrapRuleCode:902)
--------------------------------------------------------------------------
TOTAL CURATED VECTORS : 28/28 PASSED
```

### 4.3 `differential_oracle_p3b.py` Execution Output (`28/28` Fixed + `250/250` External Batch 1:1 Parity)
```text
==========================================================================
BROCA-NATIVE OMEGA — P3-B PYTHON 3.11 1:1 DIFFERENTIAL ORACLE REPORT
==========================================================================
Fixed Curated (PC, CE) Suite Parity : 28/28 PASSED
External Serialized Batch Vectors   : 250/250 EXACT 1:1 PARITY
  - Valid Enumerated Parses (|T|>=1): 66
  - In-Domain Invalid (ENUM:0:)     : 110
  - OutOfDomain Rejections (OOD:)   : 30
  - ResourceOverflow Fail-Closed    : 44
==========================================================================
DIFFERENTIAL ORACLE VERDICT: 100% EXACT 1:1 PARITY (0 MISMATCHES)
```

### 4.4 `lake env leanchecker --fresh P3BTribunalAudit` Output
```text
LEANCHECKER_EXIT_CODE=0 ELAPSED_SEC=395.38
```

---

## 5. Verbatim Unmodified Source, Build Config, Oracle & Receipt Files (`14` Source Blocks + `1` Receipt Block)

### File 1: `lean-toolchain` (SHA-256: `3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71`)
````text
leanprover/lean4:v4.33.1
````

### File 2: `lakefile.toml` (SHA-256: `5566CAF6C914C2C57B772DAAEBE24CDF9A80F7357FD9A70B78E986EC81ED5A71`)
````toml
name = "broca_omega_gate_c1_p3b"
version = "0.1.0"
defaultTargets = ["P3BFormalSpec", "P3BDetachedChecker", "P3BCounterexamples", "P3BProofObligations", "p3b_tribunal_runner"]

[[require]]
name = "broca_omega_gate_c1_p2"
path = "../P2_DerivationReplay"

[[require]]
name = "broca_omega_gate_c1_p3a"
path = "../P3_LexicalGrammar"

[[lean_lib]]
name = "P3BFormalSpec"
srcDir = "01_formal_spec"

[[lean_lib]]
name = "P3BDetachedChecker"
srcDir = "02_detached_checker"

[[lean_lib]]
name = "P3BCounterexamples"
srcDir = "03_counterexamples"

[[lean_lib]]
name = "P3BProofObligations"
srcDir = "04_proof_obligations"

[[lean_exe]]
name = "p3b_tribunal_runner"
srcDir = "05_independent_tribunal"
root = "P3BTribunalAudit"
````

### File 3: `01_formal_spec/P3BFormalSpec.lean` (SHA-256: `53612302FE6918F9B399E74D6A4CFFEF5F19BC7561C46A3082E7925E9A47A307`)
````lean
import P3BFormalSpec.DeclarativeParseSpec
import P3BFormalSpec.FullGrammarCorrespondence
````

### File 4: `01_formal_spec/P3BFormalSpec/DeclarativeParseSpec.lean` (SHA-256: `078605A7D221C0F6027DE0071D94A97EF616B40DD98E617DA893371C771C645D`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` Bounded Exhaustive Parser & `BridgeSound`)
  01_formal_spec/P3BFormalSpec/DeclarativeParseSpec.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2FormalSpec` & `P3FormalSpec`)

  Gate A Deliverable:
  Defines the algorithm-independent declarative parsing specification `ValidParse_GFrozen`
  directly from `Architecture Freeze R0` (`S0-R2`, `S0-R2.1`, `S0-R2.2`, `Gate C0-R1`, `P0-A05`):
    1. All 34 frozen productions (`27` generator `G-01`~`G-16` + envelopes, `7` parser-only traps `T1`~`T5` + envelopes).
    2. `ConcreteParseTree` carrying explicit `readingAlt : Nat` (`1..altCount`) so `T2`'s two
       semantic readings (`alt=1` non-factive vs `alt=2` factive presupposition) are distinct
       first-class parse trees without increasing the 21 canonical rule IDs!
    3. Independent side-condition, summary, and intrinsic-obligation specifications (never calling
       `P2.ruleSignature` or `parseAllBounded` — strictly non-circular!).
    4. Exact slot-level `P3-A` lexical validity (`LexicallyValid ∧ NumericallyWellFormed ∧ EntityCatalogBound`).
-/
import P2FormalSpec
import P3FormalSpec

namespace BrocaOmega.P3B

open BrocaOmega.P2
open BrocaOmega.P3A

/-! ### 1. Closed 34-Production Enumeration of `G_parse = G_gen ∪ G_trap` -/

inductive FrozenParseProd where
  -- (A) 8 Generator Structural Wrappers (`S0-R2.1` §II.1)
  | Env_DocSingle
  | Env_ScopedInitial
  | Env_ScopedRepeat
  | Env_ScopedAssoc
  | Env_ScopedContrastMeta
  | Env_LiftAssoc
  | Env_LiftMeta
  | Env_EmbeddedCausal
  -- (B) 19 Generator Core & Document Productions (`G-01` ~ `G-16`)
  | Gen_G01_DescIncidence
  | Gen_G02a_DescMeanSD
  | Gen_G02b_DescMedianIQR
  | Gen_G03_AssocUnadj
  | Gen_G04_AssocTemp
  | Gen_G05_CompRD
  | Gen_G06a_IntervDirectional
  | Gen_G06b_IntervNeutral
  | Gen_G07_MetaNotStatSig
  | Gen_G08_MetaEquiv
  | Gen_G09_MetaNonEstab
  | Gen_G10_MetaUnresolved
  | Gen_G11_QuantZero
  | Gen_G12_QuantProperPart
  | Gen_G13_QuantAtLeastOne
  | Gen_G14_AssocAdj
  | Gen_G15a_DocConjAtomic
  | Gen_G15b_DocConjDiscourse
  | Gen_G16_DocContrastive
  -- (C) 7 Parser-Only Trap Wrappers & Productions (`T1` ~ `T5`, `P0-A05` §2)
  | Env_DocTrapScoped
  | Env_ScopedTrap
  | Trap_T1_AllNot
  | Trap_T2_ConfirmThat
  | Trap_T3_WhPresup
  | Trap_T4_BarePlural
  | Trap_T5_UnscopedDoc
  deriving DecidableEq, Repr

def allFrozenParseProds : List FrozenParseProd :=
  [ .Env_DocSingle, .Env_ScopedInitial, .Env_ScopedRepeat, .Env_ScopedAssoc,
    .Env_ScopedContrastMeta, .Env_LiftAssoc, .Env_LiftMeta, .Env_EmbeddedCausal,
    .Gen_G01_DescIncidence, .Gen_G02a_DescMeanSD, .Gen_G02b_DescMedianIQR,
    .Gen_G03_AssocUnadj, .Gen_G04_AssocTemp, .Gen_G05_CompRD,
    .Gen_G06a_IntervDirectional, .Gen_G06b_IntervNeutral, .Gen_G07_MetaNotStatSig,
    .Gen_G08_MetaEquiv, .Gen_G09_MetaNonEstab, .Gen_G10_MetaUnresolved,
    .Gen_G11_QuantZero, .Gen_G12_QuantProperPart, .Gen_G13_QuantAtLeastOne,
    .Gen_G14_AssocAdj, .Gen_G15a_DocConjAtomic, .Gen_G15b_DocConjDiscourse,
    .Gen_G16_DocContrastive,
    .Env_DocTrapScoped, .Env_ScopedTrap,
    .Trap_T1_AllNot, .Trap_T2_ConfirmThat, .Trap_T3_WhPresup,
    .Trap_T4_BarePlural, .Trap_T5_UnscopedDoc ]

theorem allFrozenParseProds_nodup_and_complete (p : FrozenParseProd) :
    p ∈ allFrozenParseProds := by
  cases p <;> decide

/-! ### 2. Independent Summary, Side-Condition & Obligation Signature of `G_parse` -/

structure ParseSummary where
  cohortId      : Option String := none
  designId      : Option String := none
  expOutPair    : Option (String × String) := none
  embeddedKey   : Option String := none
  startsWithInOrWithin : Bool := false
  deriving DecidableEq, Repr

def lookupTagVal (slots : List (BNFSlotTag × String)) (t : BNFSlotTag) : String :=
  match slots.find? (fun p => p.1 == t) with
  | some (_, v) => v
  | none        => ""

def clauseOverrideOfIdx : Nat → Option ClauseLocus
  | 1 => some .clause1
  | 2 => some .clause2
  | _ => none

structure FrozenProdSpec where
  ownerRule     : Option CanonicalRuleId
  isGenerator   : Bool
  lhs           : BNFNonterm
  rhs           : List BNFSymbol
  checkSide     : ScopeEnv → List (BNFSlotTag × String) → List ParseSummary → Bool
  intrinsicObls : ClauseLocus → List (BNFSlotTag × String) → List ParseSummary → List ObligationSpec
  mkSum         : List (BNFSlotTag × String) → List ParseSummary → ParseSummary

/-- Reading count of a `FrozenParseProd` (`1` for wrappers & single-reading rules, `2` for `T1`, `T2`, `T4`). -/
def FrozenParseProd.altCount (p : FrozenParseProd) : Nat :=
  match p with
  | .Trap_T1_AllNot      => 2
  | .Trap_T2_ConfirmThat => 2
  | .Trap_T4_BarePlural  => 2
  | _                    => 1

/--
  Independent Declarative Production Specification derived directly from `Architecture Freeze R0`
  (`S0-R2`, `S0-R2.1`, `S0-R2.2`, `Gate C0-R1`, `P0-A05`).
  Does NOT call `P2.ruleSignature`!
-/
def frozenProdSig : FrozenParseProd → FrozenProdSpec
  | .Env_DocSingle =>
    { ownerRule := none, isGenerator := true, lhs := .controlledDocument,
      rhs := [.nonterm .scopedInitial 1, .term "."],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Env_ScopedInitial =>
    { ownerRule := none, isGenerator := true, lhs := .scopedInitial,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .atomicCore 0],
      checkSide := fun env s _ => lookupTagVal s .cohort == env.cohortId,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupTagVal s .cohort }],
      mkSum := fun s ch =>
        { cohortId := some (lookupTagVal s .cohort)
          expOutPair := match ch with | [c] => c.expOutPair | _ => none
          startsWithInOrWithin := true } }

  | .Env_ScopedRepeat =>
    { ownerRule := none, isGenerator := true, lhs := .scopedRepeat,
      rhs := [.term "Within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .atomicCore 0],
      checkSide := fun env s _ => lookupTagVal s .design == env.expectedDesignHead,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := "resolve:" ++ lookupTagVal s .design }],
      mkSum := fun s ch =>
        { designId := some (lookupTagVal s .design)
          expOutPair := match ch with | [c] => c.expOutPair | _ => none
          startsWithInOrWithin := true } }

  | .Env_ScopedAssoc =>
    { ownerRule := none, isGenerator := true, lhs := .scopedAssoc,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .assocCore 0],
      checkSide := fun env s _ => lookupTagVal s .cohort == env.cohortId,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupTagVal s .cohort }],
      mkSum := fun s ch =>
        { cohortId := some (lookupTagVal s .cohort)
          expOutPair := match ch with | [c] => c.expOutPair | _ => none
          startsWithInOrWithin := true } }

  | .Env_ScopedContrastMeta =>
    { ownerRule := none, isGenerator := true, lhs := .scopedContrastMeta,
      rhs := [.term "within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .metaNonEstabCore 0],
      checkSide := fun env s _ => lookupTagVal s .design == env.expectedDesignHead,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := "resolve:" ++ lookupTagVal s .design }],
      mkSum := fun s ch =>
        { designId := some (lookupTagVal s .design)
          expOutPair := match ch with | [c] => c.expOutPair | _ => none
          startsWithInOrWithin := true } }

  | .Env_LiftAssoc =>
    { ownerRule := none, isGenerator := true, lhs := .atomicCore,
      rhs := [.nonterm .assocCore 0],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ ch => match ch with | [c] => c | _ => {} }

  | .Env_LiftMeta =>
    { ownerRule := none, isGenerator := true, lhs := .atomicCore,
      rhs := [.nonterm .metaNonEstabCore 0],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ ch => match ch with | [c] => c | _ => {} }

  | .Env_EmbeddedCausal =>
    { ownerRule := none, isGenerator := true, lhs := .embeddedCausal,
      rhs := [.lexSlot .expLevel .activeExp, .term " ", .lexSlot .intervVerbPres .verb, .term " ", .lexSlot .outTerm .outcome],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun s _ =>
        let act := lookupTagVal s .activeExp
        let vb  := lookupTagVal s .verb
        let out := lookupTagVal s .outcome
        { expOutPair := some (act, out)
          embeddedKey := some (act ++ ":" ++ vb ++ ":" ++ out) } }

  | .Gen_G01_DescIncidence =>
    { ownerRule := some .G01, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "over ", .lexSlot .followUpWindow .window,
               .term ", the cumulative incidence of ", .lexSlot .eventTerm .eventA,
               .term " was ", .lexSlot .numericLit .numK,
               .term " of ", .lexSlot .numericLit .numN,
               .term " patients (", .lexSlot .numericLit .numPct, .term "%)" ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descIncidence,
           target := lookupTagVal s .window ++ ":" ++ lookupTagVal s .eventA ++ ":" ++
                     lookupTagVal s .numK ++ "/" ++ lookupTagVal s .numN ++ "=" ++ lookupTagVal s .numPct }],
      mkSum := fun _ _ => {} }

  | .Gen_G02a_DescMeanSD =>
    { ownerRule := some .G02, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the mean ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (SD ", .lexSlot .numericLit .numDisp1, .term ")" ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descDistribution,
           target := "mean_sd:" ++ lookupTagVal s .measure ++ ":" ++ lookupTagVal s .numEst ++ ":" ++ lookupTagVal s .numDisp1 }],
      mkSum := fun _ _ => {} }

  | .Gen_G02b_DescMedianIQR =>
    { ownerRule := some .G02, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the median ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (IQR ", .lexSlot .numericLit .numDisp1,
               .term " to ", .lexSlot .numericLit .numDisp2, .term ")" ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descDistribution,
           target := "median_iqr:" ++ lookupTagVal s .measure ++ ":" ++ lookupTagVal s .numEst ++ ":" ++
                     lookupTagVal s .numDisp1 ++ ".." ++ lookupTagVal s .numDisp2 }],
      mkSum := fun _ _ => {} }

  | .Gen_G03_AssocUnadj =>
    { ownerRule := some .G03, isGenerator := true, lhs := .assocCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .assocMetricDir,
           target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .direction ++ ":" ++
                     lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome }],
      mkSum := fun s _ => { expOutPair := some (lookupTagVal s .activeExp, lookupTagVal s .outcome) } }

  | .Gen_G04_AssocTemp =>
    { ownerRule := some .G04, isGenerator := true, lhs := .assocCore,
      rhs := [ .lexSlot .eventTerm .eventA, .term " preceded ", .lexSlot .eventTerm .eventB,
               .term ", and comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ =>
        (lookupTagVal s .eventA != lookupTagVal s .eventB) &&
        (lookupTagVal s .activeExp != lookupTagVal s .refExp),
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .temporalPrecedence,
            target := lookupTagVal s .eventA ++ "<" ++ lookupTagVal s .eventB },
          { locus := loc, kind := .assocMetricDir,
            target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .direction ++ ":" ++
                      lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome } ],
      mkSum := fun s _ => { expOutPair := some (lookupTagVal s .activeExp, lookupTagVal s .outcome) } }

  | .Gen_G05_CompRD =>
    { ownerRule := some .G05, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the absolute risk difference in ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " percentage points (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .absRiskDiff,
           target := "RD:" ++ lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome }],
      mkSum := fun _ _ => {} }

  | .Gen_G06a_IntervDirectional =>
    { ownerRule := some .G06, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was estimated to ", .lexSlot .intervDirVerb .verb,
               .term " ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ", p = ", .lexSlot .numericLit .numPVal, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .identAssumption, target := lookupTagVal s .assumption },
          { locus := loc, kind := .intervDirectional,
            target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .verb ++ ":" ++
                      lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome } ],
      mkSum := fun _ _ => {} }

  | .Gen_G06b_IntervNeutral =>
    { ownerRule := some .G06, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", the estimated causal ", .lexSlot .ratioMetric .metric1,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term "), which did not exclude no effect" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .identAssumption, target := lookupTagVal s .assumption },
          { locus := loc, kind := .intervNeutral,
            target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .activeExp ++ ":" ++
                      lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome } ],
      mkSum := fun _ _ => {} }

  | .Gen_G07_MetaNotStatSig =>
    { ownerRule := some .G07, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the observed ", .lexSlot .ratioMetric .metric1,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric2,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ") was not statistically significant at alpha = ",
               .lexSlot .numericLit .numAlpha ],
      checkSide := fun _ s _ =>
        (lookupTagVal s .metric1 == lookupTagVal s .metric2) &&
        (lookupTagVal s .activeExp != lookupTagVal s .refExp),
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .metaNotStatSig,
           target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .activeExp ++ ":" ++
                     lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome ++ ":" ++ lookupTagVal s .numAlpha }],
      mkSum := fun _ _ => {} }

  | .Gen_G08_MetaEquiv =>
    { ownerRule := some .G08, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " met prespecified equivalence margins (",
               .lexSlot .numericLit .numMarginLow, .term " to ", .lexSlot .numericLit .numMarginHigh,
               .term ") for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% TOST CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .metaEquivMargins,
           target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .activeExp ++ ":" ++
                     lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome ++ ":" ++
                     lookupTagVal s .numMarginLow ++ ".." ++ lookupTagVal s .numMarginHigh }],
      mkSum := fun _ _ => {} }

  | .Gen_G09_MetaNonEstab =>
    { ownerRule := some .G09, isGenerator := true, lhs := .metaNonEstabCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not establish that ", .nonterm .embeddedCausal 0 ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s ch =>
        let embKey := match ch with | [c] => c.embeddedKey.getD "" | _ => ""
        [{ locus := loc, kind := .metaNonEstabNeg, target := lookupTagVal s .source ++ ":" ++ embKey }],
      mkSum := fun _ ch => { expOutPair := match ch with | [c] => c.expOutPair | _ => none } }

  | .Gen_G10_MetaUnresolved =>
    { ownerRule := some .G10, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not determine whether ", .nonterm .embeddedCausal 0 ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s ch =>
        let embKey := match ch with | [c] => c.embeddedKey.getD "" | _ => ""
        [{ locus := loc, kind := .metaUnresolvedPolar, target := lookupTagVal s .source ++ ":" ++ embKey }],
      mkSum := fun _ _ => {} }

  | .Gen_G11_QuantZero =>
    { ownerRule := some .G11, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "no ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantZeroNeg,
           target := lookupTagVal s .subgroup ++ ":" ++ lookupTagVal s .eventA }],
      mkSum := fun _ _ => {} }

  | .Gen_G12_QuantProperPart =>
    { ownerRule := some .G12, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "some, but not all, ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantProperPart,
           target := lookupTagVal s .subgroup ++ ":" ++ lookupTagVal s .eventA }],
      mkSum := fun _ _ => {} }

  | .Gen_G13_QuantAtLeastOne =>
    { ownerRule := some .G13, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "at least one ", .lexSlot .subgroupSingular .subgroup,
               .term " patient developed ", .lexSlot .eventTerm .eventA ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantExistential,
           target := lookupTagVal s .subgroup ++ ":" ++ lookupTagVal s .eventA }],
      mkSum := fun _ _ => {} }

  | .Gen_G14_AssocAdj =>
    { ownerRule := some .G14, isGenerator := true, lhs := .assocCore,
      rhs := [ .term "after adjustment for ", .lexSlot .covariateList .covariates,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .covariateAdjustment, target := lookupTagVal s .covariates },
          { locus := loc, kind := .assocMetricDir,
            target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .direction ++ ":" ++
                      lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome } ],
      mkSum := fun s _ => { expOutPair := some (lookupTagVal s .activeExp, lookupTagVal s .outcome) } }

  | .Gen_G15a_DocConjAtomic =>
    { ownerRule := some .G15, isGenerator := true, lhs := .controlledDocument,
      rhs := [.nonterm .scopedInitial 1, .term ". ", .nonterm .scopedInitial 2, .term "."],
      checkSide := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (env.quoteIsolation == .sentenceAtomic) &&
          (c1.cohortId == some env.cohortId) &&
          (c2.cohortId == some env.cohortId)
        | _ => false,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Gen_G15b_DocConjDiscourse =>
    { ownerRule := some .G15, isGenerator := true, lhs := .controlledDocument,
      rhs := [.nonterm .scopedInitial 1, .term ". ", .nonterm .scopedRepeat 2, .term "."],
      checkSide := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (env.quoteIsolation == .discourseBound) &&
          (c1.cohortId == some env.cohortId) &&
          (c2.designId == some env.expectedDesignHead)
        | _ => false,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Gen_G16_DocContrastive =>
    { ownerRule := some .G16, isGenerator := true, lhs := .controlledDocument,
      rhs := [.nonterm .scopedAssoc 1, .term "; however, ", .nonterm .scopedContrastMeta 2, .term "."],
      checkSide := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (c1.cohortId == some env.cohortId) &&
          (c2.designId == some env.expectedDesignHead) &&
          c1.expOutPair.isSome &&
          (c1.expOutPair == c2.expOutPair)
        | _ => false,
      intrinsicObls := fun _ _ ch =>
        match ch with
        | [c1, _] =>
          match c1.expOutPair with
          | some (eId, oId) =>
            [{ locus := .clause2, kind := .contrastiveBoundary, target := eId ++ ":" ++ oId }]
          | none =>
            [{ locus := .clause2, kind := .contrastiveBoundary, target := "" }]
        | _ => [],
      mkSum := fun _ _ => {} }

  -- (C) Parser-Only Trap Productions (`G_trap = G_parse \ G_gen`, `P0-A05` §2)
  | .Env_DocTrapScoped =>
    { ownerRule := none, isGenerator := false, lhs := .controlledDocument,
      rhs := [.nonterm .scopedTrapClause 1, .term "."],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Env_ScopedTrap =>
    { ownerRule := none, isGenerator := false, lhs := .scopedTrapClause,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .trapCore 0],
      checkSide := fun env s _ => lookupTagVal s .cohort == env.cohortId,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupTagVal s .cohort }],
      mkSum := fun s _ => { cohortId := some (lookupTagVal s .cohort), startsWithInOrWithin := true } }

  | .Trap_T1_AllNot =>
    { ownerRule := some .T1, isGenerator := false, lhs := .trapCore,
      rhs := [.term "all ", .lexSlot .subgroupPlural .subgroup,
              .term " patients did not develop ", .lexSlot .eventTerm .eventA],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Trap_T2_ConfirmThat =>
    { ownerRule := some .T2, isGenerator := false, lhs := .trapCore,
      rhs := [.term "the analysis of ", .lexSlot .sourceId .source,
              .term " did not confirm that ", .nonterm .embeddedCausal 0],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ ch => { expOutPair := match ch with | [c] => c.expOutPair | _ => none } }

  | .Trap_T3_WhPresup =>
    { ownerRule := some .T3, isGenerator := false, lhs := .trapCore,
      rhs := [.term "the analysis of ", .lexSlot .sourceId .source,
              .term " did not ", .lexSlot .epistemicVerb .verb,
              .term " ", .lexSlot .whWord .whComp,
              .term " ", .nonterm .embeddedCausal 0],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ ch => { expOutPair := match ch with | [c] => c.expOutPair | _ => none } }

  | .Trap_T4_BarePlural =>
    { ownerRule := some .T4, isGenerator := false, lhs := .trapCore,
      rhs := [.lexSlot .subgroupPlural .subgroup,
              .term " patients developed ", .lexSlot .eventTerm .eventA],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Trap_T5_UnscopedDoc =>
    { ownerRule := some .T5, isGenerator := false, lhs := .controlledDocument,
      rhs := [.nonterm .atomicCore 1, .term "."],
      checkSide := fun _ _ _ => true, -- Note: `AtomicCore` never begins with `"In "` or `"Within this same "`!
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

/-- Acyclicity Theorem across ALL 34 productions of `frozenProdSig` (`childNt.level < lhs.level`). -/
theorem frozenProdSig_child_level_lt (p : FrozenParseProd) (nt : BNFNonterm) (cIdx : Nat)
    (hmem : BNFSymbol.nonterm nt cIdx ∈ (frozenProdSig p).rhs) :
    nt.level < (frozenProdSig p).lhs.level := by
  cases p <;> simp [frozenProdSig] at hmem
  all_goals
    try (rcases hmem with ⟨rfl, _⟩ | ⟨rfl, _⟩ <;> decide)
    try (rcases hmem with ⟨rfl, _⟩; decide)

/-! ### 3. Concrete Parse Reading Tree (`ParsedReadingTree` with Explicit `readingAlt`) -/

mutual
  inductive ConcreteParseArg where
    | litTok   (text : String) (span : CodepointSpan)
    | slotTok  (sort : P3SlotSort) (tag : BNFSlotTag)
               (entityId : String) (lexeme : String) (span : CodepointSpan)
    | childSub (tree : ConcreteParseTree)

  inductive ConcreteParseTree where
    | mkTree
        (prod       : FrozenParseProd)
        (readingAlt : Nat)
        (locus      : ClauseLocus)
        (span       : CodepointSpan)
        (args       : List ConcreteParseArg)
end

-- Explicit structural equality & `DecidableEq` on `ConcreteParseTree` / `ConcreteParseArg`
mutual
  def parseArgEqBool : ConcreteParseArg → ConcreteParseArg → Bool
    | .litTok t1 sp1, .litTok t2 sp2 => (t1 == t2) && (sp1 == sp2)
    | .slotTok s1 tg1 id1 l1 sp1, .slotTok s2 tg2 id2 l2 sp2 =>
      (s1 == s2) && (tg1 == tg2) && (id1 == id2) && (l1 == l2) && (sp1 == sp2)
    | .childSub sub1, .childSub sub2 => parseTreeEqBool sub1 sub2
    | _, _ => false

  def parseArgListEqBool : List ConcreteParseArg → List ConcreteParseArg → Bool
    | [], [] => true
    | a1 :: r1, a2 :: r2 => parseArgEqBool a1 a2 && parseArgListEqBool r1 r2
    | _, _ => false

  def parseTreeEqBool : ConcreteParseTree → ConcreteParseTree → Bool
    | .mkTree p1 a1 l1 sp1 args1, .mkTree p2 a2 l2 sp2 args2 =>
      (p1 == p2) && (a1 == a2) && (l1 == l2) && (sp1 == sp2) && parseArgListEqBool args1 args2
end

mutual
  theorem parseArgEqBool_iff (x y : ConcreteParseArg) :
      parseArgEqBool x y = true ↔ x = y := by
    cases x <;> cases y <;> simp [parseArgEqBool, Bool.and_eq_true, beq_iff_eq, and_assoc]
    case childSub.childSub s1 s2 =>
      exact parseTreeEqBool_iff s1 s2

  theorem parseArgListEqBool_iff (xs ys : List ConcreteParseArg) :
      parseArgListEqBool xs ys = true ↔ xs = ys := by
    cases xs <;> cases ys <;> simp [parseArgListEqBool, Bool.and_eq_true]
    case cons.cons a1 r1 a2 r2 =>
      rw [parseArgEqBool_iff, parseArgListEqBool_iff]

  theorem parseTreeEqBool_iff (t1 t2 : ConcreteParseTree) :
      parseTreeEqBool t1 t2 = true ↔ t1 = t2 := by
    cases t1 with
    | mkTree p1 a1 l1 sp1 args1 =>
      cases t2 with
      | mkTree p2 a2 l2 sp2 args2 =>
        simp [parseTreeEqBool, Bool.and_eq_true, beq_iff_eq, parseArgListEqBool_iff, and_assoc]
end

instance : DecidableEq ConcreteParseTree := fun t1 t2 =>
  if h : parseTreeEqBool t1 t2 = true then
    isTrue ((parseTreeEqBool_iff t1 t2).mp h)
  else
    isFalse (fun heq => h ((parseTreeEqBool_iff t1 t2).mpr heq))

instance : BEq ConcreteParseTree where
  beq := parseTreeEqBool

def ConcreteParseTree.span : ConcreteParseTree → CodepointSpan
  | .mkTree _ _ _ sp _ => sp

def ConcreteParseTree.readingAlt : ConcreteParseTree → Nat
  | .mkTree _ alt _ _ _ => alt

def ConcreteParseTree.prod : ConcreteParseTree → FrozenParseProd
  | .mkTree p _ _ _ _ => p

mutual
  def reconstructParseSegChars : List ConcreteParseArg → List Char
    | [] => []
    | .litTok txt _ :: rest       => txt.toList ++ reconstructParseSegChars rest
    | .slotTok _ _ _ lex _ :: rest => lex.toList ++ reconstructParseSegChars rest
    | .childSub sub :: rest       => reconstructParseChars sub ++ reconstructParseSegChars rest

  def reconstructParseChars : ConcreteParseTree → List Char
    | .mkTree _ _ _ _ args => reconstructParseSegChars args
end

def reconstructParseYield (t : ConcreteParseTree) : String :=
  String.ofList (reconstructParseChars t)

/-! ### 4. Supported Character Domain & Declarative `ValidParse_GFrozen` (`Gate A / Gate C`) -/

/--
  Character-profile domain precondition for English `D_0` (`OutOfDomain` boundary):
  Non-empty raw byte sequence where every byte is printable 7-bit ASCII (`0x20..0x7E`).
  Crucially separated from `maxBytes` resource budget (`ResourceOverflow` ≠ `OutOfDomain`)!
-/
def StrictAsciiDomainSupported (rawBytes : List UInt8) : Prop :=
  0 < rawBytes.length ∧ ∀ b ∈ rawBytes, IsPrintableAsciiByte b

def strToAsciiBytes (s : String) : List UInt8 :=
  s.toList.map (fun c => UInt8.ofNat c.toNat)

/-- Declarative `P3-A` lexical validity of a `(sort, entityId, lexeme)` triple over an in-domain string. -/
def DeclarativeSlotValid (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (eid lex : String) : Prop :=
  let cand : RawSlotCandidate := { sort := srt, entityId := eid, rawBytes := strToAsciiBytes lex }
  cand.decodedStr = lex ∧
  LexicallyValid maxSlotBytes cand ∧
  NumericallyWellFormed numCfg cand ∧
  EntityCatalogBound cat cand

/-
  Algorithm-Free Declarative Parsing Relation (`ValidParseSegs` & `ValidParseNode`):
  Defines exact membership in `G_parse` (`G-01`~`G-16` ∪ `T1`~`T5`) with contiguous spans,
  `P3-A` lexical validity on every slot, preserved `readingAlt ∈ 1..altCount`, and side conditions.
-/
mutual
  def ValidParseSegs (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (cursor : Nat) (syms : List BNFSymbol) (args : List ConcreteParseArg)
      (endPos : Nat) (slots : List (BNFSlotTag × String)) (sums : List ParseSummary) : Prop :=
    match syms, args with
    | [], [] =>
      cursor ≤ Y.length ∧ endPos = cursor ∧ slots = [] ∧ sums = []
    | .term lit :: restSyms, .litTok txt sp :: restArgs =>
      txt = lit ∧
      sp.startCp = cursor ∧
      SpanMatches Y sp txt.toList ∧
      ValidParseSegs cat numCfg env Y loc sp.endCp restSyms restArgs endPos slots sums
    | .lexSlot srt tag :: restSyms, .slotTok aSrt aTag eid lex sp :: restArgs =>
      ∃ restSlots : List (BNFSlotTag × String),
        aSrt = srt ∧
        aTag = tag ∧
        sp.startCp = cursor ∧
        SpanMatches Y sp lex.toList ∧
        DeclarativeSlotValid cat numCfg Y.length srt eid lex ∧
        slots = (tag, eid) :: restSlots ∧
        ValidParseSegs cat numCfg env Y loc sp.endCp restSyms restArgs endPos restSlots sums
    | .nonterm childNt cIdx :: restSyms, .childSub sub :: restArgs =>
      ∃ (subSum : ParseSummary) (restSums : List ParseSummary),
        sub.span.startCp = cursor ∧
        ValidParseNode cat numCfg env Y ((clauseOverrideOfIdx cIdx).getD loc) childNt sub subSum ∧
        sums = subSum :: restSums ∧
        ValidParseSegs cat numCfg env Y loc sub.span.endCp restSyms restArgs endPos slots restSums
    | _, _ => False

  def ValidParseNode (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (env : ScopeEnv) (Y : List Char) (expectedLoc : ClauseLocus)
      (expectedNt : BNFNonterm) (tree : ConcreteParseTree) (outSum : ParseSummary) : Prop :=
    match tree with
    | .mkTree p alt loc sp args =>
      let sig := frozenProdSig p
      ∃ (slots : List (BNFSlotTag × String)) (sums : List ParseSummary),
        loc = expectedLoc ∧
        sig.lhs = expectedNt ∧
        1 ≤ alt ∧ alt ≤ p.altCount ∧
        ValidParseSegs cat numCfg env Y loc sp.startCp sig.rhs args sp.endCp slots sums ∧
        sig.checkSide env slots sums = true ∧
        outSum = sig.mkSum slots sums
end

/--
  **Root Declarative Frozen Parse Relation (`ValidParse_GFrozen`)**:
  Holds iff `rawBytes` is in the supported 7-bit printable ASCII domain, `tree` spans `[0, |Y|)`,
  and `tree` is a valid root `controlledDocument` parse tree at `clause1`.
-/
def ValidParse_GFrozen (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (rawBytes : List UInt8) (tree : ConcreteParseTree) : Prop :=
  let Y := (decodeAsciiBytes rawBytes).toList
  StrictAsciiDomainSupported rawBytes ∧
  tree.span = ⟨0, Y.length⟩ ∧
  ∃ sum : ParseSummary, ValidParseNode cat numCfg env Y .clause1 .controlledDocument tree sum

/-! ### 5. Yield Identity Theorem for `ValidParse_GFrozen` -/

mutual
  theorem validParseSegs_spanMatches
      {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {syms : List BNFSymbol}
      (args : List ConcreteParseArg)
      {slots : List (BNFSlotTag × String)} {sums : List ParseSummary}
      (h : ValidParseSegs cat numCfg env Y loc cursor syms args endPos slots sums) :
      SpanMatches Y ⟨cursor, endPos⟩ (reconstructParseSegChars args) := by
    match syms, args with
    | [], [] =>
      rcases h with ⟨hle, rfl, _, _⟩
      simpa [reconstructParseSegChars] using spanMatches_empty hle
    | .term _ :: _, .litTok txt sp :: restArgs =>
      rcases h with ⟨_, hstart, hspan, hrest⟩
      have hih := validParseSegs_spanMatches restArgs hrest
      rcases sp with ⟨sCp, eCp⟩
      dsimp at hstart
      subst hstart
      simpa [reconstructParseSegChars] using spanMatches_concat hspan hih
    | .lexSlot _ _ :: _, .slotTok _ _ _ lex sp :: restArgs =>
      rcases h with ⟨_, _, _, hstart, hspan, _, _, hrest⟩
      have hih := validParseSegs_spanMatches restArgs hrest
      rcases sp with ⟨sCp, eCp⟩
      dsimp at hstart
      subst hstart
      simpa [reconstructParseSegChars] using spanMatches_concat hspan hih
    | .nonterm _ _ :: _, .childSub sub :: restArgs =>
      rcases h with ⟨_, _, hstart, hsub, _, hrest⟩
      have hsub_sp := validParseNode_spanMatches sub hsub
      have hih := validParseSegs_spanMatches restArgs hrest
      cases sub with
      | mkTree p a l sp sargs =>
        rcases sp with ⟨sCp, eCp⟩
        dsimp [ConcreteParseTree.span] at hstart hsub_sp hrest hih
        subst hstart
        simpa [reconstructParseSegChars] using spanMatches_concat hsub_sp hih
    | [], _ :: _ => exact False.elim h
    | .term _ :: _, [] => exact False.elim h
    | .lexSlot _ _ :: _, [] => exact False.elim h
    | .nonterm _ _ :: _, [] => exact False.elim h
    | .term _ :: _, .slotTok _ _ _ _ _ :: _ => exact False.elim h
    | .term _ :: _, .childSub _ :: _ => exact False.elim h
    | .lexSlot _ _ :: _, .litTok _ _ :: _ => exact False.elim h
    | .lexSlot _ _ :: _, .childSub _ :: _ => exact False.elim h
    | .nonterm _ _ :: _, .litTok _ _ :: _ => exact False.elim h
    | .nonterm _ _ :: _, .slotTok _ _ _ _ _ :: _ => exact False.elim h

  theorem validParseNode_spanMatches
      {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {nt : BNFNonterm}
      (tree : ConcreteParseTree) {sum : ParseSummary}
      (h : ValidParseNode cat numCfg env Y loc nt tree sum) :
      SpanMatches Y tree.span (reconstructParseChars tree) := by
    cases tree with
    | mkTree p alt l sp args =>
      rcases h with ⟨slots, sums, _, _, _, _, hsegs, _, _⟩
      simpa [reconstructParseChars, ConcreteParseTree.span] using
        validParseSegs_spanMatches args hsegs
end

theorem validParse_GFrozen_yield_eq
    {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {env : ScopeEnv} {rawBytes : List UInt8} {tree : ConcreteParseTree}
    (h : ValidParse_GFrozen cat numCfg env rawBytes tree) :
    reconstructParseYield tree = decodeAsciiBytes rawBytes := by
  rcases h with ⟨_, hroot_sp, sum, hnode⟩
  have hm := validParseNode_spanMatches tree hnode
  rw [hroot_sp] at hm
  have hchars := spanMatches_full_eq hm
  unfold reconstructParseYield
  rw [hchars, String.ofList_toList]

end BrocaOmega.P3B
````

### File 5: `01_formal_spec/P3BFormalSpec/FullGrammarCorrespondence.lean` (SHA-256: `AAAF8848771BF2A1E2D28D361BA51F911B81A70E98A14DBA53A6E5707C6B7557`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`F-P3A-01`: Full Grammar, Side-Condition & Obligation Correspondence)
  01_formal_spec/P3BFormalSpec/FullGrammarCorrespondence.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2FormalSpec` & `P3FormalSpec`)

  Resolves `F-P3A-01` directly on the ACTUAL frozen `BrocaOmega.P2.ruleSignature` and
  `BrocaOmega.P3A.independentFrozenBNF` definitions (zero intermediate snapshot copies!):
    1. Exact bijective correspondence between `P2.FrozenGenRule` (`27` constructors) and the `27`
       generator productions of `FrozenParseProd`, while all `7` trap productions map to `none`.
    2. Exact interleaved `(lhs, rhs)` sequence equality (terminals, typed slots, AND child nonterminals
       with `ClauseLocus` overrides in exact order) across `P2.ruleSignature`, `P3A.independentFrozenBNF`,
       and `P3B.frozenProdSig`.
    3. Universally quantified side-condition equality (`checkSide == P2.checkSideCond`) for ALL
       `env`, `slots`, and `sums`.
    4. Universally quantified intrinsic-obligation equality (`intrinsicObls == P2.intrinsicObls`)
       for ALL `loc`, `slots`, and `sums`, plus `NodeSummary` homomorphism!
-/
import P3BFormalSpec.DeclarativeParseSpec

namespace BrocaOmega.P3B

open BrocaOmega.P2
open BrocaOmega.P3A

/-! ### 1. Exact Bijections Across `P2` ↔ `P3-A` ↔ `P3-B` Types -/

def fromP2Rule : FrozenGenRule → FrozenParseProd
  | .DocSingle              => .Env_DocSingle
  | .ScopedInitial          => .Env_ScopedInitial
  | .ScopedRepeatDiscourse  => .Env_ScopedRepeat
  | .ScopedAssoc            => .Env_ScopedAssoc
  | .ScopedContrastMeta     => .Env_ScopedContrastMeta
  | .LiftAssocToAtomic      => .Env_LiftAssoc
  | .LiftMetaToAtomic       => .Env_LiftMeta
  | .EmbeddedCausal         => .Env_EmbeddedCausal
  | .G01_DescIncidence      => .Gen_G01_DescIncidence
  | .G02a_DescMeanSD        => .Gen_G02a_DescMeanSD
  | .G02b_DescMedianIQR     => .Gen_G02b_DescMedianIQR
  | .G03_AssocUnadj         => .Gen_G03_AssocUnadj
  | .G04_AssocTemp          => .Gen_G04_AssocTemp
  | .G05_CompRD             => .Gen_G05_CompRD
  | .G06a_IntervDirectional => .Gen_G06a_IntervDirectional
  | .G06b_IntervNeutral     => .Gen_G06b_IntervNeutral
  | .G07_MetaNotStatSig     => .Gen_G07_MetaNotStatSig
  | .G08_MetaEquiv          => .Gen_G08_MetaEquiv
  | .G09_MetaNonEstab       => .Gen_G09_MetaNonEstab
  | .G10_MetaUnresolved     => .Gen_G10_MetaUnresolved
  | .G11_QuantZero          => .Gen_G11_QuantZero
  | .G12_QuantProperPart    => .Gen_G12_QuantProperPart
  | .G13_QuantAtLeastOne    => .Gen_G13_QuantAtLeastOne
  | .G14_AssocAdj           => .Gen_G14_AssocAdj
  | .G15_DocConjAtomic      => .Gen_G15a_DocConjAtomic
  | .G15_DocConjDiscourse   => .Gen_G15b_DocConjDiscourse
  | .G16_DocContrastive     => .Gen_G16_DocContrastive

def toP2Rule? : FrozenParseProd → Option FrozenGenRule
  | .Env_DocSingle             => some .DocSingle
  | .Env_ScopedInitial         => some .ScopedInitial
  | .Env_ScopedRepeat          => some .ScopedRepeatDiscourse
  | .Env_ScopedAssoc           => some .ScopedAssoc
  | .Env_ScopedContrastMeta    => some .ScopedContrastMeta
  | .Env_LiftAssoc             => some .LiftAssocToAtomic
  | .Env_LiftMeta              => some .LiftMetaToAtomic
  | .Env_EmbeddedCausal        => some .EmbeddedCausal
  | .Gen_G01_DescIncidence     => some .G01_DescIncidence
  | .Gen_G02a_DescMeanSD       => some .G02a_DescMeanSD
  | .Gen_G02b_DescMedianIQR    => some .G02b_DescMedianIQR
  | .Gen_G03_AssocUnadj        => some .G03_AssocUnadj
  | .Gen_G04_AssocTemp         => some .G04_AssocTemp
  | .Gen_G05_CompRD            => some .G05_CompRD
  | .Gen_G06a_IntervDirectional => some .G06a_IntervDirectional
  | .Gen_G06b_IntervNeutral    => some .G06b_IntervNeutral
  | .Gen_G07_MetaNotStatSig    => some .G07_MetaNotStatSig
  | .Gen_G08_MetaEquiv         => some .G08_MetaEquiv
  | .Gen_G09_MetaNonEstab      => some .G09_MetaNonEstab
  | .Gen_G10_MetaUnresolved    => some .G10_MetaUnresolved
  | .Gen_G11_QuantZero         => some .G11_QuantZero
  | .Gen_G12_QuantProperPart   => some .G12_QuantProperPart
  | .Gen_G13_QuantAtLeastOne   => some .G13_QuantAtLeastOne
  | .Gen_G14_AssocAdj          => some .G14_AssocAdj
  | .Gen_G15a_DocConjAtomic    => some .G15_DocConjAtomic
  | .Gen_G15b_DocConjDiscourse => some .G15_DocConjDiscourse
  | .Gen_G16_DocContrastive    => some .G16_DocContrastive
  | _                          => none

theorem toP2Rule_fromP2Rule (r : FrozenGenRule) :
    toP2Rule? (fromP2Rule r) = some r := by
  cases r <;> rfl

theorem toP2Rule_isSome_iff_isGenerator (p : FrozenParseProd) :
    (toP2Rule? p).isSome = (frozenProdSig p).isGenerator := by
  cases p <;> rfl

def fromP2Nonterm : NontermCat → BNFNonterm
  | .embeddedCausal     => .embeddedCausal
  | .assocCore          => .assocCore
  | .metaNonEstabCore   => .metaNonEstabCore
  | .atomicCore         => .atomicCore
  | .scopedInitial      => .scopedInitial
  | .scopedRepeat       => .scopedRepeat
  | .scopedAssoc        => .scopedAssoc
  | .scopedContrastMeta => .scopedContrastMeta
  | .documentRoot       => .controlledDocument

def fromP2SlotSort : SlotSort → P3SlotSort
  | .cohortSpec       => .cohortSpec
  | .designNoun       => .designNoun
  | .followUpWindow   => .followUpWindow
  | .eventTerm        => .eventTerm
  | .measureTerm      => .measureTerm
  | .expLevel         => .expLevel
  | .outTerm          => .outTerm
  | .sourceId         => .sourceId
  | .identAssump      => .identAssump
  | .subgroupPlural   => .subgroupPlural
  | .subgroupSingular => .subgroupSingular
  | .covariateList    => .covariateList
  | .assocDir         => .assocDir
  | .ratioMetric      => .ratioMetric
  | .intervDirVerb    => .intervDirVerb
  | .intervVerbPres   => .intervVerbPres
  | .numericLit       => .numericLit

def toP2SlotSort? : P3SlotSort → Option SlotSort
  | .cohortSpec       => some .cohortSpec
  | .designNoun       => some .designNoun
  | .followUpWindow   => some .followUpWindow
  | .eventTerm        => some .eventTerm
  | .measureTerm      => some .measureTerm
  | .expLevel         => some .expLevel
  | .outTerm          => some .outTerm
  | .sourceId         => some .sourceId
  | .identAssump      => some .identAssump
  | .subgroupPlural   => some .subgroupPlural
  | .subgroupSingular => some .subgroupSingular
  | .covariateList    => some .covariateList
  | .assocDir         => some .assocDir
  | .ratioMetric      => some .ratioMetric
  | .intervDirVerb    => some .intervDirVerb
  | .intervVerbPres   => some .intervVerbPres
  | .numericLit       => some .numericLit
  | .epistemicVerb    => none
  | .whWord           => none

theorem toP2SlotSort_fromP2SlotSort (s : SlotSort) :
    toP2SlotSort? (fromP2SlotSort s) = some s := by
  cases s <;> rfl

def fromP2SlotRole : SlotRole → BNFSlotTag
  | .cohort        => .cohort
  | .design        => .design
  | .window        => .window
  | .eventA        => .eventA
  | .eventB        => .eventB
  | .measure       => .measure
  | .activeExp     => .activeExp
  | .refExp        => .refExp
  | .outcome       => .outcome
  | .source        => .source
  | .assumption    => .assumption
  | .subgroup      => .subgroup
  | .covariates    => .covariates
  | .direction     => .direction
  | .metric1       => .metric1
  | .metric2       => .metric2
  | .verb          => .verb
  | .numK          => .numK
  | .numN          => .numN
  | .numPct        => .numPct
  | .numEst        => .numEst
  | .numDisp1      => .numDisp1
  | .numDisp2      => .numDisp2
  | .numCILevel    => .numCILevel
  | .numCILow      => .numCILow
  | .numCIHigh     => .numCIHigh
  | .numPVal       => .numPVal
  | .numAlpha      => .numAlpha
  | .numMarginLow  => .numMarginLow
  | .numMarginHigh => .numMarginHigh

def toP2SlotRole? : BNFSlotTag → Option SlotRole
  | .cohort        => some .cohort
  | .design        => some .design
  | .window        => some .window
  | .eventA        => some .eventA
  | .eventB        => some .eventB
  | .measure       => some .measure
  | .activeExp     => some .activeExp
  | .refExp        => some .refExp
  | .outcome       => some .outcome
  | .source        => some .source
  | .assumption    => some .assumption
  | .subgroup      => some .subgroup
  | .covariates    => some .covariates
  | .direction     => some .direction
  | .metric1       => some .metric1
  | .metric2       => some .metric2
  | .verb          => some .verb
  | .numK          => some .numK
  | .numN          => some .numN
  | .numPct        => some .numPct
  | .numEst        => some .numEst
  | .numDisp1      => some .numDisp1
  | .numDisp2      => some .numDisp2
  | .numCILevel    => some .numCILevel
  | .numCILow      => some .numCILow
  | .numCIHigh     => some .numCIHigh
  | .numPVal       => some .numPVal
  | .numAlpha      => some .numAlpha
  | .numMarginLow  => some .numMarginLow
  | .numMarginHigh => some .numMarginHigh
  | .whComp        => none

theorem fromP2SlotRole_injective {r1 r2 : SlotRole}
    (h : fromP2SlotRole r1 = fromP2SlotRole r2) : r1 = r2 := by
  cases r1 <;> cases r2 <;> first | rfl | contradiction

def fromP2LocusOpt : Option ClauseLocus → Nat
  | none          => 0
  | some .clause1 => 1
  | some .clause2 => 2

theorem clauseOverrideOfIdx_fromP2LocusOpt (locOpt : Option ClauseLocus) :
    clauseOverrideOfIdx (fromP2LocusOpt locOpt) = locOpt := by
  cases locOpt with
  | none => rfl
  | some l => cases l <;> rfl

def fromP2RuleSegment : RuleSegment → BNFSymbol
  | .lit txt         => .term txt
  | .slot srt rl     => .lexSlot (fromP2SlotSort srt) (fromP2SlotRole rl)
  | .child cat locOp => .nonterm (fromP2Nonterm cat) (fromP2LocusOpt locOp)

def mapP2Slots (slots : List (SlotRole × String)) : List (BNFSlotTag × String) :=
  slots.map (fun p => (fromP2SlotRole p.1, p.2))

def mapP2Summary (s : NodeSummary) : ParseSummary :=
  { cohortId      := s.cohortIdOpt
    designId      := s.designIdOpt
    expOutPair    := s.expOutPairOpt
    embeddedKey   := s.embeddedKey
    startsWithInOrWithin := s.cohortIdOpt.isSome || s.designIdOpt.isSome }

/-! ### 2. `F-P3A-01` Theorem 1: Exact Interleaved `(lhs, rhs)` Correspondence Across `P2`, `P3-A`, and `P3-B` -/

/--
  Proves directly on `BrocaOmega.P2.ruleSignature` that for EVERY `r : FrozenGenRule`,
  the translated LHS nonterminal and FULL INTERLEAVED RHS sequence (`.lit`, `.slot`, `.child`)
  equal `P3B`'s `frozenProdSig (fromP2Rule r)`!
-/
theorem f_p3a_01_p2_ruleSignature_matches_p3b_interleaved (r : FrozenGenRule) :
    fromP2Nonterm (ruleSignature r).lhsCat = (frozenProdSig (fromP2Rule r)).lhs ∧
    ((ruleSignature r).segments.map fromP2RuleSegment) = (frozenProdSig (fromP2Rule r)).rhs := by
  cases r <;> decide

/--
  Proves that ALL 34 productions in `P3B.allFrozenParseProds` match `P3A.independentFrozenBNF`
  1-to-1 in exact `(ownerRule, isGenerator, lhs, rhs)` order!
-/
theorem f_p3a_01_p3b_matches_p3a_independentFrozenBNF :
    (allFrozenParseProds.map fun p =>
      let sig := frozenProdSig p
      (sig.ownerRule, sig.isGenerator, sig.lhs, sig.rhs)) =
    (independentFrozenBNF.map fun b =>
      (b.canonicalOwner, b.isGenerator, b.lhs, b.rhs)) := by
  decide

/-! ### 3. `F-P3A-01` Theorem 2: Universal Side-Condition, Intrinsic-Obligation & Summary Equivalence -/

theorem lookupTagVal_mapP2Slots (slots : List (SlotRole × String)) (rl : SlotRole) :
    lookupTagVal (mapP2Slots slots) (fromP2SlotRole rl) = lookupRoleVal slots rl := by
  induction slots with
  | nil => rfl
  | cons hd tl ih =>
    unfold mapP2Slots lookupTagVal lookupRoleVal
    simp only [List.map_cons, List.find?_cons]
    by_cases h : hd.1 = rl
    · have htag : (fromP2SlotRole hd.1 == fromP2SlotRole rl) = true := by simp [h]
      have hrl  : (hd.1 == rl) = true := by simp [h]
      rw [htag, hrl]
    · have htag : (fromP2SlotRole hd.1 == fromP2SlotRole rl) = false :=
        beq_eq_false_iff_ne.mpr (fun heq => h (fromP2SlotRole_injective heq))
      have hrl  : (hd.1 == rl) = false := beq_eq_false_iff_ne.mpr h
      rw [htag, hrl]
      exact ih

theorem fromP2_of_toP2 {tag : BNFSlotTag} {rl : SlotRole}
    (h : toP2SlotRole? tag = some rl) : fromP2SlotRole rl = tag := by
  cases tag <;> simp [toP2SlotRole?] at h <;> subst rl <;> rfl

theorem toP2_none_eq_whComp {tag : BNFSlotTag}
    (h : toP2SlotRole? tag = none) : tag = .whComp := by
  cases tag <;> simp [toP2SlotRole?] at h <;> rfl

@[simp]
theorem lookupTagVal_mapP2Slots_all (slots : List (SlotRole × String)) (tag : BNFSlotTag) :
    lookupTagVal (mapP2Slots slots) tag =
      match toP2SlotRole? tag with
      | some rl => lookupRoleVal slots rl
      | none    => "" := by
  cases h : toP2SlotRole? tag with
  | some rl =>
    rw [← fromP2_of_toP2 h]
    exact lookupTagVal_mapP2Slots slots rl
  | none =>
    rw [toP2_none_eq_whComp h]
    induction slots with
    | nil => rfl
    | cons hd tl ih =>
      unfold mapP2Slots lookupTagVal
      simp only [List.map_cons, List.find?_cons]
      have hne : (fromP2SlotRole hd.1 == .whComp) = false := by cases hd.1 <;> rfl
      rw [hne]
      exact ih

/--
  **`F-P3A-01` Side-Condition Semantic Equivalence**:
  For ALL `27` generator rules `r`, ALL `ScopeEnv`, ALL `slots`, and ALL child `NodeSummary` lists,
  `P3B`'s independent `checkSide` evaluates identically to `P2.ruleSignature.checkSideCond`!
-/
theorem f_p3a_01_universal_sidecond_equivalence
    (r : FrozenGenRule) (env : ScopeEnv)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).checkSide env (mapP2Slots slots) (sums.map mapP2Summary) =
    (ruleSignature r).checkSideCond env slots sums := by
  cases r <;> dsimp [fromP2Rule, frozenProdSig, ruleSignature]
  all_goals
    cases sums with
    | nil => simp [toP2SlotRole?]
    | cons c1 rest1 =>
      cases rest1 with
      | nil => simp [toP2SlotRole?]
      | cons c2 rest2 =>
        cases rest2 <;> simp [mapP2Summary, toP2SlotRole?]

/--
  **`F-P3A-01` Intrinsic-Obligation Semantic Equivalence**:
  For ALL `27` generator rules `r`, ALL `ClauseLocus`, ALL `slots`, and ALL child `NodeSummary` lists,
  `P3B`'s independent `intrinsicObls` produces the EXACT same `List ObligationSpec` as `P2.ruleSignature`!
-/
theorem f_p3a_01_universal_intrinsicObls_equivalence
    (r : FrozenGenRule) (loc : ClauseLocus)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).intrinsicObls loc (mapP2Slots slots) (sums.map mapP2Summary) =
    (ruleSignature r).intrinsicObls loc slots sums := by
  cases r <;> dsimp [fromP2Rule, frozenProdSig, ruleSignature]
  all_goals
    cases sums with
    | nil => simp [toP2SlotRole?]
    | cons c1 rest1 =>
      cases rest1 with
      | nil => simp [mapP2Summary, toP2SlotRole?]
      | cons c2 rest2 =>
        cases rest2 with
        | nil => rcases c1 with ⟨_, _, _ | ⟨eId, oId⟩, _⟩ <;> simp [mapP2Summary, toP2SlotRole?]
        | cons c3 rest3 => simp [mapP2Summary, toP2SlotRole?]

/--
  **Summary Homomorphism (`mkSum` Projection Consistency)**:
  For all `27` generator rules, `P3B`'s `mkSum` agrees with `mapP2Summary ∘ P2.mkSummary` on all
  semantic fields (`cohortId`, `designId`, `expOutPair`, `embeddedKey`).
-/
theorem f_p3a_01_universal_summary_equivalence
    (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    let s3 := (frozenProdSig (fromP2Rule r)).mkSum (mapP2Slots slots) (sums.map mapP2Summary)
    let s2 := mapP2Summary ((ruleSignature r).mkSummary slots sums)
    s3.cohortId = s2.cohortId ∧
    s3.designId = s2.designId ∧
    s3.expOutPair = s2.expOutPair ∧
    s3.embeddedKey = s2.embeddedKey := by
  cases r <;> dsimp [fromP2Rule, frozenProdSig, ruleSignature, mapP2Summary]
  all_goals
    cases sums with
    | nil => simp [toP2SlotRole?]
    | cons c1 rest1 =>
      cases rest1 <;> simp [mapP2Summary, toP2SlotRole?]

end BrocaOmega.P3B
````

### File 6: `02_detached_checker/P3BDetachedChecker.lean` (SHA-256: `18434566A21C37331F2375995E5B82EA4DD4D47AD4F7FC7D1F09A9E7A13218CE`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` & `BridgeSound`)
  02_detached_checker/P3BDetachedChecker.lean
-/
import P3BDetachedChecker.BoundedParser
import P3BDetachedChecker.LexicalReplayBridge
````

### File 7: `02_detached_checker/P3BDetachedChecker/BoundedParser.lean` (SHA-256: `1E5668016B5B74CA27A036D833DC106C9A4AF720CE978138683139591051D391`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01`: Bounded Exhaustive Parser Soundness & Completeness)
  02_detached_checker/P3BDetachedChecker/BoundedParser.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  Gate B & Gate C Deliverable:
  1. Formal `ResourceBudget` (`maxBytes`, `maxSteps`, `maxForestNodes`, `maxReadings`) as part of
     the explicit parser contract.
  2. Strict 3-way `BoundedParseResult`:
       - `enumerated (trees)`       : Exhaustive parse enumeration completed within budget
       - `outOfDomain (diag)`       : Raw bytes outside 7-bit printable ASCII domain (`≠ ¬ValidParse`)
       - `resourceOverflow (reason)`: Formal budget exceeded (`fail-closed`, partial trees discarded)
  3. Duplicate-free deterministic enumeration (`NoDupTrees`) preserving `T2`'s two semantic readings
     (`readingAlt = 1` vs `readingAlt = 2`) and `T1` / `T4` dual readings without adding rule IDs.
  4. Machine-checked `PO-C1-01` Soundness, Bounded Exhaustive Completeness, `OutOfDomain` boundary
     soundness, and `ResourceOverflow` fail-closed separation.
-/
import P3BFormalSpec
import P3DetachedChecker

namespace BrocaOmega.P3B

open BrocaOmega.P2
open BrocaOmega.P3A

/-! ### 1. Formal Resource Budget & 3-Way Bounded Parse Result (`Gate B`) -/

/--
  Formal resource budget governing `parseAllBounded`.
  Every dimension is actively metered and enforced fail-closed during parsing.
-/
structure ResourceBudget where
  maxBytes       : Nat
  maxSteps       : Nat
  maxForestNodes : Nat
  maxReadings    : Nat
  deriving DecidableEq, Repr

/-- Standard reference budget for single- and two-clause controlled clinical sentences (`≤ 512` bytes). -/
def defaultParseBudget : ResourceBudget :=
  { maxBytes       := 512
    maxSteps       := 4000
    maxForestNodes := 512
    maxReadings    := 16 }

/-- Domain-boundary rejection diagnostic (`rawBytes` outside supported 7-bit printable ASCII profile). -/
inductive OutOfDomainDiag where
  | emptyInput
  | nonPrintableAsciiByte (byteVal : UInt8)
  deriving DecidableEq, Repr

/-- Resource-budget exhaustion reason (strictly distinct from grammatical non-derivability!). -/
inductive OverflowReason where
  | maxBytesExceeded       (actual maxBytes : Nat)
  | maxStepsExceeded       (maxSteps : Nat)
  | maxForestNodesExceeded (maxForestNodes : Nat)
  | maxReadingsExceeded    (actual maxReadings : Nat)
  deriving DecidableEq, Repr

/--
  Strict 3-state outcome of `parseAllBounded`:
  - `enumerated T`       : `T` is the sound, complete, duplicate-free set of all `ValidParse_GFrozen` trees
                           (`T = []` iff input is in-domain and has zero valid parses).
  - `outOfDomain d`      : `¬ StrictAsciiDomainSupported rawBytes` (makes no claim on `G_parse` outside domain).
  - `resourceOverflow b` : Budget `b` exhausted; partial trees discarded fail-closed.
-/
inductive BoundedParseResult where
  | enumerated       (trees : List ConcreteParseTree)
  | outOfDomain      (diag : OutOfDomainDiag)
  | resourceOverflow (reason : OverflowReason)
  deriving DecidableEq

/-! ### 2. Generic List, Range, and Duplicate-Free Forest Helpers -/

def flatMapList {α β : Type} : List α → (α → List β) → List β
  | [], _ => []
  | x :: xs, f => f x ++ flatMapList xs f

theorem mem_flatMapList_iff {α β : Type} (xs : List α) (f : α → List β) (b : β) :
    b ∈ flatMapList xs f ↔ ∃ a ∈ xs, b ∈ f a := by
  induction xs with
  | nil => simp [flatMapList]
  | cons x rest ih => simp [flatMapList, ih]

def rangeClosed (lo hi : Nat) : List Nat :=
  if hi < lo then []
  else (List.range (hi - lo + 1)).map (fun i => lo + i)

theorem mem_rangeClosed_iff (lo hi m : Nat) :
    m ∈ rangeClosed lo hi ↔ lo ≤ m ∧ m ≤ hi := by
  unfold rangeClosed
  by_cases hlt : hi < lo
  · rw [if_pos hlt]
    simp
    omega
  · rw [if_neg hlt]
    simp only [List.mem_map, List.mem_range]
    constructor
    · rintro ⟨i, _, rfl⟩
      omega
    · rintro ⟨hlo, hhi⟩
      exact ⟨m - lo, by omega, by omega⟩

/-- Duplicate-freeness predicate over `List ConcreteParseTree`. -/
def NoDupTrees : List ConcreteParseTree → Prop
  | [] => True
  | t :: ts => t ∉ ts ∧ NoDupTrees ts

/-- Deterministic order-preserving deduplication (`[alt=1, alt=2]` order preserved). -/
def dedupTrees : List ConcreteParseTree → List ConcreteParseTree
  | [] => []
  | t :: ts => t :: (dedupTrees ts).filter (fun x => !parseTreeEqBool x t)

theorem mem_dedupTrees_iff (xs : List ConcreteParseTree) (x : ConcreteParseTree) :
    x ∈ dedupTrees xs ↔ x ∈ xs := by
  induction xs with
  | nil => rfl
  | cons t ts ih =>
    unfold dedupTrees
    simp only [List.mem_cons, List.mem_filter]
    by_cases hxt : x = t
    · subst x
      simp
    · have hneq : (!parseTreeEqBool x t) = true := by
        cases hb : parseTreeEqBool x t
        · rfl
        · exfalso; exact hxt ((parseTreeEqBool_iff x t).mp hb)
      simp [hxt, hneq, ih]

private theorem noDupTrees_filter (p : ConcreteParseTree → Bool) (xs : List ConcreteParseTree)
    (h : NoDupTrees xs) : NoDupTrees (xs.filter p) := by
  induction xs with
  | nil => trivial
  | cons x ts ih =>
    rcases h with ⟨hx_not, hts⟩
    unfold List.filter
    cases hp : p x
    · exact ih hts
    · refine ⟨?_, ih hts⟩
      intro hmem
      exact hx_not (List.mem_filter.mp hmem).1

theorem dedupTrees_nodup (xs : List ConcreteParseTree) : NoDupTrees (dedupTrees xs) := by
  induction xs with
  | nil => trivial
  | cons t ts ih =>
    unfold dedupTrees
    refine ⟨?_, noDupTrees_filter _ _ ih⟩
    intro hmem
    have hf := (List.mem_filter.mp hmem).2
    have hrefl : parseTreeEqBool t t = true := (parseTreeEqBool_iff t t).mpr rfl
    rw [hrefl] at hf
    contradiction

/-! ### 3. Domain Check, Slot Enumeration & Split-Point Lookahead Equivalence -/

def checkAsciiDomainOnly (rawBytes : List UInt8) : Except OutOfDomainDiag Unit :=
  if rawBytes.isEmpty then
    .error .emptyInput
  else
    match findBadAsciiByte rawBytes with
    | some bad => .error (.nonPrintableAsciiByte bad)
    | none     => .ok ()

theorem checkAsciiDomainOnly_ok_iff (rawBytes : List UInt8) :
    checkAsciiDomainOnly rawBytes = .ok () ↔ StrictAsciiDomainSupported rawBytes := by
  unfold checkAsciiDomainOnly StrictAsciiDomainSupported
  cases rawBytes with
  | nil => simp
  | cons b bs =>
    have hne : (b :: bs).isEmpty = false := rfl
    rw [if_neg (by simp [hne])]
    cases hbad : findBadAsciiByte (b :: bs) with
    | some bad =>
      constructor
      · intro h; contradiction
      · rintro ⟨_, hall⟩
        have hnone := (findBadAsciiByte_eq_none_iff (b :: bs)).mpr hall
        rw [hbad] at hnone
        contradiction
    | none =>
      have hall := (findBadAsciiByte_eq_none_iff (b :: bs)).mp hbad
      exact ⟨fun _ => ⟨by simp, hall⟩, fun _ => rfl⟩

theorem checkAsciiDomainOnly_err_sound (rawBytes : List UInt8) (d : OutOfDomainDiag)
    (herr : checkAsciiDomainOnly rawBytes = .error d) :
    ¬ StrictAsciiDomainSupported rawBytes := by
  intro hsup
  have hok := (checkAsciiDomainOnly_ok_iff rawBytes).mpr hsup
  rw [herr] at hok
  contradiction

def eqCharsBool : List Char → List Char → Bool
  | [], [] => true
  | c1 :: r1, c2 :: r2 => (c1.val == c2.val) && eqCharsBool r1 r2
  | _, _ => false

theorem eqCharsBool_iff (xs ys : List Char) :
    eqCharsBool xs ys = true ↔ xs = ys := by
  induction xs generalizing ys with
  | nil =>
    cases ys <;> simp [eqCharsBool]
  | cons x rx ih =>
    cases ys with
    | nil => simp [eqCharsBool]
    | cons y ry =>
      unfold eqCharsBool
      rw [Bool.and_eq_true, beq_iff_eq, ← Char.ext_iff, ih]
      simp

def eqStrBool (s1 s2 : String) : Bool :=
  eqCharsBool s1.toList s2.toList

theorem eqStrBool_iff (s1 s2 : String) :
    eqStrBool s1 s2 = true ↔ s1 = s2 := by
  unfold eqStrBool
  rw [eqCharsBool_iff, String.ext_iff]

def fastSpanMatchesBool (Y : List Char) (sp : CodepointSpan) (seg : List Char) : Bool :=
  (sp.endCp == sp.startCp + seg.length) &&
  (sp.endCp ≤ Y.length) &&
  eqCharsBool ((Y.drop sp.startCp).take seg.length) seg

theorem fastSpanMatchesBool_iff (Y : List Char) (sp : CodepointSpan) (seg : List Char) :
    fastSpanMatchesBool Y sp seg = true ↔ SpanMatches Y sp seg := by
  have h1 : fastSpanMatchesBool Y sp seg = true ↔ checkSpanMatchesBool Y sp seg = true := by
    unfold fastSpanMatchesBool checkSpanMatchesBool
    simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq, eqCharsBool_iff]
  rw [h1]
  exact ⟨checkSpanMatchesBool_sound, spanMatches_implies_checkBool⟩

/-- Finite candidate entity IDs for `(srt, lex)` determined by the 3 closed lexical regimes of `P3-A`. -/
def candidateSlotEntityIds (cat : ClosedEntityCatalog) (srt : P3SlotSort) (lex : String) : List String :=
  match srt.regime with
  | .openEntityCatalog =>
    (cat.entries.filter (fun e => (e.sort == srt) && eqStrBool e.lexeme lex)).map (·.entityId)
  | .closedFunctionalEnum =>
    (closedFunctionalEntries.filter (fun p => (p.1 == srt) && eqStrBool p.2.2 lex)).map (fun p => p.2.1)
  | .canonicalDecimal =>
    [lex]

/-- Executable slot validator delegating directly to `BrocaOmega.P3A.evalLexicalSlot`. -/
def checkSlotValidBool (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (eid lex : String) : Bool :=
  let cand : RawSlotCandidate := { sort := srt, entityId := eid, rawBytes := strToAsciiBytes lex }
  eqStrBool cand.decodedStr lex &&
  match evalLexicalSlot cat numCfg maxSlotBytes cand with
  | .ok _    => true
  | .error _ => false

theorem checkSlotValidBool_iff (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (eid lex : String) :
    checkSlotValidBool cat numCfg maxSlotBytes srt eid lex = true ↔
      DeclarativeSlotValid cat numCfg maxSlotBytes srt eid lex := by
  unfold checkSlotValidBool DeclarativeSlotValid
  dsimp only
  rw [Bool.and_eq_true, eqStrBool_iff]
  let cand : RawSlotCandidate := { sort := srt, entityId := eid, rawBytes := strToAsciiBytes lex }
  constructor
  · rintro ⟨hdec, hok_b⟩
    cases hev : evalLexicalSlot cat numCfg maxSlotBytes cand with
    | error e => rw [hev] at hok_b; contradiction
    | ok payload =>
      have hs := evalLexicalSlot_sound cat numCfg maxSlotBytes cand payload hev
      exact ⟨hdec, hs.2.1, hs.2.2.1, hs.2.2.2⟩
  · rintro ⟨hdec, hLex, hNum, hBound⟩
    rcases evalLexicalSlot_complete cat numCfg maxSlotBytes cand hLex hNum hBound with ⟨payload, hev⟩
    refine ⟨hdec, ?_⟩
    rw [hev]

def validSlotEntityIds (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (lex : String) : List String :=
  (candidateSlotEntityIds cat srt lex).filter (fun eid =>
    checkSlotValidBool cat numCfg maxSlotBytes srt eid lex)

theorem mem_validSlotEntityIds_iff (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (eid lex : String) :
    eid ∈ validSlotEntityIds cat numCfg maxSlotBytes srt lex ↔
      DeclarativeSlotValid cat numCfg maxSlotBytes srt eid lex := by
  unfold validSlotEntityIds
  rw [List.mem_filter, checkSlotValidBool_iff]
  constructor
  · exact And.right
  · intro hdsv
    refine ⟨?_, hdsv⟩
    rcases hdsv with ⟨hdec, _, hNum, hBound⟩
    unfold candidateSlotEntityIds EntityCatalogBound at *
    have hrefl_lex : eqStrBool lex lex = true := (eqStrBool_iff lex lex).mpr rfl
    cases hreg : srt.regime with
    | openEntityCatalog =>
      rw [hreg] at hBound
      dsimp at hBound ⊢
      rcases hBound with ⟨_, hmem⟩
      rw [hdec] at hmem
      rw [List.mem_map]
      refine ⟨⟨srt, eid, lex⟩, ?_, rfl⟩
      rw [List.mem_filter]
      exact ⟨hmem, by simp [hrefl_lex]⟩
    | closedFunctionalEnum =>
      rw [hreg] at hBound
      dsimp at hBound ⊢
      rw [hdec] at hBound
      rw [List.mem_map]
      refine ⟨(srt, eid, lex), ?_, rfl⟩
      rw [List.mem_filter]
      exact ⟨hBound, by simp [hrefl_lex]⟩
    | canonicalDecimal =>
      dsimp
      have hsrt : srt = .numericLit := by
        cases hs : srt <;> simp [hs, P3SlotSort.regime] at hreg
        rfl
      rcases hNum hsrt with ⟨heid_eq, _⟩
      dsimp at heid_eq
      rw [hdec] at heid_eq
      simp [heid_eq]

/-- Span-monotonicity lemma (`cursor ≤ endPos ∧ endPos ≤ Y.length`) for any `ValidParseSegs`. -/
theorem validParseSegs_bounds
    {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
    {cursor endPos : Nat} {syms : List BNFSymbol}
    {args : List ConcreteParseArg} {slots : List (BNFSlotTag × String)} {sums : List ParseSummary}
    (h : ValidParseSegs cat numCfg env Y loc cursor syms args endPos slots sums) :
    cursor ≤ endPos ∧ endPos ≤ Y.length := by
  have hsp := validParseSegs_spanMatches args h
  rcases hsp with ⟨hend, pre, post, hy, hpre⟩
  dsimp at hend hpre
  have hlen : Y.length = pre.length + (reconstructParseSegChars args).length + post.length := by
    rw [hy, List.length_append, List.length_append]
  omega

/--
  Sound & Complete Split-Point Lookahead (`candidateSplitPositions`):
  - When `restSyms = []`, the split MUST equal `endPos`.
  - When `restSyms = .term lit :: _`, `Y` MUST match `lit` right at `mid` with `mid + |lit| ≤ endPos`.
  - Otherwise enumerates `rangeClosed cursor endPos`.
-/
def candidateSplitPositions (Y : List Char) (cursor endPos : Nat) (restSyms : List BNFSymbol) : List Nat :=
  match restSyms with
  | [] =>
    if cursor ≤ endPos then [endPos] else []
  | .term lit :: _ =>
    let lcs := lit.toList
    (rangeClosed cursor endPos).filter (fun mid =>
      (mid + lcs.length ≤ endPos) && eqCharsBool ((Y.drop mid).take lcs.length) lcs)
  | _ =>
    rangeClosed cursor endPos

theorem validParseSegs_mem_candidateSplitPositions
    {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
    {cursor mid endPos : Nat} {restSyms : List BNFSymbol}
    {restArgs : List ConcreteParseArg} {slots : List (BNFSlotTag × String)} {sums : List ParseSummary}
    (hcur : cursor ≤ mid)
    (hrest : ValidParseSegs cat numCfg env Y loc mid restSyms restArgs endPos slots sums) :
    mid ∈ candidateSplitPositions Y cursor endPos restSyms := by
  have ⟨hmid_end, _⟩ := validParseSegs_bounds hrest
  cases restSyms with
  | nil =>
    cases restArgs with
    | nil =>
      rcases hrest with ⟨_, hend_eq, _, _⟩
      subst endPos
      simp [candidateSplitPositions, hcur]
    | cons _ _ => exact False.elim hrest
  | cons sym tailSyms =>
    cases sym with
    | term lit =>
      cases restArgs with
      | nil => exact False.elim hrest
      | cons a tailArgs =>
        cases a with
        | litTok txt spLit =>
          rcases hrest with ⟨htxt, hstart, hsp, htail⟩
          subst txt
          have ⟨htail_le, _⟩ := validParseSegs_bounds htail
          have hchk := spanMatches_implies_checkBool hsp
          unfold checkSpanMatchesBool at hchk
          simp [Bool.and_eq_true] at hchk
          rcases hchk with ⟨⟨hsp_end, _⟩, htake⟩
          rw [hstart] at hsp_end htake
          have hlen_end : mid + lit.toList.length ≤ endPos := by omega
          unfold candidateSplitPositions
          rw [List.mem_filter, mem_rangeClosed_iff]
          refine ⟨⟨hcur, hmid_end⟩, ?_⟩
          have heq_b : eqCharsBool ((Y.drop mid).take lit.toList.length) lit.toList = true :=
            (eqCharsBool_iff _ _).mpr htake
          simp [hlen_end, heq_b]
        | slotTok _ _ _ _ _ => exact False.elim hrest
        | childSub _ => exact False.elim hrest
    | lexSlot _ _ =>
      unfold candidateSplitPositions
      exact (mem_rangeClosed_iff cursor endPos mid).mpr ⟨hcur, hmid_end⟩
    | nonterm _ _ =>
      unfold candidateSplitPositions
      exact (mem_rangeClosed_iff cursor endPos mid).mpr ⟨hcur, hmid_end⟩

/-! ### 4. Pure Level-Indexed Reference Enumerator & Exact Soundness + Completeness Proof -/

def enumSegsWith
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig) (Y : List Char)
    (childEnum : ClauseLocus → BNFNonterm → Nat → Nat → List (ConcreteParseTree × ParseSummary))
    (loc : ClauseLocus) (cursor : Nat) (syms : List BNFSymbol) (endPos : Nat) :
    List (List ConcreteParseArg × List (BNFSlotTag × String) × List ParseSummary) :=
  match syms with
  | [] =>
    if (cursor ≤ Y.length) && (endPos == cursor) then
      [([], [], [])]
    else
      []
  | .term lit :: restSyms =>
    let lcs := lit.toList
    let sp : CodepointSpan := ⟨cursor, cursor + lcs.length⟩
    if fastSpanMatchesBool Y sp lcs then
      (enumSegsWith cat numCfg Y childEnum loc sp.endCp restSyms endPos).map fun (rArgs, rSlots, rSums) =>
        (.litTok lit sp :: rArgs, rSlots, rSums)
    else
      []
  | .lexSlot srt tag :: restSyms =>
    if endPos ≤ Y.length then
      flatMapList (candidateSplitPositions Y cursor endPos restSyms) fun mid =>
        let sliceCs := (Y.drop cursor).take (mid - cursor)
        let lex := String.ofList sliceCs
        let sp : CodepointSpan := ⟨cursor, mid⟩
        if fastSpanMatchesBool Y sp lex.toList then
          let validEids := validSlotEntityIds cat numCfg Y.length srt lex
          let tails := enumSegsWith cat numCfg Y childEnum loc mid restSyms endPos
          flatMapList validEids fun eid =>
            tails.map fun (rArgs, rSlots, rSums) =>
              (.slotTok srt tag eid lex sp :: rArgs, (tag, eid) :: rSlots, rSums)
        else
          []
    else
      []
  | .nonterm childNt cIdx :: restSyms =>
    let childLoc := (clauseOverrideOfIdx cIdx).getD loc
    flatMapList (candidateSplitPositions Y cursor endPos restSyms) fun mid =>
      let children := childEnum childLoc childNt cursor mid
      let tails := enumSegsWith cat numCfg Y childEnum loc mid restSyms endPos
      flatMapList children fun (subTree, subSum) =>
        tails.map fun (rArgs, rSlots, rSums) =>
          (.childSub subTree :: rArgs, rSlots, subSum :: rSums)

def enumNodeRef : Nat → ClosedEntityCatalog → NumericGateConfig → ScopeEnv → List Char →
    ClauseLocus → BNFNonterm → Nat → Nat → List (ConcreteParseTree × ParseSummary)
  | 0, _, _, _, _, _, _, _, _ => []
  | fuel + 1, cat, numCfg, env, Y, expectedLoc, expectedNt, startPos, endPos =>
    flatMapList allFrozenParseProds fun p =>
      let sig := frozenProdSig p
      if sig.lhs == expectedNt then
        let segResults := enumSegsWith cat numCfg Y (enumNodeRef fuel cat numCfg env Y)
                            expectedLoc startPos sig.rhs endPos
        flatMapList segResults fun (args, slots, sums) =>
          if sig.checkSide env slots sums then
            let outSum := sig.mkSum slots sums
            (rangeClosed 1 p.altCount).map fun alt =>
              (ConcreteParseTree.mkTree p alt expectedLoc ⟨startPos, endPos⟩ args, outSum)
          else
            []
      else
        []

theorem mem_enumSegsWith_iff
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig) (env : ScopeEnv) (Y : List Char)
    (childEnum : ClauseLocus → BNFNonterm → Nat → Nat → List (ConcreteParseTree × ParseSummary))
    (syms : List BNFSymbol)
    (hChild : ∀ (cLoc : ClauseLocus) (cNt : BNFNonterm),
      (∃ cIdx, BNFSymbol.nonterm cNt cIdx ∈ syms) →
      ∀ (sPos ePos : Nat) (sub : ConcreteParseTree) (subSum : ParseSummary),
        (sub, subSum) ∈ childEnum cLoc cNt sPos ePos ↔
          (sub.span = ⟨sPos, ePos⟩ ∧ ValidParseNode cat numCfg env Y cLoc cNt sub subSum))
    (loc : ClauseLocus) (cursor endPos : Nat)
    (args : List ConcreteParseArg) (slots : List (BNFSlotTag × String)) (sums : List ParseSummary) :
    (args, slots, sums) ∈ enumSegsWith cat numCfg Y childEnum loc cursor syms endPos ↔
      ValidParseSegs cat numCfg env Y loc cursor syms args endPos slots sums := by
  induction syms generalizing cursor args slots sums with
  | nil =>
    unfold enumSegsWith ValidParseSegs
    cases args with
    | nil =>
      by_cases hcond : ((cursor ≤ Y.length) && (endPos == cursor)) = true
      · rw [if_pos hcond]
        simp [Bool.and_eq_true, beq_iff_eq] at hcond
        simp [hcond.1, hcond.2]
      · rw [if_neg hcond]
        simp [Bool.and_eq_true, beq_iff_eq] at hcond
        constructor
        · intro hm; simp at hm
        · rintro ⟨hle, hend, _, _⟩
          exact False.elim (hcond hle hend)
    | cons _ _ =>
      by_cases hcond : ((cursor ≤ Y.length) && (endPos == cursor)) = true
      · rw [if_pos hcond]; simp
      · rw [if_neg hcond]; simp
  | cons sym restSyms ih =>
    have hChildRest : ∀ (cLoc : ClauseLocus) (cNt : BNFNonterm),
        (∃ cIdx, BNFSymbol.nonterm cNt cIdx ∈ restSyms) →
        ∀ (sPos ePos : Nat) (sub : ConcreteParseTree) (subSum : ParseSummary),
          (sub, subSum) ∈ childEnum cLoc cNt sPos ePos ↔
            (sub.span = ⟨sPos, ePos⟩ ∧ ValidParseNode cat numCfg env Y cLoc cNt sub subSum) := by
      intro cLoc cNt ⟨cIdx, hm⟩
      exact hChild cLoc cNt ⟨cIdx, List.Mem.tail sym hm⟩
    cases sym with
    | term lit =>
      unfold enumSegsWith
      dsimp only
      let sp : CodepointSpan := ⟨cursor, cursor + lit.toList.length⟩
      constructor
      · intro hmem
        by_cases hchk : fastSpanMatchesBool Y sp lit.toList = true
        · rw [if_pos hchk, List.mem_map] at hmem
          rcases hmem with ⟨⟨rArgs, rSlots, rSums⟩, hm_tail, heq⟩
          injection heq with ha h1
          injection h1 with hsl hsm
          subst args; subst slots; subst sums
          have hsp : SpanMatches Y sp lit.toList := (fastSpanMatchesBool_iff Y sp lit.toList).mp hchk
          have hvalid_tail := (ih hChildRest sp.endCp rArgs rSlots rSums).mp hm_tail
          exact ⟨rfl, rfl, hsp, hvalid_tail⟩
        · rw [if_neg hchk] at hmem
          simp at hmem
      · intro hval
        cases args with
        | nil => exact False.elim hval
        | cons a rArgs =>
          cases a with
          | litTok txt sp0 =>
            rcases hval with ⟨htxt, hstart, hsp0, hrest⟩
            subst txt
            have hend0 : sp0.endCp = cursor + lit.toList.length := by
              rcases hsp0 with ⟨he, _⟩
              omega
            have hsp_eq : sp0 = sp := by
              cases sp0
              dsimp at hstart hend0
              subst hstart; subst hend0
              rfl
            subst sp0
            have hchk : fastSpanMatchesBool Y sp lit.toList = true :=
              (fastSpanMatchesBool_iff Y sp lit.toList).mpr hsp0
            rw [if_pos hchk, List.mem_map]
            exact ⟨(rArgs, slots, sums), (ih hChildRest sp.endCp rArgs slots sums).mpr hrest, rfl⟩
          | slotTok _ _ _ _ _ => exact False.elim hval
          | childSub _ => exact False.elim hval
    | lexSlot srt tag =>
      unfold enumSegsWith
      dsimp only
      constructor
      · intro hmem
        by_cases hend_le : endPos ≤ Y.length
        · rw [if_pos hend_le, mem_flatMapList_iff] at hmem
          rcases hmem with ⟨mid, _, hmid_mem⟩
          let lex := String.ofList ((Y.drop cursor).take (mid - cursor))
          let sp : CodepointSpan := ⟨cursor, mid⟩
          by_cases hchk : fastSpanMatchesBool Y sp lex.toList = true
          · rw [if_pos hchk, mem_flatMapList_iff] at hmid_mem
            rcases hmid_mem with ⟨eid, heid_mem, hmap_mem⟩
            rw [List.mem_map] at hmap_mem
            rcases hmap_mem with ⟨⟨rArgs, rSlots, rSums⟩, hm_tail, heq⟩
            injection heq with ha h1
            injection h1 with hsl hsm
            subst args; subst slots; subst sums
            have hsp : SpanMatches Y sp lex.toList := (fastSpanMatchesBool_iff Y sp lex.toList).mp hchk
            have hdsv := (mem_validSlotEntityIds_iff cat numCfg Y.length srt eid lex).mp heid_mem
            have hvalid_tail := (ih hChildRest mid rArgs rSlots rSums).mp hm_tail
            exact ⟨rSlots, rfl, rfl, rfl, hsp, hdsv, rfl, hvalid_tail⟩
          · rw [if_neg hchk] at hmid_mem
            simp at hmid_mem
        · rw [if_neg hend_le] at hmem
          simp at hmem
      · intro hval
        cases args with
        | nil => exact False.elim hval
        | cons a rArgs =>
          cases a with
          | litTok _ _ => exact False.elim hval
          | childSub _ => exact False.elim hval
          | slotTok aSrt aTag eid lex0 sp0 =>
            rcases hval with ⟨rSlots, hsrt, htag, hstart, hsp0, hdsv, hslots, hrest⟩
            subst aSrt; subst aTag; subst slots
            have ⟨_, hend_le⟩ := validParseSegs_bounds hrest
            rw [if_pos hend_le, mem_flatMapList_iff]
            have hcur_le : cursor ≤ sp0.endCp := by
              rcases hsp0 with ⟨he, _⟩
              omega
            have hmid_cand := validParseSegs_mem_candidateSplitPositions hcur_le hrest
            refine ⟨sp0.endCp, hmid_cand, ?_⟩
            have hchk0 := spanMatches_implies_checkBool hsp0
            unfold checkSpanMatchesBool at hchk0
            simp [Bool.and_eq_true] at hchk0
            rcases hchk0 with ⟨⟨hsp0_end, _⟩, htake0⟩
            have hlen_diff : sp0.endCp - cursor = lex0.toList.length := by omega
            have hslice_eq : (Y.drop cursor).take (sp0.endCp - cursor) = lex0.toList := by
              rw [hlen_diff, ← hstart]
              exact htake0
            have hlex_eq : String.ofList ((Y.drop cursor).take (sp0.endCp - cursor)) = lex0 := by
              rw [hslice_eq, String.ofList_toList]
            have hsp_eq : (⟨cursor, sp0.endCp⟩ : CodepointSpan) = sp0 := by
              cases sp0
              dsimp at hstart
              subst hstart
              rfl
            rw [hlex_eq, hsp_eq]
            have hchk_sp0 : fastSpanMatchesBool Y sp0 lex0.toList = true :=
              (fastSpanMatchesBool_iff Y sp0 lex0.toList).mpr hsp0
            rw [if_pos hchk_sp0, mem_flatMapList_iff]
            refine ⟨eid, (mem_validSlotEntityIds_iff cat numCfg Y.length srt eid lex0).mpr hdsv, ?_⟩
            rw [List.mem_map]
            exact ⟨(rArgs, rSlots, sums), (ih hChildRest sp0.endCp rArgs rSlots sums).mpr hrest, rfl⟩
    | nonterm childNt cIdx =>
      unfold enumSegsWith
      dsimp only
      let childLoc := (clauseOverrideOfIdx cIdx).getD loc
      have hChildHere := hChild childLoc childNt ⟨cIdx, List.Mem.head restSyms⟩
      constructor
      · intro hmem
        rw [mem_flatMapList_iff] at hmem
        rcases hmem with ⟨mid, _, hmid_mem⟩
        rw [mem_flatMapList_iff] at hmid_mem
        rcases hmid_mem with ⟨⟨subTree, subSum⟩, hsub_mem, hmap_mem⟩
        rw [List.mem_map] at hmap_mem
        rcases hmap_mem with ⟨⟨rArgs, rSlots, rSums⟩, hm_tail, heq⟩
        injection heq with ha h1
        injection h1 with hsl hsm
        subst args; subst slots; subst sums
        rcases (hChildHere cursor mid subTree subSum).mp hsub_mem with ⟨hsub_sp, hsub_valid⟩
        have hvalid_tail := (ih hChildRest mid rArgs rSlots rSums).mp hm_tail
        refine ⟨subSum, rSums, ?_, hsub_valid, rfl, ?_⟩
        · rw [hsub_sp]
        · rw [hsub_sp]
          exact hvalid_tail
      · intro hval
        cases args with
        | nil => exact False.elim hval
        | cons a rArgs =>
          cases a with
          | litTok _ _ => exact False.elim hval
          | slotTok _ _ _ _ _ => exact False.elim hval
          | childSub subTree =>
            rcases hval with ⟨subSum, rSums, hstart, hsub_valid, hsums_eq, hrest⟩
            subst sums
            have hsub_sp_match := validParseNode_spanMatches subTree hsub_valid
            have hcur_le : cursor ≤ subTree.span.endCp := by
              rcases hsub_sp_match with ⟨he, _⟩
              omega
            have hmid_cand := validParseSegs_mem_candidateSplitPositions hcur_le hrest
            rw [mem_flatMapList_iff]
            refine ⟨subTree.span.endCp, hmid_cand, ?_⟩
            rw [mem_flatMapList_iff]
            have hsp_eq : subTree.span = ⟨cursor, subTree.span.endCp⟩ := by
              cases hsp : subTree.span
              rw [hsp] at hstart
              dsimp at hstart
              subst hstart
              rfl
            refine ⟨(subTree, subSum), (hChildHere cursor subTree.span.endCp subTree subSum).mpr ⟨hsp_eq, hsub_valid⟩, ?_⟩
            rw [List.mem_map]
            exact ⟨(rArgs, slots, rSums), (ih hChildRest subTree.span.endCp rArgs slots rSums).mpr hrest, rfl⟩

/--
  **Exact Stratification Soundness & Completeness of `enumNodeRef`**:
  Whenever `expectedNt.level < fuel`, `enumNodeRef fuel` enumerates ALL and ONLY
  `(tree, outSum)` pairs satisfying `tree.span = ⟨startPos, endPos⟩ ∧ ValidParseNode`.
-/
theorem mem_enumNodeRef_iff
    (fuel : Nat) (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (Y : List Char)
    (expectedLoc : ClauseLocus) (expectedNt : BNFNonterm)
    (hlvl : expectedNt.level < fuel)
    (startPos endPos : Nat) (tree : ConcreteParseTree) (outSum : ParseSummary) :
    (tree, outSum) ∈ enumNodeRef fuel cat numCfg env Y expectedLoc expectedNt startPos endPos ↔
      (tree.span = ⟨startPos, endPos⟩ ∧
       ValidParseNode cat numCfg env Y expectedLoc expectedNt tree outSum) := by
  induction fuel generalizing expectedLoc expectedNt startPos endPos tree outSum with
  | zero => omega
  | succ k ih =>
    unfold enumNodeRef
    rw [mem_flatMapList_iff]
    constructor
    · rintro ⟨p, _, hp_mem⟩
      dsimp only at hp_mem
      by_cases hlhs : ((frozenProdSig p).lhs == expectedNt) = true
      · rw [if_pos hlhs, mem_flatMapList_iff] at hp_mem
        rcases hp_mem with ⟨⟨args, slots, sums⟩, hseg_mem, hside_mem⟩
        dsimp only at hside_mem
        have hlhs_eq : (frozenProdSig p).lhs = expectedNt := beq_iff_eq.mp hlhs
        have hChild : ∀ (cLoc : ClauseLocus) (cNt : BNFNonterm),
            (∃ cIdx, BNFSymbol.nonterm cNt cIdx ∈ (frozenProdSig p).rhs) →
            ∀ (sPos ePos : Nat) (sub : ConcreteParseTree) (subSum : ParseSummary),
              (sub, subSum) ∈ enumNodeRef k cat numCfg env Y cLoc cNt sPos ePos ↔
                (sub.span = ⟨sPos, ePos⟩ ∧ ValidParseNode cat numCfg env Y cLoc cNt sub subSum) := by
          intro cLoc cNt ⟨cIdx, hmem_rhs⟩ sPos ePos sub subSum
          have hlt_p := frozenProdSig_child_level_lt p cNt cIdx hmem_rhs
          have hlt_k : cNt.level < k := by
            rw [hlhs_eq] at hlt_p
            omega
          exact ih cLoc cNt hlt_k sPos ePos sub subSum
        have hsegs := (mem_enumSegsWith_iff cat numCfg env Y _ (frozenProdSig p).rhs hChild expectedLoc startPos endPos args slots sums).mp hseg_mem
        by_cases hside : (frozenProdSig p).checkSide env slots sums = true
        · rw [if_pos hside, List.mem_map] at hside_mem
          rcases hside_mem with ⟨alt, halt_mem, heq⟩
          injection heq with htree hout
          subst tree; subst outSum
          rcases (mem_rangeClosed_iff 1 p.altCount alt).mp halt_mem with ⟨ha1, ha2⟩
          exact ⟨rfl, slots, sums, rfl, hlhs_eq, ha1, ha2, hsegs, hside, rfl⟩
        · rw [if_neg hside] at hside_mem
          simp at hside_mem
      · rw [if_neg hlhs] at hp_mem
        simp at hp_mem
    · rintro ⟨hsp_eq, hnode⟩
      cases tree with
      | mkTree p alt loc sp args =>
        dsimp [ConcreteParseTree.span] at hsp_eq
        subst sp
        rcases hnode with ⟨slots, sums, hloc, hlhs_eq, ha1, ha2, hsegs, hside, hout⟩
        subst loc; subst outSum
        refine ⟨p, allFrozenParseProds_nodup_and_complete p, ?_⟩
        have hlhs_b : ((frozenProdSig p).lhs == expectedNt) = true := beq_iff_eq.mpr hlhs_eq
        dsimp only
        rw [if_pos hlhs_b, mem_flatMapList_iff]
        have hChild : ∀ (cLoc : ClauseLocus) (cNt : BNFNonterm),
            (∃ cIdx, BNFSymbol.nonterm cNt cIdx ∈ (frozenProdSig p).rhs) →
            ∀ (sPos ePos : Nat) (sub : ConcreteParseTree) (subSum : ParseSummary),
              (sub, subSum) ∈ enumNodeRef k cat numCfg env Y cLoc cNt sPos ePos ↔
                (sub.span = ⟨sPos, ePos⟩ ∧ ValidParseNode cat numCfg env Y cLoc cNt sub subSum) := by
          intro cLoc cNt ⟨cIdx, hmem_rhs⟩ sPos ePos sub subSum
          have hlt_p := frozenProdSig_child_level_lt p cNt cIdx hmem_rhs
          have hlt_k : cNt.level < k := by
            rw [hlhs_eq] at hlt_p
            omega
          exact ih cLoc cNt hlt_k sPos ePos sub subSum
        have hseg_mem := (mem_enumSegsWith_iff cat numCfg env Y _ (frozenProdSig p).rhs hChild expectedLoc startPos endPos args slots sums).mpr hsegs
        refine ⟨(args, slots, sums), hseg_mem, ?_⟩
        dsimp only
        rw [if_pos hside, List.mem_map]
        exact ⟨alt, (mem_rangeClosed_iff 1 p.altCount alt).mpr ⟨ha1, ha2⟩, rfl⟩

/-! ### 5. Metered Bounded Exhaustive Parser (`parseAllBounded`) & Exact Ref Congruence -/

structure MeterState where
  stepsUsed       : Nat
  forestNodesUsed : Nat
  deriving DecidableEq, Repr

def tickStep (budget : ResourceBudget) (st : MeterState) : Except OverflowReason MeterState :=
  let next := st.stepsUsed + 1
  if budget.maxSteps < next then
    .error (.maxStepsExceeded budget.maxSteps)
  else
    .ok { st with stepsUsed := next }

def tickForestNodes (budget : ResourceBudget) (count : Nat) (st : MeterState) :
    Except OverflowReason MeterState :=
  let next := st.forestNodesUsed + count
  if budget.maxForestNodes < next then
    .error (.maxForestNodesExceeded budget.maxForestNodes)
  else
    .ok { st with forestNodesUsed := next }

def flatMapMetered {α β : Type} : List α →
    (α → MeterState → Except OverflowReason (List β × MeterState)) →
    MeterState → Except OverflowReason (List β × MeterState)
  | [], _, st => .ok ([], st)
  | x :: rest, f, st =>
    match f x st with
    | .error e => .error e
    | .ok (ys, st1) =>
      match flatMapMetered rest f st1 with
      | .error e => .error e
      | .ok (zs, st2) => .ok (ys ++ zs, st2)

theorem flatMapMetered_eq_flatMapList {α β : Type} (xs : List α)
    (f : α → MeterState → Except OverflowReason (List β × MeterState))
    (g : α → List β)
    (hfg : ∀ x ∈ xs, ∀ st res st', f x st = .ok (res, st') → res = g x)
    (st : MeterState) (out : List β) (stFinal : MeterState)
    (hok : flatMapMetered xs f st = .ok (out, stFinal)) :
    out = flatMapList xs g := by
  induction xs generalizing st out stFinal with
  | nil =>
    unfold flatMapMetered flatMapList at *
    injection hok with hp
    injection hp with hout _
    exact hout.symm
  | cons x rest ih =>
    unfold flatMapMetered at hok
    cases hfx : f x st with
    | error e => rw [hfx] at hok; contradiction
    | ok pair1 =>
      rw [hfx] at hok
      rcases pair1 with ⟨ys, st1⟩
      dsimp at hok
      cases hrest : flatMapMetered rest f st1 with
      | error e => rw [hrest] at hok; contradiction
      | ok pair2 =>
        rw [hrest] at hok
        rcases pair2 with ⟨zs, st2⟩
        dsimp at hok
        injection hok with hpair
        injection hpair with hout _
        subst out
        have hys := hfg x (List.Mem.head rest) st ys st1 hfx
        have hzs := ih (fun y hy => hfg y (List.Mem.tail x hy)) st1 zs st2 hrest
        simp [flatMapList, hys, hzs]

def enumSegsMetered
    (budget : ResourceBudget) (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig) (Y : List Char)
    (childMetered : ClauseLocus → BNFNonterm → Nat → Nat → MeterState →
      Except OverflowReason (List (ConcreteParseTree × ParseSummary) × MeterState))
    (loc : ClauseLocus) (cursor : Nat) (syms : List BNFSymbol) (endPos : Nat)
    (st : MeterState) :
    Except OverflowReason (List (List ConcreteParseArg × List (BNFSlotTag × String) × List ParseSummary) × MeterState) :=
  match tickStep budget st with
  | .error e => .error e
  | .ok st1 =>
    match syms with
    | [] =>
      if (cursor ≤ Y.length) && (endPos == cursor) then
        .ok ([([], [], [])], st1)
      else
        .ok ([], st1)
    | .term lit :: restSyms =>
      let lcs := lit.toList
      let sp : CodepointSpan := ⟨cursor, cursor + lcs.length⟩
      if fastSpanMatchesBool Y sp lcs then
        match enumSegsMetered budget cat numCfg Y childMetered loc sp.endCp restSyms endPos st1 with
        | .error e => .error e
        | .ok (tails, st2) =>
          .ok (tails.map (fun (rArgs, rSlots, rSums) => (.litTok lit sp :: rArgs, rSlots, rSums)), st2)
      else
        .ok ([], st1)
    | .lexSlot srt tag :: restSyms =>
      if endPos ≤ Y.length then
        flatMapMetered (candidateSplitPositions Y cursor endPos restSyms)
          (fun mid stMid =>
            let sliceCs := (Y.drop cursor).take (mid - cursor)
            let lex := String.ofList sliceCs
            let sp : CodepointSpan := ⟨cursor, mid⟩
            if fastSpanMatchesBool Y sp lex.toList then
              let validEids := validSlotEntityIds cat numCfg Y.length srt lex
              match validEids with
              | [] => .ok ([], stMid)
              | _ :: _ =>
                match enumSegsMetered budget cat numCfg Y childMetered loc mid restSyms endPos stMid with
                | .error e => .error e
                | .ok (tails, stTail) =>
                  let built := flatMapList validEids fun eid =>
                    tails.map fun (rArgs, rSlots, rSums) =>
                      (.slotTok srt tag eid lex sp :: rArgs, (tag, eid) :: rSlots, rSums)
                  .ok (built, stTail)
            else
              .ok ([], stMid))
          st1
      else
        .ok ([], st1)
    | .nonterm childNt cIdx :: restSyms =>
      let childLoc := (clauseOverrideOfIdx cIdx).getD loc
      flatMapMetered (candidateSplitPositions Y cursor endPos restSyms)
        (fun mid stMid =>
          match childMetered childLoc childNt cursor mid stMid with
          | .error e => .error e
          | .ok (children, stChild) =>
            match children with
            | [] => .ok ([], stChild)
            | _ :: _ =>
              match enumSegsMetered budget cat numCfg Y childMetered loc mid restSyms endPos stChild with
              | .error e => .error e
              | .ok (tails, stTail) =>
                let built := flatMapList children fun (subTree, subSum) =>
                  tails.map fun (rArgs, rSlots, rSums) =>
                    (.childSub subTree :: rArgs, rSlots, subSum :: rSums)
                .ok (built, stTail))
        st1

def enumNodeMetered : Nat → ResourceBudget → ClosedEntityCatalog → NumericGateConfig →
    ScopeEnv → List Char → ClauseLocus → BNFNonterm → Nat → Nat → MeterState →
    Except OverflowReason (List (ConcreteParseTree × ParseSummary) × MeterState)
  | 0, budget, _, _, _, _, _, _, _, _, st =>
    match tickStep budget st with
    | .error e => .error e
    | .ok st1  => .ok ([], st1)
  | fuel + 1, budget, cat, numCfg, env, Y, expectedLoc, expectedNt, startPos, endPos, st =>
    match tickStep budget st with
    | .error e => .error e
    | .ok st0 =>
      flatMapMetered allFrozenParseProds
        (fun p stProd =>
          let sig := frozenProdSig p
          if sig.lhs == expectedNt then
            match enumSegsMetered budget cat numCfg Y (enumNodeMetered fuel budget cat numCfg env Y)
                    expectedLoc startPos sig.rhs endPos stProd with
            | .error e => .error e
            | .ok (segResults, stSeg) =>
              flatMapMetered segResults
                (fun (args, slots, sums) stAlt =>
                  if sig.checkSide env slots sums then
                    let outSum := sig.mkSum slots sums
                    let alts := rangeClosed 1 p.altCount
                    match tickForestNodes budget alts.length stAlt with
                    | .error e => .error e
                    | .ok stNodes =>
                      let built := alts.map fun alt =>
                        (ConcreteParseTree.mkTree p alt expectedLoc ⟨startPos, endPos⟩ args, outSum)
                      .ok (built, stNodes)
                  else
                    .ok ([], stAlt))
                stSeg
          else
            .ok ([], stProd))
        st0

theorem enumSegsMetered_eq_ref
    (budget : ResourceBudget) (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig) (Y : List Char)
    (childMetered : ClauseLocus → BNFNonterm → Nat → Nat → MeterState →
      Except OverflowReason (List (ConcreteParseTree × ParseSummary) × MeterState))
    (childRef : ClauseLocus → BNFNonterm → Nat → Nat → List (ConcreteParseTree × ParseSummary))
    (hChild : ∀ cLoc cNt sPos ePos st res st',
      childMetered cLoc cNt sPos ePos st = .ok (res, st') → res = childRef cLoc cNt sPos ePos)
    (loc : ClauseLocus) (cursor : Nat) (syms : List BNFSymbol) (endPos : Nat)
    (st st' : MeterState)
    (res : List (List ConcreteParseArg × List (BNFSlotTag × String) × List ParseSummary))
    (hok : enumSegsMetered budget cat numCfg Y childMetered loc cursor syms endPos st = .ok (res, st')) :
    res = enumSegsWith cat numCfg Y childRef loc cursor syms endPos := by
  induction syms generalizing cursor st st' res with
  | nil =>
    unfold enumSegsMetered at hok
    unfold enumSegsWith
    cases ht : tickStep budget st with
    | error e => rw [ht] at hok; contradiction
    | ok st1 =>
      rw [ht] at hok
      dsimp at hok
      by_cases hc : ((cursor ≤ Y.length) && (endPos == cursor)) = true
      · rw [if_pos hc] at hok ⊢
        injection hok with hp; injection hp with hres _; exact hres.symm
      · rw [if_neg hc] at hok ⊢
        injection hok with hp; injection hp with hres _; exact hres.symm
  | cons sym restSyms ih =>
    unfold enumSegsMetered at hok
    unfold enumSegsWith
    cases ht : tickStep budget st with
    | error e => rw [ht] at hok; contradiction
    | ok st1 =>
      rw [ht] at hok
      dsimp at hok
      cases sym with
      | term lit =>
        dsimp only at hok ⊢
        let sp : CodepointSpan := ⟨cursor, cursor + lit.toList.length⟩
        by_cases hchk : fastSpanMatchesBool Y sp lit.toList = true
        · rw [if_pos hchk] at hok ⊢
          cases hrec : enumSegsMetered budget cat numCfg Y childMetered loc sp.endCp restSyms endPos st1 with
          | error e => rw [hrec] at hok; contradiction
          | ok pair2 =>
            rw [hrec] at hok
            rcases pair2 with ⟨tails, st2⟩
            dsimp at hok
            injection hok with hp
            injection hp with hres _
            subst res
            rw [ih sp.endCp st1 st2 tails hrec]
        · rw [if_neg hchk] at hok ⊢
          injection hok with hp; injection hp with hres _; exact hres.symm
      | lexSlot srt tag =>
        dsimp only at hok ⊢
        by_cases hend : endPos ≤ Y.length
        · rw [if_pos hend] at hok ⊢
          refine flatMapMetered_eq_flatMapList _ _ _ ?_ st1 res st' hok
          intro mid _ stMid resMid stMid' hmid_ok
          let lex := String.ofList ((Y.drop cursor).take (mid - cursor))
          let sp : CodepointSpan := ⟨cursor, mid⟩
          by_cases hchk : fastSpanMatchesBool Y sp lex.toList = true
          · rw [if_pos hchk] at hmid_ok ⊢
            cases hv : validSlotEntityIds cat numCfg Y.length srt (String.ofList ((Y.drop cursor).take (mid - cursor))) with
            | nil =>
              rw [hv] at hmid_ok
              dsimp at hmid_ok
              injection hmid_ok with hp; injection hp with hres_mid _; exact hres_mid.symm
            | cons vhead vtail =>
              rw [hv] at hmid_ok
              dsimp only at hmid_ok
              cases hrec : enumSegsMetered budget cat numCfg Y childMetered loc mid restSyms endPos stMid with
              | error e => rw [hrec] at hmid_ok; contradiction
              | ok pairTail =>
                rw [hrec] at hmid_ok
                rcases pairTail with ⟨tails, stTail⟩
                dsimp at hmid_ok
                injection hmid_ok with hp
                injection hp with hres_mid _
                subst resMid
                rw [ih mid stMid stTail tails hrec]
          · rw [if_neg hchk] at hmid_ok ⊢
            injection hmid_ok with hp; injection hp with hres_mid _; exact hres_mid.symm
        · rw [if_neg hend] at hok ⊢
          injection hok with hp; injection hp with hres _; exact hres.symm
      | nonterm childNt cIdx =>
        dsimp only at hok ⊢
        refine flatMapMetered_eq_flatMapList _ _ _ ?_ st1 res st' hok
        intro mid _ stMid resMid stMid' hmid_ok
        let childLoc := (clauseOverrideOfIdx cIdx).getD loc
        cases hch : childMetered childLoc childNt cursor mid stMid with
        | error e => rw [hch] at hmid_ok; contradiction
        | ok pairChild =>
          rw [hch] at hmid_ok
          rcases pairChild with ⟨children, stChild⟩
          dsimp at hmid_ok
          have hch_eq := hChild childLoc childNt cursor mid stMid children stChild hch
          cases hc_list : children with
          | nil =>
            rw [hc_list] at hmid_ok hch_eq
            rw [← hch_eq]
            dsimp [flatMapList] at hmid_ok ⊢
            injection hmid_ok with hp; injection hp with hres_mid _; exact hres_mid.symm
          | cons chead ctail =>
            rw [hc_list] at hmid_ok hch_eq
            dsimp only at hmid_ok
            cases hrec : enumSegsMetered budget cat numCfg Y childMetered loc mid restSyms endPos stChild with
            | error e => rw [hrec] at hmid_ok; contradiction
            | ok pairTail =>
              rw [hrec] at hmid_ok
              rcases pairTail with ⟨tails, stTail⟩
              dsimp at hmid_ok
              injection hmid_ok with hp
              injection hp with hres_mid _
              subst resMid
              rw [← hch_eq, ih mid stChild stTail tails hrec]

theorem enumNodeMetered_eq_ref
    (fuel : Nat) (budget : ResourceBudget) (cat : ClosedEntityCatalog)
    (numCfg : NumericGateConfig) (env : ScopeEnv) (Y : List Char)
    (expectedLoc : ClauseLocus) (expectedNt : BNFNonterm) (startPos endPos : Nat)
    (st st' : MeterState) (res : List (ConcreteParseTree × ParseSummary))
    (hok : enumNodeMetered fuel budget cat numCfg env Y expectedLoc expectedNt startPos endPos st = .ok (res, st')) :
    res = enumNodeRef fuel cat numCfg env Y expectedLoc expectedNt startPos endPos := by
  induction fuel generalizing expectedLoc expectedNt startPos endPos st st' res with
  | zero =>
    unfold enumNodeMetered at hok
    unfold enumNodeRef
    cases ht : tickStep budget st with
    | error e => rw [ht] at hok; contradiction
    | ok st1 =>
      rw [ht] at hok
      injection hok with hp
      injection hp with hres _
      exact hres.symm
  | succ k ih =>
    unfold enumNodeMetered at hok
    unfold enumNodeRef
    cases ht : tickStep budget st with
    | error e => rw [ht] at hok; contradiction
    | ok st0 =>
      rw [ht] at hok
      dsimp at hok
      refine flatMapMetered_eq_flatMapList _ _ _ ?_ st0 res st' hok
      intro p _ stProd resProd stProd' hp_ok
      dsimp only at hp_ok ⊢
      by_cases hlhs : ((frozenProdSig p).lhs == expectedNt) = true
      · rw [if_pos hlhs] at hp_ok ⊢
        cases hseg : enumSegsMetered budget cat numCfg Y (enumNodeMetered k budget cat numCfg env Y)
                       expectedLoc startPos (frozenProdSig p).rhs endPos stProd with
        | error e => rw [hseg] at hp_ok; contradiction
        | ok pairSeg =>
          rw [hseg] at hp_ok
          rcases pairSeg with ⟨segResults, stSeg⟩
          dsimp at hp_ok
          have hseg_eq := enumSegsMetered_eq_ref budget cat numCfg Y
            (enumNodeMetered k budget cat numCfg env Y)
            (enumNodeRef k cat numCfg env Y)
            (fun cL cN sP eP s0 r0 s1 h0 => ih cL cN sP eP s0 s1 r0 h0)
            expectedLoc startPos (frozenProdSig p).rhs endPos stProd stSeg segResults hseg
          rw [← hseg_eq]
          refine flatMapMetered_eq_flatMapList _ _ _ ?_ stSeg resProd stProd' hp_ok
          rintro ⟨args, slots, sums⟩ _ stAlt resAlt stAlt' halt_ok
          dsimp only at halt_ok ⊢
          by_cases hside : (frozenProdSig p).checkSide env slots sums = true
          · rw [if_pos hside] at halt_ok ⊢
            cases hnf : tickForestNodes budget (rangeClosed 1 p.altCount).length stAlt with
            | error e => rw [hnf] at halt_ok; contradiction
            | ok stNodes =>
              rw [hnf] at halt_ok
              dsimp at halt_ok
              injection halt_ok with hp
              injection hp with hres_alt _
              exact hres_alt.symm
          · rw [if_neg hside] at halt_ok ⊢
            injection halt_ok with hp; injection hp with hres_alt _; exact hres_alt.symm
      · rw [if_neg hlhs] at hp_ok ⊢
        injection hp_ok with hp; injection hp with hres_prod _; exact hres_prod.symm

/--
  **Top-Level Bounded Exhaustive Parser (`parseAllBounded` — `PO-C1-01`)**:
  1. Checks character-profile domain (`OutOfDomain` iff `¬ StrictAsciiDomainSupported`).
  2. Enforces `budget.maxBytes` (`ResourceOverflow`, NOT `OutOfDomain`).
  3. Runs metered exhaustive enumeration across all 34 `G_parse` productions (`maxSteps`, `maxForestNodes`).
  4. Deduplicates in deterministic order and enforces `budget.maxReadings` fail-closed.
-/
def parseAllBounded (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) : BoundedParseResult :=
  match checkAsciiDomainOnly rawBytes with
  | .error d => .outOfDomain d
  | .ok () =>
    if budget.maxBytes < rawBytes.length then
      .resourceOverflow (.maxBytesExceeded rawBytes.length budget.maxBytes)
    else
      let Y := (decodeAsciiBytes rawBytes).toList
      let initState : MeterState := { stepsUsed := 0, forestNodesUsed := 0 }
      match enumNodeMetered 5 budget cat numCfg env Y .clause1 .controlledDocument 0 Y.length initState with
      | .error ov => .resourceOverflow ov
      | .ok (rawPairs, _) =>
        let uniqueTrees := dedupTrees (rawPairs.map Prod.fst)
        if budget.maxReadings < uniqueTrees.length then
          .resourceOverflow (.maxReadingsExceeded uniqueTrees.length budget.maxReadings)
        else
          .enumerated uniqueTrees

/-! ### 6. Gate C Formal Theorems (`PO-C1-01`: Termination, Soundness, Completeness, Fail-Closed) -/

/-- **Gate C.1 (`parseAllBounded_terminates`)**: Total deterministic termination on all inputs & budgets. -/
theorem parseAllBounded_terminates
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) :
    ∃ res : BoundedParseResult, parseAllBounded cat numCfg env budget rawBytes = res :=
  ⟨_, rfl⟩

/--
  **Gate C.2 (`parseAllBounded_outOfDomain_sound`)**:
  `OutOfDomain(d)` proves strictly that `rawBytes` violates `StrictAsciiDomainSupported`
  (it never falsely claims grammatical non-derivability outside the supported character profile).
-/
theorem parseAllBounded_outOfDomain_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (d : OutOfDomainDiag)
    (hood : parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d) :
    ¬ StrictAsciiDomainSupported rawBytes := by
  unfold parseAllBounded at hood
  cases hdom : checkAsciiDomainOnly rawBytes with
  | error d' =>
    exact checkAsciiDomainOnly_err_sound rawBytes d' hdom
  | ok u =>
    rw [hdom] at hood
    dsimp at hood
    split at hood
    · contradiction
    · split at hood
      · contradiction
      · split at hood <;> contradiction

/--
  **Gate C.3 (`parseAllBounded_enumerated_sound_and_complete` — Core `PO-C1-01` Theorem)**:
  Whenever `parseAllBounded ... = .enumerated T`, ALL of the following hold simultaneously:
  1. `StrictAsciiDomainSupported rawBytes` and `rawBytes.length ≤ budget.maxBytes`.
  2. `T.length ≤ budget.maxReadings`.
  3. `NoDupTrees T` (zero duplicate parse trees).
  4. **Exact Soundness & Bounded Exhaustive Completeness**:
     `∀ τ : ConcreteParseTree, τ ∈ T ↔ ValidParse_GFrozen cat numCfg env rawBytes τ`.
-/
theorem parseAllBounded_enumerated_sound_and_complete
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree)
    (henum : parseAllBounded cat numCfg env budget rawBytes = .enumerated T) :
    StrictAsciiDomainSupported rawBytes ∧
    rawBytes.length ≤ budget.maxBytes ∧
    T.length ≤ budget.maxReadings ∧
    NoDupTrees T ∧
    (∀ τ : ConcreteParseTree, τ ∈ T ↔ ValidParse_GFrozen cat numCfg env rawBytes τ) := by
  unfold parseAllBounded at henum
  cases hdom : checkAsciiDomainOnly rawBytes with
  | error d => rw [hdom] at henum; contradiction
  | ok u =>
    rw [hdom] at henum
    dsimp at henum
    have hsup := (checkAsciiDomainOnly_ok_iff rawBytes).mp hdom
    by_cases hbytes : budget.maxBytes < rawBytes.length
    · rw [if_pos hbytes] at henum; contradiction
    · rw [if_neg hbytes] at henum
      let Y := (decodeAsciiBytes rawBytes).toList
      let initState : MeterState := { stepsUsed := 0, forestNodesUsed := 0 }
      cases hmet : enumNodeMetered 5 budget cat numCfg env Y .clause1 .controlledDocument 0 Y.length initState with
      | error ov => rw [hmet] at henum; contradiction
      | ok pairOut =>
        rw [hmet] at henum
        rcases pairOut with ⟨rawPairs, stFinal⟩
        dsimp at henum
        by_cases hread : budget.maxReadings < (dedupTrees (rawPairs.map Prod.fst)).length
        · rw [if_pos hread] at henum; contradiction
        · rw [if_neg hread] at henum
          injection henum with hT
          subst T
          have href_eq := enumNodeMetered_eq_ref 5 budget cat numCfg env Y
            .clause1 .controlledDocument 0 Y.length initState stFinal rawPairs hmet
          have hlvl : BNFNonterm.controlledDocument.level < 5 := by decide
          refine ⟨hsup, by omega, by omega, dedupTrees_nodup _, ?_⟩
          intro τ
          rw [mem_dedupTrees_iff, List.mem_map]
          unfold ValidParse_GFrozen
          constructor
          · rintro ⟨⟨t0, sum0⟩, hmem_raw, rfl⟩
            rw [href_eq] at hmem_raw
            rcases (mem_enumNodeRef_iff 5 cat numCfg env Y .clause1 .controlledDocument hlvl 0 Y.length t0 sum0).mp hmem_raw with ⟨hsp, hnode⟩
            exact ⟨hsup, hsp, sum0, hnode⟩
          · rintro ⟨_, hsp, sum0, hnode⟩
            refine ⟨(τ, sum0), ?_, rfl⟩
            rw [href_eq]
            exact (mem_enumNodeRef_iff 5 cat numCfg env Y .clause1 .controlledDocument hlvl 0 Y.length τ sum0).mpr ⟨hsp, hnode⟩

/-- **Gate C.3a (`parseAllBounded_sound`)**: Soundness corollary (`τ ∈ T → ValidParse_GFrozen`). -/
theorem parseAllBounded_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree)
    (henum : parseAllBounded cat numCfg env budget rawBytes = .enumerated T) :
    ∀ τ ∈ T, ValidParse_GFrozen cat numCfg env rawBytes τ :=
  fun τ hmem => ((parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes T henum).2.2.2.2 τ).mp hmem

/--
  **Gate C.3b (`parseAllBounded_empty_sound`)**:
  Returning `.enumerated []` proves BOTH that `rawBytes` is in-domain AND that NO valid parse exists in `G_parse`.
-/
theorem parseAllBounded_empty_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (hempty : parseAllBounded cat numCfg env budget rawBytes = .enumerated []) :
    StrictAsciiDomainSupported rawBytes ∧
    ∀ τ : ConcreteParseTree, ¬ ValidParse_GFrozen cat numCfg env rawBytes τ := by
  have hall := parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes [] hempty
  refine ⟨hall.1, ?_⟩
  intro τ hval
  have hmem := (hall.2.2.2.2 τ).mpr hval
  simp at hmem

/-! ### 7. Sealed Admission Gate & `ResourceOverflow` Fail-Closed Proof (`Gate C.5`) -/

inductive ParseGateReject where
  | domainRejected     (diag : OutOfDomainDiag)
  | overflowFailClosed (reason : OverflowReason)
  | zeroValidParses
  deriving DecidableEq, Repr

/--
  Sealed proof-carrying parse-forest witness (`private mk ::`).
  Cannot be constructed from `OutOfDomain`, `ResourceOverflow`, or `enumerated []`.
-/
structure CertifiedParseForest (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) where
  private mk ::
  trees       : List ConcreteParseTree
  hNonEmpty   : trees ≠ []
  hNoDup      : NoDupTrees trees
  hExactSet   : ∀ τ, τ ∈ trees ↔ ValidParse_GFrozen cat numCfg env rawBytes τ

def admitBoundedParse (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) :
    Except ParseGateReject (CertifiedParseForest cat numCfg env budget rawBytes) :=
  match h : parseAllBounded cat numCfg env budget rawBytes with
  | .outOfDomain d      => .error (.domainRejected d)
  | .resourceOverflow b => .error (.overflowFailClosed b)
  | .enumerated T       =>
    if hne : T = [] then
      .error .zeroValidParses
    else
      let hc := parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes T h
      .ok ⟨T, hne, hc.2.2.2.1, hc.2.2.2.2⟩

/--
  **Gate C.5 (`resourceOverflow_failClosed`)**:
  Whenever `parseAllBounded` hits `ResourceOverflow(b)`, `admitBoundedParse` deterministically
  fails closed (`.error (.overflowFailClosed b)`), discarding partial results and never issuing
  a `CertifiedParseForest` or conflating overflow with `enumerated []`.
-/
theorem resourceOverflow_failClosed
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (b : OverflowReason)
    (hov : parseAllBounded cat numCfg env budget rawBytes = .resourceOverflow b) :
    admitBoundedParse cat numCfg env budget rawBytes = .error (.overflowFailClosed b) ∧
    (∀ T, parseAllBounded cat numCfg env budget rawBytes ≠ .enumerated T) := by
  refine ⟨?_, ?_⟩
  · unfold admitBoundedParse
    split
    · rename_i d heq
      rw [hov] at heq; contradiction
    · rename_i b' heq
      rw [hov] at heq
      injection heq with hb
      rw [hb]
    · rename_i T heq
      rw [hov] at heq; contradiction
  · intro T heq
    rw [hov] at heq
    contradiction

end BrocaOmega.P3B
````

### File 8: `02_detached_checker/P3BDetachedChecker/LexicalReplayBridge.lean` (SHA-256: `4737425A39DA8570B5B7779D944A6B8760521116855BA65ED4AA52B43CA0E79C`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`Gate D`: `BridgeSound` & `ProjectionFaithful` Across Actual Frozen `P3-A` & `P2`)
  02_detached_checker/P3BDetachedChecker/LexicalReplayBridge.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  Gate D Deliverable:
  1. Directly imports and binds the ACTUAL frozen definitions:
       - `BrocaOmega.P3A.CertifiedLexicalSlot`
       - `BrocaOmega.P3A.admitLexicalSlot`
       - `BrocaOmega.P2.UntrustedDerivCert`
       - `BrocaOmega.P2.replayDerivation`
  2. Restricts `lowerToP2Cert` to `LexicallyCertifiedDerivTree` whose slot leaves carry sealed
     `P3A.CertifiedLexicalSlot` (`private mk ::`) witnesses — uncertified slots cannot be lowered!
  3. Defines full tree-recursive `ProjectionFaithful x π` preserving parent-child hierarchy, sibling
     order, `SlotSort`, `SlotRole`, `entityId`, `lexeme`, `CodepointSpan`, global pre-order span list,
     and node/global obligation `(oblId, locus, kind, target)` correspondence, with sound & complete
     boolean checker `checkProjectionFaithfulBool`.
  4. Proves `lowerToP2Cert_projectionFaithful`, `BridgeSound`, `BridgeSound_rawBytes`, and the
     3-module end-to-end unification theorem `BridgeSound_mem_enumerated_forest`.
-/
import P3BDetachedChecker.BoundedParser
import P2DetachedChecker

namespace BrocaOmega.P3B

open BrocaOmega.P2
open BrocaOmega.P3A

/-! ### 1. Exact Summary & Sort Inverse Lemmas for `P2` ↔ `P3-A` ↔ `P3-B` -/

theorem fromP2_of_toP2Sort {srt : P3SlotSort} {p2s : SlotSort}
    (h : toP2SlotSort? srt = some p2s) : srt = fromP2SlotSort p2s := by
  cases srt <;> simp [toP2SlotSort?] at h <;> subst p2s <;> rfl

theorem fromP2Rule_mkSum_eq_mapP2Summary
    (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).mkSum (mapP2Slots slots) (sums.map mapP2Summary) =
    mapP2Summary ((ruleSignature r).mkSummary slots sums) := by
  cases r <;> dsimp [fromP2Rule, frozenProdSig, ruleSignature, mapP2Summary]
  all_goals
    cases sums with
    | nil => simp [toP2SlotRole?]
    | cons c1 rest1 =>
      cases rest1 <;> simp [mapP2Summary, toP2SlotRole?]

theorem fromP2Rule_altCount_eq_one (r : FrozenGenRule) :
    (fromP2Rule r).altCount = 1 := by
  cases r <;> rfl

theorem fromP2Rule_isGenerator (r : FrozenGenRule) :
    (frozenProdSig (fromP2Rule r)).isGenerator = true := by
  cases r <;> rfl

/-! ### 2. `LexicallyCertifiedDerivTree` (Restricted to Sealed `P3A.CertifiedLexicalSlot` Witnesses) -/

/--
  Lexical slot leaf carrying a kernel-sealed `BrocaOmega.P3A.CertifiedLexicalSlot` witness (`private mk ::`).
  Cannot be constructed unless `BrocaOmega.P3A.admitLexicalSlot` succeeded on `(p3Sort, entityId, lexeme)`.
-/
structure CertifiedBridgeSlot (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) where
  lexeme     : String
  entityId   : String
  p3Sort     : P3SlotSort
  p2Sort     : SlotSort
  p2Role     : SlotRole
  span       : CodepointSpan
  witness    : BrocaOmega.P3A.CertifiedLexicalSlot cat numCfg maxSlotBytes
                 { sort := p3Sort, entityId := entityId, rawBytes := strToAsciiBytes lexeme }
  hDecodedEq : ({ sort := p3Sort, entityId := entityId, rawBytes := strToAsciiBytes lexeme } : RawSlotCandidate).decodedStr = lexeme
  hSortProj  : toP2SlotSort? p3Sort = some p2Sort

def CertifiedBridgeSlot.rawCand {cat numCfg maxSlotBytes}
    (s : CertifiedBridgeSlot cat numCfg maxSlotBytes) : RawSlotCandidate :=
  { sort := s.p3Sort, entityId := s.entityId, rawBytes := strToAsciiBytes s.lexeme }

theorem certifiedBridgeSlot_declarativeValid {cat numCfg maxSlotBytes}
    (s : CertifiedBridgeSlot cat numCfg maxSlotBytes) :
    DeclarativeSlotValid cat numCfg maxSlotBytes s.p3Sort s.entityId s.lexeme :=
  ⟨s.hDecodedEq, s.witness.hLexValid, s.witness.hNumValid, s.witness.hCatBound⟩

mutual
  inductive CertifiedSegArg (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (maxSlotBytes : Nat) where
    | litSpan   (claimedText : String) (span : CodepointSpan)
    | certSlot  (slot : CertifiedBridgeSlot cat numCfg maxSlotBytes)
    | childNode (sub : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)

  /--
    Derivation tree whose terminal slots are ALL sealed `P3-A` `CertifiedBridgeSlot`s.
    This is the ONLY input type accepted by `lowerToP2Cert`.
  -/
  inductive LexicallyCertifiedDerivTree (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (maxSlotBytes : Nat) where
    | mkCertNode
        (nodeId            : Nat)
        (genRule           : FrozenGenRule)
        (span              : CodepointSpan)
        (claimedDischarged : List ObligationToken)
        (segArgs           : List (CertifiedSegArg cat numCfg maxSlotBytes))
end

/-! ### 3. Direct Structural Observables on `LexicallyCertifiedDerivTree` -/

mutual
  def AllSegSlotsP3ACertified {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → Prop
    | [] => True
    | .litSpan _ _ :: rest => AllSegSlotsP3ACertified rest
    | .certSlot s :: rest =>
      (LexicallyValid maxSlotBytes s.rawCand ∧
       NumericallyWellFormed numCfg s.rawCand ∧
       EntityCatalogBound cat s.rawCand ∧
       s.rawCand.decodedStr = s.lexeme ∧
       toP2SlotSort? s.p3Sort = some s.p2Sort) ∧
      AllSegSlotsP3ACertified rest
    | .childNode sub :: rest =>
      AllTreeSlotsP3ACertified sub ∧ AllSegSlotsP3ACertified rest

  /-- Every slot leaf in `x` satisfies `P3-A`'s `LexicallyValid ∧ NumericallyWellFormed ∧ EntityCatalogBound`. -/
  def AllTreeSlotsP3ACertified {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → Prop
    | .mkCertNode _ _ _ _ args => AllSegSlotsP3ACertified args
end

mutual
  theorem allSegSlots_hold {cat numCfg maxSlotBytes}
      (args : List (CertifiedSegArg cat numCfg maxSlotBytes)) :
      AllSegSlotsP3ACertified args := by
    cases args with
    | nil => trivial
    | cons a rest =>
      cases a with
      | litSpan _ _ => exact allSegSlots_hold rest
      | certSlot s =>
        exact ⟨⟨s.witness.hLexValid, s.witness.hNumValid, s.witness.hCatBound,
                s.hDecodedEq, s.hSortProj⟩,
               allSegSlots_hold rest⟩
      | childNode sub =>
        exact ⟨allTreeSlots_hold sub, allSegSlots_hold rest⟩

  theorem allTreeSlots_hold {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) :
      AllTreeSlotsP3ACertified x := by
    cases x with
    | mkCertNode _ _ _ _ args => exact allSegSlots_hold args
end

mutual
  def reconstructCertSegChars {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List Char
    | [] => []
    | .litSpan txt _ :: rest => txt.toList ++ reconstructCertSegChars rest
    | .certSlot s :: rest    => s.lexeme.toList ++ reconstructCertSegChars rest
    | .childNode sub :: rest => reconstructCertChars sub ++ reconstructCertSegChars rest

  def reconstructCertChars {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → List Char
    | .mkCertNode _ _ _ _ args => reconstructCertSegChars args
end

def reconstructCertYield {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) : String :=
  String.ofList (reconstructCertChars x)

mutual
  def collectCertSegObls {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List ObligationToken
    | [] => []
    | .litSpan _ _ :: rest   => collectCertSegObls rest
    | .certSlot _ :: rest    => collectCertSegObls rest
    | .childNode sub :: rest => collectCertClaimedObls sub ++ collectCertSegObls rest

  def collectCertClaimedObls {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → List ObligationToken
    | .mkCertNode _ _ _ claimed args => claimed ++ collectCertSegObls args
end

def ObligationsConservedOnCert {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) (deltaIn : List ObligationToken) : Prop :=
  NoDupOblIds deltaIn ∧
  NoDupOblIds (collectCertClaimedObls x) ∧
  MultisetEq (collectCertClaimedObls x) deltaIn

mutual
  def collectCertSegSpans {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List CodepointSpan
    | [] => []
    | .litSpan _ sp :: rest  => sp :: collectCertSegSpans rest
    | .certSlot s :: rest    => s.span :: collectCertSegSpans rest
    | .childNode sub :: rest => collectCertSpans sub ++ collectCertSegSpans rest

  /-- Pre-order sequence of all node, literal, and slot `CodepointSpan`s in `x`. -/
  def collectCertSpans {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → List CodepointSpan
    | .mkCertNode _ _ sp _ args => sp :: collectCertSegSpans args
end

mutual
  def collectP2SegSpans : List UntrustedSegArg → List CodepointSpan
    | [] => []
    | .litSpan _ sp :: rest  => sp :: collectP2SegSpans rest
    | .slotLeaf tok :: rest  => tok.span :: collectP2SegSpans rest
    | .childNode sub :: rest => collectP2Spans sub ++ collectP2SegSpans rest

  /-- Pre-order sequence of all node, literal, and slot `CodepointSpan`s in `π : UntrustedDerivCert`. -/
  def collectP2Spans : UntrustedDerivCert → List CodepointSpan
    | .mkNode _ _ sp _ args => sp :: collectP2SegSpans args
end

/- Direct lifting of `LexicallyCertifiedDerivTree` to `P3-B`'s `ConcreteParseTree`. -/
mutual
  def certSegsToParseArgs {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → ClauseLocus → List RuleSegment → List ConcreteParseArg
    | .litSpan txt sp :: as, loc, .lit _ :: rs =>
      .litTok txt sp :: certSegsToParseArgs as loc rs
    | .certSlot s :: as, loc, .slot _ _ :: rs =>
      .slotTok s.p3Sort (fromP2SlotRole s.p2Role) s.entityId s.lexeme s.span ::
        certSegsToParseArgs as loc rs
    | .childNode sub :: as, loc, .child _ locOpt :: rs =>
      .childSub (certTreeToParseTree sub (locOpt.getD loc)) ::
        certSegsToParseArgs as loc rs
    | _, _, _ => []

  def certTreeToParseTree {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → ClauseLocus → ConcreteParseTree
    | .mkCertNode _ r sp _ args, loc =>
      .mkTree (fromP2Rule r) 1 loc sp (certSegsToParseArgs args loc (ruleSignature r).segments)
end

/- Direct `P3-B` Locus & Target Obligation Binding on `x` using `frozenProdSig.intrinsicObls`! -/
mutual
  def synthCertSegSlotsSums {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List RuleSegment →
      Option (List (BNFSlotTag × String) × List ParseSummary)
    | [], [] => some ([], [])
    | .litSpan _ _ :: as, .lit _ :: rs => synthCertSegSlotsSums as rs
    | .certSlot s :: as, .slot _ expectedRole :: rs =>
      match synthCertSegSlotsSums as rs with
      | some (slots, sums) => some ((fromP2SlotRole expectedRole, s.entityId) :: slots, sums)
      | none => none
    | .childNode sub :: as, .child _ _ :: rs =>
      match synthCertNodeSummary sub, synthCertSegSlotsSums as rs with
      | some subSum, some (slots, sums) => some (slots, subSum :: sums)
      | _, _ => none
    | _, _ => none

  def synthCertNodeSummary {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → Option ParseSummary
    | .mkCertNode _ r _ _ args =>
      match synthCertSegSlotsSums args (ruleSignature r).segments with
      | some (slots, sums) => some ((frozenProdSig (fromP2Rule r)).mkSum slots sums)
      | none => none
end

mutual
  def CertSegLocusTargetBound {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → ClauseLocus → List RuleSegment → Prop
    | [], _, [] => True
    | .litSpan _ _ :: as, loc, .lit _ :: rs => CertSegLocusTargetBound as loc rs
    | .certSlot _ :: as, loc, .slot _ _ :: rs => CertSegLocusTargetBound as loc rs
    | .childNode sub :: as, loc, .child _ locOpt :: rs =>
      CertNodeLocusTargetBound sub (locOpt.getD loc) ∧ CertSegLocusTargetBound as loc rs
    | _, _, _ => False

  def CertNodeLocusTargetBound {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → ClauseLocus → Prop
    | .mkCertNode _ r _ claimed args, loc =>
      ∃ (slots : List (BNFSlotTag × String)) (sums : List ParseSummary),
        synthCertSegSlotsSums args (ruleSignature r).segments = some (slots, sums) ∧
        claimed.map (·.spec) = (frozenProdSig (fromP2Rule r)).intrinsicObls loc slots sums ∧
        (∀ o ∈ claimed, o.spec.locus = loc ∨ (r = .G16_DocContrastive ∧ o.spec.locus = .clause2)) ∧
        CertSegLocusTargetBound args loc (ruleSignature r).segments
end

def LocusTargetBoundOnCert {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) : Prop :=
  CertNodeLocusTargetBound x .clause1

/-! ### 4. Restricted Lowering (`lowerToP2Cert`) & Full `ProjectionFaithful(x, π)` Relation -/

def lowerBridgeSlot {cat numCfg maxSlotBytes}
    (s : CertifiedBridgeSlot cat numCfg maxSlotBytes) : SlotToken :=
  { sort     := s.p2Sort
    role     := s.p2Role
    entityId := s.entityId
    lexeme   := s.lexeme
    span     := s.span }

mutual
  def lowerSegArgs {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List UntrustedSegArg
    | [] => []
    | .litSpan txt sp :: rest => .litSpan txt sp :: lowerSegArgs rest
    | .certSlot s :: rest     => .slotLeaf (lowerBridgeSlot s) :: lowerSegArgs rest
    | .childNode sub :: rest  => .childNode (lowerToP2Cert sub) :: lowerSegArgs rest

  /--
    Restricted lowering into `BrocaOmega.P2.UntrustedDerivCert`.
    Type-restricted to `LexicallyCertifiedDerivTree` so uncertified slots CANNOT be passed!
  -/
  def lowerToP2Cert {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → BrocaOmega.P2.UntrustedDerivCert
    | .mkCertNode nid r sp claimed args =>
      .mkNode nid r.toCode sp claimed (lowerSegArgs args)
end

/-
  Full Structural Projection Faithfulness (`SegProjectionFaithful` & `NodeProjectionFaithful`):
  Enforces 1-to-1 preservation of parent-child tree structure, sibling order, rule codes,
  `SlotSort`, `SlotRole`, `entityId`, `lexeme`, `CodepointSpan`, and `ObligationToken`s
  (`oblId`, `locus`, `kind`, `target`).
-/
mutual
  def SegProjectionFaithful {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List UntrustedSegArg → Prop
    | [], [] => True
    | .litSpan txt sp :: restX, .litSpan pTxt pSp :: restP =>
      pTxt = txt ∧ pSp = sp ∧ SegProjectionFaithful restX restP
    | .certSlot s :: restX, .slotLeaf tok :: restP =>
      tok.sort = s.p2Sort ∧
      toP2SlotSort? s.p3Sort = some tok.sort ∧
      tok.role = s.p2Role ∧
      tok.entityId = s.entityId ∧
      tok.lexeme = s.lexeme ∧
      tok.span = s.span ∧
      SegProjectionFaithful restX restP
    | .childNode subX :: restX, .childNode subP :: restP =>
      NodeProjectionFaithful subX subP ∧ SegProjectionFaithful restX restP
    | _, _ => False

  def NodeProjectionFaithful {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → UntrustedDerivCert → Prop
    | .mkCertNode nid r sp claimed args, .mkNode pNid rawCode pSp pClaimed pArgs =>
      pNid = nid ∧
      decodeFrozenRule rawCode = some r ∧
      pSp = sp ∧
      pClaimed = claimed ∧
      SegProjectionFaithful args pArgs
end

/--
  **Top-Level `ProjectionFaithful x π` (`Gate D`)**:
  Combines full tree-structural faithfulness with global pre-order span-sequence and
  obligation-sequence preservation.
-/
def ProjectionFaithful {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
    (π : BrocaOmega.P2.UntrustedDerivCert) : Prop :=
  NodeProjectionFaithful x π ∧
  collectCertSpans x = collectP2Spans π ∧
  collectCertClaimedObls x = collectClaimedObls π

/- Computable boolean verifier for `ProjectionFaithful` (used in adversarial tamper tests). -/
mutual
  def checkSegProjectionFaithfulBool {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List UntrustedSegArg → Bool
    | [], [] => true
    | .litSpan txt sp :: restX, .litSpan pTxt pSp :: restP =>
      (pTxt == txt) && (pSp == sp) && checkSegProjectionFaithfulBool restX restP
    | .certSlot s :: restX, .slotLeaf tok :: restP =>
      (tok.sort == s.p2Sort) &&
      (toP2SlotSort? s.p3Sort == some tok.sort) &&
      (tok.role == s.p2Role) &&
      (tok.entityId == s.entityId) &&
      (tok.lexeme == s.lexeme) &&
      (tok.span == s.span) &&
      checkSegProjectionFaithfulBool restX restP
    | .childNode subX :: restX, .childNode subP :: restP =>
      checkNodeProjectionFaithfulBool subX subP && checkSegProjectionFaithfulBool restX restP
    | _, _ => false

  def checkNodeProjectionFaithfulBool {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → UntrustedDerivCert → Bool
    | .mkCertNode nid r sp claimed args, .mkNode pNid rawCode pSp pClaimed pArgs =>
      (pNid == nid) &&
      (decodeFrozenRule rawCode == some r) &&
      (pSp == sp) &&
      (pClaimed == claimed) &&
      checkSegProjectionFaithfulBool args pArgs
end

def checkProjectionFaithfulBool {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
    (π : BrocaOmega.P2.UntrustedDerivCert) : Bool :=
  checkNodeProjectionFaithfulBool x π &&
  (collectCertSpans x == collectP2Spans π) &&
  (collectCertClaimedObls x == collectClaimedObls π)

mutual
  theorem checkSegProjectionFaithfulBool_iff {cat numCfg maxSlotBytes}
      (xs : List (CertifiedSegArg cat numCfg maxSlotBytes)) (ps : List UntrustedSegArg) :
      checkSegProjectionFaithfulBool xs ps = true ↔ SegProjectionFaithful xs ps := by
    cases xs with
    | nil =>
      cases ps <;> simp [checkSegProjectionFaithfulBool, SegProjectionFaithful]
    | cons ax rx =>
      cases ps with
      | nil => simp [checkSegProjectionFaithfulBool, SegProjectionFaithful]
      | cons ap rp =>
        cases ax <;> cases ap <;>
          simp [checkSegProjectionFaithfulBool, SegProjectionFaithful, Bool.and_eq_true, beq_iff_eq, and_assoc]
        case litSpan.litSpan =>
          intro _ _; exact checkSegProjectionFaithfulBool_iff rx rp
        case certSlot.slotLeaf =>
          intro _ _ _ _ _ _; exact checkSegProjectionFaithfulBool_iff rx rp
        case childNode.childNode sx sp_sub =>
          rw [checkNodeProjectionFaithfulBool_iff sx sp_sub, checkSegProjectionFaithfulBool_iff rx rp]

  theorem checkNodeProjectionFaithfulBool_iff {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) (π : UntrustedDerivCert) :
      checkNodeProjectionFaithfulBool x π = true ↔ NodeProjectionFaithful x π := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        simp [checkNodeProjectionFaithfulBool, NodeProjectionFaithful,
              Bool.and_eq_true, beq_iff_eq, and_assoc, checkSegProjectionFaithfulBool_iff]
end

theorem checkProjectionFaithfulBool_iff {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) (π : UntrustedDerivCert) :
    checkProjectionFaithfulBool x π = true ↔ ProjectionFaithful x π := by
  unfold checkProjectionFaithfulBool ProjectionFaithful
  simp [Bool.and_eq_true, beq_iff_eq, and_assoc, checkNodeProjectionFaithfulBool_iff]

/-! ### 5. Structural Preservation Lemmas Under `NodeProjectionFaithful` & `lowerToP2Cert` -/

mutual
  theorem nodeProjectionFaithful_spans {cat numCfg maxSlotBytes}
      {xs : List (CertifiedSegArg cat numCfg maxSlotBytes)} {ps : List UntrustedSegArg}
      (h : SegProjectionFaithful xs ps) :
      collectCertSegSpans xs = collectP2SegSpans ps := by
    cases xs with
    | nil =>
      cases ps with
      | nil => rfl
      | cons _ _ => simp [SegProjectionFaithful] at h
    | cons ax rx =>
      cases ps with
      | nil => cases ax <;> simp [SegProjectionFaithful] at h
      | cons ap rp =>
        cases ax <;> cases ap
        case litSpan.litSpan txt sp pTxt pSp =>
          rcases h with ⟨_, rfl, hr⟩
          simp [collectCertSegSpans, collectP2SegSpans, nodeProjectionFaithful_spans hr]
        case certSlot.slotLeaf s tok =>
          rcases h with ⟨_, _, _, _, _, hsp, hr⟩
          simp [collectCertSegSpans, collectP2SegSpans, hsp, nodeProjectionFaithful_spans hr]
        case childNode.childNode sx sp_sub =>
          rcases h with ⟨hsub, hr⟩
          simp [collectCertSegSpans, collectP2SegSpans,
                treeProjectionFaithful_spans hsub, nodeProjectionFaithful_spans hr]
        all_goals exact False.elim h

  theorem treeProjectionFaithful_spans {cat numCfg maxSlotBytes}
      {x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes} {π : UntrustedDerivCert}
      (h : NodeProjectionFaithful x π) :
      collectCertSpans x = collectP2Spans π := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases h with ⟨_, _, rfl, _, hargs⟩
        simp [collectCertSpans, collectP2Spans, nodeProjectionFaithful_spans hargs]
end

mutual
  theorem segProjectionFaithful_obls {cat numCfg maxSlotBytes}
      {xs : List (CertifiedSegArg cat numCfg maxSlotBytes)} {ps : List UntrustedSegArg}
      (h : SegProjectionFaithful xs ps) :
      collectCertSegObls xs = collectSegClaimedObls ps := by
    cases xs with
    | nil =>
      cases ps with
      | nil => rfl
      | cons _ _ => simp [SegProjectionFaithful] at h
    | cons ax rx =>
      cases ps with
      | nil => cases ax <;> simp [SegProjectionFaithful] at h
      | cons ap rp =>
        cases ax <;> cases ap
        case litSpan.litSpan =>
          rcases h with ⟨_, _, hr⟩
          simpa [collectCertSegObls, collectSegClaimedObls] using segProjectionFaithful_obls hr
        case certSlot.slotLeaf =>
          rcases h with ⟨_, _, _, _, _, _, hr⟩
          simpa [collectCertSegObls, collectSegClaimedObls] using segProjectionFaithful_obls hr
        case childNode.childNode sx sp_sub =>
          rcases h with ⟨hsub, hr⟩
          simp [collectCertSegObls, collectSegClaimedObls,
                treeProjectionFaithful_obls hsub, segProjectionFaithful_obls hr]
        all_goals exact False.elim h

  theorem treeProjectionFaithful_obls {cat numCfg maxSlotBytes}
      {x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes} {π : UntrustedDerivCert}
      (h : NodeProjectionFaithful x π) :
      collectCertClaimedObls x = collectClaimedObls π := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases h with ⟨_, _, _, rfl, hargs⟩
        simp [collectCertClaimedObls, collectClaimedObls, segProjectionFaithful_obls hargs]
end

mutual
  theorem segProjectionFaithful_yield {cat numCfg maxSlotBytes}
      {xs : List (CertifiedSegArg cat numCfg maxSlotBytes)} {ps : List UntrustedSegArg}
      (h : SegProjectionFaithful xs ps) :
      reconstructCertSegChars xs = reconstructSegYield ps := by
    cases xs with
    | nil =>
      cases ps with
      | nil => rfl
      | cons _ _ => simp [SegProjectionFaithful] at h
    | cons ax rx =>
      cases ps with
      | nil => cases ax <;> simp [SegProjectionFaithful] at h
      | cons ap rp =>
        cases ax <;> cases ap
        case litSpan.litSpan =>
          rcases h with ⟨rfl, _, hr⟩
          simp [reconstructCertSegChars, reconstructSegYield, segProjectionFaithful_yield hr]
        case certSlot.slotLeaf =>
          rcases h with ⟨_, _, _, _, hlex, _, hr⟩
          simp [reconstructCertSegChars, reconstructSegYield, hlex, segProjectionFaithful_yield hr]
        case childNode.childNode sx sp_sub =>
          rcases h with ⟨hsub, hr⟩
          simp [reconstructCertSegChars, reconstructSegYield,
                treeProjectionFaithful_yield hsub, segProjectionFaithful_yield hr]
        all_goals exact False.elim h

  theorem treeProjectionFaithful_yield {cat numCfg maxSlotBytes}
      {x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes} {π : UntrustedDerivCert}
      (h : NodeProjectionFaithful x π) :
      reconstructCertChars x = reconstructYieldChars π := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases h with ⟨_, _, _, _, hargs⟩
        simp [reconstructCertChars, reconstructYieldChars, segProjectionFaithful_yield hargs]
end

mutual
  theorem lowerSegArgs_faithful {cat numCfg maxSlotBytes}
      (args : List (CertifiedSegArg cat numCfg maxSlotBytes)) :
      SegProjectionFaithful args (lowerSegArgs args) := by
    cases args with
    | nil => trivial
    | cons a rest =>
      cases a with
      | litSpan txt sp =>
        exact ⟨rfl, rfl, lowerSegArgs_faithful rest⟩
      | certSlot s =>
        exact ⟨rfl, s.hSortProj, rfl, rfl, rfl, rfl, lowerSegArgs_faithful rest⟩
      | childNode sub =>
        exact ⟨lowerNode_faithful sub, lowerSegArgs_faithful rest⟩

  theorem lowerNode_faithful {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) :
      NodeProjectionFaithful x (lowerToP2Cert x) := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      exact ⟨rfl, decode_toCode_id r, rfl, rfl, lowerSegArgs_faithful args⟩
end

/-- **Gate D.1 (`lowerToP2Cert_projectionFaithful`)**: `lowerToP2Cert x` ALWAYS satisfies `ProjectionFaithful`! -/
theorem lowerToP2Cert_projectionFaithful {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) :
    ProjectionFaithful x (lowerToP2Cert x) := by
  have hn := lowerNode_faithful x
  exact ⟨hn, treeProjectionFaithful_spans hn, treeProjectionFaithful_obls hn⟩

/-! ### 6. Core Inductive Lifting Theorems (`P2` Replay + `ProjectionFaithful` ⟹ `P3-B` `ValidParseNode` & `LocusTargetBoundOnCert`) -/

mutual
  theorem lift_synthSlotsSums {cat numCfg maxSlotBytes}
      (args : List (CertifiedSegArg cat numCfg maxSlotBytes))
      {pArgs : List UntrustedSegArg} {segs : List RuleSegment}
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (hfaith : SegProjectionFaithful args pArgs)
      (hsynth : synthSegSlotsSums segs pArgs = some (slots, sums)) :
      synthCertSegSlotsSums args segs = some (mapP2Slots slots, sums.map mapP2Summary) := by
    cases args with
    | nil =>
      cases pArgs with
      | nil =>
        cases segs with
        | nil =>
          simp [synthSegSlotsSums] at hsynth
          rcases hsynth with ⟨rfl, rfl⟩
          rfl
        | cons _ _ => simp [synthSegSlotsSums] at hsynth
      | cons _ _ => simp [SegProjectionFaithful] at hfaith
    | cons ax rx =>
      cases pArgs with
      | nil => cases ax <;> simp [SegProjectionFaithful] at hfaith
      | cons ap rp =>
        cases segs with
        | nil => simp [synthSegSlotsSums] at hsynth
        | cons seg rsegs =>
          cases ax <;> cases ap
          case litSpan.litSpan =>
            rcases hfaith with ⟨_, _, hrf⟩
            cases seg with
            | lit _ =>
              simpa [synthCertSegSlotsSums, synthSegSlotsSums] using lift_synthSlotsSums rx hrf hsynth
            | slot _ _ => simp [synthSegSlotsSums] at hsynth
            | child _ _ => simp [synthSegSlotsSums] at hsynth
          case certSlot.slotLeaf s tok =>
            rcases hfaith with ⟨_, _, _, heid, _, _, hrf⟩
            cases seg with
            | lit _ => simp [synthSegSlotsSums] at hsynth
            | child _ _ => simp [synthSegSlotsSums] at hsynth
            | slot expectedSort expectedRole =>
              unfold synthSegSlotsSums at hsynth
              cases hrec : synthSegSlotsSums rsegs rp with
              | none => rw [hrec] at hsynth; contradiction
              | some pair =>
                rw [hrec] at hsynth
                rcases pair with ⟨rSlots, rSums⟩
                dsimp at hsynth
                injection hsynth with hp
                injection hp with hsl hsm
                subst slots; subst sums
                have hih := lift_synthSlotsSums rx hrf hrec
                simp [synthCertSegSlotsSums, hih, mapP2Slots, heid]
          case childNode.childNode subX subP =>
            rcases hfaith with ⟨hsubf, hrf⟩
            cases seg with
            | lit _ => simp [synthSegSlotsSums] at hsynth
            | slot _ _ => simp [synthSegSlotsSums] at hsynth
            | child _ _ =>
              unfold synthSegSlotsSums at hsynth
              cases hsub_s : synthNodeSummary subP with
              | none => rw [hsub_s] at hsynth; contradiction
              | some subSum =>
                rw [hsub_s] at hsynth
                cases hrec : synthSegSlotsSums rsegs rp with
                | none => rw [hrec] at hsynth; contradiction
                | some pair =>
                  rw [hrec] at hsynth
                  rcases pair with ⟨rSlots, rSums⟩
                  dsimp at hsynth
                  injection hsynth with hp
                  injection hp with hsl hsm
                  subst slots; subst sums
                  have hsub_ih := lift_synthNodeSummary subX hsubf hsub_s
                  have hrec_ih := lift_synthSlotsSums rx hrf hrec
                  simp [synthCertSegSlotsSums, hsub_ih, hrec_ih]
          all_goals exact False.elim hfaith

  theorem lift_synthNodeSummary {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
      {π : UntrustedDerivCert} {sum : NodeSummary}
      (hfaith : NodeProjectionFaithful x π)
      (hsynth : synthNodeSummary π = some sum) :
      synthCertNodeSummary x = some (mapP2Summary sum) := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases hfaith with ⟨_, hdec, _, _, hargs⟩
        unfold synthNodeSummary at hsynth
        rw [hdec] at hsynth
        dsimp at hsynth
        cases hseg : synthSegSlotsSums (ruleSignature r).segments pArgs with
        | none => rw [hseg] at hsynth; contradiction
        | some pair =>
          rw [hseg] at hsynth
          rcases pair with ⟨slots, sums⟩
          dsimp at hsynth
          injection hsynth with hsum
          subst sum
          have hih := lift_synthSlotsSums args hargs hseg
          simp [synthCertNodeSummary, hih, fromP2Rule_mkSum_eq_mapP2Summary]
end

mutual
  theorem lift_segLocusBound {cat numCfg maxSlotBytes}
      (args : List (CertifiedSegArg cat numCfg maxSlotBytes))
      {pArgs : List UntrustedSegArg} {loc : ClauseLocus} {segs : List RuleSegment}
      (hfaith : SegProjectionFaithful args pArgs)
      (hlb : SegLocusTargetBound loc segs pArgs) :
      CertSegLocusTargetBound args loc segs := by
    cases args with
    | nil =>
      cases pArgs with
      | nil =>
        cases segs with
        | nil => trivial
        | cons sg _ => cases sg <;> simp [SegLocusTargetBound] at hlb
      | cons _ _ => simp [SegProjectionFaithful] at hfaith
    | cons ax rx =>
      cases pArgs with
      | nil => cases ax <;> simp [SegProjectionFaithful] at hfaith
      | cons ap rp =>
        cases segs with
        | nil => simp [SegLocusTargetBound] at hlb
        | cons seg rsegs =>
          cases ax <;> cases ap
          case litSpan.litSpan =>
            rcases hfaith with ⟨_, _, hrf⟩
            cases seg with
            | lit _ => exact lift_segLocusBound rx hrf hlb
            | slot _ _ => exact False.elim hlb
            | child _ _ => exact False.elim hlb
          case certSlot.slotLeaf =>
            rcases hfaith with ⟨_, _, _, _, _, _, hrf⟩
            cases seg with
            | slot _ _ => exact lift_segLocusBound rx hrf hlb
            | lit _ => exact False.elim hlb
            | child _ _ => exact False.elim hlb
          case childNode.childNode subX subP =>
            rcases hfaith with ⟨hsubf, hrf⟩
            cases seg with
            | child _ locOpt =>
              rcases hlb with ⟨hsub_lb, hrest_lb⟩
              exact ⟨lift_nodeLocusBound subX hsubf hsub_lb, lift_segLocusBound rx hrf hrest_lb⟩
            | lit _ => exact False.elim hlb
            | slot _ _ => exact False.elim hlb
          all_goals exact False.elim hfaith

  theorem lift_nodeLocusBound {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
      {π : UntrustedDerivCert} {loc : ClauseLocus}
      (hfaith : NodeProjectionFaithful x π)
      (hlb : NodeLocusTargetBound loc π) :
      CertNodeLocusTargetBound x loc := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases hfaith with ⟨_, hdec, _, rfl, hargs⟩
        rcases hlb with ⟨r', slots, sums, hdec', hsynth, hobls, hloc_mem, hseg_lb⟩
        rw [hdec] at hdec'
        injection hdec' with hr_eq
        subst r'
        refine ⟨mapP2Slots slots, sums.map mapP2Summary,
                lift_synthSlotsSums args hargs hsynth, ?_, hloc_mem,
                lift_segLocusBound args hargs hseg_lb⟩
        rw [f_p3a_01_universal_intrinsicObls_equivalence r loc slots sums]
        exact hobls
end

mutual
  theorem lift_validSegChain_to_validParseSegs {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {cursor endPos : Nat}
      (args : List (CertifiedSegArg cat numCfg Y.length))
      {pArgs : List UntrustedSegArg} {segs : List RuleSegment}
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (hfaith : SegProjectionFaithful args pArgs)
      (hchain : ValidSegChain env Y loc cursor segs pArgs endPos slots sums) :
      ValidParseSegs cat numCfg env Y loc cursor
        (segs.map fromP2RuleSegment) (certSegsToParseArgs args loc segs)
        endPos (mapP2Slots slots) (sums.map mapP2Summary) := by
    cases args with
    | nil =>
      cases pArgs with
      | nil =>
        cases segs with
        | nil =>
          rcases hchain with ⟨hle, hend, rfl, rfl⟩
          exact ⟨hle, hend, rfl, rfl⟩
        | cons sg _ => cases sg <;> simp [ValidSegChain] at hchain
      | cons _ _ => simp [SegProjectionFaithful] at hfaith
    | cons ax rx =>
      cases pArgs with
      | nil => cases ax <;> simp [SegProjectionFaithful] at hfaith
      | cons ap rp =>
        cases segs with
        | nil => simp [ValidSegChain] at hchain
        | cons seg rsegs =>
          cases ax <;> cases ap
          case litSpan.litSpan txt sp pTxt pSp =>
            rcases hfaith with ⟨rfl, rfl, hrf⟩
            cases seg with
            | lit expectedLit =>
              rcases hchain with ⟨htxt, hstart, hsp, hrest⟩
              exact ⟨htxt, hstart, hsp, lift_validSegChain_to_validParseSegs rx hrf hrest⟩
            | slot _ _ => exact False.elim hchain
            | child _ _ => exact False.elim hchain
          case certSlot.slotLeaf s tok =>
            rcases hfaith with ⟨hsort_tok, hsort_p3, hrole_tok, heid_tok, hlex_tok, hsp_tok, hrf⟩
            cases seg with
            | lit _ => exact False.elim hchain
            | child _ _ => exact False.elim hchain
            | slot expectedSort expectedRole =>
              rcases hchain with ⟨rSlots, htok_s, htok_r, _, hstart, hsp, hslots_eq, hrest⟩
              subst slots
              have hp3_eq : s.p3Sort = fromP2SlotSort expectedSort := by
                rw [htok_s] at hsort_p3
                exact fromP2_of_toP2Sort hsort_p3
              have hrole_eq : s.p2Role = expectedRole := by
                rw [← hrole_tok, htok_r]
              rw [hsp_tok] at hstart hsp hrest
              rw [hlex_tok] at hsp
              have hdsv : DeclarativeSlotValid cat numCfg Y.length (fromP2SlotSort expectedSort) s.entityId s.lexeme := by
                rw [← hp3_eq]
                exact certifiedBridgeSlot_declarativeValid s
              refine ⟨mapP2Slots rSlots, hp3_eq, congrArg fromP2SlotRole hrole_eq,
                      hstart, hsp, hdsv, ?_, lift_validSegChain_to_validParseSegs rx hrf hrest⟩
              simp [mapP2Slots, heid_tok]
          case childNode.childNode subX subP =>
            rcases hfaith with ⟨hsubf, hrf⟩
            cases seg with
            | lit _ => exact False.elim hchain
            | slot _ _ => exact False.elim hchain
            | child childCat locOpt =>
              rcases hchain with ⟨subSum, rSums, hstart, hsub_deriv, hsums_eq, hrest⟩
              subst sums
              have hsub_parse := lift_validNodeDeriv_to_validParseNode subX hsubf hsub_deriv
              have hloc_eq : (clauseOverrideOfIdx (fromP2LocusOpt locOpt)).getD loc = locOpt.getD loc := by
                rw [clauseOverrideOfIdx_fromP2LocusOpt]
              cases subX with
              | mkCertNode sNid sR sSp sCl sArgs =>
                cases subP with
                | mkNode pNid pRc pSp pCl pArgs_sub =>
                  rcases hsubf with ⟨_, _, rfl, _, _⟩
                  dsimp [certTreeToParseTree, ConcreteParseTree.span] at hstart hrest hsub_parse ⊢
                  refine ⟨mapP2Summary subSum, rSums.map mapP2Summary, hstart, ?_, rfl,
                          lift_validSegChain_to_validParseSegs rx hrf hrest⟩
                  rw [hloc_eq]
                  exact hsub_parse
          all_goals exact False.elim hfaith

  theorem lift_validNodeDeriv_to_validParseNode {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {expectedCat : NontermCat}
      (x : LexicallyCertifiedDerivTree cat numCfg Y.length)
      {π : UntrustedDerivCert} {outSum : NodeSummary}
      (hfaith : NodeProjectionFaithful x π)
      (hderiv : ValidNodeDeriv env Y loc expectedCat π outSum) :
      ValidParseNode cat numCfg env Y loc (fromP2Nonterm expectedCat)
        (certTreeToParseTree x loc) (mapP2Summary outSum) := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases hfaith with ⟨_, hdec, rfl, _, hargs⟩
        rcases hderiv with ⟨r', slots, sums, hdec', hlhs, hsegs, hside, _, hout⟩
        rw [hdec] at hdec'
        injection hdec' with hr_eq
        subst r'; subst outSum
        have ⟨hlhs_corr, hrhs_corr⟩ := f_p3a_01_p2_ruleSignature_matches_p3b_interleaved r
        have hsegs_parse := lift_validSegChain_to_validParseSegs args hargs hsegs
        rw [hrhs_corr] at hsegs_parse
        have hside_parse : (frozenProdSig (fromP2Rule r)).checkSide env (mapP2Slots slots) (sums.map mapP2Summary) = true := by
          rw [f_p3a_01_universal_sidecond_equivalence r env slots sums]
          exact hside
        have halt_le : 1 ≤ (fromP2Rule r).altCount := by
          rw [fromP2Rule_altCount_eq_one r]; decide
        refine ⟨mapP2Slots slots, sums.map mapP2Summary, rfl, ?_, by decide, halt_le,
                hsegs_parse, hside_parse, ?_⟩
        · rw [← hlhs_corr, hlhs]
        · exact (fromP2Rule_mkSum_eq_mapP2Summary r slots sums).symm
end

/-! ### 7. Master Gate D Theorems (`BridgeSound` & End-to-End 3-Module Unification) -/

/--
  **Master Theorem `BridgeSound` (`Gate D`)**:
  Directly connects `BrocaOmega.P3A.CertifiedLexicalSlot`, `ProjectionFaithful x π`, and
  `BrocaOmega.P2.replayDerivation env Y deltaIn π = .accepted wP2`, lifting ALL lexical,
  grammatical, span-yield, locus-target, and linear multiset guarantees back onto the
  ORIGINAL `x : LexicallyCertifiedDerivTree`!
-/
theorem BridgeSound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (x : LexicallyCertifiedDerivTree cat numCfg Y.toList.length)
    (π : BrocaOmega.P2.UntrustedDerivCert)
    (wP2 : BrocaOmega.P2.CertifiedDerivation env Y deltaIn)
    (hFaithful : ProjectionFaithful x π)
    (hReplay : BrocaOmega.P2.replayDerivation env Y deltaIn π = .accepted wP2) :
    let τ_x := certTreeToParseTree x .clause1
    AllTreeSlotsP3ACertified x ∧
    reconstructCertYield x = Y ∧
    ObligationsConservedOnCert x deltaIn ∧
    LocusTargetBoundOnCert x ∧
    collectCertSpans x = collectP2Spans π ∧
    (frozenProdSig τ_x.prod).isGenerator = true ∧
    τ_x.span = ⟨0, Y.toList.length⟩ ∧
    (∃ sum3 : ParseSummary,
      ValidParseNode cat numCfg env Y.toList .clause1 .controlledDocument τ_x sum3) := by
  rcases BrocaOmega.P2.replayDerivation_sound env Y deltaIn π wP2 hReplay with
    ⟨_, hValidDeriv, hYieldP2, hOblP2, hLocusP2⟩
  rcases hFaithful with ⟨hNodeF, hSpansEq, hOblsEq⟩
  have hYieldX : reconstructCertYield x = Y := by
    unfold reconstructCertYield
    rw [treeProjectionFaithful_yield hNodeF]
    exact hYieldP2
  have hOblX : ObligationsConservedOnCert x deltaIn := by
    rcases hOblP2 with ⟨hnd1, hnd2, hms⟩
    unfold ObligationsConservedOnCert
    rw [hOblsEq]
    exact ⟨hnd1, hnd2, hms⟩
  have hLocusX : LocusTargetBoundOnCert x :=
    lift_nodeLocusBound x hNodeF hLocusP2
  rcases hValidDeriv with ⟨hRootSp, sum2, hNodeDeriv⟩
  have hParseNode := lift_validNodeDeriv_to_validParseNode x hNodeF hNodeDeriv
  have hGenAndSp :
      (frozenProdSig (certTreeToParseTree x .clause1).prod).isGenerator = true ∧
      (certTreeToParseTree x .clause1).span = ⟨0, Y.toList.length⟩ := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases hNodeF with ⟨_, _, hpSp, _, _⟩
        dsimp at hRootSp
        rw [hpSp] at hRootSp
        exact ⟨fromP2Rule_isGenerator r, hRootSp⟩
  exact ⟨allTreeSlots_hold x, hYieldX, hOblX, hLocusX, hSpansEq,
         hGenAndSp.1, hGenAndSp.2, mapP2Summary sum2, hParseNode⟩

/--
  **3-Module End-to-End Unification Theorem (`BridgeSound_mem_enumerated_forest`)**:
  Combines:
  1. `P3-A` raw-byte ingress (`admitStrictAsciiIngress`) + `CertifiedLexicalSlot` slot witnesses on `x`,
  2. `ProjectionFaithful x π`,
  3. `P2` derivation replay (`replayDerivation env wIng.decoded deltaIn π = .accepted wP2`), AND
  4. `P3-B` bounded exhaustive parsing (`parseAllBounded ... rawBytes = .enumerated T`),
  proving `ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree x .clause1)` AND
  membership `certTreeToParseTree x .clause1 ∈ T`!
-/
theorem BridgeSound_mem_enumerated_forest
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget)
    (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (wIng : BrocaOmega.P3A.VerifiedIngressText maxIngressBytes)
    (hIng : BrocaOmega.P3A.admitStrictAsciiIngress maxIngressBytes rawBytes = .ok wIng)
    (deltaIn : List ObligationToken)
    (x : LexicallyCertifiedDerivTree cat numCfg wIng.decoded.toList.length)
    (π : BrocaOmega.P2.UntrustedDerivCert)
    (wP2 : BrocaOmega.P2.CertifiedDerivation env wIng.decoded deltaIn)
    (hFaithful : ProjectionFaithful x π)
    (hReplay : BrocaOmega.P2.replayDerivation env wIng.decoded deltaIn π = .accepted wP2) :
    let τ_x := certTreeToParseTree x .clause1
    ValidParse_GFrozen cat numCfg env rawBytes τ_x ∧
    (∀ T : List ConcreteParseTree,
      parseAllBounded cat numCfg env budget rawBytes = .enumerated T → τ_x ∈ T) := by
  have ⟨hRawEq, hStrict⟩ := BrocaOmega.P3A.admitStrictAsciiIngress_sound maxIngressBytes rawBytes wIng hIng
  have hDom : StrictAsciiDomainSupported rawBytes := ⟨hStrict.1, hStrict.2.2⟩
  have hbs := BridgeSound cat numCfg env wIng.decoded deltaIn x π wP2 hFaithful hReplay
  rcases hbs with ⟨_, _, _, _, _, _, hSp, sum3, hParseNode⟩
  have hDecEq : wIng.decoded = decodeAsciiBytes rawBytes := by
    rw [wIng.hDecoded, hRawEq]
  have hValidGF : ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree x .clause1) := by
    unfold ValidParse_GFrozen
    rw [← hDecEq]
    exact ⟨hDom, hSp, sum3, hParseNode⟩
  refine ⟨hValidGF, ?_⟩
  intro T henum
  exact ((parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes T henum).2.2.2.2 _).mpr hValidGF

/-! ### 8. Executable End-to-End Slot-Certification + Replay Gate (`verifyBridgedDerivation`) -/

inductive BridgeRejectDiag where
  | ingressRejected       (diag : LexicalRejectDiag)
  | forgedOrTrapRuleCode  (nodeId rawRuleCode : Nat)
  | nonAsciiSlotLexeme    (nodeId : Nat) (lexeme : String)
  | slotLexicalRejected   (nodeId : Nat) (diag : LexicalRejectDiag)
  | projectionTampered
  | p2ReplayRejected      (diag : CEGESReplayDiag)
  deriving DecidableEq, Repr

/-- Certifies a single untrusted `P2.SlotToken` through `BrocaOmega.P3A.admitLexicalSlot`! -/
def certifySlotToken (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (nodeId : Nat) (tok : SlotToken) :
    Except BridgeRejectDiag (CertifiedBridgeSlot cat numCfg maxSlotBytes) :=
  let p3s := fromP2SlotSort tok.sort
  let cand : RawSlotCandidate :=
    { sort := p3s, entityId := tok.entityId, rawBytes := strToAsciiBytes tok.lexeme }
  if hdec_b : eqStrBool cand.decodedStr tok.lexeme = true then
    match BrocaOmega.P3A.admitLexicalSlot cat numCfg maxSlotBytes cand with
    | .rejected d => .error (.slotLexicalRejected nodeId d)
    | .accepted w =>
      .ok { lexeme     := tok.lexeme
            entityId   := tok.entityId
            p3Sort     := p3s
            p2Sort     := tok.sort
            p2Role     := tok.role
            span       := tok.span
            witness    := w
            hDecodedEq := (eqStrBool_iff cand.decodedStr tok.lexeme).mp hdec_b
            hSortProj  := toP2SlotSort_fromP2SlotSort tok.sort }
  else
    .error (.nonAsciiSlotLexeme nodeId tok.lexeme)

mutual
  def certifySegArgs (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (maxSlotBytes : Nat) (nodeId : Nat) :
      List UntrustedSegArg →
      Except BridgeRejectDiag (List (CertifiedSegArg cat numCfg maxSlotBytes))
    | [] => .ok []
    | .litSpan txt sp :: rest =>
      match certifySegArgs cat numCfg maxSlotBytes nodeId rest with
      | .error e => .error e
      | .ok rCert => .ok (.litSpan txt sp :: rCert)
    | .slotLeaf tok :: rest =>
      match certifySlotToken cat numCfg maxSlotBytes nodeId tok with
      | .error e => .error e
      | .ok sCert =>
        match certifySegArgs cat numCfg maxSlotBytes nodeId rest with
        | .error e => .error e
        | .ok rCert => .ok (.certSlot sCert :: rCert)
    | .childNode sub :: rest =>
      match certifyDerivTree cat numCfg maxSlotBytes sub with
      | .error e => .error e
      | .ok subCert =>
        match certifySegArgs cat numCfg maxSlotBytes nodeId rest with
        | .error e => .error e
        | .ok rCert => .ok (.childNode subCert :: rCert)

  /--
    Walks an untrusted `UntrustedDerivCert` and enforces `BrocaOmega.P3A.admitLexicalSlot`
    on EVERY slot leaf before constructing `LexicallyCertifiedDerivTree`.
  -/
  def certifyDerivTree (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (maxSlotBytes : Nat) :
      UntrustedDerivCert →
      Except BridgeRejectDiag (LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
    | .mkNode nid rawCode sp claimed args =>
      match decodeFrozenRule rawCode with
      | none => .error (.forgedOrTrapRuleCode nid rawCode)
      | some r =>
        match certifySegArgs cat numCfg maxSlotBytes nid args with
        | .error e => .error e
        | .ok certArgs => .ok (.mkCertNode nid r sp claimed certArgs)
end

/-- Sealed end-to-end witness combining `P3-A`, `ProjectionFaithful`, `P2` Replay, and `P3-B` `ValidParse_GFrozen`. -/
structure CertifiedBridgedDerivation (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (deltaIn : List ObligationToken) where
  private mk ::
  ingressWitness : BrocaOmega.P3A.VerifiedIngressText maxIngressBytes
  certTree       : LexicallyCertifiedDerivTree cat numCfg ingressWitness.decoded.toList.length
  loweredCert    : BrocaOmega.P2.UntrustedDerivCert
  replayWitness  : BrocaOmega.P2.CertifiedDerivation env ingressWitness.decoded deltaIn
  hFaithful      : ProjectionFaithful certTree loweredCert
  hSlotsValid    : AllTreeSlotsP3ACertified certTree
  hYieldEq       : reconstructCertYield certTree = ingressWitness.decoded
  hOblConserved  : ObligationsConservedOnCert certTree deltaIn
  hLocusBound    : LocusTargetBoundOnCert certTree
  hValidParse    : ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree certTree .clause1)

/--
  **End-to-End Bridged Verification Gate (`verifyBridgedDerivation`)**:
  1. Validates `rawBytes` via `BrocaOmega.P3A.admitStrictAsciiIngress`.
  2. Certifies all slots of `rawCandidate` via `BrocaOmega.P3A.admitLexicalSlot` (`certifyDerivTree`).
  3. Lowers `certTree` via `lowerToP2Cert` (preserving `ProjectionFaithful`) AND verifies
     `checkProjectionFaithfulBool certTree rawCandidate` so any projection tampering is rejected!
  4. Replays `loweredCert` via `BrocaOmega.P2.replayDerivation`.
-/
def verifyBridgedDerivation
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (deltaIn : List ObligationToken) (rawCandidate : BrocaOmega.P2.UntrustedDerivCert) :
    Except BridgeRejectDiag (CertifiedBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn) :=
  match hIng : BrocaOmega.P3A.admitStrictAsciiIngress maxIngressBytes rawBytes with
  | .error d => .error (.ingressRejected d)
  | .ok wIng =>
    match certifyDerivTree cat numCfg wIng.decoded.toList.length rawCandidate with
    | .error e => .error e
    | .ok x =>
      if checkProjectionFaithfulBool x rawCandidate then
        let π := lowerToP2Cert x
        let hFaith := lowerToP2Cert_projectionFaithful x
        match hRep : BrocaOmega.P2.replayDerivation env wIng.decoded deltaIn π with
        | .rejected d => .error (.p2ReplayRejected d)
        | .accepted wP2 =>
          let hbs := BridgeSound cat numCfg env wIng.decoded deltaIn x π wP2 hFaith hRep
          let hgf := (BridgeSound_mem_enumerated_forest cat numCfg env defaultParseBudget
                        maxIngressBytes rawBytes wIng hIng deltaIn x π wP2 hFaith hRep).1
          .ok ⟨wIng, x, π, wP2, hFaith, hbs.1, hbs.2.1, hbs.2.2.1, hbs.2.2.2.1, hgf⟩
      else
        .error .projectionTampered

theorem verifyBridgedDerivation_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (deltaIn : List ObligationToken) (rawCandidate : BrocaOmega.P2.UntrustedDerivCert)
    (w : CertifiedBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn)
    (_hok : verifyBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn rawCandidate = .ok w) :
    ProjectionFaithful w.certTree w.loweredCert ∧
    AllTreeSlotsP3ACertified w.certTree ∧
    reconstructCertYield w.certTree = w.ingressWitness.decoded ∧
    ObligationsConservedOnCert w.certTree deltaIn ∧
    LocusTargetBoundOnCert w.certTree ∧
    ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree w.certTree .clause1) :=
  ⟨w.hFaithful, w.hSlotsValid, w.hYieldEq, w.hOblConserved, w.hLocusBound, w.hValidParse⟩

end BrocaOmega.P3B
````

### File 9: `03_counterexamples/P3BCounterexamples.lean` (SHA-256: `575E0CE7C3DA45B03F380EFA708D58DEED51B06F72922CC1E1AB989CE717F592`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` & `BridgeSound`)
  03_counterexamples/P3BCounterexamples.lean
-/
import P3BCounterexamples.P3BSuite
````

### File 10: `03_counterexamples/P3BCounterexamples/P3BSuite.lean` (SHA-256: `28DBABEEC365916CC8973A85D89EAB516F660C6C66DFAB0139F23F1BF207B3F0`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`Gate C.4` Non-Vacuity & `Gate E` Counterexample Suite)
  03_counterexamples/P3BCounterexamples/P3BSuite.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  Verifies 28 curated positive controls & adversarial counterexamples via Lean's kernel `decide`:
    - Positive non-vacuity parses across `G-01`, `G-03`, `G-09`, `G-15b`, `G-16` (`|T| = 1`)
    - Multi-reading trap preservation (`T2` `|T| = 2` `[alt=1, alt=2]`, `T1` `|T| = 2`, `T4` `|T| = 2`,
      plus `T3` and `T5` parser-only traps)
    - Strict 3-state separation:
        * `enumerated []` on in-domain grammatically/lexically/side-condition invalid inputs
        * `outOfDomain` on empty / non-7-bit-ASCII inputs
        * `resourceOverflow` on all 4 `ResourceBudget` bounds (`maxBytes`, `maxSteps`, `maxForestNodes`,
          and `maxReadings = 1` on `T2` proving non-truncation fail-closed!)
    - End-to-end `BridgeSound` & `ProjectionFaithful` verification (`verifyBridgedDerivation` accepting
      valid `P3-A` + `P2` certificates while blocking `1..25` multi-dot bypass, `entityId` spoofing,
      `T2` trap rule injection, and projection tampering).
-/
import P3BDetachedChecker

namespace BrocaOmega.P3B.Counterexamples

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B

/-! ### 1. Reference Closed Entity Catalog & Scope Environments (Strictly Within `R0` Sorts) -/

/-- Clean catalog obeying `F-R2.2-02` Global Canonical Surface Injectivity (`checkValidEntityCatalogBool = true`). -/
def strictTestCatalog : ClosedEntityCatalog :=
  { entries :=
      [ { sort := .cohortSpec,       entityId := "coh_primary", lexeme := "the primary cohort" },
        { sort := .designNoun,       entityId := "des_study",   lexeme := "study" },
        { sort := .followUpWindow,   entityId := "win_12m",     lexeme := "12 months" },
        { sort := .eventTerm,        entityId := "ev_stroke",   lexeme := "stroke" },
        { sort := .eventTerm,        entityId := "ev_aki",      lexeme := "acute kidney injury" },
        { sort := .expLevel,         entityId := "exp_intens",  lexeme := "intensive therapy" },
        { sort := .expLevel,         entityId := "exp_std",     lexeme := "standard care" },
        { sort := .outTerm,          entityId := "out_mi",      lexeme := "myocardial infarction" },
        { sort := .outTerm,          entityId := "out_death",   lexeme := "all-cause mortality" },
        { sort := .sourceId,         entityId := "src_trialA",  lexeme := "Trial-A" },
        { sort := .subgroupPlural,   entityId := "sub_dm_pl",   lexeme := "diabetic" },
        { sort := .subgroupSingular, entityId := "sub_hr_sg",   lexeme := "high-risk" } ] }

theorem strictTestCatalog_valid :
    ValidEntityCatalog strictTestCatalog :=
  (checkValidEntityCatalogBool_iff strictTestCatalog).mp (by decide)

def envAtomic : ScopeEnv :=
  { cohortId := "coh_primary", expectedDesignHead := "des_study", quoteIsolation := .sentenceAtomic }

def envDiscourse : ScopeEnv :=
  { cohortId := "coh_primary", expectedDesignHead := "des_study", quoteIsolation := .discourseBound }

/-! ### 2. Canonical Reading Signature Extractor for `ConcreteParseTree` -/

mutual
  def findPrimaryReadingSegs : List ConcreteParseArg → Option (CanonicalRuleId × Nat × Bool)
    | [] => none
    | .litTok _ _ :: rest => findPrimaryReadingSegs rest
    | .slotTok _ _ _ _ _ :: rest => findPrimaryReadingSegs rest
    | .childSub sub :: rest =>
      match extractPrimaryReading sub with
      | some r => some r
      | none   => findPrimaryReadingSegs rest

  /-- Extracts `(canonicalOwnerRule, readingAlt, isGenerator)` of the primary rule node in pre-order. -/
  def extractPrimaryReading : ConcreteParseTree → Option (CanonicalRuleId × Nat × Bool)
    | .mkTree p alt _ _ args =>
      let sig := frozenProdSig p
      match sig.ownerRule with
      | some r => some (r, alt, sig.isGenerator)
      | none   => findPrimaryReadingSegs args
end

def runParserOnStr (env : ScopeEnv) (budget : ResourceBudget) (s : String) : BoundedParseResult :=
  parseAllBounded strictTestCatalog frozenR22NumericConfig env budget (strToAsciiBytes s)

/-! ### 3. Concrete Non-Vacuity Theorems (`Gate C.4` — Kernel-Proved via `decide`) -/

def sG01 : String :=
  "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%)."

def sG03 : String :=
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."

def sG09 : String :=
  "In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."

def sG15b : String :=
  "In the primary cohort, no diabetic patients developed stroke. Within this same study, at least one high-risk patient developed acute kidney injury."

def sG16 : String :=
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."

/-- Mandatory `T2` Dual-Reading Sentence (`Y_T08` from `Architecture Freeze R0` / `P0-A05`). -/
def sT2_DualReading : String :=
  "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction."

def sT1_DualReading : String :=
  "In the primary cohort, all diabetic patients did not develop stroke."

def sT3_WhTrap : String :=
  "In the primary cohort, the analysis of Trial-A did not determine why intensive therapy reduces myocardial infarction."

def sT4_DualReading : String :=
  "In the primary cohort, diabetic patients developed stroke."

def sT5_Unscoped : String :=
  "no diabetic patients developed stroke."

def checkSingleGeneratorParse (env : ScopeEnv) (s : String) (expectedRule : CanonicalRuleId) : Bool :=
  match runParserOnStr env defaultParseBudget s with
  | .enumerated [t] =>
    eqStrBool (reconstructParseYield t) s &&
    (extractPrimaryReading t == some (expectedRule, 1, true))
  | _ => false

def checkDualTrapReadingsRes (res : BoundedParseResult) (s : String) (expectedTrap : CanonicalRuleId) : Bool :=
  match res with
  | .enumerated [t1, t2] =>
    (!parseTreeEqBool t1 t2) &&
    eqStrBool (reconstructParseYield t1) s &&
    eqStrBool (reconstructParseYield t2) s &&
    (extractPrimaryReading t1 == some (expectedTrap, 1, false)) &&
    (extractPrimaryReading t2 == some (expectedTrap, 2, false))
  | _ => false

/--
  Verifies that `parseAllBounded` enumerates EXACTLY 2 distinct `ConcreteParseTree`s
  `[t1, t2]` (`!parseTreeEqBool t1 t2`) with `readingAlt = 1` and `readingAlt = 2` for a 2-reading trap (`T1`, `T2`, `T4`).
-/
def checkDualTrapReadings (env : ScopeEnv) (s : String) (expectedTrap : CanonicalRuleId) : Bool :=
  checkDualTrapReadingsRes (runParserOnStr env defaultParseBudget s) s expectedTrap

theorem checkDualTrapReadingsRes_sound (res : BoundedParseResult) (s : String) (expectedTrap : CanonicalRuleId)
    (h : checkDualTrapReadingsRes res s expectedTrap = true) :
    ∃ t1 t2 : ConcreteParseTree,
      res = .enumerated [t1, t2] ∧
      t1 ≠ t2 ∧
      extractPrimaryReading t1 = some (expectedTrap, 1, false) ∧
      extractPrimaryReading t2 = some (expectedTrap, 2, false) := by
  cases res with
  | outOfDomain _ => contradiction
  | resourceOverflow _ => contradiction
  | enumerated ts =>
    cases ts with
    | nil => contradiction
    | cons t1 r1 =>
      cases r1 with
      | nil => contradiction
      | cons t2 r2 =>
        cases r2 with
        | cons _ _ => contradiction
        | nil =>
          unfold checkDualTrapReadingsRes at h
          simp only [Bool.and_eq_true, Bool.not_eq_true', beq_iff_eq] at h
          have hfalse : parseTreeEqBool t1 t2 = false := h.1.1.1.1
          have hext1 : extractPrimaryReading t1 = some (expectedTrap, 1, false) := h.1.2
          have hext2 : extractPrimaryReading t2 = some (expectedTrap, 2, false) := h.2
          have hne : t1 ≠ t2 := by
            intro heq
            rw [(parseTreeEqBool_iff t1 t2).mpr heq] at hfalse
            contradiction
          exact ⟨t1, t2, rfl, hne, hext1, hext2⟩

def checkSingleTrapReading (env : ScopeEnv) (s : String) (expectedTrap : CanonicalRuleId) : Bool :=
  match runParserOnStr env defaultParseBudget s with
  | .enumerated [t] =>
    eqStrBool (reconstructParseYield t) s &&
    (extractPrimaryReading t == some (expectedTrap, 1, false))
  | _ => false

set_option maxRecDepth 16384 in
/-- **Gate C.4a Non-Vacuity**: Concrete `G-01` valid parse witness (`|T| = 1`). -/
theorem nonvacuous_G01_enumerated :
    checkSingleGeneratorParse envAtomic sG01 .G01 = true := by decide

set_option maxRecDepth 16384 in
private theorem nonvacuous_T2_bool :
    checkDualTrapReadings envAtomic sT2_DualReading .T2 = true := by decide

/-- **Gate C.4b Non-Vacuity**: Concrete `T2` dual-reading witness (`|T| = 2`, `τ₁ ≠ τ₂`, `alt = 1, 2`). -/
theorem nonvacuous_T2_two_distinct_readings :
    checkDualTrapReadings envAtomic sT2_DualReading .T2 = true ∧
    (∃ t1 t2 : ConcreteParseTree,
      runParserOnStr envAtomic defaultParseBudget sT2_DualReading = .enumerated [t1, t2] ∧
      t1 ≠ t2 ∧
      extractPrimaryReading t1 = some (.T2, 1, false) ∧
      extractPrimaryReading t2 = some (.T2, 2, false)) :=
  ⟨nonvacuous_T2_bool,
   checkDualTrapReadingsRes_sound (runParserOnStr envAtomic defaultParseBudget sT2_DualReading)
     sT2_DualReading .T2 nonvacuous_T2_bool⟩

/-! ### 4. Concrete Bridge Certificates & Adversarial Bypass/Tamper Fixtures (`Gate D / Gate E`) -/

def sBridgeG11 : String :=
  "In the primary cohort, no diabetic patients developed stroke."

def deltaBridgeG11 : List ObligationToken :=
  [ { oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } },
    { oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_stroke" } } ]

def validRawCertG11 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 61⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 60⟩
          [{ oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G11_QuantZero.toCode ⟨23, 60⟩
                [{ oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_stroke" } }]
                [ .litSpan "no " ⟨23, 26⟩,
                  .slotLeaf { sort := .subgroupPlural, role := .subgroup, entityId := "sub_dm_pl",
                              lexeme := "diabetic", span := ⟨26, 34⟩ },
                  .litSpan " patients developed " ⟨34, 54⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_stroke",
                              lexeme := "stroke", span := ⟨54, 60⟩ } ]) ]),
      .litSpan "." ⟨60, 61⟩ ]

def spoofedEntityCertG11 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 61⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 60⟩
          [{ oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G11_QuantZero.toCode ⟨23, 60⟩
                [{ oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_aki" } }]
                [ .litSpan "no " ⟨23, 26⟩,
                  .slotLeaf { sort := .subgroupPlural, role := .subgroup, entityId := "sub_dm_pl",
                              lexeme := "diabetic", span := ⟨26, 34⟩ },
                  .litSpan " patients developed " ⟨34, 54⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_aki",
                              lexeme := "stroke", span := ⟨54, 60⟩ } ]) ]),
      .litSpan "." ⟨60, 61⟩ ]

def spoofedDeltaG11 : List ObligationToken :=
  [ { oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } },
    { oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_aki" } } ]

def deltaBridgeG01 : List ObligationToken :=
  [ { oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } },
    { oblId := 11, spec := { locus := .clause1, kind := .descIncidence, target := "win_12m:ev_stroke:42/500=8.4" } } ]

def validRawCertG01 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 104⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 103⟩
          [{ oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G01_DescIncidence.toCode ⟨23, 103⟩
                [{ oblId := 11, spec := { locus := .clause1, kind := .descIncidence, target := "win_12m:ev_stroke:42/500=8.4" } }]
                [ .litSpan "over " ⟨23, 28⟩,
                  .slotLeaf { sort := .followUpWindow, role := .window, entityId := "win_12m",
                              lexeme := "12 months", span := ⟨28, 37⟩ },
                  .litSpan ", the cumulative incidence of " ⟨37, 67⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_stroke",
                              lexeme := "stroke", span := ⟨67, 73⟩ },
                  .litSpan " was " ⟨73, 78⟩,
                  .slotLeaf { sort := .numericLit, role := .numK, entityId := "42",
                              lexeme := "42", span := ⟨78, 80⟩ },
                  .litSpan " of " ⟨80, 84⟩,
                  .slotLeaf { sort := .numericLit, role := .numN, entityId := "500",
                              lexeme := "500", span := ⟨84, 87⟩ },
                  .litSpan " patients (" ⟨87, 98⟩,
                  .slotLeaf { sort := .numericLit, role := .numPct, entityId := "8.4",
                              lexeme := "8.4", span := ⟨98, 101⟩ },
                  .litSpan "%)" ⟨101, 103⟩ ]) ]),
      .litSpan "." ⟨103, 104⟩ ]

def sBadMultiDotG01 : String :=
  "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (1..25%)."

def badMultiDotCertG01 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 106⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 105⟩
          [{ oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G01_DescIncidence.toCode ⟨23, 105⟩
                [{ oblId := 11, spec := { locus := .clause1, kind := .descIncidence, target := "win_12m:ev_stroke:42/500=1..25" } }]
                [ .litSpan "over " ⟨23, 28⟩,
                  .slotLeaf { sort := .followUpWindow, role := .window, entityId := "win_12m",
                              lexeme := "12 months", span := ⟨28, 37⟩ },
                  .litSpan ", the cumulative incidence of " ⟨37, 67⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_stroke",
                              lexeme := "stroke", span := ⟨67, 73⟩ },
                  .litSpan " was " ⟨73, 78⟩,
                  .slotLeaf { sort := .numericLit, role := .numK, entityId := "42",
                              lexeme := "42", span := ⟨78, 80⟩ },
                  .litSpan " of " ⟨80, 84⟩,
                  .slotLeaf { sort := .numericLit, role := .numN, entityId := "500",
                              lexeme := "500", span := ⟨84, 87⟩ },
                  .litSpan " patients (" ⟨87, 98⟩,
                  .slotLeaf { sort := .numericLit, role := .numPct, entityId := "1..25",
                              lexeme := "1..25", span := ⟨98, 103⟩ },
                  .litSpan "%)" ⟨103, 105⟩ ]) ]),
      .litSpan "." ⟨105, 106⟩ ]

def badMultiDotDeltaG01 : List ObligationToken :=
  [ { oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } },
    { oblId := 11, spec := { locus := .clause1, kind := .descIncidence, target := "win_12m:ev_stroke:42/500=1..25" } } ]

def tamperedSpanCertG11 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 61⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 59⟩
          [{ oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G11_QuantZero.toCode ⟨23, 60⟩
                [{ oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_stroke" } }]
                [ .litSpan "no " ⟨23, 26⟩,
                  .slotLeaf { sort := .subgroupPlural, role := .subgroup, entityId := "sub_dm_pl",
                              lexeme := "diabetic", span := ⟨26, 34⟩ },
                  .litSpan " patients developed " ⟨34, 54⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_stroke",
                              lexeme := "stroke", span := ⟨54, 60⟩ } ]) ]),
      .litSpan "." ⟨60, 61⟩ ]

def trapInjectedCert : UntrustedDerivCert :=
  .mkNode 1 902 ⟨0, 61⟩ [] []

/-! ### 5. Unified 28-Vector `(PC, CE)` Verification Table (`Gate E`) -/

def evalBridgeVerdict (env : ScopeEnv) (rawBytes : List UInt8)
    (delta : List ObligationToken) (cert : UntrustedDerivCert) : Bool × Option BridgeRejectDiag :=
  match verifyBridgedDerivation strictTestCatalog frozenR22NumericConfig env 512 rawBytes delta cert with
  | .ok _    => (true, none)
  | .error e => (false, some e)

def checkTamperedProjectionDetected : Bool :=
  match certifyDerivTree strictTestCatalog frozenR22NumericConfig 61 validRawCertG11 with
  | .error _ => false
  | .ok x    =>
    checkProjectionFaithfulBool x (lowerToP2Cert x) &&
    !checkProjectionFaithfulBool x tamperedSpanCertG11

structure P3BTestCase where
  caseId      : String
  pairGroup   : String
  description : String
  passed      : Bool
  verdictTag  : String
  deriving DecidableEq, Repr

def pc01_b : Bool := checkSingleGeneratorParse envAtomic sG01 .G01
def ce01_b : Bool := runParserOnStr envAtomic defaultParseBudget sBadMultiDotG01 == .enumerated []
def pc02_b : Bool := checkSingleGeneratorParse envAtomic sG03 .G03
def ce02_b : Bool := runParserOnStr envAtomic defaultParseBudget
  "In the primary cohort, comparing intensive therapy versus intensive therapy was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)." == .enumerated []
def pc03_b : Bool := checkSingleGeneratorParse envAtomic sG09 .G09
def ce03_b : Bool := runParserOnStr envAtomic defaultParseBudget
  "In the primary cohort, intensive therapy cured myocardial infarction." == .enumerated []
def pc04_b : Bool := checkSingleGeneratorParse envDiscourse sG15b .G15
def ce04_b : Bool := runParserOnStr envAtomic defaultParseBudget sG15b == .enumerated []
def pc05_b : Bool := checkSingleGeneratorParse envDiscourse sG16 .G16
def ce05_b : Bool := runParserOnStr envDiscourse defaultParseBudget
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality." == .enumerated []
def pc06_b : Bool := checkDualTrapReadings envAtomic sT2_DualReading .T2
def ce06_b : Bool := runParserOnStr envAtomic { defaultParseBudget with maxReadings := 1 } sT2_DualReading ==
  .resourceOverflow (.maxReadingsExceeded 2 1)
def pc07_b : Bool := checkDualTrapReadings envAtomic sT1_DualReading .T1
def ce07_b : Bool := runParserOnStr envAtomic { defaultParseBudget with maxBytes := 20 } sT1_DualReading ==
  .resourceOverflow (.maxBytesExceeded 68 20)
def pc08_b : Bool := checkSingleTrapReading envAtomic sT3_WhTrap .T3
def ce08_b : Bool := runParserOnStr envAtomic { defaultParseBudget with maxSteps := 5 } sT3_WhTrap ==
  .resourceOverflow (.maxStepsExceeded 5)
def pc09_b : Bool := checkDualTrapReadings envAtomic sT4_DualReading .T4
def ce09_b : Bool := runParserOnStr envAtomic { defaultParseBudget with maxForestNodes := 1 } sT4_DualReading ==
  .resourceOverflow (.maxForestNodesExceeded 1)
def pc10_b : Bool := checkSingleTrapReading envAtomic sT5_Unscoped .T5
def ce10_b : Bool := parseAllBounded strictTestCatalog frozenR22NumericConfig envAtomic defaultParseBudget [] ==
  .outOfDomain .emptyInput
def pc11_b : Bool := checkSingleGeneratorParse envAtomic sBridgeG11 .G11
def ce11_b : Bool := parseAllBounded strictTestCatalog frozenR22NumericConfig envAtomic defaultParseBudget
  ([0x49, 0x6E, 0x20, 0xC3, 0xA9]) == .outOfDomain (.nonPrintableAsciiByte 0xC3)
def pc12_b : Bool := (evalBridgeVerdict envAtomic (strToAsciiBytes sG01) deltaBridgeG01 validRawCertG01).1
def ce12_b : Bool :=
  let v := evalBridgeVerdict envAtomic (strToAsciiBytes sBadMultiDotG01) badMultiDotDeltaG01 badMultiDotCertG01
  (!v.1) && (v.2 == some (.slotLexicalRejected 3 .multipleDecimalPoints))
def pc13_b : Bool := (evalBridgeVerdict envAtomic (strToAsciiBytes sBridgeG11) deltaBridgeG11 validRawCertG11).1
def ce13_b : Bool :=
  let v := evalBridgeVerdict envAtomic (strToAsciiBytes sBridgeG11) spoofedDeltaG11 spoofedEntityCertG11
  (!v.1) && (v.2 == some (.slotLexicalRejected 3 .entityCatalogMismatch))
def pc14_b : Bool := checkTamperedProjectionDetected
def ce14_b : Bool :=
  let v := evalBridgeVerdict envAtomic (strToAsciiBytes sBridgeG11) [] trapInjectedCert
  (!v.1) && (v.2 == some (.forgedOrTrapRuleCode 1 902))

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc01_ok : pc01_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce01_ok : ce01_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc02_ok : pc02_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce02_ok : ce02_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc03_ok : pc03_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce03_ok : ce03_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc04_ok : pc04_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce04_ok : ce04_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc05_ok : pc05_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce05_ok : ce05_b = true := by decide
set_option maxRecDepth 16384 in theorem pc06_ok : pc06_b = true := by decide
set_option maxRecDepth 16384 in theorem ce06_ok : ce06_b = true := by decide
set_option maxRecDepth 16384 in theorem pc07_ok : pc07_b = true := by decide
set_option maxRecDepth 16384 in theorem ce07_ok : ce07_b = true := by decide
set_option maxRecDepth 16384 in theorem pc08_ok : pc08_b = true := by decide
set_option maxRecDepth 16384 in theorem ce08_ok : ce08_b = true := by decide
set_option maxRecDepth 16384 in theorem pc09_ok : pc09_b = true := by decide
set_option maxRecDepth 16384 in theorem ce09_ok : ce09_b = true := by decide
set_option maxRecDepth 16384 in theorem pc10_ok : pc10_b = true := by decide
set_option maxRecDepth 16384 in theorem ce10_ok : ce10_b = true := by decide
set_option maxRecDepth 16384 in theorem pc11_ok : pc11_b = true := by decide
set_option maxRecDepth 16384 in theorem ce11_ok : ce11_b = true := by decide
set_option maxRecDepth 16384 in theorem pc12_ok : pc12_b = true := by decide
set_option maxRecDepth 16384 in theorem ce12_ok : ce12_b = true := by decide
set_option maxRecDepth 16384 in theorem pc13_ok : pc13_b = true := by decide
set_option maxRecDepth 16384 in theorem ce13_ok : ce13_b = true := by decide
set_option maxRecDepth 16384 in theorem pc14_ok : pc14_b = true := by decide
set_option maxRecDepth 16384 in theorem ce14_ok : ce14_b = true := by decide

def allP3BCases : List P3BTestCase :=
  [ { caseId := "PC-P3B-01", pairGroup := "PAIR-01-G01-PARSE",
      description := "Valid G-01 incidence sentence enumerated uniquely (|T|=1)",
      passed := pc01_b, verdictTag := "ENUMERATED_1(G01:alt1)" },
    { caseId := "CE-P3B-01", pairGroup := "PAIR-01-G01-PARSE",
      description := "G-01 sentence with multi-dot numeric 1..25% yields Enumerated([])",
      passed := ce01_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-02", pairGroup := "PAIR-02-G03-SIDECOND",
      description := "Valid G-03 association sentence enumerated uniquely (|T|=1)",
      passed := pc02_b, verdictTag := "ENUMERATED_1(G03:alt1)" },
    { caseId := "CE-P3B-02", pairGroup := "PAIR-02-G03-SIDECOND",
      description := "G-03 activeExp == refExp side-condition violation yields Enumerated([])",
      passed := ce02_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-03", pairGroup := "PAIR-03-G09-VS-GRAMMAR",
      description := "Valid G-09 non-establishment sentence enumerated uniquely (|T|=1)",
      passed := pc03_b, verdictTag := "ENUMERATED_1(G09:alt1)" },
    { caseId := "CE-P3B-03", pairGroup := "PAIR-03-G09-VS-GRAMMAR",
      description := "In-domain ungrammatical verb 'cured' yields Enumerated([]) (NOT OutOfDomain)",
      passed := ce03_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-04", pairGroup := "PAIR-04-G15-DISCOURSE",
      description := "Valid G-15b discourse-bound two-clause document enumerated uniquely (|T|=1)",
      passed := pc04_b, verdictTag := "ENUMERATED_1(G15:alt1)" },
    { caseId := "CE-P3B-04", pairGroup := "PAIR-04-G15-DISCOURSE",
      description := "G-15b under sentenceAtomic quoteIsolation yields Enumerated([])",
      passed := ce04_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-05", pairGroup := "PAIR-05-G16-CONTRAST",
      description := "Valid G-16 contrastive two-clause document enumerated uniquely (|T|=1)",
      passed := pc05_b, verdictTag := "ENUMERATED_1(G16:alt1)" },
    { caseId := "CE-P3B-05", pairGroup := "PAIR-05-G16-CONTRAST",
      description := "G-16 with mismatched clause-2 outcome yields Enumerated([])",
      passed := ce05_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-06", pairGroup := "PAIR-06-T2-DUAL-READING",
      description := "T2 'did not confirm that' enumerates BOTH distinct readings [alt=1, alt=2] (|T|=2)",
      passed := pc06_b, verdictTag := "ENUMERATED_2(T2:alt1,T2:alt2)" },
    { caseId := "CE-P3B-06", pairGroup := "PAIR-06-T2-DUAL-READING",
      description := "T2 under maxReadings=1 fails closed with ResourceOverflow(maxReadingsExceeded 2 1)",
      passed := ce06_b, verdictTag := "OVERFLOW(maxReadingsExceeded:2>1)" },
    { caseId := "PC-P3B-07", pairGroup := "PAIR-07-T1-AND-MAXBYTES",
      description := "T1 'all ... did not' enumerates BOTH distinct readings [alt=1, alt=2] (|T|=2)",
      passed := pc07_b, verdictTag := "ENUMERATED_2(T1:alt1,T1:alt2)" },
    { caseId := "CE-P3B-07", pairGroup := "PAIR-07-T1-AND-MAXBYTES",
      description := "Valid ASCII input exceeding maxBytes=20 yields ResourceOverflow(maxBytesExceeded)",
      passed := ce07_b, verdictTag := "OVERFLOW(maxBytesExceeded:68>20)" },
    { caseId := "PC-P3B-08", pairGroup := "PAIR-08-T3-AND-MAXSTEPS",
      description := "T3 wh-presupposition trap ('did not determine why') enumerated as trap (|T|=1)",
      passed := pc08_b, verdictTag := "ENUMERATED_1(T3:alt1)" },
    { caseId := "CE-P3B-08", pairGroup := "PAIR-08-T3-AND-MAXSTEPS",
      description := "Tight maxSteps=5 fails closed with ResourceOverflow(maxStepsExceeded 5)",
      passed := ce08_b, verdictTag := "OVERFLOW(maxStepsExceeded:5)" },
    { caseId := "PC-P3B-09", pairGroup := "PAIR-09-T4-AND-MAXNODES",
      description := "T4 bare-plural trap enumerates BOTH distinct readings [alt=1, alt=2] (|T|=2)",
      passed := pc09_b, verdictTag := "ENUMERATED_2(T4:alt1,T4:alt2)" },
    { caseId := "CE-P3B-09", pairGroup := "PAIR-09-T4-AND-MAXNODES",
      description := "Tight maxForestNodes=1 on 2-reading T4 fails closed with ResourceOverflow(maxForestNodesExceeded 1)",
      passed := ce09_b, verdictTag := "OVERFLOW(maxForestNodesExceeded:1)" },
    { caseId := "PC-P3B-10", pairGroup := "PAIR-10-T5-AND-DOMAIN-EMPTY",
      description := "T5 unscoped sentence enumerated as parser-only trap (|T|=1)",
      passed := pc10_b, verdictTag := "ENUMERATED_1(T5:alt1)" },
    { caseId := "CE-P3B-10", pairGroup := "PAIR-10-T5-AND-DOMAIN-EMPTY",
      description := "Empty raw byte sequence yields OutOfDomain(emptyInput)",
      passed := ce10_b, verdictTag := "OUT_OF_DOMAIN(emptyInput)" },
    { caseId := "PC-P3B-11", pairGroup := "PAIR-11-DOMAIN-NONASCII",
      description := "Clean 7-bit ASCII G-11 sentence enumerated uniquely (|T|=1)",
      passed := pc11_b, verdictTag := "ENUMERATED_1(G11:alt1)" },
    { caseId := "CE-P3B-11", pairGroup := "PAIR-11-DOMAIN-NONASCII",
      description := "Non-7-bit-ASCII byte 0xC3 yields OutOfDomain(nonPrintableAsciiByte 0xC3)",
      passed := ce11_b, verdictTag := "OUT_OF_DOMAIN(nonPrintableAsciiByte:195)" },
    { caseId := "PC-P3B-12", pairGroup := "PAIR-12-BRIDGE-MULTIDOT",
      description := "End-to-end BridgeSound gate accepts valid P3-A + P2 G-01 certificate",
      passed := pc12_b, verdictTag := "BRIDGE_ACCEPTED" },
    { caseId := "CE-P3B-12", pairGroup := "PAIR-12-BRIDGE-MULTIDOT",
      description := "End-to-end BridgeSound gate blocks multi-dot 1..25 numeric bypass via P3-A admitLexicalSlot",
      passed := ce12_b, verdictTag := "BRIDGE_REJECTED(slotLexicalRejected:multipleDecimalPoints)" },
    { caseId := "PC-P3B-13", pairGroup := "PAIR-13-BRIDGE-ENTITY-SPOOF",
      description := "End-to-end BridgeSound gate accepts valid P3-A + P2 G-11 certificate",
      passed := pc13_b, verdictTag := "BRIDGE_ACCEPTED" },
    { caseId := "CE-P3B-13", pairGroup := "PAIR-13-BRIDGE-ENTITY-SPOOF",
      description := "End-to-end BridgeSound gate blocks spoofed entityId ('ev_aki' on 'stroke') via P3-A catalog",
      passed := ce13_b, verdictTag := "BRIDGE_REJECTED(slotLexicalRejected:entityCatalogMismatch)" },
    { caseId := "PC-P3B-14", pairGroup := "PAIR-14-PROJECTION-AND-TRAP",
      description := "ProjectionFaithful holds on lowerToP2Cert(x) and rejects span-tampered projection",
      passed := pc14_b, verdictTag := "PROJECTION_FAITHFUL_VERIFIED" },
    { caseId := "CE-P3B-14", pairGroup := "PAIR-14-PROJECTION-AND-TRAP",
      description := "End-to-end BridgeSound gate blocks T2 trap rule code 902 injection",
      passed := ce14_b, verdictTag := "BRIDGE_REJECTED(forgedOrTrapRuleCode:902)" } ]

/-- Kernel-checked theorem (`decide`, ZERO `native_decide`): ALL 28 `(PC, CE)` vectors pass! -/
theorem allP3BCases_verified :
    (allP3BCases.all (·.passed)) = true ∧ allP3BCases.length = 28 := by
  refine ⟨?_, rfl⟩
  simp [allP3BCases, List.all,
        pc01_ok, ce01_ok, pc02_ok, ce02_ok, pc03_ok, ce03_ok, pc04_ok, ce04_ok,
        pc05_ok, ce05_ok, pc06_ok, ce06_ok, pc07_ok, ce07_ok, pc08_ok, ce08_ok,
        pc09_ok, ce09_ok, pc10_ok, ce10_ok, pc11_ok, ce11_ok, pc12_ok, ce12_ok,
        pc13_ok, ce13_ok, pc14_ok, ce14_ok]

end BrocaOmega.P3B.Counterexamples
````

### File 11: `04_proof_obligations/P3BProofObligations.lean` (SHA-256: `CFC70A41A3D0DE67A539C36875A0811E50C967041E08C080F48F50ED0309CEB1`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` & `BridgeSound`)
  04_proof_obligations/P3BProofObligations.lean
-/
import P3BProofObligations.PO_C1_01_And_Bridge
````

### File 12: `04_proof_obligations/P3BProofObligations/PO_C1_01_And_Bridge.lean` (SHA-256: `D0A39693AE96EB34234C8459D7873508688064C305A2C0B789E199CC8F040F11`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` Bounded Parser & `BridgeSound` Proof Obligations)
  04_proof_obligations/P3BProofObligations/PO_C1_01_And_Bridge.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  Exports the canonical machine-checked proof obligations across `Gate A` ~ `Gate F`:
    - Gate A (`F-P3A-01`):
        1. `PO_P3B_F_P3A_01_InterleavedGrammarEq`
        2. `PO_P3B_F_P3A_01_MatchesP3AFrozenBNF`
        3. `PO_P3B_F_P3A_01_UniversalSideCondEq`
        4. `PO_P3B_F_P3A_01_UniversalIntrinsicOblsEq`
        5. `PO_P3B_F_P3A_01_UniversalSummaryEq`
        6. `PO_P3B_FrozenParseGrammarAcyclic`
    - Gate B & Gate C (`PO-C1-01`):
        7. `PO_C1_01_BoundedParserTerminates`
        8. `PO_C1_01_OutOfDomainBoundarySound`
        9. `PO_C1_01_BoundedParserSoundness`
       10. `PO_C1_01_BoundedParserExhaustiveCompleteness`
       11. `PO_C1_01_EnumeratedEmptySound`
       12. `PO_C1_01_ResourceOverflowFailClosed`
       13. `PO_C1_01_NonVacuous_G01_Witness`
       14. `PO_C1_01_NonVacuous_T2_DualReadings`
    - Gate D (`BridgeSound` + `ProjectionFaithful` on Actual Frozen `P3-A` & `P2`):
       15. `PO_P3B_LowerToP2Cert_ProjectionFaithful`
       16. `PO_P3B_ProjectionFaithful_CheckerIff`
       17. `PO_P3B_BridgeSound`
       18. `PO_P3B_BridgeSound_MemEnumeratedForest`
       19. `PO_P3B_VerifyBridgedDerivation_Sound`
    - Gate E (`28` Kernel-Proved `(PC, CE)` Vectors):
       20. `PO_P3B_All28CounterexampleVectors_Verified`
    - Gate F (Explicit Residual `HELD` & `NOT_AUTHORIZED` Governance Locks)
-/
import P3BCounterexamples

namespace BrocaOmega.P3B.ProofObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open BrocaOmega.P3B.Counterexamples

/-! ### 1. Gate A — `F-P3A-01` Full Grammar, Side-Condition & Obligation Correspondence -/

theorem PO_P3B_F_P3A_01_InterleavedGrammarEq (r : FrozenGenRule) :
    fromP2Nonterm (ruleSignature r).lhsCat = (frozenProdSig (fromP2Rule r)).lhs ∧
    ((ruleSignature r).segments.map fromP2RuleSegment) = (frozenProdSig (fromP2Rule r)).rhs :=
  f_p3a_01_p2_ruleSignature_matches_p3b_interleaved r

theorem PO_P3B_F_P3A_01_MatchesP3AFrozenBNF :
    (allFrozenParseProds.map fun p =>
      let sig := frozenProdSig p
      (sig.ownerRule, sig.isGenerator, sig.lhs, sig.rhs)) =
    (independentFrozenBNF.map fun b =>
      (b.canonicalOwner, b.isGenerator, b.lhs, b.rhs)) :=
  f_p3a_01_p3b_matches_p3a_independentFrozenBNF

theorem PO_P3B_F_P3A_01_UniversalSideCondEq
    (r : FrozenGenRule) (env : ScopeEnv)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).checkSide env (mapP2Slots slots) (sums.map mapP2Summary) =
    (ruleSignature r).checkSideCond env slots sums :=
  f_p3a_01_universal_sidecond_equivalence r env slots sums

theorem PO_P3B_F_P3A_01_UniversalIntrinsicOblsEq
    (r : FrozenGenRule) (loc : ClauseLocus)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).intrinsicObls loc (mapP2Slots slots) (sums.map mapP2Summary) =
    (ruleSignature r).intrinsicObls loc slots sums :=
  f_p3a_01_universal_intrinsicObls_equivalence r loc slots sums

theorem PO_P3B_F_P3A_01_UniversalSummaryEq
    (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).mkSum (mapP2Slots slots) (sums.map mapP2Summary) =
    mapP2Summary ((ruleSignature r).mkSummary slots sums) :=
  fromP2Rule_mkSum_eq_mapP2Summary r slots sums

theorem PO_P3B_FrozenParseGrammarAcyclic
    (p : FrozenParseProd) (nt : BNFNonterm) (cIdx : Nat)
    (hmem : BNFSymbol.nonterm nt cIdx ∈ (frozenProdSig p).rhs) :
    nt.level < (frozenProdSig p).lhs.level :=
  frozenProdSig_child_level_lt p nt cIdx hmem

/-! ### 2. Gate B & Gate C — `PO-C1-01` Bounded Exhaustive Parser Soundness & Completeness -/

theorem PO_C1_01_BoundedParserTerminates
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) :
    ∃ res : BoundedParseResult, parseAllBounded cat numCfg env budget rawBytes = res :=
  parseAllBounded_terminates cat numCfg env budget rawBytes

theorem PO_C1_01_OutOfDomainBoundarySound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (d : OutOfDomainDiag)
    (hood : parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d) :
    ¬ StrictAsciiDomainSupported rawBytes :=
  parseAllBounded_outOfDomain_sound cat numCfg env budget rawBytes d hood

theorem PO_C1_01_BoundedParserSoundness
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree)
    (henum : parseAllBounded cat numCfg env budget rawBytes = .enumerated T) :
    ∀ τ ∈ T, ValidParse_GFrozen cat numCfg env rawBytes τ :=
  parseAllBounded_sound cat numCfg env budget rawBytes T henum

theorem PO_C1_01_BoundedParserExhaustiveCompleteness
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree)
    (henum : parseAllBounded cat numCfg env budget rawBytes = .enumerated T) :
    StrictAsciiDomainSupported rawBytes ∧
    rawBytes.length ≤ budget.maxBytes ∧
    T.length ≤ budget.maxReadings ∧
    NoDupTrees T ∧
    (∀ τ : ConcreteParseTree, τ ∈ T ↔ ValidParse_GFrozen cat numCfg env rawBytes τ) :=
  parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes T henum

theorem PO_C1_01_EnumeratedEmptySound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (hempty : parseAllBounded cat numCfg env budget rawBytes = .enumerated []) :
    StrictAsciiDomainSupported rawBytes ∧
    ∀ τ : ConcreteParseTree, ¬ ValidParse_GFrozen cat numCfg env rawBytes τ :=
  parseAllBounded_empty_sound cat numCfg env budget rawBytes hempty

theorem PO_C1_01_ResourceOverflowFailClosed
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (b : OverflowReason)
    (hov : parseAllBounded cat numCfg env budget rawBytes = .resourceOverflow b) :
    admitBoundedParse cat numCfg env budget rawBytes = .error (.overflowFailClosed b) ∧
    (∀ T, parseAllBounded cat numCfg env budget rawBytes ≠ .enumerated T) :=
  resourceOverflow_failClosed cat numCfg env budget rawBytes b hov

theorem PO_C1_01_NonVacuous_G01_Witness :
    checkSingleGeneratorParse envAtomic sG01 .G01 = true :=
  nonvacuous_G01_enumerated

theorem PO_C1_01_NonVacuous_T2_DualReadings :
    checkDualTrapReadings envAtomic sT2_DualReading .T2 = true ∧
    (∃ t1 t2 : ConcreteParseTree,
      runParserOnStr envAtomic defaultParseBudget sT2_DualReading = .enumerated [t1, t2] ∧
      t1 ≠ t2 ∧
      extractPrimaryReading t1 = some (.T2, 1, false) ∧
      extractPrimaryReading t2 = some (.T2, 2, false)) :=
  nonvacuous_T2_two_distinct_readings

/-! ### 3. Gate D — `BridgeSound` & `ProjectionFaithful` Over Actual Frozen `P3-A` & `P2` -/

theorem PO_P3B_LowerToP2Cert_ProjectionFaithful {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) :
    ProjectionFaithful x (lowerToP2Cert x) :=
  lowerToP2Cert_projectionFaithful x

theorem PO_P3B_ProjectionFaithful_CheckerIff {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
    (π : BrocaOmega.P2.UntrustedDerivCert) :
    checkProjectionFaithfulBool x π = true ↔ ProjectionFaithful x π :=
  checkProjectionFaithfulBool_iff x π

theorem PO_P3B_BridgeSound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (x : LexicallyCertifiedDerivTree cat numCfg Y.toList.length)
    (π : BrocaOmega.P2.UntrustedDerivCert)
    (wP2 : BrocaOmega.P2.CertifiedDerivation env Y deltaIn)
    (hFaithful : ProjectionFaithful x π)
    (hReplay : BrocaOmega.P2.replayDerivation env Y deltaIn π = .accepted wP2) :
    let τ_x := certTreeToParseTree x .clause1
    AllTreeSlotsP3ACertified x ∧
    reconstructCertYield x = Y ∧
    ObligationsConservedOnCert x deltaIn ∧
    LocusTargetBoundOnCert x ∧
    collectCertSpans x = collectP2Spans π ∧
    (frozenProdSig τ_x.prod).isGenerator = true ∧
    τ_x.span = ⟨0, Y.toList.length⟩ ∧
    (∃ sum3 : ParseSummary,
      ValidParseNode cat numCfg env Y.toList .clause1 .controlledDocument τ_x sum3) :=
  BridgeSound cat numCfg env Y deltaIn x π wP2 hFaithful hReplay

theorem PO_P3B_BridgeSound_MemEnumeratedForest
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget)
    (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (wIng : BrocaOmega.P3A.VerifiedIngressText maxIngressBytes)
    (hIng : BrocaOmega.P3A.admitStrictAsciiIngress maxIngressBytes rawBytes = .ok wIng)
    (deltaIn : List ObligationToken)
    (x : LexicallyCertifiedDerivTree cat numCfg wIng.decoded.toList.length)
    (π : BrocaOmega.P2.UntrustedDerivCert)
    (wP2 : BrocaOmega.P2.CertifiedDerivation env wIng.decoded deltaIn)
    (hFaithful : ProjectionFaithful x π)
    (hReplay : BrocaOmega.P2.replayDerivation env wIng.decoded deltaIn π = .accepted wP2) :
    let τ_x := certTreeToParseTree x .clause1
    ValidParse_GFrozen cat numCfg env rawBytes τ_x ∧
    (∀ T : List ConcreteParseTree,
      parseAllBounded cat numCfg env budget rawBytes = .enumerated T → τ_x ∈ T) :=
  BridgeSound_mem_enumerated_forest cat numCfg env budget maxIngressBytes rawBytes
    wIng hIng deltaIn x π wP2 hFaithful hReplay

theorem PO_P3B_VerifyBridgedDerivation_Sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (deltaIn : List ObligationToken) (rawCandidate : BrocaOmega.P2.UntrustedDerivCert)
    (w : CertifiedBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn)
    (hok : verifyBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn rawCandidate = .ok w) :
    ProjectionFaithful w.certTree w.loweredCert ∧
    AllTreeSlotsP3ACertified w.certTree ∧
    reconstructCertYield w.certTree = w.ingressWitness.decoded ∧
    ObligationsConservedOnCert w.certTree deltaIn ∧
    LocusTargetBoundOnCert w.certTree ∧
    ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree w.certTree .clause1) :=
  verifyBridgedDerivation_sound cat numCfg env maxIngressBytes rawBytes deltaIn rawCandidate w hok

/-! ### 4. Gate E — All 28 Curated `(PC, CE)` Vectors Verified via Pure `decide` -/

theorem PO_P3B_All28CounterexampleVectors_Verified :
    (allP3BCases.all (·.passed)) = true ∧ allP3BCases.length = 28 :=
  allP3BCases_verified

/-! ### 5. Gate F — Explicit Governance Locks (`HELD` & `NOT_AUTHORIZED` Preserved) -/

inductive GovernanceDisposition where
  | EVIDENCE_SUBMITTED_PENDING_TRIBUNAL_HELD
  | HELD_EXTERNAL_KERNEL_REPLAY
  | HELD_UNSPECIFIED_IN_R0
  | NOT_AUTHORIZED
  deriving DecidableEq, Repr

def status_F_P3A_01_FullCorrespondence : GovernanceDisposition :=
  .EVIDENCE_SUBMITTED_PENDING_TRIBUNAL_HELD

def status_F_P3A_02_BridgeSoundness : GovernanceDisposition :=
  .EVIDENCE_SUBMITTED_PENDING_TRIBUNAL_HELD

def status_P1_P2_P3A_ExternalKernelReplay : GovernanceDisposition :=
  .HELD_EXTERNAL_KERNEL_REPLAY

def status_G01_RightCensoredSurface_And_ProductionCatalog : GovernanceDisposition :=
  .HELD_UNSPECIFIED_IN_R0

def status_P1C_P3C_P4_P5_Pneuma : GovernanceDisposition :=
  .NOT_AUTHORIZED

end BrocaOmega.P3B.ProofObligations
````

### File 13: `05_independent_tribunal/P3BTribunalAudit.lean` (SHA-256: `E0F1D27419BE36D02375B26155BA5AD0F9D2385FF2AC1B9F4A444CDF28A8496A`)
````lean
/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` & `BridgeSound` Independent Tribunal Runner)
  05_independent_tribunal/P3BTribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  1. Emits compile-time `#print axioms` audit across all 20 exported `P3-B` proof obligations.
  2. Provides executable CLI (`p3b_tribunal_runner`) supporting:
       - Default human-readable verification table of all 28 curated `(PC, CE)` vectors
       - `--export-fixed-json`: JSON export of the 28 curated vectors
       - `--eval-batch <tsv_path>`: True 1-to-1 serialized batch evaluation of `parseAllBounded`
         for differential parity verification against the clean-room Python 3.11 oracle.
-/
import P3BProofObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open BrocaOmega.P3B.Counterexamples
open BrocaOmega.P3B.ProofObligations

/-! ### 1. Compile-Time Axiom Footprint Audit (`#print axioms` — Zero `sorryAx`, Zero `ofReduceBool`) -/

#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_InterleavedGrammarEq
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_MatchesP3AFrozenBNF
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalSideCondEq
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalIntrinsicOblsEq
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalSummaryEq
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_FrozenParseGrammarAcyclic
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserTerminates
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_OutOfDomainBoundarySound
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserSoundness
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserExhaustiveCompleteness
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_EnumeratedEmptySound
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_ResourceOverflowFailClosed
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_NonVacuous_G01_Witness
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_NonVacuous_T2_DualReadings
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_LowerToP2Cert_ProjectionFaithful
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_ProjectionFaithful_CheckerIff
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_BridgeSound
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_BridgeSound_MemEnumeratedForest
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_VerifyBridgedDerivation_Sound
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_All28CounterexampleVectors_Verified

/-! ### 2. Canonical Formatting & Hex-TSV Batch Evaluator for 1:1 Differential Parity -/

private def ruleIdToStr : CanonicalRuleId → String
  | .G01 => "G01" | .G02 => "G02" | .G03 => "G03" | .G04 => "G04"
  | .G05 => "G05" | .G06 => "G06" | .G07 => "G07" | .G08 => "G08"
  | .G09 => "G09" | .G10 => "G10" | .G11 => "G11" | .G12 => "G12"
  | .G13 => "G13" | .G14 => "G14" | .G15 => "G15" | .G16 => "G16"
  | .T1  => "T1"  | .T2  => "T2"  | .T3  => "T3"  | .T4  => "T4" | .T5 => "T5"

private def formatTreeSig (t : ConcreteParseTree) : String :=
  match extractPrimaryReading t with
  | some (r, alt, isGen) =>
    let gTag := if isGen then "gen" else "trap"
    s!"{ruleIdToStr r}:alt{alt}:{gTag}"
  | none => "WRAPPER:alt1:gen"

private def joinComma : List String → String
  | [] => ""
  | [x] => x
  | x :: xs => x ++ "," ++ joinComma xs

private def formatParseResult (res : BoundedParseResult) : String :=
  match res with
  | .outOfDomain .emptyInput =>
    "OOD:emptyInput"
  | .outOfDomain (.nonPrintableAsciiByte b) =>
    s!"OOD:nonPrintableAsciiByte:{b.toNat}"
  | .resourceOverflow (.maxBytesExceeded act mx) =>
    s!"OVF:maxBytesExceeded:{act}:{mx}"
  | .resourceOverflow (.maxStepsExceeded mx) =>
    s!"OVF:maxStepsExceeded:{mx}"
  | .resourceOverflow (.maxForestNodesExceeded mx) =>
    s!"OVF:maxForestNodesExceeded:{mx}"
  | .resourceOverflow (.maxReadingsExceeded act mx) =>
    s!"OVF:maxReadingsExceeded:{act}:{mx}"
  | .enumerated ts =>
    let sigs := joinComma (ts.map formatTreeSig)
    s!"ENUM:{ts.length}:{sigs}"

private def hexDigitVal (c : Char) : Option Nat :=
  if ('0' ≤ c) && (c ≤ '9') then some (c.toNat - '0'.toNat)
  else if ('a' ≤ c) && (c ≤ 'f') then some (10 + (c.toNat - 'a'.toNat))
  else if ('A' ≤ c) && (c ≤ 'F') then some (10 + (c.toNat - 'A'.toNat))
  else none

private def decodeHexChars : List Char → Option (List UInt8)
  | [] => some []
  | c1 :: c2 :: rest =>
    match hexDigitVal c1, hexDigitVal c2, decodeHexChars rest with
    | some v1, some v2, some tail => some (UInt8.ofNat (v1 * 16 + v2) :: tail)
    | _, _, _ => none
  | [_] => none

private def stripCR (s : String) : String :=
  String.ofList (s.toList.filter (fun c => c != '\r'))

private def parseNatSimple (s : String) : Nat :=
  s.toNat?.getD 0

private def evalBatchLine (line : String) : Option String :=
  let clean := stripCR line
  if clean.isEmpty then none
  else
    match clean.splitOn "\t" with
    | [vecId, modeStr, maxBStr, maxSStr, maxNStr, maxRStr, hexPayload] =>
      let env := if modeStr == "discourse" then envDiscourse else envAtomic
      let budget : ResourceBudget :=
        { maxBytes       := parseNatSimple maxBStr
          maxSteps       := parseNatSimple maxSStr
          maxForestNodes := parseNatSimple maxNStr
          maxReadings    := parseNatSimple maxRStr }
      match decodeHexChars hexPayload.toList with
      | none => some s!"{vecId}\tERR:INVALID_HEX"
      | some rawBytes =>
        let res := parseAllBounded strictTestCatalog frozenR22NumericConfig env budget rawBytes
        some s!"{vecId}\t{formatParseResult res}"
    | _ => some "ERR:MALFORMED_LINE"

private def exportFixedJson : String :=
  let items := allP3BCases.map fun c =>
    s!"  \{\"caseId\": \"{c.caseId}\", \"pairGroup\": \"{c.pairGroup}\", \"passed\": {c.passed}, \"verdictTag\": \"{c.verdictTag}\"}"
  "[\n" ++ String.intercalate ",\n" items ++ "\n]"

def main (args : List String) : IO UInt32 := do
  match args with
  | ["--export-fixed-json"] =>
    IO.println exportFixedJson
    return 0
  | ["--eval-batch", path] =>
    let content ← IO.FS.readFile path
    for line in content.splitOn "\n" do
      match evalBatchLine line with
      | some out => IO.println out
      | none     => pure ()
    return 0
  | _ =>
    IO.println "=========================================================================="
    IO.println "BROCA-NATIVE OMEGA — AUTH-C1-P3-B BOUNDED PARSER & BRIDGE VERIFICATION"
    IO.println "Scope     : PO-C1-01 Bounded Exhaustive Parser + BridgeSound + F-P3A-01"
    IO.println "Toolchain : Lean 4.33.1 Core (Init + Frozen P2/P3-A, 0 sorry, 0 ofReduceBool)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for c in allP3BCases do
      let status := if c.passed then "PASS" else "FAIL"
      if c.passed then passCount := passCount + 1
      IO.println s!"[{status}] {c.caseId} ({c.pairGroup}) => {c.verdictTag}"
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"TOTAL CURATED VECTORS : {passCount}/{allP3BCases.length} PASSED"
    if passCount == allP3BCases.length then
      return 0
    else
      return 1
````

### File 14: `05_independent_tribunal/differential_oracle_p3b.py` (SHA-256: `EF3E734346B3D6F673173777F23BFF4EFDB3D2B0730E8E5A09E34B38296F2CED`)
````python
#!/usr/bin/env python3
"""
BROCA-NATIVE OMEGA — AUTH-C1-P3-B Independent Clean-Room Differential Oracle
05_independent_tribunal/differential_oracle_p3b.py
Python 3.11 Standard Library Only (zero external packages)

Verifies true 1-to-1 input-by-input equivalence (`Result_Lean(x) == Result_Python(x)`):
  1. Fixed 28-vector `(PC, CE)` suite exported by `p3b_tribunal_runner.exe --export-fixed-json`.
  2. External 250-vector serialized TSV batch evaluated identically by BOTH this clean-room
     Python 3.11 bounded parser & `p3b_tribunal_runner.exe --eval-batch <tsv_path>`, covering:
       - All valid generator sentences (`G-01` ~ `G-16`, including `G-02a/b`, `G-06a/b`, `G-15a/b`, `G-16`)
       - All parser-only trap sentences (`T1` ~ `T5`), verifying `|T| = 2` (`alt1, alt2`) on `T1`, `T2`, `T4`
       - In-domain grammatical, side-condition, and `P3-A` lexical/numeric rejections (`ENUM:0:`)
       - Character-profile `OutOfDomain` boundary cases (`OOD:emptyInput`, `OOD:nonPrintableAsciiByte`)
       - Formal `ResourceBudget` exhaustion sweeps across ALL 4 dimensions (`maxBytes`, `maxSteps`,
         `maxForestNodes`, `maxReadings`) confirming fail-closed `OVF:...` parity!
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Optional, Tuple


# ---------------------------------------------------------------------------
# 1. Clean-Room P3-A Strict Lexical Gate & Reference Catalog
# ---------------------------------------------------------------------------

RESERVED_DELIMITERS: List[str] = [
    ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same",
    "In ", " why ", " how ",
]

OPEN_ENTITY_SORTS = {
    "cohortSpec", "designNoun", "followUpWindow", "eventTerm", "measureTerm",
    "expLevel", "outTerm", "sourceId", "identAssump", "subgroupPlural",
    "subgroupSingular", "covariateList",
}

CLOSED_FUNCTIONAL_ENTRIES: List[Tuple[str, str, str]] = [
    ("assocDir",       "positively", "positively"),
    ("assocDir",       "inversely",  "inversely"),
    ("ratioMetric",    "rr",         "risk ratio"),
    ("ratioMetric",    "or",         "odds ratio"),
    ("ratioMetric",    "hr",         "hazard ratio"),
    ("intervDirVerb",  "increase",   "increase"),
    ("intervDirVerb",  "reduce",     "reduce"),
    ("intervVerbPres", "causes",     "causes"),
    ("intervVerbPres", "increases",  "increases"),
    ("intervVerbPres", "reduces",    "reduces"),
    ("epistemicVerb",  "establish",  "establish"),
    ("epistemicVerb",  "determine",  "determine"),
    ("epistemicVerb",  "confirm",    "confirm"),
    ("epistemicVerb",  "reveal",     "reveal"),
    ("whWord",         "why",        "why"),
    ("whWord",         "how",        "how"),
]

STRICT_TEST_CATALOG: List[Tuple[str, str, str]] = [
    ("cohortSpec",       "coh_primary", "the primary cohort"),
    ("designNoun",       "des_study",   "study"),
    ("followUpWindow",   "win_12m",     "12 months"),
    ("eventTerm",        "ev_stroke",   "stroke"),
    ("eventTerm",        "ev_aki",      "acute kidney injury"),
    ("expLevel",         "exp_intens",  "intensive therapy"),
    ("expLevel",         "exp_std",     "standard care"),
    ("outTerm",          "out_mi",      "myocardial infarction"),
    ("outTerm",          "out_death",   "all-cause mortality"),
    ("sourceId",         "src_trialA",  "Trial-A"),
    ("subgroupPlural",   "sub_dm_pl",   "diabetic"),
    ("subgroupSingular", "sub_hr_sg",   "high-risk"),
]


def is_printable_ascii_str(s: str) -> bool:
    return len(s) > 0 and all(0x20 <= ord(c) <= 0x7E for c in s)


def has_trimmed_spaces(s: str) -> bool:
    return len(s) > 0 and s[0] != " " and s[-1] != " "


def check_valid_catalog(entries: List[Tuple[str, str, str]]) -> bool:
    for srt, eid, lex in entries:
        if srt not in OPEN_ENTITY_SORTS:
            return False
        if not is_printable_ascii_str(eid) or not is_printable_ascii_str(lex):
            return False
        if not has_trimmed_spaces(lex):
            return False
        if any(bad in lex for bad in RESERVED_DELIMITERS):
            return False
    for i, (s1, id1, l1) in enumerate(entries):
        for j, (s2, id2, l2) in enumerate(entries):
            if s1 == s2 and id1 == id2 and l1 != l2:
                return False
            if l1 == l2 and (s1, id1, l1) != (s2, id2, l2):
                return False
    return True


def is_canonical_decimal(s: str, max_int: int = 7, max_frac: int = 4) -> bool:
    if not s or s[0] == "+":
        return False
    neg = False
    body = s
    if s[0] == "-":
        neg = True
        body = s[1:]
    if not body:
        return False
    if any(not (("0" <= c <= "9") or c == ".") for c in body):
        return False
    parts = body.split(".")
    if len(parts) > 2:
        return False
    int_part = parts[0]
    if not int_part:
        return False
    if len(int_part) > 1 and int_part[0] == "0":
        return False
    if len(int_part) > max_int:
        return False
    frac_part = ""
    if len(parts) == 2:
        frac_part = parts[1]
        if not frac_part or len(frac_part) > max_frac:
            return False
    abs_val = int(int_part + frac_part)
    if neg and abs_val == 0:
        return False
    return True


def valid_slot_entity_ids(max_slot_bytes: int, srt: str, lex: str) -> List[str]:
    if not lex or len(lex) > max_slot_bytes:
        return []
    if not is_printable_ascii_str(lex) or not has_trimmed_spaces(lex):
        return []
    if srt in OPEN_ENTITY_SORTS:
        cands = [eid for (es, eid, el) in STRICT_TEST_CATALOG if es == srt and el == lex]
    elif srt == "numericLit":
        cands = [lex]
    else:
        cands = [eid for (es, eid, el) in CLOSED_FUNCTIONAL_ENTRIES if es == srt and el == lex]

    out: List[str] = []
    cat_ok = check_valid_catalog(STRICT_TEST_CATALOG)
    for eid in cands:
        if not is_printable_ascii_str(eid):
            continue
        if srt in OPEN_ENTITY_SORTS:
            if any(bad in lex for bad in RESERVED_DELIMITERS):
                continue
            if cat_ok and (srt, eid, lex) in STRICT_TEST_CATALOG:
                out.append(eid)
        elif srt == "numericLit":
            if eid == lex and is_canonical_decimal(lex, 7, 4):
                out.append(eid)
        else:
            if (srt, eid, lex) in CLOSED_FUNCTIONAL_ENTRIES:
                out.append(eid)
    return out


# ---------------------------------------------------------------------------
# 2. Clean-Room Frozen 34-Production Grammar (`G-01`~`G-16` + `T1`~`T5`)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SymTerm:
    lit: str


@dataclass(frozen=True)
class SymSlot:
    sort: str
    tag: str


@dataclass(frozen=True)
class SymNonterm:
    nt: str
    clause_idx: int


Symbol = SymTerm | SymSlot | SymNonterm


@dataclass(frozen=True)
class ParseSummaryPy:
    cohort_id: Optional[str] = None
    design_id: Optional[str] = None
    exp_out_pair: Optional[Tuple[str, str]] = None
    embedded_key: Optional[str] = None
    starts_in_within: bool = False


@dataclass(frozen=True)
class ScopeEnvPy:
    cohort_id: str
    expected_design_head: str
    quote_isolation: str  # "sentenceAtomic" | "discourseBound"


def lookup_tag(slots: List[Tuple[str, str]], tag: str) -> str:
    for k, v in slots:
        if k == tag:
            return v
    return ""


@dataclass(frozen=True)
class ProdSpecPy:
    name: str
    owner_rule: Optional[str]
    is_generator: bool
    alt_count: int
    lhs: str
    rhs: Tuple[Symbol, ...]
    check_side: Callable[[ScopeEnvPy, List[Tuple[str, str]], List[ParseSummaryPy]], bool]
    mk_sum: Callable[[List[Tuple[str, str]], List[ParseSummaryPy]], ParseSummaryPy]


FROZEN_PRODS: List[ProdSpecPy] = [
    ProdSpecPy(
        "Env_DocSingle", None, True, 1, "controlledDocument",
        (SymNonterm("scopedInitial", 1), SymTerm(".")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_ScopedInitial", None, True, 1, "scopedInitial",
        (SymTerm("In "), SymSlot("cohortSpec", "cohort"), SymTerm(", "), SymNonterm("atomicCore", 0)),
        lambda env, s, _c: lookup_tag(s, "cohort") == env.cohort_id,
        lambda s, c: ParseSummaryPy(
            cohort_id=lookup_tag(s, "cohort"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_ScopedRepeat", None, True, 1, "scopedRepeat",
        (SymTerm("Within this same "), SymSlot("designNoun", "design"), SymTerm(", "), SymNonterm("atomicCore", 0)),
        lambda env, s, _c: lookup_tag(s, "design") == env.expected_design_head,
        lambda s, c: ParseSummaryPy(
            design_id=lookup_tag(s, "design"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_ScopedAssoc", None, True, 1, "scopedAssoc",
        (SymTerm("In "), SymSlot("cohortSpec", "cohort"), SymTerm(", "), SymNonterm("assocCore", 0)),
        lambda env, s, _c: lookup_tag(s, "cohort") == env.cohort_id,
        lambda s, c: ParseSummaryPy(
            cohort_id=lookup_tag(s, "cohort"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_ScopedContrastMeta", None, True, 1, "scopedContrastMeta",
        (SymTerm("within this same "), SymSlot("designNoun", "design"), SymTerm(", "), SymNonterm("metaNonEstabCore", 0)),
        lambda env, s, _c: lookup_tag(s, "design") == env.expected_design_head,
        lambda s, c: ParseSummaryPy(
            design_id=lookup_tag(s, "design"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_LiftAssoc", None, True, 1, "atomicCore",
        (SymNonterm("assocCore", 0),),
        lambda _e, _s, _c: True,
        lambda _s, c: c[0] if len(c) == 1 else ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_LiftMeta", None, True, 1, "atomicCore",
        (SymNonterm("metaNonEstabCore", 0),),
        lambda _e, _s, _c: True,
        lambda _s, c: c[0] if len(c) == 1 else ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_EmbeddedCausal", None, True, 1, "embeddedCausal",
        (SymSlot("expLevel", "activeExp"), SymTerm(" "), SymSlot("intervVerbPres", "verb"), SymTerm(" "), SymSlot("outTerm", "outcome")),
        lambda _e, _s, _c: True,
        lambda s, _c: ParseSummaryPy(
            exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome")),
            embedded_key=f"{lookup_tag(s, 'activeExp')}:{lookup_tag(s, 'verb')}:{lookup_tag(s, 'outcome')}",
        ),
    ),
    ProdSpecPy(
        "Gen_G01_DescIncidence", "G01", True, 1, "atomicCore",
        (SymTerm("over "), SymSlot("followUpWindow", "window"), SymTerm(", the cumulative incidence of "),
         SymSlot("eventTerm", "eventA"), SymTerm(" was "), SymSlot("numericLit", "numK"),
         SymTerm(" of "), SymSlot("numericLit", "numN"), SymTerm(" patients ("),
         SymSlot("numericLit", "numPct"), SymTerm("%)")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G02a_DescMeanSD", "G02", True, 1, "atomicCore",
        (SymTerm("the mean "), SymSlot("measureTerm", "measure"), SymTerm(" was "),
         SymSlot("numericLit", "numEst"), SymTerm(" (SD "), SymSlot("numericLit", "numDisp1"), SymTerm(")")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G02b_DescMedianIQR", "G02", True, 1, "atomicCore",
        (SymTerm("the median "), SymSlot("measureTerm", "measure"), SymTerm(" was "),
         SymSlot("numericLit", "numEst"), SymTerm(" (IQR "), SymSlot("numericLit", "numDisp1"),
         SymTerm(" to "), SymSlot("numericLit", "numDisp2"), SymTerm(")")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G03_AssocUnadj", "G03", True, 1, "assocCore",
        (SymTerm("comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("assocDir", "direction"),
         SymTerm(" associated with "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda s, _c: ParseSummaryPy(exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome"))),
    ),
    ProdSpecPy(
        "Gen_G04_AssocTemp", "G04", True, 1, "assocCore",
        (SymSlot("eventTerm", "eventA"), SymTerm(" preceded "), SymSlot("eventTerm", "eventB"),
         SymTerm(", and comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("assocDir", "direction"),
         SymTerm(" associated with "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: (lookup_tag(s, "eventA") != lookup_tag(s, "eventB")) and (lookup_tag(s, "activeExp") != lookup_tag(s, "refExp")),
        lambda s, _c: ParseSummaryPy(exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome"))),
    ),
    ProdSpecPy(
        "Gen_G05_CompRD", "G05", True, 1, "atomicCore",
        (SymTerm("the absolute risk difference in "), SymSlot("outTerm", "outcome"),
         SymTerm(" comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("numericLit", "numEst"),
         SymTerm(" percentage points ("), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G06a_IntervDirectional", "G06", True, 1, "atomicCore",
        (SymTerm("under "), SymSlot("identAssump", "assumption"), SymTerm(", comparing "),
         SymSlot("expLevel", "activeExp"), SymTerm(" versus "), SymSlot("expLevel", "refExp"),
         SymTerm(" was estimated to "), SymSlot("intervDirVerb", "verb"), SymTerm(" "),
         SymSlot("outTerm", "outcome"), SymTerm(" ("), SymSlot("ratioMetric", "metric1"),
         SymTerm(" = "), SymSlot("numericLit", "numEst"), SymTerm(", "),
         SymSlot("numericLit", "numCILevel"), SymTerm("% CI "), SymSlot("numericLit", "numCILow"),
         SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(", p = "),
         SymSlot("numericLit", "numPVal"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G06b_IntervNeutral", "G06", True, 1, "atomicCore",
        (SymTerm("under "), SymSlot("identAssump", "assumption"), SymTerm(", the estimated causal "),
         SymSlot("ratioMetric", "metric1"), SymTerm(" for "), SymSlot("outTerm", "outcome"),
         SymTerm(" comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("numericLit", "numEst"),
         SymTerm(" ("), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"),
         SymTerm("), which did not exclude no effect")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G07_MetaNotStatSig", "G07", True, 1, "atomicCore",
        (SymTerm("the observed "), SymSlot("ratioMetric", "metric1"), SymTerm(" comparing "),
         SymSlot("expLevel", "activeExp"), SymTerm(" versus "), SymSlot("expLevel", "refExp"),
         SymTerm(" for "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric2"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"),
         SymTerm(") was not statistically significant at alpha = "), SymSlot("numericLit", "numAlpha")),
        lambda _e, s, _c: (lookup_tag(s, "metric1") == lookup_tag(s, "metric2")) and (lookup_tag(s, "activeExp") != lookup_tag(s, "refExp")),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G08_MetaEquiv", "G08", True, 1, "atomicCore",
        (SymTerm("comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" met prespecified equivalence margins ("),
         SymSlot("numericLit", "numMarginLow"), SymTerm(" to "), SymSlot("numericLit", "numMarginHigh"),
         SymTerm(") for "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% TOST CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G09_MetaNonEstab", "G09", True, 1, "metaNonEstabCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not establish that "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, c: ParseSummaryPy(exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None),
    ),
    ProdSpecPy(
        "Gen_G10_MetaUnresolved", "G10", True, 1, "atomicCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not determine whether "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G11_QuantZero", "G11", True, 1, "atomicCore",
        (SymTerm("no "), SymSlot("subgroupPlural", "subgroup"),
         SymTerm(" patients developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G12_QuantProperPart", "G12", True, 1, "atomicCore",
        (SymTerm("some, but not all, "), SymSlot("subgroupPlural", "subgroup"),
         SymTerm(" patients developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G13_QuantAtLeastOne", "G13", True, 1, "atomicCore",
        (SymTerm("at least one "), SymSlot("subgroupSingular", "subgroup"),
         SymTerm(" patient developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G14_AssocAdj", "G14", True, 1, "assocCore",
        (SymTerm("after adjustment for "), SymSlot("covariateList", "covariates"),
         SymTerm(", comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("assocDir", "direction"),
         SymTerm(" associated with "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda s, _c: ParseSummaryPy(exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome"))),
    ),
    ProdSpecPy(
        "Gen_G15a_DocConjAtomic", "G15", True, 1, "controlledDocument",
        (SymNonterm("scopedInitial", 1), SymTerm(". "), SymNonterm("scopedInitial", 2), SymTerm(".")),
        lambda env, _s, c: len(c) == 2 and env.quote_isolation == "sentenceAtomic" and c[0].cohort_id == env.cohort_id and c[1].cohort_id == env.cohort_id,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G15b_DocConjDiscourse", "G15", True, 1, "controlledDocument",
        (SymNonterm("scopedInitial", 1), SymTerm(". "), SymNonterm("scopedRepeat", 2), SymTerm(".")),
        lambda env, _s, c: len(c) == 2 and env.quote_isolation == "discourseBound" and c[0].cohort_id == env.cohort_id and c[1].design_id == env.expected_design_head,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G16_DocContrastive", "G16", True, 1, "controlledDocument",
        (SymNonterm("scopedAssoc", 1), SymTerm("; however, "), SymNonterm("scopedContrastMeta", 2), SymTerm(".")),
        lambda env, _s, c: (
            len(c) == 2
            and c[0].cohort_id == env.cohort_id
            and c[1].design_id == env.expected_design_head
            and c[0].exp_out_pair is not None
            and c[0].exp_out_pair == c[1].exp_out_pair
        ),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_DocTrapScoped", None, False, 1, "controlledDocument",
        (SymNonterm("scopedTrapClause", 1), SymTerm(".")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_ScopedTrap", None, False, 1, "scopedTrapClause",
        (SymTerm("In "), SymSlot("cohortSpec", "cohort"), SymTerm(", "), SymNonterm("trapCore", 0)),
        lambda env, s, _c: lookup_tag(s, "cohort") == env.cohort_id,
        lambda s, _c: ParseSummaryPy(cohort_id=lookup_tag(s, "cohort"), starts_in_within=True),
    ),
    ProdSpecPy(
        "Trap_T1_AllNot", "T1", False, 2, "trapCore",
        (SymTerm("all "), SymSlot("subgroupPlural", "subgroup"),
         SymTerm(" patients did not develop "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Trap_T2_ConfirmThat", "T2", False, 2, "trapCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not confirm that "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, c: ParseSummaryPy(exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None),
    ),
    ProdSpecPy(
        "Trap_T3_WhPresup", "T3", False, 1, "trapCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not "), SymSlot("epistemicVerb", "verb"),
         SymTerm(" "), SymSlot("whWord", "whComp"), SymTerm(" "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, c: ParseSummaryPy(exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None),
    ),
    ProdSpecPy(
        "Trap_T4_BarePlural", "T4", False, 2, "trapCore",
        (SymSlot("subgroupPlural", "subgroup"), SymTerm(" patients developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Trap_T5_UnscopedDoc", "T5", False, 1, "controlledDocument",
        (SymNonterm("atomicCore", 1), SymTerm(".")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
]

PRODS_BY_NAME = {p.name: p for p in FROZEN_PRODS}


# ---------------------------------------------------------------------------
# 3. Clean-Room Metered Bounded Exhaustive Parser (`parse_all_bounded_py`)
# ---------------------------------------------------------------------------

class OverflowEx(Exception):
    def __init__(self, tag: str) -> None:
        super().__init__(tag)
        self.tag = tag


@dataclass(frozen=True)
class TreeNodePy:
    prod_name: str
    reading_alt: int
    locus: str
    span: Tuple[int, int]
    args: Tuple[object, ...]


def extract_primary_reading_py(t: TreeNodePy) -> str:
    spec = PRODS_BY_NAME[t.prod_name]
    if spec.owner_rule is not None:
        gtag = "gen" if spec.is_generator else "trap"
        return f"{spec.owner_rule}:alt{t.reading_alt}:{gtag}"
    for a in t.args:
        if isinstance(a, TreeNodePy):
            res = extract_primary_reading_py(a)
            if res != "WRAPPER:alt1:gen":
                return res
    return "WRAPPER:alt1:gen"


def candidate_splits_py(y: str, cursor: int, end_pos: int, rest_syms: Tuple[Symbol, ...]) -> List[int]:
    if not rest_syms:
        return [end_pos] if cursor <= end_pos else []
    head = rest_syms[0]
    if isinstance(head, SymTerm):
        lit = head.lit
        n = len(lit)
        if end_pos < cursor:
            return []
        return [
            mid for mid in range(cursor, end_pos + 1)
            if mid + n <= end_pos and y[mid:mid + n] == lit
        ]
    if end_pos < cursor:
        return []
    return list(range(cursor, end_pos + 1))


def parse_all_bounded_py(
    env: ScopeEnvPy,
    max_bytes: int,
    max_steps: int,
    max_forest_nodes: int,
    max_readings: int,
    raw_bytes: bytes,
) -> str:
    if len(raw_bytes) == 0:
        return "OOD:emptyInput"
    for b in raw_bytes:
        if b < 0x20 or b > 0x7E:
            return f"OOD:nonPrintableAsciiByte:{b}"
    if len(raw_bytes) > max_bytes:
        return f"OVF:maxBytesExceeded:{len(raw_bytes)}:{max_bytes}"

    y = raw_bytes.decode("ascii")
    steps_used = 0
    nodes_used = 0

    def tick_step() -> None:
        nonlocal steps_used
        steps_used += 1
        if steps_used > max_steps:
            raise OverflowEx(f"OVF:maxStepsExceeded:{max_steps}")

    def tick_nodes(k: int) -> None:
        nonlocal nodes_used
        nodes_used += k
        if nodes_used > max_forest_nodes:
            raise OverflowEx(f"OVF:maxForestNodesExceeded:{max_forest_nodes}")

    def clause_override(c_idx: int, loc: str) -> str:
        if c_idx == 1:
            return "clause1"
        if c_idx == 2:
            return "clause2"
        return loc

    def enum_segs(
        child_fuel: int, loc: str, cursor: int, syms: Tuple[Symbol, ...], end_pos: int
    ) -> List[Tuple[Tuple[object, ...], List[Tuple[str, str]], List[ParseSummaryPy]]]:
        tick_step()
        if not syms:
            if cursor <= len(y) and end_pos == cursor:
                return [((), [], [])]
            return []
        sym = syms[0]
        rest = syms[1:]
        if isinstance(sym, SymTerm):
            lit = sym.lit
            end_lit = cursor + len(lit)
            if end_lit <= len(y) and y[cursor:end_lit] == lit:
                tails = enum_segs(child_fuel, loc, end_lit, rest, end_pos)
                return [
                    ((("LIT", lit, (cursor, end_lit)),) + r_args, r_slots, r_sums)
                    for (r_args, r_slots, r_sums) in tails
                ]
            return []
        if isinstance(sym, SymSlot):
            if end_pos <= len(y):
                out = []
                for mid in candidate_splits_py(y, cursor, end_pos, rest):
                    if cursor <= mid <= len(y):
                        lex = y[cursor:mid]
                        valid_eids = valid_slot_entity_ids(len(y), sym.sort, lex)
                        if not valid_eids:
                            continue
                        tails = enum_segs(child_fuel, loc, mid, rest, end_pos)
                        for eid in valid_eids:
                            for (r_args, r_slots, r_sums) in tails:
                                out.append((
                                    (("SLOT", sym.sort, sym.tag, eid, lex, (cursor, mid)),) + r_args,
                                    [(sym.tag, eid)] + r_slots,
                                    r_sums,
                                ))
                return out
            return []
        if isinstance(sym, SymNonterm):
            c_loc = clause_override(sym.clause_idx, loc)
            out = []
            for mid in candidate_splits_py(y, cursor, end_pos, rest):
                children = enum_node(child_fuel, c_loc, sym.nt, cursor, mid)
                if not children:
                    continue
                tails = enum_segs(child_fuel, loc, mid, rest, end_pos)
                for (sub_tree, sub_sum) in children:
                    for (r_args, r_slots, r_sums) in tails:
                        out.append((
                            (sub_tree,) + r_args,
                            r_slots,
                            [sub_sum] + r_sums,
                        ))
            return out
        return []

    def enum_node(
        fuel: int, expected_loc: str, expected_nt: str, start_pos: int, end_pos: int
    ) -> List[Tuple[TreeNodePy, ParseSummaryPy]]:
        tick_step()
        if fuel == 0:
            return []
        out: List[Tuple[TreeNodePy, ParseSummaryPy]] = []
        for p in FROZEN_PRODS:
            if p.lhs == expected_nt:
                seg_results = enum_segs(fuel - 1, expected_loc, start_pos, p.rhs, end_pos)
                for (args, slots, sums) in seg_results:
                    if p.check_side(env, slots, sums):
                        out_sum = p.mk_sum(slots, sums)
                        alts = list(range(1, p.alt_count + 1))
                        tick_nodes(len(alts))
                        for alt in alts:
                            out.append((
                                TreeNodePy(p.name, alt, expected_loc, (start_pos, end_pos), args),
                                out_sum,
                            ))
        return out

    try:
        raw_pairs = enum_node(5, "clause1", "controlledDocument", 0, len(y))
    except OverflowEx as ex:
        return ex.tag

    dedup: List[TreeNodePy] = []
    for t, _ in raw_pairs:
        if t not in dedup:
            dedup.append(t)

    if len(dedup) > max_readings:
        return f"OVF:maxReadingsExceeded:{len(dedup)}:{max_readings}"

    sigs = ",".join(extract_primary_reading_py(t) for t in dedup)
    return f"ENUM:{len(dedup)}:{sigs}"


# ---------------------------------------------------------------------------
# 4. External 250-Vector Batch Construction & 1:1 Lean <-> Python Verification
# ---------------------------------------------------------------------------

def build_batch_vectors() -> List[Tuple[str, str, int, int, int, int, bytes]]:
    vecs: List[Tuple[str, str, int, int, int, int, bytes]] = []

    def add(vid: str, mode: str, mb: int, ms: int, mn: int, mr: int, raw: bytes) -> None:
        vecs.append((vid, mode, mb, ms, mn, mr, raw))

    def add_str(vid: str, mode: str, s: str, mb: int = 512, ms: int = 4000, mn: int = 512, mr: int = 16) -> None:
        add(vid, mode, mb, ms, mn, mr, s.encode("ascii"))

    # (1) Valid Generator Core & Multi-Clause Sentences (20 vectors)
    valid_sentences = [
        ("GEN-G01-A", "atomic", "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%)."),
        ("GEN-G01-B", "atomic", "In the primary cohort, over 12 months, the cumulative incidence of acute kidney injury was 0 of 120 patients (0%)."),
        ("GEN-G03-HR", "atomic", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("GEN-G03-RR", "atomic", "In the primary cohort, comparing intensive therapy versus standard care was positively associated with all-cause mortality (risk ratio = 1.18, 95% CI 1.02 to 1.37)."),
        ("GEN-G03-OR", "atomic", "In the primary cohort, comparing standard care versus intensive therapy was positively associated with myocardial infarction (odds ratio = 1.33, 95% CI 1.08 to 1.64)."),
        ("GEN-G04-A", "atomic", "In the primary cohort, stroke preceded acute kidney injury, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("GEN-G05-A", "atomic", "In the primary cohort, the absolute risk difference in myocardial infarction comparing intensive therapy versus standard care was -2.4 percentage points (95% CI -4.1 to -0.7)."),
        ("GEN-G07-A", "atomic", "In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (hazard ratio = 0.91, 95% CI 0.78 to 1.06) was not statistically significant at alpha = 0.05."),
        ("GEN-G08-A", "atomic", "In the primary cohort, comparing intensive therapy versus standard care met prespecified equivalence margins (-1.5 to 1.5) for myocardial infarction (risk ratio = 1.01, 90% TOST CI 0.94 to 1.08)."),
        ("GEN-G09-A", "atomic", "In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
        ("GEN-G09-B", "atomic", "In the primary cohort, the analysis of Trial-A did not establish that standard care increases all-cause mortality."),
        ("GEN-G10-A", "atomic", "In the primary cohort, the analysis of Trial-A did not determine whether intensive therapy causes myocardial infarction."),
        ("GEN-G11-A", "atomic", "In the primary cohort, no diabetic patients developed stroke."),
        ("GEN-G12-A", "atomic", "In the primary cohort, some, but not all, diabetic patients developed stroke."),
        ("GEN-G13-A", "atomic", "In the primary cohort, at least one high-risk patient developed acute kidney injury."),
        ("GEN-G15A-1", "atomic", "In the primary cohort, no diabetic patients developed stroke. In the primary cohort, at least one high-risk patient developed acute kidney injury."),
        ("GEN-G15B-1", "discourse", "In the primary cohort, no diabetic patients developed stroke. Within this same study, at least one high-risk patient developed acute kidney injury."),
        ("GEN-G15B-2", "discourse", "In the primary cohort, some, but not all, diabetic patients developed stroke. Within this same study, no diabetic patients developed acute kidney injury."),
        ("GEN-G16-1", "discourse", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
        ("GEN-G16-2", "discourse", "In the primary cohort, comparing standard care versus intensive therapy was positively associated with all-cause mortality (risk ratio = 1.25, 95% CI 1.04 to 1.51); however, within this same study, the analysis of Trial-A did not establish that standard care increases all-cause mortality."),
    ]
    for vid, mode, s in valid_sentences:
        add_str(vid, mode, s)

    # (2) Trap Sentences & Dual-Reading Non-Collapse Checks (`T1`~`T5`: 15 vectors)
    trap_sentences = [
        ("TRAP-T1-A", "atomic", "In the primary cohort, all diabetic patients did not develop stroke."),
        ("TRAP-T1-B", "atomic", "In the primary cohort, all diabetic patients did not develop acute kidney injury."),
        ("TRAP-T2-A", "atomic", "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction."),
        ("TRAP-T2-B", "atomic", "In the primary cohort, the analysis of Trial-A did not confirm that standard care causes all-cause mortality."),
        ("TRAP-T2-C", "atomic", "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy increases all-cause mortality."),
        ("TRAP-T3-WHY-EST", "atomic", "In the primary cohort, the analysis of Trial-A did not establish why intensive therapy reduces myocardial infarction."),
        ("TRAP-T3-WHY-DET", "atomic", "In the primary cohort, the analysis of Trial-A did not determine why intensive therapy reduces myocardial infarction."),
        ("TRAP-T3-HOW-CONF", "atomic", "In the primary cohort, the analysis of Trial-A did not confirm how intensive therapy reduces myocardial infarction."),
        ("TRAP-T3-HOW-REV", "atomic", "In the primary cohort, the analysis of Trial-A did not reveal how standard care increases all-cause mortality."),
        ("TRAP-T4-A", "atomic", "In the primary cohort, diabetic patients developed stroke."),
        ("TRAP-T4-B", "atomic", "In the primary cohort, diabetic patients developed acute kidney injury."),
        ("TRAP-T5-G11", "atomic", "no diabetic patients developed stroke."),
        ("TRAP-T5-G12", "atomic", "some, but not all, diabetic patients developed stroke."),
        ("TRAP-T5-G13", "atomic", "at least one high-risk patient developed acute kidney injury."),
        ("TRAP-T5-G09", "atomic", "the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
    ]
    for vid, mode, s in trap_sentences:
        add_str(vid, mode, s)

    # (3) Adversarial Malformed Numerics Embedded in Full Sentences (`P3-A` Strict Gate: 45 vectors)
    bad_nums = [
        "1..25", "1.2.3", "0..5", "1.", "42.", ".25", ".05", "+1.25", "+42",
        "-0", "-0.0", "-0.00", "-0.0000", "00", "01", "001.25", "-01.5",
        "1e-3", "1E4", "2.5e2", "12345678", "1.12345", "-12345678", "1,000",
        "NaN", "Inf", "-Inf", "1.2.3.4", "..", "-", "8.4 ", " 8.4", "1_000",
        "0x10", "1/2", "8.40001", "99999999", "00.5", "-.5", "5.", "+0",
        "1..0", "0.1.2", "3.14159", "10000000",
    ]
    for idx, bn in enumerate(bad_nums):
        s = f"In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients ({bn}%)."
        add_str(f"BADNUM-{idx+1:02d}", "atomic", s)

    # (4) Adversarial Side-Condition, Catalog, Terminal & Structural Mutations (60 vectors)
    structural_mutations = [
        # Side-condition failures
        ("SC-G03-SAME-EXP", "atomic", "In the primary cohort, comparing intensive therapy versus intensive therapy was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("SC-G04-SAME-EVT", "atomic", "In the primary cohort, stroke preceded stroke, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("SC-G04-SAME-EXP", "atomic", "In the primary cohort, stroke preceded acute kidney injury, and comparing standard care versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("SC-G05-SAME-EXP", "atomic", "In the primary cohort, the absolute risk difference in myocardial infarction comparing standard care versus standard care was 0 percentage points (95% CI -1.0 to 1.0)."),
        ("SC-G07-METRIC-MISMATCH", "atomic", "In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (risk ratio = 0.91, 95% CI 0.78 to 1.06) was not statistically significant at alpha = 0.05."),
        ("SC-G08-SAME-EXP", "atomic", "In the primary cohort, comparing intensive therapy versus intensive therapy met prespecified equivalence margins (-1.5 to 1.5) for myocardial infarction (risk ratio = 1.01, 90% TOST CI 0.94 to 1.08)."),
        ("SC-G15A-WRONG-MODE", "discourse", "In the primary cohort, no diabetic patients developed stroke. In the primary cohort, at least one high-risk patient developed acute kidney injury."),
        ("SC-G15B-WRONG-MODE", "atomic", "In the primary cohort, no diabetic patients developed stroke. Within this same study, at least one high-risk patient developed acute kidney injury."),
        ("SC-G16-OUT-MISMATCH", "discourse", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality."),
        ("SC-G16-EXP-MISMATCH", "discourse", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that standard care reduces myocardial infarction."),
        # Unknown entities / wrong sort swaps / missing punctuation / recursive G-15 attempts
        ("LEX-UNKNOWN-COHORT", "atomic", "In the secondary cohort, no diabetic patients developed stroke."),
        ("LEX-UNKNOWN-DESIGN", "discourse", "In the primary cohort, no diabetic patients developed stroke. Within this same trial, no diabetic patients developed stroke."),
        ("LEX-SORT-SWAP-1", "atomic", "In the primary cohort, no high-risk patients developed stroke."),
        ("LEX-SORT-SWAP-2", "atomic", "In the primary cohort, at least one diabetic patient developed stroke."),
        ("LEX-SORT-SWAP-3", "atomic", "In the primary cohort, no diabetic patients developed myocardial infarction."),
        ("LEX-SORT-SWAP-4", "atomic", "In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces stroke."),
        ("SYN-NO-PERIOD", "atomic", "In the primary cohort, no diabetic patients developed stroke"),
        ("SYN-DOUBLE-PERIOD", "atomic", "In the primary cohort, no diabetic patients developed stroke.."),
        ("SYN-TRIPLE-CLAUSE-G15", "atomic", "In the primary cohort, no diabetic patients developed stroke. In the primary cohort, no diabetic patients developed stroke. In the primary cohort, no diabetic patients developed stroke."),
        ("SYN-NESTED-G16", "discourse", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction; however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
    ]
    for vid, mode, s in structural_mutations:
        add_str(vid, mode, s)

    # Generate 40 additional systematic terminal/keyword perturbations
    base_g11 = "In the primary cohort, no diabetic patients developed stroke."
    for i in range(40):
        pos = (i * 3) % len(base_g11)
        mutated = base_g11[:pos] + "X" + base_g11[pos:]
        add_str(f"PERTURB-G11-{i+1:02d}", "atomic", mutated)

    # (5) OutOfDomain Raw Byte Vectors (30 vectors: empty, control chars, tabs/newlines, UTF-8 multibyte, 0x7F..0xFF)
    add("OOD-EMPTY", "atomic", 512, 4000, 512, 16, b"")
    bad_byte_vals = [
        0x00, 0x01, 0x07, 0x08, 0x09, 0x0A, 0x0D, 0x1B, 0x1F, 0x7F,
        0x80, 0x81, 0x9F, 0xA0, 0xB5, 0xC0, 0xC2, 0xC3, 0xCE, 0xD0,
        0xE0, 0xE2, 0xED, 0xF0, 0xF4, 0xF8, 0xFC, 0xFE, 0xFF,
    ]
    for idx, bval in enumerate(bad_byte_vals):
        payload = b"In the primary cohort, " + bytes([bval]) + b" stroke."
        add(f"OOD-BYTE-{idx+1:02d}", "atomic", 512, 4000, 512, 16, payload)

    # (6) ResourceBudget Exhaustion Sweeps Across ALL 4 Dimensions (80 vectors!)
    s_t2 = "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction.".encode("ascii")
    s_t1 = "In the primary cohort, all diabetic patients did not develop stroke.".encode("ascii")
    s_t4 = "In the primary cohort, diabetic patients developed stroke.".encode("ascii")
    s_g01 = "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%).".encode("ascii")

    # 6a. maxBytes sweep (20 vectors)
    for idx, mb in enumerate([0, 1, 10, 20, 40, 57, 58, 67, 68, 103, 104, 112, 113, 200]):
        target = s_t4 if idx % 3 == 0 else (s_t1 if idx % 3 == 1 else s_g01)
        add(f"BUDGET-BYTES-{idx+1:02d}", "atomic", mb, 4000, 512, 16, target)
    for idx in range(6):
        add(f"BUDGET-BYTES-EXTRA-{idx+1:02d}", "atomic", 50 + idx * 10, 4000, 512, 16, s_t2)

    # 6b. maxSteps sweep (25 vectors from 0 up to 500!)
    for idx, ms in enumerate([0, 1, 2, 3, 5, 8, 12, 15, 20, 25, 30, 40, 50, 60, 75, 90, 110, 130, 160, 200, 250, 300, 400, 600, 1000]):
        target = s_t2 if idx % 2 == 0 else s_g01
        add(f"BUDGET-STEPS-{idx+1:02d}", "atomic", 512, ms, 512, 16, target)

    # 6c. maxForestNodes sweep (20 vectors: 0..10 on G-11, T2, T4, G-16)
    for idx, mn in enumerate([0, 1, 2, 3, 4, 5, 6, 7, 8, 10]):
        add(f"BUDGET-NODES-T2-{idx+1:02d}", "atomic", 512, 4000, mn, 16, s_t2)
        add(f"BUDGET-NODES-G01-{idx+1:02d}", "atomic", 512, 4000, mn, 16, s_g01)

    # 6d. maxReadings sweep (15 vectors: 0, 1, 2, 3 on 0-reading, 1-reading, and 2-reading inputs!)
    s_invalid = b"In the primary cohort, intensive therapy cured myocardial infarction."
    for mr in [0, 1, 2, 3, 5]:
        add(f"BUDGET-READ-T2-{mr}", "atomic", 512, 4000, 512, mr, s_t2)
        add(f"BUDGET-READ-G01-{mr}", "atomic", 512, 4000, 512, mr, s_g01)
        add(f"BUDGET-READ-INV-{mr}", "atomic", 512, 4000, 512, mr, s_invalid)

    assert len(vecs) == 250, f"Expected 250 batch vectors, got {len(vecs)}"
    return vecs


def main() -> int:
    pkg_root = Path(__file__).resolve().parent.parent
    exe_path = pkg_root / ".lake" / "build" / "bin" / "p3b_tribunal_runner.exe"
    if not exe_path.exists():
        exe_alt = pkg_root / ".lake" / "build" / "bin" / "p3b_tribunal_runner"
        if exe_alt.exists():
            exe_path = exe_alt
        else:
            print(f"[FATAL] Lean executable not found at {exe_path}", file=sys.stderr)
            return 1

    # 1. Verify Fixed 28-Vector `(PC, CE)` Suite via `--export-fixed-json`
    proc_fixed = subprocess.run(
        [str(exe_path), "--export-fixed-json"],
        capture_output=True,
        text=True,
        check=True,
    )
    fixed_cases = json.loads(proc_fixed.stdout)
    if len(fixed_cases) != 28:
        print(f"[FAIL] Expected 28 fixed cases, got {len(fixed_cases)}", file=sys.stderr)
        return 1
    fixed_passed = sum(1 for c in fixed_cases if c["passed"] is True)
    if fixed_passed != 28:
        print(f"[FAIL] Fixed Lean suite passed {fixed_passed}/28", file=sys.stderr)
        return 1

    # Cross-check key fixed cases independently in Python
    env_atomic = ScopeEnvPy("coh_primary", "des_study", "sentenceAtomic")
    py_t2_default = parse_all_bounded_py(
        env_atomic, 512, 4000, 512, 16,
        b"In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction.",
    )
    assert py_t2_default == "ENUM:2:T2:alt1:trap,T2:alt2:trap", f"Unexpected T2 Python result: {py_t2_default}"

    py_t2_mr1 = parse_all_bounded_py(
        env_atomic, 512, 4000, 512, 1,
        b"In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction.",
    )
    assert py_t2_mr1 == "OVF:maxReadingsExceeded:2:1", f"Unexpected T2 mr=1 result: {py_t2_mr1}"

    # 2. True 1-to-1 External Serialized Batch Differential Verification (`250` vectors)
    batch_vecs = build_batch_vectors()
    env_discourse = ScopeEnvPy("coh_primary", "des_study", "discourseBound")

    py_outcomes = {}
    tsv_lines: List[str] = []
    for vid, mode, mb, ms, mn, mr, raw in batch_vecs:
        env_obj = env_discourse if mode == "discourse" else env_atomic
        py_outcomes[vid] = parse_all_bounded_py(env_obj, mb, ms, mn, mr, raw)
        tsv_lines.append(f"{vid}\t{mode}\t{mb}\t{ms}\t{mn}\t{mr}\t{raw.hex()}")

    with tempfile.NamedTemporaryFile("w", suffix=".tsv", delete=False, encoding="utf-8", newline="\n") as tf:
        tf.write("\n".join(tsv_lines) + "\n")
        tsv_path = Path(tf.name)

    try:
        proc_batch = subprocess.run(
            [str(exe_path), "--eval-batch", str(tsv_path)],
            capture_output=True,
            text=True,
            check=True,
        )
    finally:
        tsv_path.unlink(missing_ok=True)

    lean_lines = [ln.strip() for ln in proc_batch.stdout.splitlines() if ln.strip()]
    if len(lean_lines) != len(batch_vecs):
        print(f"[FAIL] Batch line count mismatch: Lean={len(lean_lines)}, Python={len(batch_vecs)}", file=sys.stderr)
        return 1

    mismatches: List[str] = []
    enum_pos_cnt = 0
    enum_zero_cnt = 0
    ood_cnt = 0
    ovf_cnt = 0

    for ln in lean_lines:
        vid, lean_res = ln.split("\t", 1)
        py_res = py_outcomes[vid]
        if lean_res != py_res:
            mismatches.append(f"  {vid}: Lean='{lean_res}' != Python='{py_res}'")
        if lean_res.startswith("ENUM:0:"):
            enum_zero_cnt += 1
        elif lean_res.startswith("ENUM:"):
            enum_pos_cnt += 1
        elif lean_res.startswith("OOD:"):
            ood_cnt += 1
        elif lean_res.startswith("OVF:"):
            ovf_cnt += 1

    print("==========================================================================")
    print("BROCA-NATIVE OMEGA — P3-B PYTHON 3.11 1:1 DIFFERENTIAL ORACLE REPORT")
    print("==========================================================================")
    print(f"Fixed Curated (PC, CE) Suite Parity : {fixed_passed}/28 PASSED")
    print(f"External Serialized Batch Vectors   : {len(batch_vecs) - len(mismatches)}/{len(batch_vecs)} EXACT 1:1 PARITY")
    print(f"  - Valid Enumerated Parses (|T|>=1): {enum_pos_cnt}")
    print(f"  - In-Domain Invalid (ENUM:0:)     : {enum_zero_cnt}")
    print(f"  - OutOfDomain Rejections (OOD:)   : {ood_cnt}")
    print(f"  - ResourceOverflow Fail-Closed    : {ovf_cnt}")
    print("==========================================================================")

    if mismatches:
        print("[FAIL] Differential Mismatches Detected:", file=sys.stderr)
        for m in mismatches[:20]:
            print(m, file=sys.stderr)
        return 1

    print("DIFFERENTIAL ORACLE VERDICT: 100% EXACT 1:1 PARITY (0 MISMATCHES)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
````

### File 15: `06_receipts/auth_c1_p3b_verification_receipt.json` (SHA-256: `212FE405EA722F72E11CB65493072F688AC86FFB7E6E47D49F6FAD5CDC58E595`)
````json
{
  "schema": "BROCA_NATIVE_OMEGA_AUTH_C1_P3B_RECEIPT_V1",
  "recorded_at": "2026-11-22T22:16:30+09:00",
  "authorization_gate": "AUTH-C1-P3-B",
  "target_scope": "PO-C1-01 Bounded Exhaustive Parser Soundness & Completeness + BridgeSound / ProjectionFaithful Across Frozen P3-A & P2 + F-P3A-01 Full Grammar/Side-Condition/Obligation Correspondence",
  "isolated_root": "C:\\antigravity work\\BROCA_NATIVE_OMEGA_GATE_C1",
  "p3b_subpackage_root": "C:\\antigravity work\\BROCA_NATIVE_OMEGA_GATE_C1\\P3B_BoundedParser",
  "toolchain": {
    "lean_version": "Lean (version 4.33.1, x86_64-w64-windows-gnu, commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6, Release)",
    "lake_version": "Lake version 5.0.0-src+819816b (Lean version 4.33.1)",
    "python_differential_oracle_version": "Python 3.11.8",
    "local_readonly_path_dependencies": [
      "../P2_DerivationReplay",
      "../P3_LexicalGrammar"
    ],
    "external_network_or_mathlib_dependencies": []
  },
  "verification_commands_executed": [
    {
      "command": "lake build",
      "exit_code": 0,
      "jobs_succeeded": "54/54",
      "warnings": 0,
      "errors": 0
    },
    {
      "command": ".\\.lake\\build\\bin\\p3b_tribunal_runner.exe",
      "exit_code": 0,
      "paired_cases_passed": "28/28",
      "status_line": "TOTAL CURATED VECTORS : 28/28 PASSED"
    },
    {
      "command": "python 05_independent_tribunal/differential_oracle_p3b.py",
      "exit_code": 0,
      "fixed_curated_lean_python_parity": "28/28",
      "external_batch_lean_python_parity": "250/250",
      "batch_valid_enumerated_parses": 66,
      "batch_in_domain_enumerated_zero": 110,
      "batch_out_of_domain_rejections": 30,
      "batch_resource_overflow_fail_closed": 44,
      "mismatches": 0
    },
    {
      "command": "lake env leanchecker --fresh P3BTribunalAudit",
      "exit_code": 0,
      "p3b_project_olean_modules": 11,
      "replayed_upstream_frozen_packages": [
        "P2_DerivationReplay",
        "P3_LexicalGrammar"
      ],
      "elapsed_sec": 395.38
    }
  ],
  "axiom_audit": {
    "sorryAx_present": false,
    "ofReduceBool_native_decide_present": false,
    "trustCompiler_present": false,
    "custom_axioms_present": false,
    "unsafe_declarations_present": false,
    "standard_lean_foundational_axioms_only": [
      "propext",
      "Classical.choice",
      "Quot.sound"
    ],
    "per_theorem_axioms": {
      "BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_InterleavedGrammarEq": [
        "propext"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_MatchesP3AFrozenBNF": [
        "propext"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalSideCondEq": [
        "propext"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalIntrinsicOblsEq": [
        "propext",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalSummaryEq": [
        "propext"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_FrozenParseGrammarAcyclic": [
        "propext"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserTerminates": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_C1_01_OutOfDomainBoundarySound": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserSoundness": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserExhaustiveCompleteness": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_C1_01_EnumeratedEmptySound": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_C1_01_ResourceOverflowFailClosed": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_C1_01_NonVacuous_G01_Witness": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_C1_01_NonVacuous_T2_DualReadings": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_LowerToP2Cert_ProjectionFaithful": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_ProjectionFaithful_CheckerIff": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_BridgeSound": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_BridgeSound_MemEnumeratedForest": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_VerifyBridgedDerivation_Sound": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P3B.ProofObligations.PO_P3B_All28CounterexampleVectors_Verified": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ]
    }
  },
  "source_artifact_sha256": {
    "lean-toolchain": "3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71",
    "lakefile.toml": "5566CAF6C914C2C57B772DAAEBE24CDF9A80F7357FD9A70B78E986EC81ED5A71",
    "01_formal_spec/P3BFormalSpec.lean": "53612302FE6918F9B399E74D6A4CFFEF5F19BC7561C46A3082E7925E9A47A307",
    "01_formal_spec/P3BFormalSpec/DeclarativeParseSpec.lean": "078605A7D221C0F6027DE0071D94A97EF616B40DD98E617DA893371C771C645D",
    "01_formal_spec/P3BFormalSpec/FullGrammarCorrespondence.lean": "AAAF8848771BF2A1E2D28D361BA51F911B81A70E98A14DBA53A6E5707C6B7557",
    "02_detached_checker/P3BDetachedChecker.lean": "18434566A21C37331F2375995E5B82EA4DD4D47AD4F7FC7D1F09A9E7A13218CE",
    "02_detached_checker/P3BDetachedChecker/BoundedParser.lean": "1E5668016B5B74CA27A036D833DC106C9A4AF720CE978138683139591051D391",
    "02_detached_checker/P3BDetachedChecker/LexicalReplayBridge.lean": "4737425A39DA8570B5B7779D944A6B8760521116855BA65ED4AA52B43CA0E79C",
    "03_counterexamples/P3BCounterexamples.lean": "575E0CE7C3DA45B03F380EFA708D58DEED51B06F72922CC1E1AB989CE717F592",
    "03_counterexamples/P3BCounterexamples/P3BSuite.lean": "28DBABEEC365916CC8973A85D89EAB516F660C6C66DFAB0139F23F1BF207B3F0",
    "04_proof_obligations/P3BProofObligations.lean": "CFC70A41A3D0DE67A539C36875A0811E50C967041E08C080F48F50ED0309CEB1",
    "04_proof_obligations/P3BProofObligations/PO_C1_01_And_Bridge.lean": "D0A39693AE96EB34234C8459D7873508688064C305A2C0B789E199CC8F040F11",
    "05_independent_tribunal/P3BTribunalAudit.lean": "E0F1D27419BE36D02375B26155BA5AD0F9D2385FF2AC1B9F4A444CDF28A8496A",
    "05_independent_tribunal/differential_oracle_p3b.py": "EF3E734346B3D6F673173777F23BFF4EFDB3D2B0730E8E5A09E34B38296F2CED"
  },
  "compiled_artifact_sha256": {
    "P3BFormalSpec/DeclarativeParseSpec.olean": "124E26B1399449F696A3BE3DFC41C3CBF1FD5F04F0A1473B5D8ACA71BF008038",
    "P3BFormalSpec/FullGrammarCorrespondence.olean": "CF6C77F4A1A0A74ACB184CFA7223D94322D7BAB3067B907FF505F2A551021116",
    "P3BFormalSpec.olean": "17FA2EF13C33A9F8E27F8F29242ACA74BDB7B600D20CBF2F4DEBAAFF25EEE335",
    "P3BDetachedChecker/BoundedParser.olean": "71702629DA8F4CDEA4DEE42C01FE4F27C54590A88DF4E1E2DBCE64B1F0F51C95",
    "P3BDetachedChecker/LexicalReplayBridge.olean": "9A8D6C88CEE0C9E70646D646DD753B58AED255668E9B9E25FA25BDF04B06E885",
    "P3BDetachedChecker.olean": "B07127D2769704D21D8C9C98D746A3EE653C7B20D12F6C44B4625D833348FBAB",
    "P3BCounterexamples/P3BSuite.olean": "FE7E993E4767CA06ED1156957FB0B2AC4997400AFD59B19E97821870439B5E6D",
    "P3BCounterexamples.olean": "ADA3FCF8875F73C6889B820F96233F937D90522B461ED94513B396889C451053",
    "P3BProofObligations/PO_C1_01_And_Bridge.olean": "56F82A640D9E3B595491BF767D2A6BA6FCC7F33059DEA2234A957900776B0723",
    "P3BProofObligations.olean": "11E9F985E9D518A3D0556CAD212FFCEF744FAE6F12EC6001522646794FE62966",
    "P3BTribunalAudit.olean": "D35DBBB8EF62651D4094A262C8004016CF1D38C3D70625208F49879F36DE4244",
    "p3b_tribunal_runner.exe": "3D99D849C7B3E120608EECA1E1F988C2E6D7E73BA101F7B2D4DB4B905B003FAB"
  },
  "prior_gate_immutability_verified": {
    "pneuma_workspace_file_count": 0,
    "frozen_reference_manifest_sha256": "2FA5C7EC0423A6D404EBBB681E2393B9041C7E02634EB71D4505405162D3C076",
    "auth_c1_dir_receipt_sha256": "036E6543AD43365F9B914259840E0508F920FE24F56AAD45824639B7F480620E",
    "auth_c1_p1_receipt_sha256": "EC53292AD346D0FD17393C00F0DE5AD0832CEB48B09CE2D298A97B8101C5CDAB",
    "auth_c1_p2_receipt_sha256": "5D9BFCD3B3F029AF1B338CB47AC0445FB8707437898B9777A6C771BD40029F3E",
    "auth_c1_p3a_receipt_sha256": "46A80A14CEEF917E133B375B49D4C2CD60FCB91300246920D7A819E556BEC79F",
    "p1_sources_unchanged": "13/13",
    "p2_sources_unchanged": "14/14",
    "p3a_sources_unchanged": "14/14",
    "broca_shared_anchors_unchanged": "6/6"
  },
  "scope_and_held_locks": {
    "po_c1_01_bounded_exhaustive_parser_mechanized": true,
    "bridge_sound_and_projection_faithful_mechanized_on_actual_p3a_p2": true,
    "f_p3a_01_full_grammar_sidecond_obligation_correspondence_mechanized": true,
    "f_p3a_01_and_f_p3a_02_evidence_submitted_pending_tribunal_held": true,
    "p3b_external_independent_kernel_replay_held": true,
    "p1_external_replay_held": true,
    "p2_external_replay_held": true,
    "p3a_external_replay_held": true,
    "r0_g01_right_censored_surface_unspecified_held": true,
    "r0_production_ontology_entries_unspecified_held": true,
    "p1_c_int128_fast_path_authorized": false,
    "p3_c_semantic_norm_po_c1_03_authorized": false,
    "p4_clinical_evidence_authorized": false,
    "p5_snapshot_admission_authorized": false,
    "pneuma_s3_s4_integration_authorized": false,
    "master_soundness_proven": false,
    "ancestors_or_p1_or_p2_or_p3a_modified": false
  }
}
````

---

## 6. Explicit Residual `HELD` & `NOT_AUTHORIZED` Ledger (`FROZEN_AND_STANDBY`)

- **`F-P3A-01` & `F-P3A-02`**: `EVIDENCE_SUBMITTED_PENDING_TRIBUNAL_HELD` (formal proofs & executable evidence submitted above; no self-promotion prior to Independent Tribunal disposition).
- **External Independent Kernel Replay (`P1`, `P2`, `P3-A`, `P3-B`)**: `HELD` (local `lake env leanchecker --fresh P3BTribunalAudit` exited `0` in `395.38s`; external host binary replay remains under Tribunal control).
- **`Architecture Freeze R0` Unspecified Items**: `HELD_UNSPECIFIED_IN_R0` (`G-01` right-censored KM/AJ English surface template & production clinical ontology catalog entries were NOT invented).
- **Downstream Phases (`P1-C`, `P3-C`, `P4`, `P5`, `Pneuma-S3/S4`)**: `NOT_AUTHORIZED` (`0` files touched).
- **Current Execution Posture**: `FROZEN_AND_STANDBY`.

