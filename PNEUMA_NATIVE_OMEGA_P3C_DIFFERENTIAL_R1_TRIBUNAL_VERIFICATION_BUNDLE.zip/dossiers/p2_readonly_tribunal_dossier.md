# BROCA-NATIVE Ω — AUTH-C1-P2 Read-Only Independent Tribunal Verification Bundle (`PO-C1-02`)

> [!IMPORTANT]
> **Read-Only Audit Submission (`PO-C1-02`: Derivation Replay Soundness & Completeness)**
> All Lean `4.33.1` source files, build configurations, Python `3.11` differential oracle code, execution logs, and receipt JSON contents below are **100% verbatim, unmodified copies** of the files on disk inside `C:\antigravity work\BROCA_NATIVE_OMEGA_GATE_C1\P2_DerivationReplay\` and `06_receipts\`. All `AUTH-C1-P1` (`13/13` files) and ancestor `Broca`/`shared`/`Pneuma` (`0` files) hashes remain untouched (`PO_C1_04A_FINAL_EXTERNAL_ADMISSION_HELD` preserved).

---

## 1. Tribunal Source Audit Index (`P2-T01` ~ `P2-T10` Exact Line Mapping)

| Audit ID | Audit Criterion | Verbatim Source Location & Mechanism |
| :--- | :--- | :--- |
| **`P2-T01`** | Free Commutative Monoid Multiset Accounting & `NoDupOblIds` | `ObligationLedger.lean`: `countOcc`, `MultisetEq`, `checkMultisetEqBool_iff`, `NoDupOblIds`, `checkNoDupOblIdsBool_iff` (prevents weakening & contraction). |
| **`P2-T02`** | Frozen `G-01` ~ `G-16` Rule Table & Trap-Rule Exclusion | `GrammarG16.lean`: `FrozenGenRule` (`27` closed constructors), `decodeFrozenRule` (rejects trap codes `901`~`905` and arbitrary codes), `ruleSignature` (exact segments, side conditions, intrinsic obligations). |
| **`P2-T03`** | Acyclic Nonterminal Stratification Proof (`rank` `0..4`) | `GrammarG16.lean`: `NontermCat.rank` and `child_rank_lt_lhs_rank` (proves `cat.rank < (ruleSignature r).lhsCat.rank` on every rule edge; blocks recursive `G-15`/`G-16` cycles). |
| **`P2-T04`** | Syncategorematic Reserved Keyword & `-0.0` Barrier | `GrammarG16.lean`: `forbiddenSlotDelimiters`, `isValidNumericSurface`, `isValidSlotLexeme` (blocks `"did not"`, `". "`, `";"`, `"however"`, etc. inside open slots). |
| **`P2-T05`** | Exact Prefix-Slice Contiguous Span Algebra (`Yield(π) = Y`) | `DeclarativeSemantics.lean`: `SpanMatches`, `spanMatches_concat`, `spanMatches_full_eq`, `validGrammarDerivation_yield_eq` (`reconstructYield cert = Y`). |
| **`P2-T06`** | Independent `LocusTargetBound` Predicate (Rules Out Both Locus & Target Swaps) | `DeclarativeSemantics.lean`: `synthSegSlotsSums`, `NodeLocusTargetBound`, `LocusTargetBound` (enforces `claimed.map (·.spec) = (ruleSignature r).intrinsicObls loc slots sums` AND `ClauseLocus` validity at every node). |
| **`P2-T07`** | Sealed Proof-Carrying `CertifiedDerivation` vs Non-Authoritative `CEGESReplayDiag` | `ReplayChecker.lean`: `CertifiedDerivation` (`private mk ::`), `ReplayOutcome.accepted` vs `ReplayOutcome.rejected (diag : CEGESReplayDiag)`. |
| **`P2-T08`** | Witness Binding + `PO-C1-02` Soundness & Relative Completeness | `ReplayChecker.lean`: `replayDerivation_witness_cert_eq` (`w.cert = cert`), `replayDerivation_sound`, and `replayDerivation_complete` (`0` `sorry`). |
| **`P2-T09`** | 12 Symmetric `(PC, CE)` Pairs (`24` Kernel-Checked Cases, Zero `native_decide`) | `P2Suite.lean`: `pc01`..`ce12` proved at compile time via `decide` (`allP2Cases_verified`), including `CE-P2-08` (clause-locus swap with multiset preserved) and `CE-P2-09` (target-payload swap with locus & multiset preserved). |
| **`P2-T10`** | `#print axioms`, `leanchecker --fresh`, & Python `3.11` Differential Oracle | `P2TribunalAudit.lean` (`10` `#print axioms` declarations, zero `Lean.ofReduceBool` / `sorryAx`) + `differential_oracle_p2.py` (`24/24` parity + `240/240` adversarial fuzz rejections). |

---

## 2. SHA-256 Integrity Ledger (`.lean` Sources, `.olean` Artifacts, Receipt & Prior Gate Preservation)

### 2.1 Prior Gate & Ancestor Immutability Verification
- `C:\antigravity work\Pneuma`: `0` files (`UNCHANGED`)
- `00_frozen_reference/manifest_only/frozen_reference_manifest.json`: `2FA5C7EC0423A6D404EBBB681E2393B9041C7E02634EB71D4505405162D3C076` (`6/6` `Broca`/`shared` anchors verified)
- `06_receipts/auth_c1_dir_environment_receipt.json`: `036E6543AD43365F9B914259840E0508F920FE24F56AAD45824639B7F480620E` (`UNCHANGED`)
- `06_receipts/auth_c1_p1_verification_receipt.json`: `EC53292AD346D0FD17393C00F0DE5AD0832CEB48B09CE2D298A97B8101C5CDAB` (`13/13` `P1` source files verified)
- `06_receipts/auth_c1_p2_verification_receipt.json`: `5D9BFCD3B3F029AF1B338CB47AC0445FB8707437898B9777A6C771BD40029F3E`

### 2.2 `P2` Source ↔ `.olean` SHA-256 Correspondence

| Relative Path (`P2_DerivationReplay/`) | Source SHA-256 | Compiled `.olean` / `.exe` SHA-256 |
| :--- | :--- | :--- |
| `lean-toolchain` | `3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71` | *(config / oracle script)* |
| `lakefile.toml` | `C820C282EE9C00920FB2F5B39F9E7150C6B9018F9936C534081E7D34A9688EAF` | *(config / oracle script)* |
| `01_formal_spec/P2FormalSpec.lean` | `C07FDB6E76A087FF7DD3B986F8C1034AD1554C5ABB5A260FBECAE1C74AF18B94` | `DB37ED56066D8E3B072DB2BCE81C6A0A68EB2852F3B90F709914AF4948DBECCB` |
| `01_formal_spec/P2FormalSpec/ObligationLedger.lean` | `72984286ABC21A925E8DAD5D1933D43405EF843D00C1A38ABA8B785A749D0D65` | `7E0F29DA38E077CC1CA53A4AD46DEABA98D2047762D5EC78201A27AAAEF7EDEC` |
| `01_formal_spec/P2FormalSpec/GrammarG16.lean` | `97B20F7A2BA892A23CB94D9D6B7FFB9E14BB8FF22AFD3D4B4BE4C6CFC82E130C` | `16821A978B0CB45AF3F238A743630B7A07FA7E517896BD8806A6C631BB59CC1D` |
| `01_formal_spec/P2FormalSpec/DeclarativeSemantics.lean` | `47409B4A5CCB8CA9001B92B7F2ACE4719B9AAECB4FD3AE4E2E6162DE247D1F1B` | `9FFCC145B91492E5B3F987226E963337340E0D964FEDA01F3AB890641FC22E32` |
| `02_detached_checker/P2DetachedChecker.lean` | `E760EA1634186EEC8E063CCC1EA28C6E84E07AAD87BCEEBB1DD43DAED7E4F997` | `F68688585AFDE1ABA5E53FE1FA3DE755CC18C1D276A72DEC3F779F84B1AB4381` |
| `02_detached_checker/P2DetachedChecker/ReplayChecker.lean` | `DC30D0E9313A9A695B19852ADC9C1DDF45F6FC05E31DD9DE9777AB2299E91068` | `2757F05E4CF2AE5DC19FB74F540E8194E7619193BC11016BF7AED5E864181AB0` |
| `03_counterexamples/P2Counterexamples.lean` | `DF074F59C32A38F5098BD8E5DE4EC17364A1DCD0967EE0BE54479AC7EB7063EA` | `04DB5514AFFFC618F4EF42B44D169FAAD375BABE3F2E06C3152AE4859F111528` |
| `03_counterexamples/P2Counterexamples/P2Suite.lean` | `23C5DC565F18402A98F70E691935FC1DB38E29B2E2B884E906F07A05606F9E6B` | `437235E644A5239251F059A98A5C69B17C85342F1547A189C0058B3E142CDE4C` |
| `04_proof_obligations/P2ProofObligations.lean` | `439AEF182FFC6C4F421B2560E787E0F6B74D6609EA2EBDAC465882E98F27CCAD` | `3A9B9A2005D167171091BCA0E5E43B2B7D1D4A4E6A37732953EFC3D1784DB39B` |
| `04_proof_obligations/P2ProofObligations/PO_C1_02_ReplaySoundness.lean` | `64CA94681C5791E03FCE479CEBC1DBF385BB8B4B8344406ACFD7AF032789E27B` | `20608B33AF14E59093E1A1CF22CA7409FAFDBD3751438F44A4A277F2BA44A3D2` |
| `05_independent_tribunal/P2TribunalAudit.lean` | `BC9164210E9F347940FC3ECEADC09FD1855D141D5CDD5D3FFC2FC70936C3B4E7` | `FE4DB546C2788F9E415F53B1B710F7D54E4E5F0D3507E4241BDF9D1E2B22FCD9` / exe `AABB56BE3977A176A09304F4BEE1C90D02B13122E4826BB9D3130C20A4B7F2E8` |
| `05_independent_tribunal/differential_oracle_p2.py` | `0D9423FAD53DF981BC623ED6E39E5163ACBFBCE55ACF084339B6B16AE8AFF8C5` | *(config / oracle script)* |

---

## 3. Verbatim Execution, `#print axioms`, `leanchecker --fresh`, and Differential Oracle Logs

### 3.1 `lake build` & `#print axioms` Output
```text
✔ [10/28] Built P2FormalSpec.ObligationLedger:c.o (136s)
✔ [11/28] Built P2FormalSpec.GrammarG16:c.o (136s)
✔ [12/28] Built P2FormalSpec.DeclarativeSemantics:c.o (136s)
✔ [13/28] Built P2FormalSpec:c.o (136s)
✔ [14/28] Built P2DetachedChecker.ReplayChecker:c.o (136s)
✔ [15/28] Built P2DetachedChecker:c.o (136s)
✔ [16/28] Built P2Counterexamples.P2Suite (137s)
✔ [17/28] Built P2Counterexamples (821ms)
✔ [19/28] Built P2Counterexamples.P2Suite:c.o (772ms)
✔ [20/28] Built P2Counterexamples:c.o (880ms)
✔ [21/28] Built P2ProofObligations.PO_C1_02_ReplaySoundness (941ms)
✔ [22/28] Built P2ProofObligations.PO_C1_02_ReplaySoundness:c.o (810ms)
✔ [23/28] Built P2ProofObligations (863ms)
✔ [25/28] Built P2ProofObligations:c.o (1.1s)
ℹ [26/28] Built P2TribunalAudit (1.2s)
info: 05_independent_tribunal/P2TribunalAudit.lean:18:0: 'BrocaOmega.P2.ProofObligations.PO_C1_02_GrammarAcyclicRank' depends on axioms: [propext]
info: 05_independent_tribunal/P2TribunalAudit.lean:19:0: 'BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplaySoundness' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P2TribunalAudit.lean:20:0: 'BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplayCompleteness' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P2TribunalAudit.lean:21:0: 'BrocaOmega.P2.ProofObligations.PO_C1_02_CounterexampleSuiteVerified' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P2TribunalAudit.lean:22:0: 'BrocaOmega.P2.validGrammarDerivation_yield_eq' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P2TribunalAudit.lean:23:0: 'BrocaOmega.P2.validGrammarDerivation_implies_locusTargetBound' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P2TribunalAudit.lean:24:0: 'BrocaOmega.P2.spanMatches_concat' depends on axioms: [propext, Classical.choice, Quot.sound]
info: 05_independent_tribunal/P2TribunalAudit.lean:25:0: 'BrocaOmega.P2.spanMatches_full_eq' depends on axioms: [propext, Quot.sound]
info: 05_independent_tribunal/P2TribunalAudit.lean:26:0: 'BrocaOmega.P2.checkMultisetEqBool_iff' depends on axioms: [propext, Quot.sound]
info: 05_independent_tribunal/P2TribunalAudit.lean:27:0: 'BrocaOmega.P2.checkNoDupOblIdsBool_iff' depends on axioms: [propext, Quot.sound]
✔ [27/28] Built P2TribunalAudit:c.o (317ms)
✔ [28/28] Built p2_tribunal_runner:exe (661ms)
Build completed successfully (28 jobs).
```

### 3.2 `p2_tribunal_runner.exe` Execution Output (`24/24` Symmetric Vectors)
```text
==========================================================================
BROCA-NATIVE OMEGA — AUTH-C1-P2 DETACHED DERIVATION REPLAY VERIFICATION
Target Obligation : PO-C1-02 (Derivation Replay Soundness & Completeness)
Toolchain         : Lean 4.33.1 Core (Init only, 0 external deps, 0 sorry)
==========================================================================
[PASS] PC-P2-01 (PAIR-01-RULE-ID) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-01 (PAIR-01-RULE-ID) => REJECTED (forgedOrTrapRuleId)
[PASS] PC-P2-02 (PAIR-02-FIXED-TERMINAL) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-02 (PAIR-02-FIXED-TERMINAL) => REJECTED (fixedTerminalMismatch)
[PASS] PC-P2-03 (PAIR-03-YIELD-1CHAR) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-03 (PAIR-03-YIELD-1CHAR) => REJECTED (spanSliceMismatch)
[PASS] PC-P2-04 (PAIR-04-SPAN-GAP) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-04 (PAIR-04-SPAN-GAP) => REJECTED (spanStartDiscontinuity)
[PASS] PC-P2-05 (PAIR-05-DUP-OBL-ID) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-05 (PAIR-05-DUP-OBL-ID) => REJECTED (duplicateOblIdDischarged)
[PASS] PC-P2-06 (PAIR-06-UNCONSUMED-OBL) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-06 (PAIR-06-UNCONSUMED-OBL) => REJECTED (obligationMultisetMismatch)
[PASS] PC-P2-07 (PAIR-07-UNLICENSED-OBL) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-07 (PAIR-07-UNLICENSED-OBL) => REJECTED (locusOrTargetOblMismatch)
[PASS] PC-P2-08 (PAIR-08-CLAUSE-LOCUS-SWAP) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-08 (PAIR-08-CLAUSE-LOCUS-SWAP) => REJECTED (locusOrTargetOblMismatch)
[PASS] PC-P2-09 (PAIR-09-TARGET-SWAP) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-09 (PAIR-09-TARGET-SWAP) => REJECTED (locusOrTargetOblMismatch)
[PASS] PC-P2-10 (PAIR-10-ACYCLIC-G15) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-10 (PAIR-10-ACYCLIC-G15) => REJECTED (nontermCatMismatch)
[PASS] PC-P2-11 (PAIR-11-G16-SIDE-COND) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-11 (PAIR-11-G16-SIDE-COND) => REJECTED (sideConditionFailed)
[PASS] PC-P2-12 (PAIR-12-KEYWORD-BARRIER) => ACCEPTED (reconstructYield == Y: true)
[PASS] CE-P2-12 (PAIR-12-KEYWORD-BARRIER) => REJECTED (invalidSlotLexemeOrKeywordLeak)
--------------------------------------------------------------------------
SUMMARY: 24 / 24 symmetric (PC, CE) vectors verified.
P1 External Replay Status : HELD (PO_C1_04A_FINAL_EXTERNAL_ADMISSION_HELD)
P1-C / P3..P5 / Pneuma-S3 : NOT_AUTHORIZED
==========================================================================
```

### 3.3 `lake env leanchecker --fresh P2TribunalAudit` Kernel Replay Output
```text
﻿Command: lake env leanchecker --fresh P2TribunalAudit
WorkingDirectory: C:\antigravity work\BROCA_NATIVE_OMEGA_GATE_C1\P2_DerivationReplay
LEANCHECKER_EXIT_CODE=0
LEANCHECKER_ELAPSED_SEC=178.81
```

### 3.4 Python `3.11` Differential Oracle Output (`24/24` Parity + `240/240` Fuzz Rejections)
```text
==========================================================================
PYTHON 3.11 INDEPENDENT DIFFERENTIAL ORACLE — BROCA-NATIVE OMEGA P2
Loaded 24 serialized vectors from Lean p2_tribunal_runner.exe
==========================================================================
[PARITY_OK] PC-P2-01 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-01 | Lean=(False, forgedOrTrapRuleId) | Python=(False, forgedOrTrapRuleId)
[PARITY_OK] PC-P2-02 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-02 | Lean=(False, fixedTerminalMismatch) | Python=(False, fixedTerminalMismatch)
[PARITY_OK] PC-P2-03 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-03 | Lean=(False, spanSliceMismatch) | Python=(False, spanSliceMismatch)
[PARITY_OK] PC-P2-04 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-04 | Lean=(False, spanStartDiscontinuity) | Python=(False, spanStartDiscontinuity)
[PARITY_OK] PC-P2-05 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-05 | Lean=(False, duplicateOblIdDischarged) | Python=(False, duplicateOblIdDischarged)
[PARITY_OK] PC-P2-06 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-06 | Lean=(False, obligationMultisetMismatch) | Python=(False, obligationMultisetMismatch)
[PARITY_OK] PC-P2-07 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-07 | Lean=(False, locusOrTargetOblMismatch) | Python=(False, locusOrTargetOblMismatch)
[PARITY_OK] PC-P2-08 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-08 | Lean=(False, locusOrTargetOblMismatch) | Python=(False, locusOrTargetOblMismatch)
[PARITY_OK] PC-P2-09 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-09 | Lean=(False, locusOrTargetOblMismatch) | Python=(False, locusOrTargetOblMismatch)
[PARITY_OK] PC-P2-10 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-10 | Lean=(False, nontermCatMismatch) | Python=(False, nontermCatMismatch)
[PARITY_OK] PC-P2-11 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-11 | Lean=(False, sideConditionFailed) | Python=(False, sideConditionFailed)
[PARITY_OK] PC-P2-12 | Lean=(True, NONE) | Python=(True, NONE)
[PARITY_OK] CE-P2-12 | Lean=(False, invalidSlotLexemeOrKeywordLeak) | Python=(False, invalidSlotLexemeOrKeywordLeak)
--------------------------------------------------------------------------
Suite Differential Parity : 24 / 24 EXACT MATCH
Adversarial Fuzz Trials   : 240 / 240 REJECTED (seed=20261122)
==========================================================================
```

---

## 4. Verbatim `auth_c1_p2_verification_receipt.json`
(`SHA-256: 5D9BFCD3B3F029AF1B338CB47AC0445FB8707437898B9777A6C771BD40029F3E`)
```json
{
  "schema": "BROCA_NATIVE_OMEGA_AUTH_C1_P2_RECEIPT_V1",
  "recorded_at": "2026-11-22T19:25:00+09:00",
  "authorization_gate": "AUTH-C1-P2",
  "target_proof_obligation": "PO-C1-02 (Derivation Replay Soundness & Relative Completeness)",
  "isolated_root": "C:\\antigravity work\\BROCA_NATIVE_OMEGA_GATE_C1",
  "p2_subpackage_root": "C:\\antigravity work\\BROCA_NATIVE_OMEGA_GATE_C1\\P2_DerivationReplay",
  "toolchain": {
    "lean_version": "Lean (version 4.33.1, x86_64-w64-windows-gnu, commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6, Release)",
    "lake_version": "Lake version 5.0.0-src+819816b (Lean version 4.33.1)",
    "python_differential_oracle_version": "Python 3.11.8",
    "external_lean_dependencies": []
  },
  "verification_commands_executed": [
    {
      "command": "lake build",
      "exit_code": 0,
      "jobs_succeeded": "28/28",
      "warnings": 0,
      "errors": 0
    },
    {
      "command": ".\\.lake\\build\\bin\\p2_tribunal_runner.exe",
      "exit_code": 0,
      "paired_cases_passed": "24/24",
      "status_line": "SUMMARY: 24 / 24 symmetric (PC, CE) vectors verified."
    },
    {
      "command": "lake env leanchecker --fresh P2TribunalAudit",
      "exit_code": 0,
      "project_olean_modules": 11,
      "elapsed_sec": 178.81
    },
    {
      "command": "python 05_independent_tribunal/differential_oracle_p2.py",
      "exit_code": 0,
      "suite_differential_parity": "24/24",
      "adversarial_fuzz_rejected": "240/240",
      "prng_seed": 20261122
    }
  ],
  "axiom_audit": {
    "sorryAx_present": false,
    "ofReduceBool_native_decide_present": false,
    "trustCompiler_present": false,
    "custom_axioms_present": false,
    "unsafe_declarations_present": false,
    "standard_lean_foundational_axioms_only": [
      "propext",
      "Classical.choice",
      "Quot.sound"
    ],
    "per_theorem_axioms": {
      "BrocaOmega.P2.ProofObligations.PO_C1_02_GrammarAcyclicRank": [
        "propext"
      ],
      "BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplaySoundness": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplayCompleteness": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P2.ProofObligations.PO_C1_02_CounterexampleSuiteVerified": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P2.validGrammarDerivation_yield_eq": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P2.validGrammarDerivation_implies_locusTargetBound": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P2.spanMatches_concat": [
        "propext",
        "Classical.choice",
        "Quot.sound"
      ],
      "BrocaOmega.P2.spanMatches_full_eq": [
        "propext",
        "Quot.sound"
      ],
      "BrocaOmega.P2.checkMultisetEqBool_iff": [
        "propext",
        "Quot.sound"
      ],
      "BrocaOmega.P2.checkNoDupOblIdsBool_iff": [
        "propext",
        "Quot.sound"
      ]
    }
  },
  "source_artifact_sha256": {
    "lean-toolchain": "3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71",
    "lakefile.toml": "C820C282EE9C00920FB2F5B39F9E7150C6B9018F9936C534081E7D34A9688EAF",
    "01_formal_spec/P2FormalSpec.lean": "C07FDB6E76A087FF7DD3B986F8C1034AD1554C5ABB5A260FBECAE1C74AF18B94",
    "01_formal_spec/P2FormalSpec/ObligationLedger.lean": "72984286ABC21A925E8DAD5D1933D43405EF843D00C1A38ABA8B785A749D0D65",
    "01_formal_spec/P2FormalSpec/GrammarG16.lean": "97B20F7A2BA892A23CB94D9D6B7FFB9E14BB8FF22AFD3D4B4BE4C6CFC82E130C",
    "01_formal_spec/P2FormalSpec/DeclarativeSemantics.lean": "47409B4A5CCB8CA9001B92B7F2ACE4719B9AAECB4FD3AE4E2E6162DE247D1F1B",
    "02_detached_checker/P2DetachedChecker.lean": "E760EA1634186EEC8E063CCC1EA28C6E84E07AAD87BCEEBB1DD43DAED7E4F997",
    "02_detached_checker/P2DetachedChecker/ReplayChecker.lean": "DC30D0E9313A9A695B19852ADC9C1DDF45F6FC05E31DD9DE9777AB2299E91068",
    "03_counterexamples/P2Counterexamples.lean": "DF074F59C32A38F5098BD8E5DE4EC17364A1DCD0967EE0BE54479AC7EB7063EA",
    "03_counterexamples/P2Counterexamples/P2Suite.lean": "23C5DC565F18402A98F70E691935FC1DB38E29B2E2B884E906F07A05606F9E6B",
    "04_proof_obligations/P2ProofObligations.lean": "439AEF182FFC6C4F421B2560E787E0F6B74D6609EA2EBDAC465882E98F27CCAD",
    "04_proof_obligations/P2ProofObligations/PO_C1_02_ReplaySoundness.lean": "64CA94681C5791E03FCE479CEBC1DBF385BB8B4B8344406ACFD7AF032789E27B",
    "05_independent_tribunal/P2TribunalAudit.lean": "BC9164210E9F347940FC3ECEADC09FD1855D141D5CDD5D3FFC2FC70936C3B4E7",
    "05_independent_tribunal/differential_oracle_p2.py": "0D9423FAD53DF981BC623ED6E39E5163ACBFBCE55ACF084339B6B16AE8AFF8C5"
  },
  "compiled_artifact_sha256": {
    "P2FormalSpec/ObligationLedger.olean": "7E0F29DA38E077CC1CA53A4AD46DEABA98D2047762D5EC78201A27AAAEF7EDEC",
    "P2FormalSpec/GrammarG16.olean": "16821A978B0CB45AF3F238A743630B7A07FA7E517896BD8806A6C631BB59CC1D",
    "P2FormalSpec/DeclarativeSemantics.olean": "9FFCC145B91492E5B3F987226E963337340E0D964FEDA01F3AB890641FC22E32",
    "P2FormalSpec.olean": "DB37ED56066D8E3B072DB2BCE81C6A0A68EB2852F3B90F709914AF4948DBECCB",
    "P2DetachedChecker/ReplayChecker.olean": "2757F05E4CF2AE5DC19FB74F540E8194E7619193BC11016BF7AED5E864181AB0",
    "P2DetachedChecker.olean": "F68688585AFDE1ABA5E53FE1FA3DE755CC18C1D276A72DEC3F779F84B1AB4381",
    "P2Counterexamples/P2Suite.olean": "437235E644A5239251F059A98A5C69B17C85342F1547A189C0058B3E142CDE4C",
    "P2Counterexamples.olean": "04DB5514AFFFC618F4EF42B44D169FAAD375BABE3F2E06C3152AE4859F111528",
    "P2ProofObligations/PO_C1_02_ReplaySoundness.olean": "20608B33AF14E59093E1A1CF22CA7409FAFDBD3751438F44A4A277F2BA44A3D2",
    "P2ProofObligations.olean": "3A9B9A2005D167171091BCA0E5E43B2B7D1D4A4E6A37732953EFC3D1784DB39B",
    "P2TribunalAudit.olean": "FE4DB546C2788F9E415F53B1B710F7D54E4E5F0D3507E4241BDF9D1E2B22FCD9",
    "p2_tribunal_runner.exe": "AABB56BE3977A176A09304F4BEE1C90D02B13122E4826BB9D3130C20A4B7F2E8"
  },
  "prior_gate_immutability_verified": {
    "pneuma_workspace_file_count": 0,
    "frozen_reference_manifest_sha256": "2FA5C7EC0423A6D404EBBB681E2393B9041C7E02634EB71D4505405162D3C076",
    "auth_c1_dir_receipt_sha256": "036E6543AD43365F9B914259840E0508F920FE24F56AAD45824639B7F480620E",
    "auth_c1_p1_receipt_sha256": "EC53292AD346D0FD17393C00F0DE5AD0832CEB48B09CE2D298A97B8101C5CDAB",
    "p1_sources_unchanged": "13/13",
    "broca_shared_anchors_unchanged": "6/6"
  },
  "verbatim_logs": {
    "lake_build_and_print_axioms": "✔ [10/28] Built P2FormalSpec.ObligationLedger:c.o (136s)\n✔ [11/28] Built P2FormalSpec.GrammarG16:c.o (136s)\n✔ [12/28] Built P2FormalSpec.DeclarativeSemantics:c.o (136s)\n✔ [13/28] Built P2FormalSpec:c.o (136s)\n✔ [14/28] Built P2DetachedChecker.ReplayChecker:c.o (136s)\n✔ [15/28] Built P2DetachedChecker:c.o (136s)\n✔ [16/28] Built P2Counterexamples.P2Suite (137s)\n✔ [17/28] Built P2Counterexamples (821ms)\n✔ [19/28] Built P2Counterexamples.P2Suite:c.o (772ms)\n✔ [20/28] Built P2Counterexamples:c.o (880ms)\n✔ [21/28] Built P2ProofObligations.PO_C1_02_ReplaySoundness (941ms)\n✔ [22/28] Built P2ProofObligations.PO_C1_02_ReplaySoundness:c.o (810ms)\n✔ [23/28] Built P2ProofObligations (863ms)\n✔ [25/28] Built P2ProofObligations:c.o (1.1s)\nℹ [26/28] Built P2TribunalAudit (1.2s)\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:18:0: 'BrocaOmega.P2.ProofObligations.PO_C1_02_GrammarAcyclicRank' depends on axioms: [propext]\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:19:0: 'BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplaySoundness' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:20:0: 'BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplayCompleteness' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:21:0: 'BrocaOmega.P2.ProofObligations.PO_C1_02_CounterexampleSuiteVerified' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:22:0: 'BrocaOmega.P2.validGrammarDerivation_yield_eq' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:23:0: 'BrocaOmega.P2.validGrammarDerivation_implies_locusTargetBound' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:24:0: 'BrocaOmega.P2.spanMatches_concat' depends on axioms: [propext, Classical.choice, Quot.sound]\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:25:0: 'BrocaOmega.P2.spanMatches_full_eq' depends on axioms: [propext, Quot.sound]\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:26:0: 'BrocaOmega.P2.checkMultisetEqBool_iff' depends on axioms: [propext, Quot.sound]\ninfo: 05_independent_tribunal/P2TribunalAudit.lean:27:0: 'BrocaOmega.P2.checkNoDupOblIdsBool_iff' depends on axioms: [propext, Quot.sound]\n✔ [27/28] Built P2TribunalAudit:c.o (317ms)\n✔ [28/28] Built p2_tribunal_runner:exe (661ms)\nBuild completed successfully (28 jobs).",
    "p2_tribunal_runner": "==========================================================================\nBROCA-NATIVE OMEGA — AUTH-C1-P2 DETACHED DERIVATION REPLAY VERIFICATION\nTarget Obligation : PO-C1-02 (Derivation Replay Soundness & Completeness)\nToolchain         : Lean 4.33.1 Core (Init only, 0 external deps, 0 sorry)\n==========================================================================\n[PASS] PC-P2-01 (PAIR-01-RULE-ID) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-01 (PAIR-01-RULE-ID) => REJECTED (forgedOrTrapRuleId)\n[PASS] PC-P2-02 (PAIR-02-FIXED-TERMINAL) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-02 (PAIR-02-FIXED-TERMINAL) => REJECTED (fixedTerminalMismatch)\n[PASS] PC-P2-03 (PAIR-03-YIELD-1CHAR) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-03 (PAIR-03-YIELD-1CHAR) => REJECTED (spanSliceMismatch)\n[PASS] PC-P2-04 (PAIR-04-SPAN-GAP) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-04 (PAIR-04-SPAN-GAP) => REJECTED (spanStartDiscontinuity)\n[PASS] PC-P2-05 (PAIR-05-DUP-OBL-ID) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-05 (PAIR-05-DUP-OBL-ID) => REJECTED (duplicateOblIdDischarged)\n[PASS] PC-P2-06 (PAIR-06-UNCONSUMED-OBL) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-06 (PAIR-06-UNCONSUMED-OBL) => REJECTED (obligationMultisetMismatch)\n[PASS] PC-P2-07 (PAIR-07-UNLICENSED-OBL) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-07 (PAIR-07-UNLICENSED-OBL) => REJECTED (locusOrTargetOblMismatch)\n[PASS] PC-P2-08 (PAIR-08-CLAUSE-LOCUS-SWAP) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-08 (PAIR-08-CLAUSE-LOCUS-SWAP) => REJECTED (locusOrTargetOblMismatch)\n[PASS] PC-P2-09 (PAIR-09-TARGET-SWAP) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-09 (PAIR-09-TARGET-SWAP) => REJECTED (locusOrTargetOblMismatch)\n[PASS] PC-P2-10 (PAIR-10-ACYCLIC-G15) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-10 (PAIR-10-ACYCLIC-G15) => REJECTED (nontermCatMismatch)\n[PASS] PC-P2-11 (PAIR-11-G16-SIDE-COND) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-11 (PAIR-11-G16-SIDE-COND) => REJECTED (sideConditionFailed)\n[PASS] PC-P2-12 (PAIR-12-KEYWORD-BARRIER) => ACCEPTED (reconstructYield == Y: true)\n[PASS] CE-P2-12 (PAIR-12-KEYWORD-BARRIER) => REJECTED (invalidSlotLexemeOrKeywordLeak)\n--------------------------------------------------------------------------\nSUMMARY: 24 / 24 symmetric (PC, CE) vectors verified.\nP1 External Replay Status : HELD (PO_C1_04A_FINAL_EXTERNAL_ADMISSION_HELD)\nP1-C / P3..P5 / Pneuma-S3 : NOT_AUTHORIZED\n==========================================================================",
    "python_differential_oracle": "==========================================================================\nPYTHON 3.11 INDEPENDENT DIFFERENTIAL ORACLE — BROCA-NATIVE OMEGA P2\nLoaded 24 serialized vectors from Lean p2_tribunal_runner.exe\n==========================================================================\n[PARITY_OK] PC-P2-01 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-01 | Lean=(False, forgedOrTrapRuleId) | Python=(False, forgedOrTrapRuleId)\n[PARITY_OK] PC-P2-02 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-02 | Lean=(False, fixedTerminalMismatch) | Python=(False, fixedTerminalMismatch)\n[PARITY_OK] PC-P2-03 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-03 | Lean=(False, spanSliceMismatch) | Python=(False, spanSliceMismatch)\n[PARITY_OK] PC-P2-04 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-04 | Lean=(False, spanStartDiscontinuity) | Python=(False, spanStartDiscontinuity)\n[PARITY_OK] PC-P2-05 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-05 | Lean=(False, duplicateOblIdDischarged) | Python=(False, duplicateOblIdDischarged)\n[PARITY_OK] PC-P2-06 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-06 | Lean=(False, obligationMultisetMismatch) | Python=(False, obligationMultisetMismatch)\n[PARITY_OK] PC-P2-07 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-07 | Lean=(False, locusOrTargetOblMismatch) | Python=(False, locusOrTargetOblMismatch)\n[PARITY_OK] PC-P2-08 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-08 | Lean=(False, locusOrTargetOblMismatch) | Python=(False, locusOrTargetOblMismatch)\n[PARITY_OK] PC-P2-09 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-09 | Lean=(False, locusOrTargetOblMismatch) | Python=(False, locusOrTargetOblMismatch)\n[PARITY_OK] PC-P2-10 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-10 | Lean=(False, nontermCatMismatch) | Python=(False, nontermCatMismatch)\n[PARITY_OK] PC-P2-11 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-11 | Lean=(False, sideConditionFailed) | Python=(False, sideConditionFailed)\n[PARITY_OK] PC-P2-12 | Lean=(True, NONE) | Python=(True, NONE)\n[PARITY_OK] CE-P2-12 | Lean=(False, invalidSlotLexemeOrKeywordLeak) | Python=(False, invalidSlotLexemeOrKeywordLeak)\n--------------------------------------------------------------------------\nSuite Differential Parity : 24 / 24 EXACT MATCH\nAdversarial Fuzz Trials   : 240 / 240 REJECTED (seed=20261122)\n=========================================================================="
  },
  "scope_and_held_locks": {
    "po_c1_02_derivation_replay_mechanized_in_lean4": true,
    "po_c1_02_external_independent_kernel_replay_held": true,
    "po_c1_04a_final_external_admission_held": true,
    "p1_c_fixed_width_int128_implemented": false,
    "po_c1_01_parser_completeness_held": true,
    "po_c1_03_normalization_soundness_held": true,
    "po_c1_04b_clinical_evidence_witness_held": true,
    "po_c1_05_serialization_snapshot_held": true,
    "po_c1_06_full_pipeline_completeness_held": true,
    "master_soundness_held": true,
    "pneuma_s3_s4_integration_authorized": false,
    "scientific_or_clinical_validity_certified": false,
    "ancestors_or_p1_modified": false
  }
}
```

---

## 5. Verbatim `P2_DerivationReplay` Source Files (100% Unmodified)

### 5.1 `lean-toolchain` (`SHA-256: 3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71`)
```text
leanprover/lean4:v4.33.1
```

### 5.2 `lakefile.toml` (`SHA-256: C820C282EE9C00920FB2F5B39F9E7150C6B9018F9936C534081E7D34A9688EAF`)
```toml
name = "broca_omega_gate_c1_p2"
version = "0.1.0"
defaultTargets = ["P2FormalSpec", "P2DetachedChecker", "P2Counterexamples", "P2ProofObligations", "p2_tribunal_runner"]

[[lean_lib]]
name = "P2FormalSpec"
srcDir = "01_formal_spec"

[[lean_lib]]
name = "P2DetachedChecker"
srcDir = "02_detached_checker"

[[lean_lib]]
name = "P2Counterexamples"
srcDir = "03_counterexamples"

[[lean_lib]]
name = "P2ProofObligations"
srcDir = "04_proof_obligations"

[[lean_exe]]
name = "p2_tribunal_runner"
srcDir = "05_independent_tribunal"
root = "P2TribunalAudit"
```

### 5.3 `01_formal_spec/P2FormalSpec.lean` (`SHA-256: C07FDB6E76A087FF7DD3B986F8C1034AD1554C5ABB5A260FBECAE1C74AF18B94`)
```lean
import P2FormalSpec.ObligationLedger
import P2FormalSpec.GrammarG16
import P2FormalSpec.DeclarativeSemantics
```

### 5.4 `01_formal_spec/P2FormalSpec/ObligationLedger.lean` (`SHA-256: 72984286ABC21A925E8DAD5D1933D43405EF843D00C1A38ABA8B785A749D0D65`)
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2FormalSpec/ObligationLedger.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)
  Formalizes free commutative monoid multiset accounting (`F-R1.1-01`),
  clause-locus and target-bound linear obligations (`Locus-Bound Obligation Discharge`),
  and decidable multiset conservation without weakening or unlicensed contraction.
-/

namespace BrocaOmega.P2

/-- Syntactic clause locus (`s₁` vs `s₂`) within the bounded max-2-clause document hierarchy. -/
inductive ClauseLocus where
  | clause1
  | clause2
  deriving DecidableEq, Repr

/-- Semantic/grammatical obligation sorts across frozen rules `G-01` ~ `G-16`. -/
inductive OblKind where
  | scopeAnchor           -- Cohort/scope anchoring at clause s₁ or s₂ (`F-R1.1-02`)
  | descIncidence         -- G-01 cumulative incidence count/window obligation
  | descDistribution      -- G-02 summary/dispersion obligation
  | assocMetricDir        -- G-03 / G-04 / G-14 association metric & direction obligation
  | temporalPrecedence    -- G-04 non-commutative temporal order obligation (t_a ≺ t_b)
  | absRiskDiff           -- G-05 RD comparative obligation
  | identAssumption       -- G-06a / G-06b explicit causal identification assumption H_id
  | intervDirectional     -- G-06a statistically supported directional estimation obligation
  | intervNeutral         -- G-06b null-crossing neutral causal estimation obligation
  | metaNotStatSig        -- G-07 non-significance status obligation
  | metaEquivMargins      -- G-08 prespecified TOST equivalence margin obligation
  | metaNonEstabNeg       -- G-09 unary non-establishment negation obligation
  | metaUnresolvedPolar   -- G-10 polar question non-resolution obligation
  | quantZeroNeg          -- G-11 universal zero-incidence negation obligation (`no ...`)
  | quantProperPart       -- G-12 non-empty proper subset obligation (`some, but not all`)
  | quantExistential      -- G-13 pure existential obligation (`at least one`)
  | covariateAdjustment   -- G-14 covariate adjustment set Z obligation
  | contrastiveBoundary   -- G-16 licensed contrastive discourse boundary obligation
  deriving DecidableEq, Repr

/--
  Structural locus-and-target specification of an obligation.
  Computed deterministically by each grammar rule from its syntactic `ClauseLocus` and verified slot payloads.
-/
structure ObligationSpec where
  locus  : ClauseLocus
  kind   : OblKind
  target : String
  deriving DecidableEq, Repr

/--
  Numbered linear obligation token in `Δ_in`.
  Combines a unique `oblId : Nat` with its required `spec : ObligationSpec`.
-/
structure ObligationToken where
  oblId : Nat
  spec  : ObligationSpec
  deriving DecidableEq, Repr

/-! ### Free Commutative Monoid `(ℕ^(𝒪), +, 0)` Multiset Accounting -/

/-- Exact occurrence count of element `a` in list `xs` (free commutative monoid multiplicity). -/
def countOcc {α : Type} [DecidableEq α] (a : α) : List α → Nat
  | [] => 0
  | x :: xs => (if x = a then 1 else 0) + countOcc a xs

@[simp]
theorem countOcc_nil {α : Type} [DecidableEq α] (a : α) :
    countOcc a ([] : List α) = 0 := rfl

@[simp]
theorem countOcc_cons {α : Type} [DecidableEq α] (a x : α) (xs : List α) :
    countOcc a (x :: xs) = (if x = a then 1 else 0) + countOcc a xs := rfl

theorem countOcc_append {α : Type} [DecidableEq α] (a : α) (xs ys : List α) :
    countOcc a (xs ++ ys) = countOcc a xs + countOcc a ys := by
  induction xs with
  | nil => simp
  | cons x rest ih =>
    simp [ih, Nat.add_assoc]

theorem countOcc_eq_zero_of_not_mem {α : Type} [DecidableEq α] {a : α} {xs : List α}
    (hnot : a ∉ xs) : countOcc a xs = 0 := by
  induction xs with
  | nil => rfl
  | cons x rest ih =>
    have hx : x ≠ a := fun heq => hnot (heq ▸ List.Mem.head rest)
    have hrest : a ∉ rest := fun hm => hnot (List.Mem.tail x hm)
    simp [hx, ih hrest]

theorem mem_of_countOcc_pos {α : Type} [DecidableEq α] {a : α} {xs : List α}
    (hpos : 0 < countOcc a xs) : a ∈ xs := by
  induction xs with
  | nil => simp at hpos
  | cons x rest ih =>
    simp at hpos
    by_cases hx : x = a
    · subst hx; exact List.Mem.head rest
    · simp [hx] at hpos
      exact List.Mem.tail x (ih hpos)

/--
  Exact Multiset Equality in the Free Commutative Monoid `(ℕ^(α), +, 0)`:
  Every element `a : α` has the exact same multiplicity in `xs` and `ys`.
-/
def MultisetEq {α : Type} [DecidableEq α] (xs ys : List α) : Prop :=
  ∀ a : α, countOcc a xs = countOcc a ys

theorem multisetEq_refl {α : Type} [DecidableEq α] (xs : List α) : MultisetEq xs xs :=
  fun _ => rfl

theorem multisetEq_symm {α : Type} [DecidableEq α] {xs ys : List α} (h : MultisetEq xs ys) :
    MultisetEq ys xs :=
  fun a => (h a).symm

theorem multisetEq_trans {α : Type} [DecidableEq α] {xs ys zs : List α}
    (h₁ : MultisetEq xs ys) (h₂ : MultisetEq ys zs) : MultisetEq xs zs :=
  fun a => (h₁ a).trans (h₂ a)

/-- Computable boolean check for `MultisetEq` by testing all elements in `xs ++ ys`. -/
def checkMultisetEqBool {α : Type} [DecidableEq α] (xs ys : List α) : Bool :=
  (xs ++ ys).all (fun a => decide (countOcc a xs = countOcc a ys))

theorem list_all_iff {α : Type} (p : α → Bool) (l : List α) :
    l.all p = true ↔ ∀ x ∈ l, p x = true := by
  induction l with
  | nil => simp
  | cons hd tl ih =>
    simp [List.all, Bool.and_eq_true, ih]

theorem checkMultisetEqBool_iff {α : Type} [DecidableEq α] (xs ys : List α) :
    checkMultisetEqBool xs ys = true ↔ MultisetEq xs ys := by
  unfold checkMultisetEqBool MultisetEq
  rw [list_all_iff]
  constructor
  · intro hall a
    by_cases hmem : a ∈ xs ++ ys
    · exact of_decide_eq_true (hall a hmem)
    · have hx : a ∉ xs := fun hx => hmem (List.mem_append_left ys hx)
      have hy : a ∉ ys := fun hy => hmem (List.mem_append_right xs hy)
      rw [countOcc_eq_zero_of_not_mem hx, countOcc_eq_zero_of_not_mem hy]
  · intro h a _
    exact decide_eq_true (h a)

instance {α : Type} [DecidableEq α] (xs ys : List α) : Decidable (MultisetEq xs ys) :=
  if h : checkMultisetEqBool xs ys = true then
    isTrue ((checkMultisetEqBool_iff xs ys).mp h)
  else
    isFalse (fun hm => h ((checkMultisetEqBool_iff xs ys).mpr hm))

/-- Duplicate-freeness on obligation IDs (`oblId` appears at most once). -/
def NoDupOblIds (obls : List ObligationToken) : Prop :=
  ∀ id : Nat, countOcc id (obls.map (·.oblId)) ≤ 1

def checkNoDupOblIdsBool (obls : List ObligationToken) : Bool :=
  let ids := obls.map (·.oblId)
  ids.all (fun id => decide (countOcc id ids ≤ 1))

theorem checkNoDupOblIdsBool_iff (obls : List ObligationToken) :
    checkNoDupOblIdsBool obls = true ↔ NoDupOblIds obls := by
  unfold checkNoDupOblIdsBool NoDupOblIds
  dsimp
  rw [list_all_iff]
  constructor
  · intro hall id
    by_cases hm : id ∈ obls.map (·.oblId)
    · exact of_decide_eq_true (hall id hm)
    · rw [countOcc_eq_zero_of_not_mem hm]
      omega
  · intro h id _
    exact decide_eq_true (h id)

instance (obls : List ObligationToken) : Decidable (NoDupOblIds obls) :=
  if h : checkNoDupOblIdsBool obls = true then
    isTrue ((checkNoDupOblIdsBool_iff obls).mp h)
  else
    isFalse (fun hn => h ((checkNoDupOblIdsBool_iff obls).mpr hn))

end BrocaOmega.P2
```

### 5.5 `01_formal_spec/P2FormalSpec/GrammarG16.lean` (`SHA-256: 97B20F7A2BA892A23CB94D9D6B7FFB9E14BB8FF22AFD3D4B4BE4C6CFC82E130C`)
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2FormalSpec/GrammarG16.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)
  Defines the frozen `Architecture Freeze R0` (`S0-R2.1` / `S0-R2.2` / `Gate C0-R1`)
  16-rule controlled generator grammar (`G-01` ~ `G-16`), acyclic nonterminal stratification,
  typed terminal slots, reserved syncategorematic keyword barrier, and untrusted certificate AST.
-/
import P2FormalSpec.ObligationLedger

namespace BrocaOmega.P2

/-- Quote-isolation discourse contract from `S0-R2.2` (`F-R2.1-05`). -/
inductive QuoteIsolationMode where
  | sentenceAtomic
  | discourseBound
  deriving DecidableEq, Repr

/-- Persistent scope environment `Γ_env` (`F-R1.1-02`). -/
structure ScopeEnv where
  cohortId           : String
  expectedDesignHead : String
  quoteIsolation     : QuoteIsolationMode
  deriving DecidableEq, Repr

/-- Half-open codepoint span `[startCp, endCp)`. -/
structure CodepointSpan where
  startCp : Nat
  endCp   : Nat
  deriving DecidableEq, Repr

/-- Strictly stratified acyclic nonterminal categories (`catRank` strictly increases toward root). -/
inductive NontermCat where
  | embeddedCausal      -- Rank 0: `<ExpLevel> <IntervVerbPres> <OutTerm>`
  | assocCore           -- Rank 1: Association cores (`G-03`, `G-04`, `G-14`)
  | metaNonEstabCore    -- Rank 1: Non-establishment core (`G-09`)
  | atomicCore          -- Rank 2: All single-clause cores (`G-01` ~ `G-14`)
  | scopedInitial       -- Rank 3: `"In <CohortSpec>, <AtomicCore>"`
  | scopedRepeat        -- Rank 3: `"Within this same <DesignNoun>, <AtomicCore>"`
  | scopedAssoc         -- Rank 3: `"In <CohortSpec>, <AssocCore>"`
  | scopedContrastMeta  -- Rank 3: `"within this same <DesignNoun>, <MetaNonEstabCore>"`
  | documentRoot        -- Rank 4: Root `ControlledDocument` (`DocSingle`, `G-15`, `G-16`)
  deriving DecidableEq, Repr

/-- Rank function witnessing that `G_gen` is a finite-depth DAG (zero cycles). -/
def NontermCat.rank : NontermCat → Nat
  | .embeddedCausal     => 0
  | .assocCore          => 1
  | .metaNonEstabCore   => 1
  | .atomicCore         => 2
  | .scopedInitial      => 3
  | .scopedRepeat       => 3
  | .scopedAssoc        => 3
  | .scopedContrastMeta => 3
  | .documentRoot       => 4

/-- Closed typed terminal slot categories in `G-01` ~ `G-16`. -/
inductive SlotSort where
  | cohortSpec
  | designNoun
  | followUpWindow
  | eventTerm
  | measureTerm
  | expLevel
  | outTerm
  | sourceId
  | identAssump
  | subgroupPlural
  | subgroupSingular
  | covariateList
  | assocDir         -- Closed: "positively" | "inversely"
  | ratioMetric      -- Closed: "risk ratio" | "odds ratio" | "hazard ratio"
  | intervDirVerb    -- Closed: "increase" | "reduce"
  | intervVerbPres   -- Closed: "causes" | "increases" | "reduces"
  | numericLit       -- Validated decimal/integer literal string
  deriving DecidableEq, Repr

/-- Positional role tag within a grammar production for deterministic obligation target assembly. -/
inductive SlotRole where
  | cohort
  | design
  | window
  | eventA
  | eventB
  | measure
  | activeExp
  | refExp
  | outcome
  | source
  | assumption
  | subgroup
  | covariates
  | direction
  | metric1
  | metric2
  | verb
  | numK
  | numN
  | numPct
  | numEst
  | numDisp1
  | numDisp2
  | numCILevel
  | numCILow
  | numCIHigh
  | numPVal
  | numAlpha
  | numMarginLow
  | numMarginHigh
  deriving DecidableEq, Repr

/-- Typed terminal slot token submitted inside an untrusted derivation certificate. -/
structure SlotToken where
  sort     : SlotSort
  role     : SlotRole
  entityId : String
  lexeme   : String
  span     : CodepointSpan
  deriving DecidableEq, Repr

/-! ### Reserved Syncategorematic Barrier & Printable ASCII Checks -/

def isPrintableAsciiChar (c : Char) : Bool :=
  ((0x20 : UInt32) ≤ c.val) && (c.val ≤ (0x7E : UInt32))

def isPrintableAsciiStr (s : String) : Bool :=
  !s.isEmpty && s.toList.all isPrintableAsciiChar

/-- Pure `List Char` contiguous sublist test (`needle` occurs in `haystack`). -/
def isPrefixChars : List Char → List Char → Bool
  | [], _ => true
  | _ :: _, [] => false
  | n :: ns, h :: hs => (n == h) && isPrefixChars ns hs

def containsSubstrChars (needle : List Char) : List Char → Bool
  | [] => needle.isEmpty
  | h :: hs => isPrefixChars needle (h :: hs) || containsSubstrChars needle hs

def containsSubstr (s sub : String) : Bool :=
  containsSubstrChars sub.toList s.toList

/-- Reserved structural delimiters forbidden inside open entity/phrase slots (`S0-R2.1` Barrier). -/
def forbiddenSlotDelimiters : List String :=
  [ ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same" ]

def isDigitChar (c : Char) : Bool :=
  (('0' : Char).val ≤ c.val) && (c.val ≤ ('9' : Char).val)

def isValidNumericSurface (s : String) : Bool :=
  let cs := s.toList
  match cs with
  | [] => false
  | '-' :: '0' :: rest =>
    -- Forbid `-0` and `-0.0...` (`F-C0-01` negative zero surface check)
    if rest.all (fun c => c == '0' || c == '.') then false
    else rest.all (fun c => isDigitChar c || c == '.')
  | '-' :: d :: rest =>
    isDigitChar d && rest.all (fun c => isDigitChar c || c == '.')
  | d :: rest =>
    isDigitChar d && rest.all (fun c => isDigitChar c || c == '.')

/-- Validates that a `SlotToken` lexeme obeys ASCII, closed-class, numeric, and keyword-barrier rules. -/
def isValidSlotLexeme (sort : SlotSort) (lex : String) : Bool :=
  if !isPrintableAsciiStr lex then false
  else
    match sort with
    | .assocDir       => (lex == "positively") || (lex == "inversely")
    | .ratioMetric    => (lex == "risk ratio") || (lex == "odds ratio") || (lex == "hazard ratio")
    | .intervDirVerb  => (lex == "increase") || (lex == "reduce")
    | .intervVerbPres => (lex == "causes") || (lex == "increases") || (lex == "reduces")
    | .numericLit     => isValidNumericSurface lex
    | _               => forbiddenSlotDelimiters.all (fun bad => !containsSubstr lex bad)

/-! ### Frozen Canonical Generator Rules (`G-01` ~ `G-16` + Structural Envelopes) -/

/--
  Closed enumeration of ALL legal generator rules in `Architecture Freeze R0`.
  Note: Trap rules `T1`~`T5` (IDs `901`~`905`) and unknown IDs are NOT in `FrozenGenRule`,
  so `decodeFrozenRule` deterministically rejects them (`forgedOrTrapRuleId`).
-/
inductive FrozenGenRule where
  | DocSingle               -- ID 1:   ScopedInitial(s₁) "."
  | G15_DocConjAtomic       -- ID 150: ScopedInitial(s₁) ". " ScopedInitial(s₂) "."
  | G15_DocConjDiscourse    -- ID 151: ScopedInitial(s₁) ". " ScopedRepeat(s₂) "."
  | G16_DocContrastive      -- ID 160: ScopedAssoc(s₁) "; however, " ScopedContrastMeta(s₂) "."
  | ScopedInitial           -- ID 201: "In " CohortSpec ", " AtomicCore
  | ScopedRepeatDiscourse   -- ID 202: "Within this same " DesignNoun ", " AtomicCore
  | ScopedAssoc             -- ID 203: "In " CohortSpec ", " AssocCore
  | ScopedContrastMeta      -- ID 204: "within this same " DesignNoun ", " MetaNonEstabCore
  | LiftAssocToAtomic       -- ID 210: AssocCore -> AtomicCore
  | LiftMetaToAtomic        -- ID 211: MetaNonEstabCore -> AtomicCore
  | EmbeddedCausal          -- ID 301: ExpLevel " " IntervVerbPres " " OutTerm
  | G01_DescIncidence       -- ID 10
  | G02a_DescMeanSD         -- ID 20
  | G02b_DescMedianIQR      -- ID 21
  | G03_AssocUnadj          -- ID 30
  | G04_AssocTemp           -- ID 40
  | G05_CompRD              -- ID 50
  | G06a_IntervDirectional  -- ID 60
  | G06b_IntervNeutral      -- ID 61
  | G07_MetaNotStatSig      -- ID 70
  | G08_MetaEquiv           -- ID 80
  | G09_MetaNonEstab        -- ID 90
  | G10_MetaUnresolved      -- ID 100
  | G11_QuantZero           -- ID 110
  | G12_QuantProperPart     -- ID 120
  | G13_QuantAtLeastOne     -- ID 130
  | G14_AssocAdj            -- ID 140
  deriving DecidableEq, Repr

/-- Canonical numeric encoding of `FrozenGenRule` (used in untrusted `DerivationCert` wire format). -/
def FrozenGenRule.toCode : FrozenGenRule → Nat
  | .DocSingle              => 1
  | .G01_DescIncidence      => 10
  | .G02a_DescMeanSD        => 20
  | .G02b_DescMedianIQR     => 21
  | .G03_AssocUnadj         => 30
  | .G04_AssocTemp          => 40
  | .G05_CompRD             => 50
  | .G06a_IntervDirectional => 60
  | .G06b_IntervNeutral     => 61
  | .G07_MetaNotStatSig     => 70
  | .G08_MetaEquiv          => 80
  | .G09_MetaNonEstab       => 90
  | .G10_MetaUnresolved     => 100
  | .G11_QuantZero          => 110
  | .G12_QuantProperPart    => 120
  | .G13_QuantAtLeastOne    => 130
  | .G14_AssocAdj           => 140
  | .G15_DocConjAtomic      => 150
  | .G15_DocConjDiscourse   => 151
  | .G16_DocContrastive     => 160
  | .ScopedInitial          => 201
  | .ScopedRepeatDiscourse  => 202
  | .ScopedAssoc            => 203
  | .ScopedContrastMeta     => 204
  | .LiftAssocToAtomic      => 210
  | .LiftMetaToAtomic       => 211
  | .EmbeddedCausal         => 301

/-- Decodes untrusted rule code `rawCode : Nat` into `Option FrozenGenRule`. -/
def decodeFrozenRule : Nat → Option FrozenGenRule
  | 1   => some .DocSingle
  | 10  => some .G01_DescIncidence
  | 20  => some .G02a_DescMeanSD
  | 21  => some .G02b_DescMedianIQR
  | 30  => some .G03_AssocUnadj
  | 40  => some .G04_AssocTemp
  | 50  => some .G05_CompRD
  | 60  => some .G06a_IntervDirectional
  | 61  => some .G06b_IntervNeutral
  | 70  => some .G07_MetaNotStatSig
  | 80  => some .G08_MetaEquiv
  | 90  => some .G09_MetaNonEstab
  | 100 => some .G10_MetaUnresolved
  | 110 => some .G11_QuantZero
  | 120 => some .G12_QuantProperPart
  | 130 => some .G13_QuantAtLeastOne
  | 140 => some .G14_AssocAdj
  | 150 => some .G15_DocConjAtomic
  | 151 => some .G15_DocConjDiscourse
  | 160 => some .G16_DocContrastive
  | 201 => some .ScopedInitial
  | 202 => some .ScopedRepeatDiscourse
  | 203 => some .ScopedAssoc
  | 204 => some .ScopedContrastMeta
  | 210 => some .LiftAssocToAtomic
  | 211 => some .LiftMetaToAtomic
  | 301 => some .EmbeddedCausal
  | _   => none

theorem decode_toCode_id (r : FrozenGenRule) : decodeFrozenRule r.toCode = some r := by
  cases r <;> rfl

/-- Ordered production segment: fixed literal terminal, typed slot leaf, or typed child subtree. -/
inductive RuleSegment where
  | lit   (text : String)
  | slot  (sort : SlotSort) (role : SlotRole)
  | child (cat : NontermCat) (locusOverride : Option ClauseLocus)
  deriving DecidableEq, Repr

/-- Summary metadata synthesized bottom-up from children for cross-slot/cross-clause side conditions. -/
structure NodeSummary where
  cohortIdOpt   : Option String := none
  designIdOpt   : Option String := none
  expOutPairOpt : Option (String × String) := none
  embeddedKey   : Option String := none
  deriving DecidableEq, Repr

def lookupRoleVal (slots : List (SlotRole × String)) (r : SlotRole) : String :=
  match slots.find? (fun p => p.1 == r) with
  | some (_, v) => v
  | none        => ""

/-- Complete declarative signature of a `FrozenGenRule`. -/
structure RuleSignature where
  lhsCat        : NontermCat
  segments      : List RuleSegment
  intrinsicObls : ClauseLocus → List (SlotRole × String) → List NodeSummary → List ObligationSpec
  checkSideCond : ScopeEnv → List (SlotRole × String) → List NodeSummary → Bool
  mkSummary     : List (SlotRole × String) → List NodeSummary → NodeSummary

/-- Master Frozen Rule Table (`G-01` ~ `G-16` + Structural Envelopes). -/
def ruleSignature : FrozenGenRule → RuleSignature
  | .DocSingle =>
    { lhsCat := .documentRoot
      segments := [.child .scopedInitial (some .clause1), .lit "."]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G15_DocConjAtomic =>
    { lhsCat := .documentRoot
      segments := [ .child .scopedInitial (some .clause1),
                    .lit ". ",
                    .child .scopedInitial (some .clause2),
                    .lit "." ]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (env.quoteIsolation == .sentenceAtomic) &&
          (c1.cohortIdOpt == some env.cohortId) &&
          (c2.cohortIdOpt == some env.cohortId)
        | _ => false
      mkSummary := fun _ _ => {} }

  | .G15_DocConjDiscourse =>
    { lhsCat := .documentRoot
      segments := [ .child .scopedInitial (some .clause1),
                    .lit ". ",
                    .child .scopedRepeat (some .clause2),
                    .lit "." ]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (env.quoteIsolation == .discourseBound) &&
          (c1.cohortIdOpt == some env.cohortId) &&
          (c2.designIdOpt == some env.expectedDesignHead)
        | _ => false
      mkSummary := fun _ _ => {} }

  | .G16_DocContrastive =>
    { lhsCat := .documentRoot
      segments := [ .child .scopedAssoc (some .clause1),
                    .lit "; however, ",
                    .child .scopedContrastMeta (some .clause2),
                    .lit "." ]
      intrinsicObls := fun _ _ ch =>
        match ch with
        | [c1, _] =>
          match c1.expOutPairOpt with
          | some (eId, oId) =>
            [{ locus := .clause2, kind := .contrastiveBoundary, target := eId ++ ":" ++ oId }]
          | none => [{ locus := .clause2, kind := .contrastiveBoundary, target := "" }]
        | _ => []
      checkSideCond := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (c1.cohortIdOpt == some env.cohortId) &&
          (c2.designIdOpt == some env.expectedDesignHead) &&
          c1.expOutPairOpt.isSome &&
          (c1.expOutPairOpt == c2.expOutPairOpt)
        | _ => false
      mkSummary := fun _ _ => {} }

  | .ScopedInitial =>
    { lhsCat := .scopedInitial
      segments := [.lit "In ", .slot .cohortSpec .cohort, .lit ", ", .child .atomicCore none]
      intrinsicObls := fun loc slots _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupRoleVal slots .cohort }]
      checkSideCond := fun env slots _ =>
        lookupRoleVal slots .cohort == env.cohortId
      mkSummary := fun slots ch =>
        { cohortIdOpt := some (lookupRoleVal slots .cohort)
          expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .ScopedRepeatDiscourse =>
    { lhsCat := .scopedRepeat
      segments := [.lit "Within this same ", .slot .designNoun .design, .lit ", ", .child .atomicCore none]
      intrinsicObls := fun loc slots _ =>
        [{ locus := loc, kind := .scopeAnchor, target := "resolve:" ++ lookupRoleVal slots .design }]
      checkSideCond := fun env slots _ =>
        lookupRoleVal slots .design == env.expectedDesignHead
      mkSummary := fun slots ch =>
        { designIdOpt := some (lookupRoleVal slots .design)
          expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .ScopedAssoc =>
    { lhsCat := .scopedAssoc
      segments := [.lit "In ", .slot .cohortSpec .cohort, .lit ", ", .child .assocCore none]
      intrinsicObls := fun loc slots _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupRoleVal slots .cohort }]
      checkSideCond := fun env slots _ =>
        lookupRoleVal slots .cohort == env.cohortId
      mkSummary := fun slots ch =>
        { cohortIdOpt := some (lookupRoleVal slots .cohort)
          expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .ScopedContrastMeta =>
    { lhsCat := .scopedContrastMeta
      segments := [.lit "within this same ", .slot .designNoun .design, .lit ", ", .child .metaNonEstabCore none]
      intrinsicObls := fun loc slots _ =>
        [{ locus := loc, kind := .scopeAnchor, target := "resolve:" ++ lookupRoleVal slots .design }]
      checkSideCond := fun env slots _ =>
        lookupRoleVal slots .design == env.expectedDesignHead
      mkSummary := fun slots ch =>
        { designIdOpt := some (lookupRoleVal slots .design)
          expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .LiftAssocToAtomic =>
    { lhsCat := .atomicCore
      segments := [.child .assocCore none]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ ch => match ch with | [c] => c | _ => {} }

  | .LiftMetaToAtomic =>
    { lhsCat := .atomicCore
      segments := [.child .metaNonEstabCore none]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ ch => match ch with | [c] => c | _ => {} }

  | .EmbeddedCausal =>
    { lhsCat := .embeddedCausal
      segments := [.slot .expLevel .activeExp, .lit " ", .slot .intervVerbPres .verb, .lit " ", .slot .outTerm .outcome]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun _ _ _ => true
      mkSummary := fun slots _ =>
        let act := lookupRoleVal slots .activeExp
        let vb  := lookupRoleVal slots .verb
        let out := lookupRoleVal slots .outcome
        { expOutPairOpt := some (act, out)
          embeddedKey := some (act ++ ":" ++ vb ++ ":" ++ out) } }

  | .G01_DescIncidence =>
    { lhsCat := .atomicCore
      segments := [ .lit "over ", .slot .followUpWindow .window,
                    .lit ", the cumulative incidence of ", .slot .eventTerm .eventA,
                    .lit " was ", .slot .numericLit .numK,
                    .lit " of ", .slot .numericLit .numN,
                    .lit " patients (", .slot .numericLit .numPct, .lit "%)" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descIncidence,
           target := lookupRoleVal s .window ++ ":" ++ lookupRoleVal s .eventA ++ ":" ++
                     lookupRoleVal s .numK ++ "/" ++ lookupRoleVal s .numN ++ "=" ++ lookupRoleVal s .numPct }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G02a_DescMeanSD =>
    { lhsCat := .atomicCore
      segments := [ .lit "the mean ", .slot .measureTerm .measure,
                    .lit " was ", .slot .numericLit .numEst,
                    .lit " (SD ", .slot .numericLit .numDisp1, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descDistribution,
           target := "mean_sd:" ++ lookupRoleVal s .measure ++ ":" ++ lookupRoleVal s .numEst ++ ":" ++ lookupRoleVal s .numDisp1 }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G02b_DescMedianIQR =>
    { lhsCat := .atomicCore
      segments := [ .lit "the median ", .slot .measureTerm .measure,
                    .lit " was ", .slot .numericLit .numEst,
                    .lit " (IQR ", .slot .numericLit .numDisp1,
                    .lit " to ", .slot .numericLit .numDisp2, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descDistribution,
           target := "median_iqr:" ++ lookupRoleVal s .measure ++ ":" ++ lookupRoleVal s .numEst ++ ":" ++
                     lookupRoleVal s .numDisp1 ++ ".." ++ lookupRoleVal s .numDisp2 }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G03_AssocUnadj =>
    { lhsCat := .assocCore
      segments := [ .lit "comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .assocDir .direction,
                    .lit " associated with ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .assocMetricDir,
           target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .direction ++ ":" ++
                     lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome }]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun s _ =>
        { expOutPairOpt := some (lookupRoleVal s .activeExp, lookupRoleVal s .outcome) } }

  | .G04_AssocTemp =>
    { lhsCat := .assocCore
      segments := [ .slot .eventTerm .eventA, .lit " preceded ", .slot .eventTerm .eventB,
                    .lit ", and comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .assocDir .direction,
                    .lit " associated with ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .temporalPrecedence,
            target := lookupRoleVal s .eventA ++ "<" ++ lookupRoleVal s .eventB },
          { locus := loc, kind := .assocMetricDir,
            target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .direction ++ ":" ++
                      lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome } ]
      checkSideCond := fun _ s _ =>
        (lookupRoleVal s .eventA != lookupRoleVal s .eventB) &&
        (lookupRoleVal s .activeExp != lookupRoleVal s .refExp)
      mkSummary := fun s _ =>
        { expOutPairOpt := some (lookupRoleVal s .activeExp, lookupRoleVal s .outcome) } }

  | .G05_CompRD =>
    { lhsCat := .atomicCore
      segments := [ .lit "the absolute risk difference in ", .slot .outTerm .outcome,
                    .lit " comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .numericLit .numEst,
                    .lit " percentage points (", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .absRiskDiff,
           target := "RD:" ++ lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome }]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun _ _ => {} }

  | .G06a_IntervDirectional =>
    { lhsCat := .atomicCore
      segments := [ .lit "under ", .slot .identAssump .assumption,
                    .lit ", comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was estimated to ", .slot .intervDirVerb .verb,
                    .lit " ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh,
                    .lit ", p = ", .slot .numericLit .numPVal, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .identAssumption, target := lookupRoleVal s .assumption },
          { locus := loc, kind := .intervDirectional,
            target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .verb ++ ":" ++
                      lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome } ]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun _ _ => {} }

  | .G06b_IntervNeutral =>
    { lhsCat := .atomicCore
      segments := [ .lit "under ", .slot .identAssump .assumption,
                    .lit ", the estimated causal ", .slot .ratioMetric .metric1,
                    .lit " for ", .slot .outTerm .outcome,
                    .lit " comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .numericLit .numEst,
                    .lit " (", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh,
                    .lit "), which did not exclude no effect" ]
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .identAssumption, target := lookupRoleVal s .assumption },
          { locus := loc, kind := .intervNeutral,
            target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .activeExp ++ ":" ++
                      lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome } ]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun _ _ => {} }

  | .G07_MetaNotStatSig =>
    { lhsCat := .atomicCore
      segments := [ .lit "the observed ", .slot .ratioMetric .metric1,
                    .lit " comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " for ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric2,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh,
                    .lit ") was not statistically significant at alpha = ",
                    .slot .numericLit .numAlpha ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .metaNotStatSig,
           target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .activeExp ++ ":" ++
                     lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome ++ ":" ++ lookupRoleVal s .numAlpha }]
      checkSideCond := fun _ s _ =>
        (lookupRoleVal s .metric1 == lookupRoleVal s .metric2) &&
        (lookupRoleVal s .activeExp != lookupRoleVal s .refExp)
      mkSummary := fun _ _ => {} }

  | .G08_MetaEquiv =>
    { lhsCat := .atomicCore
      segments := [ .lit "comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " met prespecified equivalence margins (",
                    .slot .numericLit .numMarginLow, .lit " to ", .slot .numericLit .numMarginHigh,
                    .lit ") for ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% TOST CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .metaEquivMargins,
           target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .activeExp ++ ":" ++
                     lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome ++ ":" ++
                     lookupRoleVal s .numMarginLow ++ ".." ++ lookupRoleVal s .numMarginHigh }]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun _ _ => {} }

  | .G09_MetaNonEstab =>
    { lhsCat := .metaNonEstabCore
      segments := [ .lit "the analysis of ", .slot .sourceId .source,
                    .lit " did not establish that ", .child .embeddedCausal none ]
      intrinsicObls := fun loc s ch =>
        let embKey := match ch with | [c] => c.embeddedKey.getD "" | _ => ""
        [{ locus := loc, kind := .metaNonEstabNeg,
           target := lookupRoleVal s .source ++ ":" ++ embKey }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ ch =>
        { expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .G10_MetaUnresolved =>
    { lhsCat := .atomicCore
      segments := [ .lit "the analysis of ", .slot .sourceId .source,
                    .lit " did not determine whether ", .child .embeddedCausal none ]
      intrinsicObls := fun loc s ch =>
        let embKey := match ch with | [c] => c.embeddedKey.getD "" | _ => ""
        [{ locus := loc, kind := .metaUnresolvedPolar,
           target := lookupRoleVal s .source ++ ":" ++ embKey }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G11_QuantZero =>
    { lhsCat := .atomicCore
      segments := [ .lit "no ", .slot .subgroupPlural .subgroup,
                    .lit " patients developed ", .slot .eventTerm .eventA ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantZeroNeg,
           target := lookupRoleVal s .subgroup ++ ":" ++ lookupRoleVal s .eventA }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G12_QuantProperPart =>
    { lhsCat := .atomicCore
      segments := [ .lit "some, but not all, ", .slot .subgroupPlural .subgroup,
                    .lit " patients developed ", .slot .eventTerm .eventA ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantProperPart,
           target := lookupRoleVal s .subgroup ++ ":" ++ lookupRoleVal s .eventA }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G13_QuantAtLeastOne =>
    { lhsCat := .atomicCore
      segments := [ .lit "at least one ", .slot .subgroupSingular .subgroup,
                    .lit " patient developed ", .slot .eventTerm .eventA ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantExistential,
           target := lookupRoleVal s .subgroup ++ ":" ++ lookupRoleVal s .eventA }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G14_AssocAdj =>
    { lhsCat := .assocCore
      segments := [ .lit "after adjustment for ", .slot .covariateList .covariates,
                    .lit ", comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .assocDir .direction,
                    .lit " associated with ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .covariateAdjustment, target := lookupRoleVal s .covariates },
          { locus := loc, kind := .assocMetricDir,
            target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .direction ++ ":" ++
                      lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome } ]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun s _ =>
        { expOutPairOpt := some (lookupRoleVal s .activeExp, lookupRoleVal s .outcome) } }

/-! ### Acyclicity Proof of Frozen Generator Grammar (`rank` Strictly Decreases to Children) -/

theorem child_rank_lt_lhs_rank (r : FrozenGenRule) (cat : NontermCat) (locOpt : Option ClauseLocus)
    (hmem : RuleSegment.child cat locOpt ∈ (ruleSignature r).segments) :
    cat.rank < (ruleSignature r).lhsCat.rank := by
  cases r <;> simp [ruleSignature] at hmem
  all_goals
    try (rcases hmem with ⟨rfl, _⟩ | ⟨rfl, _⟩ <;> decide)
    try (rcases hmem with ⟨rfl, _⟩; decide)

/-! ### Untrusted Derivation Certificate AST (Submitted by Untrusted Generator) -/

mutual
  /-- Argument item corresponding to a `RuleSegment` inside `UntrustedDerivCert`. -/
  inductive UntrustedSegArg where
    | litSpan (claimedText : String) (span : CodepointSpan)
    | slotLeaf (tok : SlotToken)
    | childNode (sub : UntrustedDerivCert)
    deriving Repr

  /-- Untrusted concrete syntax derivation tree submitted to `replayDerivation`. -/
  inductive UntrustedDerivCert where
    | mkNode
        (nodeId            : Nat)
        (rawRuleCode       : Nat)
        (span              : CodepointSpan)
        (claimedDischarged : List ObligationToken)
        (segArgs           : List UntrustedSegArg)
    deriving Repr
end

/-! ### Bottom-Up Yield & Discharged Obligation Collectors -/

mutual
  def reconstructSegYield : List UntrustedSegArg → List Char
    | [] => []
    | .litSpan txt _ :: rest => txt.toList ++ reconstructSegYield rest
    | .slotLeaf tok :: rest  => tok.lexeme.toList ++ reconstructSegYield rest
    | .childNode sub :: rest => reconstructYieldChars sub ++ reconstructSegYield rest

  def reconstructYieldChars : UntrustedDerivCert → List Char
    | .mkNode _ _ _ _ args => reconstructSegYield args
end

/-- Bottom-up reconstructed surface string from the derivation tree's terminals & slots. -/
def reconstructYield (cert : UntrustedDerivCert) : String :=
  String.ofList (reconstructYieldChars cert)

mutual
  def collectSegClaimedObls : List UntrustedSegArg → List ObligationToken
    | [] => []
    | .litSpan _ _ :: rest   => collectSegClaimedObls rest
    | .slotLeaf _ :: rest    => collectSegClaimedObls rest
    | .childNode sub :: rest => collectClaimedObls sub ++ collectSegClaimedObls rest

  /-- Collects all `ObligationToken`s across the entire derivation tree in pre-order. -/
  def collectClaimedObls : UntrustedDerivCert → List ObligationToken
    | .mkNode _ _ _ claimed args => claimed ++ collectSegClaimedObls args
end

end BrocaOmega.P2
```

### 5.6 `01_formal_spec/P2FormalSpec/DeclarativeSemantics.lean` (`SHA-256: 47409B4A5CCB8CA9001B92B7F2ACE4719B9AAECB4FD3AE4E2E6162DE247D1F1B`)
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2FormalSpec/DeclarativeSemantics.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)
  Defines the algorithm-independent declarative reference relations (`Prop`):
    1. `ValidGrammarDerivation` (Frozen G-01..G-16 rule membership, sort typing, acyclic hierarchy & side conditions)
    2. `ExactSpanPartition` & `SpanMatches` (Gap-free, overlap-free span partition & `Yield(π) = Y`)
    3. `LocusTargetBound` (Every node's obligations match the intrinsic rule, clause locus & slot targets)
    4. `ObligationsConserved` (No-dup IDs & exact free-commutative-monoid multiset equality with `Δ_in`)
-/
import P2FormalSpec.GrammarG16

namespace BrocaOmega.P2

/-! ### 1. Exact Prefix-Slice Algebra (`SpanMatches`) -/

/--
  `SpanMatches Y sp seg` holds iff `Y` decomposes as `pre ++ seg ++ post` where
  `pre.length = sp.startCp` and `sp.endCp = sp.startCp + seg.length`.
  Guarantees `0 ≤ startCp ≤ endCp ≤ Y.length` and exact character-slice identity.
-/
def SpanMatches (Y : List Char) (sp : CodepointSpan) (seg : List Char) : Prop :=
  sp.endCp = sp.startCp + seg.length ∧
  ∃ pre post : List Char, Y = pre ++ seg ++ post ∧ pre.length = sp.startCp

theorem spanMatches_empty {Y : List Char} {pos : Nat} (hle : pos ≤ Y.length) :
    SpanMatches Y ⟨pos, pos⟩ [] := by
  refine ⟨by simp, Y.take pos, Y.drop pos, ?_, ?_⟩
  · simp [List.take_append_drop]
  · exact List.length_take_of_le hle

private theorem append_eq_of_eq_len {α : Type} {l₁ r₁ l₂ r₂ : List α}
    (heq : l₁ ++ r₁ = l₂ ++ r₂) (hlen : l₁.length = l₂.length) :
    l₁ = l₂ ∧ r₁ = r₂ := by
  induction l₁ generalizing l₂ with
  | nil =>
    cases l₂ with
    | nil => exact ⟨rfl, heq⟩
    | cons _ _ => simp at hlen
  | cons x xs ih =>
    cases l₂ with
    | nil => simp at hlen
    | cons y ys =>
      simp at heq hlen
      have ⟨hxs, hrs⟩ := ih heq.2 hlen
      rw [heq.1, hxs]
      exact ⟨rfl, hrs⟩

/-- Contiguous Span Composition: `[a, b)` matching `s₁` + `[b, c)` matching `s₂` => `[a, c)` matches `s₁ ++ s₂`! -/
theorem spanMatches_concat {Y : List Char} {a b c : Nat} {s₁ s₂ : List Char}
    (h₁ : SpanMatches Y ⟨a, b⟩ s₁) (h₂ : SpanMatches Y ⟨b, c⟩ s₂) :
    SpanMatches Y ⟨a, c⟩ (s₁ ++ s₂) := by
  rcases h₁ with ⟨hb, pre₁, post₁, hy₁, hlen₁⟩
  rcases h₂ with ⟨hc, pre₂, post₂, hy₂, hlen₂⟩
  change b = a + s₁.length at hb
  change c = b + s₂.length at hc
  change pre₁.length = a at hlen₁
  change pre₂.length = b at hlen₂
  have hcomb : (pre₁ ++ s₁) ++ post₁ = pre₂ ++ (s₂ ++ post₂) := by
    calc
      (pre₁ ++ s₁) ++ post₁ = pre₁ ++ s₁ ++ post₁ := rfl
      _ = Y := hy₁.symm
      _ = pre₂ ++ s₂ ++ post₂ := hy₂
      _ = pre₂ ++ (s₂ ++ post₂) := by rw [List.append_assoc]
  have hlen_eq : (pre₁ ++ s₁).length = pre₂.length := by
    rw [List.length_append, hlen₁, hlen₂, hb]
  have ⟨_, hpost⟩ := append_eq_of_eq_len hcomb hlen_eq
  refine ⟨?_, pre₁, post₂, ?_, hlen₁⟩
  · change c = a + (s₁ ++ s₂).length
    rw [List.length_append]
    omega
  · calc
      Y = (pre₁ ++ s₁) ++ post₁ := hy₁
      _ = (pre₁ ++ s₁) ++ (s₂ ++ post₂) := by rw [hpost]
      _ = pre₁ ++ (s₁ ++ s₂) ++ post₂ := by simp [List.append_assoc]

/-- Root Span Completeness: matching `[0, Y.length)` forces exact whole-string identity `seg = Y`! -/
theorem spanMatches_full_eq {Y seg : List Char}
    (h : SpanMatches Y ⟨0, Y.length⟩ seg) : seg = Y := by
  rcases h with ⟨hend, pre, post, hy, hpre_len⟩
  dsimp at hend hpre_len
  cases pre with
  | cons _ _ => simp at hpre_len
  | nil =>
    simp at hy hend
    have hlen_y : Y.length = seg.length + post.length := by
      rw [hy, List.length_append]
    have hpost_len : post.length = 0 := by omega
    cases post with
    | cons _ _ => simp at hpost_len
    | nil =>
      simp at hy
      exact hy.symm

/-- Soundness of computable slice check `checkSpanMatchesBool`. -/
def checkSpanMatchesBool (Y : List Char) (sp : CodepointSpan) (seg : List Char) : Bool :=
  decide (sp.endCp = sp.startCp + seg.length) &&
  decide (sp.endCp ≤ Y.length) &&
  decide (((Y.drop sp.startCp).take seg.length) = seg)

theorem checkSpanMatchesBool_sound {Y : List Char} {sp : CodepointSpan} {seg : List Char}
    (hok : checkSpanMatchesBool Y sp seg = true) : SpanMatches Y sp seg := by
  unfold checkSpanMatchesBool at hok
  simp [Bool.and_eq_true] at hok
  rcases hok with ⟨⟨hend, hle_end⟩, htake⟩
  have hstart_le : sp.startCp ≤ Y.length := by omega
  refine ⟨hend, Y.take sp.startCp, (Y.drop sp.startCp).drop seg.length, ?_, List.length_take_of_le hstart_le⟩
  have h1 : Y = Y.take sp.startCp ++ Y.drop sp.startCp := (List.take_append_drop sp.startCp Y).symm
  have h2 : Y.drop sp.startCp = seg ++ (Y.drop sp.startCp).drop seg.length := by
    have htd := (List.take_append_drop seg.length (Y.drop sp.startCp)).symm
    rw [htake] at htd
    exact htd
  calc
    Y = Y.take sp.startCp ++ (seg ++ (Y.drop sp.startCp).drop seg.length) :=
      h1.trans (congrArg (Y.take sp.startCp ++ ·) h2)
    _ = Y.take sp.startCp ++ seg ++ (Y.drop sp.startCp).drop seg.length := by
      rw [← List.append_assoc]

theorem spanMatches_implies_checkBool {Y : List Char} {sp : CodepointSpan} {seg : List Char}
    (h : SpanMatches Y sp seg) : checkSpanMatchesBool Y sp seg = true := by
  rcases h with ⟨hend, pre, post, hy, hpre_len⟩
  unfold checkSpanMatchesBool
  have hlen_y : Y.length = pre.length + seg.length + post.length := by
    rw [hy, List.length_append, List.length_append]
  have hbound : sp.startCp + seg.length ≤ Y.length := by omega
  have hdrop : Y.drop sp.startCp = seg ++ post := by
    rw [hy, List.append_assoc, ← hpre_len]
    exact List.drop_left
  have htake : (Y.drop sp.startCp).take seg.length = seg := by
    rw [hdrop]
    exact List.take_left
  simp [hend, hbound, htake]

/-! ### 2. Declarative Reference Relations (`Prop`) for Grammar, Spans, Locus & Obligations -/

/-
  Declarative Reference Relations (`Prop`):
  `ValidSegChain` and `ValidNodeDeriv` specify valid typing, contiguous non-overlapping spans,
  exact literal/slot slices against `Y`, rule side conditions, and `LocusTargetBound` by
  structural recursion over the finite certificate AST.
-/
mutual
  def ValidSegChain (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (cursor : Nat) (segs : List RuleSegment) (args : List UntrustedSegArg)
      (endPos : Nat) (slots : List (SlotRole × String)) (sums : List NodeSummary) : Prop :=
    match segs, args with
    | [], [] =>
      cursor ≤ Y.length ∧ endPos = cursor ∧ slots = [] ∧ sums = []
    | .lit txt :: restSegs, .litSpan claimed sp :: restArgs =>
      claimed = txt ∧
      sp.startCp = cursor ∧
      SpanMatches Y sp claimed.toList ∧
      ValidSegChain env Y loc sp.endCp restSegs restArgs endPos slots sums
    | .slot expectedSort expectedRole :: restSegs, .slotLeaf tok :: restArgs =>
      ∃ restSlots : List (SlotRole × String),
        tok.sort = expectedSort ∧
        tok.role = expectedRole ∧
        isValidSlotLexeme expectedSort tok.lexeme = true ∧
        tok.span.startCp = cursor ∧
        SpanMatches Y tok.span tok.lexeme.toList ∧
        slots = (expectedRole, tok.entityId) :: restSlots ∧
        ValidSegChain env Y loc tok.span.endCp restSegs restArgs endPos restSlots sums
    | .child cat locOpt :: restSegs, .childNode sub :: restArgs =>
      ∃ (subSum : NodeSummary) (restSums : List NodeSummary),
        (match sub with | .mkNode _ _ sp _ _ => sp.startCp) = cursor ∧
        ValidNodeDeriv env Y (locOpt.getD loc) cat sub subSum ∧
        sums = subSum :: restSums ∧
        ValidSegChain env Y loc
          (match sub with | .mkNode _ _ sp _ _ => sp.endCp) restSegs restArgs endPos slots restSums
    | _, _ => False

  def ValidNodeDeriv (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (expectedCat : NontermCat) (cert : UntrustedDerivCert) (outSum : NodeSummary) : Prop :=
    match cert with
    | .mkNode _ rawCode sp claimed args =>
      ∃ (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary),
        decodeFrozenRule rawCode = some r ∧
        (ruleSignature r).lhsCat = expectedCat ∧
        ValidSegChain env Y loc sp.startCp (ruleSignature r).segments args sp.endCp slots sums ∧
        (ruleSignature r).checkSideCond env slots sums = true ∧
        claimed.map (·.spec) = (ruleSignature r).intrinsicObls loc slots sums ∧
        outSum = (ruleSignature r).mkSummary slots sums
end

/-- Root-level Valid Grammar & Span Derivation over `Y`. -/
def ValidGrammarDerivation (env : ScopeEnv) (Y : String) (cert : UntrustedDerivCert) : Prop :=
  (match cert with | .mkNode _ _ sp _ _ => sp = ⟨0, Y.toList.length⟩) ∧
  ∃ sum : NodeSummary, ValidNodeDeriv env Y.toList .clause1 .documentRoot cert sum

/- Pure structural extraction of slot `(role, entityId)` pairs and child `NodeSummary` values from `UntrustedDerivCert`. -/
mutual
  def synthSegSlotsSums : List RuleSegment → List UntrustedSegArg →
      Option (List (SlotRole × String) × List NodeSummary)
    | [], [] => some ([], [])
    | .lit _ :: rs, .litSpan _ _ :: as => synthSegSlotsSums rs as
    | .slot _ expectedRole :: rs, .slotLeaf tok :: as =>
      match synthSegSlotsSums rs as with
      | some (slots, sums) => some ((expectedRole, tok.entityId) :: slots, sums)
      | none => none
    | .child _ _ :: rs, .childNode sub :: as =>
      match synthNodeSummary sub, synthSegSlotsSums rs as with
      | some subSum, some (slots, sums) => some (slots, subSum :: sums)
      | _, _ => none
    | _, _ => none

  def synthNodeSummary : UntrustedDerivCert → Option NodeSummary
    | .mkNode _ rawCode _ _ args =>
      match decodeFrozenRule rawCode with
      | none => none
      | some r =>
        match synthSegSlotsSums (ruleSignature r).segments args with
        | some (slots, sums) => some ((ruleSignature r).mkSummary slots sums)
        | none => none
end

/-
  Explicit Structural Predicate: Every node's `claimedDischarged` specs match:
  1. Exact syntactic `ClauseLocus` licensing (`clause1` vs `clause2`), AND
  2. Exact rule-intrinsic `(locus, kind, target)` obligation list synthesized from its own slots & children!
-/
mutual
  def SegLocusTargetBound (loc : ClauseLocus) :
      List RuleSegment → List UntrustedSegArg → Prop
    | [], [] => True
    | .lit _ :: rs, .litSpan _ _ :: as => SegLocusTargetBound loc rs as
    | .slot _ _ :: rs, .slotLeaf _ :: as => SegLocusTargetBound loc rs as
    | .child _ locOpt :: rs, .childNode sub :: as =>
        NodeLocusTargetBound (locOpt.getD loc) sub ∧ SegLocusTargetBound loc rs as
    | _, _ => False

  def NodeLocusTargetBound (loc : ClauseLocus) : UntrustedDerivCert → Prop
    | .mkNode _ rawCode _ claimed args =>
      ∃ (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary),
        decodeFrozenRule rawCode = some r ∧
        synthSegSlotsSums (ruleSignature r).segments args = some (slots, sums) ∧
        claimed.map (·.spec) = (ruleSignature r).intrinsicObls loc slots sums ∧
        (∀ o ∈ claimed, o.spec.locus = loc ∨ (r = .G16_DocContrastive ∧ o.spec.locus = .clause2)) ∧
        SegLocusTargetBound loc (ruleSignature r).segments args
end

/-- Root-level Locus & Target Binding Predicate (`LocusTargetBound`). -/
def LocusTargetBound (cert : UntrustedDerivCert) : Prop :=
  NodeLocusTargetBound .clause1 cert

/-- Linear Obligation Conservation (`ObligationsConserved`): duplicate-free IDs & exact multiset equality! -/
def ObligationsConserved (cert : UntrustedDerivCert) (deltaIn : List ObligationToken) : Prop :=
  NoDupOblIds deltaIn ∧
  NoDupOblIds (collectClaimedObls cert) ∧
  MultisetEq (collectClaimedObls cert) deltaIn

/-! ### 3. Fundamental Structural Theorems on `ValidNodeDeriv` (Yield & Locus-Target Invariants) -/

mutual
  theorem validSegChain_spanMatches
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {segs : List RuleSegment}
      (args : List UntrustedSegArg)
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (h : ValidSegChain env Y loc cursor segs args endPos slots sums) :
      SpanMatches Y ⟨cursor, endPos⟩ (reconstructSegYield args) := by
    match segs, args with
    | [], [] =>
      rcases h with ⟨hle, rfl, _, _⟩
      simpa [reconstructSegYield] using spanMatches_empty hle
    | .lit txt :: restSegs, .litSpan claimed sp :: restArgs =>
      rcases h with ⟨_, hstart, hspan, hrest⟩
      have hih := validSegChain_spanMatches restArgs hrest
      rcases sp with ⟨sCp, eCp⟩
      dsimp at hstart
      subst hstart
      simpa [reconstructSegYield] using spanMatches_concat hspan hih
    | .slot expectedSort expectedRole :: restSegs, .slotLeaf tok :: restArgs =>
      rcases h with ⟨restSlots, _, _, _, hstart, hspan, _, hrest⟩
      have hih := validSegChain_spanMatches restArgs hrest
      rcases tok with ⟨srt, rl, eid, lex, ⟨sCp, eCp⟩⟩
      dsimp at hstart
      subst hstart
      simpa [reconstructSegYield] using spanMatches_concat hspan hih
    | .child cat locOpt :: restSegs, .childNode sub :: restArgs =>
      rcases h with ⟨subSum, restSums, hstart, hsub, _, hrest⟩
      have hsub_span := validNodeDeriv_spanMatches sub hsub
      have hih := validSegChain_spanMatches restArgs hrest
      cases sub with
      | mkNode nid rc sp cl sargs =>
        rcases sp with ⟨sCp, eCp⟩
        dsimp at hstart hsub_span hih
        subst hstart
        simpa [reconstructSegYield] using spanMatches_concat hsub_span hih
    | [], _ :: _ => exact False.elim h
    | .lit _ :: _, [] => exact False.elim h
    | .slot _ _ :: _, [] => exact False.elim h
    | .child _ _ :: _, [] => exact False.elim h
    | .lit _ :: _, .slotLeaf _ :: _ => exact False.elim h
    | .lit _ :: _, .childNode _ :: _ => exact False.elim h
    | .slot _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .slot _ _ :: _, .childNode _ :: _ => exact False.elim h
    | .child _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .child _ _ :: _, .slotLeaf _ :: _ => exact False.elim h

  theorem validNodeDeriv_spanMatches
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {cat : NontermCat}
      (cert : UntrustedDerivCert) {sum : NodeSummary}
      (h : ValidNodeDeriv env Y loc cat cert sum) :
      SpanMatches Y (match cert with | .mkNode _ _ sp _ _ => sp) (reconstructYieldChars cert) := by
    cases cert with
    | mkNode nid rawCode sp claimed args =>
      rcases h with ⟨r, slots, sums, _, _, hsegs, _, _, _⟩
      simpa [reconstructYieldChars] using validSegChain_spanMatches args hsegs
end

/-- Theorem: Any `ValidGrammarDerivation` reconstructs the EXACT target string `Y` (`Yield(π) = Y`)! -/
theorem validGrammarDerivation_yield_eq
    {env : ScopeEnv} {Y : String} {cert : UntrustedDerivCert}
    (h : ValidGrammarDerivation env Y cert) :
    reconstructYield cert = Y := by
  rcases h with ⟨hroot_sp, sum, hderiv⟩
  have hmatch := validNodeDeriv_spanMatches cert hderiv
  cases cert with
  | mkNode nid rc sp cl args =>
    dsimp at hroot_sp hmatch
    rw [hroot_sp] at hmatch
    have hchars : reconstructYieldChars (.mkNode nid rc sp cl args) = Y.toList :=
      spanMatches_full_eq hmatch
    unfold reconstructYield
    rw [hchars, String.ofList_toList]

theorem intrinsicObls_locus_valid (r : FrozenGenRule) (loc : ClauseLocus)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    ∀ s ∈ (ruleSignature r).intrinsicObls loc slots sums,
      s.locus = loc ∨ (r = .G16_DocContrastive ∧ s.locus = .clause2) := by
  intro s hs
  cases r <;> simp [ruleSignature] at hs
  all_goals
    try (subst hs; left; rfl)
  · -- G16_DocContrastive
    split at hs
    · split at hs
      · simp at hs; subst hs; right; exact ⟨rfl, rfl⟩
      · simp at hs; subst hs; right; exact ⟨rfl, rfl⟩
    · simp at hs
  · -- G04_AssocTemp
    rcases hs with h1 | h2
    · subst h1; left; rfl
    · subst h2; left; rfl
  · -- G06a_IntervDirectional
    rcases hs with h1 | h2
    · subst h1; left; rfl
    · subst h2; left; rfl
  · -- G06b_IntervNeutral
    rcases hs with h1 | h2
    · subst h1; left; rfl
    · subst h2; left; rfl
  · -- G14_AssocAdj
    rcases hs with h1 | h2
    · subst h1; left; rfl
    · subst h2; left; rfl

mutual
  theorem validSegChain_synth_eq
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {segs : List RuleSegment}
      (args : List UntrustedSegArg)
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (h : ValidSegChain env Y loc cursor segs args endPos slots sums) :
      synthSegSlotsSums segs args = some (slots, sums) := by
    match segs, args with
    | [], [] =>
      rcases h with ⟨_, _, rfl, rfl⟩
      rfl
    | .lit _ :: _, .litSpan _ _ :: restArgs =>
      rcases h with ⟨_, _, _, hrest⟩
      simpa [synthSegSlotsSums] using validSegChain_synth_eq restArgs hrest
    | .slot _ _ :: _, .slotLeaf _ :: restArgs =>
      rcases h with ⟨restSlots, _, _, _, _, _, rfl, hrest⟩
      have hih := validSegChain_synth_eq restArgs hrest
      simp [synthSegSlotsSums, hih]
    | .child _ _ :: _, .childNode sub :: restArgs =>
      rcases h with ⟨subSum, restSums, _, hsub, rfl, hrest⟩
      have hsub_eq := validNodeDeriv_synth_eq sub hsub
      have hih := validSegChain_synth_eq restArgs hrest
      simp [synthSegSlotsSums, hsub_eq, hih]
    | [], _ :: _ => exact False.elim h
    | .lit _ :: _, [] => exact False.elim h
    | .slot _ _ :: _, [] => exact False.elim h
    | .child _ _ :: _, [] => exact False.elim h
    | .lit _ :: _, .slotLeaf _ :: _ => exact False.elim h
    | .lit _ :: _, .childNode _ :: _ => exact False.elim h
    | .slot _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .slot _ _ :: _, .childNode _ :: _ => exact False.elim h
    | .child _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .child _ _ :: _, .slotLeaf _ :: _ => exact False.elim h

  theorem validNodeDeriv_synth_eq
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {cat : NontermCat}
      (cert : UntrustedDerivCert) {sum : NodeSummary}
      (h : ValidNodeDeriv env Y loc cat cert sum) :
      synthNodeSummary cert = some sum := by
    cases cert with
    | mkNode nid rawCode sp claimed args =>
      rcases h with ⟨r, slots, sums, hrule, _, hsegs, _, _, rfl⟩
      have hseg_eq := validSegChain_synth_eq args hsegs
      simp [synthNodeSummary, hrule, hseg_eq]
end

mutual
  theorem validSegChain_locusBound
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {segs : List RuleSegment}
      (args : List UntrustedSegArg)
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (h : ValidSegChain env Y loc cursor segs args endPos slots sums) :
      SegLocusTargetBound loc segs args := by
    match segs, args with
    | [], [] => trivial
    | .lit _ :: _, .litSpan _ _ :: restArgs =>
      rcases h with ⟨_, _, _, hrest⟩
      exact validSegChain_locusBound restArgs hrest
    | .slot _ _ :: _, .slotLeaf _ :: restArgs =>
      rcases h with ⟨_, _, _, _, _, _, _, hrest⟩
      exact validSegChain_locusBound restArgs hrest
    | .child _ _ :: _, .childNode sub :: restArgs =>
      rcases h with ⟨_, _, _, hsub, _, hrest⟩
      exact ⟨validNodeDeriv_locusBound sub hsub, validSegChain_locusBound restArgs hrest⟩
    | [], _ :: _ => exact False.elim h
    | .lit _ :: _, [] => exact False.elim h
    | .slot _ _ :: _, [] => exact False.elim h
    | .child _ _ :: _, [] => exact False.elim h
    | .lit _ :: _, .slotLeaf _ :: _ => exact False.elim h
    | .lit _ :: _, .childNode _ :: _ => exact False.elim h
    | .slot _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .slot _ _ :: _, .childNode _ :: _ => exact False.elim h
    | .child _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .child _ _ :: _, .slotLeaf _ :: _ => exact False.elim h

  theorem validNodeDeriv_locusBound
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {cat : NontermCat}
      (cert : UntrustedDerivCert) {sum : NodeSummary}
      (h : ValidNodeDeriv env Y loc cat cert sum) :
      NodeLocusTargetBound loc cert := by
    cases cert with
    | mkNode nid rawCode sp claimed args =>
      rcases h with ⟨r, slots, sums, hrule, _, hsegs, _, hlocus, _⟩
      refine ⟨r, slots, sums, hrule, validSegChain_synth_eq args hsegs, hlocus, ?_, validSegChain_locusBound args hsegs⟩
      intro o ho
      have hspec_mem : o.spec ∈ claimed.map (·.spec) := List.mem_map_of_mem (f := (·.spec)) ho
      rw [hlocus] at hspec_mem
      exact intrinsicObls_locus_valid r loc slots sums o.spec hspec_mem
end

theorem validGrammarDerivation_implies_locusTargetBound
    {env : ScopeEnv} {Y : String} {cert : UntrustedDerivCert}
    (h : ValidGrammarDerivation env Y cert) :
    LocusTargetBound cert := by
  rcases h with ⟨_, _, hderiv⟩
  exact validNodeDeriv_locusBound cert hderiv

end BrocaOmega.P2
```

### 5.7 `02_detached_checker/P2DetachedChecker.lean` (`SHA-256: E760EA1634186EEC8E063CCC1EA28C6E84E07AAD87BCEEBB1DD43DAED7E4F997`)
```lean
import P2DetachedChecker.ReplayChecker
```

### 5.8 `02_detached_checker/P2DetachedChecker/ReplayChecker.lean` (`SHA-256: DC30D0E9313A9A695B19852ADC9C1DDF45F6FC05E31DD9DE9777AB2299E91068`)
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2DetachedChecker/ReplayChecker.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  Implements the detached Bottom-Up Span-Yield & Locus-Bound Obligation Replay Kernel:
  1. Strict architectural separation between proof-carrying `ReplayOutcome.accepted (w)`
     (`CertifiedDerivation` with `private mk ::`) and non-authoritative structured
     diagnostics `ReplayOutcome.rejected (diag : CEGESReplayDiag)`.
  2. Total recursive verification of frozen `G-01` ~ `G-16` rules, contiguous spans,
     keyword barriers, clause-locus/target-bound obligations, and linear multiset conservation.
  3. Machine-checked `replayDerivation_sound` (`PO-C1-02`) and `replayDerivation_complete`.
-/
import P2FormalSpec

namespace BrocaOmega.P2

/-! ### 1. Non-Authoritative Structured CEGES Refutation Diagnostics -/

/--
  Structured diagnostic emitted on rejection to guide outer untrusted CEGES repair.
  Carries zero proof authority and cannot construct `CertifiedDerivation`.
-/
inductive CEGESReplayDiag where
  | forgedOrTrapRuleId            (nodeId : Nat) (rawRuleCode : Nat)
  | nontermCatMismatch            (nodeId : Nat) (expected actual : NontermCat)
  | segmentArityOrKindMismatch    (nodeId : Nat)
  | fixedTerminalMismatch         (nodeId : Nat) (expected claimed : String)
  | invalidSlotSortOrRole         (nodeId : Nat)
  | invalidSlotLexemeOrKeywordLeak (nodeId : Nat) (sort : SlotSort) (lexeme : String)
  | spanStartDiscontinuity        (nodeId : Nat) (expectedCursor actualStart : Nat)
  | spanSliceMismatch             (nodeId : Nat) (span : CodepointSpan)
  | cursorOutOfBounds             (nodeId : Nat) (cursor textLen : Nat)
  | nodeEndSpanMismatch           (nodeId : Nat) (expectedEnd actualEnd : Nat)
  | sideConditionFailed           (nodeId : Nat) (rule : FrozenGenRule)
  | locusOrTargetOblMismatch      (nodeId : Nat) (expected actual : List ObligationSpec)
  | rootSpanNotFullText           (actual : CodepointSpan) (expectedLen : Nat)
  | inputOblIdsNotUnique
  | duplicateOblIdDischarged
  | obligationMultisetMismatch
  deriving DecidableEq, Repr

/-! ### 2. Sealed Proof-Carrying Witness & Replay Outcome -/

/--
  Sealed proof-carrying witness for an accepted `UntrustedDerivCert`.
  `private mk ::` ensures no external code can forge an instance without passing `replayDerivation`.
-/
structure CertifiedDerivation (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken) where
  private mk ::
  cert        : UntrustedDerivCert
  hValidDeriv : ValidGrammarDerivation env Y cert
  hYieldEq    : reconstructYield cert = Y
  hOblConserv : ObligationsConserved cert deltaIn
  hLocusBound : LocusTargetBound cert

/-- Outcome of detached derivation replay: proof-carrying `accepted` vs diagnostic `rejected`. -/
inductive ReplayOutcome (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken) where
  | accepted (witness : CertifiedDerivation env Y deltaIn)
  | rejected (diag : CEGESReplayDiag)

def ReplayOutcome.isAccepted {env : ScopeEnv} {Y : String} {deltaIn : List ObligationToken} :
    ReplayOutcome env Y deltaIn → Bool
  | .accepted _ => true
  | .rejected _ => false

def ReplayOutcome.diag? {env : ScopeEnv} {Y : String} {deltaIn : List ObligationToken} :
    ReplayOutcome env Y deltaIn → Option CEGESReplayDiag
  | .accepted _ => none
  | .rejected d => some d

/-! ### 3. Proof-Carrying Bottom-Up Segment & Node Replay Kernel -/

mutual
  /--
    Verifies a production's `RuleSegment` list against `UntrustedSegArg` list from `cursor`,
    synthesizing `(endPos, slots, childSummaries)` together with a proof of `ValidSegChain`.
  -/
  def replaySegs (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (nodeId : Nat) (cursor : Nat) (segs : List RuleSegment) (args : List UntrustedSegArg) :
      Except CEGESReplayDiag
        { res : Nat × List (SlotRole × String) × List NodeSummary //
          ValidSegChain env Y loc cursor segs args res.1 res.2.1 res.2.2 } :=
    match segs, args with
    | [], [] =>
      if hle : cursor ≤ Y.length then
        .ok ⟨(cursor, [], []), ⟨hle, rfl, rfl, rfl⟩⟩
      else
        .error (.cursorOutOfBounds nodeId cursor Y.length)

    | .lit txt :: restSegs, .litSpan claimed sp :: restArgs =>
      if htxt : claimed = txt then
        if hstart : sp.startCp = cursor then
          if hslice : checkSpanMatchesBool Y sp claimed.toList = true then
            match replaySegs env Y loc nodeId sp.endCp restSegs restArgs with
            | .error e => .error e
            | .ok subRes =>
              let endPos := subRes.1.1
              let slots  := subRes.1.2.1
              let sums   := subRes.1.2.2
              .ok ⟨(endPos, slots, sums),
                    ⟨htxt, hstart, checkSpanMatchesBool_sound hslice, subRes.2⟩⟩
          else
            .error (.spanSliceMismatch nodeId sp)
        else
          .error (.spanStartDiscontinuity nodeId cursor sp.startCp)
      else
        .error (.fixedTerminalMismatch nodeId txt claimed)

    | .slot expectedSort expectedRole :: restSegs, .slotLeaf tok :: restArgs =>
      if hsr : tok.sort = expectedSort ∧ tok.role = expectedRole then
        if hlex : isValidSlotLexeme expectedSort tok.lexeme = true then
          if hstart : tok.span.startCp = cursor then
            if hslice : checkSpanMatchesBool Y tok.span tok.lexeme.toList = true then
              match replaySegs env Y loc nodeId tok.span.endCp restSegs restArgs with
              | .error e => .error e
              | .ok subRes =>
                let endPos    := subRes.1.1
                let restSlots := subRes.1.2.1
                let sums      := subRes.1.2.2
                .ok ⟨(endPos, (expectedRole, tok.entityId) :: restSlots, sums),
                      ⟨restSlots, hsr.1, hsr.2, hlex, hstart,
                       checkSpanMatchesBool_sound hslice, rfl, subRes.2⟩⟩
            else
              .error (.spanSliceMismatch nodeId tok.span)
          else
            .error (.spanStartDiscontinuity nodeId cursor tok.span.startCp)
        else
          .error (.invalidSlotLexemeOrKeywordLeak nodeId expectedSort tok.lexeme)
      else
        .error (.invalidSlotSortOrRole nodeId)

    | .child cat locOpt :: restSegs, .childNode sub :: restArgs =>
      let childStart := match sub with | .mkNode _ _ sp _ _ => sp.startCp
      let childEnd   := match sub with | .mkNode _ _ sp _ _ => sp.endCp
      if hstart : childStart = cursor then
        match replayNode env Y (locOpt.getD loc) cat sub with
        | .error e => .error e
        | .ok childRes =>
          match replaySegs env Y loc nodeId childEnd restSegs restArgs with
          | .error e => .error e
          | .ok subRes =>
            let endPos   := subRes.1.1
            let slots    := subRes.1.2.1
            let restSums := subRes.1.2.2
            .ok ⟨(endPos, slots, childRes.1 :: restSums),
                  ⟨childRes.1, restSums, hstart, childRes.2, rfl, subRes.2⟩⟩
      else
        .error (.spanStartDiscontinuity nodeId cursor childStart)

    | _, _ =>
      .error (.segmentArityOrKindMismatch nodeId)

  /--
    Verifies a single node of `UntrustedDerivCert` against `expectedCat` and `loc`,
    synthesizing its `NodeSummary` together with a proof of `ValidNodeDeriv`.
  -/
  def replayNode (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (expectedCat : NontermCat) (cert : UntrustedDerivCert) :
      Except CEGESReplayDiag { sum : NodeSummary // ValidNodeDeriv env Y loc expectedCat cert sum } :=
    match cert with
    | .mkNode nodeId rawCode sp claimed args =>
      match hdec : decodeFrozenRule rawCode with
      | none => .error (.forgedOrTrapRuleId nodeId rawCode)
      | some r =>
        let sig := ruleSignature r
        if hcat : sig.lhsCat = expectedCat then
          match replaySegs env Y loc nodeId sp.startCp sig.segments args with
          | .error e => .error e
          | .ok segRes =>
            let endPos := segRes.1.1
            let slots  := segRes.1.2.1
            let sums   := segRes.1.2.2
            if hend : endPos = sp.endCp then
              if hside : sig.checkSideCond env slots sums = true then
                let expectedSpecs := sig.intrinsicObls loc slots sums
                let actualSpecs   := claimed.map (·.spec)
                if hlocus : actualSpecs = expectedSpecs then
                  have hsegs' : ValidSegChain env Y loc sp.startCp sig.segments args sp.endCp slots sums := by
                    rw [← hend]
                    exact segRes.2
                  .ok ⟨sig.mkSummary slots sums,
                        ⟨r, slots, sums, hdec, hcat, hsegs', hside, hlocus, rfl⟩⟩
                else
                  .error (.locusOrTargetOblMismatch nodeId expectedSpecs actualSpecs)
              else
                .error (.sideConditionFailed nodeId r)
            else
              .error (.nodeEndSpanMismatch nodeId endPos sp.endCp)
        else
          .error (.nontermCatMismatch nodeId expectedCat sig.lhsCat)
end

/--
  Top-Level Detached Derivation Replay Verifier (`Gate C1-P2`).
  Verifies:
  1. Duplicate-freeness of `deltaIn` obligation IDs (`NoDupOblIds deltaIn`).
  2. Root span covers `[0, Y.toList.length)` (`rootSpanNotFullText`).
  3. Full recursive `G-01`~`G-16` grammar, contiguous span-yield, and locus-target obligations (`replayNode`).
  4. Duplicate-freeness of discharged obligation IDs (`NoDupOblIds (collectClaimedObls cert)`).
  5. Exact free-commutative-monoid multiset equality (`MultisetEq (collectClaimedObls cert) deltaIn`).
-/
def replayDerivation (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert) : ReplayOutcome env Y deltaIn :=
  if hNoDupIn : checkNoDupOblIdsBool deltaIn = true then
    match cert with
    | .mkNode nid rc rootSp cl args =>
      let certVal := UntrustedDerivCert.mkNode nid rc rootSp cl args
      if hRootSp : rootSp = ⟨0, Y.toList.length⟩ then
        match replayNode env Y.toList .clause1 .documentRoot certVal with
        | .error diag => .rejected diag
        | .ok nodeRes =>
          let claimedAll := collectClaimedObls certVal
          if hNoDupClaim : checkNoDupOblIdsBool claimedAll = true then
            if hMulti : checkMultisetEqBool claimedAll deltaIn = true then
              have hValid : ValidGrammarDerivation env Y certVal :=
                ⟨hRootSp, nodeRes.1, nodeRes.2⟩
              have hYield : reconstructYield certVal = Y :=
                validGrammarDerivation_yield_eq hValid
              have hObl : ObligationsConserved certVal deltaIn :=
                ⟨(checkNoDupOblIdsBool_iff deltaIn).mp hNoDupIn,
                 (checkNoDupOblIdsBool_iff claimedAll).mp hNoDupClaim,
                 (checkMultisetEqBool_iff claimedAll deltaIn).mp hMulti⟩
              have hLocus : LocusTargetBound certVal :=
                validGrammarDerivation_implies_locusTargetBound hValid
              .accepted ⟨certVal, hValid, hYield, hObl, hLocus⟩
            else
              .rejected .obligationMultisetMismatch
          else
            .rejected .duplicateOblIdDischarged
      else
        .rejected (.rootSpanNotFullText rootSp Y.toList.length)
  else
    .rejected .inputOblIdsNotUnique

/-! ### 4. Main Soundness (`PO-C1-02`) & Relative Completeness Theorems -/

/--
  Lemma: Witness binding (`replayDerivation` never substitutes a different certificate).
-/
theorem replayDerivation_witness_cert_eq
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert) (w : CertifiedDerivation env Y deltaIn)
    (hAcc : replayDerivation env Y deltaIn cert = .accepted w) :
    w.cert = cert := by
  cases cert with
  | mkNode nid rc rootSp cl args =>
    unfold replayDerivation at hAcc
    dsimp at hAcc
    split at hAcc
    · split at hAcc
      · split at hAcc
        · contradiction
        · split at hAcc
          · split at hAcc
            · injection hAcc with hw
              rw [← hw]
            · contradiction
          · contradiction
      · contradiction
    · contradiction

/--
  **Theorem `PO-C1-02` (`replayDerivation_sound`) — Derivation Replay Soundness**:
  Whenever `replayDerivation env Y deltaIn cert = .accepted w`, the exact submitted `cert`
  satisfies all four declarative guarantees:
  1. `ValidGrammarDerivation env Y cert`
  2. `reconstructYield cert = Y`
  3. `ObligationsConserved cert deltaIn`
  4. `LocusTargetBound cert`
-/
theorem replayDerivation_sound
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert) (w : CertifiedDerivation env Y deltaIn)
    (hAcc : replayDerivation env Y deltaIn cert = .accepted w) :
    w.cert = cert ∧
    ValidGrammarDerivation env Y cert ∧
    reconstructYield cert = Y ∧
    ObligationsConserved cert deltaIn ∧
    LocusTargetBound cert := by
  have hcert : w.cert = cert := replayDerivation_witness_cert_eq env Y deltaIn cert w hAcc
  refine ⟨hcert, ?_, ?_, ?_, ?_⟩
  · exact hcert ▸ w.hValidDeriv
  · exact hcert ▸ w.hYieldEq
  · exact hcert ▸ w.hOblConserv
  · exact hcert ▸ w.hLocusBound

/-! ### 5. Relative Completeness (`ValidGrammarDerivation ∧ ObligationsConserved ⟹ accepted`) -/

mutual
  theorem replaySegs_complete
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      (nodeId : Nat) {cursor endPos : Nat} {segs : List RuleSegment}
      (args : List UntrustedSegArg)
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (h : ValidSegChain env Y loc cursor segs args endPos slots sums) :
      ∃ subRes,
        replaySegs env Y loc nodeId cursor segs args = .ok subRes ∧
        subRes.1 = (endPos, slots, sums) := by
    match segs, args with
    | [], [] =>
      rcases h with ⟨hle, hend, hslots, hsums⟩
      subst endPos; subst slots; subst sums
      refine ⟨⟨(cursor, [], []), ⟨hle, rfl, rfl, rfl⟩⟩, ?_, rfl⟩
      simp [replaySegs, hle]
    | .lit txt :: restSegs, .litSpan claimed sp :: restArgs =>
      rcases h with ⟨htxt, hstart, hspan, hrest⟩
      subst claimed
      have hslice : checkSpanMatchesBool Y sp txt.toList = true :=
        spanMatches_implies_checkBool hspan
      rcases replaySegs_complete nodeId restArgs hrest with ⟨subRes, hrec, hval⟩
      rcases subRes with ⟨⟨eP, sls, sms⟩, hprf⟩
      dsimp at hval
      injection hval with h1 h2
      injection h2 with h3 h4
      subst eP; subst sls; subst sms
      refine ⟨⟨(endPos, slots, sums), ⟨rfl, hstart, checkSpanMatchesBool_sound hslice, hprf⟩⟩, ?_, rfl⟩
      simp [replaySegs, hstart, hslice, hrec]
    | .slot expectedSort expectedRole :: restSegs, .slotLeaf tok :: restArgs =>
      rcases h with ⟨restSlots, hsort, hrole, hlex, hstart, hspan, hslots_eq, hrest⟩
      subst slots; subst expectedSort; subst expectedRole
      have hslice : checkSpanMatchesBool Y tok.span tok.lexeme.toList = true :=
        spanMatches_implies_checkBool hspan
      rcases replaySegs_complete nodeId restArgs hrest with ⟨subRes, hrec, hval⟩
      rcases subRes with ⟨⟨eP, sls, sms⟩, hprf⟩
      dsimp at hval
      injection hval with h1 h2
      injection h2 with h3 h4
      subst eP; subst sls; subst sms
      refine ⟨⟨(endPos, (tok.role, tok.entityId) :: restSlots, sums),
              ⟨restSlots, rfl, rfl, hlex, hstart, checkSpanMatchesBool_sound hslice, rfl, hprf⟩⟩, ?_, rfl⟩
      simp [replaySegs, hlex, hstart, hslice, hrec]
    | .child cat locOpt :: restSegs, .childNode sub :: restArgs =>
      rcases h with ⟨subSum, restSums, hstart, hsub, hsums_eq, hrest⟩
      subst sums
      rcases replayNode_complete sub hsub with ⟨childRes, hchild, hchild_val⟩
      rcases childRes with ⟨cSum, hcPrf⟩
      dsimp at hchild_val
      subst cSum
      rcases replaySegs_complete nodeId restArgs hrest with ⟨subRes, hrec, hval⟩
      rcases subRes with ⟨⟨eP, sls, sms⟩, hprf⟩
      dsimp at hval
      injection hval with h1 h2
      injection h2 with h3 h4
      subst eP; subst sls; subst sms
      cases sub with
      | mkNode sNid sRc sSp sCl sArgs =>
        dsimp at hstart hrest hprf hrec
        refine ⟨⟨(endPos, slots, subSum :: restSums),
                ⟨subSum, restSums, hstart, hcPrf, rfl, hprf⟩⟩, ?_, rfl⟩
        unfold replaySegs
        dsimp
        rw [dif_pos hstart, hchild]
        dsimp
        rw [hrec]
    | [], _ :: _ => exact False.elim h
    | .lit _ :: _, [] => exact False.elim h
    | .slot _ _ :: _, [] => exact False.elim h
    | .child _ _ :: _, [] => exact False.elim h
    | .lit _ :: _, .slotLeaf _ :: _ => exact False.elim h
    | .lit _ :: _, .childNode _ :: _ => exact False.elim h
    | .slot _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .slot _ _ :: _, .childNode _ :: _ => exact False.elim h
    | .child _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .child _ _ :: _, .slotLeaf _ :: _ => exact False.elim h

  theorem replayNode_complete
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {expectedCat : NontermCat}
      (cert : UntrustedDerivCert) {outSum : NodeSummary}
      (h : ValidNodeDeriv env Y loc expectedCat cert outSum) :
      ∃ nodeRes,
        replayNode env Y loc expectedCat cert = .ok nodeRes ∧
        nodeRes.1 = outSum := by
    cases cert with
    | mkNode nodeId rawCode sp claimed args =>
      rcases h with ⟨r, slots, sums, hrule, hcat, hsegs, hside, hlocus, hout⟩
      subst outSum
      rcases replaySegs_complete nodeId args hsegs with ⟨segRes, hseg_ok, hseg_val⟩
      rcases segRes with ⟨⟨eP, sls, sms⟩, hseg_prf⟩
      dsimp at hseg_val
      injection hseg_val with h1 h2
      injection h2 with h3 h4
      subst eP; subst sls; subst sms
      unfold replayNode
      split
      · rename_i hnone
        rw [hrule] at hnone
        contradiction
      · rename_i r' hsome
        have hr_eq : r' = r := by
          rw [hrule] at hsome
          injection hsome with h_eq
          exact h_eq.symm
        subst r'
        dsimp
        rw [dif_pos hcat, hseg_ok]
        dsimp
        rw [dif_pos rfl, dif_pos hside, dif_pos hlocus]
        exact ⟨_, rfl, rfl⟩
end

/--
  **Relative Completeness (`replayDerivation_complete`)**:
  Every derivation certificate satisfying `ValidGrammarDerivation` and `ObligationsConserved`
  is deterministically accepted by `replayDerivation` (confirming non-vacuity of `replayDerivation_sound`).
-/
theorem replayDerivation_complete
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken) (cert : UntrustedDerivCert)
    (hValid : ValidGrammarDerivation env Y cert)
    (hObl : ObligationsConserved cert deltaIn) :
    ∃ w : CertifiedDerivation env Y deltaIn,
      replayDerivation env Y deltaIn cert = .accepted w ∧ w.cert = cert := by
  cases cert with
  | mkNode nid rc rootSp cl args =>
    rcases hValid with ⟨hRootSp, sum, hNode⟩
    dsimp at hRootSp
    subst rootSp
    rcases hObl with ⟨hNoDupIn, hNoDupClaim, hMulti⟩
    have hInBool : checkNoDupOblIdsBool deltaIn = true :=
      (checkNoDupOblIdsBool_iff deltaIn).mpr hNoDupIn
    have hClaimBool :
        checkNoDupOblIdsBool (collectClaimedObls (.mkNode nid rc ⟨0, Y.toList.length⟩ cl args)) = true :=
      (checkNoDupOblIdsBool_iff _).mpr hNoDupClaim
    have hMultiBool :
        checkMultisetEqBool (collectClaimedObls (.mkNode nid rc ⟨0, Y.toList.length⟩ cl args)) deltaIn = true :=
      (checkMultisetEqBool_iff _ deltaIn).mpr hMulti
    rcases replayNode_complete (.mkNode nid rc ⟨0, Y.toList.length⟩ cl args) hNode with ⟨nodeRes, hNodeOk, _⟩
    unfold replayDerivation
    simp [hInBool, hNodeOk, hClaimBool, hMultiBool]

end BrocaOmega.P2
```

### 5.9 `03_counterexamples/P2Counterexamples.lean` (`SHA-256: DF074F59C32A38F5098BD8E5DE4EC17364A1DCD0967EE0BE54479AC7EB7063EA`)
```lean
import P2Counterexamples.P2Suite
```

### 5.10 `03_counterexamples/P2Counterexamples/P2Suite.lean` (`SHA-256: 23C5DC565F18402A98F70E691935FC1DB38E29B2E2B884E906F07A05606F9E6B`)
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2Counterexamples/P2Suite.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `native_decide`)

  12 Symmetric `(PC, CE)` Contract Pairs (24 executable & kernel-proved test vectors)
  exercising every soundness invariant of `replayDerivation`:
    01. Forged / Trap Rule ID (`T2 = 902`) vs valid `G-03`
    02. Fixed structural terminal polarity tampering vs valid `G-09`
    03. 1-char surface string `Y` mutation (`"128.4"` -> `"128.5"`) vs valid `G-02a`
    04. Span contiguity gap/overlap shift vs valid `G-01`
    05. Duplicate obligation ID contraction (`oblId` discharged twice) vs valid `G-04`
    06. Unconsumed mandatory negation obligation (weakening) vs valid `G-11`
    07. Unlicensed extra obligation injected at node vs valid `G-12`
    08. Clause-Locus Swap (`clause1` <-> `clause2`, multiset preserved!) vs valid `G-15` (`sentenceAtomic`)
    09. Target-Payload Swap (locus & multiset preserved, metric forged!) vs valid `G-14`
    10. Illegal nested recursion (`G-15` inside `G-15`) vs valid flat `G-15` (`discourseBound`)
    11. Cross-clause exposure/outcome mismatch in contrastive `G-16` vs valid `G-16`
    12. Reserved syncategorematic keyword (`"did not"`) smuggled in slot vs valid `G-06a`
-/
import P2DetachedChecker

namespace BrocaOmega.P2.Counterexamples

/-! ### Test-Fixture Helpers (Untrusted Certificate Assembly for Test Vectors Only) -/

/- Raw unspanned tree used ONLY inside `P2Counterexamples` to compute canonical test fixtures. -/
instance : Inhabited ObligationToken where
  default := { oblId := 0, spec := { locus := .clause1, kind := .scopeAnchor, target := "" } }

mutual
  inductive RawTestArg where
    | lit (txt : String)
    | slot (sort : SlotSort) (role : SlotRole) (entityId : String) (lex : String)
    | child (node : RawTestNode)

  inductive RawTestNode where
    | mk (nodeId : Nat) (rawCode : Nat) (claimed : List ObligationToken) (args : List RawTestArg)
end

mutual
  def buildSpannedArgs (cursor : Nat) : List RawTestArg → Nat × List UntrustedSegArg
    | [] => (cursor, [])
    | .lit txt :: rest =>
      let next := cursor + txt.toList.length
      let (endPos, tailArgs) := buildSpannedArgs next rest
      (endPos, .litSpan txt ⟨cursor, next⟩ :: tailArgs)
    | .slot srt rl eid lex :: rest =>
      let next := cursor + lex.toList.length
      let (endPos, tailArgs) := buildSpannedArgs next rest
      (endPos, .slotLeaf ⟨srt, rl, eid, lex, ⟨cursor, next⟩⟩ :: tailArgs)
    | .child sub :: rest =>
      let (subEnd, subCert) := buildSpannedNode cursor sub
      let (endPos, tailArgs) := buildSpannedArgs subEnd rest
      (endPos, .childNode subCert :: tailArgs)

  def buildSpannedNode (cursor : Nat) : RawTestNode → Nat × UntrustedDerivCert
    | .mk nid rc claimed args =>
      let (endPos, spArgs) := buildSpannedArgs cursor args
      (endPos, .mkNode nid rc ⟨cursor, endPos⟩ claimed spArgs)
end

def mkFixture (raw : RawTestNode) : String × UntrustedDerivCert :=
  let (_, cert) := buildSpannedNode 0 raw
  (reconstructYield cert, cert)

/-- Standard environments for `sentenceAtomic` and `discourseBound` contracts. -/
def envAtomic : ScopeEnv :=
  { cohortId := "cohort_primary"
    expectedDesignHead := "design_rct"
    quoteIsolation := .sentenceAtomic }

def envDiscourse : ScopeEnv :=
  { cohortId := "cohort_primary"
    expectedDesignHead := "design_rct"
    quoteIsolation := .discourseBound }

def envObsDiscourse : ScopeEnv :=
  { cohortId := "cohort_primary"
    expectedDesignHead := "design_obs"
    quoteIsolation := .discourseBound }

/-- Descriptor for unified table execution & differential oracle export. -/
structure P2TestCase where
  caseId       : String
  pairGroup    : String
  isPositive   : Bool
  env          : ScopeEnv
  surfaceText  : String
  deltaIn      : List ObligationToken
  cert         : UntrustedDerivCert
  expectedPass : Bool
  expectedDiag : Option CEGESReplayDiag

def P2TestCase.runCheck (tc : P2TestCase) : Bool :=
  let out := replayDerivation tc.env tc.surfaceText tc.deltaIn tc.cert
  match tc.expectedPass, tc.expectedDiag with
  | true, none      => out.isAccepted
  | false, some exp => decide (out.diag? = some exp)
  | _, _            => false

/-! ### Pair 01: Forged / Trap Rule ID (`T2 = 902`) vs Valid `G-03` -/

def obls01 : List ObligationToken :=
  [ { oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 2, spec := { locus := .clause1, kind := .assocMetricDir,
                            target := "hr:inversely:exp_intensive:exp_std:out_mi" } } ]

def rawG03Node (ruleCode : Nat) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls01[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 210 []
            [ .child (.mk 4 ruleCode [obls01[1]!]
                [ .lit "comparing ",
                  .slot .expLevel .activeExp "exp_intensive" "intensive therapy",
                  .lit " versus ",
                  .slot .expLevel .refExp "exp_std" "standard care",
                  .lit " was ",
                  .slot .assocDir .direction "inversely" "inversely",
                  .lit " associated with ",
                  .slot .outTerm .outcome "out_mi" "myocardial infarction",
                  .lit " (",
                  .slot .ratioMetric .metric1 "hr" "hazard ratio",
                  .lit " = ",
                  .slot .numericLit .numEst "0.78" "0.78",
                  .lit ", ",
                  .slot .numericLit .numCILevel "95" "95",
                  .lit "% CI ",
                  .slot .numericLit .numCILow "0.65" "0.65",
                  .lit " to ",
                  .slot .numericLit .numCIHigh "0.94" "0.94",
                  .lit ")" ]) ]) ]),
      .lit "." ]

def pc01 : P2TestCase :=
  let (y, c) := mkFixture (rawG03Node 30)
  { caseId := "PC-P2-01", pairGroup := "PAIR-01-RULE-ID", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls01, cert := c,
    expectedPass := true, expectedDiag := none }

def ce01 : P2TestCase :=
  let (y, _) := mkFixture (rawG03Node 30)
  let (_, cTrap) := mkFixture (rawG03Node 902) -- Trap Rule T2 = 902
  { caseId := "CE-P2-01", pairGroup := "PAIR-01-RULE-ID", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls01, cert := cTrap,
    expectedPass := false, expectedDiag := some (.forgedOrTrapRuleId 4 902) }

/-! ### Pair 02: Fixed Structural Terminal Tampering vs Valid `G-09` -/

def obls02 : List ObligationToken :=
  [ { oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 11, spec := { locus := .clause1, kind := .metaNonEstabNeg,
                             target := "src_trialA:exp_intensive:reduces:out_stroke" } } ]

def rawG09Node (bridgeLit : String) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls02[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 211 []
            [ .child (.mk 4 90 [obls02[1]!]
                [ .lit "the analysis of ",
                  .slot .sourceId .source "src_trialA" "Trial-A",
                  .lit bridgeLit,
                  .child (.mk 5 301 []
                    [ .slot .expLevel .activeExp "exp_intensive" "intensive therapy",
                      .lit " ",
                      .slot .intervVerbPres .verb "reduces" "reduces",
                      .lit " ",
                      .slot .outTerm .outcome "out_stroke" "stroke" ]) ]) ]) ]),
      .lit "." ]

def pc02 : P2TestCase :=
  let (y, c) := mkFixture (rawG09Node " did not establish that ")
  { caseId := "PC-P2-02", pairGroup := "PAIR-02-FIXED-TERMINAL", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls02, cert := c,
    expectedPass := true, expectedDiag := none }

def ce02 : P2TestCase :=
  let (yTampered, cTampered) := mkFixture (rawG09Node " established that ")
  { caseId := "CE-P2-02", pairGroup := "PAIR-02-FIXED-TERMINAL", isPositive := false,
    env := envAtomic, surfaceText := yTampered, deltaIn := obls02, cert := cTampered,
    expectedPass := false,
    expectedDiag := some (.fixedTerminalMismatch 4 " did not establish that " " established that ") }

/-! ### Pair 03: 1-Character Surface `Y` Mutation (`"128.4"` -> `"128.5"`) vs Valid `G-02a` -/

def obls03 : List ObligationToken :=
  [ { oblId := 20, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 21, spec := { locus := .clause1, kind := .descDistribution,
                             target := "mean_sd:meas_sbp:128.4:14.2" } } ]

def rawG02aNode : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls03[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 20 [obls03[1]!]
            [ .lit "the mean ",
              .slot .measureTerm .measure "meas_sbp" "systolic blood pressure",
              .lit " was ",
              .slot .numericLit .numEst "128.4" "128.4",
              .lit " (SD ",
              .slot .numericLit .numDisp1 "14.2" "14.2",
              .lit ")" ]) ]),
      .lit "." ]

def pc03 : P2TestCase :=
  let (y, c) := mkFixture rawG02aNode
  { caseId := "PC-P2-03", pairGroup := "PAIR-03-YIELD-1CHAR", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls03, cert := c,
    expectedPass := true, expectedDiag := none }

def ce03 : P2TestCase :=
  let (_, c) := mkFixture rawG02aNode
  -- Exact same length `Y`, mutating `"128.4"` to `"128.5"` at codepoint span `[60, 65)`!
  let yMutated := "In the primary cohort, the mean systolic blood pressure was 128.5 (SD 14.2)."
  { caseId := "CE-P2-03", pairGroup := "PAIR-03-YIELD-1CHAR", isPositive := false,
    env := envAtomic, surfaceText := yMutated, deltaIn := obls03, cert := c,
    expectedPass := false, expectedDiag := some (.spanSliceMismatch 3 ⟨60, 65⟩) }

/-! ### Pair 04: Span Contiguity Gap/Overlap Attack vs Valid `G-01` -/

def obls04 : List ObligationToken :=
  [ { oblId := 30, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 31, spec := { locus := .clause1, kind := .descIncidence,
                             target := "win_24m:evt_hf:18/200=9.0" } } ]

def rawG01Node : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls04[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 10 [obls04[1]!]
            [ .lit "over ",
              .slot .followUpWindow .window "win_24m" "24 months",
              .lit ", the cumulative incidence of ",
              .slot .eventTerm .eventA "evt_hf" "heart failure",
              .lit " was ",
              .slot .numericLit .numK "18" "18",
              .lit " of ",
              .slot .numericLit .numN "200" "200",
              .lit " patients (",
              .slot .numericLit .numPct "9.0" "9.0",
              .lit "%)" ]) ]),
      .lit "." ]

def pc04 : P2TestCase :=
  let (y, c) := mkFixture rawG01Node
  { caseId := "PC-P2-04", pairGroup := "PAIR-04-SPAN-GAP", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls04, cert := c,
    expectedPass := true, expectedDiag := none }

/-- Mutates the final `.lit "."` at root node `1` to start 1 codepoint late (gap at end of sentence). -/
def introduceRootDotGap : UntrustedDerivCert → UntrustedDerivCert
  | .mkNode nid rc sp cl [sub, .litSpan "." ⟨s, e⟩] =>
    .mkNode nid rc sp cl [sub, .litSpan "." ⟨s + 1, e⟩]
  | c => c

def ce04 : P2TestCase :=
  let (y, c) := mkFixture rawG01Node
  let len := y.toList.length
  { caseId := "CE-P2-04", pairGroup := "PAIR-04-SPAN-GAP", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls04, cert := introduceRootDotGap c,
    expectedPass := false, expectedDiag := some (.spanStartDiscontinuity 1 (len - 1) len) }

/-! ### Pair 05: Duplicate Obligation ID Contraction Attack vs Valid `G-04` -/

def obls05 : List ObligationToken :=
  [ { oblId := 40, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 41, spec := { locus := .clause1, kind := .temporalPrecedence, target := "evt_aki<evt_ckd" } },
    { oblId := 42, spec := { locus := .clause1, kind := .assocMetricDir,
                             target := "rr:positively:exp_aki:exp_noaki:out_ckd" } } ]

def rawG04Node (scopeOblId : Nat) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [{ oblId := scopeOblId, spec := obls05[0]!.spec }]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 210 []
            [ .child (.mk 4 40 [obls05[1]!, obls05[2]!]
                [ .slot .eventTerm .eventA "evt_aki" "acute kidney injury",
                  .lit " preceded ",
                  .slot .eventTerm .eventB "evt_ckd" "chronic kidney disease",
                  .lit ", and comparing ",
                  .slot .expLevel .activeExp "exp_aki" "prior AKI",
                  .lit " versus ",
                  .slot .expLevel .refExp "exp_noaki" "no prior AKI",
                  .lit " was ",
                  .slot .assocDir .direction "positively" "positively",
                  .lit " associated with ",
                  .slot .outTerm .outcome "out_ckd" "renal progression",
                  .lit " (",
                  .slot .ratioMetric .metric1 "rr" "risk ratio",
                  .lit " = ",
                  .slot .numericLit .numEst "2.10" "2.10",
                  .lit ", ",
                  .slot .numericLit .numCILevel "95" "95",
                  .lit "% CI ",
                  .slot .numericLit .numCILow "1.50" "1.50",
                  .lit " to ",
                  .slot .numericLit .numCIHigh "2.94" "2.94",
                  .lit ")" ]) ]) ]),
      .lit "." ]

def pc05 : P2TestCase :=
  let (y, c) := mkFixture (rawG04Node 40)
  { caseId := "PC-P2-05", pairGroup := "PAIR-05-DUP-OBL-ID", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls05, cert := c,
    expectedPass := true, expectedDiag := none }

def ce05 : P2TestCase :=
  -- Reuses `oblId := 41` on `ScopedInitial` so `oblId = 41` is discharged TWICE in `collectClaimedObls`!
  let (y, cDup) := mkFixture (rawG04Node 41)
  { caseId := "CE-P2-05", pairGroup := "PAIR-05-DUP-OBL-ID", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls05, cert := cDup,
    expectedPass := false, expectedDiag := some .duplicateOblIdDischarged }

/-! ### Pair 06: Unconsumed Mandatory Negation Obligation (Weakening) vs Valid `G-11` -/

def obls06 : List ObligationToken :=
  [ { oblId := 50, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 51, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_lowrisk:evt_dka" } } ]

def rawG11Node : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls06[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 110 [obls06[1]!]
            [ .lit "no ",
              .slot .subgroupPlural .subgroup "sub_lowrisk" "low-risk",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_dka" "diabetic ketoacidosis" ]) ]),
      .lit "." ]

def pc06 : P2TestCase :=
  let (y, c) := mkFixture rawG11Node
  { caseId := "PC-P2-06", pairGroup := "PAIR-06-UNCONSUMED-OBL", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls06, cert := c,
    expectedPass := true, expectedDiag := none }

def ce06 : P2TestCase :=
  let (y, c) := mkFixture rawG11Node
  let extraNeg : ObligationToken :=
    { oblId := 52, spec := { locus := .clause1, kind := .metaNonEstabNeg, target := "src_A:x:causes:y" } }
  { caseId := "CE-P2-06", pairGroup := "PAIR-06-UNCONSUMED-OBL", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls06 ++ [extraNeg], cert := c,
    expectedPass := false, expectedDiag := some .obligationMultisetMismatch }

/-! ### Pair 07: Unlicensed Extra Obligation Injected at Node vs Valid `G-12` -/

def obls07 : List ObligationToken :=
  [ { oblId := 60, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 61, spec := { locus := .clause1, kind := .quantProperPart, target := "sub_elderly:evt_ edema" } } ]

-- Clean ASCII entityId `"evt_edema"`:
def obls07Clean : List ObligationToken :=
  [ { oblId := 60, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 61, spec := { locus := .clause1, kind := .quantProperPart, target := "sub_elderly:evt_edema" } } ]

def extraRogueObl07 : ObligationToken :=
  { oblId := 62, spec := { locus := .clause1, kind := .quantExistential, target := "sub_elderly:evt_edema" } }

def rawG12Node (claimedAtG12 : List ObligationToken) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls07Clean[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 120 claimedAtG12
            [ .lit "some, but not all, ",
              .slot .subgroupPlural .subgroup "sub_elderly" "elderly",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_edema" "peripheral edema" ]) ]),
      .lit "." ]

def pc07 : P2TestCase :=
  let (y, c) := mkFixture (rawG12Node [obls07Clean[1]!])
  { caseId := "PC-P2-07", pairGroup := "PAIR-07-UNLICENSED-OBL", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls07Clean, cert := c,
    expectedPass := true, expectedDiag := none }

def ce07 : P2TestCase :=
  let (y, cRogue) := mkFixture (rawG12Node [obls07Clean[1]!, extraRogueObl07])
  { caseId := "CE-P2-07", pairGroup := "PAIR-07-UNLICENSED-OBL", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls07Clean ++ [extraRogueObl07], cert := cRogue,
    expectedPass := false,
    expectedDiag := some (.locusOrTargetOblMismatch 3
      [obls07Clean[1]!.spec] [obls07Clean[1]!.spec, extraRogueObl07.spec]) }

/-! ### Pair 08: Clause-Locus Swap Attack (`clause1` <-> `clause2`, Multiset Preserved!) vs Valid `G-15` -/

def obls08Valid : List ObligationToken :=
  [ { oblId := 70, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 71, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_lowrisk:evt_hypo" } },
    { oblId := 72, spec := { locus := .clause2, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 73, spec := { locus := .clause2, kind := .quantExistential, target := "sub_frail:evt_syncope" } } ]

-- Swapped obligations: `quantZeroNeg` placed at `clause2` and `quantExistential` placed at `clause1`!
def obls08Swapped : List ObligationToken :=
  [ { oblId := 70, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 71, spec := { locus := .clause2, kind := .quantZeroNeg, target := "sub_lowrisk:evt_hypo" } },
    { oblId := 72, spec := { locus := .clause2, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 73, spec := { locus := .clause1, kind := .quantExistential, target := "sub_frail:evt_syncope" } } ]

def rawG15LocusNode (s1Obl s2Obl : ObligationToken) : RawTestNode :=
  .mk 1 150 []
    [ .child (.mk 2 201 [obls08Valid[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 110 [s1Obl]
            [ .lit "no ",
              .slot .subgroupPlural .subgroup "sub_lowrisk" "low-risk",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_hypo" "severe hypoglycemia" ]) ]),
      .lit ". ",
      .child (.mk 4 201 [obls08Valid[2]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 5 130 [s2Obl]
            [ .lit "at least one ",
              .slot .subgroupSingular .subgroup "sub_frail" "frail",
              .lit " patient developed ",
              .slot .eventTerm .eventA "evt_syncope" "syncope" ]) ]),
      .lit "." ]

def pc08 : P2TestCase :=
  let (y, c) := mkFixture (rawG15LocusNode obls08Valid[1]! obls08Valid[3]!)
  { caseId := "PC-P2-08", pairGroup := "PAIR-08-CLAUSE-LOCUS-SWAP", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls08Valid, cert := c,
    expectedPass := true, expectedDiag := none }

def ce08 : P2TestCase :=
  -- Global multiset of `cSwap` equals `obls08Swapped`! Only `LocusTargetBound` catches the locus swap at node 3!
  let (y, cSwap) := mkFixture (rawG15LocusNode obls08Swapped[1]! obls08Swapped[3]!)
  { caseId := "CE-P2-08", pairGroup := "PAIR-08-CLAUSE-LOCUS-SWAP", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls08Swapped, cert := cSwap,
    expectedPass := false,
    expectedDiag := some (.locusOrTargetOblMismatch 3 [obls08Valid[1]!.spec] [obls08Swapped[1]!.spec]) }

/-! ### Pair 09: Target-Payload Swap Attack (Locus & Multiset Preserved!) vs Valid `G-14` -/

def obls09Valid : List ObligationToken :=
  [ { oblId := 80, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 81, spec := { locus := .clause1, kind := .covariateAdjustment, target := "cov_age_hba1c" } },
    { oblId := 82, spec := { locus := .clause1, kind := .assocMetricDir,
                             target := "hr:inversely:exp_glp1:exp_dpp4:out_mace" } } ]

def forgedAssocObl09 : ObligationToken :=
  { oblId := 82, spec := { locus := .clause1, kind := .assocMetricDir,
                           target := "or:inversely:exp_glp1:exp_dpp4:out_mace" } } -- `"or"` instead of `"hr"`!

def rawG14Node (assocObl : ObligationToken) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls09Valid[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 210 []
            [ .child (.mk 4 140 [obls09Valid[1]!, assocObl]
                [ .lit "after adjustment for ",
                  .slot .covariateList .covariates "cov_age_hba1c" "age and baseline HbA1c",
                  .lit ", comparing ",
                  .slot .expLevel .activeExp "exp_glp1" "GLP-1 therapy",
                  .lit " versus ",
                  .slot .expLevel .refExp "exp_dpp4" "DPP-4 therapy",
                  .lit " was ",
                  .slot .assocDir .direction "inversely" "inversely",
                  .lit " associated with ",
                  .slot .outTerm .outcome "out_mace" "major cardiovascular events",
                  .lit " (",
                  .slot .ratioMetric .metric1 "hr" "hazard ratio",
                  .lit " = ",
                  .slot .numericLit .numEst "0.82" "0.82",
                  .lit ", ",
                  .slot .numericLit .numCILevel "95" "95",
                  .lit "% CI ",
                  .slot .numericLit .numCILow "0.70" "0.70",
                  .lit " to ",
                  .slot .numericLit .numCIHigh "0.96" "0.96",
                  .lit ")" ]) ]) ]),
      .lit "." ]

def pc09 : P2TestCase :=
  let (y, c) := mkFixture (rawG14Node obls09Valid[2]!)
  { caseId := "PC-P2-09", pairGroup := "PAIR-09-TARGET-SWAP", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls09Valid, cert := c,
    expectedPass := true, expectedDiag := none }

def ce09 : P2TestCase :=
  let (y, cTargetSwap) := mkFixture (rawG14Node forgedAssocObl09)
  let deltaForged := [obls09Valid[0]!, obls09Valid[1]!, forgedAssocObl09]
  { caseId := "CE-P2-09", pairGroup := "PAIR-09-TARGET-SWAP", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := deltaForged, cert := cTargetSwap,
    expectedPass := false,
    expectedDiag := some (.locusOrTargetOblMismatch 4
      [obls09Valid[1]!.spec, obls09Valid[2]!.spec]
      [obls09Valid[1]!.spec, forgedAssocObl09.spec]) }

/-! ### Pair 10: Illegal Recursive `G-15` Nesting (`documentRoot` Inside `G-15`) vs Flat `G-15` -/

def obls10 : List ObligationToken :=
  [ { oblId := 90, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 91, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_armA:evt_sepsis" } },
    { oblId := 92, spec := { locus := .clause2, kind := .scopeAnchor, target := "resolve:design_rct" } },
    { oblId := 93, spec := { locus := .clause2, kind := .quantExistential, target := "sub_armB:evt_rash" } } ]

def rawG15DiscourseValid : RawTestNode :=
  .mk 1 151 []
    [ .child (.mk 2 201 [obls10[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 110 [obls10[1]!]
            [ .lit "no ",
              .slot .subgroupPlural .subgroup "sub_armA" "intervention-arm",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_sepsis" "sepsis" ]) ]),
      .lit ". ",
      .child (.mk 4 202 [obls10[2]!]
        [ .lit "Within this same ",
          .slot .designNoun .design "design_rct" "randomized trial",
          .lit ", ",
          .child (.mk 5 130 [obls10[3]!]
            [ .lit "at least one ",
              .slot .subgroupSingular .subgroup "sub_armB" "control-arm",
              .lit " patient developed ",
              .slot .eventTerm .eventA "evt_rash" "injection-site rash" ]) ]),
      .lit "." ]

def rawG15NestedIllegal : RawTestNode :=
  .mk 1 151 []
    [ .child (.mk 2 201 [obls10[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 110 [obls10[1]!]
            [ .lit "no ",
              .slot .subgroupPlural .subgroup "sub_armA" "intervention-arm",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_sepsis" "sepsis" ]) ]),
      .lit ". ",
      -- Illegal recursive `G15_DocConjDiscourse` (code 151, `documentRoot`) placed where `scopedRepeat` is required!
      .child rawG15DiscourseValid,
      .lit "." ]

def pc10 : P2TestCase :=
  let (y, c) := mkFixture rawG15DiscourseValid
  { caseId := "PC-P2-10", pairGroup := "PAIR-10-ACYCLIC-G15", isPositive := true,
    env := envDiscourse, surfaceText := y, deltaIn := obls10, cert := c,
    expectedPass := true, expectedDiag := none }

def ce10 : P2TestCase :=
  let (yNested, cNested) := mkFixture rawG15NestedIllegal
  { caseId := "CE-P2-10", pairGroup := "PAIR-10-ACYCLIC-G15", isPositive := false,
    env := envDiscourse, surfaceText := yNested, deltaIn := obls10, cert := cNested,
    expectedPass := false,
    expectedDiag := some (.nontermCatMismatch 1 .scopedRepeat .documentRoot) }

/-! ### Pair 11: Cross-Clause Exposure/Outcome Mismatch in `G-16` (`; however,`) vs Valid `G-16` -/

def obls11 (c2OutId : String) : List ObligationToken :=
  [ { oblId := 100, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 101, spec := { locus := .clause1, kind := .assocMetricDir,
                              target := "hr:inversely:exp_sglt2:exp_placebo:out_hosp" } },
    { oblId := 102, spec := { locus := .clause2, kind := .scopeAnchor, target := "resolve:design_obs" } },
    { oblId := 103, spec := { locus := .clause2, kind := .metaNonEstabNeg,
                              target := "src_regB:exp_sglt2:reduces:" ++ c2OutId } },
    { oblId := 104, spec := { locus := .clause2, kind := .contrastiveBoundary,
                              target := "exp_sglt2:out_hosp" } } ]

def rawG16Node (c2OutId c2OutLex : String) : RawTestNode :=
  let obls := obls11 c2OutId
  .mk 1 160 [obls[4]!]
    [ .child (.mk 2 203 [obls[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 30 [obls[1]!]
            [ .lit "comparing ",
              .slot .expLevel .activeExp "exp_sglt2" "SGLT2 inhibition",
              .lit " versus ",
              .slot .expLevel .refExp "exp_placebo" "placebo",
              .lit " was ",
              .slot .assocDir .direction "inversely" "inversely",
              .lit " associated with ",
              .slot .outTerm .outcome "out_hosp" "heart-failure hospitalization",
              .lit " (",
              .slot .ratioMetric .metric1 "hr" "hazard ratio",
              .lit " = ",
              .slot .numericLit .numEst "0.74" "0.74",
              .lit ", ",
              .slot .numericLit .numCILevel "95" "95",
              .lit "% CI ",
              .slot .numericLit .numCILow "0.61" "0.61",
              .lit " to ",
              .slot .numericLit .numCIHigh "0.89" "0.89",
              .lit ")" ]) ]),
      .lit "; however, ",
      .child (.mk 4 204 [obls[2]!]
        [ .lit "within this same ",
          .slot .designNoun .design "design_obs" "observational study",
          .lit ", ",
          .child (.mk 5 90 [obls[3]!]
            [ .lit "the analysis of ",
              .slot .sourceId .source "src_regB" "Registry-B",
              .lit " did not establish that ",
              .child (.mk 6 301 []
                [ .slot .expLevel .activeExp "exp_sglt2" "SGLT2 inhibition",
                  .lit " ",
                  .slot .intervVerbPres .verb "reduces" "reduces",
                  .lit " ",
                  .slot .outTerm .outcome c2OutId c2OutLex ]) ]) ]),
      .lit "." ]

def pc11 : P2TestCase :=
  let (y, c) := mkFixture (rawG16Node "out_hosp" "heart-failure hospitalization")
  { caseId := "PC-P2-11", pairGroup := "PAIR-11-G16-SIDE-COND", isPositive := true,
    env := envObsDiscourse, surfaceText := y, deltaIn := obls11 "out_hosp", cert := c,
    expectedPass := true, expectedDiag := none }

def ce11 : P2TestCase :=
  let (yMismatch, cMismatch) := mkFixture (rawG16Node "out_mortality" "all-cause mortality")
  { caseId := "CE-P2-11", pairGroup := "PAIR-11-G16-SIDE-COND", isPositive := false,
    env := envObsDiscourse, surfaceText := yMismatch, deltaIn := obls11 "out_mortality", cert := cMismatch,
    expectedPass := false, expectedDiag := some (.sideConditionFailed 1 .G16_DocContrastive) }

/-! ### Pair 12: Syncategorematic Reserved Keyword Smuggling (`"did not"`) vs Valid `G-06a` -/

def obls12 : List ObligationToken :=
  [ { oblId := 110, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 111, spec := { locus := .clause1, kind := .identAssumption, target := "assump_exch" } },
    { oblId := 112, spec := { locus := .clause1, kind := .intervDirectional,
                              target := "rr:reduce:exp_insulin:exp_oral:out_micro" } } ]

def rawG06aNode (activeLex : String) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls12[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 60 [obls12[1]!, obls12[2]!]
            [ .lit "under ",
              .slot .identAssump .assumption "assump_exch" "conditional exchangeability",
              .lit ", comparing ",
              .slot .expLevel .activeExp "exp_insulin" activeLex,
              .lit " versus ",
              .slot .expLevel .refExp "exp_oral" "oral monotherapy",
              .lit " was estimated to ",
              .slot .intervDirVerb .verb "reduce" "reduce",
              .lit " ",
              .slot .outTerm .outcome "out_micro" "microvascular progression",
              .lit " (",
              .slot .ratioMetric .metric1 "rr" "risk ratio",
              .lit " = ",
              .slot .numericLit .numEst "0.72" "0.72",
              .lit ", ",
              .slot .numericLit .numCILevel "95" "95",
              .lit "% CI ",
              .slot .numericLit .numCILow "0.58" "0.58",
              .lit " to ",
              .slot .numericLit .numCIHigh "0.89" "0.89",
              .lit ", p = ",
              .slot .numericLit .numPVal "0.002" "0.002",
              .lit ")" ]) ]),
      .lit "." ]

def pc12 : P2TestCase :=
  let (y, c) := mkFixture (rawG06aNode "early insulin")
  { caseId := "PC-P2-12", pairGroup := "PAIR-12-KEYWORD-BARRIER", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls12, cert := c,
    expectedPass := true, expectedDiag := none }

def ce12 : P2TestCase :=
  let (yLeak, cLeak) := mkFixture (rawG06aNode "early insulin did not")
  { caseId := "CE-P2-12", pairGroup := "PAIR-12-KEYWORD-BARRIER", isPositive := false,
    env := envAtomic, surfaceText := yLeak, deltaIn := obls12, cert := cLeak,
    expectedPass := false,
    expectedDiag := some (.invalidSlotLexemeOrKeywordLeak 3 .expLevel "early insulin did not") }

/-! ### Complete 24-Vector Suite & Kernel-Checked Compile-Time Proofs (Zero `native_decide`) -/

def allP2Cases : List P2TestCase :=
  [ pc01, ce01, pc02, ce02, pc03, ce03, pc04, ce04,
    pc05, ce05, pc06, ce06, pc07, ce07, pc08, ce08,
    pc09, ce09, pc10, ce10, pc11, ce11, pc12, ce12 ]

set_option maxRecDepth 16384 in
theorem pc01_verified : pc01.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce01_verified : ce01.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc02_verified : pc02.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce02_verified : ce02.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc03_verified : pc03.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce03_verified : ce03.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc04_verified : pc04.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce04_verified : ce04.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc05_verified : pc05.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce05_verified : ce05.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc06_verified : pc06.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce06_verified : ce06.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc07_verified : pc07.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce07_verified : ce07.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc08_verified : pc08.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce08_verified : ce08.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc09_verified : pc09.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce09_verified : ce09.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc10_verified : pc10.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce10_verified : ce10.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc11_verified : pc11.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce11_verified : ce11.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc12_verified : pc12.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce12_verified : ce12.runCheck = true := by decide

theorem allP2Cases_verified : allP2Cases.all P2TestCase.runCheck = true := by
  simp [allP2Cases, List.all,
        pc01_verified, ce01_verified, pc02_verified, ce02_verified,
        pc03_verified, ce03_verified, pc04_verified, ce04_verified,
        pc05_verified, ce05_verified, pc06_verified, ce06_verified,
        pc07_verified, ce07_verified, pc08_verified, ce08_verified,
        pc09_verified, ce09_verified, pc10_verified, ce10_verified,
        pc11_verified, ce11_verified, pc12_verified, ce12_verified]

end BrocaOmega.P2.Counterexamples
```

### 5.11 `04_proof_obligations/P2ProofObligations.lean` (`SHA-256: 439AEF182FFC6C4F421B2560E787E0F6B74D6609EA2EBDAC465882E98F27CCAD`)
```lean
import P2ProofObligations.PO_C1_02_ReplaySoundness
```

### 5.12 `04_proof_obligations/P2ProofObligations/PO_C1_02_ReplaySoundness.lean` (`SHA-256: 64CA94681C5791E03FCE479CEBC1DBF385BB8B4B8344406ACFD7AF032789E27B`)
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2ProofObligations/PO_C1_02_ReplaySoundness.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `sorry`, zero custom `axiom`)

  Canonical Proof Obligation Export Ledger for `AUTH-C1-P2`:
  - `PO_C1_02_GrammarAcyclicRank`
  - `PO_C1_02_DerivationReplaySoundness`
  - `PO_C1_02_DerivationReplayCompleteness`
  - `PO_C1_02_CounterexampleSuiteVerified`
  - Explicit authorization & HELD locks preserving upstream/downstream isolation.
-/
import P2FormalSpec
import P2DetachedChecker
import P2Counterexamples

namespace BrocaOmega.P2.ProofObligations

/--
  **PO-C1-02a (`GrammarAcyclicRank`)**:
  Every child nonterminal referenced by any rule in frozen `G-01` ~ `G-16` has strictly
  smaller stratification rank than the rule's LHS category (`0 ≤ rank ≤ 4`), proving DAG acyclicity.
-/
theorem PO_C1_02_GrammarAcyclicRank
    (r : FrozenGenRule) (cat : NontermCat) (locOpt : Option ClauseLocus)
    (hmem : RuleSegment.child cat locOpt ∈ (ruleSignature r).segments) :
    cat.rank < (ruleSignature r).lhsCat.rank :=
  child_rank_lt_lhs_rank r cat locOpt hmem

/--
  **PO-C1-02 (`DerivationReplaySoundness`) — Master Theorem of `AUTH-C1-P2`**:
  $$
  \operatorname{replayDerivation}(\Gamma_{\mathrm{env}}, Y, \Delta_{\mathrm{in}}, \pi) = \operatorname{accepted}(w)
  \implies
  w.\pi = \pi \land
  \operatorname{ValidGrammarDerivation}(\Gamma_{\mathrm{env}}, Y, \pi) \land
  \operatorname{reconstructYield}(\pi) = Y \land
  \operatorname{ObligationsConserved}(\pi, \Delta_{\mathrm{in}}) \land
  \operatorname{LocusTargetBound}(\pi)
  $$
-/
theorem PO_C1_02_DerivationReplaySoundness
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert) (w : CertifiedDerivation env Y deltaIn)
    (hAcc : replayDerivation env Y deltaIn cert = .accepted w) :
    w.cert = cert ∧
    ValidGrammarDerivation env Y cert ∧
    reconstructYield cert = Y ∧
    ObligationsConserved cert deltaIn ∧
    LocusTargetBound cert :=
  replayDerivation_sound env Y deltaIn cert w hAcc

/--
  **PO-C1-02b (`DerivationReplayCompleteness`) — Non-Vacuity / Relative Completeness**:
  Every derivation tree satisfying `ValidGrammarDerivation` and `ObligationsConserved`
  is accepted by `replayDerivation` with witness bound to the exact input certificate.
-/
theorem PO_C1_02_DerivationReplayCompleteness
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert)
    (hValid : ValidGrammarDerivation env Y cert)
    (hObl : ObligationsConserved cert deltaIn) :
    ∃ w : CertifiedDerivation env Y deltaIn,
      replayDerivation env Y deltaIn cert = .accepted w ∧ w.cert = cert :=
  replayDerivation_complete env Y deltaIn cert hValid hObl

/--
  **PO-C1-02c (`CounterexampleSuiteVerified`)**:
  All 24 symmetric `(PC, CE)` test cases (`12` positive controls + `12` adversarial mutations)
  evaluate to `true` under Lean's kernel reduction (`decide`, zero `native_decide`).
-/
theorem PO_C1_02_CounterexampleSuiteVerified :
    Counterexamples.allP2Cases.all Counterexamples.P2TestCase.runCheck = true :=
  Counterexamples.allP2Cases_verified

/-! ### Explicit Scope & Authorization Locks (`Gate C1-P2` Isolation Boundaries) -/

inductive TrackGateStatus where
  | scopedSourceVerifiedLocal
  | heldExternalKernelReplay
  | notAuthorized
  deriving DecidableEq, Repr

def status_P1_PO_C1_04a_ExternalAdmission : TrackGateStatus := .heldExternalKernelReplay
def status_P1_C_Int128FastPath            : TrackGateStatus := .notAuthorized
def status_P2_PO_C1_02_DerivationReplay   : TrackGateStatus := .scopedSourceVerifiedLocal
def status_P3_SurfaceCanonicalizerParser  : TrackGateStatus := .notAuthorized
def status_P4_ClinicalEvidenceCalculus    : TrackGateStatus := .notAuthorized
def status_P5_SnapshotHashAdmission       : TrackGateStatus := .notAuthorized
def status_Pneuma_S3_S4_Integration       : TrackGateStatus := .notAuthorized

end BrocaOmega.P2.ProofObligations
```

### 5.13 `05_independent_tribunal/P2TribunalAudit.lean` (`SHA-256: BC9164210E9F347940FC3ECEADC09FD1855D141D5CDD5D3FFC2FC70936C3B4E7`)
```lean
/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  05_independent_tribunal/P2TribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  1. `#print axioms` audit across all exported `PO-C1-02` theorems and foundational lemmas.
  2. Executable CLI test runner (`p2_tribunal_runner`) supporting both human-readable
     table verification and `--json` vector serialization for the independent Python 3.11
     differential oracle (`differential_oracle_p2.py`).
-/
import P2FormalSpec
import P2DetachedChecker
import P2Counterexamples
import P2ProofObligations

/-! ### 1. Compile-Time Kernel Axiom Footprint Audit (`#print axioms`) -/

#print axioms BrocaOmega.P2.ProofObligations.PO_C1_02_GrammarAcyclicRank
#print axioms BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplaySoundness
#print axioms BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplayCompleteness
#print axioms BrocaOmega.P2.ProofObligations.PO_C1_02_CounterexampleSuiteVerified
#print axioms BrocaOmega.P2.validGrammarDerivation_yield_eq
#print axioms BrocaOmega.P2.validGrammarDerivation_implies_locusTargetBound
#print axioms BrocaOmega.P2.spanMatches_concat
#print axioms BrocaOmega.P2.spanMatches_full_eq
#print axioms BrocaOmega.P2.checkMultisetEqBool_iff
#print axioms BrocaOmega.P2.checkNoDupOblIdsBool_iff

namespace BrocaOmega.P2.Tribunal

open BrocaOmega.P2
open BrocaOmega.P2.Counterexamples

/-! ### 2. Deterministic Diagnostic Tag & Minimal Pure JSON Serializer -/

def diagCategoryTag : CEGESReplayDiag → String
  | .forgedOrTrapRuleId _ _            => "forgedOrTrapRuleId"
  | .nontermCatMismatch _ _ _          => "nontermCatMismatch"
  | .segmentArityOrKindMismatch _      => "segmentArityOrKindMismatch"
  | .fixedTerminalMismatch _ _ _       => "fixedTerminalMismatch"
  | .invalidSlotSortOrRole _           => "invalidSlotSortOrRole"
  | .invalidSlotLexemeOrKeywordLeak _ _ _ => "invalidSlotLexemeOrKeywordLeak"
  | .spanStartDiscontinuity _ _ _      => "spanStartDiscontinuity"
  | .spanSliceMismatch _ _             => "spanSliceMismatch"
  | .cursorOutOfBounds _ _ _           => "cursorOutOfBounds"
  | .nodeEndSpanMismatch _ _ _         => "nodeEndSpanMismatch"
  | .sideConditionFailed _ _           => "sideConditionFailed"
  | .locusOrTargetOblMismatch _ _ _    => "locusOrTargetOblMismatch"
  | .rootSpanNotFullText _ _           => "rootSpanNotFullText"
  | .inputOblIdsNotUnique              => "inputOblIdsNotUnique"
  | .duplicateOblIdDischarged          => "duplicateOblIdDischarged"
  | .obligationMultisetMismatch        => "obligationMultisetMismatch"

def escapeJsonChars : List Char → List Char
  | [] => []
  | '"' :: cs  => '\\' :: '"' :: escapeJsonChars cs
  | '\\' :: cs => '\\' :: '\\' :: escapeJsonChars cs
  | '\n' :: cs => '\\' :: 'n' :: escapeJsonChars cs
  | c :: cs    => c :: escapeJsonChars cs

def jStr (s : String) : String :=
  "\"" ++ String.ofList (escapeJsonChars s.toList) ++ "\""

def jBool (b : Bool) : String := if b then "true" else "false"

def jList (items : List String) : String :=
  "[" ++ String.intercalate "," items ++ "]"

def locusToStr : ClauseLocus → String
  | .clause1 => "clause1"
  | .clause2 => "clause2"

def oblKindToStr : OblKind → String
  | .scopeAnchor          => "scopeAnchor"
  | .descIncidence        => "descIncidence"
  | .descDistribution     => "descDistribution"
  | .assocMetricDir       => "assocMetricDir"
  | .temporalPrecedence   => "temporalPrecedence"
  | .absRiskDiff          => "absRiskDiff"
  | .identAssumption      => "identAssumption"
  | .intervDirectional    => "intervDirectional"
  | .intervNeutral        => "intervNeutral"
  | .metaNotStatSig       => "metaNotStatSig"
  | .metaEquivMargins     => "metaEquivMargins"
  | .metaNonEstabNeg      => "metaNonEstabNeg"
  | .metaUnresolvedPolar  => "metaUnresolvedPolar"
  | .quantZeroNeg         => "quantZeroNeg"
  | .quantProperPart      => "quantProperPart"
  | .quantExistential     => "quantExistential"
  | .covariateAdjustment  => "covariateAdjustment"
  | .contrastiveBoundary  => "contrastiveBoundary"

def slotSortToStr : SlotSort → String
  | .cohortSpec       => "cohortSpec"
  | .designNoun       => "designNoun"
  | .followUpWindow   => "followUpWindow"
  | .eventTerm        => "eventTerm"
  | .measureTerm      => "measureTerm"
  | .expLevel         => "expLevel"
  | .outTerm          => "outTerm"
  | .sourceId         => "sourceId"
  | .identAssump      => "identAssump"
  | .subgroupPlural   => "subgroupPlural"
  | .subgroupSingular => "subgroupSingular"
  | .covariateList    => "covariateList"
  | .assocDir         => "assocDir"
  | .ratioMetric      => "ratioMetric"
  | .intervDirVerb    => "intervDirVerb"
  | .intervVerbPres   => "intervVerbPres"
  | .numericLit       => "numericLit"

def slotRoleToStr : SlotRole → String
  | .cohort        => "cohort"
  | .design        => "design"
  | .window        => "window"
  | .eventA        => "eventA"
  | .eventB        => "eventB"
  | .measure       => "measure"
  | .activeExp     => "activeExp"
  | .refExp        => "refExp"
  | .outcome       => "outcome"
  | .source        => "source"
  | .assumption    => "assumption"
  | .subgroup      => "subgroup"
  | .covariates    => "covariates"
  | .direction     => "direction"
  | .metric1       => "metric1"
  | .metric2       => "metric2"
  | .verb          => "verb"
  | .numK          => "numK"
  | .numN          => "numN"
  | .numPct        => "numPct"
  | .numEst        => "numEst"
  | .numDisp1      => "numDisp1"
  | .numDisp2      => "numDisp2"
  | .numCILevel    => "numCILevel"
  | .numCILow      => "numCILow"
  | .numCIHigh     => "numCIHigh"
  | .numPVal       => "numPVal"
  | .numAlpha      => "numAlpha"
  | .numMarginLow  => "numMarginLow"
  | .numMarginHigh => "numMarginHigh"

def spanToJson (sp : CodepointSpan) : String :=
  "{\"startCp\":" ++ toString sp.startCp ++ ",\"endCp\":" ++ toString sp.endCp ++ "}"

def oblTokToJson (o : ObligationToken) : String :=
  "{\"oblId\":" ++ toString o.oblId ++
  ",\"locus\":" ++ jStr (locusToStr o.spec.locus) ++
  ",\"kind\":" ++ jStr (oblKindToStr o.spec.kind) ++
  ",\"target\":" ++ jStr o.spec.target ++ "}"

mutual
  def segArgToJson : UntrustedSegArg → String
    | .litSpan txt sp =>
      "{\"argKind\":\"litSpan\",\"claimedText\":" ++ jStr txt ++
      ",\"span\":" ++ spanToJson sp ++ "}"
    | .slotLeaf tok =>
      "{\"argKind\":\"slotLeaf\",\"sort\":" ++ jStr (slotSortToStr tok.sort) ++
      ",\"role\":" ++ jStr (slotRoleToStr tok.role) ++
      ",\"entityId\":" ++ jStr tok.entityId ++
      ",\"lexeme\":" ++ jStr tok.lexeme ++
      ",\"span\":" ++ spanToJson tok.span ++ "}"
    | .childNode sub =>
      "{\"argKind\":\"childNode\",\"sub\":" ++ certToJson sub ++ "}"

  def certToJson : UntrustedDerivCert → String
    | .mkNode nid rc sp claimed args =>
      "{\"nodeId\":" ++ toString nid ++
      ",\"rawRuleCode\":" ++ toString rc ++
      ",\"span\":" ++ spanToJson sp ++
      ",\"claimedDischarged\":" ++ jList (claimed.map oblTokToJson) ++
      ",\"segArgs\":" ++ jList (args.map segArgToJson) ++ "}"
end

def envToJson (e : ScopeEnv) : String :=
  let qMode := match e.quoteIsolation with
    | .sentenceAtomic => "sentenceAtomic"
    | .discourseBound => "discourseBound"
  "{\"cohortId\":" ++ jStr e.cohortId ++
  ",\"expectedDesignHead\":" ++ jStr e.expectedDesignHead ++
  ",\"quoteIsolation\":" ++ jStr qMode ++ "}"

def testCaseToJson (tc : P2TestCase) : String :=
  let out := replayDerivation tc.env tc.surfaceText tc.deltaIn tc.cert
  let dTag := match out.diag? with
    | none => "NONE"
    | some d => diagCategoryTag d
  "{\"caseId\":" ++ jStr tc.caseId ++
  ",\"pairGroup\":" ++ jStr tc.pairGroup ++
  ",\"isPositive\":" ++ jBool tc.isPositive ++
  ",\"env\":" ++ envToJson tc.env ++
  ",\"surfaceText\":" ++ jStr tc.surfaceText ++
  ",\"deltaIn\":" ++ jList (tc.deltaIn.map oblTokToJson) ++
  ",\"cert\":" ++ certToJson tc.cert ++
  ",\"leanAccepted\":" ++ jBool out.isAccepted ++
  ",\"leanDiagTag\":" ++ jStr dTag ++ "}"

end BrocaOmega.P2.Tribunal

def main (args : List String) : IO UInt32 := do
  let cases := BrocaOmega.P2.Counterexamples.allP2Cases
  if args.contains "--json" then
    IO.println (BrocaOmega.P2.Tribunal.jList (cases.map BrocaOmega.P2.Tribunal.testCaseToJson))
    return 0
  else
    IO.println "=========================================================================="
    IO.println "BROCA-NATIVE OMEGA — AUTH-C1-P2 DETACHED DERIVATION REPLAY VERIFICATION"
    IO.println "Target Obligation : PO-C1-02 (Derivation Replay Soundness & Completeness)"
    IO.println "Toolchain         : Lean 4.33.1 Core (Init only, 0 external deps, 0 sorry)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for tc in cases do
      let ok := tc.runCheck
      let out := BrocaOmega.P2.replayDerivation tc.env tc.surfaceText tc.deltaIn tc.cert
      let statusStr := if ok then "PASS" else "FAIL"
      let outcomeStr := match out with
        | .accepted w =>
          s!"ACCEPTED (reconstructYield == Y: {BrocaOmega.P2.reconstructYield w.cert == tc.surfaceText})"
        | .rejected d =>
          s!"REJECTED ({BrocaOmega.P2.Tribunal.diagCategoryTag d})"
      IO.println s!"[{statusStr}] {tc.caseId} ({tc.pairGroup}) => {outcomeStr}"
      if ok then
        passCount := passCount + 1
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"SUMMARY: {passCount} / {cases.length} symmetric (PC, CE) vectors verified."
    IO.println "P1 External Replay Status : HELD (PO_C1_04A_FINAL_EXTERNAL_ADMISSION_HELD)"
    IO.println "P1-C / P3..P5 / Pneuma-S3 : NOT_AUTHORIZED"
    IO.println "=========================================================================="
    if passCount == cases.length then
      return 0
    else
      return 1
```

### 5.14 `05_independent_tribunal/differential_oracle_p2.py` (`SHA-256: 0D9423FAD53DF981BC623ED6E39E5163ACBFBCE55ACF084339B6B16AE8AFF8C5`)
```python
#!/usr/bin/env python3
"""
BROCA-NATIVE OMEGA — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
05_independent_tribunal/differential_oracle_p2.py

Clean-room Python 3.11 differential oracle for `AUTH-C1-P2`:
1. Independently implements `G-01` ~ `G-16` frozen rule table, rank acyclicity,
   contiguous codepoint span verification, syncategorematic keyword barrier,
   `LocusTargetBound` node-local obligation checking, and `collections.Counter`
   free-commutative-monoid multiset conservation.
2. Executes `p2_tribunal_runner.exe --json` and checks 100% exact decision AND
   diagnostic-tag parity on all 24 `(PC, CE)` vectors.
3. Runs 240 deterministic adversarial fuzz mutations (`seed = 20261122`) over
   positive certificates and verifies 0 false acceptances.
"""

from __future__ import annotations

import copy
import json
import pathlib
import random
import subprocess
import sys
from collections import Counter
from typing import Any

FORBIDDEN_DELIMITERS = [
    ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same",
]

CAT_RANK = {
    "embeddedCausal": 0,
    "assocCore": 1,
    "metaNonEstabCore": 1,
    "atomicCore": 2,
    "scopedInitial": 3,
    "scopedRepeat": 3,
    "scopedAssoc": 3,
    "scopedContrastMeta": 3,
    "documentRoot": 4,
}


def is_printable_ascii(s: str) -> bool:
    return len(s) > 0 and all(0x20 <= ord(c) <= 0x7E for c in s)


def is_valid_numeric_surface(s: str) -> bool:
    if not s:
        return False
    if s.startswith("-0"):
        rest = s[2:]
        if all(c in ("0", ".") for c in rest):
            return False
        return all(c.isdigit() or c == "." for c in rest)
    if s.startswith("-"):
        if len(s) < 2 or not s[1].isdigit():
            return False
        return all(c.isdigit() or c == "." for c in s[2:])
    return s[0].isdigit() and all(c.isdigit() or c == "." for c in s[1:])


def is_valid_slot_lexeme(sort_name: str, lex: str) -> bool:
    if not is_printable_ascii(lex):
        return False
    if sort_name == "assocDir":
        return lex in ("positively", "inversely")
    if sort_name == "ratioMetric":
        return lex in ("risk ratio", "odds ratio", "hazard ratio")
    if sort_name == "intervDirVerb":
        return lex in ("increase", "reduce")
    if sort_name == "intervVerbPres":
        return lex in ("causes", "increases", "reduces")
    if sort_name == "numericLit":
        return is_valid_numeric_surface(lex)
    return all(bad not in lex for bad in FORBIDDEN_DELIMITERS)


def lookup_role(slots: list[tuple[str, str]], role: str) -> str:
    for r, v in slots:
        if r == role:
            return v
    return ""


def get_rule_spec(code: int) -> dict[str, Any] | None:
    """Clean-room frozen G-01 ~ G-16 rule table."""
    table: dict[int, dict[str, Any]] = {
        1: {
            "name": "DocSingle",
            "lhs": "documentRoot",
            "segs": [("child", "scopedInitial", "clause1"), ("lit", ".")],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        150: {
            "name": "G15_DocConjAtomic",
            "lhs": "documentRoot",
            "segs": [
                ("child", "scopedInitial", "clause1"),
                ("lit", ". "),
                ("child", "scopedInitial", "clause2"),
                ("lit", "."),
            ],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: (
                len(ch) == 2
                and env["quoteIsolation"] == "sentenceAtomic"
                and ch[0].get("cohort") == env["cohortId"]
                and ch[1].get("cohort") == env["cohortId"]
            ),
            "sum": lambda s, ch: {},
        },
        151: {
            "name": "G15_DocConjDiscourse",
            "lhs": "documentRoot",
            "segs": [
                ("child", "scopedInitial", "clause1"),
                ("lit", ". "),
                ("child", "scopedRepeat", "clause2"),
                ("lit", "."),
            ],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: (
                len(ch) == 2
                and env["quoteIsolation"] == "discourseBound"
                and ch[0].get("cohort") == env["cohortId"]
                and ch[1].get("design") == env["expectedDesignHead"]
            ),
            "sum": lambda s, ch: {},
        },
        160: {
            "name": "G16_DocContrastive",
            "lhs": "documentRoot",
            "segs": [
                ("child", "scopedAssoc", "clause1"),
                ("lit", "; however, "),
                ("child", "scopedContrastMeta", "clause2"),
                ("lit", "."),
            ],
            "obls": lambda loc, s, ch: (
                [
                    {
                        "locus": "clause2",
                        "kind": "contrastiveBoundary",
                        "target": (
                            f"{ch[0]['expOut'][0]}:{ch[0]['expOut'][1]}"
                            if ch[0].get("expOut") is not None
                            else ""
                        ),
                    }
                ]
                if len(ch) == 2
                else []
            ),
            "side": lambda env, s, ch: (
                len(ch) == 2
                and ch[0].get("cohort") == env["cohortId"]
                and ch[1].get("design") == env["expectedDesignHead"]
                and ch[0].get("expOut") is not None
                and ch[0].get("expOut") == ch[1].get("expOut")
            ),
            "sum": lambda s, ch: {},
        },
        201: {
            "name": "ScopedInitial",
            "lhs": "scopedInitial",
            "segs": [("lit", "In "), ("slot", "cohortSpec", "cohort"), ("lit", ", "), ("child", "atomicCore", None)],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "scopeAnchor", "target": lookup_role(s, "cohort")}],
            "side": lambda env, s, ch: lookup_role(s, "cohort") == env["cohortId"],
            "sum": lambda s, ch: {"cohort": lookup_role(s, "cohort"), "expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        202: {
            "name": "ScopedRepeatDiscourse",
            "lhs": "scopedRepeat",
            "segs": [("lit", "Within this same "), ("slot", "designNoun", "design"), ("lit", ", "), ("child", "atomicCore", None)],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "scopeAnchor", "target": "resolve:" + lookup_role(s, "design")}],
            "side": lambda env, s, ch: lookup_role(s, "design") == env["expectedDesignHead"],
            "sum": lambda s, ch: {"design": lookup_role(s, "design"), "expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        203: {
            "name": "ScopedAssoc",
            "lhs": "scopedAssoc",
            "segs": [("lit", "In "), ("slot", "cohortSpec", "cohort"), ("lit", ", "), ("child", "assocCore", None)],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "scopeAnchor", "target": lookup_role(s, "cohort")}],
            "side": lambda env, s, ch: lookup_role(s, "cohort") == env["cohortId"],
            "sum": lambda s, ch: {"cohort": lookup_role(s, "cohort"), "expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        204: {
            "name": "ScopedContrastMeta",
            "lhs": "scopedContrastMeta",
            "segs": [("lit", "within this same "), ("slot", "designNoun", "design"), ("lit", ", "), ("child", "metaNonEstabCore", None)],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "scopeAnchor", "target": "resolve:" + lookup_role(s, "design")}],
            "side": lambda env, s, ch: lookup_role(s, "design") == env["expectedDesignHead"],
            "sum": lambda s, ch: {"design": lookup_role(s, "design"), "expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        210: {
            "name": "LiftAssocToAtomic",
            "lhs": "atomicCore",
            "segs": [("child", "assocCore", None)],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: ch[0] if len(ch) == 1 else {},
        },
        211: {
            "name": "LiftMetaToAtomic",
            "lhs": "atomicCore",
            "segs": [("child", "metaNonEstabCore", None)],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: ch[0] if len(ch) == 1 else {},
        },
        301: {
            "name": "EmbeddedCausal",
            "lhs": "embeddedCausal",
            "segs": [("slot", "expLevel", "activeExp"), ("lit", " "), ("slot", "intervVerbPres", "verb"), ("lit", " "), ("slot", "outTerm", "outcome")],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {
                "expOut": (lookup_role(s, "activeExp"), lookup_role(s, "outcome")),
                "embKey": f"{lookup_role(s, 'activeExp')}:{lookup_role(s, 'verb')}:{lookup_role(s, 'outcome')}",
            },
        },
        10: {
            "name": "G01_DescIncidence",
            "lhs": "atomicCore",
            "segs": [
                ("lit", "over "), ("slot", "followUpWindow", "window"),
                ("lit", ", the cumulative incidence of "), ("slot", "eventTerm", "eventA"),
                ("lit", " was "), ("slot", "numericLit", "numK"),
                ("lit", " of "), ("slot", "numericLit", "numN"),
                ("lit", " patients ("), ("slot", "numericLit", "numPct"), ("lit", "%)"),
            ],
            "obls": lambda loc, s, ch: [{
                "locus": loc, "kind": "descIncidence",
                "target": f"{lookup_role(s, 'window')}:{lookup_role(s, 'eventA')}:{lookup_role(s, 'numK')}/{lookup_role(s, 'numN')}={lookup_role(s, 'numPct')}",
            }],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        20: {
            "name": "G02a_DescMeanSD",
            "lhs": "atomicCore",
            "segs": [
                ("lit", "the mean "), ("slot", "measureTerm", "measure"),
                ("lit", " was "), ("slot", "numericLit", "numEst"),
                ("lit", " (SD "), ("slot", "numericLit", "numDisp1"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [{
                "locus": loc, "kind": "descDistribution",
                "target": f"mean_sd:{lookup_role(s, 'measure')}:{lookup_role(s, 'numEst')}:{lookup_role(s, 'numDisp1')}",
            }],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        30: {
            "name": "G03_AssocUnadj",
            "lhs": "assocCore",
            "segs": [
                ("lit", "comparing "), ("slot", "expLevel", "activeExp"),
                ("lit", " versus "), ("slot", "expLevel", "refExp"),
                ("lit", " was "), ("slot", "assocDir", "direction"),
                ("lit", " associated with "), ("slot", "outTerm", "outcome"),
                ("lit", " ("), ("slot", "ratioMetric", "metric1"),
                ("lit", " = "), ("slot", "numericLit", "numEst"),
                ("lit", ", "), ("slot", "numericLit", "numCILevel"),
                ("lit", "% CI "), ("slot", "numericLit", "numCILow"),
                ("lit", " to "), ("slot", "numericLit", "numCIHigh"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [{
                "locus": loc, "kind": "assocMetricDir",
                "target": f"{lookup_role(s, 'metric1')}:{lookup_role(s, 'direction')}:{lookup_role(s, 'activeExp')}:{lookup_role(s, 'refExp')}:{lookup_role(s, 'outcome')}",
            }],
            "side": lambda env, s, ch: lookup_role(s, "activeExp") != lookup_role(s, "refExp"),
            "sum": lambda s, ch: {"expOut": (lookup_role(s, "activeExp"), lookup_role(s, "outcome"))},
        },
        40: {
            "name": "G04_AssocTemp",
            "lhs": "assocCore",
            "segs": [
                ("slot", "eventTerm", "eventA"), ("lit", " preceded "), ("slot", "eventTerm", "eventB"),
                ("lit", ", and comparing "), ("slot", "expLevel", "activeExp"),
                ("lit", " versus "), ("slot", "expLevel", "refExp"),
                ("lit", " was "), ("slot", "assocDir", "direction"),
                ("lit", " associated with "), ("slot", "outTerm", "outcome"),
                ("lit", " ("), ("slot", "ratioMetric", "metric1"),
                ("lit", " = "), ("slot", "numericLit", "numEst"),
                ("lit", ", "), ("slot", "numericLit", "numCILevel"),
                ("lit", "% CI "), ("slot", "numericLit", "numCILow"),
                ("lit", " to "), ("slot", "numericLit", "numCIHigh"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [
                {"locus": loc, "kind": "temporalPrecedence", "target": f"{lookup_role(s, 'eventA')}<{lookup_role(s, 'eventB')}"},
                {"locus": loc, "kind": "assocMetricDir", "target": f"{lookup_role(s, 'metric1')}:{lookup_role(s, 'direction')}:{lookup_role(s, 'activeExp')}:{lookup_role(s, 'refExp')}:{lookup_role(s, 'outcome')}"},
            ],
            "side": lambda env, s, ch: lookup_role(s, "eventA") != lookup_role(s, "eventB") and lookup_role(s, "activeExp") != lookup_role(s, "refExp"),
            "sum": lambda s, ch: {"expOut": (lookup_role(s, "activeExp"), lookup_role(s, "outcome"))},
        },
        60: {
            "name": "G06a_IntervDirectional",
            "lhs": "atomicCore",
            "segs": [
                ("lit", "under "), ("slot", "identAssump", "assumption"),
                ("lit", ", comparing "), ("slot", "expLevel", "activeExp"),
                ("lit", " versus "), ("slot", "expLevel", "refExp"),
                ("lit", " was estimated to "), ("slot", "intervDirVerb", "verb"),
                ("lit", " "), ("slot", "outTerm", "outcome"),
                ("lit", " ("), ("slot", "ratioMetric", "metric1"),
                ("lit", " = "), ("slot", "numericLit", "numEst"),
                ("lit", ", "), ("slot", "numericLit", "numCILevel"),
                ("lit", "% CI "), ("slot", "numericLit", "numCILow"),
                ("lit", " to "), ("slot", "numericLit", "numCIHigh"),
                ("lit", ", p = "), ("slot", "numericLit", "numPVal"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [
                {"locus": loc, "kind": "identAssumption", "target": lookup_role(s, "assumption")},
                {"locus": loc, "kind": "intervDirectional", "target": f"{lookup_role(s, 'metric1')}:{lookup_role(s, 'verb')}:{lookup_role(s, 'activeExp')}:{lookup_role(s, 'refExp')}:{lookup_role(s, 'outcome')}"},
            ],
            "side": lambda env, s, ch: lookup_role(s, "activeExp") != lookup_role(s, "refExp"),
            "sum": lambda s, ch: {},
        },
        90: {
            "name": "G09_MetaNonEstab",
            "lhs": "metaNonEstabCore",
            "segs": [("lit", "the analysis of "), ("slot", "sourceId", "source"), ("lit", " did not establish that "), ("child", "embeddedCausal", None)],
            "obls": lambda loc, s, ch: [{
                "locus": loc, "kind": "metaNonEstabNeg",
                "target": f"{lookup_role(s, 'source')}:{ch[0].get('embKey', '') if len(ch) == 1 else ''}",
            }],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {"expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        110: {
            "name": "G11_QuantZero",
            "lhs": "atomicCore",
            "segs": [("lit", "no "), ("slot", "subgroupPlural", "subgroup"), ("lit", " patients developed "), ("slot", "eventTerm", "eventA")],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "quantZeroNeg", "target": f"{lookup_role(s, 'subgroup')}:{lookup_role(s, 'eventA')}"}],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        120: {
            "name": "G12_QuantProperPart",
            "lhs": "atomicCore",
            "segs": [("lit", "some, but not all, "), ("slot", "subgroupPlural", "subgroup"), ("lit", " patients developed "), ("slot", "eventTerm", "eventA")],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "quantProperPart", "target": f"{lookup_role(s, 'subgroup')}:{lookup_role(s, 'eventA')}"}],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        130: {
            "name": "G13_QuantAtLeastOne",
            "lhs": "atomicCore",
            "segs": [("lit", "at least one "), ("slot", "subgroupSingular", "subgroup"), ("lit", " patient developed "), ("slot", "eventTerm", "eventA")],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "quantExistential", "target": f"{lookup_role(s, 'subgroup')}:{lookup_role(s, 'eventA')}"}],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        140: {
            "name": "G14_AssocAdj",
            "lhs": "assocCore",
            "segs": [
                ("lit", "after adjustment for "), ("slot", "covariateList", "covariates"),
                ("lit", ", comparing "), ("slot", "expLevel", "activeExp"),
                ("lit", " versus "), ("slot", "expLevel", "refExp"),
                ("lit", " was "), ("slot", "assocDir", "direction"),
                ("lit", " associated with "), ("slot", "outTerm", "outcome"),
                ("lit", " ("), ("slot", "ratioMetric", "metric1"),
                ("lit", " = "), ("slot", "numericLit", "numEst"),
                ("lit", ", "), ("slot", "numericLit", "numCILevel"),
                ("lit", "% CI "), ("slot", "numericLit", "numCILow"),
                ("lit", " to "), ("slot", "numericLit", "numCIHigh"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [
                {"locus": loc, "kind": "covariateAdjustment", "target": lookup_role(s, "covariates")},
                {"locus": loc, "kind": "assocMetricDir", "target": f"{lookup_role(s, 'metric1')}:{lookup_role(s, 'direction')}:{lookup_role(s, 'activeExp')}:{lookup_role(s, 'refExp')}:{lookup_role(s, 'outcome')}"},
            ],
            "side": lambda env, s, ch: lookup_role(s, "activeExp") != lookup_role(s, "refExp"),
            "sum": lambda s, ch: {"expOut": (lookup_role(s, "activeExp"), lookup_role(s, "outcome"))},
        },
    }
    return table.get(code)


def check_span(y: str, sp: dict[str, int], seg: str) -> bool:
    s, e = sp["startCp"], sp["endCp"]
    return e == s + len(seg) and e <= len(y) and y[s:e] == seg


def py_reconstruct_yield(cert: dict[str, Any]) -> str:
    parts: list[str] = []
    for arg in cert["segArgs"]:
        if arg["argKind"] == "litSpan":
            parts.append(arg["claimedText"])
        elif arg["argKind"] == "slotLeaf":
            parts.append(arg["lexeme"])
        elif arg["argKind"] == "childNode":
            parts.append(py_reconstruct_yield(arg["sub"]))
    return "".join(parts)


def py_collect_obls(cert: dict[str, Any]) -> list[dict[str, Any]]:
    out = list(cert["claimedDischarged"])
    for arg in cert["segArgs"]:
        if arg["argKind"] == "childNode":
            out.extend(py_collect_obls(arg["sub"]))
    return out


def py_replay_segs(
    env: dict[str, Any],
    y: str,
    loc: str,
    cursor: int,
    segs: list[tuple[Any, ...]],
    args: list[dict[str, Any]],
) -> tuple[bool, str, tuple[int, list[tuple[str, str]], list[dict[str, Any]]] | None]:
    if not segs and not args:
        if cursor <= len(y):
            return True, "NONE", (cursor, [], [])
        return False, "cursorOutOfBounds", None
    if not segs or not args:
        return False, "segmentArityOrKindMismatch", None

    seg, rest_segs = segs[0], segs[1:]
    arg, rest_args = args[0], args[1:]

    if seg[0] == "lit" and arg["argKind"] == "litSpan":
        txt = seg[1]
        claimed = arg["claimedText"]
        sp = arg["span"]
        if claimed != txt:
            return False, "fixedTerminalMismatch", None
        if sp["startCp"] != cursor:
            return False, "spanStartDiscontinuity", None
        if not check_span(y, sp, claimed):
            return False, "spanSliceMismatch", None
        return py_replay_segs(env, y, loc, sp["endCp"], rest_segs, rest_args)

    if seg[0] == "slot" and arg["argKind"] == "slotLeaf":
        exp_sort, exp_role = seg[1], seg[2]
        if arg["sort"] != exp_sort or arg["role"] != exp_role:
            return False, "invalidSlotSortOrRole", None
        if not is_valid_slot_lexeme(exp_sort, arg["lexeme"]):
            return False, "invalidSlotLexemeOrKeywordLeak", None
        sp = arg["span"]
        if sp["startCp"] != cursor:
            return False, "spanStartDiscontinuity", None
        if not check_span(y, sp, arg["lexeme"]):
            return False, "spanSliceMismatch", None
        ok, tag, sub = py_replay_segs(env, y, loc, sp["endCp"], rest_segs, rest_args)
        if not ok or sub is None:
            return False, tag, None
        end_pos, rest_slots, sums = sub
        return True, "NONE", (end_pos, [(exp_role, arg["entityId"])] + rest_slots, sums)

    if seg[0] == "child" and arg["argKind"] == "childNode":
        cat, loc_override = seg[1], seg[2]
        sub_cert = arg["sub"]
        if sub_cert["span"]["startCp"] != cursor:
            return False, "spanStartDiscontinuity", None
        child_loc = loc_override if loc_override is not None else loc
        ok_c, tag_c, child_sum = py_replay_node(env, y, child_loc, cat, sub_cert)
        if not ok_c or child_sum is None:
            return False, tag_c, None
        ok_r, tag_r, sub = py_replay_segs(env, y, loc, sub_cert["span"]["endCp"], rest_segs, rest_args)
        if not ok_r or sub is None:
            return False, tag_r, None
        end_pos, slots, rest_sums = sub
        return True, "NONE", (end_pos, slots, [child_sum] + rest_sums)

    return False, "segmentArityOrKindMismatch", None


def py_replay_node(
    env: dict[str, Any],
    y: str,
    loc: str,
    expected_cat: str,
    cert: dict[str, Any],
) -> tuple[bool, str, dict[str, Any] | None]:
    rule = get_rule_spec(cert["rawRuleCode"])
    if rule is None:
        return False, "forgedOrTrapRuleId", None
    if rule["lhs"] != expected_cat:
        return False, "nontermCatMismatch", None
    # Verify rank acyclicity explicitly on rule definition
    for seg in rule["segs"]:
        if seg[0] == "child":
            assert CAT_RANK[seg[1]] < CAT_RANK[rule["lhs"]], "Rank acyclicity violated!"

    sp = cert["span"]
    ok, tag, seg_res = py_replay_segs(env, y, loc, sp["startCp"], rule["segs"], cert["segArgs"])
    if not ok or seg_res is None:
        return False, tag, None
    end_pos, slots, sums = seg_res
    if end_pos != sp["endCp"]:
        return False, "nodeEndSpanMismatch", None
    if not rule["side"](env, slots, sums):
        return False, "sideConditionFailed", None
    expected_specs = rule["obls"](loc, slots, sums)
    actual_specs = [
        {"locus": o["locus"], "kind": o["kind"], "target": o["target"]}
        for o in cert["claimedDischarged"]
    ]
    if actual_specs != expected_specs:
        return False, "locusOrTargetOblMismatch", None
    return True, "NONE", rule["sum"](slots, sums)


def obl_key(o: dict[str, Any]) -> tuple[int, str, str, str]:
    return (o["oblId"], o["locus"], o["kind"], o["target"])


def py_replay_derivation(
    env: dict[str, Any],
    y: str,
    delta_in: list[dict[str, Any]],
    cert: dict[str, Any],
) -> tuple[bool, str]:
    in_ids = [o["oblId"] for o in delta_in]
    if len(in_ids) != len(set(in_ids)):
        return False, "inputOblIdsNotUnique"
    if cert["span"] != {"startCp": 0, "endCp": len(y)}:
        return False, "rootSpanNotFullText"
    ok, tag, _ = py_replay_node(env, y, "clause1", "documentRoot", cert)
    if not ok:
        return False, tag
    claimed_all = py_collect_obls(cert)
    claimed_ids = [o["oblId"] for o in claimed_all]
    if len(claimed_ids) != len(set(claimed_ids)):
        return False, "duplicateOblIdDischarged"
    if Counter(obl_key(o) for o in claimed_all) != Counter(obl_key(o) for o in delta_in):
        return False, "obligationMultisetMismatch"
    return True, "NONE"


def run_adversarial_fuzz(positive_cases: list[dict[str, Any]], trials: int = 240) -> tuple[int, int]:
    rng = random.Random(20261122)
    rejected_count = 0
    for i in range(trials):
        base = copy.deepcopy(positive_cases[i % len(positive_cases)])
        env = base["env"]
        y = base["surfaceText"]
        delta = base["deltaIn"]
        cert = base["cert"]
        mode = i % 6
        if mode == 0:
            # Forge root or child rule code
            cert["rawRuleCode"] = rng.choice([901, 902, 903, 999, 777])
        elif mode == 1:
            # Mutate 1 character in surface text Y
            idx = rng.randrange(len(y))
            replacement = "X" if y[idx] != "X" else "Z"
            y = y[:idx] + replacement + y[idx + 1 :]
        elif mode == 2:
            # Shift root endCp or first child startCp
            cert["span"]["endCp"] += 1
        elif mode == 3:
            # Drop or add obligation in deltaIn (multiset violation)
            delta.append({"oblId": 99999 + i, "locus": "clause1", "kind": "quantZeroNeg", "target": "x:y"})
        elif mode == 4:
            # Swap locus on an obligation in both deltaIn and root/child
            if delta:
                delta[0]["locus"] = "clause2" if delta[0]["locus"] == "clause1" else "clause1"
        elif mode == 5:
            # Duplicate obligation ID in deltaIn
            if delta:
                delta.append(copy.deepcopy(delta[0]))

        ok, _ = py_replay_derivation(env, y, delta, cert)
        if not ok:
            rejected_count += 1
    return rejected_count, trials


def main() -> int:
    root_dir = pathlib.Path(__file__).resolve().parent.parent
    exe_path = root_dir / ".lake" / "build" / "bin" / "p2_tribunal_runner.exe"
    if not exe_path.exists():
        print(f"ERROR: Missing executable {exe_path}", file=sys.stderr)
        return 2

    proc = subprocess.run([str(exe_path), "--json"], capture_output=True, text=True, check=True)
    cases: list[dict[str, Any]] = json.loads(proc.stdout)

    print("==========================================================================")
    print("PYTHON 3.11 INDEPENDENT DIFFERENTIAL ORACLE — BROCA-NATIVE OMEGA P2")
    print(f"Loaded {len(cases)} serialized vectors from Lean p2_tribunal_runner.exe")
    print("==========================================================================")

    mismatches = 0
    positives: list[dict[str, Any]] = []
    for tc in cases:
        py_acc, py_tag = py_replay_derivation(tc["env"], tc["surfaceText"], tc["deltaIn"], tc["cert"])
        lean_acc = tc["leanAccepted"]
        lean_tag = tc["leanDiagTag"]
        yield_ok = (py_reconstruct_yield(tc["cert"]) == tc["surfaceText"]) if py_acc else True
        parity = (py_acc == lean_acc) and (py_tag == lean_tag) and yield_ok
        mark = "PARITY_OK" if parity else "MISMATCH"
        print(
            f"[{mark}] {tc['caseId']} | Lean=({lean_acc}, {lean_tag}) "
            f"| Python=({py_acc}, {py_tag})"
        )
        if not parity:
            mismatches += 1
        if tc["isPositive"]:
            positives.append(tc)

    rej_fuzz, total_fuzz = run_adversarial_fuzz(positives, trials=240)
    print("--------------------------------------------------------------------------")
    print(f"Suite Differential Parity : {len(cases) - mismatches} / {len(cases)} EXACT MATCH")
    print(f"Adversarial Fuzz Trials   : {rej_fuzz} / {total_fuzz} REJECTED (seed=20261122)")
    print("==========================================================================")
    if mismatches == 0 and rej_fuzz == total_fuzz:
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
```
