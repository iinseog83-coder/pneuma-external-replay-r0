#!/usr/bin/env python3
"""
PNEUMA-NATIVE OMEGA — AUTH-P3C-DIFFERENTIAL-R1 Standalone Bundle Integrity Verifier
Verifies:
  1. 100% SHA-256 parity for every file listed in MANIFEST.sha256
  2. 15/15 verbatim code/receipt block SHA-256 parity in PNEUMA_P3C_DIFFERENTIAL_R1_READONLY_TRIBUNAL_DOSSIER.md
  3. 14/14 verbatim code/receipt block SHA-256 parity in PNEUMA_P3C_PROVENANCE_R1_READONLY_TRIBUNAL_DOSSIER.md
"""
import hashlib
import re
import sys
from pathlib import Path


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def verify_dossier_blocks(dossier_path: Path, subpkg_root: Path, expected_count: int) -> None:
    raw = dossier_path.read_bytes()
    pat = re.compile(
        rb"### File \d+: `([^`]+)` \(SHA-256: `([0-9A-F]{64})`\)\r?\n````[^\r\n]*\r?\n(.*?)\r?\n````",
        re.DOTALL,
    )
    matches = pat.findall(raw)
    if len(matches) != expected_count:
        raise AssertionError(f"{dossier_path.name}: expected {expected_count} blocks, got {len(matches)}")
    for rel_b, decl_sha_b, body_b in matches:
        rel = rel_b.decode("utf-8")
        decl_sha = decl_sha_b.decode("utf-8")
        calc_sha = sha256_bytes(body_b.replace(b"\r\n", b"\n") + b"\n")
        disk_sha = sha256_bytes((subpkg_root / rel).read_bytes())
        if not (calc_sha == decl_sha == disk_sha):
            raise AssertionError(f"Mismatch on {rel}: block={calc_sha}, declared={decl_sha}, disk={disk_sha}")


def main() -> int:
    bundle_root = Path(__file__).resolve().parent
    sha_lines = [
        ln.strip()
        for ln in (bundle_root / "MANIFEST.sha256").read_text(encoding="utf-8").splitlines()
        if ln.strip()
    ]
    checked = 0
    for ln in sha_lines:
        exp_sha, rel_path = ln.split("  ", 1)
        fp = bundle_root / rel_path
        if not fp.exists():
            print(f"[FAIL] Missing file: {rel_path}")
            return 1
        actual_sha = sha256_bytes(fp.read_bytes())
        if actual_sha != exp_sha.upper():
            print(f"[FAIL] SHA-256 mismatch on {rel_path}: {actual_sha} != {exp_sha}")
            return 1
        checked += 1

    verify_dossier_blocks(
        bundle_root / "dossiers" / "PNEUMA_P3C_DIFFERENTIAL_R1_READONLY_TRIBUNAL_DOSSIER.md",
        bundle_root / "BROCA_NATIVE_OMEGA_GATE_C1" / "P3C_Differential_R1",
        15,
    )
    verify_dossier_blocks(
        bundle_root / "dossiers" / "PNEUMA_P3C_PROVENANCE_R1_READONLY_TRIBUNAL_DOSSIER.md",
        bundle_root / "BROCA_NATIVE_OMEGA_GATE_C1" / "P3C_Provenance_R1",
        14,
    )

    print(f"[PASS] MANIFEST.sha256 verified: {checked}/{checked} files byte-identical")
    print("[PASS] Differential R1 Dossier block parity verified: 15/15 blocks byte-identical")
    print("[PASS] Provenance R1 Dossier block parity verified: 14/14 blocks byte-identical")
    return 0


if __name__ == "__main__":
    sys.exit(main())
