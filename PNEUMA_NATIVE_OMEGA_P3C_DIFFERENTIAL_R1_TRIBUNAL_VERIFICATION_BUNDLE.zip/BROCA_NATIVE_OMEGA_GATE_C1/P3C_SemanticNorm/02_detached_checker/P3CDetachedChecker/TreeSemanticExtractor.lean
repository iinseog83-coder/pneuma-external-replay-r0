/-
  PNEUMA-NATIVE Ω — AUTH-C1-P3-C (`PO-C1-03`, `F-P3C-D02`, `F-P3C-D03`)
  02_detached_checker/P3CDetachedChecker/TreeSemanticExtractor.lean
  Pure Lean 4.33.1 Core (`Init` + read-only Legacy BROCA `P2`, `P3-A`, `P3-B`, zero `sorry`)

  Total, stratified parse-tree-to-meaning extractor (`extractRawMeaning`, `extractAllMeanings`):
    1. Maps all 34 `FrozenParseProd` rules of `G_parse` (`G-01`~`G-16` ∪ `T1`~`T5`) to `RawSemanticTerm`.
    2. Evaluates `T1`, `T2`, `T4` dual `readingAlt ∈ {1, 2}` readings independently (`F-P3C-D03`).
    3. Resolves discourse-bound anaphoric scope (`Within this same <design>,`) against `env.expectedDesignHead`
       and preserves distinct surface binders (`"x_init"` vs `"y_repeat"`) prior to canonical normalization.
    4. Fails explicitly with `ExtractionFailureDiag` on any malformed node, unsupported `readingAlt`,
       unresolved scope design/cohort, or mismatched contrastive anchor — NEVER conflating extraction
       failure with semantic ambiguity (`F-P3C-D02`)!
-/
import P3CFormalSpec

namespace PneumaOmega.P3C

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B

/-! ### 1. Explicit Semantic Extraction Failure Diagnostic (`F-P3C-D02`) -/

inductive ExtractionFailureDiag where
  | malformedParseNode       (prod : FrozenParseProd) (detail : String)
  | unsupportedReadingAlt    (prod : FrozenParseProd) (alt : Nat)
  | mismatchedScopeCohort    (foundCohort expectedCohort : String)
  | unresolvedAnaphoricScope (foundDesign expectedDesign : String)
  | invalidContrastiveAnchor (prod : FrozenParseProd)
  deriving DecidableEq, Repr

/-! ### 2. Stratified Non-Recursive Parse-Tree Accessors (Fast `UInt32` String Checks) -/

def collectParseSlots : List ConcreteParseArg → List (BNFSlotTag × String)
  | [] => []
  | .litTok _ _ :: rest => collectParseSlots rest
  | .slotTok _ tag eid _ _ :: rest => (tag, eid) :: collectParseSlots rest
  | .childSub _ :: rest => collectParseSlots rest

def collectParseChildren : List ConcreteParseArg → List ConcreteParseTree
  | [] => []
  | .litTok _ _ :: rest => collectParseChildren rest
  | .slotTok _ _ _ _ _ :: rest => collectParseChildren rest
  | .childSub sub :: rest => sub :: collectParseChildren rest

def requireSlot (prod : FrozenParseProd) (slots : List (BNFSlotTag × String))
    (tag : BNFSlotTag) : Except ExtractionFailureDiag String :=
  match slots.find? (fun p => p.1 == tag) with
  | some (_, val) => .ok val
  | none          => .error (.malformedParseNode prod "missing_required_slot")

def requireAltOne (prod : FrozenParseProd) (alt : Nat) : Except ExtractionFailureDiag Unit :=
  if alt == 1 then .ok () else .error (.unsupportedReadingAlt prod alt)

def requireZeroChildren (prod : FrozenParseProd) (ch : List ConcreteParseTree) :
    Except ExtractionFailureDiag Unit :=
  match ch with
  | [] => .ok ()
  | _  => .error (.malformedParseNode prod "unexpected_child_subtrees")

def requireOneChild (prod : FrozenParseProd) (ch : List ConcreteParseTree) :
    Except ExtractionFailureDiag ConcreteParseTree :=
  match ch with
  | [c] => .ok c
  | _   => .error (.malformedParseNode prod "expected_single_child_subtree")

def requireTwoChildren (prod : FrozenParseProd) (ch : List ConcreteParseTree) :
    Except ExtractionFailureDiag (ConcreteParseTree × ConcreteParseTree) :=
  match ch with
  | [c1, c2] => .ok (c1, c2)
  | _        => .error (.malformedParseNode prod "expected_two_child_subtrees")

/-! ### 3. Level-by-Level Compositional Semantic Extraction (`G-01`~`G-16`, `T1`~`T5`) -/

/-- Level 0: Embedded causal proposition `<activeExp> <verb> <outcome>` (`Env_EmbeddedCausal`). -/
def extractEmbeddedCausal : ConcreteParseTree → Except ExtractionFailureDiag (String × String × String)
  | .mkTree prod alt _ _ args => do
    if prod != .Env_EmbeddedCausal then
      .error (.malformedParseNode prod "expected_Env_EmbeddedCausal")
    else
      requireAltOne prod alt
      let slots := collectParseSlots args
      let ch    := collectParseChildren args
      requireZeroChildren prod ch
      let act ← requireSlot prod slots .activeExp
      let vb  ← requireSlot prod slots .verb
      let out ← requireSlot prod slots .outcome
      return (act, vb, out)

/--
  Level 1: Leaf Core Propositions (`assocCore`, `metaNonEstabCore`, `trapCore`, and non-lift `atomicCore`).
  Returns `(claim, presups, expOutAnchorOpt)`.
-/
def extractLeafCore : ConcreteParseTree →
    Except ExtractionFailureDiag (AtomicClaim × List PresupItem × Option (String × String))
  | .mkTree prod alt _ _ args => do
    let slots := collectParseSlots args
    let ch    := collectParseChildren args
    match prod with
    | .Gen_G01_DescIncidence =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let win ← requireSlot prod slots .window
      let ev  ← requireSlot prod slots .eventA
      let k   ← requireSlot prod slots .numK
      let n   ← requireSlot prod slots .numN
      let pct ← requireSlot prod slots .numPct
      return (.descIncidence win ev k n pct, [], none)

    | .Gen_G02a_DescMeanSD =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let m   ← requireSlot prod slots .measure
      let est ← requireSlot prod slots .numEst
      let d1  ← requireSlot prod slots .numDisp1
      return (.descDist .meanSD m est d1 none, [], none)

    | .Gen_G02b_DescMedianIQR =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let m   ← requireSlot prod slots .measure
      let est ← requireSlot prod slots .numEst
      let d1  ← requireSlot prod slots .numDisp1
      let d2  ← requireSlot prod slots .numDisp2
      return (.descDist .medianIQR m est d1 (some d2), [], none)

    | .Gen_G03_AssocUnadj =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let act  ← requireSlot prod slots .activeExp
      let ref  ← requireSlot prod slots .refExp
      let dir  ← requireSlot prod slots .direction
      let out  ← requireSlot prod slots .outcome
      let met  ← requireSlot prod slots .metric1
      let est  ← requireSlot prod slots .numEst
      let ciL  ← requireSlot prod slots .numCILevel
      let ciLo ← requireSlot prod slots .numCILow
      let ciHi ← requireSlot prod slots .numCIHigh
      return (.assocClaim met dir act ref out none none est ciL ciLo ciHi, [], some (act, out))

    | .Gen_G04_AssocTemp =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let evA  ← requireSlot prod slots .eventA
      let evB  ← requireSlot prod slots .eventB
      let act  ← requireSlot prod slots .activeExp
      let ref  ← requireSlot prod slots .refExp
      let dir  ← requireSlot prod slots .direction
      let out  ← requireSlot prod slots .outcome
      let met  ← requireSlot prod slots .metric1
      let est  ← requireSlot prod slots .numEst
      let ciL  ← requireSlot prod slots .numCILevel
      let ciLo ← requireSlot prod slots .numCILow
      let ciHi ← requireSlot prod slots .numCIHigh
      return (.assocClaim met dir act ref out none (some (evA, evB)) est ciL ciLo ciHi, [], some (act, out))

    | .Gen_G05_CompRD =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let out  ← requireSlot prod slots .outcome
      let act  ← requireSlot prod slots .activeExp
      let ref  ← requireSlot prod slots .refExp
      let est  ← requireSlot prod slots .numEst
      let ciL  ← requireSlot prod slots .numCILevel
      let ciLo ← requireSlot prod slots .numCILow
      let ciHi ← requireSlot prod slots .numCIHigh
      return (.compRD act ref out est ciL ciLo ciHi, [], none)

    | .Gen_G06a_IntervDirectional =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let assump ← requireSlot prod slots .assumption
      let act    ← requireSlot prod slots .activeExp
      let ref    ← requireSlot prod slots .refExp
      let vb     ← requireSlot prod slots .verb
      let out    ← requireSlot prod slots .outcome
      let met    ← requireSlot prod slots .metric1
      let est    ← requireSlot prod slots .numEst
      let ciL    ← requireSlot prod slots .numCILevel
      let ciLo   ← requireSlot prod slots .numCILow
      let ciHi   ← requireSlot prod slots .numCIHigh
      let pv     ← requireSlot prod slots .numPVal
      return (.intervClaim (.directional vb) assump met act ref out est ciL ciLo ciHi (some pv), [], none)

    | .Gen_G06b_IntervNeutral =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let assump ← requireSlot prod slots .assumption
      let met    ← requireSlot prod slots .metric1
      let out    ← requireSlot prod slots .outcome
      let act    ← requireSlot prod slots .activeExp
      let ref    ← requireSlot prod slots .refExp
      let est    ← requireSlot prod slots .numEst
      let ciL    ← requireSlot prod slots .numCILevel
      let ciLo   ← requireSlot prod slots .numCILow
      let ciHi   ← requireSlot prod slots .numCIHigh
      return (.intervClaim .neutralNullIncluded assump met act ref out est ciL ciLo ciHi none, [], none)

    | .Gen_G07_MetaNotStatSig =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let m1   ← requireSlot prod slots .metric1
      let act  ← requireSlot prod slots .activeExp
      let ref  ← requireSlot prod slots .refExp
      let out  ← requireSlot prod slots .outcome
      let m2   ← requireSlot prod slots .metric2
      let est  ← requireSlot prod slots .numEst
      let ciL  ← requireSlot prod slots .numCILevel
      let ciLo ← requireSlot prod slots .numCILow
      let ciHi ← requireSlot prod slots .numCIHigh
      let al   ← requireSlot prod slots .numAlpha
      if !eqStrBool m1 m2 then
        .error (.malformedParseNode prod "G07_metric1_metric2_mismatch")
      else
        return (.metaNotStatSig m1 act ref out est ciL ciLo ciHi al, [], none)

    | .Gen_G08_MetaEquiv =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let act  ← requireSlot prod slots .activeExp
      let ref  ← requireSlot prod slots .refExp
      let mLo  ← requireSlot prod slots .numMarginLow
      let mHi  ← requireSlot prod slots .numMarginHigh
      let out  ← requireSlot prod slots .outcome
      let met  ← requireSlot prod slots .metric1
      let est  ← requireSlot prod slots .numEst
      let ciL  ← requireSlot prod slots .numCILevel
      let ciLo ← requireSlot prod slots .numCILow
      let ciHi ← requireSlot prod slots .numCIHigh
      return (.metaEquiv met act ref out mLo mHi est ciL ciLo ciHi, [], none)

    | .Gen_G09_MetaNonEstab =>
      requireAltOne prod alt
      let embSub ← requireOneChild prod ch
      let src ← requireSlot prod slots .source
      let (act, vb, out) ← extractEmbeddedCausal embSub
      return (.metaNonEstab src act vb out, [], some (act, out))

    | .Gen_G10_MetaUnresolved =>
      requireAltOne prod alt
      let embSub ← requireOneChild prod ch
      let src ← requireSlot prod slots .source
      let (act, vb, out) ← extractEmbeddedCausal embSub
      return (.metaUnresolvedPolar src act vb out, [], none)

    | .Gen_G11_QuantZero =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let sg ← requireSlot prod slots .subgroup
      let ev ← requireSlot prod slots .eventA
      return (.quantClaim (.negExistential sg ev), [], none)

    | .Gen_G12_QuantProperPart =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let sg ← requireSlot prod slots .subgroup
      let ev ← requireSlot prod slots .eventA
      return (.quantClaim (.properPart sg ev), [], none)

    | .Gen_G13_QuantAtLeastOne =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let sg ← requireSlot prod slots .subgroup
      let ev ← requireSlot prod slots .eventA
      return (.quantClaim (.existentialPos sg ev), [], none)

    | .Gen_G14_AssocAdj =>
      requireAltOne prod alt
      requireZeroChildren prod ch
      let covs ← requireSlot prod slots .covariates
      let act  ← requireSlot prod slots .activeExp
      let ref  ← requireSlot prod slots .refExp
      let dir  ← requireSlot prod slots .direction
      let out  ← requireSlot prod slots .outcome
      let met  ← requireSlot prod slots .metric1
      let est  ← requireSlot prod slots .numEst
      let ciL  ← requireSlot prod slots .numCILevel
      let ciLo ← requireSlot prod slots .numCILow
      let ciHi ← requireSlot prod slots .numCIHigh
      return (.assocClaim met dir act ref out (some covs) none est ciL ciLo ciHi, [], some (act, out))

    -- Independent reading evaluation for `T1` (`alt = 1`: `∀¬`, `alt = 2`: `¬∀`, `F-P3C-D03`):
    | .Trap_T1_AllNot =>
      requireZeroChildren prod ch
      let sg ← requireSlot prod slots .subgroup
      let ev ← requireSlot prod slots .eventA
      if alt == 1 then
        return (.quantClaim (.universalNeg sg ev), [], none)
      else if alt == 2 then
        return (.quantClaim (.negUniversal sg ev), [], none)
      else
        .error (.unsupportedReadingAlt prod alt)

    -- Independent reading evaluation for `T2` (`alt = 1`: non-factive, `alt = 2`: factive presup, `F-P3C-D03`):
    | .Trap_T2_ConfirmThat =>
      let embSub ← requireOneChild prod ch
      let src ← requireSlot prod slots .source
      let (act, vb, out) ← extractEmbeddedCausal embSub
      if alt == 1 then
        return (.metaNonEstab src act vb out, [], some (act, out))
      else if alt == 2 then
        return (.metaNonEstab src act vb out, [.factiveCausal act vb out], some (act, out))
      else
        .error (.unsupportedReadingAlt prod alt)

    -- `T3` (`did not <V> why/how <S>`): single reading carrying unlicensed factive presupposition:
    | .Trap_T3_WhPresup =>
      requireAltOne prod alt
      let embSub ← requireOneChild prod ch
      let src ← requireSlot prod slots .source
      let epV ← requireSlot prod slots .verb
      let wh  ← requireSlot prod slots .whComp
      let (act, vb, out) ← extractEmbeddedCausal embSub
      return (.metaWhUnresolved src epV wh act vb out, [.factiveCausal act vb out], some (act, out))

    -- Independent reading evaluation for `T4` (`alt = 1`: `∀_gen`, `alt = 2`: `∃`, `F-P3C-D03`):
    | .Trap_T4_BarePlural =>
      requireZeroChildren prod ch
      let sg ← requireSlot prod slots .subgroup
      let ev ← requireSlot prod slots .eventA
      if alt == 1 then
        return (.quantClaim (.genericUniversalPos sg ev), [], none)
      else if alt == 2 then
        return (.quantClaim (.existentialPos sg ev), [], none)
      else
        .error (.unsupportedReadingAlt prod alt)

    | _ =>
      .error (.malformedParseNode prod "expected_leaf_core_production")

/-- Level 2: `atomicCore` / lifted `assocCore` / lifted `metaNonEstabCore` / `trapCore`. -/
def extractCoreClause : ConcreteParseTree →
    Except ExtractionFailureDiag (AtomicClaim × List PresupItem × Option (String × String))
  | t@(.mkTree prod alt _ _ args) => do
    match prod with
    | .Env_LiftAssoc =>
      requireAltOne prod alt
      let sub ← requireOneChild prod (collectParseChildren args)
      extractLeafCore sub
    | .Env_LiftMeta =>
      requireAltOne prod alt
      let sub ← requireOneChild prod (collectParseChildren args)
      extractLeafCore sub
    | _ =>
      extractLeafCore t

/--
  Level 3: Scoped Clauses (`Env_ScopedInitial`, `Env_ScopedRepeat`, `Env_ScopedAssoc`,
  `Env_ScopedContrastMeta`, `Env_ScopedTrap`).
  Resolves `"Within this same <design>,"` against `env.expectedDesignHead` to `.cohortBound env.cohortId`,
  while assigning distinct surface bound variables (`"x_init"` vs `"y_repeat"`) so bound-variable α-renaming
  is genuinely exercised between `G-15a` and `G-15b`!
-/
def extractScopedClause (env : ScopeEnv) : ConcreteParseTree →
    Except ExtractionFailureDiag (RawSemanticTerm × Option (String × String))
  | .mkTree prod alt _ _ args => do
    requireAltOne prod alt
    let slots := collectParseSlots args
    let sub   ← requireOneChild prod (collectParseChildren args)
    match prod with
    | .Env_ScopedInitial | .Env_ScopedAssoc | .Env_ScopedTrap =>
      let coh ← requireSlot prod slots .cohort
      if !eqStrBool coh env.cohortId then
        .error (.mismatchedScopeCohort coh env.cohortId)
      else
        let (claim, presups, anchorOpt) ← extractCoreClause sub
        return (.scopedAtom (.cohortBound coh) "x_init" claim presups, anchorOpt)

    | .Env_ScopedRepeat | .Env_ScopedContrastMeta =>
      let des ← requireSlot prod slots .design
      if !eqStrBool des env.expectedDesignHead then
        .error (.unresolvedAnaphoricScope des env.expectedDesignHead)
      else
        let (claim, presups, anchorOpt) ← extractCoreClause sub
        return (.scopedAtom (.cohortBound env.cohortId) "y_repeat" claim presups, anchorOpt)

    | _ =>
      .error (.malformedParseNode prod "expected_scoped_clause_production")

/--
  Level 4 (Root): **Total Document Semantic Extractor (`extractRawMeaning`)**.
  Maps any document `ConcreteParseTree` under `env : ScopeEnv` to either `.ok m` (`RawSemanticTerm`)
  or an explicit `.error diag` (`ExtractionFailureDiag`).
-/
def extractRawMeaning (env : ScopeEnv) : ConcreteParseTree → Except ExtractionFailureDiag RawSemanticTerm
  | .mkTree prod alt _ _ args => do
    requireAltOne prod alt
    let ch := collectParseChildren args
    match prod with
    | .Env_DocSingle | .Env_DocTrapScoped =>
      let c1 ← requireOneChild prod ch
      let (m1, _) ← extractScopedClause env c1
      return m1

    | .Gen_G15a_DocConjAtomic | .Gen_G15b_DocConjDiscourse =>
      let (c1, c2) ← requireTwoChildren prod ch
      let (m1, _) ← extractScopedClause env c1
      let (m2, _) ← extractScopedClause env c2
      return (.symConj m1 m2)

    | .Gen_G16_DocContrastive =>
      let (c1, c2) ← requireTwoChildren prod ch
      let (m1, anc1) ← extractScopedClause env c1
      let (m2, anc2) ← extractScopedClause env c2
      match anc1, anc2 with
      | some (e1, o1), some (e2, o2) =>
        if eqStrBool e1 e2 && eqStrBool o1 o2 then
          return (.contrastivePair m1 m2 e1 o1)
        else
          .error (.invalidContrastiveAnchor prod)
      | _, _ =>
        .error (.invalidContrastiveAnchor prod)

    | .Trap_T5_UnscopedDoc =>
      let coreSub ← requireOneChild prod ch
      let (claim, presups, _) ← extractCoreClause coreSub
      return (.scopedAtom .unrestrictedPop "u_unscoped" claim presups)

    | _ =>
      .error (.malformedParseNode prod "expected_document_root_production")

/-! ### 4. Forest-Wide Extraction (`extractAllMeanings`) & Soundness/Completeness Lemmas (`D02`) -/

/-- Failure witness pinpointing the exact parse tree `τ ∈ T` that failed semantic extraction. -/
structure ForestExtractionError where
  failedTree : ConcreteParseTree
  diag       : ExtractionFailureDiag
  deriving DecidableEq

/--
  Extracts raw meanings for ALL parse trees `τ ∈ T`, failing immediately with `ForestExtractionError`
  if ANY tree `τ ∈ T` cannot be mapped to a `RawSemanticTerm` (`F-P3C-D02`).
-/
def extractAllMeanings (env : ScopeEnv) :
    List ConcreteParseTree → Except ForestExtractionError (List (ConcreteParseTree × RawSemanticTerm))
  | [] => .ok []
  | t :: ts =>
    match extractRawMeaning env t with
    | .error d => .error { failedTree := t, diag := d }
    | .ok m    =>
      match extractAllMeanings env ts with
      | .error err => .error err
      | .ok rest   => .ok ((t, m) :: rest)

theorem extractAllMeanings_ok_iff (env : ScopeEnv) (T : List ConcreteParseTree)
    (pairs : List (ConcreteParseTree × RawSemanticTerm)) :
    extractAllMeanings env T = .ok pairs ↔
      pairs.map Prod.fst = T ∧ ∀ p ∈ pairs, extractRawMeaning env p.1 = .ok p.2 := by
  induction T generalizing pairs with
  | nil =>
    unfold extractAllMeanings
    constructor
    · intro h
      injection h with hp
      subst pairs
      simp
    · rintro ⟨hmap, _⟩
      cases pairs with
      | nil => rfl
      | cons _ _ => simp at hmap
  | cons t ts ih =>
    unfold extractAllMeanings
    cases ht : extractRawMeaning env t with
    | error d =>
      constructor
      · intro h; contradiction
      · rintro ⟨hmap, hall⟩
        cases pairs with
        | nil => simp at hmap
        | cons p rps =>
          simp at hmap
          rcases hmap with ⟨hp1, _⟩
          have hp := hall p (List.Mem.head rps)
          rw [hp1, ht] at hp
          contradiction
    | ok m =>
      cases hts : extractAllMeanings env ts with
      | error err =>
        constructor
        · intro h; contradiction
        · rintro ⟨hmap, hall⟩
          cases pairs with
          | nil => simp at hmap
          | cons p rps =>
            simp at hmap
            rcases hmap with ⟨hp1, hps⟩
            have hok_rps : extractAllMeanings env ts = .ok rps :=
              (ih rps).mpr ⟨hps, fun q hq => hall q (List.Mem.tail p hq)⟩
            rw [hts] at hok_rps
            contradiction
      | ok rps =>
        dsimp only
        have ⟨hmap_ts, hall_ts⟩ := (ih rps).mp hts
        constructor
        · intro h
          injection h with hp
          subst pairs
          refine ⟨by simp [hmap_ts], ?_⟩
          intro q hq
          rcases List.mem_cons.mp hq with rfl | hm
          · exact ht
          · exact hall_ts q hm
        · rintro ⟨hmap, hall⟩
          cases pairs with
          | nil => simp at hmap
          | cons p tailPairs =>
            simp at hmap
            rcases hmap with ⟨hp1, htail_map⟩
            rcases p with ⟨pt, pm⟩
            dsimp at hp1
            subst pt
            have hpm : extractRawMeaning env t = .ok pm := hall (t, pm) (List.Mem.head tailPairs)
            rw [ht] at hpm
            injection hpm with hm_eq
            subst pm
            have htail_ok : extractAllMeanings env ts = .ok tailPairs :=
              (ih tailPairs).mpr ⟨htail_map, fun q hq => hall q (List.Mem.tail (t, m) hq)⟩
            rw [hts] at htail_ok
            injection htail_ok with htp
            subst tailPairs
            rfl

theorem extractAllMeanings_nonempty {env : ScopeEnv} {T : List ConcreteParseTree}
    {pairs : List (ConcreteParseTree × RawSemanticTerm)}
    (hne : T ≠ []) (hok : extractAllMeanings env T = .ok pairs) :
    pairs ≠ [] := by
  have hmap := ((extractAllMeanings_ok_iff env T pairs).mp hok).1
  intro hp
  rw [hp] at hmap
  simp at hmap
  exact hne hmap

theorem extractAllMeanings_err_sound {env : ScopeEnv} {T : List ConcreteParseTree}
    {err : ForestExtractionError}
    (herr : extractAllMeanings env T = .error err) :
    err.failedTree ∈ T ∧ extractRawMeaning env err.failedTree = .error err.diag := by
  induction T with
  | nil =>
    simp [extractAllMeanings] at herr
  | cons t ts ih =>
    unfold extractAllMeanings at herr
    cases ht : extractRawMeaning env t with
    | error d =>
      rw [ht] at herr
      injection herr with heq
      subst err
      exact ⟨List.Mem.head ts, ht⟩
    | ok m =>
      rw [ht] at herr
      dsimp only at herr
      cases hts : extractAllMeanings env ts with
      | error e2 =>
        rw [hts] at herr
        injection herr with heq
        subst err
        have ⟨hmem, hfail⟩ := ih hts
        exact ⟨List.Mem.tail t hmem, hfail⟩
      | ok rps =>
        rw [hts] at herr
        contradiction

end PneumaOmega.P3C
