/-
  PNEUMA-NATIVE Ω — AUTH-C1-P3-C (`PO-C1-03`, `F-P3C-D02`, `F-P3C-D03`)
  02_detached_checker/P3CDetachedChecker/ConsensusAndTrapGate.lean
  Pure Lean 4.33.1 Core (`Init` + read-only Legacy BROCA `P2`, `P3-A`, `P3-B`, zero `sorry`)

  Implements:
    1. Direct consumption of frozen `BrocaOmega.P3B.parseAllBounded` (`F-P3C-D02`).
    2. Explicit 5-Way Outcome Type (`SemanticNormOutcome` — `F-P3C-D02`):
       - `consensus`                 : `T ≠ []`, ALL `τ ∈ T` extract cleanly, ALL normalize to identical `c`,
                                       AND `TrapPolicyPermitsForest T` holds!
       - `ambiguousReadings`         : Explicit dual-tree witness `(τ₁, τ₂, m₁, m₂)` with `normalizeMeaning m₁ ≠ normalizeMeaning m₂`
                                       (hence machine-checked `¬ SemEq m₁ m₂`!).
       - `semanticExtractionFailure` : Explicit tree `τ ∈ T` whose semantic extraction failed (NEVER conflated with ambiguity!).
       - `trapPolicyRejected`        : `UniversalConsensus` succeeded on `T`, yet `TrapPolicyPermitsForest T` rejected `T`
                                       (catches single-reading traps `T3` & `T5` and truncated 1-tree trap inputs!).
       - `upstreamRejected`          : `OutOfDomain(d)`, `ResourceOverflow(b)`, or `Enumerated []`.
    3. Strict Authority Separation (`F-P3C-D03`):
       - Sealed `SemanticConsensusCertificate` (`private mk ::`) proves linguistic consensus + `R0` trap-policy compliance ONLY.
       - Theorem `consensus_does_not_certify_empirical_truth` exhibits two extensional clinical worlds `(W_true, W_false)`
         proving that `SemanticConsensusCertificate` does NOT certify empirical/clinical truth (`P4`) and cannot construct
         any `CertifiedOutput` (`P5` remains `NOT_AUTHORIZED`).
-/
import P3CDetachedChecker.TreeSemanticExtractor

namespace PneumaOmega.P3C

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B

/-! ### 1. Universal Reading Consensus & Ambiguity Refutation Witness (`D02` / `D03`) -/

/--
  **Declarative Universal Reading Consensus (`UniversalConsensus`)**:
  Non-empty extracted forest `pairs` where EVERY `(τ, m) ∈ pairs` normalizes to `c`.
-/
def UniversalConsensus (pairs : List (ConcreteParseTree × RawSemanticTerm))
    (c : CanonicalMeaning) : Prop :=
  pairs ≠ [] ∧ ∀ p ∈ pairs, normalizeMeaning p.2 = c

/--
  Concrete machine-checkable witness of semantic ambiguity (`AmbiguousReadings` — `D02` / `D03`):
  Exhibits two parse trees `tree1, tree2 ∈ T` whose extracted meanings `raw1, raw2` normalize to
  distinct canonical forms `norm1 ≠ norm2`, immediately entailing `¬ SemEq raw1 raw2`!
-/
structure AmbiguityRefutationWitness where
  tree1  : ConcreteParseTree
  tree2  : ConcreteParseTree
  raw1   : RawSemanticTerm
  raw2   : RawSemanticTerm
  norm1  : CanonicalMeaning
  norm2  : CanonicalMeaning
  deriving DecidableEq

/-- Executable invariant check on `AmbiguityRefutationWitness` (`!canonicalMeaningEqBool norm1 norm2`). -/
def AmbiguityRefutationWitness.isDivergent (w : AmbiguityRefutationWitness) : Bool :=
  !canonicalMeaningEqBool w.norm1 w.norm2

/--
  **Ambiguity Witness Refutation Theorem (`ambiguityWitness_not_semEq`)**:
  Whenever `w.norm1 = normalizeMeaning w.raw1`, `w.norm2 = normalizeMeaning w.raw2`, and `w.norm1 ≠ w.norm2`,
  `raw1` and `raw2` are PROVABLY NOT semantically equivalent (`¬ SemEq w.raw1 w.raw2`)!
-/
theorem ambiguityWitness_not_semEq (w : AmbiguityRefutationWitness)
    (hn1 : w.norm1 = normalizeMeaning w.raw1)
    (hn2 : w.norm2 = normalizeMeaning w.raw2)
    (hne : w.norm1 ≠ w.norm2) :
    ¬ SemEq w.raw1 w.raw2 := by
  intro hsem
  have heq := semEq_implies_normalizeMeaning_eq hsem
  rw [← hn1, ← hn2] at heq
  exact hne heq

/-- Scans `rest` for any `(τ₂, m₂)` whose `normalizeMeaning` diverges from `(τ₁, m₁, c₁)`. -/
def findDivergentReading (t1 : ConcreteParseTree) (m1 : RawSemanticTerm) (c1 : CanonicalMeaning) :
    List (ConcreteParseTree × RawSemanticTerm) → Option AmbiguityRefutationWitness
  | [] => none
  | (t2, m2) :: rest =>
    let c2 := normalizeMeaning m2
    if canonicalMeaningEqBool c1 c2 then
      findDivergentReading t1 m1 c1 rest
    else
      some { tree1 := t1, tree2 := t2, raw1 := m1, raw2 := m2, norm1 := c1, norm2 := c2 }

theorem findDivergentReading_none_iff (t1 : ConcreteParseTree) (m1 : RawSemanticTerm)
    (c1 : CanonicalMeaning) (rest : List (ConcreteParseTree × RawSemanticTerm)) :
    findDivergentReading t1 m1 c1 rest = none ↔
      ∀ p ∈ rest, normalizeMeaning p.2 = c1 := by
  induction rest with
  | nil => simp [findDivergentReading]
  | cons p rps ih =>
    rcases p with ⟨t2, m2⟩
    unfold findDivergentReading
    dsimp only
    by_cases heq : canonicalMeaningEqBool c1 (normalizeMeaning m2) = true
    · rw [if_pos heq, ih]
      have hc : normalizeMeaning m2 = c1 := ((canonicalMeaningEqBool_iff _ _).mp heq).symm
      constructor
      · intro hall q hq
        rcases List.mem_cons.mp hq with rfl | hm
        · exact hc
        · exact hall q hm
      · intro hall q hq
        exact hall q (List.Mem.tail (t2, m2) hq)
    · rw [if_neg heq]
      constructor
      · intro h; contradiction
      · intro hall
        have hc : normalizeMeaning m2 = c1 := hall (t2, m2) (List.Mem.head rps)
        have hbeq : canonicalMeaningEqBool c1 (normalizeMeaning m2) = true :=
          (canonicalMeaningEqBool_iff _ _).mpr hc.symm
        exact False.elim (heq hbeq)

theorem findDivergentReading_some_sound (t1 : ConcreteParseTree) (m1 : RawSemanticTerm)
    (rest : List (ConcreteParseTree × RawSemanticTerm)) (w : AmbiguityRefutationWitness)
    (hsome : findDivergentReading t1 m1 (normalizeMeaning m1) rest = some w) :
    w.tree1 = t1 ∧
    w.raw1 = m1 ∧
    (w.tree2, w.raw2) ∈ rest ∧
    w.norm1 = normalizeMeaning w.raw1 ∧
    w.norm2 = normalizeMeaning w.raw2 ∧
    w.norm1 ≠ w.norm2 ∧
    ¬ SemEq w.raw1 w.raw2 := by
  generalize hc1 : normalizeMeaning m1 = c1 at hsome
  induction rest with
  | nil => simp [findDivergentReading] at hsome
  | cons p rps ih =>
    rcases p with ⟨t2, m2⟩
    unfold findDivergentReading at hsome
    dsimp only at hsome
    by_cases heq : canonicalMeaningEqBool c1 (normalizeMeaning m2) = true
    · rw [if_pos heq] at hsome
      rcases ih hsome with ⟨ht1, hr1, hmem, hn1, hn2, hne, hnotsem⟩
      exact ⟨ht1, hr1, List.Mem.tail (t2, m2) hmem, hn1, hn2, hne, hnotsem⟩
    · rw [if_neg heq] at hsome
      injection hsome with hw
      subst w
      have hne_c : c1 ≠ normalizeMeaning m2 := by
        intro h; exact heq ((canonicalMeaningEqBool_iff _ _).mpr h)
      have hn1_eq : c1 = normalizeMeaning m1 := hc1.symm
      refine ⟨rfl, rfl, List.Mem.head rps, hn1_eq, rfl, hne_c, ?_⟩
      exact ambiguityWitness_not_semEq
        { tree1 := t1, tree2 := t2, raw1 := m1, raw2 := m2, norm1 := c1, norm2 := normalizeMeaning m2 }
        hn1_eq rfl hne_c

/-! ### 2. Upstream Parse Diagnostics & Sealed `SemanticConsensusCertificate` (`D02` / `D03`) -/

/-- Upstream `P3-B` rejection causes (`F-P3C-D02`: kept strictly disjoint from extraction failure & ambiguity). -/
inductive UpstreamParseDiag where
  | outOfDomain      (diag : OutOfDomainDiag)
  | resourceOverflow (reason : OverflowReason)
  | emptyParseSet
  deriving DecidableEq, Repr

/--
  **Sealed Linguistic Consensus & Trap-Compliance Certificate (`SemanticConsensusCertificate` — `D03`)**:
  Uses `private mk ::` so ONLY `evaluateForestConsensus` (after verifying non-emptiness, total extraction,
  `UniversalConsensus`, AND `TrapPolicyPermitsForest` independently) can mint this certificate!
  Carries ZERO empirical/clinical truth claim (`P4` is `NOT_AUTHORIZED`) and ZERO `CertifiedOutput` authority
  (`P5` is `NOT_AUTHORIZED`).
-/
structure SemanticConsensusCertificate (env : ScopeEnv) (T : List ConcreteParseTree)
    (canonical : CanonicalMeaning) where
  private mk ::
  extractedPairs : List (ConcreteParseTree × RawSemanticTerm)
  hNonEmpty      : T ≠ []
  hExtractedAll  : extractAllMeanings env T = .ok extractedPairs
  hConsensus     : UniversalConsensus extractedPairs canonical
  hTrapPermits   : TrapPolicyPermitsForest T

/--
  **5-Way Forest Outcome (`ForestSemanticOutcome` — `F-P3C-D02`)**:
  Separates all five mandatory `P3-C` states cleanly without conflating any two failure modes.
-/
inductive ForestSemanticOutcome (env : ScopeEnv) (T : List ConcreteParseTree) where
  | consensus
      (canonical : CanonicalMeaning)
      (cert      : SemanticConsensusCertificate env T canonical)
  | ambiguousReadings
      (witness   : AmbiguityRefutationWitness)
  | semanticExtractionFailure
      (err       : ForestExtractionError)
  | trapPolicyRejected
      (consensusCandidate : CanonicalMeaning)
      (diag               : TrapPolicyDiag)
  | upstreamRejected
      (diag      : UpstreamParseDiag)

/--
  **Core `P3-C` Forest Consensus & Independent Trap-Policy Evaluator (`evaluateForestConsensus`)**:
  1. Empty forest `T = []` ↦ `.upstreamRejected .emptyParseSet` (NEVER vacuous consensus!).
  2. Total semantic extraction `extractAllMeanings env T`: any `.error err` ↦ `.semanticExtractionFailure err`.
  3. Universal reading consensus check across all `(τ, m) ∈ pairs`:
     any divergent `normalizeMeaning m₂ ≠ normalizeMeaning m₁` ↦ `.ambiguousReadings witness`.
  4. Independent `R0` trap-policy check `findForestTrapViolation T`:
     any `some diag` ↦ `.trapPolicyRejected c1 diag` (catches `T3`, `T5`, and 1-tree trap forests!).
  5. Both `UniversalConsensus` AND `TrapPolicyPermitsForest` hold ↦ `.consensus c1 cert`!
-/
def evaluateForestConsensus (env : ScopeEnv) (T : List ConcreteParseTree) :
    ForestSemanticOutcome env T :=
  if hne : T = [] then
    .upstreamRejected .emptyParseSet
  else
    match hext : extractAllMeanings env T with
    | .error err => .semanticExtractionFailure err
    | .ok [] =>
      False.elim (extractAllMeanings_nonempty hne hext rfl)
    | .ok ((t1, m1) :: rest) =>
      let c1 := normalizeMeaning m1
      match hdiv : findDivergentReading t1 m1 c1 rest with
      | some w => .ambiguousReadings w
      | none   =>
        match htrap : findForestTrapViolation T with
        | some trapDiag => .trapPolicyRejected c1 trapDiag
        | none          =>
          have hall_rest : ∀ p ∈ rest, normalizeMeaning p.2 = c1 :=
            (findDivergentReading_none_iff t1 m1 c1 rest).mp hdiv
          have hcons : UniversalConsensus ((t1, m1) :: rest) c1 := by
            refine ⟨by simp, ?_⟩
            intro p hp
            rcases List.mem_cons.mp hp with rfl | hm
            · rfl
            · exact hall_rest p hm
          have hperm : TrapPolicyPermitsForest T :=
            (findForestTrapViolation_none_iff T).mp htrap
          .consensus c1
            { extractedPairs := (t1, m1) :: rest
              hNonEmpty      := hne
              hExtractedAll  := hext
              hConsensus     := hcons
              hTrapPermits   := hperm }

/-! ### 3. Direct `P3-B → P3-C` End-to-End Byte Pipeline (`certifySemanticConsensus`) -/

/--
  **5-Way End-to-End Pipeline Result (`SemanticNormOutcome` — `F-P3C-D02`)**:
  Produced directly on top of frozen `BrocaOmega.P3B.parseAllBounded`.
-/
inductive SemanticNormOutcome where
  | consensus
      (trees     : List ConcreteParseTree)
      (canonical : CanonicalMeaning)
  | ambiguousReadings
      (trees     : List ConcreteParseTree)
      (witness   : AmbiguityRefutationWitness)
  | semanticExtractionFailure
      (trees     : List ConcreteParseTree)
      (err       : ForestExtractionError)
  | trapPolicyRejected
      (trees              : List ConcreteParseTree)
      (consensusCandidate : CanonicalMeaning)
      (diag               : TrapPolicyDiag)
  | upstreamRejected
      (diag      : UpstreamParseDiag)
  deriving DecidableEq

/--
  Pure non-dependent forest evaluator (`evalForestPure`) with zero `dite` / dependent-match motives
  for fast kernel WHNF reduction.
-/
def evalForestPure (env : ScopeEnv) (T : List ConcreteParseTree) : SemanticNormOutcome :=
  match T with
  | [] => .upstreamRejected .emptyParseSet
  | _ :: _ =>
    match extractAllMeanings env T with
    | .error err => .semanticExtractionFailure T err
    | .ok [] => .upstreamRejected .emptyParseSet
    | .ok ((t1, m1) :: rest) =>
      let c1 := normalizeMeaning m1
      match findDivergentReading t1 m1 c1 rest with
      | some w => .ambiguousReadings T w
      | none   =>
        match findForestTrapViolation T with
        | some trapDiag => .trapPolicyRejected T c1 trapDiag
        | none          => .consensus T c1

/--
  **End-to-End `P3-B → P3-C` Semantic Normalization & Consensus Gate (`certifySemanticConsensus`)**:
  Directly invokes `BrocaOmega.P3B.parseAllBounded` and evaluates `evalForestPure`.
-/
def certifySemanticConsensus
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) :
    SemanticNormOutcome :=
  match parseAllBounded cat numCfg env budget rawBytes with
  | .outOfDomain d      => .upstreamRejected (.outOfDomain d)
  | .resourceOverflow b => .upstreamRejected (.resourceOverflow b)
  | .enumerated T       => evalForestPure env T

/-! ### 4. Full Suite of `D02` & `D03` Soundness & Authority-Separation Theorems -/

/--
  **Theorem `D02.1` (`evaluateForestConsensus_consensus_sound`)**:
  Whenever `evaluateForestConsensus env T = .consensus c cert`, `T` is non-empty, every `τ ∈ T`
  extracts cleanly, all extracted meanings normalize to `c` AND are `SemEq` to `embedCanonical c`
  (which satisfies `IsCanonicalNorm`), AND `TrapPolicyPermitsForest T` holds!
-/
theorem evaluateForestConsensus_consensus_sound
    (env : ScopeEnv) (T : List ConcreteParseTree)
    (c : CanonicalMeaning) (cert : SemanticConsensusCertificate env T c)
    (_h : evaluateForestConsensus env T = .consensus c cert) :
    T ≠ [] ∧
    cert.extractedPairs.map Prod.fst = T ∧
    UniversalConsensus cert.extractedPairs c ∧
    TrapPolicyPermitsForest T ∧
    IsCanonicalNorm (embedCanonical c) ∧
    (∀ p ∈ cert.extractedPairs,
       extractRawMeaning env p.1 = .ok p.2 ∧ SemEq (embedCanonical c) p.2) := by
  have ⟨hmap, hall_ext⟩ := (extractAllMeanings_ok_iff env T cert.extractedPairs).mp cert.hExtractedAll
  have ⟨hp_ne, hall_norm⟩ := cert.hConsensus
  have hcanon : IsCanonicalNorm (embedCanonical c) := by
    cases hp_case : cert.extractedPairs with
    | nil => exact False.elim (hp_ne hp_case)
    | cons p0 rps =>
      have hc0 : normalizeMeaning p0.2 = c := hall_norm p0 (by rw [hp_case]; exact List.Mem.head rps)
      rw [← hc0]
      exact (isCanonicalNorm_iff_fixedPoint (N p0.2)).mpr (N_idempotent p0.2)
  refine ⟨cert.hNonEmpty, hmap, cert.hConsensus, cert.hTrapPermits, hcanon, ?_⟩
  intro p hp
  have hext_p := hall_ext p hp
  have hnorm_p : normalizeMeaning p.2 = c := hall_norm p hp
  have hsem_p : SemEq (embedCanonical c) p.2 := by
    rw [← hnorm_p]
    exact N_preserves_SemEq p.2
  exact ⟨hext_p, hsem_p⟩

/--
  **Theorem `D02.2` (`evaluateForestConsensus_ambiguous_sound`)**:
  Whenever `evaluateForestConsensus env T = .ambiguousReadings w`, `w.tree1 ∈ T`, `w.tree2 ∈ T`,
  both extract cleanly to `w.raw1` and `w.raw2`, `w.norm1 ≠ w.norm2`, and `¬ SemEq w.raw1 w.raw2`!
-/
theorem evaluateForestConsensus_ambiguous_sound
    (env : ScopeEnv) (T : List ConcreteParseTree) (w : AmbiguityRefutationWitness)
    (h : evaluateForestConsensus env T = .ambiguousReadings w) :
    w.tree1 ∈ T ∧
    w.tree2 ∈ T ∧
    extractRawMeaning env w.tree1 = .ok w.raw1 ∧
    extractRawMeaning env w.tree2 = .ok w.raw2 ∧
    w.norm1 = normalizeMeaning w.raw1 ∧
    w.norm2 = normalizeMeaning w.raw2 ∧
    w.norm1 ≠ w.norm2 ∧
    ¬ SemEq w.raw1 w.raw2 := by
  unfold evaluateForestConsensus at h
  split at h
  · contradiction
  · split at h
    · contradiction
    · rename_i hne hext
      exact False.elim (extractAllMeanings_nonempty hne hext rfl)
    · rename_i hne t1 m1 rest hext
      dsimp only at h
      split at h
      · rename_i w0 hdiv
        injection h with hw
        subst w0
        have ⟨ht1, hr1, hmem_rest, hn1, hn2, hne_norm, hnotsem⟩ :=
          findDivergentReading_some_sound t1 m1 rest w hdiv
        have ⟨hmap, hall_ext⟩ := (extractAllMeanings_ok_iff env T ((t1, m1) :: rest)).mp hext
        have hmem1_pairs : (w.tree1, w.raw1) ∈ (t1, m1) :: rest := by
          rw [ht1, hr1]; exact List.Mem.head rest
        have hmem2_pairs : (w.tree2, w.raw2) ∈ (t1, m1) :: rest :=
          List.Mem.tail (t1, m1) hmem_rest
        have ht1_in_T : w.tree1 ∈ T := by
          rw [← hmap]; exact List.mem_map.mpr ⟨(w.tree1, w.raw1), hmem1_pairs, rfl⟩
        have ht2_in_T : w.tree2 ∈ T := by
          rw [← hmap]; exact List.mem_map.mpr ⟨(w.tree2, w.raw2), hmem2_pairs, rfl⟩
        exact ⟨ht1_in_T, ht2_in_T, hall_ext _ hmem1_pairs, hall_ext _ hmem2_pairs,
               hn1, hn2, hne_norm, hnotsem⟩
      · split at h <;> contradiction

/--
  **Theorem `D02.3` (`evaluateForestConsensus_extractionFailure_sound`)**:
  Whenever `evaluateForestConsensus env T = .semanticExtractionFailure err`, `err.failedTree ∈ T`
  and `extractRawMeaning env err.failedTree = .error err.diag` (distinct from ambiguity!).
-/
theorem evaluateForestConsensus_extractionFailure_sound
    (env : ScopeEnv) (T : List ConcreteParseTree) (err : ForestExtractionError)
    (h : evaluateForestConsensus env T = .semanticExtractionFailure err) :
    err.failedTree ∈ T ∧ extractRawMeaning env err.failedTree = .error err.diag := by
  unfold evaluateForestConsensus at h
  split at h
  · contradiction
  · split at h
    · rename_i hne e0 hext
      injection h with heq
      subst e0
      exact extractAllMeanings_err_sound hext
    · rename_i hne hext
      exact False.elim (extractAllMeanings_nonempty hne hext rfl)
    · dsimp only at h
      split at h
      · contradiction
      · split at h <;> contradiction

/--
  **Theorem `D02.4` / `D03.1` (`evaluateForestConsensus_trapRejected_sound`)**:
  Whenever `evaluateForestConsensus env T = .trapPolicyRejected c diag`, `UniversalConsensus`
  HELD across all extracted pairs of `T`, YET `¬ TrapPolicyPermitsForest T` failed — proving
  formally that `UniversalConsensus` and `TrapPolicyPermitsForest` are verified independently!
-/
theorem evaluateForestConsensus_trapRejected_sound
    (env : ScopeEnv) (T : List ConcreteParseTree) (c : CanonicalMeaning) (diag : TrapPolicyDiag)
    (h : evaluateForestConsensus env T = .trapPolicyRejected c diag) :
    (∃ pairs, extractAllMeanings env T = .ok pairs ∧ UniversalConsensus pairs c) ∧
    ¬ TrapPolicyPermitsForest T := by
  unfold evaluateForestConsensus at h
  split at h
  · contradiction
  · split at h
    · contradiction
    · rename_i hne hext
      exact False.elim (extractAllMeanings_nonempty hne hext rfl)
    · rename_i hne t1 m1 rest hext
      dsimp only at h
      split at h
      · contradiction
      · rename_i hdiv
        split at h
        · rename_i d0 htrap
          injection h with hc hd
          subst c; subst d0
          have hall_rest := (findDivergentReading_none_iff t1 m1 (normalizeMeaning m1) rest).mp hdiv
          have hcons : UniversalConsensus ((t1, m1) :: rest) (normalizeMeaning m1) := by
            refine ⟨by simp, ?_⟩
            intro p hp
            rcases List.mem_cons.mp hp with rfl | hm
            · rfl
            · exact hall_rest p hm
          have hnot_perm : ¬ TrapPolicyPermitsForest T := by
            intro hperm
            have hnone := (findForestTrapViolation_none_iff T).mpr hperm
            rw [htrap] at hnone
            contradiction
          exact ⟨⟨(t1, m1) :: rest, hext, hcons⟩, hnot_perm⟩
        · contradiction

/--
  **Master End-to-End Soundness Theorem (`certifySemanticConsensus_sound` — `PO-C1-03` + `D01` + `D02` + `D03`)**:
  Whenever `certifySemanticConsensus cat numCfg env budget rawBytes = .consensus T c`, ALL of the following hold:
  1. `parseAllBounded cat numCfg env budget rawBytes = .enumerated T` with `T ≠ []` and `NoDupTrees T`.
  2. **Bounded Exhaustive Parse Set (`P3-B`)**: `StrictAsciiDomainSupported rawBytes` and
     `∀ τ, τ ∈ T ↔ ValidParse_GFrozen cat numCfg env rawBytes τ`.
  3. **Independent Trap Policy (`D03`)**: `TrapPolicyPermitsForest T` (zero `G_trap` nodes in `T`).
  4. **Universal Reading Consensus & Semantic Preservation (`D01` + `D02`)**:
     Every parse reading `τ ∈ T` extracts cleanly to some `m`, normalizes to `c`, and satisfies
     `SemEq (embedCanonical c) m`, where `IsCanonicalNorm (embedCanonical c)`!
-/
theorem certifySemanticConsensus_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree) (c : CanonicalMeaning)
    (h : certifySemanticConsensus cat numCfg env budget rawBytes = .consensus T c) :
    parseAllBounded cat numCfg env budget rawBytes = .enumerated T ∧
    StrictAsciiDomainSupported rawBytes ∧
    T ≠ [] ∧
    NoDupTrees T ∧
    (∀ τ : ConcreteParseTree, τ ∈ T ↔ ValidParse_GFrozen cat numCfg env rawBytes τ) ∧
    TrapPolicyPermitsForest T ∧
    IsCanonicalNorm (embedCanonical c) ∧
    (∃ pairs : List (ConcreteParseTree × RawSemanticTerm),
       extractAllMeanings env T = .ok pairs ∧
       pairs.map Prod.fst = T ∧
       UniversalConsensus pairs c ∧
       ∀ p ∈ pairs, extractRawMeaning env p.1 = .ok p.2 ∧ SemEq (embedCanonical c) p.2) := by
  unfold certifySemanticConsensus at h
  cases hp : parseAllBounded cat numCfg env budget rawBytes with
  | outOfDomain _ => rw [hp] at h; contradiction
  | resourceOverflow _ => rw [hp] at h; contradiction
  | enumerated T0 =>
    rw [hp] at h
    dsimp only at h
    cases T0 with
    | nil => simp [evalForestPure] at h
    | cons hd tl =>
      unfold evalForestPure at h
      dsimp only at h
      cases hext : extractAllMeanings env (hd :: tl) with
      | error _ => rw [hext] at h; contradiction
      | ok pairs =>
        rw [hext] at h
        cases pairs with
        | nil => contradiction
        | cons p1 rest =>
          rcases p1 with ⟨t1, m1⟩
          dsimp only at h
          cases hdiv : findDivergentReading t1 m1 (normalizeMeaning m1) rest with
          | some _ => rw [hdiv] at h; contradiction
          | none =>
            rw [hdiv] at h
            dsimp only at h
            cases htrap : findForestTrapViolation (hd :: tl) with
            | some _ => rw [htrap] at h; contradiction
            | none =>
              rw [htrap] at h
              injection h with hT hc
              subst T; subst c
              have ⟨hsup, _, _, hnodup, hexact⟩ :=
                parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes (hd :: tl) hp
              have ⟨hmap, hall_ext⟩ := (extractAllMeanings_ok_iff env (hd :: tl) ((t1, m1) :: rest)).mp hext
              have hall_rest := (findDivergentReading_none_iff t1 m1 (normalizeMeaning m1) rest).mp hdiv
              have hcons : UniversalConsensus ((t1, m1) :: rest) (normalizeMeaning m1) := by
                refine ⟨by simp, ?_⟩
                intro p hp_m
                rcases List.mem_cons.mp hp_m with rfl | hm
                · rfl
                · exact hall_rest p hm
              have hperm : TrapPolicyPermitsForest (hd :: tl) :=
                (findForestTrapViolation_none_iff (hd :: tl)).mp htrap
              have hcanon : IsCanonicalNorm (embedCanonical (normalizeMeaning m1)) :=
                (isCanonicalNorm_iff_fixedPoint (N m1)).mpr (N_idempotent m1)
              refine ⟨rfl, hsup, by simp, hnodup, hexact, hperm, hcanon,
                      ⟨(t1, m1) :: rest, hext, hmap, hcons, ?_⟩⟩
              intro p hp_m
              have hext_p := hall_ext p hp_m
              have hnorm_p : normalizeMeaning p.2 = normalizeMeaning m1 := hcons.2 p hp_m
              have hsem_p : SemEq (embedCanonical (normalizeMeaning m1)) p.2 := by
                rw [← hnorm_p]
                exact N_preserves_SemEq p.2
              exact ⟨hext_p, hsem_p⟩

/--
  **End-to-End Ambiguity Refutation Soundness (`certifySemanticConsensus_ambiguous_sound`)**:
  Whenever `certifySemanticConsensus ... = .ambiguousReadings T w`, `w.tree1` and `w.tree2` are
  both valid `G_parse` readings of `rawBytes` (`ValidParse_GFrozen`) whose extracted meanings
  satisfy `¬ SemEq w.raw1 w.raw2`!
-/
theorem certifySemanticConsensus_ambiguous_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree) (w : AmbiguityRefutationWitness)
    (h : certifySemanticConsensus cat numCfg env budget rawBytes = .ambiguousReadings T w) :
    ValidParse_GFrozen cat numCfg env rawBytes w.tree1 ∧
    ValidParse_GFrozen cat numCfg env rawBytes w.tree2 ∧
    extractRawMeaning env w.tree1 = .ok w.raw1 ∧
    extractRawMeaning env w.tree2 = .ok w.raw2 ∧
    w.norm1 ≠ w.norm2 ∧
    ¬ SemEq w.raw1 w.raw2 := by
  unfold certifySemanticConsensus at h
  cases hp : parseAllBounded cat numCfg env budget rawBytes with
  | outOfDomain _ => rw [hp] at h; contradiction
  | resourceOverflow _ => rw [hp] at h; contradiction
  | enumerated T0 =>
    rw [hp] at h
    dsimp only at h
    cases T0 with
    | nil => simp [evalForestPure] at h
    | cons hd tl =>
      unfold evalForestPure at h
      dsimp only at h
      cases hext : extractAllMeanings env (hd :: tl) with
      | error _ => rw [hext] at h; contradiction
      | ok pairs =>
        rw [hext] at h
        cases pairs with
        | nil => contradiction
        | cons p1 rest =>
          rcases p1 with ⟨t1, m1⟩
          dsimp only at h
          cases hdiv : findDivergentReading t1 m1 (normalizeMeaning m1) rest with
          | none =>
            rw [hdiv] at h
            dsimp only at h
            cases htrap : findForestTrapViolation (hd :: tl) <;> rw [htrap] at h <;> contradiction
          | some w0 =>
            rw [hdiv] at h
            injection h with hT hw
            subst T; subst w0
            have hexact := (parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes (hd :: tl) hp).2.2.2.2
            have ⟨ht1, hr1, hmem_rest, _, _, hne_norm, hnotsem⟩ :=
              findDivergentReading_some_sound t1 m1 rest w hdiv
            have ⟨hmap, hall_ext⟩ := (extractAllMeanings_ok_iff env (hd :: tl) ((t1, m1) :: rest)).mp hext
            have hmem1_pairs : (w.tree1, w.raw1) ∈ (t1, m1) :: rest := by
              rw [ht1, hr1]; exact List.Mem.head rest
            have hmem2_pairs : (w.tree2, w.raw2) ∈ (t1, m1) :: rest :=
              List.Mem.tail (t1, m1) hmem_rest
            have ht1_in_T : w.tree1 ∈ hd :: tl := by
              rw [← hmap]; exact List.mem_map.mpr ⟨(w.tree1, w.raw1), hmem1_pairs, rfl⟩
            have ht2_in_T : w.tree2 ∈ hd :: tl := by
              rw [← hmap]; exact List.mem_map.mpr ⟨(w.tree2, w.raw2), hmem2_pairs, rfl⟩
            exact ⟨(hexact w.tree1).mp ht1_in_T, (hexact w.tree2).mp ht2_in_T,
                   hall_ext _ hmem1_pairs, hall_ext _ hmem2_pairs, hne_norm, hnotsem⟩

/--
  **End-to-End Upstream Rejection Soundness (`certifySemanticConsensus_upstream_failClosed`)**:
  `OutOfDomain(d)`, `ResourceOverflow(b)`, and `Enumerated []` deterministically map to
  `.upstreamRejected` and NEVER emit `.consensus`!
-/
theorem certifySemanticConsensus_upstream_failClosed
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) :
    (∀ d, parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d →
          certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected (.outOfDomain d)) ∧
    (∀ b, parseAllBounded cat numCfg env budget rawBytes = .resourceOverflow b →
          certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected (.resourceOverflow b)) ∧
    (parseAllBounded cat numCfg env budget rawBytes = .enumerated [] →
          certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected .emptyParseSet) := by
  refine ⟨?_, ?_, ?_⟩
  · intro d hd; unfold certifySemanticConsensus; rw [hd]
  · intro b hb; unfold certifySemanticConsensus; rw [hb]
  · intro he; unfold certifySemanticConsensus; rw [he]; rfl

/--
  **Theorem `D03.2` (`consensus_does_not_certify_empirical_truth` — Authority Separation)**:
  Even when a `CanonicalMeaning` `c` comes from a valid `SemanticConsensusCertificate` (e.g., an
  in-grammar `G-01` descriptive incidence proposition), there exist extensional clinical worlds
  `W_true` and `W_false` where `Denotes W_true (embedCanonical c)` holds while
  `¬ Denotes W_false (embedCanonical c)`!
  Hence linguistic semantic consensus (`P3-C`) is strictly orthogonal to empirical/clinical
  evidence truth (`P4`, `NOT_AUTHORIZED`) and final `CertifiedOutput` admission (`P5`, `NOT_AUTHORIZED`).
-/
theorem consensus_does_not_certify_empirical_truth
    (coh win ev k n pct : String) :
    let c : CanonicalMeaning :=
      normalizeMeaning (.scopedAtom (.cohortBound coh) "x_init" (.descIncidence win ev k n pct) [])
    ∃ (W_true W_false : SemanticWorld),
      ExtensionalContrastiveWorld W_true ∧
      ExtensionalContrastiveWorld W_false ∧
      Denotes W_true (embedCanonical c) ∧
      ¬ Denotes W_false (embedCanonical c) := by
  intro c
  let W_true : SemanticWorld :=
    { patientDomain      := fun _ _ => []
      patientEventHolds  := fun _ _ _ => false
      genericLawHolds    := fun _ _ _ => false
      eventTimestamp     := fun _ _ => 0
      factTableHolds     := fun _ _ => true
      presupHolds        := fun _ _ => true
      contrastiveCoheres := fun _ _ _ _ => true }
  let W_false : SemanticWorld :=
    { patientDomain      := fun _ _ => []
      patientEventHolds  := fun _ _ _ => false
      genericLawHolds    := fun _ _ _ => false
      eventTimestamp     := fun _ _ => 0
      factTableHolds     := fun _ _ => false
      presupHolds        := fun _ _ => true
      contrastiveCoheres := fun _ _ _ _ => true }
  refine ⟨W_true, W_false, (fun _ _ _ _ _ _ _ _ => rfl), (fun _ _ _ _ _ _ _ _ => rfl), ?_, ?_⟩
  · rfl
  · intro hf
    exact Bool.noConfusion hf

end PneumaOmega.P3C
