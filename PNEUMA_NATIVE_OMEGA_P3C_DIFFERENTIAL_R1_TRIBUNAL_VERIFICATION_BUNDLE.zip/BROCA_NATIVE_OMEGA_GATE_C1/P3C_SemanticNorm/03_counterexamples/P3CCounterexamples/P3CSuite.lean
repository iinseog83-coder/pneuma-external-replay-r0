/-
  PNEUMA-NATIVE Ω — AUTH-C1-P3-C (`PO-C1-03`, `F-P3C-D01`, `F-P3C-D02`, `F-P3C-D03`)
  03_counterexamples/P3CCounterexamples/P3CSuite.lean
  Pure Lean 4.33.1 Core (`Init` + read-only Legacy BROCA `P2`, `P3-A`, `P3-B`, zero `sorry`, zero `native_decide`)

  Verifies 30 curated vectors (`15` symmetric `(PC, CE)` pairs) via Lean's kernel `decide`:
    - `PAIR-01`: `G-01` Consensus vs Empirical Truth Authority Separation (`W_true` vs `W_false`, `D03`)
    - `PAIR-02`: `G-11` Consensus + `T1 alt=1` De Morgan equivalence vs `T1` Dual-Reading `AmbiguousReadings`
    - `PAIR-03`: `G-09` Consensus vs `T2` (`Y_T08`) Dual-Reading `AmbiguousReadings` (`[]` vs `[Presup]`)
    - `PAIR-04`: `G-10` Consensus (`≠ G-09`) vs `T3` Single-Reading `TrapPolicyRejected` (`whFactivePresuppositionForbidden`)
    - `PAIR-05`: `G-13` Consensus vs `T4` Bare-Plural Dual-Reading `AmbiguousReadings` (`∀_gen` vs `∃`)
    - `PAIR-06`: `G-12` Consensus vs `T5` Single-Reading Unscoped `TrapPolicyRejected` (`unscopedClauseForbidden`)
    - `PAIR-07`: `G-15a` `(A ∧ B)` vs `G-15b` `(B ∧ Within-study A)` Paraphrase Convergence (`m₁ ≠ m₂`, `N(m₁) = N(m₂)`)
                 vs Truncated 1-Tree `[τ_(T2, alt=1)]` `TrapPolicyRejected` (`parserOnlyTrapProduction .T2`)
    - `PAIR-08`: Multi-Tree Equivalent Generator Forest `[τ_15a, τ_15b]` (`|T|=2`) Consensus
                 vs Malformed `alt=3` `SemanticExtractionFailure` (`≠ AmbiguousReadings`, `D02`)
    - `PAIR-09`: `G-04` Temporal Precedence Consensus vs Reversed `ev_aki ≺ ev_stroke` Non-Equivalence (`N(m₁) ≠ N(m₂)`)
    - `PAIR-10`: `G-16` Contrastive Discourse Consensus vs Contrastive Side-Swap Non-Equivalence & Unresolved Anaphora Failure
    - `PAIR-11`: `G-06a` Causal Directional Consensus vs Causal/Associative (`G-03`) & Neutral (`G-06b`) Non-Equivalence
    - `PAIR-12`: Normalizer Idempotence (`N(N(m)) = N(m)`), Conjunct/Presup Dedup vs Invalid Contrastive Anchor Extraction Failure
    - `PAIR-13`: `G-07` Not-Stat-Sig Consensus vs Multi-Dot `1..25%` `UpstreamRejected (.emptyParseSet)`
    - `PAIR-14`: `G-05` Absolute Risk Difference Consensus vs Non-ASCII `UpstreamRejected (.outOfDomain ...)`
    - `PAIR-15`: `G-14` Covariate-Adjusted Consensus vs Tight `maxReadings = 1` on `T2` `UpstreamRejected (.resourceOverflow ...)`
-/
import P3CDetachedChecker

namespace PneumaOmega.P3C.Counterexamples

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C

/-! ### 1. Reference `ClosedEntityCatalog` Covering All 12 Open Entity Sorts (`ValidEntityCatalog`) -/

def p3cTestCatalog : ClosedEntityCatalog :=
  { entries :=
      [ { sort := .cohortSpec,       entityId := "coh_primary",  lexeme := "the primary cohort" },
        { sort := .designNoun,       entityId := "des_study",    lexeme := "study" },
        { sort := .followUpWindow,   entityId := "win_12m",      lexeme := "12 months" },
        { sort := .eventTerm,        entityId := "ev_stroke",    lexeme := "stroke" },
        { sort := .eventTerm,        entityId := "ev_aki",       lexeme := "acute kidney injury" },
        { sort := .measureTerm,      entityId := "meas_sbp",     lexeme := "systolic blood pressure" },
        { sort := .expLevel,         entityId := "exp_intens",   lexeme := "intensive therapy" },
        { sort := .expLevel,         entityId := "exp_std",      lexeme := "standard care" },
        { sort := .outTerm,          entityId := "out_mi",       lexeme := "myocardial infarction" },
        { sort := .outTerm,          entityId := "out_death",    lexeme := "all-cause mortality" },
        { sort := .sourceId,         entityId := "src_trialA",   lexeme := "Trial-A" },
        { sort := .identAssump,      entityId := "assump_exch",  lexeme := "conditional exchangeability" },
        { sort := .subgroupPlural,   entityId := "sub_dm_pl",    lexeme := "diabetic" },
        { sort := .subgroupSingular, entityId := "sub_hr_sg",    lexeme := "high-risk" },
        { sort := .covariateList,    entityId := "cov_age_risk", lexeme := "age and baseline risk" } ] }

theorem p3cTestCatalog_valid :
    ValidEntityCatalog p3cTestCatalog :=
  (checkValidEntityCatalogBool_iff p3cTestCatalog).mp (by decide)

def envAtomic : ScopeEnv :=
  { cohortId := "coh_primary", expectedDesignHead := "des_study", quoteIsolation := .sentenceAtomic }

def envDiscourse : ScopeEnv :=
  { cohortId := "coh_primary", expectedDesignHead := "des_study", quoteIsolation := .discourseBound }

def envMismatchedDesign : ScopeEnv :=
  { cohortId := "coh_primary", expectedDesignHead := "des_other_registry", quoteIsolation := .discourseBound }

def runP3COnStr (env : ScopeEnv) (budget : ResourceBudget) (s : String) : SemanticNormOutcome :=
  certifySemanticConsensus p3cTestCatalog frozenR22NumericConfig env budget (strToAsciiBytes s)

/-! ### 2. Canonical Test Sentences Across `G-01`~`G-16` & `T1`~`T5` -/

def sG01 : String :=
  "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%)."

def sG03 : String :=
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."

def sG04_StrokeBeforeAki : String :=
  "In the primary cohort, stroke preceded acute kidney injury, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."

def sG04_AkiBeforeStroke : String :=
  "In the primary cohort, acute kidney injury preceded stroke, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."

def sG05 : String :=
  "In the primary cohort, the absolute risk difference in myocardial infarction comparing intensive therapy versus standard care was -3.2 percentage points (95% CI -5.1 to -1.3)."

def sG06a : String :=
  "In the primary cohort, under conditional exchangeability, comparing intensive therapy versus standard care was estimated to reduce myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92, p = 0.006)."

def sG06b : String :=
  "In the primary cohort, under conditional exchangeability, the estimated causal hazard ratio for myocardial infarction comparing intensive therapy versus standard care was 0.98 (95% CI 0.81 to 1.19), which did not exclude no effect."

def sG07 : String :=
  "In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (hazard ratio = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = 0.05."

def sG09 : String :=
  "In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."

def sG10 : String :=
  "In the primary cohort, the analysis of Trial-A did not determine whether intensive therapy reduces myocardial infarction."

def sG11 : String :=
  "In the primary cohort, no diabetic patients developed stroke."

def sG12 : String :=
  "In the primary cohort, some, but not all, diabetic patients developed stroke."

def sG13 : String :=
  "In the primary cohort, at least one high-risk patient developed acute kidney injury."

def sG14 : String :=
  "In the primary cohort, after adjustment for age and baseline risk, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."

/-- `G-15a` sentence-atomic document `(Clause A. Clause B.)` under `envAtomic`. -/
def sG15a_AB : String :=
  "In the primary cohort, no diabetic patients developed stroke. In the primary cohort, at least one high-risk patient developed acute kidney injury."

/-- `G-15b` discourse-bound document `(Clause B. Within this same study, Clause A.)` under `envDiscourse`. -/
def sG15b_BA : String :=
  "In the primary cohort, at least one high-risk patient developed acute kidney injury. Within this same study, no diabetic patients developed stroke."

def sG16 : String :=
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."

def sT1_AllNot : String :=
  "In the primary cohort, all diabetic patients did not develop stroke."

/-- Mandatory `T2` (`Y_T08`) Dual-Reading Trap Sentence. -/
def sT2_ConfirmThat : String :=
  "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction."

def sT3_WhWhy : String :=
  "In the primary cohort, the analysis of Trial-A did not determine why intensive therapy reduces myocardial infarction."

def sT4_BarePlural : String :=
  "In the primary cohort, diabetic patients developed stroke."

def sT5_Unscoped : String :=
  "no diabetic patients developed stroke."

def sBadMultiDotG01 : String :=
  "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (1..25%)."

/-! ### 3. Hand-Crafted Synthetic Parse Trees for Direct Forest / Extraction Edge Tests (`D02` / `D03`) -/

private def sp0 : CodepointSpan := ⟨0, 1⟩

private def mkSlot (s : P3SlotSort) (t : BNFSlotTag) (eid lex : String) : ConcreteParseArg :=
  .slotTok s t eid lex sp0

/-- Valid `G-15a` tree `(Clause A ∧ Clause B)` with `"x_init"` binders on both clauses. -/
def synthTreeG15a_AB : ConcreteParseTree :=
  let coreA := ConcreteParseTree.mkTree .Gen_G11_QuantZero 1 .clause1 sp0
    [ mkSlot .subgroupPlural .subgroup "sub_dm_pl" "diabetic",
      mkSlot .eventTerm .eventA "ev_stroke" "stroke" ]
  let coreB := ConcreteParseTree.mkTree .Gen_G13_QuantAtLeastOne 1 .clause2 sp0
    [ mkSlot .subgroupSingular .subgroup "sub_hr_sg" "high-risk",
      mkSlot .eventTerm .eventA "ev_aki" "acute kidney injury" ]
  let sc1 := ConcreteParseTree.mkTree .Env_ScopedInitial 1 .clause1 sp0
    [ mkSlot .cohortSpec .cohort "coh_primary" "the primary cohort", .childSub coreA ]
  let sc2 := ConcreteParseTree.mkTree .Env_ScopedInitial 1 .clause2 sp0
    [ mkSlot .cohortSpec .cohort "coh_primary" "the primary cohort", .childSub coreB ]
  ConcreteParseTree.mkTree .Gen_G15a_DocConjAtomic 1 .clause1 sp0 [ .childSub sc1, .childSub sc2 ]

/-- Valid `G-15b` tree `(Clause B ∧ Within-study Clause A)` with `"y_repeat"` binder on clause 2. -/
def synthTreeG15b_BA : ConcreteParseTree :=
  let coreB := ConcreteParseTree.mkTree .Gen_G13_QuantAtLeastOne 1 .clause1 sp0
    [ mkSlot .subgroupSingular .subgroup "sub_hr_sg" "high-risk",
      mkSlot .eventTerm .eventA "ev_aki" "acute kidney injury" ]
  let coreA := ConcreteParseTree.mkTree .Gen_G11_QuantZero 1 .clause2 sp0
    [ mkSlot .subgroupPlural .subgroup "sub_dm_pl" "diabetic",
      mkSlot .eventTerm .eventA "ev_stroke" "stroke" ]
  let sc1 := ConcreteParseTree.mkTree .Env_ScopedInitial 1 .clause1 sp0
    [ mkSlot .cohortSpec .cohort "coh_primary" "the primary cohort", .childSub coreB ]
  let sc2 := ConcreteParseTree.mkTree .Env_ScopedRepeat 1 .clause2 sp0
    [ mkSlot .designNoun .design "des_study" "study", .childSub coreA ]
  ConcreteParseTree.mkTree .Gen_G15b_DocConjDiscourse 1 .clause1 sp0 [ .childSub sc1, .childSub sc2 ]

/-- Truncated single-tree `[τ_(T2, alt=1)]` attempting to bypass dual-reading ambiguity detection. -/
def synthTruncatedT2Alt1 : ConcreteParseTree :=
  let emb := ConcreteParseTree.mkTree .Env_EmbeddedCausal 1 .clause1 sp0
    [ mkSlot .expLevel .activeExp "exp_intens" "intensive therapy",
      mkSlot .intervVerbPres .verb "reduces" "reduces",
      mkSlot .outTerm .outcome "out_mi" "myocardial infarction" ]
  let t2 := ConcreteParseTree.mkTree .Trap_T2_ConfirmThat 1 .clause1 sp0
    [ mkSlot .sourceId .source "src_trialA" "Trial-A", .childSub emb ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedTrap 1 .clause1 sp0
    [ mkSlot .cohortSpec .cohort "coh_primary" "the primary cohort", .childSub t2 ]
  ConcreteParseTree.mkTree .Env_DocTrapScoped 1 .clause1 sp0 [ .childSub sc ]

/-- Malformed parse tree carrying unsupported `readingAlt = 3` on `Trap_T1_AllNot`. -/
def synthInvalidAlt3Tree : ConcreteParseTree :=
  let t1Bad := ConcreteParseTree.mkTree .Trap_T1_AllNot 3 .clause1 sp0
    [ mkSlot .subgroupPlural .subgroup "sub_dm_pl" "diabetic",
      mkSlot .eventTerm .eventA "ev_stroke" "stroke" ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedTrap 1 .clause1 sp0
    [ mkSlot .cohortSpec .cohort "coh_primary" "the primary cohort", .childSub t1Bad ]
  ConcreteParseTree.mkTree .Env_DocTrapScoped 1 .clause1 sp0 [ .childSub sc ]

/-- Malformed `G-16` tree with mismatched contrastive outcome anchor (`out_mi` vs `out_death`). -/
def synthBadAnchorG16Tree : ConcreteParseTree :=
  let assocCore := ConcreteParseTree.mkTree .Gen_G03_AssocUnadj 1 .clause1 sp0
    [ mkSlot .expLevel .activeExp "exp_intens" "intensive therapy",
      mkSlot .expLevel .refExp "exp_std" "standard care",
      mkSlot .assocDir .direction "inversely" "inversely",
      mkSlot .outTerm .outcome "out_mi" "myocardial infarction",
      mkSlot .ratioMetric .metric1 "hr" "hazard ratio",
      mkSlot .numericLit .numEst "0.75" "0.75",
      mkSlot .numericLit .numCILevel "95" "95",
      mkSlot .numericLit .numCILow "0.61" "0.61",
      mkSlot .numericLit .numCIHigh "0.92" "0.92" ]
  let embBad := ConcreteParseTree.mkTree .Env_EmbeddedCausal 1 .clause2 sp0
    [ mkSlot .expLevel .activeExp "exp_intens" "intensive therapy",
      mkSlot .intervVerbPres .verb "reduces" "reduces",
      mkSlot .outTerm .outcome "out_death" "all-cause mortality" ]
  let metaCore := ConcreteParseTree.mkTree .Gen_G09_MetaNonEstab 1 .clause2 sp0
    [ mkSlot .sourceId .source "src_trialA" "Trial-A", .childSub embBad ]
  let sc1 := ConcreteParseTree.mkTree .Env_ScopedAssoc 1 .clause1 sp0
    [ mkSlot .cohortSpec .cohort "coh_primary" "the primary cohort", .childSub assocCore ]
  let sc2 := ConcreteParseTree.mkTree .Env_ScopedContrastMeta 1 .clause2 sp0
    [ mkSlot .designNoun .design "des_study" "study", .childSub metaCore ]
  ConcreteParseTree.mkTree .Gen_G16_DocContrastive 1 .clause1 sp0 [ .childSub sc1, .childSub sc2 ]

/-! ### 4. Boolean Test Predicates & 30-Vector `(PC, CE)` Suite (`15` Pairs) -/

def isConsensusSingle (out : SemanticNormOutcome) : Bool :=
  match out with
  | .consensus [_] _ => true
  | _                => false

def isConsensusSingleEq (out : SemanticNormOutcome) (expected : CanonicalMeaning) : Bool :=
  match out with
  | .consensus [_] c => canonicalMeaningEqBool c expected
  | _                => false

def extractConsensusOpt : SemanticNormOutcome → Option CanonicalMeaning
  | .consensus _ c => some c
  | _              => none

def isAmbiguousDual (out : SemanticNormOutcome) : Bool :=
  match out with
  | .ambiguousReadings [t1, t2] w =>
    (!parseTreeEqBool t1 t2) && w.isDivergent
  | _ => false

def isTrapRejectedSingle (out : SemanticNormOutcome) (expectedDiag : TrapPolicyDiag) : Bool :=
  match out with
  | .trapPolicyRejected [_] _ d => d == expectedDiag
  | _                           => false

def expectedCanonG01 : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.descIncidence "win_12m" "ev_stroke" "42" "500" "8.4") [])

def expectedCanonG03 : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") [])

def expectedCanonG04_AB : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none (some ("ev_stroke", "ev_aki")) "0.75" "95" "0.61" "0.92") [])

def expectedCanonG04_BA : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none (some ("ev_aki", "ev_stroke")) "0.75" "95" "0.61" "0.92") [])

def expectedCanonG06a : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.intervClaim (.directional "reduce") "assump_exch" "hr" "exp_intens" "exp_std" "out_mi" "0.75" "95" "0.61" "0.92" (some "0.006")) [])

def expectedCanonG06b : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.intervClaim .neutralNullIncluded "assump_exch" "hr" "exp_intens" "exp_std" "out_mi" "0.98" "95" "0.81" "1.19" none) [])

def expectedCanonG09 : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") [])

def expectedCanonG10 : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.metaUnresolvedPolar "src_trialA" "exp_intens" "reduces" "out_mi") [])

-- PAIR 01: G-01 Consensus vs Empirical Truth Authority Separation (`D03`)
def pc01_b : Bool :=
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG01) expectedCanonG01

def ce01_b : Bool :=
  let wTrue : SemanticWorld :=
    { patientDomain := fun _ _ => [], patientEventHolds := fun _ _ _ => false,
      genericLawHolds := fun _ _ _ => false, eventTimestamp := fun _ _ => 0,
      factTableHolds := fun _ _ => true, presupHolds := fun _ _ => true,
      contrastiveCoheres := fun _ _ _ _ => true }
  let wFalse : SemanticWorld :=
    { patientDomain := fun _ _ => [], patientEventHolds := fun _ _ _ => false,
      genericLawHolds := fun _ _ _ => false, eventTimestamp := fun _ _ => 0,
      factTableHolds := fun _ _ => false, presupHolds := fun _ _ => true,
      contrastiveCoheres := fun _ _ _ _ => true }
  evalDenotation wTrue (embedCanonical expectedCanonG01) &&
  !evalDenotation wFalse (embedCanonical expectedCanonG01)

-- PAIR 02: G-11 Consensus + T1 alt=1 De Morgan equivalence vs T1 Dual-Reading Ambiguity
def pc02_b : Bool :=
  let t1Alt1Canon := normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "z_alt1"
    (.quantClaim (.universalNeg "sub_dm_pl" "ev_stroke")) [])
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG11) t1Alt1Canon

def ce02_b : Bool :=
  isAmbiguousDual (runP3COnStr envAtomic defaultParseBudget sT1_AllNot)

-- PAIR 03: G-09 Consensus vs T2 (`Y_T08`) Dual-Reading Ambiguity
def pc03_b : Bool :=
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG09) expectedCanonG09

def ce03_b : Bool :=
  isAmbiguousDual (runP3COnStr envAtomic defaultParseBudget sT2_ConfirmThat)

-- PAIR 04: G-10 Consensus (`≠ G-09`) vs T3 Single-Reading `whFactivePresuppositionForbidden`
def pc04_b : Bool :=
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG10) expectedCanonG10 &&
  !canonicalMeaningEqBool expectedCanonG10 expectedCanonG09

def ce04_b : Bool :=
  isTrapRejectedSingle (runP3COnStr envAtomic defaultParseBudget sT3_WhWhy)
    .whFactivePresuppositionForbidden

-- PAIR 05: G-13 Consensus vs T4 Bare-Plural Dual-Reading Ambiguity
def pc05_b : Bool :=
  isConsensusSingle (runP3COnStr envAtomic defaultParseBudget sG13)

def ce05_b : Bool :=
  isAmbiguousDual (runP3COnStr envAtomic defaultParseBudget sT4_BarePlural)

-- PAIR 06: G-12 Consensus vs T5 Single-Reading Unscoped `unscopedClauseForbidden`
def pc06_b : Bool :=
  isConsensusSingle (runP3COnStr envAtomic defaultParseBudget sG12)

def ce06_b : Bool :=
  isTrapRejectedSingle (runP3COnStr envAtomic defaultParseBudget sT5_Unscoped)
    .unscopedClauseForbidden

-- PAIR 07: Full Pipeline `G-15a (A ∧ B)` vs `G-15b (B ∧ Within-study A)` Paraphrase Convergence
--          vs Truncated 1-Tree `[τ_(T2, alt=1)]` Independent Trap Rejection
def pc07_b : Bool :=
  let expectedConj := normalizeMeaning (.symConj
    (.scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) [])
    (.scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.existentialPos "sub_hr_sg" "ev_aki")) []))
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG15a_AB) expectedConj &&
  isConsensusSingleEq (runP3COnStr envDiscourse defaultParseBudget sG15b_BA) expectedConj

def ce07_b : Bool :=
  match evalForestPure envAtomic [synthTruncatedT2Alt1] with
  | .trapPolicyRejected _ _ (.parserOnlyTrapProduction .T2) => true
  | _ => false

-- PAIR 08: Multi-Tree Equivalent Generator Forest (`|T| = 2`, `τ₁ ≠ τ₂`, `m₁ ≠ m₂`, `N(m₁) = N(m₂)`) Consensus
--          vs Malformed `alt = 3` `SemanticExtractionFailure` (`≠ AmbiguousReadings`, `D02`)
def pc08_b : Bool :=
  (!parseTreeEqBool synthTreeG15a_AB synthTreeG15b_BA) &&
  match extractRawMeaning envDiscourse synthTreeG15a_AB,
        extractRawMeaning envDiscourse synthTreeG15b_BA,
        evalForestPure envDiscourse [synthTreeG15a_AB, synthTreeG15b_BA] with
  | .ok m1, .ok m2, .consensus [_, _] _ => !(m1 == m2)
  | _, _, _ => false

def ce08_b : Bool :=
  match evalForestPure envAtomic [synthInvalidAlt3Tree] with
  | .semanticExtractionFailure _ err =>
    err.diag == .unsupportedReadingAlt .Trap_T1_AllNot 3
  | _ => false

-- PAIR 09: `G-04` Temporal Precedence Consensus vs Reversed `ev_aki ≺ ev_stroke` Non-Equivalence
def pc09_b : Bool :=
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG04_StrokeBeforeAki) expectedCanonG04_AB

def ce09_b : Bool :=
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG04_AkiBeforeStroke) expectedCanonG04_BA &&
  !canonicalMeaningEqBool expectedCanonG04_AB expectedCanonG04_BA

-- PAIR 10: `G-16` Contrastive Discourse Consensus vs Contrastive Side-Swap Non-Equivalence + Unresolved Anaphora
def pc10_b : Bool :=
  isConsensusSingle (runP3COnStr envDiscourse defaultParseBudget sG16)

def ce10_b : Bool :=
  let aSide := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") []
  let mSide := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "y_repeat"
    (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") []
  let cOrig := normalizeMeaning (.contrastivePair aSide mSide "exp_intens" "out_mi")
  let cSwap := normalizeMeaning (.contrastivePair mSide aSide "exp_intens" "out_mi")
  let badAnaph :=
    match evalForestPure envMismatchedDesign [synthTreeG15b_BA] with
    | .semanticExtractionFailure _ err =>
      err.diag == .unresolvedAnaphoricScope "des_study" "des_other_registry"
    | _ => false
  (!canonicalMeaningEqBool cOrig cSwap) && badAnaph

-- PAIR 11: `G-06a` Causal Directional Consensus vs Causal (`G-06a`) ≠ Assoc (`G-03`) & ≠ Neutral (`G-06b`)
def pc11_b : Bool :=
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG06a) expectedCanonG06a &&
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG03) expectedCanonG03

def ce11_b : Bool :=
  isConsensusSingleEq (runP3COnStr envAtomic defaultParseBudget sG06b) expectedCanonG06b &&
  (!canonicalMeaningEqBool expectedCanonG06a expectedCanonG03) &&
  (!canonicalMeaningEqBool expectedCanonG06a expectedCanonG06b)

-- PAIR 12: Idempotence + Conjunct/Presup Dedup vs Invalid `G-16` Contrastive Anchor Extraction Failure
def pc12_b : Bool :=
  let p := PresupItem.factiveCausal "exp_intens" "reduces" "out_mi"
  let mDup := RawSemanticTerm.symConj
    (.scopedAtom (.cohortBound "coh_primary") "b1" (.quantClaim (.universalNeg "sub_dm_pl" "ev_stroke")) [p, p])
    (.scopedAtom (.cohortBound "coh_primary") "b2" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) [p])
  let mSingle := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "b3"
    (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) [p]
  canonicalMeaningEqBool (normalizeMeaning (N mDup)) (normalizeMeaning mDup) &&
  canonicalMeaningEqBool (normalizeMeaning mDup) (normalizeMeaning mSingle)

def ce12_b : Bool :=
  match evalForestPure envDiscourse [synthBadAnchorG16Tree] with
  | .semanticExtractionFailure _ err =>
    err.diag == .invalidContrastiveAnchor .Gen_G16_DocContrastive
  | _ => false

-- PAIR 13: `G-07` Consensus vs Multi-Dot `1..25%` `UpstreamRejected (.emptyParseSet)`
def pc13_b : Bool :=
  isConsensusSingle (runP3COnStr envAtomic defaultParseBudget sG07)

def ce13_b : Bool :=
  runP3COnStr envAtomic defaultParseBudget sBadMultiDotG01 ==
    .upstreamRejected .emptyParseSet

-- PAIR 14: `G-05` Consensus vs Non-ASCII `UpstreamRejected (.outOfDomain ...)`
def pc14_b : Bool :=
  isConsensusSingle (runP3COnStr envAtomic defaultParseBudget sG05)

def ce14_b : Bool :=
  certifySemanticConsensus p3cTestCatalog frozenR22NumericConfig envAtomic defaultParseBudget
    ([0x49, 0x6E, 0x20, 0xC3, 0xA9]) ==
      .upstreamRejected (.outOfDomain (.nonPrintableAsciiByte 0xC3))

-- PAIR 15: `G-14` Covariate-Adjusted Consensus vs Tight `maxReadings = 1` on `T2` `UpstreamRejected (.resourceOverflow ...)`
def pc15_b : Bool :=
  isConsensusSingle (runP3COnStr envAtomic defaultParseBudget sG14)

def ce15_b : Bool :=
  runP3COnStr envAtomic { defaultParseBudget with maxReadings := 1 } sT2_ConfirmThat ==
    .upstreamRejected (.resourceOverflow (.maxReadingsExceeded 2 1))

/-! ### 5. Pure Kernel `decide` Proofs Across All 30 Suite Vectors (`0` `native_decide`) -/

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc01_ok : pc01_b = true := by decide
set_option maxRecDepth 16384 in theorem ce01_ok : ce01_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc02_ok : pc02_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce02_ok : ce02_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc03_ok : pc03_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce03_ok : ce03_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc04_ok : pc04_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce04_ok : ce04_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc05_ok : pc05_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce05_ok : ce05_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc06_ok : pc06_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce06_ok : ce06_b = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem pc07_ok : pc07_b = true := by decide
set_option maxRecDepth 16384 in theorem ce07_ok : ce07_b = true := by decide
set_option maxRecDepth 16384 in theorem pc08_ok : pc08_b = true := by decide
set_option maxRecDepth 16384 in theorem ce08_ok : ce08_b = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem pc09_ok : pc09_b = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem ce09_ok : ce09_b = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem pc10_ok : pc10_b = true := by decide
set_option maxRecDepth 16384 in theorem ce10_ok : ce10_b = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem pc11_ok : pc11_b = true := by decide
set_option maxHeartbeats 2000000 in
set_option maxRecDepth 16384 in theorem ce11_ok : ce11_b = true := by decide
set_option maxRecDepth 16384 in theorem pc12_ok : pc12_b = true := by decide
set_option maxRecDepth 16384 in theorem ce12_ok : ce12_b = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem pc13_ok : pc13_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce13_ok : ce13_b = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem pc14_ok : pc14_b = true := by decide
set_option maxRecDepth 16384 in theorem ce14_ok : ce14_b = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem pc15_ok : pc15_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce15_ok : ce15_b = true := by decide

structure P3CTestCase where
  caseId      : String
  pairGroup   : String
  description : String
  passed      : Bool
  verdictTag  : String
  deriving DecidableEq, Repr

def allP3CCases : List P3CTestCase :=
  [ { caseId := "PC-P3C-01", pairGroup := "PAIR-01-G01-CONSENSUS-VS-EMPIRICAL",
      description := "Valid G-01 incidence sentence reaches Consensus with unique CanonicalMeaning",
      passed := pc01_b, verdictTag := "CONSENSUS_1(G01)" },
    { caseId := "CE-P3C-01", pairGroup := "PAIR-01-G01-CONSENSUS-VS-EMPIRICAL",
      description := "G-01 Consensus holds in W_true yet fails in W_false (P3-C != P4 empirical truth)",
      passed := ce01_b, verdictTag := "AUTHORITY_SEPARATED(W_TRUE!=W_FALSE)" },
    { caseId := "PC-P3C-02", pairGroup := "PAIR-02-T1-DEMORGAN-AMBIGUITY",
      description := "Valid G-11 'no patients' Consensus matches De Morgan normal form of T1 alt=1",
      passed := pc02_b, verdictTag := "CONSENSUS_1(G11==N(T1_ALT1))" },
    { caseId := "CE-P3C-02", pairGroup := "PAIR-02-T1-DEMORGAN-AMBIGUITY",
      description := "T1 'all ... not' enumerates 2 readings with N(m1) != N(m2) -> AmbiguousReadings",
      passed := ce02_b, verdictTag := "AMBIGUOUS_2(T1)" },
    { caseId := "PC-P3C-03", pairGroup := "PAIR-03-T2-PRESUP-AMBIGUITY",
      description := "Valid G-09 'did not establish that' reaches Consensus (presups = [])",
      passed := pc03_b, verdictTag := "CONSENSUS_1(G09)" },
    { caseId := "CE-P3C-03", pairGroup := "PAIR-03-T2-PRESUP-AMBIGUITY",
      description := "T2 (Y_T08) 'did not confirm that' yields AmbiguousReadings ([] vs [factiveCausal])",
      passed := ce03_b, verdictTag := "AMBIGUOUS_2(T2)" },
    { caseId := "PC-P3C-04", pairGroup := "PAIR-04-T3-SINGLE-READING-TRAP",
      description := "Valid G-10 'did not determine whether' reaches Consensus distinct from G-09",
      passed := pc04_b, verdictTag := "CONSENSUS_1(G10!=G09)" },
    { caseId := "CE-P3C-04", pairGroup := "PAIR-04-T3-SINGLE-READING-TRAP",
      description := "T3 'did not determine why' (|T|=1) passes consensus but fails TrapPolicyPermits",
      passed := ce04_b, verdictTag := "TRAP_REJECTED_1(T3_WH_PRESUP)" },
    { caseId := "PC-P3C-05", pairGroup := "PAIR-05-T4-BARE-PLURAL-AMBIGUITY",
      description := "Valid G-13 'at least one' reaches Consensus (existentialPos)",
      passed := pc05_b, verdictTag := "CONSENSUS_1(G13)" },
    { caseId := "CE-P3C-05", pairGroup := "PAIR-05-T4-BARE-PLURAL-AMBIGUITY",
      description := "T4 bare plural yields AmbiguousReadings (genericUniversalPos vs existentialPos)",
      passed := ce05_b, verdictTag := "AMBIGUOUS_2(T4)" },
    { caseId := "PC-P3C-06", pairGroup := "PAIR-06-T5-UNSCOPED-TRAP",
      description := "Valid G-12 'some, but not all' reaches Consensus (properPart, cohortBound)",
      passed := pc06_b, verdictTag := "CONSENSUS_1(G12)" },
    { caseId := "CE-P3C-06", pairGroup := "PAIR-06-T5-UNSCOPED-TRAP",
      description := "T5 unscoped sentence (|T|=1) passes consensus but fails TrapPolicyPermits",
      passed := ce06_b, verdictTag := "TRAP_REJECTED_1(T5_UNSCOPED)" },
    { caseId := "PC-P3C-07", pairGroup := "PAIR-07-G15-PARAPHRASE-CONVERGENCE",
      description := "G-15a (A & B) and G-15b (B & Within-study A) have m1 != m2 yet identical CanonicalMeaning",
      passed := pc07_b, verdictTag := "CONSENSUS_CONVERGED(G15a==G15b)" },
    { caseId := "CE-P3C-07", pairGroup := "PAIR-07-G15-PARAPHRASE-CONVERGENCE",
      description := "Truncated 1-tree [T2:alt=1] forest rejected by independent TrapPolicyPermits",
      passed := ce07_b, verdictTag := "TRAP_REJECTED_1(TRUNCATED_T2)" },
    { caseId := "PC-P3C-08", pairGroup := "PAIR-08-MULTI-TREE-VS-EXTRACTION-ERR",
      description := "2-tree generator forest [t_G15a_AB, t_G15b_BA] (m1 != m2, N(m1)=N(m2)) reaches Consensus",
      passed := pc08_b, verdictTag := "CONSENSUS_2_TREES" },
    { caseId := "CE-P3C-08", pairGroup := "PAIR-08-MULTI-TREE-VS-EXTRACTION-ERR",
      description := "Unsupported readingAlt=3 yields SemanticExtractionFailure (never AmbiguousReadings)",
      passed := ce08_b, verdictTag := "EXTRACTION_FAILURE(ALT_3)" },
    { caseId := "PC-P3C-09", pairGroup := "PAIR-09-G04-TEMPORAL-ORDER",
      description := "Valid G-04 'stroke preceded acute kidney injury' reaches Consensus",
      passed := pc09_b, verdictTag := "CONSENSUS_1(G04_AB)" },
    { caseId := "CE-P3C-09", pairGroup := "PAIR-09-G04-TEMPORAL-ORDER",
      description := "Reversed G-04 'acute kidney injury preceded stroke' produces distinct CanonicalMeaning",
      passed := ce09_b, verdictTag := "TEMPORAL_NONCOMMUTATIVE(AB!=BA)" },
    { caseId := "PC-P3C-10", pairGroup := "PAIR-10-G16-CONTRASTIVE-ORDER",
      description := "Valid G-16 contrastive '; however, within this same study' reaches Consensus",
      passed := pc10_b, verdictTag := "CONSENSUS_1(G16)" },
    { caseId := "CE-P3C-10", pairGroup := "PAIR-10-G16-CONTRASTIVE-ORDER",
      description := "Contrastive side-swap changes CanonicalMeaning & wrong design fails extraction",
      passed := ce10_b, verdictTag := "CONTRASTIVE_NONCOMM_AND_ANAPHORA_ERR" },
    { caseId := "PC-P3C-11", pairGroup := "PAIR-11-CAUSAL-VS-ASSOC-MODALITY",
      description := "Valid G-06a directional causal claim reaches Consensus",
      passed := pc11_b, verdictTag := "CONSENSUS_1(G06a)" },
    { caseId := "CE-P3C-11", pairGroup := "PAIR-11-CAUSAL-VS-ASSOC-MODALITY",
      description := "G-06a causal != G-03 associative and G-06a directional != G-06b neutral",
      passed := ce11_b, verdictTag := "MODALITY_PRESERVED(G06a!=G03!=G06b)" },
    { caseId := "PC-P3C-12", pairGroup := "PAIR-12-IDEMPOTENCE-AND-DEDUP",
      description := "N(N(m)) == N(m) and duplicate conjuncts/presuppositions collapse to canonical singleton",
      passed := pc12_b, verdictTag := "IDEMPOTENT_AND_DEDUPED" },
    { caseId := "CE-P3C-12", pairGroup := "PAIR-12-IDEMPOTENCE-AND-DEDUP",
      description := "Malformed G-16 mismatched contrastive outcome anchor fails with SemanticExtractionFailure",
      passed := ce12_b, verdictTag := "EXTRACTION_FAILURE(BAD_ANCHOR)" },
    { caseId := "PC-P3C-13", pairGroup := "PAIR-13-UPSTREAM-EMPTY-PARSE",
      description := "Valid G-07 'not statistically significant' reaches Consensus",
      passed := pc13_b, verdictTag := "CONSENSUS_1(G07)" },
    { caseId := "CE-P3C-13", pairGroup := "PAIR-13-UPSTREAM-EMPTY-PARSE",
      description := "Lexically invalid 1..25% yields UpstreamRejected(.emptyParseSet)",
      passed := ce13_b, verdictTag := "UPSTREAM_REJECTED(EMPTY_PARSE)" },
    { caseId := "PC-P3C-14", pairGroup := "PAIR-14-UPSTREAM-OUT-OF-DOMAIN",
      description := "Valid G-05 absolute risk difference reaches Consensus",
      passed := pc14_b, verdictTag := "CONSENSUS_1(G05)" },
    { caseId := "CE-P3C-14", pairGroup := "PAIR-14-UPSTREAM-OUT-OF-DOMAIN",
      description := "Non-7-bit-ASCII input yields UpstreamRejected(.outOfDomain)",
      passed := ce14_b, verdictTag := "UPSTREAM_REJECTED(OUT_OF_DOMAIN)" },
    { caseId := "PC-P3C-15", pairGroup := "PAIR-15-UPSTREAM-RESOURCE-OVERFLOW",
      description := "Valid G-14 covariate-adjusted association reaches Consensus",
      passed := pc15_b, verdictTag := "CONSENSUS_1(G14)" },
    { caseId := "CE-P3C-15", pairGroup := "PAIR-15-UPSTREAM-RESOURCE-OVERFLOW",
      description := "Tight maxReadings=1 on T2 yields UpstreamRejected(.resourceOverflow)",
      passed := ce15_b, verdictTag := "UPSTREAM_REJECTED(RESOURCE_OVERFLOW)" } ]

/-- **Master Suite Theorem (`all_30_p3c_suite_cases_pass`)**: Every single `(PC, CE)` vector holds! -/
theorem all_30_p3c_suite_cases_pass :
    ∀ tc ∈ allP3CCases, tc.passed = true := by
  apply (list_all_eq_true (·.passed) allP3CCases).mp
  dsimp only [allP3CCases, List.all]
  rw [pc01_ok, ce01_ok, pc02_ok, ce02_ok, pc03_ok, ce03_ok, pc04_ok, ce04_ok,
      pc05_ok, ce05_ok, pc06_ok, ce06_ok, pc07_ok, ce07_ok, pc08_ok, ce08_ok,
      pc09_ok, ce09_ok, pc10_ok, ce10_ok, pc11_ok, ce11_ok, pc12_ok, ce12_ok,
      pc13_ok, ce13_ok, pc14_ok, ce14_ok, pc15_ok, ce15_ok]
  rfl

end PneumaOmega.P3C.Counterexamples
