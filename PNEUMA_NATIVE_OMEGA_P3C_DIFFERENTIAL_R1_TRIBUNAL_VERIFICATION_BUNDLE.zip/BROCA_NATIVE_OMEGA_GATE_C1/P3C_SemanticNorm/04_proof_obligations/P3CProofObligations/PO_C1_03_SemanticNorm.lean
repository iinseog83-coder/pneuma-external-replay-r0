/-
  PNEUMA-NATIVE Ω — AUTH-C1-P3-C (`PO-C1-03`: Canonical Proof Obligations & Governance Locks)
  04_proof_obligations/P3CProofObligations/PO_C1_03_SemanticNorm.lean
  Pure Lean 4.33.1 Core (`Init` + read-only Legacy BROCA `P2`, `P3-A`, `P3-B`, zero `sorry`)

  Exports all canonical machine-checked obligations for `AUTH-C1-P3-C` (`PO-C1-03`, `D01`, `D02`, `D03`)
  together with explicit scope-boundary / `HELD` / `NOT_AUTHORIZED` locks.
-/
import P3CCounterexamples

namespace PneumaOmega.P3C.ProofObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples

/-! ### 1. Explicit Governance & Scope-Boundary Locks (`AUTH-C1-P3-C`) -/

inductive P3CGovernanceLock where
  | _P1_P2_P3A_P3B_SCOPED_ACCEPTED_AND_FROZEN
  | _PRIOR_EXTERNAL_KERNEL_REPLAY_HELD
  | _G01_RIGHT_CENSORED_KM_AJ_HELD_UNSPECIFIED_IN_R0
  | _FULL_GRAMMAR_SEMANTIC_EQUIVALENCE_HELD
  | _GLOBAL_ADMISSION_NONBYPASS_HELD
  | _PNEUMA_FINITE_OPERATOR_R0_NOT_AUTHORIZED
  | _P4_EMPIRICAL_EVIDENCE_GATE_NOT_AUTHORIZED
  | _P5_CERTIFIED_OUTPUT_ADMISSION_NOT_AUTHORIZED
  | _PNEUMA_SPEECH_AND_LISTENER_NOT_AUTHORIZED
  deriving DecidableEq, Repr

/-! ### 2. `F-P3C-D01`: Independent Semantics (`SemEq`, `Denotes`) & Canonical Normalizer (`N`) -/

/-- `D01.0`: Model-theoretic soundness of `SemEq` (`m₁ ∼_sem m₂ → Denotes W m₁ ↔ Denotes W m₂`) with zero call to `N`. -/
theorem PO_C1_03_D01_SemEqSoundForDenotes {m₁ m₂ : RawSemanticTerm}
    (h : SemEq m₁ m₂) (W : SemanticWorld) (hExt : ExtensionalContrastiveWorld W) :
    Denotes W m₁ ↔ Denotes W m₂ :=
  semEq_sound_for_denotes h W hExt

/-- `D01.1`: Total termination of `normalizeMeaning`. -/
theorem PO_C1_03_D01_NormalizerTerminates (m : RawSemanticTerm) :
    ∃ c : CanonicalMeaning, normalizeMeaning m = c :=
  normalizeMeaning_terminates m

/-- `D01.2`: Meaning preservation (`SemEq (N m) m` and `Denotes W (N m) ↔ Denotes W m`). -/
theorem PO_C1_03_D01_NormalizerPreservesMeaning (m : RawSemanticTerm) :
    SemEq (N m) m ∧
    ∀ W : SemanticWorld, ExtensionalContrastiveWorld W → (Denotes W (N m) ↔ Denotes W m) :=
  ⟨N_preserves_SemEq m, fun W hExt => N_preserves_Denotes m W hExt⟩

/-- `D01.3`: Strict idempotence (`N (N m) = N m` and `normalizeMeaning (N m) = normalizeMeaning m`). -/
theorem PO_C1_03_D01_NormalizerIdempotent (m : RawSemanticTerm) :
    N (N m) = N m ∧ normalizeMeaning (N m) = normalizeMeaning m :=
  ⟨N_idempotent m, normalizeMeaning_embed_id m⟩

/-- `D01.4`: Canonical normal form characterization (`IsCanonicalNorm m ↔ N m = m`). -/
theorem PO_C1_03_D01_CanonicalCharacterization (m : RawSemanticTerm) :
    IsCanonicalNorm m ↔ N m = m :=
  isCanonicalNorm_iff_fixedPoint m

/-- `D01.5`: Exact two-way equivalence (`SemEq m₁ m₂ ↔ normalizeMeaning m₁ = normalizeMeaning m₂`). -/
theorem PO_C1_03_D01_SemEqIffNormalFormEq (m₁ m₂ : RawSemanticTerm) :
    SemEq m₁ m₂ ↔ normalizeMeaning m₁ = normalizeMeaning m₂ :=
  semEq_iff_normalizeMeaning_eq m₁ m₂

/-- `D01.6`: Concrete model-theoretic refutations (`¬ SemEq`) on `T1`, `T2`, `T4`, and `G-04` temporal swap. -/
theorem PO_C1_03_D01_SemanticRefutations
    (sc : SemanticScope) (sg ev src act vb out metric dir ref est ciL ciLo ciHi : String)
    (hneEv : sg ≠ ev) :
    (¬ SemEq (.scopedAtom sc "x" (.quantClaim (.universalNeg sg ev)) [])
             (.scopedAtom sc "x" (.quantClaim (.negUniversal sg ev)) [])) ∧
    (¬ SemEq (.scopedAtom sc "x" (.metaNonEstab src act vb out) [])
             (.scopedAtom sc "x" (.metaNonEstab src act vb out) [.factiveCausal act vb out])) ∧
    (¬ SemEq (.scopedAtom sc "x" (.quantClaim (.genericUniversalPos sg ev)) [])
             (.scopedAtom sc "x" (.quantClaim (.existentialPos sg ev)) [])) ∧
    (¬ SemEq (.scopedAtom sc "x" (.assocClaim metric dir act ref out none (some (sg, ev)) est ciL ciLo ciHi) [])
             (.scopedAtom sc "x" (.assocClaim metric dir act ref out none (some (ev, sg)) est ciL ciLo ciHi) [])) :=
  ⟨not_semEq_T1_dual_readings sc sg ev,
   not_semEq_T2_dual_readings sc src act vb out,
   not_semEq_T4_dual_readings sc sg ev,
   not_semEq_G04_temporal_reversal sc sg ev metric dir act ref out est ciL ciLo ciHi hneEv⟩

/-! ### 3. `F-P3C-D02` & `F-P3C-D03`: Direct `P3-B → P3-C` 5-Way Gate, Trap Policy & Authority Separation -/

/-- `D02` + `D03` Master Consensus Soundness over `BrocaOmega.P3B.parseAllBounded`. -/
theorem PO_C1_03_D02_EndToEndConsensusSound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree) (c : CanonicalMeaning)
    (h : certifySemanticConsensus cat numCfg env budget rawBytes = .consensus T c) :
    parseAllBounded cat numCfg env budget rawBytes = .enumerated T ∧
    StrictAsciiDomainSupported rawBytes ∧
    T ≠ [] ∧
    NoDupTrees T ∧
    (∀ τ : ConcreteParseTree, τ ∈ T ↔ ValidParse_GFrozen cat numCfg env rawBytes τ) ∧
    TrapPolicyPermitsForest T ∧
    IsCanonicalNorm (embedCanonical c) ∧
    (∃ pairs : List (ConcreteParseTree × RawSemanticTerm),
       extractAllMeanings env T = .ok pairs ∧
       pairs.map Prod.fst = T ∧
       UniversalConsensus pairs c ∧
       ∀ p ∈ pairs, extractRawMeaning env p.1 = .ok p.2 ∧ SemEq (embedCanonical c) p.2) :=
  certifySemanticConsensus_sound cat numCfg env budget rawBytes T c h

/-- `D02` Ambiguity Refutation Soundness (`AmbiguousReadings ⟹ ¬ SemEq raw1 raw2`). -/
theorem PO_C1_03_D02_EndToEndAmbiguityRefutation
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree) (w : AmbiguityRefutationWitness)
    (h : certifySemanticConsensus cat numCfg env budget rawBytes = .ambiguousReadings T w) :
    ValidParse_GFrozen cat numCfg env rawBytes w.tree1 ∧
    ValidParse_GFrozen cat numCfg env rawBytes w.tree2 ∧
    extractRawMeaning env w.tree1 = .ok w.raw1 ∧
    extractRawMeaning env w.tree2 = .ok w.raw2 ∧
    w.norm1 ≠ w.norm2 ∧
    ¬ SemEq w.raw1 w.raw2 :=
  certifySemanticConsensus_ambiguous_sound cat numCfg env budget rawBytes T w h

/-- `D02` Extraction Failure Soundness (strictly separated from `AmbiguousReadings` and `Consensus`). -/
theorem PO_C1_03_D02_ExtractionFailureSound
    (env : ScopeEnv) (T : List ConcreteParseTree) (err : ForestExtractionError)
    (h : evaluateForestConsensus env T = .semanticExtractionFailure err) :
    err.failedTree ∈ T ∧ extractRawMeaning env err.failedTree = .error err.diag :=
  evaluateForestConsensus_extractionFailure_sound env T err h

/-- `D03` Trap Policy Independence (`UniversalConsensus` holds while `¬ TrapPolicyPermitsForest` rejects). -/
theorem PO_C1_03_D03_IndependentTrapRejectionSound
    (env : ScopeEnv) (T : List ConcreteParseTree) (c : CanonicalMeaning) (diag : TrapPolicyDiag)
    (h : evaluateForestConsensus env T = .trapPolicyRejected c diag) :
    (∃ pairs, extractAllMeanings env T = .ok pairs ∧ UniversalConsensus pairs c) ∧
    ¬ TrapPolicyPermitsForest T :=
  evaluateForestConsensus_trapRejected_sound env T c diag h

/-- `D02` Upstream Fail-Closed (`OutOfDomain`, `ResourceOverflow`, `Enumerated []` → `upstreamRejected`). -/
theorem PO_C1_03_D02_UpstreamFailClosed
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) :
    (∀ d, parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d →
          certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected (.outOfDomain d)) ∧
    (∀ b, parseAllBounded cat numCfg env budget rawBytes = .resourceOverflow b →
          certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected (.resourceOverflow b)) ∧
    (parseAllBounded cat numCfg env budget rawBytes = .enumerated [] →
          certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected .emptyParseSet) :=
  certifySemanticConsensus_upstream_failClosed cat numCfg env budget rawBytes

/-- `D03` Authority Separation (`SemanticConsensusCertificate` does NOT certify empirical clinical truth). -/
theorem PO_C1_03_D03_AuthoritySeparation
    (coh win ev k n pct : String) :
    let c : CanonicalMeaning :=
      normalizeMeaning (.scopedAtom (.cohortBound coh) "x_init" (.descIncidence win ev k n pct) [])
    ∃ (W_true W_false : SemanticWorld),
      ExtensionalContrastiveWorld W_true ∧
      ExtensionalContrastiveWorld W_false ∧
      Denotes W_true (embedCanonical c) ∧
      ¬ Denotes W_false (embedCanonical c) :=
  consensus_does_not_certify_empirical_truth coh win ev k n pct

/-- Concrete 30-Vector `(PC, CE)` Suite Closure (`15` pairs, pure kernel `decide`). -/
theorem PO_C1_03_SymmetricSuiteVerified :
    ValidEntityCatalog p3cTestCatalog ∧
    (∀ tc ∈ allP3CCases, tc.passed = true) :=
  ⟨p3cTestCatalog_valid, all_30_p3c_suite_cases_pass⟩

end PneumaOmega.P3C.ProofObligations
