#!/usr/bin/env python3
"""
PNEUMA-NATIVE OMEGA — AUTH-C1-P3-C Independent Clean-Room Differential Oracle
05_independent_tribunal/differential_oracle_p3c.py
Python 3.11 Standard Library Only (zero external packages)

Verifies true 1-to-1 input-by-input equivalence (`Result_Lean(x) == Result_Python(x)`):
  1. Fixed 30-vector `(PC, CE)` suite exported by `p3c_tribunal_runner.exe --export-fixed-json`.
  2. External 250-vector serialized TSV batch evaluated identically by BOTH this clean-room
     Python 3.11 full pipeline (parser + semantic extractor + canonical normalizer + 5-way
     consensus/trap gate) AND `p3c_tribunal_runner.exe --eval-batch <tsv_path>`, comparing
     the COMPLETE serialized `CanonicalMeaning` normal form string on every vector!
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Optional, Tuple


# ---------------------------------------------------------------------------
# 1. Clean-Room P3-A Strict Lexical Gate & P3-C Reference Catalog
# ---------------------------------------------------------------------------

RESERVED_DELIMITERS: List[str] = [
    ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same",
    "In ", " why ", " how ",
]

OPEN_ENTITY_SORTS = {
    "cohortSpec", "designNoun", "followUpWindow", "eventTerm", "measureTerm",
    "expLevel", "outTerm", "sourceId", "identAssump", "subgroupPlural",
    "subgroupSingular", "covariateList",
}

CLOSED_FUNCTIONAL_ENTRIES: List[Tuple[str, str, str]] = [
    ("assocDir",       "positively", "positively"),
    ("assocDir",       "inversely",  "inversely"),
    ("ratioMetric",    "rr",         "risk ratio"),
    ("ratioMetric",    "or",         "odds ratio"),
    ("ratioMetric",    "hr",         "hazard ratio"),
    ("intervDirVerb",  "increase",   "increase"),
    ("intervDirVerb",  "reduce",     "reduce"),
    ("intervVerbPres", "causes",     "causes"),
    ("intervVerbPres", "increases",  "increases"),
    ("intervVerbPres", "reduces",    "reduces"),
    ("epistemicVerb",  "establish",  "establish"),
    ("epistemicVerb",  "determine",  "determine"),
    ("epistemicVerb",  "confirm",    "confirm"),
    ("epistemicVerb",  "reveal",     "reveal"),
    ("whWord",         "why",        "why"),
    ("whWord",         "how",        "how"),
]

P3C_TEST_CATALOG: List[Tuple[str, str, str]] = [
    ("cohortSpec",       "coh_primary",  "the primary cohort"),
    ("designNoun",       "des_study",    "study"),
    ("followUpWindow",   "win_12m",      "12 months"),
    ("eventTerm",        "ev_stroke",    "stroke"),
    ("eventTerm",        "ev_aki",       "acute kidney injury"),
    ("measureTerm",      "meas_sbp",     "systolic blood pressure"),
    ("expLevel",         "exp_intens",   "intensive therapy"),
    ("expLevel",         "exp_std",      "standard care"),
    ("outTerm",          "out_mi",       "myocardial infarction"),
    ("outTerm",          "out_death",    "all-cause mortality"),
    ("sourceId",         "src_trialA",   "Trial-A"),
    ("identAssump",      "assump_exch",  "conditional exchangeability"),
    ("subgroupPlural",   "sub_dm_pl",    "diabetic"),
    ("subgroupSingular", "sub_hr_sg",    "high-risk"),
    ("covariateList",    "cov_age_risk", "age and baseline risk"),
]


def is_printable_ascii_str(s: str) -> bool:
    return len(s) > 0 and all(0x20 <= ord(c) <= 0x7E for c in s)


def has_trimmed_spaces(s: str) -> bool:
    return len(s) > 0 and s[0] != " " and s[-1] != " "


def check_valid_catalog(entries: List[Tuple[str, str, str]]) -> bool:
    for srt, eid, lex in entries:
        if srt not in OPEN_ENTITY_SORTS:
            return False
        if not is_printable_ascii_str(eid) or not is_printable_ascii_str(lex):
            return False
        if not has_trimmed_spaces(lex):
            return False
        if any(bad in lex for bad in RESERVED_DELIMITERS):
            return False
    for s1, id1, l1 in entries:
        for s2, id2, l2 in entries:
            if s1 == s2 and id1 == id2 and l1 != l2:
                return False
            if l1 == l2 and (s1, id1, l1) != (s2, id2, l2):
                return False
    return True


def is_canonical_decimal(s: str, max_int: int = 7, max_frac: int = 4) -> bool:
    if not s or s[0] == "+":
        return False
    neg = False
    body = s
    if s[0] == "-":
        neg = True
        body = s[1:]
    if not body:
        return False
    if any(not (("0" <= c <= "9") or c == ".") for c in body):
        return False
    parts = body.split(".")
    if len(parts) > 2:
        return False
    int_part = parts[0]
    if not int_part:
        return False
    if len(int_part) > 1 and int_part[0] == "0":
        return False
    if len(int_part) > max_int:
        return False
    frac_part = ""
    if len(parts) == 2:
        frac_part = parts[1]
        if not frac_part or len(frac_part) > max_frac:
            return False
    abs_val = int(int_part + frac_part)
    if neg and abs_val == 0:
        return False
    return True


CATALOG_IS_VALID = check_valid_catalog(P3C_TEST_CATALOG)


def valid_slot_entity_ids(max_slot_bytes: int, srt: str, lex: str) -> List[str]:
    if not lex or len(lex) > max_slot_bytes:
        return []
    if not is_printable_ascii_str(lex) or not has_trimmed_spaces(lex):
        return []
    if srt in OPEN_ENTITY_SORTS:
        cands = [eid for (es, eid, el) in P3C_TEST_CATALOG if es == srt and el == lex]
    elif srt == "numericLit":
        cands = [lex]
    else:
        cands = [eid for (es, eid, el) in CLOSED_FUNCTIONAL_ENTRIES if es == srt and el == lex]

    out: List[str] = []
    for eid in cands:
        if not is_printable_ascii_str(eid):
            continue
        if srt in OPEN_ENTITY_SORTS:
            if any(bad in lex for bad in RESERVED_DELIMITERS):
                continue
            if CATALOG_IS_VALID and (srt, eid, lex) in P3C_TEST_CATALOG:
                out.append(eid)
        elif srt == "numericLit":
            if eid == lex and is_canonical_decimal(lex, 7, 4):
                out.append(eid)
        else:
            if (srt, eid, lex) in CLOSED_FUNCTIONAL_ENTRIES:
                out.append(eid)
    return out


# ---------------------------------------------------------------------------
# 2. Clean-Room Frozen 34-Production Grammar (`G-01`~`G-16` + `T1`~`T5`)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SymTerm:
    lit: str


@dataclass(frozen=True)
class SymSlot:
    sort: str
    tag: str


@dataclass(frozen=True)
class SymNonterm:
    nt: str
    clause_idx: int


Symbol = SymTerm | SymSlot | SymNonterm


@dataclass(frozen=True)
class ParseSummaryPy:
    cohort_id: Optional[str] = None
    design_id: Optional[str] = None
    exp_out_pair: Optional[Tuple[str, str]] = None
    embedded_key: Optional[str] = None
    starts_in_within: bool = False


@dataclass(frozen=True)
class ScopeEnvPy:
    cohort_id: str
    expected_design_head: str
    quote_isolation: str


def lookup_tag(slots: List[Tuple[str, str]], tag: str) -> str:
    for k, v in slots:
        if k == tag:
            return v
    return ""


@dataclass(frozen=True)
class ProdSpecPy:
    name: str
    owner_rule: Optional[str]
    is_generator: bool
    alt_count: int
    lhs: str
    rhs: Tuple[Symbol, ...]
    check_side: Callable[[ScopeEnvPy, List[Tuple[str, str]], List[ParseSummaryPy]], bool]
    mk_sum: Callable[[List[Tuple[str, str]], List[ParseSummaryPy]], ParseSummaryPy]


FROZEN_PRODS: List[ProdSpecPy] = [
    ProdSpecPy(
        "Env_DocSingle", None, True, 1, "controlledDocument",
        (SymNonterm("scopedInitial", 1), SymTerm(".")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_ScopedInitial", None, True, 1, "scopedInitial",
        (SymTerm("In "), SymSlot("cohortSpec", "cohort"), SymTerm(", "), SymNonterm("atomicCore", 0)),
        lambda env, s, _c: lookup_tag(s, "cohort") == env.cohort_id,
        lambda s, c: ParseSummaryPy(
            cohort_id=lookup_tag(s, "cohort"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_ScopedRepeat", None, True, 1, "scopedRepeat",
        (SymTerm("Within this same "), SymSlot("designNoun", "design"), SymTerm(", "), SymNonterm("atomicCore", 0)),
        lambda env, s, _c: lookup_tag(s, "design") == env.expected_design_head,
        lambda s, c: ParseSummaryPy(
            design_id=lookup_tag(s, "design"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_ScopedAssoc", None, True, 1, "scopedAssoc",
        (SymTerm("In "), SymSlot("cohortSpec", "cohort"), SymTerm(", "), SymNonterm("assocCore", 0)),
        lambda env, s, _c: lookup_tag(s, "cohort") == env.cohort_id,
        lambda s, c: ParseSummaryPy(
            cohort_id=lookup_tag(s, "cohort"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_ScopedContrastMeta", None, True, 1, "scopedContrastMeta",
        (SymTerm("within this same "), SymSlot("designNoun", "design"), SymTerm(", "), SymNonterm("metaNonEstabCore", 0)),
        lambda env, s, _c: lookup_tag(s, "design") == env.expected_design_head,
        lambda s, c: ParseSummaryPy(
            design_id=lookup_tag(s, "design"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_LiftAssoc", None, True, 1, "atomicCore",
        (SymNonterm("assocCore", 0),),
        lambda _e, _s, _c: True,
        lambda _s, c: c[0] if len(c) == 1 else ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_LiftMeta", None, True, 1, "atomicCore",
        (SymNonterm("metaNonEstabCore", 0),),
        lambda _e, _s, _c: True,
        lambda _s, c: c[0] if len(c) == 1 else ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_EmbeddedCausal", None, True, 1, "embeddedCausal",
        (SymSlot("expLevel", "activeExp"), SymTerm(" "), SymSlot("intervVerbPres", "verb"), SymTerm(" "), SymSlot("outTerm", "outcome")),
        lambda _e, _s, _c: True,
        lambda s, _c: ParseSummaryPy(
            exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome")),
            embedded_key=f"{lookup_tag(s, 'activeExp')}:{lookup_tag(s, 'verb')}:{lookup_tag(s, 'outcome')}",
        ),
    ),
    ProdSpecPy(
        "Gen_G01_DescIncidence", "G01", True, 1, "atomicCore",
        (SymTerm("over "), SymSlot("followUpWindow", "window"), SymTerm(", the cumulative incidence of "),
         SymSlot("eventTerm", "eventA"), SymTerm(" was "), SymSlot("numericLit", "numK"),
         SymTerm(" of "), SymSlot("numericLit", "numN"), SymTerm(" patients ("),
         SymSlot("numericLit", "numPct"), SymTerm("%)")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G02a_DescMeanSD", "G02", True, 1, "atomicCore",
        (SymTerm("the mean "), SymSlot("measureTerm", "measure"), SymTerm(" was "),
         SymSlot("numericLit", "numEst"), SymTerm(" (SD "), SymSlot("numericLit", "numDisp1"), SymTerm(")")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G02b_DescMedianIQR", "G02", True, 1, "atomicCore",
        (SymTerm("the median "), SymSlot("measureTerm", "measure"), SymTerm(" was "),
         SymSlot("numericLit", "numEst"), SymTerm(" (IQR "), SymSlot("numericLit", "numDisp1"),
         SymTerm(" to "), SymSlot("numericLit", "numDisp2"), SymTerm(")")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G03_AssocUnadj", "G03", True, 1, "assocCore",
        (SymTerm("comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("assocDir", "direction"),
         SymTerm(" associated with "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda s, _c: ParseSummaryPy(exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome"))),
    ),
    ProdSpecPy(
        "Gen_G04_AssocTemp", "G04", True, 1, "assocCore",
        (SymSlot("eventTerm", "eventA"), SymTerm(" preceded "), SymSlot("eventTerm", "eventB"),
         SymTerm(", and comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("assocDir", "direction"),
         SymTerm(" associated with "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: (lookup_tag(s, "eventA") != lookup_tag(s, "eventB")) and (lookup_tag(s, "activeExp") != lookup_tag(s, "refExp")),
        lambda s, _c: ParseSummaryPy(exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome"))),
    ),
    ProdSpecPy(
        "Gen_G05_CompRD", "G05", True, 1, "atomicCore",
        (SymTerm("the absolute risk difference in "), SymSlot("outTerm", "outcome"),
         SymTerm(" comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("numericLit", "numEst"),
         SymTerm(" percentage points ("), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G06a_IntervDirectional", "G06", True, 1, "atomicCore",
        (SymTerm("under "), SymSlot("identAssump", "assumption"), SymTerm(", comparing "),
         SymSlot("expLevel", "activeExp"), SymTerm(" versus "), SymSlot("expLevel", "refExp"),
         SymTerm(" was estimated to "), SymSlot("intervDirVerb", "verb"), SymTerm(" "),
         SymSlot("outTerm", "outcome"), SymTerm(" ("), SymSlot("ratioMetric", "metric1"),
         SymTerm(" = "), SymSlot("numericLit", "numEst"), SymTerm(", "),
         SymSlot("numericLit", "numCILevel"), SymTerm("% CI "), SymSlot("numericLit", "numCILow"),
         SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(", p = "),
         SymSlot("numericLit", "numPVal"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G06b_IntervNeutral", "G06", True, 1, "atomicCore",
        (SymTerm("under "), SymSlot("identAssump", "assumption"), SymTerm(", the estimated causal "),
         SymSlot("ratioMetric", "metric1"), SymTerm(" for "), SymSlot("outTerm", "outcome"),
         SymTerm(" comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("numericLit", "numEst"),
         SymTerm(" ("), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"),
         SymTerm("), which did not exclude no effect")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G07_MetaNotStatSig", "G07", True, 1, "atomicCore",
        (SymTerm("the observed "), SymSlot("ratioMetric", "metric1"), SymTerm(" comparing "),
         SymSlot("expLevel", "activeExp"), SymTerm(" versus "), SymSlot("expLevel", "refExp"),
         SymTerm(" for "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric2"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"),
         SymTerm(") was not statistically significant at alpha = "), SymSlot("numericLit", "numAlpha")),
        lambda _e, s, _c: (lookup_tag(s, "metric1") == lookup_tag(s, "metric2")) and (lookup_tag(s, "activeExp") != lookup_tag(s, "refExp")),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G08_MetaEquiv", "G08", True, 1, "atomicCore",
        (SymTerm("comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" met prespecified equivalence margins ("),
         SymSlot("numericLit", "numMarginLow"), SymTerm(" to "), SymSlot("numericLit", "numMarginHigh"),
         SymTerm(") for "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% TOST CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G09_MetaNonEstab", "G09", True, 1, "metaNonEstabCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not establish that "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, c: ParseSummaryPy(exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None),
    ),
    ProdSpecPy(
        "Gen_G10_MetaUnresolved", "G10", True, 1, "atomicCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not determine whether "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G11_QuantZero", "G11", True, 1, "atomicCore",
        (SymTerm("no "), SymSlot("subgroupPlural", "subgroup"),
         SymTerm(" patients developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G12_QuantProperPart", "G12", True, 1, "atomicCore",
        (SymTerm("some, but not all, "), SymSlot("subgroupPlural", "subgroup"),
         SymTerm(" patients developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G13_QuantAtLeastOne", "G13", True, 1, "atomicCore",
        (SymTerm("at least one "), SymSlot("subgroupSingular", "subgroup"),
         SymTerm(" patient developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G14_AssocAdj", "G14", True, 1, "assocCore",
        (SymTerm("after adjustment for "), SymSlot("covariateList", "covariates"),
         SymTerm(", comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("assocDir", "direction"),
         SymTerm(" associated with "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda s, _c: ParseSummaryPy(exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome"))),
    ),
    ProdSpecPy(
        "Gen_G15a_DocConjAtomic", "G15", True, 1, "controlledDocument",
        (SymNonterm("scopedInitial", 1), SymTerm(". "), SymNonterm("scopedInitial", 2), SymTerm(".")),
        lambda env, _s, c: len(c) == 2 and env.quote_isolation == "sentenceAtomic" and c[0].cohort_id == env.cohort_id and c[1].cohort_id == env.cohort_id,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G15b_DocConjDiscourse", "G15", True, 1, "controlledDocument",
        (SymNonterm("scopedInitial", 1), SymTerm(". "), SymNonterm("scopedRepeat", 2), SymTerm(".")),
        lambda env, _s, c: len(c) == 2 and env.quote_isolation == "discourseBound" and c[0].cohort_id == env.cohort_id and c[1].design_id == env.expected_design_head,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G16_DocContrastive", "G16", True, 1, "controlledDocument",
        (SymNonterm("scopedAssoc", 1), SymTerm("; however, "), SymNonterm("scopedContrastMeta", 2), SymTerm(".")),
        lambda env, _s, c: (
            len(c) == 2
            and c[0].cohort_id == env.cohort_id
            and c[1].design_id == env.expected_design_head
            and c[0].exp_out_pair is not None
            and c[0].exp_out_pair == c[1].exp_out_pair
        ),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_DocTrapScoped", None, False, 1, "controlledDocument",
        (SymNonterm("scopedTrapClause", 1), SymTerm(".")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_ScopedTrap", None, False, 1, "scopedTrapClause",
        (SymTerm("In "), SymSlot("cohortSpec", "cohort"), SymTerm(", "), SymNonterm("trapCore", 0)),
        lambda env, s, _c: lookup_tag(s, "cohort") == env.cohort_id,
        lambda s, _c: ParseSummaryPy(cohort_id=lookup_tag(s, "cohort"), starts_in_within=True),
    ),
    ProdSpecPy(
        "Trap_T1_AllNot", "T1", False, 2, "trapCore",
        (SymTerm("all "), SymSlot("subgroupPlural", "subgroup"),
         SymTerm(" patients did not develop "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Trap_T2_ConfirmThat", "T2", False, 2, "trapCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not confirm that "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, c: ParseSummaryPy(exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None),
    ),
    ProdSpecPy(
        "Trap_T3_WhPresup", "T3", False, 1, "trapCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not "), SymSlot("epistemicVerb", "verb"),
         SymTerm(" "), SymSlot("whWord", "whComp"), SymTerm(" "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, c: ParseSummaryPy(exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None),
    ),
    ProdSpecPy(
        "Trap_T4_BarePlural", "T4", False, 2, "trapCore",
        (SymSlot("subgroupPlural", "subgroup"), SymTerm(" patients developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Trap_T5_UnscopedDoc", "T5", False, 1, "controlledDocument",
        (SymNonterm("atomicCore", 1), SymTerm(".")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
]


# ---------------------------------------------------------------------------
# 3. Clean-Room Metered Bounded Exhaustive Parser (`parse_all_bounded_trees_py`)
# ---------------------------------------------------------------------------

class OverflowEx(Exception):
    def __init__(self, tag: str) -> None:
        super().__init__(tag)
        self.tag = tag


@dataclass(frozen=True)
class TreeNodePy:
    prod_name: str
    reading_alt: int
    locus: str
    span: Tuple[int, int]
    args: Tuple[object, ...]


def candidate_splits_py(y: str, cursor: int, end_pos: int, rest_syms: Tuple[Symbol, ...]) -> List[int]:
    if not rest_syms:
        return [end_pos] if cursor <= end_pos else []
    head = rest_syms[0]
    if isinstance(head, SymTerm):
        lit = head.lit
        n = len(lit)
        if end_pos < cursor:
            return []
        return [
            mid for mid in range(cursor, end_pos + 1)
            if mid + n <= end_pos and y[mid:mid + n] == lit
        ]
    if end_pos < cursor:
        return []
    return list(range(cursor, end_pos + 1))


def parse_all_bounded_trees_py(
    env: ScopeEnvPy,
    max_bytes: int,
    max_steps: int,
    max_forest_nodes: int,
    max_readings: int,
    raw_bytes: bytes,
) -> Tuple[str, Optional[List[TreeNodePy]]]:
    if len(raw_bytes) == 0:
        return ("OOD_EMPTY", None)
    for b in raw_bytes:
        if b < 0x20 or b > 0x7E:
            return (f"OOD_BYTE_{b}", None)
    if len(raw_bytes) > max_bytes:
        return (f"OVF_BYTES_{len(raw_bytes)}_{max_bytes}", None)

    y = raw_bytes.decode("ascii")
    steps_used = 0
    nodes_used = 0

    def tick_step() -> None:
        nonlocal steps_used
        steps_used += 1
        if steps_used > max_steps:
            raise OverflowEx(f"OVF_STEPS_{max_steps}")

    def tick_nodes(k: int) -> None:
        nonlocal nodes_used
        nodes_used += k
        if nodes_used > max_forest_nodes:
            raise OverflowEx(f"OVF_NODES_{max_forest_nodes}")

    def clause_override(c_idx: int, loc: str) -> str:
        if c_idx == 1:
            return "clause1"
        if c_idx == 2:
            return "clause2"
        return loc

    def enum_segs(
        child_fuel: int, loc: str, cursor: int, syms: Tuple[Symbol, ...], end_pos: int
    ) -> List[Tuple[Tuple[object, ...], List[Tuple[str, str]], List[ParseSummaryPy]]]:
        tick_step()
        if not syms:
            if cursor <= len(y) and end_pos == cursor:
                return [((), [], [])]
            return []
        sym = syms[0]
        rest = syms[1:]
        if isinstance(sym, SymTerm):
            lit = sym.lit
            end_lit = cursor + len(lit)
            if end_lit <= len(y) and y[cursor:end_lit] == lit:
                tails = enum_segs(child_fuel, loc, end_lit, rest, end_pos)
                return [
                    ((("LIT", lit, (cursor, end_lit)),) + r_args, r_slots, r_sums)
                    for (r_args, r_slots, r_sums) in tails
                ]
            return []
        if isinstance(sym, SymSlot):
            if end_pos <= len(y):
                out = []
                for mid in candidate_splits_py(y, cursor, end_pos, rest):
                    if cursor <= mid <= len(y):
                        lex = y[cursor:mid]
                        valid_eids = valid_slot_entity_ids(len(y), sym.sort, lex)
                        if not valid_eids:
                            continue
                        tails = enum_segs(child_fuel, loc, mid, rest, end_pos)
                        for eid in valid_eids:
                            for (r_args, r_slots, r_sums) in tails:
                                out.append((
                                    (("SLOT", sym.sort, sym.tag, eid, lex, (cursor, mid)),) + r_args,
                                    [(sym.tag, eid)] + r_slots,
                                    r_sums,
                                ))
                return out
            return []
        if isinstance(sym, SymNonterm):
            c_loc = clause_override(sym.clause_idx, loc)
            out = []
            for mid in candidate_splits_py(y, cursor, end_pos, rest):
                children = enum_node(child_fuel, c_loc, sym.nt, cursor, mid)
                if not children:
                    continue
                tails = enum_segs(child_fuel, loc, mid, rest, end_pos)
                for (sub_tree, sub_sum) in children:
                    for (r_args, r_slots, r_sums) in tails:
                        out.append((
                            (sub_tree,) + r_args,
                            r_slots,
                            [sub_sum] + r_sums,
                        ))
            return out
        return []

    def enum_node(
        fuel: int, expected_loc: str, expected_nt: str, start_pos: int, end_pos: int
    ) -> List[Tuple[TreeNodePy, ParseSummaryPy]]:
        tick_step()
        if fuel == 0:
            return []
        out: List[Tuple[TreeNodePy, ParseSummaryPy]] = []
        for p in FROZEN_PRODS:
            if p.lhs == expected_nt:
                seg_results = enum_segs(fuel - 1, expected_loc, start_pos, p.rhs, end_pos)
                for (args, slots, sums) in seg_results:
                    if p.check_side(env, slots, sums):
                        out_sum = p.mk_sum(slots, sums)
                        alts = list(range(1, p.alt_count + 1))
                        tick_nodes(len(alts))
                        for alt in alts:
                            out.append((
                                TreeNodePy(p.name, alt, expected_loc, (start_pos, end_pos), args),
                                out_sum,
                            ))
        return out

    try:
        raw_pairs = enum_node(5, "clause1", "controlledDocument", 0, len(y))
    except OverflowEx as ex:
        return (ex.tag, None)

    dedup: List[TreeNodePy] = []
    for t, _ in raw_pairs:
        if t not in dedup:
            dedup.append(t)

    if len(dedup) > max_readings:
        return (f"OVF_READINGS_{len(dedup)}_{max_readings}", None)

    return ("OK", dedup)


# ---------------------------------------------------------------------------
# 4. Clean-Room Semantic Extractor, Key-Order Normalizer & 5-Way Gate (P3-C)
# ---------------------------------------------------------------------------

class ExtractionEx(Exception):
    def __init__(self, tag: str) -> None:
        super().__init__(tag)
        self.tag = tag


def pack_nat_field(xs: List[int]) -> List[int]:
    return [len(xs)] + xs


def enc_str(s: str) -> List[int]:
    return [ord(c) for c in s]


def enc_str_list(ss: List[str]) -> List[int]:
    out: List[int] = []
    for s in ss:
        out.extend(pack_nat_field(enc_str(s)))
    return out


def enc_presup(p: Tuple[str, str, str]) -> List[int]:
    return enc_str_list([p[0], p[1], p[2]])


def enc_presup_list(ps: Tuple[Tuple[str, str, str], ...]) -> List[int]:
    out: List[int] = []
    for p in ps:
        out.extend(pack_nat_field(enc_presup(p)))
    return out


def enc_scope(sc: Tuple[str, ...]) -> List[int]:
    if sc[0] == "unrestrictedPop":
        return [0]
    return [1] + enc_str(sc[1])


def enc_opt_str(o: Optional[str]) -> List[str]:
    return ["0"] if o is None else ["1", o]


def enc_opt_pair_str(o: Optional[Tuple[str, str]]) -> List[str]:
    return ["0", "", ""] if o is None else ["1", o[0], o[1]]


QUANT_TAGS = {
    "universalNeg": 0,
    "negExistential": 1,
    "negUniversal": 2,
    "properPart": 3,
    "existentialPos": 4,
    "genericUniversalPos": 5,
}


def enc_atomic_claim(cl: tuple) -> List[int]:
    kind = cl[0]
    if kind == "descIncidence":
        _, w, e, k, n, p = cl
        return [0] + enc_str_list([w, e, k, n, p])
    if kind == "descDist":
        _, sk, m, est, d1, d2o = cl
        sub_tag = 0 if sk == "meanSD" else 1
        return [1, sub_tag] + enc_str_list([m, est, d1] + enc_opt_str(d2o))
    if kind == "assocClaim":
        _, met, dir_, act, ref, out, cov_o, tmp_o, est, cil, cilo, cihi = cl
        return [2] + enc_str_list(
            [met, dir_, act, ref, out, est, cil, cilo, cihi]
            + enc_opt_str(cov_o)
            + enc_opt_pair_str(tmp_o)
        )
    if kind == "compRD":
        _, act, ref, out, est, cil, cilo, cihi = cl
        return [3] + enc_str_list([act, ref, out, est, cil, cilo, cihi])
    if kind == "intervClaim":
        _, mod, assump, met, act, ref, out, est, cil, cilo, cihi, pv_o = cl
        if mod[0] == "directional":
            return [4, 0] + enc_str_list([mod[1], assump, met, act, ref, out, est, cil, cilo, cihi] + enc_opt_str(pv_o))
        return [4, 1] + enc_str_list([assump, met, act, ref, out, est, cil, cilo, cihi] + enc_opt_str(pv_o))
    if kind == "metaNotStatSig":
        _, met, act, ref, out, est, cil, cilo, cihi, al = cl
        return [5] + enc_str_list([met, act, ref, out, est, cil, cilo, cihi, al])
    if kind == "metaEquiv":
        _, met, act, ref, out, mlo, mhi, est, cil, cilo, cihi = cl
        return [6] + enc_str_list([met, act, ref, out, mlo, mhi, est, cil, cilo, cihi])
    if kind == "metaNonEstab":
        _, src, act, vb, out = cl
        return [7] + enc_str_list([src, act, vb, out])
    if kind == "metaUnresolvedPolar":
        _, src, act, vb, out = cl
        return [8] + enc_str_list([src, act, vb, out])
    if kind == "metaWhUnresolved":
        _, src, ep, wh, act, vb, out = cl
        return [9] + enc_str_list([src, ep, wh, act, vb, out])
    if kind == "quantClaim":
        _, (qk, sg, ev) = cl
        return [10, QUANT_TAGS[qk]] + enc_str_list([sg, ev])
    raise ValueError(f"Unknown atomic claim: {cl}")


def enc_norm_item(item: tuple) -> List[int]:
    if item[0] == "normAtom":
        _, sc, cl, ps = item
        return (
            [0]
            + pack_nat_field(enc_scope(sc))
            + pack_nat_field(enc_atomic_claim(cl))
            + enc_presup_list(ps)
        )
    if item[0] == "normContrastive":
        _, a_items, m_items, sh_exp, sh_out = item
        return (
            [1]
            + pack_nat_field(enc_norm_item_list(a_items))
            + pack_nat_field(enc_norm_item_list(m_items))
            + enc_str_list([sh_exp, sh_out])
        )
    raise ValueError(f"Unknown norm item: {item}")


def enc_norm_item_list(items: Tuple[tuple, ...]) -> List[int]:
    out: List[int] = []
    for x in items:
        out.extend(pack_nat_field(enc_norm_item(x)))
    return out


def dedup_sort_by_key(xs: list, key_fn: Callable[[object], List[int]]) -> tuple:
    uniq = []
    for x in xs:
        if x not in uniq:
            uniq.append(x)
    uniq.sort(key=key_fn)
    return tuple(uniq)


def normalize_atomic_claim_py(cl: tuple) -> tuple:
    if cl[0] == "quantClaim" and cl[1][0] == "universalNeg":
        _, (_, sg, ev) = cl
        return ("quantClaim", ("negExistential", sg, ev))
    return cl


def normalize_to_items_py(raw_term: tuple) -> Tuple[tuple, ...]:
    tag = raw_term[0]
    if tag == "scopedAtom":
        _, sc, _binder, cl, presups = raw_term
        norm_cl = normalize_atomic_claim_py(cl)
        norm_ps = dedup_sort_by_key(list(presups), enc_presup)
        return (("normAtom", sc, norm_cl, norm_ps),)
    if tag == "symConj":
        _, left, right = raw_term
        l_items = normalize_to_items_py(left)
        r_items = normalize_to_items_py(right)
        return dedup_sort_by_key(list(l_items) + list(r_items), enc_norm_item)
    if tag == "contrastivePair":
        _, a_side, m_side, sh_exp, sh_out = raw_term
        return (("normContrastive", normalize_to_items_py(a_side), normalize_to_items_py(m_side), sh_exp, sh_out),)
    raise ValueError(f"Unknown raw semantic term: {raw_term}")


def collect_slots_py(args: Tuple[object, ...]) -> List[Tuple[str, str]]:
    out = []
    for a in args:
        if isinstance(a, tuple) and len(a) == 6 and a[0] == "SLOT":
            out.append((a[2], a[3]))
    return out


def collect_children_py(args: Tuple[object, ...]) -> List[TreeNodePy]:
    return [a for a in args if isinstance(a, TreeNodePy)]


def req_slot_py(slots: List[Tuple[str, str]], tag: str) -> str:
    for k, v in slots:
        if k == tag:
            return v
    raise ExtractionEx("EXT_MALFORMED:missing_required_slot")


def extract_embedded_causal_py(t: TreeNodePy) -> Tuple[str, str, str]:
    if t.prod_name != "Env_EmbeddedCausal":
        raise ExtractionEx("EXT_MALFORMED:expected_Env_EmbeddedCausal")
    if t.reading_alt != 1:
        raise ExtractionEx(f"EXT_BAD_ALT:{t.reading_alt}")
    slots = collect_slots_py(t.args)
    if collect_children_py(t.args):
        raise ExtractionEx("EXT_MALFORMED:unexpected_child_subtrees")
    return (req_slot_py(slots, "activeExp"), req_slot_py(slots, "verb"), req_slot_py(slots, "outcome"))


def extract_leaf_core_py(t: TreeNodePy) -> Tuple[tuple, Tuple[Tuple[str, str, str], ...], Optional[Tuple[str, str]]]:
    p = t.prod_name
    alt = t.reading_alt
    slots = collect_slots_py(t.args)
    ch = collect_children_py(t.args)

    def req_alt1() -> None:
        if alt != 1:
            raise ExtractionEx(f"EXT_BAD_ALT:{alt}")

    def req_ch0() -> None:
        if ch:
            raise ExtractionEx("EXT_MALFORMED:unexpected_child_subtrees")

    def req_ch1() -> TreeNodePy:
        if len(ch) != 1:
            raise ExtractionEx("EXT_MALFORMED:expected_single_child_subtree")
        return ch[0]

    if p == "Gen_G01_DescIncidence":
        req_alt1(); req_ch0()
        return (("descIncidence", req_slot_py(slots, "window"), req_slot_py(slots, "eventA"),
                 req_slot_py(slots, "numK"), req_slot_py(slots, "numN"), req_slot_py(slots, "numPct")), (), None)
    if p == "Gen_G02a_DescMeanSD":
        req_alt1(); req_ch0()
        return (("descDist", "meanSD", req_slot_py(slots, "measure"),
                 req_slot_py(slots, "numEst"), req_slot_py(slots, "numDisp1"), None), (), None)
    if p == "Gen_G02b_DescMedianIQR":
        req_alt1(); req_ch0()
        return (("descDist", "medianIQR", req_slot_py(slots, "measure"),
                 req_slot_py(slots, "numEst"), req_slot_py(slots, "numDisp1"), req_slot_py(slots, "numDisp2")), (), None)
    if p == "Gen_G03_AssocUnadj":
        req_alt1(); req_ch0()
        act = req_slot_py(slots, "activeExp"); out = req_slot_py(slots, "outcome")
        return (("assocClaim", req_slot_py(slots, "metric1"), req_slot_py(slots, "direction"),
                 act, req_slot_py(slots, "refExp"), out, None, None,
                 req_slot_py(slots, "numEst"), req_slot_py(slots, "numCILevel"),
                 req_slot_py(slots, "numCILow"), req_slot_py(slots, "numCIHigh")), (), (act, out))
    if p == "Gen_G04_AssocTemp":
        req_alt1(); req_ch0()
        act = req_slot_py(slots, "activeExp"); out = req_slot_py(slots, "outcome")
        return (("assocClaim", req_slot_py(slots, "metric1"), req_slot_py(slots, "direction"),
                 act, req_slot_py(slots, "refExp"), out, None,
                 (req_slot_py(slots, "eventA"), req_slot_py(slots, "eventB")),
                 req_slot_py(slots, "numEst"), req_slot_py(slots, "numCILevel"),
                 req_slot_py(slots, "numCILow"), req_slot_py(slots, "numCIHigh")), (), (act, out))
    if p == "Gen_G05_CompRD":
        req_alt1(); req_ch0()
        return (("compRD", req_slot_py(slots, "activeExp"), req_slot_py(slots, "refExp"),
                 req_slot_py(slots, "outcome"), req_slot_py(slots, "numEst"),
                 req_slot_py(slots, "numCILevel"), req_slot_py(slots, "numCILow"), req_slot_py(slots, "numCIHigh")), (), None)
    if p == "Gen_G06a_IntervDirectional":
        req_alt1(); req_ch0()
        return (("intervClaim", ("directional", req_slot_py(slots, "verb")), req_slot_py(slots, "assumption"),
                 req_slot_py(slots, "metric1"), req_slot_py(slots, "activeExp"), req_slot_py(slots, "refExp"),
                 req_slot_py(slots, "outcome"), req_slot_py(slots, "numEst"), req_slot_py(slots, "numCILevel"),
                 req_slot_py(slots, "numCILow"), req_slot_py(slots, "numCIHigh"), req_slot_py(slots, "numPVal")), (), None)
    if p == "Gen_G06b_IntervNeutral":
        req_alt1(); req_ch0()
        return (("intervClaim", ("neutralNullIncluded",), req_slot_py(slots, "assumption"),
                 req_slot_py(slots, "metric1"), req_slot_py(slots, "activeExp"), req_slot_py(slots, "refExp"),
                 req_slot_py(slots, "outcome"), req_slot_py(slots, "numEst"), req_slot_py(slots, "numCILevel"),
                 req_slot_py(slots, "numCILow"), req_slot_py(slots, "numCIHigh"), None), (), None)
    if p == "Gen_G07_MetaNotStatSig":
        req_alt1(); req_ch0()
        m1 = req_slot_py(slots, "metric1"); m2 = req_slot_py(slots, "metric2")
        if m1 != m2:
            raise ExtractionEx("EXT_MALFORMED:G07_metric1_metric2_mismatch")
        return (("metaNotStatSig", m1, req_slot_py(slots, "activeExp"), req_slot_py(slots, "refExp"),
                 req_slot_py(slots, "outcome"), req_slot_py(slots, "numEst"), req_slot_py(slots, "numCILevel"),
                 req_slot_py(slots, "numCILow"), req_slot_py(slots, "numCIHigh"), req_slot_py(slots, "numAlpha")), (), None)
    if p == "Gen_G08_MetaEquiv":
        req_alt1(); req_ch0()
        return (("metaEquiv", req_slot_py(slots, "metric1"), req_slot_py(slots, "activeExp"), req_slot_py(slots, "refExp"),
                 req_slot_py(slots, "outcome"), req_slot_py(slots, "numMarginLow"), req_slot_py(slots, "numMarginHigh"),
                 req_slot_py(slots, "numEst"), req_slot_py(slots, "numCILevel"),
                 req_slot_py(slots, "numCILow"), req_slot_py(slots, "numCIHigh")), (), None)
    if p == "Gen_G09_MetaNonEstab":
        req_alt1()
        emb = req_ch1()
        act, vb, out = extract_embedded_causal_py(emb)
        return (("metaNonEstab", req_slot_py(slots, "source"), act, vb, out), (), (act, out))
    if p == "Gen_G10_MetaUnresolved":
        req_alt1()
        emb = req_ch1()
        act, vb, out = extract_embedded_causal_py(emb)
        return (("metaUnresolvedPolar", req_slot_py(slots, "source"), act, vb, out), (), None)
    if p == "Gen_G11_QuantZero":
        req_alt1(); req_ch0()
        return (("quantClaim", ("negExistential", req_slot_py(slots, "subgroup"), req_slot_py(slots, "eventA"))), (), None)
    if p == "Gen_G12_QuantProperPart":
        req_alt1(); req_ch0()
        return (("quantClaim", ("properPart", req_slot_py(slots, "subgroup"), req_slot_py(slots, "eventA"))), (), None)
    if p == "Gen_G13_QuantAtLeastOne":
        req_alt1(); req_ch0()
        return (("quantClaim", ("existentialPos", req_slot_py(slots, "subgroup"), req_slot_py(slots, "eventA"))), (), None)
    if p == "Gen_G14_AssocAdj":
        req_alt1(); req_ch0()
        act = req_slot_py(slots, "activeExp"); out = req_slot_py(slots, "outcome")
        return (("assocClaim", req_slot_py(slots, "metric1"), req_slot_py(slots, "direction"),
                 act, req_slot_py(slots, "refExp"), out, req_slot_py(slots, "covariates"), None,
                 req_slot_py(slots, "numEst"), req_slot_py(slots, "numCILevel"),
                 req_slot_py(slots, "numCILow"), req_slot_py(slots, "numCIHigh")), (), (act, out))
    if p == "Trap_T1_AllNot":
        req_ch0()
        sg = req_slot_py(slots, "subgroup"); ev = req_slot_py(slots, "eventA")
        if alt == 1:
            return (("quantClaim", ("universalNeg", sg, ev)), (), None)
        if alt == 2:
            return (("quantClaim", ("negUniversal", sg, ev)), (), None)
        raise ExtractionEx(f"EXT_BAD_ALT:{alt}")
    if p == "Trap_T2_ConfirmThat":
        emb = req_ch1()
        src = req_slot_py(slots, "source")
        act, vb, out = extract_embedded_causal_py(emb)
        if alt == 1:
            return (("metaNonEstab", src, act, vb, out), (), (act, out))
        if alt == 2:
            return (("metaNonEstab", src, act, vb, out), ((act, vb, out),), (act, out))
        raise ExtractionEx(f"EXT_BAD_ALT:{alt}")
    if p == "Trap_T3_WhPresup":
        req_alt1()
        emb = req_ch1()
        src = req_slot_py(slots, "source")
        ep_v = req_slot_py(slots, "verb")
        wh = req_slot_py(slots, "whComp")
        act, vb, out = extract_embedded_causal_py(emb)
        return (("metaWhUnresolved", src, ep_v, wh, act, vb, out), ((act, vb, out),), (act, out))
    if p == "Trap_T4_BarePlural":
        req_ch0()
        sg = req_slot_py(slots, "subgroup"); ev = req_slot_py(slots, "eventA")
        if alt == 1:
            return (("quantClaim", ("genericUniversalPos", sg, ev)), (), None)
        if alt == 2:
            return (("quantClaim", ("existentialPos", sg, ev)), (), None)
        raise ExtractionEx(f"EXT_BAD_ALT:{alt}")
    raise ExtractionEx("EXT_MALFORMED:expected_leaf_core_production")


def extract_core_clause_py(t: TreeNodePy):
    if t.prod_name in ("Env_LiftAssoc", "Env_LiftMeta"):
        if t.reading_alt != 1:
            raise ExtractionEx(f"EXT_BAD_ALT:{t.reading_alt}")
        ch = collect_children_py(t.args)
        if len(ch) != 1:
            raise ExtractionEx("EXT_MALFORMED:expected_single_child_subtree")
        return extract_leaf_core_py(ch[0])
    return extract_leaf_core_py(t)


def extract_scoped_clause_py(env: ScopeEnvPy, t: TreeNodePy) -> Tuple[tuple, Optional[Tuple[str, str]]]:
    if t.reading_alt != 1:
        raise ExtractionEx(f"EXT_BAD_ALT:{t.reading_alt}")
    slots = collect_slots_py(t.args)
    ch = collect_children_py(t.args)
    if len(ch) != 1:
        raise ExtractionEx("EXT_MALFORMED:expected_single_child_subtree")
    sub = ch[0]
    if t.prod_name in ("Env_ScopedInitial", "Env_ScopedAssoc", "Env_ScopedTrap"):
        coh = req_slot_py(slots, "cohort")
        if coh != env.cohort_id:
            raise ExtractionEx(f"EXT_COHORT:{coh}!={env.cohort_id}")
        cl, ps, anc = extract_core_clause_py(sub)
        return (("scopedAtom", ("cohortBound", coh), "x_init", cl, ps), anc)
    if t.prod_name in ("Env_ScopedRepeat", "Env_ScopedContrastMeta"):
        des = req_slot_py(slots, "design")
        if des != env.expected_design_head:
            raise ExtractionEx(f"EXT_ANAPHORA:{des}!={env.expected_design_head}")
        cl, ps, anc = extract_core_clause_py(sub)
        return (("scopedAtom", ("cohortBound", env.cohort_id), "y_repeat", cl, ps), anc)
    raise ExtractionEx("EXT_MALFORMED:expected_scoped_clause_production")


def extract_raw_meaning_py(env: ScopeEnvPy, t: TreeNodePy) -> tuple:
    if t.reading_alt != 1:
        raise ExtractionEx(f"EXT_BAD_ALT:{t.reading_alt}")
    ch = collect_children_py(t.args)
    p = t.prod_name
    if p in ("Env_DocSingle", "Env_DocTrapScoped"):
        if len(ch) != 1:
            raise ExtractionEx("EXT_MALFORMED:expected_single_child_subtree")
        m1, _ = extract_scoped_clause_py(env, ch[0])
        return m1
    if p in ("Gen_G15a_DocConjAtomic", "Gen_G15b_DocConjDiscourse"):
        if len(ch) != 2:
            raise ExtractionEx("EXT_MALFORMED:expected_two_child_subtrees")
        m1, _ = extract_scoped_clause_py(env, ch[0])
        m2, _ = extract_scoped_clause_py(env, ch[1])
        return ("symConj", m1, m2)
    if p == "Gen_G16_DocContrastive":
        if len(ch) != 2:
            raise ExtractionEx("EXT_MALFORMED:expected_two_child_subtrees")
        m1, anc1 = extract_scoped_clause_py(env, ch[0])
        m2, anc2 = extract_scoped_clause_py(env, ch[1])
        if anc1 is not None and anc2 is not None and anc1 == anc2:
            return ("contrastivePair", m1, m2, anc1[0], anc1[1])
        raise ExtractionEx("EXT_BAD_ANCHOR")
    if p == "Trap_T5_UnscopedDoc":
        if len(ch) != 1:
            raise ExtractionEx("EXT_MALFORMED:expected_single_child_subtree")
        cl, ps, _ = extract_core_clause_py(ch[0])
        return ("scopedAtom", ("unrestrictedPop",), "u_unscoped", cl, ps)
    raise ExtractionEx("EXT_MALFORMED:expected_document_root_production")


def check_tree_trap_policy_py(t: TreeNodePy) -> Optional[str]:
    p = t.prod_name
    if p == "Trap_T3_WhPresup":
        return "WH_FACTIVE_PRESUP"
    if p == "Trap_T5_UnscopedDoc":
        return "UNSCOPED_CLAUSE"
    if p == "Trap_T1_AllNot":
        return "TRAP_PROD(T1)"
    if p == "Trap_T2_ConfirmThat":
        return "TRAP_PROD(T2)"
    if p == "Trap_T4_BarePlural":
        return "TRAP_PROD(T4)"
    if p in ("Env_DocTrapScoped", "Env_ScopedTrap"):
        for sub in collect_children_py(t.args):
            d = check_tree_trap_policy_py(sub)
            if d is not None:
                return d
        return "TRAP_WRAPPER"
    for sub in collect_children_py(t.args):
        d = check_tree_trap_policy_py(sub)
        if d is not None:
            return d
    return None


def render_opt_str(o: Optional[str]) -> str:
    return "NONE" if o is None else f"SOME({o})"


def render_opt_pair(o: Optional[Tuple[str, str]]) -> str:
    return "NONE" if o is None else f"PAIR({o[0]}<{o[1]})"


QUANT_RENDER = {
    "universalNeg": "UNIV_NEG",
    "negExistential": "NEG_EX",
    "negUniversal": "NEG_UNIV",
    "properPart": "PROPER_PART",
    "existentialPos": "EX_POS",
    "genericUniversalPos": "GEN_UNIV",
}


def render_atomic_claim_py(cl: tuple) -> str:
    k = cl[0]
    if k == "descIncidence":
        _, w, e, nk, nn, np = cl
        return f"INC({w},{e},{nk},{nn},{np})"
    if k == "descDist":
        _, sk, m, est, d1, d2o = cl
        hdr = "MEAN_SD" if sk == "meanSD" else "MED_IQR"
        return f"{hdr}({m},{est},{d1},{render_opt_str(d2o)})"
    if k == "assocClaim":
        _, met, dir_, act, ref, out, cov_o, tmp_o, est, cil, cilo, cihi = cl
        return f"ASSOC({met},{dir_},{act},{ref},{out},{render_opt_str(cov_o)},{render_opt_pair(tmp_o)},{est},{cil},{cilo},{cihi})"
    if k == "compRD":
        _, act, ref, out, est, cil, cilo, cihi = cl
        return f"RD({act},{ref},{out},{est},{cil},{cilo},{cihi})"
    if k == "intervClaim":
        _, mod, assump, met, act, ref, out, est, cil, cilo, cihi, pv_o = cl
        if mod[0] == "directional":
            return f"INTERV_DIR({mod[1]},{assump},{met},{act},{ref},{out},{est},{cil},{cilo},{cihi},{render_opt_str(pv_o)})"
        return f"INTERV_NEUT({assump},{met},{act},{ref},{out},{est},{cil},{cilo},{cihi},{render_opt_str(pv_o)})"
    if k == "metaNotStatSig":
        _, met, act, ref, out, est, cil, cilo, cihi, al = cl
        return f"NOT_SIG({met},{act},{ref},{out},{est},{cil},{cilo},{cihi},{al})"
    if k == "metaEquiv":
        _, met, act, ref, out, mlo, mhi, est, cil, cilo, cihi = cl
        return f"EQUIV({met},{act},{ref},{out},{mlo},{mhi},{est},{cil},{cilo},{cihi})"
    if k == "metaNonEstab":
        _, src, act, vb, out = cl
        return f"NON_ESTAB({src},{act},{vb},{out})"
    if k == "metaUnresolvedPolar":
        _, src, act, vb, out = cl
        return f"UNRES_POLAR({src},{act},{vb},{out})"
    if k == "metaWhUnresolved":
        _, src, ep, wh, act, vb, out = cl
        return f"UNRES_WH({src},{ep},{wh},{act},{vb},{out})"
    if k == "quantClaim":
        _, (qk, sg, ev) = cl
        return f"QUANT({QUANT_RENDER[qk]}({sg},{ev}))"
    raise ValueError(k)


def render_norm_item_py(item: tuple) -> str:
    if item[0] == "normAtom":
        _, sc, cl, ps = item
        sc_str = "UNRESTRICTED" if sc[0] == "unrestrictedPop" else f"COH({sc[1]})"
        ps_str = ";".join(f"FACT({a},{v},{o})" for (a, v, o) in ps)
        return f"ATOM[{sc_str};{render_atomic_claim_py(cl)};[{ps_str}]]"
    _, a_items, m_items, sh_exp, sh_out = item
    a_seq = " && ".join(render_norm_item_py(x) for x in a_items)
    m_seq = " && ".join(render_norm_item_py(x) for x in m_items)
    return f"CONTRAST[{{{a_seq}}};HOWEVER;{{{m_seq}}};ANCHOR({sh_exp},{sh_out})]"


def render_canonical_py(items: Tuple[tuple, ...]) -> str:
    return "{" + " && ".join(render_norm_item_py(x) for x in items) + "}"


def certify_semantic_consensus_py(
    env: ScopeEnvPy,
    max_bytes: int,
    max_steps: int,
    max_forest_nodes: int,
    max_readings: int,
    raw_bytes: bytes,
) -> str:
    status, trees = parse_all_bounded_trees_py(
        env, max_bytes, max_steps, max_forest_nodes, max_readings, raw_bytes
    )
    if trees is None:
        return f"UPSTREAM_REJECTED|{status}"
    if len(trees) == 0:
        return "UPSTREAM_REJECTED|EMPTY_PARSE_SET"

    pairs = []
    for t in trees:
        try:
            m = extract_raw_meaning_py(env, t)
        except ExtractionEx as ex:
            return f"EXTRACTION_FAILURE|{len(trees)}|{ex.tag}"
        pairs.append((t, m))

    c1 = normalize_to_items_py(pairs[0][1])
    for _t2, m2 in pairs[1:]:
        c2 = normalize_to_items_py(m2)
        if c1 != c2:
            return f"AMBIGUOUS|{len(trees)}|{render_canonical_py(c1)}|{render_canonical_py(c2)}"

    for t in trees:
        trap_d = check_tree_trap_policy_py(t)
        if trap_d is not None:
            return f"TRAP_REJECTED|{len(trees)}|{trap_d}|{render_canonical_py(c1)}"

    return f"CONSENSUS|{len(trees)}|{render_canonical_py(c1)}"


# ---------------------------------------------------------------------------
# 5. External 250-Vector Batch Construction & 1:1 Lean <-> Python Verification
# ---------------------------------------------------------------------------

def build_batch_vectors() -> List[Tuple[str, str, int, int, int, int, bytes]]:
    vecs: List[Tuple[str, str, int, int, int, int, bytes]] = []

    def add(vid: str, mode: str, mb: int, ms: int, mn: int, mr: int, raw: bytes) -> None:
        vecs.append((vid, mode, mb, ms, mn, mr, raw))

    def b(s: str) -> bytes:
        return s.encode("ascii")

    # A. Generator Consensus Vectors across G-01..G-16 (120 vectors)
    for idx, (ev, k, n, pct) in enumerate([
        ("stroke", "42", "500", "8.4"),
        ("stroke", "0", "250", "0"),
        ("acute kidney injury", "15", "300", "5.0"),
        ("acute kidney injury", "128", "1000", "12.8"),
        ("stroke", "7", "140", "5"),
        ("acute kidney injury", "1", "80", "1.25"),
    ], 1):
        add(f"V-G01-{idx:02d}", "atomic", 512, 200000, 128, 16,
            b(f"In the primary cohort, over 12 months, the cumulative incidence of {ev} was {k} of {n} patients ({pct}%)."))

    for idx, (est, sd) in enumerate([("128.4", "14.2"), ("132", "16.5"), ("119.8", "11.05"), ("140.25", "18.9")], 1):
        add(f"V-G02a-{idx:02d}", "atomic", 512, 200000, 128, 16,
            b(f"In the primary cohort, the mean systolic blood pressure was {est} (SD {sd})."))

    for idx, (est, q1, q3) in enumerate([("126", "118", "136"), ("130.5", "120.2", "141.8"), ("122.0", "114.5", "131.5"), ("135", "125", "148")], 1):
        add(f"V-G02b-{idx:02d}", "atomic", 512, 200000, 128, 16,
            b(f"In the primary cohort, the median systolic blood pressure was {est} (IQR {q1} to {q3})."))

    idx = 0
    for met in ["risk ratio", "odds ratio", "hazard ratio"]:
        for dir_ in ["positively", "inversely"]:
            for out in ["myocardial infarction", "all-cause mortality"]:
                idx += 1
                add(f"V-G03-{idx:02d}", "atomic", 512, 200000, 128, 16,
                    b(f"In the primary cohort, comparing intensive therapy versus standard care was {dir_} associated with {out} ({met} = 0.75, 95% CI 0.61 to 0.92)."))

    idx = 0
    for (ev_a, ev_b) in [("stroke", "acute kidney injury"), ("acute kidney injury", "stroke")]:
        for met in ["hazard ratio", "risk ratio", "odds ratio"]:
            for out in ["myocardial infarction", "all-cause mortality"]:
                idx += 1
                add(f"V-G04-{idx:02d}", "atomic", 512, 200000, 128, 16,
                    b(f"In the primary cohort, {ev_a} preceded {ev_b}, and comparing intensive therapy versus standard care was inversely associated with {out} ({met} = 0.78, 95% CI 0.63 to 0.96)."))

    for idx, (out, est, lo, hi) in enumerate([
        ("myocardial infarction", "-3.2", "-5.1", "-1.3"),
        ("all-cause mortality", "-1.8", "-3.4", "-0.2"),
        ("myocardial infarction", "2.4", "0.5", "4.3"),
        ("all-cause mortality", "0", "-1.2", "1.2"),
        ("myocardial infarction", "-4.05", "-6.1", "-2.0"),
        ("all-cause mortality", "-0.95", "-2.1", "0.2"),
    ], 1):
        add(f"V-G05-{idx:02d}", "atomic", 512, 200000, 128, 16,
            b(f"In the primary cohort, the absolute risk difference in {out} comparing intensive therapy versus standard care was {est} percentage points (95% CI {lo} to {hi})."))

    idx = 0
    for vb in ["reduce", "increase"]:
        for met in ["hazard ratio", "risk ratio", "odds ratio"]:
            for out in ["myocardial infarction", "all-cause mortality"]:
                idx += 1
                add(f"V-G06a-{idx:02d}", "atomic", 512, 200000, 128, 16,
                    b(f"In the primary cohort, under conditional exchangeability, comparing intensive therapy versus standard care was estimated to {vb} {out} ({met} = 0.75, 95% CI 0.61 to 0.92, p = 0.006)."))

    idx = 0
    for met in ["hazard ratio", "risk ratio", "odds ratio"]:
        for out in ["myocardial infarction", "all-cause mortality"]:
            idx += 1
            add(f"V-G06b-{idx:02d}", "atomic", 512, 200000, 128, 16,
                b(f"In the primary cohort, under conditional exchangeability, the estimated causal {met} for {out} comparing intensive therapy versus standard care was 0.98 (95% CI 0.81 to 1.19), which did not exclude no effect."))

    idx = 0
    for met in ["hazard ratio", "risk ratio", "odds ratio"]:
        for out in ["myocardial infarction", "all-cause mortality"]:
            for al in ["0.05", "0.01"]:
                idx += 1
                add(f"V-G07-{idx:02d}", "atomic", 512, 200000, 128, 16,
                    b(f"In the primary cohort, the observed {met} comparing intensive therapy versus standard care for {out} ({met} = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = {al}."))

    idx = 0
    for met in ["risk ratio", "odds ratio", "hazard ratio"]:
        for out in ["myocardial infarction", "all-cause mortality"]:
            idx += 1
            add(f"V-G08-{idx:02d}", "atomic", 512, 200000, 128, 16,
                b(f"In the primary cohort, comparing intensive therapy versus standard care met prespecified equivalence margins (0.85 to 1.18) for {out} ({met} = 0.99, 90% TOST CI 0.89 to 1.10)."))

    idx = 0
    for vb in ["causes", "increases", "reduces"]:
        for out in ["myocardial infarction", "all-cause mortality"]:
            idx += 1
            add(f"V-G09-{idx:02d}", "atomic", 512, 200000, 128, 16,
                b(f"In the primary cohort, the analysis of Trial-A did not establish that intensive therapy {vb} {out}."))
            add(f"V-G10-{idx:02d}", "atomic", 512, 200000, 128, 16,
                b(f"In the primary cohort, the analysis of Trial-A did not determine whether intensive therapy {vb} {out}."))

    for idx, ev in enumerate(["stroke", "acute kidney injury"], 1):
        add(f"V-G11-{idx:02d}", "atomic", 512, 200000, 128, 16,
            b(f"In the primary cohort, no diabetic patients developed {ev}."))
        add(f"V-G12-{idx:02d}", "atomic", 512, 200000, 128, 16,
            b(f"In the primary cohort, some, but not all, diabetic patients developed {ev}."))
        add(f"V-G13-{idx:02d}", "atomic", 512, 200000, 128, 16,
            b(f"In the primary cohort, at least one high-risk patient developed {ev}."))

    idx = 0
    for met in ["hazard ratio", "risk ratio", "odds ratio"]:
        for dir_ in ["inversely", "positively"]:
            for out in ["myocardial infarction", "all-cause mortality"]:
                idx += 1
                add(f"V-G14-{idx:02d}", "atomic", 512, 200000, 128, 16,
                    b(f"In the primary cohort, after adjustment for age and baseline risk, comparing intensive therapy versus standard care was {dir_} associated with {out} ({met} = 0.76, 95% CI 0.62 to 0.93)."))

    # Paraphrase Convergence Pairs: G-15a (A . B) vs G-15b (B . Within-study A) (24 vectors = 12 pairs)
    c1_opts = [
        "no diabetic patients developed stroke",
        "no diabetic patients developed acute kidney injury",
        "some, but not all, diabetic patients developed stroke",
        "the mean systolic blood pressure was 128.4 (SD 14.2)",
    ]
    c2_opts = [
        "at least one high-risk patient developed acute kidney injury",
        "at least one high-risk patient developed stroke",
        "over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%)",
    ]
    pidx = 0
    for c1 in c1_opts:
        for c2 in c2_opts:
            pidx += 1
            add(f"V-G15A-PAIR-{pidx:02d}", "atomic", 512, 250000, 128, 16,
                b(f"In the primary cohort, {c1}. In the primary cohort, {c2}."))
            add(f"V-G15B-PAIR-{pidx:02d}", "discourse", 512, 250000, 128, 16,
                b(f"In the primary cohort, {c2}. Within this same study, {c1}."))

    # G-16 Contrastive Discourse Vectors (12 vectors)
    g16_idx = 0
    for met in ["hazard ratio", "risk ratio"]:
        for vb in ["reduces", "increases", "causes"]:
            for out in ["myocardial infarction", "all-cause mortality"]:
                g16_idx += 1
                add(f"V-G16-{g16_idx:02d}", "discourse", 512, 300000, 128, 16,
                    b(f"In the primary cohort, comparing intensive therapy versus standard care was inversely associated with {out} ({met} = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy {vb} {out}."))

    # B. Trap Vectors T1, T2, T3, T4, T5 (68 vectors)
    for idx, ev in enumerate(["stroke", "acute kidney injury"], 1):
        add(f"V-T1-{idx:02d}", "atomic", 512, 200000, 128, 16,
            b(f"In the primary cohort, all diabetic patients did not develop {ev}."))
        add(f"V-T4-{idx:02d}", "atomic", 512, 200000, 128, 16,
            b(f"In the primary cohort, diabetic patients developed {ev}."))

    t2_idx = 0
    for act, ref in [("intensive therapy", "standard care"), ("standard care", "intensive therapy")]:
        for vb in ["causes", "increases", "reduces"]:
            for out in ["myocardial infarction", "all-cause mortality"]:
                t2_idx += 1
                add(f"V-T2-{t2_idx:02d}", "atomic", 512, 200000, 128, 16,
                    b(f"In the primary cohort, the analysis of Trial-A did not confirm that {act} {vb} {out}."))

    t3_idx = 0
    for ep in ["establish", "determine", "confirm", "reveal"]:
        for wh in ["why", "how"]:
            for vb in ["causes", "increases", "reduces"]:
                for out in ["myocardial infarction", "all-cause mortality"]:
                    if t3_idx < 36:
                        t3_idx += 1
                        add(f"V-T3-{t3_idx:02d}", "atomic", 512, 200000, 128, 16,
                            b(f"In the primary cohort, the analysis of Trial-A did not {ep} {wh} intensive therapy {vb} {out}."))

    t5_cores = [
        "no diabetic patients developed stroke.",
        "no diabetic patients developed acute kidney injury.",
        "some, but not all, diabetic patients developed stroke.",
        "some, but not all, diabetic patients developed acute kidney injury.",
        "at least one high-risk patient developed stroke.",
        "at least one high-risk patient developed acute kidney injury.",
        "the mean systolic blood pressure was 128.4 (SD 14.2).",
        "the median systolic blood pressure was 126 (IQR 118 to 136).",
        "over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%).",
        "the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction.",
        "the analysis of Trial-A did not determine whether intensive therapy reduces myocardial infarction.",
        "comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92).",
        "the absolute risk difference in myocardial infarction comparing intensive therapy versus standard care was -3.2 percentage points (95% CI -5.1 to -1.3).",
        "under conditional exchangeability, comparing intensive therapy versus standard care was estimated to reduce myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92, p = 0.006).",
        "the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (hazard ratio = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = 0.05.",
        "comparing intensive therapy versus standard care met prespecified equivalence margins (0.85 to 1.18) for myocardial infarction (hazard ratio = 0.99, 90% TOST CI 0.89 to 1.10).",
    ]
    for idx, s_un in enumerate(t5_cores, 1):
        add(f"V-T5-{idx:02d}", "atomic", 512, 200000, 128, 16, b(s_un))

    # C. Upstream Rejections: EmptyParseSet, OutOfDomain, ResourceOverflow (50 vectors)
    bad_gram_or_lex = [
        "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (1..25%).",
        "In the primary cohort, over 12 months, the cumulative incidence of stroke was 042 of 500 patients (8.4%).",
        "In the primary cohort, over 12 months, the cumulative incidence of stroke was +42 of 500 patients (8.4%).",
        "In the primary cohort, over 12 months, the cumulative incidence of stroke was -0 of 500 patients (8.4%).",
        "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.12345%).",
        "In the primary cohort, comparing intensive therapy versus intensive therapy was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92).",
        "In the primary cohort, stroke preceded stroke, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92).",
        "In the primary cohort, the observed risk ratio comparing intensive therapy versus standard care for myocardial infarction (hazard ratio = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = 0.05.",
        "In the primary cohort, intensive therapy cured myocardial infarction.",
        "In the primary cohort, no diabetic patients developed stroke",
        "In unknown cohort, no diabetic patients developed stroke.",
        "In the primary cohort, at least one high-risk patient developed acute kidney injury. Within this same study, no diabetic patients developed stroke.",  # atomic mode rejects G-15b
        "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality.",
    ]
    for idx, s_bad in enumerate(bad_gram_or_lex, 1):
        add(f"V-UP-EMPTY-{idx:02d}", "atomic" if idx != 13 else "discourse", 512, 200000, 128, 16, b(s_bad))

    ood_payloads = [
        b"",
        b"In the primary cohort,\nno diabetic patients developed stroke.",
        b"In the primary cohort,\tno diabetic patients developed stroke.",
        b"In the primary cohort, \xc3\xa9.",
        b"\x00In the primary cohort.",
        b"In the primary cohort.\x7f",
        b"\x80\x81",
        b"In the primary cohort, \xe2\x80\x94.",
    ]
    for idx, raw_ood in enumerate(ood_payloads, 1):
        add(f"V-UP-OOD-{idx:02d}", "atomic", 512, 200000, 128, 16, raw_ood)

    s_ref_t2 = b("In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction.")
    s_ref_g01 = b("In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%).")
    for idx, lim_b in enumerate([10, 25, 50, 80, 100], 1):
        add(f"V-UP-OVF-B-{idx:02d}", "atomic", lim_b, 200000, 128, 16, s_ref_g01)
    for idx, lim_s in enumerate([1, 3, 8, 15, 30], 1):
        add(f"V-UP-OVF-S-{idx:02d}", "atomic", 512, lim_s, 128, 16, s_ref_g01)
    for idx, lim_n in enumerate([0, 1, 2], 1):
        add(f"V-UP-OVF-N-{idx:02d}", "atomic", 512, 200000, lim_n, 16, s_ref_t2)
    for idx, (s_dual, lim_r) in enumerate([
        (b("In the primary cohort, all diabetic patients did not develop stroke."), 1),
        (b("In the primary cohort, all diabetic patients did not develop stroke."), 0),
        (s_ref_t2, 1),
        (s_ref_t2, 0),
        (b("In the primary cohort, diabetic patients developed stroke."), 1),
        (s_ref_g01, 0),
    ], 1):
        add(f"V-UP-OVF-R-{idx:02d}", "atomic", 512, 200000, 128, lim_r, s_dual)

    # Pad to >= 250 deterministic vectors if needed
    pad_idx = 0
    while len(vecs) < 250:
        pad_idx += 1
        add(
            f"V-PAD-GEN-{pad_idx:02d}",
            "atomic",
            512,
            200000,
            128,
            16,
            b(f"In the primary cohort, over 12 months, the cumulative incidence of stroke was {pad_idx} of {100 + pad_idx} patients ({pad_idx}.5%)."),
        )

    return vecs[:250]


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    exe = root / ".lake" / "build" / "bin" / "p3c_tribunal_runner.exe"
    if not exe.exists():
        print(f"ERROR: Lean executable not found at {exe}", file=sys.stderr)
        return 2

    assert CATALOG_IS_VALID, "Clean-room P3C_TEST_CATALOG failed ValidEntityCatalog!"

    # 1. Verify fixed 30-vector Lean suite via --export-fixed-json
    fixed_proc = subprocess.run(
        [str(exe), "--export-fixed-json"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=True,
    )
    fixed_cases = json.loads(fixed_proc.stdout)
    fixed_passed = sum(1 for c in fixed_cases if c["passed"] is True)
    if len(fixed_cases) != 30 or fixed_passed != 30:
        print(f"ERROR: Fixed suite expected 30/30 passed, got {fixed_passed}/{len(fixed_cases)}", file=sys.stderr)
        return 1

    # 2. Build 250 external batch vectors & run 1:1 Lean <-> Python differential check
    batch_vecs = build_batch_vectors()
    assert len(batch_vecs) == 250

    py_results = {}
    tsv_lines = []
    for vid, mode, mb, ms, mn, mr, raw in batch_vecs:
        env = ScopeEnvPy(
            cohort_id="coh_primary",
            expected_design_head="des_study",
            quote_isolation="discourseBound" if mode == "discourse" else "sentenceAtomic",
        )
        py_sig = certify_semantic_consensus_py(env, mb, ms, mn, mr, raw)
        py_results[vid] = py_sig
        tsv_lines.append(f"{vid}\t{mode}\t{mb}\t{ms}\t{mn}\t{mr}\t{raw.hex()}")

    # Verify cross-paraphrase canonical convergence in Python oracle on all 12 G-15a / G-15b pairs
    for pidx in range(1, 13):
        sig_a = py_results[f"V-G15A-PAIR-{pidx:02d}"]
        sig_b = py_results[f"V-G15B-PAIR-{pidx:02d}"]
        assert sig_a.startswith("CONSENSUS|1|") and sig_a == sig_b, (
            f"Paraphrase convergence failed on pair {pidx}: {sig_a} vs {sig_b}"
        )

    with tempfile.NamedTemporaryFile("w", suffix=".tsv", encoding="utf-8", delete=False) as tf:
        tf.write("\n".join(tsv_lines) + "\n")
        tsv_path = Path(tf.name)

    try:
        batch_proc = subprocess.run(
            [str(exe), "--eval-batch", str(tsv_path)],
            capture_output=True,
            text=True,
            encoding="utf-8",
            check=True,
        )
    finally:
        tsv_path.unlink(missing_ok=True)

    lean_results = {}
    for line in batch_proc.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        vid, lsig = line.split("\t", 1)
        lean_results[vid] = lsig

    mismatches = []
    category_counts = {
        "CONSENSUS": 0,
        "AMBIGUOUS": 0,
        "TRAP_REJECTED": 0,
        "EXTRACTION_FAILURE": 0,
        "UPSTREAM_REJECTED": 0,
    }
    for vid, *_rest in batch_vecs:
        lsig = lean_results.get(vid, "<MISSING>")
        psig = py_results[vid]
        if lsig != psig:
            mismatches.append((vid, lsig, psig))
        else:
            head = psig.split("|", 1)[0]
            category_counts[head] = category_counts.get(head, 0) + 1

    print("==========================================================================")
    print("PNEUMA-NATIVE OMEGA — AUTH-C1-P3-C 1:1 DIFFERENTIAL ORACLE AUDIT REPORT")
    print("==========================================================================")
    print(f"Fixed Curated (PC, CE) Suite   : {fixed_passed}/{len(fixed_cases)} PASSED")
    print(f"External Serialized TSV Batch  : {len(batch_vecs) - len(mismatches)}/{len(batch_vecs)} MATCHED")
    print(f"Outcome Breakdown              : {json.dumps(category_counts, sort_keys=True)}")
    print(f"G-15a == G-15b Convergence     : 12/12 PAIRS IDENTICAL CANONICAL NORMAL FORM")
    print(f"Differential Mismatches        : {len(mismatches)}")
    print("==========================================================================")

    if mismatches:
        for vid, lsig, psig in mismatches[:10]:
            print(f"MISMATCH {vid}:\n  Lean  : {lsig}\n  Python: {psig}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
