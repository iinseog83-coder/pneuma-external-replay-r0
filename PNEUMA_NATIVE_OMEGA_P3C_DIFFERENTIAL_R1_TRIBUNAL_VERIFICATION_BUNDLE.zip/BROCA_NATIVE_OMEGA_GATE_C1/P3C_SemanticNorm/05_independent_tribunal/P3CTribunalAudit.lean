/-
  PNEUMA-NATIVE Ω — AUTH-C1-P3-C (`PO-C1-03` Independent Tribunal Audit & Differential CLI)
  05_independent_tribunal/P3CTribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` + read-only Legacy BROCA `P2`, `P3-A`, `P3-B`, zero `sorry`)

  1. Emits `#print axioms` on all exported `PO-C1-03` / `D01` / `D02` / `D03` theorems
     (verifying `0` `sorryAx`, `0` `Lean.ofReduceBool`, `0` custom axioms).
  2. Provides CLI executable `p3c_tribunal_runner`:
     - Default mode            : runs all 30 curated `(PC, CE)` suite vectors.
     - `--export-fixed-json`   : exports JSON report of all 30 curated suite vectors.
     - `--eval-batch <tsv>`    : evaluates arbitrary external hex-encoded TSV batch vectors
                                 through `certifySemanticConsensus` and prints deterministic
                                 full canonical normal form signatures for 1:1 Python parity!
-/
import P3CProofObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProofObligations

/-! ### 1. Kernel Axiom Fingerprint Audit (`#print axioms`) -/

#print axioms PO_C1_03_D01_SemEqSoundForDenotes
#print axioms PO_C1_03_D01_NormalizerTerminates
#print axioms PO_C1_03_D01_NormalizerPreservesMeaning
#print axioms PO_C1_03_D01_NormalizerIdempotent
#print axioms PO_C1_03_D01_CanonicalCharacterization
#print axioms PO_C1_03_D01_SemEqIffNormalFormEq
#print axioms PO_C1_03_D01_SemanticRefutations
#print axioms PO_C1_03_D02_EndToEndConsensusSound
#print axioms PO_C1_03_D02_EndToEndAmbiguityRefutation
#print axioms PO_C1_03_D02_ExtractionFailureSound
#print axioms PO_C1_03_D03_IndependentTrapRejectionSound
#print axioms PO_C1_03_D02_UpstreamFailClosed
#print axioms PO_C1_03_D03_AuthoritySeparation
#print axioms PO_C1_03_SymmetricSuiteVerified

/-! ### 2. Deterministic Full-AST Serialization for 1:1 Differential Oracle Parity -/

private def renderScope : SemanticScope → String
  | .unrestrictedPop => "UNRESTRICTED"
  | .cohortBound cid => "COH(" ++ cid ++ ")"

private def renderPresup : PresupItem → String
  | .factiveCausal act vb out => "FACT(" ++ act ++ "," ++ vb ++ "," ++ out ++ ")"

private def renderQuantForm : QuantPredForm → String
  | .universalNeg sg ev        => "UNIV_NEG(" ++ sg ++ "," ++ ev ++ ")"
  | .negExistential sg ev      => "NEG_EX(" ++ sg ++ "," ++ ev ++ ")"
  | .negUniversal sg ev        => "NEG_UNIV(" ++ sg ++ "," ++ ev ++ ")"
  | .properPart sg ev          => "PROPER_PART(" ++ sg ++ "," ++ ev ++ ")"
  | .existentialPos sg ev      => "EX_POS(" ++ sg ++ "," ++ ev ++ ")"
  | .genericUniversalPos sg ev => "GEN_UNIV(" ++ sg ++ "," ++ ev ++ ")"

private def renderOptStr : Option String → String
  | none   => "NONE"
  | some s => "SOME(" ++ s ++ ")"

private def renderOptPair : Option (String × String) → String
  | none        => "NONE"
  | some (a, b) => "PAIR(" ++ a ++ "<" ++ b ++ ")"

private def renderAtomicClaim : AtomicClaim → String
  | .descIncidence w e k n p =>
    "INC(" ++ String.intercalate "," [w, e, k, n, p] ++ ")"
  | .descDist .meanSD m est d1 d2o =>
    "MEAN_SD(" ++ String.intercalate "," [m, est, d1, renderOptStr d2o] ++ ")"
  | .descDist .medianIQR m est d1 d2o =>
    "MED_IQR(" ++ String.intercalate "," [m, est, d1, renderOptStr d2o] ++ ")"
  | .assocClaim met dir act ref out covO tmpO est ciL ciLo ciHi =>
    "ASSOC(" ++ String.intercalate "," [met, dir, act, ref, out, renderOptStr covO, renderOptPair tmpO, est, ciL, ciLo, ciHi] ++ ")"
  | .compRD act ref out est ciL ciLo ciHi =>
    "RD(" ++ String.intercalate "," [act, ref, out, est, ciL, ciLo, ciHi] ++ ")"
  | .intervClaim (.directional vb) assump met act ref out est ciL ciLo ciHi pvO =>
    "INTERV_DIR(" ++ String.intercalate "," [vb, assump, met, act, ref, out, est, ciL, ciLo, ciHi, renderOptStr pvO] ++ ")"
  | .intervClaim .neutralNullIncluded assump met act ref out est ciL ciLo ciHi pvO =>
    "INTERV_NEUT(" ++ String.intercalate "," [assump, met, act, ref, out, est, ciL, ciLo, ciHi, renderOptStr pvO] ++ ")"
  | .metaNotStatSig met act ref out est ciL ciLo ciHi al =>
    "NOT_SIG(" ++ String.intercalate "," [met, act, ref, out, est, ciL, ciLo, ciHi, al] ++ ")"
  | .metaEquiv met act ref out mLo mHi est ciL ciLo ciHi =>
    "EQUIV(" ++ String.intercalate "," [met, act, ref, out, mLo, mHi, est, ciL, ciLo, ciHi] ++ ")"
  | .metaNonEstab src act vb out =>
    "NON_ESTAB(" ++ String.intercalate "," [src, act, vb, out] ++ ")"
  | .metaUnresolvedPolar src act vb out =>
    "UNRES_POLAR(" ++ String.intercalate "," [src, act, vb, out] ++ ")"
  | .metaWhUnresolved src ep wh act vb out =>
    "UNRES_WH(" ++ String.intercalate "," [src, ep, wh, act, vb, out] ++ ")"
  | .quantClaim qf =>
    "QUANT(" ++ renderQuantForm qf ++ ")"

mutual
  private def renderNormItem : NormItem → String
    | .normAtom sc cl ps =>
      "ATOM[" ++ renderScope sc ++ ";" ++ renderAtomicClaim cl ++ ";[" ++
        String.intercalate ";" (ps.map renderPresup) ++ "]]"
    | .normContrastive aItems mItems shExp shOut =>
      "CONTRAST[{" ++ renderNormItemSeq aItems ++ "};HOWEVER;{" ++
        renderNormItemSeq mItems ++ "};ANCHOR(" ++ shExp ++ "," ++ shOut ++ ")]"

  private def renderNormItemSeq : List NormItem → String
    | []            => ""
    | [x]           => renderNormItem x
    | x :: y :: rst => renderNormItem x ++ " && " ++ renderNormItemSeq (y :: rst)
end

private def renderCanonicalMeaning (c : CanonicalMeaning) : String :=
  "{" ++ renderNormItemSeq c.items ++ "}"

private def renderTrapDiag : TrapPolicyDiag → String
  | .whFactivePresuppositionForbidden => "WH_FACTIVE_PRESUP"
  | .unscopedClauseForbidden          => "UNSCOPED_CLAUSE"
  | .parserOnlyTrapProduction .T1     => "TRAP_PROD(T1)"
  | .parserOnlyTrapProduction .T2     => "TRAP_PROD(T2)"
  | .parserOnlyTrapProduction .T3     => "TRAP_PROD(T3)"
  | .parserOnlyTrapProduction .T4     => "TRAP_PROD(T4)"
  | .parserOnlyTrapProduction .T5     => "TRAP_PROD(T5)"
  | .parserOnlyTrapProduction _       => "TRAP_PROD(OTHER)"
  | .wrapperTrapEnvelope              => "TRAP_WRAPPER"

private def renderUpstreamDiag : UpstreamParseDiag → String
  | .emptyParseSet => "EMPTY_PARSE_SET"
  | .outOfDomain .emptyInput => "OOD_EMPTY"
  | .outOfDomain (.nonPrintableAsciiByte b) => "OOD_BYTE_" ++ toString b.toNat
  | .resourceOverflow (.maxBytesExceeded actual lim) =>
    "OVF_BYTES_" ++ toString actual ++ "_" ++ toString lim
  | .resourceOverflow (.maxStepsExceeded lim) =>
    "OVF_STEPS_" ++ toString lim
  | .resourceOverflow (.maxForestNodesExceeded lim) =>
    "OVF_NODES_" ++ toString lim
  | .resourceOverflow (.maxReadingsExceeded actual lim) =>
    "OVF_READINGS_" ++ toString actual ++ "_" ++ toString lim

private def renderExtractionDiag : ExtractionFailureDiag → String
  | .malformedParseNode _ d       => "EXT_MALFORMED:" ++ d
  | .unsupportedReadingAlt _ alt  => "EXT_BAD_ALT:" ++ toString alt
  | .mismatchedScopeCohort f e    => "EXT_COHORT:" ++ f ++ "!=" ++ e
  | .unresolvedAnaphoricScope f e => "EXT_ANAPHORA:" ++ f ++ "!=" ++ e
  | .invalidContrastiveAnchor _   => "EXT_BAD_ANCHOR"

private def formatOutcomeSig : SemanticNormOutcome → String
  | .consensus ts c =>
    s!"CONSENSUS|{ts.length}|{renderCanonicalMeaning c}"
  | .ambiguousReadings ts w =>
    s!"AMBIGUOUS|{ts.length}|{renderCanonicalMeaning w.norm1}|{renderCanonicalMeaning w.norm2}"
  | .trapPolicyRejected ts c d =>
    s!"TRAP_REJECTED|{ts.length}|{renderTrapDiag d}|{renderCanonicalMeaning c}"
  | .semanticExtractionFailure ts err =>
    s!"EXTRACTION_FAILURE|{ts.length}|{renderExtractionDiag err.diag}"
  | .upstreamRejected d =>
    s!"UPSTREAM_REJECTED|{renderUpstreamDiag d}"

/-! ### 3. Hex-Encoded TSV Batch Evaluator & Fixed JSON Exporter -/

private def hexDigitVal (c : Char) : Option Nat :=
  if ('0' ≤ c) && (c ≤ '9') then some (c.toNat - '0'.toNat)
  else if ('a' ≤ c) && (c ≤ 'f') then some (10 + (c.toNat - 'a'.toNat))
  else if ('A' ≤ c) && (c ≤ 'F') then some (10 + (c.toNat - 'A'.toNat))
  else none

private def decodeHexChars : List Char → Option (List UInt8)
  | [] => some []
  | c1 :: c2 :: rest =>
    match hexDigitVal c1, hexDigitVal c2, decodeHexChars rest with
    | some v1, some v2, some tail => some (UInt8.ofNat (v1 * 16 + v2) :: tail)
    | _, _, _ => none
  | [_] => none

private def stripCR (s : String) : String :=
  String.ofList (s.toList.filter (fun c => c != '\r'))

private def parseNatSimple (s : String) : Nat :=
  s.toNat?.getD 0

private def evalBatchLine (line : String) : Option String :=
  let clean := stripCR line
  if clean.isEmpty then none
  else
    match clean.splitOn "\t" with
    | [vecId, modeStr, maxBStr, maxSStr, maxNStr, maxRStr, hexPayload] =>
      let env := if modeStr == "discourse" then envDiscourse else envAtomic
      let budget : ResourceBudget :=
        { maxBytes       := parseNatSimple maxBStr
          maxSteps       := parseNatSimple maxSStr
          maxForestNodes := parseNatSimple maxNStr
          maxReadings    := parseNatSimple maxRStr }
      match decodeHexChars hexPayload.toList with
      | none => some s!"{vecId}\tERR:INVALID_HEX"
      | some rawBytes =>
        let res := certifySemanticConsensus p3cTestCatalog frozenR22NumericConfig env budget rawBytes
        some s!"{vecId}\t{formatOutcomeSig res}"
    | _ => some "ERR:MALFORMED_LINE"

private def exportFixedJson : String :=
  let items := allP3CCases.map fun c =>
    s!"  \{\"caseId\": \"{c.caseId}\", \"pairGroup\": \"{c.pairGroup}\", \"passed\": {c.passed}, \"verdictTag\": \"{c.verdictTag}\"}"
  "[\n" ++ String.intercalate ",\n" items ++ "\n]"

def main (args : List String) : IO UInt32 := do
  match args with
  | ["--export-fixed-json"] =>
    IO.println exportFixedJson
    return 0
  | ["--eval-batch", path] =>
    let content ← IO.FS.readFile path
    for line in content.splitOn "\n" do
      match evalBatchLine line with
      | some out => IO.println out
      | none     => pure ()
    return 0
  | _ =>
    IO.println "=========================================================================="
    IO.println "PNEUMA-NATIVE OMEGA — AUTH-C1-P3-C SEMANTIC NORMALIZATION & CONSENSUS GATE"
    IO.println "Scope     : PO-C1-03 + F-P3C-D01 / D02 / D03 (Isolated P3C_SemanticNorm)"
    IO.println "Toolchain : Lean 4.33.1 Core (Init + Frozen P2/P3-A/P3-B, 0 sorry, 0 ofReduceBool)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for c in allP3CCases do
      let status := if c.passed then "PASS" else "FAIL"
      if c.passed then passCount := passCount + 1
      IO.println s!"[{status}] {c.caseId} ({c.pairGroup}) => {c.verdictTag}"
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"TOTAL CURATED VECTORS : {passCount}/{allP3CCases.length} PASSED"
    if passCount == allP3CCases.length then
      return 0
    else
      return 1
