/-
  PNEUMA-NATIVE Ω — AUTH-C1-P3-C (`PO-C1-03`: Semantic Normalization Soundness)
  01_formal_spec/P3CFormalSpec.lean
-/
import P3CFormalSpec.DeclarativeSemantics
import P3CFormalSpec.CanonicalNormalizer
