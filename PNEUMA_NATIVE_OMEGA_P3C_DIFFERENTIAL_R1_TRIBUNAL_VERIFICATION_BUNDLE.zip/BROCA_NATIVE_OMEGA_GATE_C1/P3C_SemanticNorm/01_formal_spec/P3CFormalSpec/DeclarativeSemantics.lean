/-
  PNEUMA-NATIVE Ω — AUTH-C1-P3-C (`PO-C1-03`: Semantic Normalization Soundness)
  01_formal_spec/P3CFormalSpec/DeclarativeSemantics.lean
  Pure Lean 4.33.1 Core (`Init` + read-only Legacy BROCA `P2`, `P3-A`, `P3-B`)

  Implements Mandatory Pre-Execution Design Contracts `D01` & `D03` (Spec Layer):
    1. Explicit Semantic IR (`RawSemanticTerm`) representing polarity, quantifier scope,
       epistemic/causal modality, temporal precedence, presupposition projection, and
       cohort vs unrestricted scope across `G-01`~`G-16` and `T1`~`T5`.
    2. Algorithm-free Model-Theoretic Denotational Semantics (`SemanticWorld`, `Denotes`)
       defined with ZERO reference to the executable normalizer `N`.
    3. Algorithm-free Inductive Equational Equivalence (`SemEq`, `m₁ ∼_sem m₂`) capturing
       ONLY the authorized `Architecture Freeze R0` equivalences (bound-variable α-renaming,
       De Morgan domain negation `∀x.¬P(x) ↔ ¬∃x.P(x)`, presupposition set order/dedup,
       and non-temporal `∧_sym` associativity/commutativity/idempotence — while strictly
       preserving `preceded` temporal order and `; however,` contrastive order!).
    4. Soundness of `SemEq` w.r.t. `Denotes` (`SemEq m₁ m₂ → ∀ W, Denotes W m₁ ↔ Denotes W m₂`)
       plus concrete model-theoretic refutation theorems (`¬ SemEq`) on `T1`, `T2`, `T4`,
       `G-09` vs `G-10`, and `G-04` temporal-order reversal.
    5. Independent Original `R0` Trap Policy Specification (`TrapPolicyPermitsTree`,
       `TrapPolicyPermitsForest`) traced directly to `S0-R2` / `Gate C0-R1` / `P0-A05`.
-/
import P3BDetachedChecker

namespace PneumaOmega.P3C

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B

/-! ### 1. Explicit Semantic IR (`RawSemanticTerm`) Covering `G-01`~`G-16` & `T1`~`T5` -/

/-- Population scope domain (`S0-R2`: cohort-bound `In <Dc>` vs `T5` unrestricted population). -/
inductive SemanticScope where
  | cohortBound     (cohortId : String)
  | unrestrictedPop                     -- Produced ONLY by `T5` unscoped clause trap
  deriving DecidableEq, Repr

/-- Descriptive distribution summary kind (`G-02a` Mean/SD vs `G-02b` Median/IQR). -/
inductive DistStatKind where
  | meanSD
  | medianIQR
  deriving DecidableEq, Repr

/-- Causal estimation modality (`Gate C0-R1` §II.3 `F-C0-07` 3-axis decomposition). -/
inductive IntervModality where
  | directional         (dirVerb : String) -- `G-06a`: `"increase"` | `"reduce"` (`NullExcluded`)
  | neutralNullIncluded                    -- `G-06b`: `"which did not exclude no effect"` (`NullIncluded`)
  deriving DecidableEq, Repr

/--
  Quantifier & Polarity Forms (`S0-R2` §I.2 & §III `G-11`~`G-13`, `T1`, `T4`):
  Distinguishes:
  - `universalNeg`        : `∀ x ∈ D_s, ¬ P(x)` (`T1 alt=1` surface wide-scope `all ... not`)
  - `negExistential`      : `¬ ∃ x ∈ D_s, P(x)` (`G-11` canonical `"no <Ds> patients developed <E>"`)
  - `negUniversal`        : `¬ ∀ x ∈ D_s, P(x)` (`T1 alt=2` inverse-scope `"not all"`)
  - `properPart`          : `(∃ x ∈ D_s, P(x)) ∧ (∃ y ∈ D_s, ¬ P(y))` (`G-12` `"some, but not all"`)
  - `existentialPos`      : `∃ x ∈ D_s, P(x)` (`G-13` `"at least one"` & `T4 alt=2` existential bare plural)
  - `genericUniversalPos` : `∀_gen x ∈ D_s, P(x)` (`T4 alt=1` generic/universal bare plural)
-/
inductive QuantPredForm where
  | universalNeg        (subgroup eventId : String)
  | negExistential      (subgroup eventId : String)
  | negUniversal        (subgroup eventId : String)
  | properPart          (subgroup eventId : String)
  | existentialPos      (subgroup eventId : String)
  | genericUniversalPos (subgroup eventId : String)
  deriving DecidableEq, Repr

/-- Presupposed proposition projected by factive/wh-complement traps (`T2 alt=2`, `T3`). -/
inductive PresupItem where
  | factiveCausal (activeExp verb outcome : String)
  deriving DecidableEq, Repr

/--
  Core Atomic Clinical Proposition (`S0-R2` + `Gate C0-R1` + `P0-A05`).
  Note (`D01` Honesty): `G-01` right-censored KM/AJ surface is NOT invented here (`HELD_UNSPECIFIED_IN_R0`).
-/
inductive AtomicClaim where
  | descIncidence
      (window eventId numK numN numPct : String)
  | descDist
      (statKind : DistStatKind) (measureId est disp1 : String) (disp2Opt : Option String)
  | assocClaim
      (metric dir activeExp refExp outcome : String)
      (covariatesOpt : Option String)
      (temporalOrder : Option (String × String)) -- `some (evA, evB)` in `G-04`: STRICTLY ORDERED!
      (est ciLevel ciLow ciHigh : String)
  | compRD
      (activeExp refExp outcome est ciLevel ciLow ciHigh : String)
  | intervClaim
      (modality : IntervModality)
      (assumption metric activeExp refExp outcome est ciLevel ciLow ciHigh : String)
      (pValOpt : Option String)
  | metaNotStatSig
      (metric activeExp refExp outcome est ciLevel ciLow ciHigh alpha : String)
  | metaEquiv
      (metric activeExp refExp outcome marginLow marginHigh est ciLevel ciLow ciHigh : String)
  | metaNonEstab
      (sourceId activeExp verb outcome : String)
  | metaUnresolvedPolar
      (sourceId activeExp verb outcome : String)
  | metaWhUnresolved
      (sourceId epVerb whWord activeExp verb outcome : String)
  | quantClaim
      (qform : QuantPredForm)
  deriving DecidableEq, Repr

/--
  Document-level Raw Semantic Term (`RawSemanticTerm`):
  - `scopedAtom`      : Single clause scoped to `scope`, carrying surface bound variable `binderName`
                        (normalized via De Bruijn index in `CanonicalMeaning`), `claim`, and `presups`.
  - `symConj`         : Non-temporal symmetric conjunction `M₁ ∧_sym M₂` (`G-15a`, `G-15b`).
  - `contrastivePair` : Contrastive discourse boundary `M_assoc ; however, M_meta` (`G-16`, non-commutative!).
-/
inductive RawSemanticTerm where
  | scopedAtom
      (scope      : SemanticScope)
      (binderName : String)
      (claim      : AtomicClaim)
      (presups    : List PresupItem)
  | symConj
      (left right : RawSemanticTerm)
  | contrastivePair
      (assocSide metaSide : RawSemanticTerm)
      (sharedExp sharedOut : String)
  deriving DecidableEq, Repr

/-! ### 2. Independent Model-Theoretic Denotational Semantics (`Denotes` — Zero Call to `N`) -/

/--
  Abstract Clinical Model (`SemanticWorld`) used ONLY in declarative `Prop` semantics (`D01`):
  Interprets patient domains, clinical event predicates, event timestamps (for `G-04` `preceded`),
  statistical/causal/epistemic relations, presuppositions, and contrastive discourse coherence
  WITHOUT referencing any normalization or parsing function!
-/
structure SemanticWorld where
  patientDomain      : SemanticScope → String → List Nat
  patientEventHolds  : SemanticScope → String → Nat → Bool
  genericLawHolds    : SemanticScope → String → String → Bool
  eventTimestamp     : SemanticScope → String → Nat
  factTableHolds     : SemanticScope → AtomicClaim → Bool
  presupHolds        : SemanticScope → PresupItem → Bool
  contrastiveCoheres : RawSemanticTerm → RawSemanticTerm → String → String → Bool

/-- Model-theoretic evaluation of `QuantPredForm` over a finite patient cohort domain. -/
def evalQuantForm (W : SemanticWorld) (sc : SemanticScope) : QuantPredForm → Bool
  | .universalNeg sg ev =>
    (W.patientDomain sc sg).all (fun x => !W.patientEventHolds sc ev x)
  | .negExistential sg ev =>
    !((W.patientDomain sc sg).any (fun x => W.patientEventHolds sc ev x))
  | .negUniversal sg ev =>
    !((W.patientDomain sc sg).all (fun x => W.patientEventHolds sc ev x))
  | .properPart sg ev =>
    ((W.patientDomain sc sg).any (fun x => W.patientEventHolds sc ev x)) &&
    ((W.patientDomain sc sg).any (fun x => !W.patientEventHolds sc ev x))
  | .existentialPos sg ev =>
    (W.patientDomain sc sg).any (fun x => W.patientEventHolds sc ev x)
  | .genericUniversalPos sg ev =>
    W.genericLawHolds sc sg ev &&
    (W.patientDomain sc sg).all (fun x => W.patientEventHolds sc ev x)

/-- Model-theoretic evaluation of `AtomicClaim` in `W` at scope `sc`. -/
def evalAtomicClaim (W : SemanticWorld) (sc : SemanticScope) (c : AtomicClaim) : Bool :=
  match c with
  | .quantClaim qf =>
    evalQuantForm W sc qf
  | .assocClaim metric dir act ref out covOpt tempOpt est ciL ciLo ciHi =>
    let baseAtom := AtomicClaim.assocClaim metric dir act ref out covOpt none est ciL ciLo ciHi
    match tempOpt with
    | none => W.factTableHolds sc baseAtom
    | some (evA, evB) =>
      decide (W.eventTimestamp sc evA < W.eventTimestamp sc evB) &&
      W.factTableHolds sc baseAtom
  | other =>
    W.factTableHolds sc other

/-- Model-theoretic truth valuation of `RawSemanticTerm` in `W` (strictly independent of `N`!). -/
def evalDenotation (W : SemanticWorld) : RawSemanticTerm → Bool
  | .scopedAtom sc _binder claim presups =>
    evalAtomicClaim W sc claim &&
    presups.all (fun p => W.presupHolds sc p)
  | .symConj l r =>
    evalDenotation W l && evalDenotation W r
  | .contrastivePair aSide mSide shExp shOut =>
    evalDenotation W aSide &&
    evalDenotation W mSide &&
    W.contrastiveCoheres aSide mSide shExp shOut

/-- **Declarative Denotation Relation (`Denotes W m` — `D01`)**: `m` holds in clinical model `W`. -/
def Denotes (W : SemanticWorld) (m : RawSemanticTerm) : Prop :=
  evalDenotation W m = true

theorem list_all_not_eq_not_any {α : Type} (p : α → Bool) (xs : List α) :
    xs.all (fun x => !p x) = !(xs.any p) := by
  induction xs with
  | nil => rfl
  | cons x rest ih =>
    simp [List.all, List.any, ih, Bool.not_or]

/-! ### 3. Independent Equational Semantic Equivalence (`SemEq`, `m₁ ∼_sem m₂` — `D01`) -/

/-- Set-wise membership equivalence on `List PresupItem` (order & multiplicity invariant). -/
def PresupSetEq (ps₁ ps₂ : List PresupItem) : Prop :=
  ∀ p : PresupItem, p ∈ ps₁ ↔ p ∈ ps₂

/-- Atomic claim equivalence under `R0`'s authorized De Morgan quantifier-negation duality ONLY. -/
inductive AtomicSemEq : AtomicClaim → AtomicClaim → Prop where
  | refl (c : AtomicClaim) :
      AtomicSemEq c c
  | deMorgan_univNeg_negEx (sg ev : String) :
      AtomicSemEq (.quantClaim (.universalNeg sg ev)) (.quantClaim (.negExistential sg ev))
  | deMorgan_negEx_univNeg (sg ev : String) :
      AtomicSemEq (.quantClaim (.negExistential sg ev)) (.quantClaim (.universalNeg sg ev))

theorem atomicSemEq_symm {c₁ c₂ : AtomicClaim} (h : AtomicSemEq c₁ c₂) :
    AtomicSemEq c₂ c₁ := by
  cases h with
  | refl => exact .refl _
  | deMorgan_univNeg_negEx sg ev => exact .deMorgan_negEx_univNeg sg ev
  | deMorgan_negEx_univNeg sg ev => exact .deMorgan_univNeg_negEx sg ev

theorem atomicSemEq_trans {c₁ c₂ c₃ : AtomicClaim}
    (h₁ : AtomicSemEq c₁ c₂) (h₂ : AtomicSemEq c₂ c₃) :
    AtomicSemEq c₁ c₃ := by
  cases h₁ with
  | refl _ => exact h₂
  | deMorgan_univNeg_negEx sg ev =>
    cases h₂ with
    | refl _ => exact .deMorgan_univNeg_negEx sg ev
    | deMorgan_negEx_univNeg _ _ => exact .refl _
  | deMorgan_negEx_univNeg sg ev =>
    cases h₂ with
    | refl _ => exact .deMorgan_negEx_univNeg sg ev
    | deMorgan_univNeg_negEx _ _ => exact .refl _

/--
  **Algorithm-Free Inductive Semantic Equivalence (`SemEq`, `m₁ ∼_sem m₂`)**:
  Generated strictly by `Architecture Freeze R0` (`AC-P0-02` `PO-C1-03` `L3.1`~`L3.3`):
  - `atom_equiv` : Bound-variable α-renaming (`b₁` ↔ `b₂`), `AtomicSemEq` (`∀¬ ↔ ¬∃`), and `PresupSetEq`
  - `symConj`    : Congruence, commutativity, associativity, and idempotence of non-temporal `∧_sym`
  - `contrastive`: Congruence on `contrastivePair` (ONLY when raw sides match structurally on `contrastiveCoheres`
                   or via atomic equivalence — NEVER commuting `assocSide` and `metaSide`!)
-/
inductive SemEq : RawSemanticTerm → RawSemanticTerm → Prop where
  | refl (m : RawSemanticTerm) :
      SemEq m m
  | symm {m₁ m₂ : RawSemanticTerm} :
      SemEq m₁ m₂ → SemEq m₂ m₁
  | trans {m₁ m₂ m₃ : RawSemanticTerm} :
      SemEq m₁ m₂ → SemEq m₂ m₃ → SemEq m₁ m₃
  | atom_equiv (sc : SemanticScope) (b₁ b₂ : String)
      (c₁ c₂ : AtomicClaim) (ps₁ ps₂ : List PresupItem) :
      AtomicSemEq c₁ c₂ →
      PresupSetEq ps₁ ps₂ →
      SemEq (.scopedAtom sc b₁ c₁ ps₁) (.scopedAtom sc b₂ c₂ ps₂)
  | symConj_congr {l₁ l₂ r₁ r₂ : RawSemanticTerm} :
      SemEq l₁ l₂ → SemEq r₁ r₂ → SemEq (.symConj l₁ r₁) (.symConj l₂ r₂)
  | symConj_comm (a b : RawSemanticTerm) :
      SemEq (.symConj a b) (.symConj b a)
  | symConj_assoc (a b c : RawSemanticTerm) :
      SemEq (.symConj (.symConj a b) c) (.symConj a (.symConj b c))
  | symConj_idem (a : RawSemanticTerm) :
      SemEq (.symConj a a) a
  | contrastive_congr {a₁ a₂ m₁ m₂ : RawSemanticTerm} (shExp shOut : String) :
      SemEq a₁ a₂ → SemEq m₁ m₂ →
      SemEq (.contrastivePair a₁ m₁ shExp shOut)
            (.contrastivePair a₂ m₂ shExp shOut)

/-- Well-formedness invariant on `SemanticWorld` respecting extensional equivalence on `contrastiveCoheres`. -/
def ExtensionalContrastiveWorld (W : SemanticWorld) : Prop :=
  ∀ (a₁ a₂ m₁ m₂ : RawSemanticTerm) (shExp shOut : String),
    evalDenotation W a₁ = evalDenotation W a₂ →
    evalDenotation W m₁ = evalDenotation W m₂ →
    W.contrastiveCoheres a₁ m₁ shExp shOut = W.contrastiveCoheres a₂ m₂ shExp shOut

theorem atomicSemEq_eval_eq (W : SemanticWorld) (sc : SemanticScope)
    {c₁ c₂ : AtomicClaim} (h : AtomicSemEq c₁ c₂) :
    evalAtomicClaim W sc c₁ = evalAtomicClaim W sc c₂ := by
  cases h with
  | refl _ => rfl
  | deMorgan_univNeg_negEx sg ev =>
    unfold evalAtomicClaim evalQuantForm
    exact list_all_not_eq_not_any (W.patientEventHolds sc ev) (W.patientDomain sc sg)
  | deMorgan_negEx_univNeg sg ev =>
    unfold evalAtomicClaim evalQuantForm
    exact (list_all_not_eq_not_any (W.patientEventHolds sc ev) (W.patientDomain sc sg)).symm

theorem presupSetEq_eval_eq (W : SemanticWorld) (sc : SemanticScope)
    {ps₁ ps₂ : List PresupItem} (h : PresupSetEq ps₁ ps₂) :
    ps₁.all (W.presupHolds sc) = ps₂.all (W.presupHolds sc) := by
  apply Bool.eq_iff_iff.mpr
  rw [list_all_eq_true, list_all_eq_true]
  constructor
  · intro h1 p hp2
    exact h1 p ((h p).mpr hp2)
  · intro h2 p hp1
    exact h2 p ((h p).mp hp1)

/--
  **Model-Theoretic Soundness of `SemEq` (`D01`)**:
  Whenever `SemEq m₁ m₂` (`m₁ ∼_sem m₂`), `m₁` and `m₂` have IDENTICAL truth values
  in every extensional clinical world `W`!
-/
theorem semEq_sound_for_denotes {m₁ m₂ : RawSemanticTerm} (h : SemEq m₁ m₂)
    (W : SemanticWorld) (hExt : ExtensionalContrastiveWorld W) :
    Denotes W m₁ ↔ Denotes W m₂ := by
  suffices hev : evalDenotation W m₁ = evalDenotation W m₂ by
    unfold Denotes; rw [hev]
  induction h with
  | refl _ => rfl
  | symm _ ih => exact ih.symm
  | trans _ _ ih1 ih2 => exact ih1.trans ih2
  | atom_equiv sc b1 b2 c1 c2 ps1 ps2 hc hps =>
    unfold evalDenotation
    rw [atomicSemEq_eval_eq W sc hc, presupSetEq_eval_eq W sc hps]
  | symConj_congr _ _ ihl ihr =>
    unfold evalDenotation
    rw [ihl, ihr]
  | symConj_comm a b =>
    unfold evalDenotation
    exact Bool.and_comm _ _
  | symConj_assoc a b c =>
    unfold evalDenotation
    exact Bool.and_assoc _ _ _
  | symConj_idem a =>
    change (evalDenotation W a && evalDenotation W a) = evalDenotation W a
    exact Bool.and_self _
  | contrastive_congr shExp shOut _ _ iha ihm =>
    unfold evalDenotation
    rw [iha, ihm, hExt _ _ _ _ shExp shOut iha ihm]

/-! ### 4. Concrete Model-Theoretic Refutation Theorems (`¬ SemEq` Witnesses — `D01` / `D03`) -/

/-- `T1` (`all ... not` wide-scope `∀¬` vs inverse-scope `¬∀`) are PROVABLY NOT `SemEq`! -/
theorem not_semEq_T1_dual_readings (sc : SemanticScope) (sg ev : String) :
    ¬ SemEq (.scopedAtom sc "x" (.quantClaim (.universalNeg sg ev)) [])
            (.scopedAtom sc "x" (.quantClaim (.negUniversal sg ev)) []) := by
  intro hEq
  let W : SemanticWorld :=
    { patientDomain      := fun _ _ => [1, 2]
      patientEventHolds  := fun _ _ pid => pid == 1
      genericLawHolds    := fun _ _ _ => false
      eventTimestamp     := fun _ _ => 0
      factTableHolds     := fun _ _ => false
      presupHolds        := fun _ _ => true
      contrastiveCoheres := fun _ _ _ _ => true }
  have hExt : ExtensionalContrastiveWorld W := fun _ _ _ _ _ _ _ _ => rfl
  have hiff := semEq_sound_for_denotes hEq W hExt
  have h1 : evalDenotation W (.scopedAtom sc "x" (.quantClaim (.universalNeg sg ev)) []) = false := rfl
  have h2 : evalDenotation W (.scopedAtom sc "x" (.quantClaim (.negUniversal sg ev)) []) = true := rfl
  unfold Denotes at hiff
  rw [h1, h2] at hiff
  exact Bool.noConfusion (hiff.mpr rfl)

/-- `T2` (`did not confirm that` non-factive `[]` vs factive `[Presup]`) are PROVABLY NOT `SemEq`! -/
theorem not_semEq_T2_dual_readings (sc : SemanticScope) (src act vb out : String) :
    ¬ SemEq (.scopedAtom sc "x" (.metaNonEstab src act vb out) [])
            (.scopedAtom sc "x" (.metaNonEstab src act vb out) [.factiveCausal act vb out]) := by
  intro hEq
  let W : SemanticWorld :=
    { patientDomain      := fun _ _ => []
      patientEventHolds  := fun _ _ _ => false
      genericLawHolds    := fun _ _ _ => false
      eventTimestamp     := fun _ _ => 0
      factTableHolds     := fun _ _ => true
      presupHolds        := fun _ _ => false
      contrastiveCoheres := fun _ _ _ _ => true }
  have hExt : ExtensionalContrastiveWorld W := fun _ _ _ _ _ _ _ _ => rfl
  have hiff := semEq_sound_for_denotes hEq W hExt
  have h1 : evalDenotation W (.scopedAtom sc "x" (.metaNonEstab src act vb out) []) = true := rfl
  have h2 : evalDenotation W (.scopedAtom sc "x" (.metaNonEstab src act vb out) [.factiveCausal act vb out]) = false := rfl
  unfold Denotes at hiff
  rw [h1, h2] at hiff
  exact Bool.noConfusion (hiff.mp rfl)

/-- `T4` (bare plural generic universal `∀_gen` vs existential `∃`) are PROVABLY NOT `SemEq`! -/
theorem not_semEq_T4_dual_readings (sc : SemanticScope) (sg ev : String) :
    ¬ SemEq (.scopedAtom sc "x" (.quantClaim (.genericUniversalPos sg ev)) [])
            (.scopedAtom sc "x" (.quantClaim (.existentialPos sg ev)) []) := by
  intro hEq
  let W : SemanticWorld :=
    { patientDomain      := fun _ _ => [1, 2]
      patientEventHolds  := fun _ _ pid => pid == 1
      genericLawHolds    := fun _ _ _ => false
      eventTimestamp     := fun _ _ => 0
      factTableHolds     := fun _ _ => false
      presupHolds        := fun _ _ => true
      contrastiveCoheres := fun _ _ _ _ => true }
  have hExt : ExtensionalContrastiveWorld W := fun _ _ _ _ _ _ _ _ => rfl
  have hiff := semEq_sound_for_denotes hEq W hExt
  have h1 : evalDenotation W (.scopedAtom sc "x" (.quantClaim (.genericUniversalPos sg ev)) []) = false := rfl
  have h2 : evalDenotation W (.scopedAtom sc "x" (.quantClaim (.existentialPos sg ev)) []) = true := rfl
  unfold Denotes at hiff
  rw [h1, h2] at hiff
  exact Bool.noConfusion (hiff.mpr rfl)

/-- `G-04` Temporal Precedence (`evA ≺ evB` vs `evB ≺ evA`, when `evA ≠ evB`) is STRICTLY NON-COMMUTATIVE! -/
theorem not_semEq_G04_temporal_reversal
    (sc : SemanticScope) (evA evB metric dir act ref out est ciL ciLo ciHi : String)
    (hne : evA ≠ evB) :
    ¬ SemEq (.scopedAtom sc "x" (.assocClaim metric dir act ref out none (some (evA, evB)) est ciL ciLo ciHi) [])
            (.scopedAtom sc "x" (.assocClaim metric dir act ref out none (some (evB, evA)) est ciL ciLo ciHi) []) := by
  intro hEq
  let W : SemanticWorld :=
    { patientDomain      := fun _ _ => []
      patientEventHolds  := fun _ _ _ => false
      genericLawHolds    := fun _ _ _ => false
      eventTimestamp     := fun _ e => if e == evA then 1 else 2
      factTableHolds     := fun _ _ => true
      presupHolds        := fun _ _ => true
      contrastiveCoheres := fun _ _ _ _ => true }
  have hExt : ExtensionalContrastiveWorld W := fun _ _ _ _ _ _ _ _ => rfl
  have hiff := semEq_sound_for_denotes hEq W hExt
  have hb : (evB == evA) = false := beq_eq_false_iff_ne.mpr hne.symm
  have h1 : evalDenotation W (.scopedAtom sc "x" (.assocClaim metric dir act ref out none (some (evA, evB)) est ciL ciLo ciHi) []) = true := by
    simp [evalDenotation, evalAtomicClaim, W, hb]
  have h2 : evalDenotation W (.scopedAtom sc "x" (.assocClaim metric dir act ref out none (some (evB, evA)) est ciL ciLo ciHi) []) = false := by
    simp [evalDenotation, evalAtomicClaim, W, hb]
  unfold Denotes at hiff
  rw [h1, h2] at hiff
  exact Bool.noConfusion (hiff.mp rfl)

/-! ### 5. Independent Original `R0` Trap Policy Specification (`D03`) -/

/--
  Structured diagnostic for `R0` Trap Policy rejection (`S0-R2` §III + `Gate C0-R1` + `P0-A05`):
  Distinguishes `T3` wh-factive presupposition, `T5` unscoped discourse clause, and `T1`/`T2`/`T4`
  parser-only trap productions independently of `UniversalConsensus`.
-/
inductive TrapPolicyDiag where
  | whFactivePresuppositionForbidden   -- `T3`: `"did not <V> why/how <S>"` projects unlicensed `Presup(S)`
  | unscopedClauseForbidden            -- `T5`: missing `"In <Cohort>,"` / `"Within this same <Design>,"`
  | parserOnlyTrapProduction (rule : CanonicalRuleId) -- `T1`, `T2`, `T4` or wrapper in `G_trap = G_parse \ G_gen`
  | wrapperTrapEnvelope
  deriving DecidableEq, Repr

mutual
  def checkSegsTrapPolicy : List ConcreteParseArg → Option TrapPolicyDiag
    | [] => none
    | .litTok _ _ :: rest => checkSegsTrapPolicy rest
    | .slotTok _ _ _ _ _ :: rest => checkSegsTrapPolicy rest
    | .childSub sub :: rest =>
      match checkTreeTrapPolicy sub with
      | some d => some d
      | none   => checkSegsTrapPolicy rest

  /--
    Checks whether a `ConcreteParseTree` obeys the frozen `R0` admissibility policy (`τ ∈ G_gen`):
    - Rejects `T3` specifically with `.whFactivePresuppositionForbidden`
    - Rejects `T5` specifically with `.unscopedClauseForbidden`
    - Rejects `T1`, `T2`, `T4` with `.parserOnlyTrapProduction r`
    - Rejects trap structural wrappers (`Env_DocTrapScoped`, `Env_ScopedTrap`) with `.wrapperTrapEnvelope`
    - Permits ONLY generator productions (`(frozenProdSig p).isGenerator = true`).
  -/
  def checkTreeTrapPolicy : ConcreteParseTree → Option TrapPolicyDiag
    | .mkTree p _ _ _ args =>
      match p with
      | .Trap_T3_WhPresup    => some .whFactivePresuppositionForbidden
      | .Trap_T5_UnscopedDoc => some .unscopedClauseForbidden
      | .Trap_T1_AllNot      => some (.parserOnlyTrapProduction .T1)
      | .Trap_T2_ConfirmThat => some (.parserOnlyTrapProduction .T2)
      | .Trap_T4_BarePlural  => some (.parserOnlyTrapProduction .T4)
      | .Env_DocTrapScoped   =>
        match checkSegsTrapPolicy args with
        | some d => some d
        | none   => some .wrapperTrapEnvelope
      | .Env_ScopedTrap      =>
        match checkSegsTrapPolicy args with
        | some d => some d
        | none   => some .wrapperTrapEnvelope
      | _ =>
        checkSegsTrapPolicy args
end

def findForestTrapViolation : List ConcreteParseTree → Option TrapPolicyDiag
  | [] => none
  | t :: ts =>
    match checkTreeTrapPolicy t with
    | some d => some d
    | none   => findForestTrapViolation ts

/- Declarative `R0` Trap Policy on a single `ConcreteParseTree` (`AllNodesInG_gen`). -/
mutual
  def AllSegsGeneratorOnly : List ConcreteParseArg → Prop
    | [] => True
    | .litTok _ _ :: rest => AllSegsGeneratorOnly rest
    | .slotTok _ _ _ _ _ :: rest => AllSegsGeneratorOnly rest
    | .childSub sub :: rest => TrapPolicyPermitsTree sub ∧ AllSegsGeneratorOnly rest

  def TrapPolicyPermitsTree : ConcreteParseTree → Prop
    | .mkTree p _ _ _ args =>
      (frozenProdSig p).isGenerator = true ∧ AllSegsGeneratorOnly args
end

/-- **Declarative `TrapPolicyPermitsForest` (`D03`)**: Every parse reading in `T` is in `G_gen` (zero `G_trap` nodes). -/
def TrapPolicyPermitsForest (T : List ConcreteParseTree) : Prop :=
  ∀ τ ∈ T, TrapPolicyPermitsTree τ

mutual
  theorem checkSegsTrapPolicy_none_iff (args : List ConcreteParseArg) :
      checkSegsTrapPolicy args = none ↔ AllSegsGeneratorOnly args := by
    cases args with
    | nil => simp [checkSegsTrapPolicy, AllSegsGeneratorOnly]
    | cons a rest =>
      cases a with
      | litTok _ _ =>
        simpa [checkSegsTrapPolicy, AllSegsGeneratorOnly] using checkSegsTrapPolicy_none_iff rest
      | slotTok _ _ _ _ _ =>
        simpa [checkSegsTrapPolicy, AllSegsGeneratorOnly] using checkSegsTrapPolicy_none_iff rest
      | childSub sub =>
        unfold checkSegsTrapPolicy AllSegsGeneratorOnly
        cases hsub : checkTreeTrapPolicy sub with
        | some d =>
          simp only [reduceCtorEq, false_iff]
          intro h
          have hn := (checkTreeTrapPolicy_none_iff sub).mpr h.1
          rw [hsub] at hn; contradiction
        | none =>
          dsimp only
          rw [checkSegsTrapPolicy_none_iff rest]
          exact ⟨fun hr => ⟨(checkTreeTrapPolicy_none_iff sub).mp hsub, hr⟩, And.right⟩

  theorem checkTreeTrapPolicy_none_iff (t : ConcreteParseTree) :
      checkTreeTrapPolicy t = none ↔ TrapPolicyPermitsTree t := by
    cases t with
    | mkTree p alt loc sp args =>
      cases p <;> unfold checkTreeTrapPolicy TrapPolicyPermitsTree
      case Env_DocTrapScoped =>
        cases checkSegsTrapPolicy args <;> simp [frozenProdSig]
      case Env_ScopedTrap =>
        cases checkSegsTrapPolicy args <;> simp [frozenProdSig]
      case Trap_T1_AllNot => simp [frozenProdSig]
      case Trap_T2_ConfirmThat => simp [frozenProdSig]
      case Trap_T3_WhPresup => simp [frozenProdSig]
      case Trap_T4_BarePlural => simp [frozenProdSig]
      case Trap_T5_UnscopedDoc => simp [frozenProdSig]
      all_goals
        simp [frozenProdSig, checkSegsTrapPolicy_none_iff args]
end

theorem findForestTrapViolation_none_iff (T : List ConcreteParseTree) :
    findForestTrapViolation T = none ↔ TrapPolicyPermitsForest T := by
  induction T with
  | nil => simp [findForestTrapViolation, TrapPolicyPermitsForest]
  | cons t ts ih =>
    unfold findForestTrapViolation TrapPolicyPermitsForest
    cases ht : checkTreeTrapPolicy t with
    | some d =>
      constructor
      · intro h; contradiction
      · intro hall
        have hn := (checkTreeTrapPolicy_none_iff t).mpr (hall t (List.Mem.head ts))
        rw [ht] at hn; contradiction
    | none =>
      dsimp only
      rw [ih]
      have hperm_t := (checkTreeTrapPolicy_none_iff t).mp ht
      constructor
      · intro hts x hx
        rcases List.mem_cons.mp hx with rfl | hm
        · exact hperm_t
        · exact hts x hm
      · intro hall x hx
        exact hall x (List.Mem.tail t hx)

end PneumaOmega.P3C
