/-
  PNEUMA-NATIVE Ω — AUTH-C1-P3-C (`PO-C1-03` & `F-P3C-D01`: Canonical Semantic Normalizer)
  01_formal_spec/P3CFormalSpec/CanonicalNormalizer.lean
  Pure Lean 4.33.1 Core (`Init` + read-only Legacy BROCA `P2`, `P3-A`, `P3-B`, zero `sorry`)

  Implements & proves Mandatory Design Supplement `F-P3C-D01` as FIVE distinct theorems:
    1. `normalizeMeaning_terminates`      : Total termination on all `RawSemanticTerm`s.
    2. `N_preserves_SemEq` & `Denotes`    : `SemEq (N m) m` and `∀ W, Denotes W (N m) ↔ Denotes W m`.
    3. `N_idempotent`                     : `N (N m) = N m` (and `normalizeMeaning (embedCanonical c) = c`).
    4. `isCanonicalNorm_iff_fixedPoint`   : `IsCanonicalNorm m ↔ N m = m`.
    5. `semEq_iff_normalizeMeaning_eq`    : BOTH directions (`normalizeMeaning m₁ = normalizeMeaning m₂ → SemEq m₁ m₂`
                                            AND `SemEq m₁ m₂ → normalizeMeaning m₁ = normalizeMeaning m₂`),
                                            establishing a UNIQUE canonical normal form per `SemEq` equivalence class!
-/
import P3CFormalSpec.DeclarativeSemantics

namespace PneumaOmega.P3C

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B

/-! ### 1. Generic Strict Linear Order & Sorted Duplicate-Free Set Algebra (`SortedStrict`) -/

def ltListNat : List Nat → List Nat → Bool
  | [], [] => false
  | [], _ :: _ => true
  | _ :: _, [] => false
  | x :: xs, y :: ys =>
    if x < y then true
    else if y < x then false
    else ltListNat xs ys

theorem ltListNat_irrefl (xs : List Nat) : ltListNat xs xs = false := by
  induction xs with
  | nil => rfl
  | cons x rest ih =>
    unfold ltListNat
    have hlt : ¬ (x < x) := Nat.lt_irrefl x
    rw [if_neg hlt, if_neg hlt]
    exact ih

theorem ltListNat_trans {xs ys zs : List Nat}
    (h₁ : ltListNat xs ys = true) (h₂ : ltListNat ys zs = true) :
    ltListNat xs zs = true := by
  induction xs generalizing ys zs with
  | nil =>
    cases ys with
    | nil => simp [ltListNat] at h₁
    | cons y rys =>
      cases zs with
      | nil => simp [ltListNat] at h₂
      | cons z rzs => rfl
  | cons x rxs ih =>
    cases ys with
    | nil => simp [ltListNat] at h₁
    | cons y rys =>
      cases zs with
      | nil => simp [ltListNat] at h₂
      | cons z rzs =>
        unfold ltListNat at h₁ h₂ ⊢
        by_cases hxy : x < y
        · rw [if_pos hxy] at h₁
          by_cases hyz : y < z
          · rw [if_pos (Nat.lt_trans hxy hyz)]
          · rw [if_neg hyz] at h₂
            by_cases hzy : z < y
            · rw [if_pos hzy] at h₂; contradiction
            · have hy_eq_z : y = z := by omega
              subst z
              rw [if_pos hxy]
        · rw [if_neg hxy] at h₁
          by_cases hyx : y < x
          · rw [if_pos hyx] at h₁; contradiction
          · rw [if_neg hyx] at h₁
            have hx_eq_y : x = y := by omega
            subst y
            by_cases hxz : x < z
            · rw [if_pos hxz]
            · rw [if_neg hxz] at h₂ ⊢
              by_cases hzx : z < x
              · rw [if_pos hzx] at h₂; contradiction
              · rw [if_neg hzx] at h₂ ⊢
                exact ih h₁ h₂

theorem ltListNat_trichotomy (xs ys : List Nat) :
    ltListNat xs ys = true ∨ xs = ys ∨ ltListNat ys xs = true := by
  induction xs generalizing ys with
  | nil =>
    cases ys with
    | nil => exact Or.inr (Or.inl rfl)
    | cons _ _ => exact Or.inl rfl
  | cons x rxs ih =>
    cases ys with
    | nil => exact Or.inr (Or.inr rfl)
    | cons y rys =>
      by_cases hxy : x < y
      · simp [ltListNat, hxy]
      · by_cases hyx : y < x
        · simp [ltListNat, hxy, hyx]
        · have hxeq : x = y := by omega
          subst y
          have hlt_f : ¬ (x < x) := Nat.lt_irrefl x
          simp only [ltListNat, hlt_f, ↓reduceIte]
          rcases ih rys with hlt1 | rfl | hlt2
          · exact Or.inl hlt1
          · exact Or.inr (Or.inl rfl)
          · exact Or.inr (Or.inr hlt2)

/-- Strict linear order bundle Induced by an injective `List Nat` encoder. -/
structure StrictKeyOrder (α : Type) where
  key  : α → List Nat
  inj  : ∀ x y : α, key x = key y → x = y

def StrictKeyOrder.lt {α : Type} (ord : StrictKeyOrder α) (x y : α) : Bool :=
  ltListNat (ord.key x) (ord.key y)

theorem StrictKeyOrder.lt_irrefl {α : Type} (ord : StrictKeyOrder α) (x : α) :
    ord.lt x x = false :=
  ltListNat_irrefl (ord.key x)

theorem StrictKeyOrder.lt_trans {α : Type} (ord : StrictKeyOrder α) {x y z : α}
    (h₁ : ord.lt x y = true) (h₂ : ord.lt y z = true) :
    ord.lt x z = true :=
  ltListNat_trans h₁ h₂

theorem StrictKeyOrder.lt_trichotomy {α : Type} (ord : StrictKeyOrder α) (x y : α) :
    ord.lt x y = true ∨ x = y ∨ ord.lt y x = true := by
  rcases ltListNat_trichotomy (ord.key x) (ord.key y) with h1 | heq | h2
  · exact Or.inl h1
  · exact Or.inr (Or.inl (ord.inj x y heq))
  · exact Or.inr (Or.inr h2)

/-- Strict sorted duplicate-free list predicate (`all tail elements > head`). -/
def SortedStrict {α : Type} (ord : StrictKeyOrder α) : List α → Prop
  | [] => True
  | x :: xs => (∀ z ∈ xs, ord.lt x z = true) ∧ SortedStrict ord xs

/--
  **Fundamental Canonical Set Uniqueness Lemma (`sortedStrict_ext`)**:
  Two `SortedStrict` lists with the same element membership are IDENTICAL (`xs = ys`)!
-/
theorem sortedStrict_ext {α : Type} (ord : StrictKeyOrder α) {xs ys : List α}
    (hxs : SortedStrict ord xs) (hys : SortedStrict ord ys)
    (hext : ∀ z : α, z ∈ xs ↔ z ∈ ys) :
    xs = ys := by
  induction xs generalizing ys with
  | nil =>
    cases ys with
    | nil => rfl
    | cons y rys =>
      have hm := (hext y).mpr (List.Mem.head rys)
      simp at hm
  | cons x rxs ih =>
    cases ys with
    | nil =>
      have hm := (hext x).mp (List.Mem.head rxs)
      simp at hm
    | cons y rys =>
      rcases hxs with ⟨hx_lt, hrxs⟩
      rcases hys with ⟨hy_lt, hrys⟩
      have hx_in_y : x ∈ y :: rys := (hext x).mp (List.Mem.head rxs)
      have hy_in_x : y ∈ x :: rxs := (hext y).mpr (List.Mem.head rys)
      have hxy_eq : x = y := by
        rcases List.mem_cons.mp hx_in_y with rfl | hx_tail
        · rfl
        · rcases List.mem_cons.mp hy_in_x with rfl | hy_tail
          · rfl
          · exfalso
            have h1 := hy_lt x hx_tail
            have h2 := hx_lt y hy_tail
            have hself := ord.lt_trans h1 h2
            rw [ord.lt_irrefl y] at hself
            contradiction
      subst y
      have htail_ext : ∀ z : α, z ∈ rxs ↔ z ∈ rys := by
        intro z
        constructor
        · intro hz
          have hzx : ord.lt x z = true := hx_lt z hz
          have hne : z ≠ x := by
            intro heq; subst z
            rw [ord.lt_irrefl x] at hzx; contradiction
          rcases List.mem_cons.mp ((hext z).mp (List.Mem.tail x hz)) with rfl | hzy
          · exact False.elim (hne rfl)
          · exact hzy
        · intro hz
          have hzx : ord.lt x z = true := hy_lt z hz
          have hne : z ≠ x := by
            intro heq; subst z
            rw [ord.lt_irrefl x] at hzx; contradiction
          rcases List.mem_cons.mp ((hext z).mpr (List.Mem.tail x hz)) with rfl | hzx_m
          · exact False.elim (hne rfl)
          · exact hzx_m
      rw [ih hrxs hrys htail_ext]

def sortedInsert {α : Type} (ord : StrictKeyOrder α) (x : α) : List α → List α
  | [] => [x]
  | y :: ys =>
    if ord.lt x y then x :: y :: ys
    else if ord.lt y x then y :: sortedInsert ord x ys
    else y :: ys

theorem sortedInsert_nonempty {α : Type} (ord : StrictKeyOrder α) (x : α) (ys : List α) :
    sortedInsert ord x ys ≠ [] := by
  cases ys with
  | nil => simp [sortedInsert]
  | cons y rys =>
    unfold sortedInsert
    split
    · simp
    · split <;> simp

theorem mem_sortedInsert_iff {α : Type} (ord : StrictKeyOrder α) (x : α) (ys : List α) (z : α) :
    z ∈ sortedInsert ord x ys ↔ z = x ∨ z ∈ ys := by
  induction ys with
  | nil => simp [sortedInsert]
  | cons y rys ih =>
    unfold sortedInsert
    by_cases hxy : ord.lt x y = true
    · rw [if_pos hxy]
      simp
    · rw [if_neg hxy]
      by_cases hyx : ord.lt y x = true
      · rw [if_pos hyx]
        simp only [List.mem_cons, ih]
        constructor
        · rintro (rfl | rfl | hm)
          · exact Or.inr (Or.inl rfl)
          · exact Or.inl rfl
          · exact Or.inr (Or.inr hm)
        · rintro (rfl | rfl | hm)
          · exact Or.inr (Or.inl rfl)
          · exact Or.inl rfl
          · exact Or.inr (Or.inr hm)
      · rw [if_neg hyx]
        rcases ord.lt_trichotomy x y with h1 | rfl | h2
        · exact False.elim (hxy h1)
        · simp only [List.mem_cons]
          constructor
          · rintro (rfl | hm)
            · exact Or.inl rfl
            · exact Or.inr (Or.inr hm)
          · rintro (rfl | rfl | hm)
            · exact Or.inl rfl
            · exact Or.inl rfl
            · exact Or.inr hm
        · exact False.elim (hyx h2)

theorem sortedInsert_sorted {α : Type} (ord : StrictKeyOrder α) (x : α) {ys : List α}
    (hys : SortedStrict ord ys) :
    SortedStrict ord (sortedInsert ord x ys) := by
  induction ys with
  | nil => exact ⟨by simp, trivial⟩
  | cons y rys ih =>
    rcases hys with ⟨hy_lt, hrys⟩
    unfold sortedInsert
    by_cases hxy : ord.lt x y = true
    · rw [if_pos hxy]
      refine ⟨?_, hy_lt, hrys⟩
      intro z hz
      rcases List.mem_cons.mp hz with rfl | hm
      · exact hxy
      · exact ord.lt_trans hxy (hy_lt z hm)
    · rw [if_neg hxy]
      by_cases hyx : ord.lt y x = true
      · rw [if_pos hyx]
        refine ⟨?_, ih hrys⟩
        intro z hz
        rcases (mem_sortedInsert_iff ord x rys z).mp hz with rfl | hm
        · exact hyx
        · exact hy_lt z hm
      · rw [if_neg hyx]
        exact ⟨hy_lt, hrys⟩

def sortedUnion {α : Type} (ord : StrictKeyOrder α) : List α → List α → List α
  | [], ys => ys
  | x :: xs, ys => sortedInsert ord x (sortedUnion ord xs ys)

theorem mem_sortedUnion_iff {α : Type} (ord : StrictKeyOrder α) (xs ys : List α) (z : α) :
    z ∈ sortedUnion ord xs ys ↔ z ∈ xs ∨ z ∈ ys := by
  induction xs with
  | nil => simp [sortedUnion]
  | cons x rxs ih =>
    unfold sortedUnion
    rw [mem_sortedInsert_iff, ih, List.mem_cons, or_assoc]

theorem sortedUnion_sorted {α : Type} (ord : StrictKeyOrder α) (xs : List α) {ys : List α}
    (hys : SortedStrict ord ys) :
    SortedStrict ord (sortedUnion ord xs ys) := by
  induction xs with
  | nil => exact hys
  | cons x rxs ih =>
    exact sortedInsert_sorted ord x (ih)

theorem sortedUnion_nonempty_left {α : Type} (ord : StrictKeyOrder α) {xs : List α} (ys : List α)
    (hne : xs ≠ []) :
    sortedUnion ord xs ys ≠ [] := by
  cases xs with
  | nil => exact False.elim (hne rfl)
  | cons x rxs => exact sortedInsert_nonempty ord x _

def dedupSort {α : Type} (ord : StrictKeyOrder α) (xs : List α) : List α :=
  sortedUnion ord xs []

theorem dedupSort_sorted {α : Type} (ord : StrictKeyOrder α) (xs : List α) :
    SortedStrict ord (dedupSort ord xs) :=
  sortedUnion_sorted ord xs trivial

theorem mem_dedupSort_iff {α : Type} (ord : StrictKeyOrder α) (xs : List α) (z : α) :
    z ∈ dedupSort ord xs ↔ z ∈ xs := by
  unfold dedupSort
  simp [mem_sortedUnion_iff]

/-! ### 2. Length-Prefixed Injective `List Nat` Encoders (`PresupItem`, `AtomicClaim`, `NormItem`) -/

def packNatField (xs : List Nat) : List Nat :=
  xs.length :: xs

private theorem append_eq_of_eq_len_nat {l₁ r₁ l₂ r₂ : List Nat}
    (heq : l₁ ++ r₁ = l₂ ++ r₂) (hlen : l₁.length = l₂.length) :
    l₁ = l₂ ∧ r₁ = r₂ := by
  induction l₁ generalizing l₂ with
  | nil =>
    cases l₂ with
    | nil => exact ⟨rfl, heq⟩
    | cons _ _ => simp at hlen
  | cons x xs ih =>
    cases l₂ with
    | nil => simp at hlen
    | cons y ys =>
      simp at heq hlen
      have ⟨hxs, hrs⟩ := ih heq.2 hlen
      exact ⟨by rw [heq.1, hxs], hrs⟩

theorem packNatField_append_inj {x₁ x₂ r₁ r₂ : List Nat}
    (h : packNatField x₁ ++ r₁ = packNatField x₂ ++ r₂) :
    x₁ = x₂ ∧ r₁ = r₂ := by
  unfold packNatField at h
  simp only [List.cons_append] at h
  injection h with hlen htail
  exact append_eq_of_eq_len_nat htail hlen

def encStr (s : String) : List Nat :=
  s.toList.map (fun c => c.val.toNat)

private theorem char_val_toNat_inj {c₁ c₂ : Char} (h : c₁.val.toNat = c₂.val.toNat) :
    c₁ = c₂ := by
  rcases c₁ with ⟨⟨⟨v₁, _⟩⟩, _⟩
  rcases c₂ with ⟨⟨⟨v₂, _⟩⟩, _⟩
  change v₁ = v₂ at h
  subst v₁
  rfl

private theorem list_map_char_inj {cs₁ cs₂ : List Char}
    (h : cs₁.map (fun c => c.val.toNat) = cs₂.map (fun c => c.val.toNat)) :
    cs₁ = cs₂ := by
  induction cs₁ generalizing cs₂ with
  | nil =>
    cases cs₂ <;> simp at h
    rfl
  | cons x xs ih =>
    cases cs₂ with
    | nil => simp at h
    | cons y ys =>
      simp at h
      rw [char_val_toNat_inj h.1, ih h.2]

theorem encStr_inj {s₁ s₂ : String} (h : encStr s₁ = encStr s₂) : s₁ = s₂ :=
  String.ext_iff.mpr (list_map_char_inj h)

def encStrList : List String → List Nat
  | [] => []
  | s :: rest => packNatField (encStr s) ++ encStrList rest

theorem encStrList_inj {xs ys : List String} (h : encStrList xs = encStrList ys) :
    xs = ys := by
  induction xs generalizing ys with
  | nil =>
    cases ys with
    | nil => rfl
    | cons y rys => simp [encStrList, packNatField] at h
  | cons x rxs ih =>
    cases ys with
    | nil => simp [encStrList, packNatField] at h
    | cons y rys =>
      unfold encStrList at h
      have ⟨hx, hr⟩ := packNatField_append_inj h
      rw [encStr_inj hx, ih hr]

def encPresup : PresupItem → List Nat
  | .factiveCausal act vb out => encStrList [act, vb, out]

theorem encPresup_inj (p₁ p₂ : PresupItem) (h : encPresup p₁ = encPresup p₂) : p₁ = p₂ := by
  cases p₁ with
  | factiveCausal a1 v1 o1 =>
    cases p₂ with
    | factiveCausal a2 v2 o2 =>
      have hl := encStrList_inj h
      simp at hl
      rcases hl with ⟨rfl, rfl, rfl⟩
      rfl

def presupOrder : StrictKeyOrder PresupItem :=
  { key := encPresup, inj := encPresup_inj }

def encPresupList : List PresupItem → List Nat
  | [] => []
  | p :: ps => packNatField (encPresup p) ++ encPresupList ps

theorem encPresupList_inj {xs ys : List PresupItem} (h : encPresupList xs = encPresupList ys) :
    xs = ys := by
  induction xs generalizing ys with
  | nil =>
    cases ys with
    | nil => rfl
    | cons _ _ => simp [encPresupList, packNatField] at h
  | cons x rxs ih =>
    cases ys with
    | nil => simp [encPresupList, packNatField] at h
    | cons y rys =>
      unfold encPresupList at h
      have ⟨hx, hr⟩ := packNatField_append_inj h
      rw [encPresup_inj x y hx, ih hr]

def encScope : SemanticScope → List Nat
  | .unrestrictedPop => [0]
  | .cohortBound cid => 1 :: encStr cid

theorem encScope_inj {s₁ s₂ : SemanticScope} (h : encScope s₁ = encScope s₂) : s₁ = s₂ := by
  cases s₁ <;> cases s₂ <;> simp [encScope] at h ⊢
  exact encStr_inj h

def encOptStr : Option String → List String
  | none   => ["0"]
  | some s => ["1", s]

theorem encOptStr_inj {o₁ o₂ : Option String} (h : encOptStr o₁ = encOptStr o₂) : o₁ = o₂ := by
  cases o₁ <;> cases o₂ <;> simp [encOptStr] at h ⊢
  exact h

def encOptPairStr : Option (String × String) → List String
  | none        => ["0", "", ""]
  | some (a, b) => ["1", a, b]

theorem encOptPairStr_inj {o₁ o₂ : Option (String × String)}
    (h : encOptPairStr o₁ = encOptPairStr o₂) : o₁ = o₂ := by
  cases o₁ with
  | none =>
    cases o₂ with
    | none => rfl
    | some p2 => simp [encOptPairStr] at h
  | some p1 =>
    rcases p1 with ⟨a1, b1⟩
    cases o₂ with
    | none => simp [encOptPairStr] at h
    | some p2 =>
      rcases p2 with ⟨a2, b2⟩
      simp [encOptPairStr] at h
      rcases h with ⟨rfl, rfl⟩
      rfl

def encQuantForm : QuantPredForm → Nat × List String
  | .universalNeg sg ev        => (0, [sg, ev])
  | .negExistential sg ev      => (1, [sg, ev])
  | .negUniversal sg ev        => (2, [sg, ev])
  | .properPart sg ev          => (3, [sg, ev])
  | .existentialPos sg ev      => (4, [sg, ev])
  | .genericUniversalPos sg ev => (5, [sg, ev])

theorem encQuantForm_inj {q₁ q₂ : QuantPredForm} (h : encQuantForm q₁ = encQuantForm q₂) :
    q₁ = q₂ := by
  cases q₁ <;> cases q₂ <;> simp [encQuantForm] at h
  all_goals
    rcases h with ⟨rfl, rfl⟩
    rfl

def encAtomicClaim : AtomicClaim → List Nat
  | .descIncidence w e k n p =>
    0 :: encStrList [w, e, k, n, p]
  | .descDist k m est d1 d2o =>
    1 :: (match k with | .meanSD => 0 | .medianIQR => 1) :: encStrList ([m, est, d1] ++ encOptStr d2o)
  | .assocClaim met dir act ref out covO tmpO est ciL ciLo ciHi =>
    2 :: encStrList ([met, dir, act, ref, out, est, ciL, ciLo, ciHi] ++ encOptStr covO ++ encOptPairStr tmpO)
  | .compRD act ref out est ciL ciLo ciHi =>
    3 :: encStrList [act, ref, out, est, ciL, ciLo, ciHi]
  | .intervClaim mod assump met act ref out est ciL ciLo ciHi pvO =>
    4 :: (match mod with
          | .directional vb => 0 :: encStrList ([vb, assump, met, act, ref, out, est, ciL, ciLo, ciHi] ++ encOptStr pvO)
          | .neutralNullIncluded => 1 :: encStrList ([assump, met, act, ref, out, est, ciL, ciLo, ciHi] ++ encOptStr pvO))
  | .metaNotStatSig met act ref out est ciL ciLo ciHi al =>
    5 :: encStrList [met, act, ref, out, est, ciL, ciLo, ciHi, al]
  | .metaEquiv met act ref out mLo mHi est ciL ciLo ciHi =>
    6 :: encStrList [met, act, ref, out, mLo, mHi, est, ciL, ciLo, ciHi]
  | .metaNonEstab src act vb out =>
    7 :: encStrList [src, act, vb, out]
  | .metaUnresolvedPolar src act vb out =>
    8 :: encStrList [src, act, vb, out]
  | .metaWhUnresolved src ep wh act vb out =>
    9 :: encStrList [src, ep, wh, act, vb, out]
  | .quantClaim qf =>
    let (qt, qs) := encQuantForm qf
    10 :: qt :: encStrList qs

theorem encAtomicClaim_inj {c₁ c₂ : AtomicClaim} (h : encAtomicClaim c₁ = encAtomicClaim c₂) :
    c₁ = c₂ := by
  cases c₁ <;> cases c₂ <;> simp [encAtomicClaim] at h
  case descIncidence.descIncidence =>
    have hl := encStrList_inj h; simp at hl; rcases hl with ⟨rfl, rfl, rfl, rfl, rfl⟩; rfl
  case descDist.descDist k1 m1 e1 d11 d21 k2 m2 e2 d12 d22 =>
    cases k1 <;> cases k2 <;> simp at h
    all_goals
      have hl := encStrList_inj h; simp at hl
      rcases hl with ⟨rfl, rfl, rfl, ho⟩
      rw [encOptStr_inj ho]
  case assocClaim.assocClaim met1 dir1 act1 ref1 out1 cov1 tmp1 est1 cl1 clo1 chi1
                             met2 dir2 act2 ref2 out2 cov2 tmp2 est2 cl2 clo2 chi2 =>
    have hl := encStrList_inj h; simp at hl
    rcases hl with ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, htail⟩
    cases cov1 <;> cases cov2 <;> simp [encOptStr] at htail
    · rw [encOptPairStr_inj htail]
    · rcases htail with ⟨rfl, htmp⟩
      rw [encOptPairStr_inj htmp]
  case compRD.compRD =>
    have hl := encStrList_inj h; simp at hl; rcases hl with ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩; rfl
  case intervClaim.intervClaim mod1 a1 m1 ac1 rf1 o1 e1 cl1 clo1 chi1 pv1
                               mod2 a2 m2 ac2 rf2 o2 e2 cl2 clo2 chi2 pv2 =>
    cases mod1 <;> cases mod2 <;> simp at h
    · have hl := encStrList_inj h; simp at hl
      rcases hl with ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, ho⟩
      rw [encOptStr_inj ho]
    · have hl := encStrList_inj h; simp at hl
      rcases hl with ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, ho⟩
      rw [encOptStr_inj ho]
  case metaNotStatSig.metaNotStatSig =>
    have hl := encStrList_inj h; simp at hl
    rcases hl with ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩; rfl
  case metaEquiv.metaEquiv =>
    have hl := encStrList_inj h; simp at hl
    rcases hl with ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩; rfl
  case metaNonEstab.metaNonEstab =>
    have hl := encStrList_inj h; simp at hl; rcases hl with ⟨rfl, rfl, rfl, rfl⟩; rfl
  case metaUnresolvedPolar.metaUnresolvedPolar =>
    have hl := encStrList_inj h; simp at hl; rcases hl with ⟨rfl, rfl, rfl, rfl⟩; rfl
  case metaWhUnresolved.metaWhUnresolved =>
    have hl := encStrList_inj h; simp at hl; rcases hl with ⟨rfl, rfl, rfl, rfl, rfl, rfl⟩; rfl
  case quantClaim.quantClaim q1 q2 =>
    cases q1 <;> cases q2 <;> simp [encQuantForm] at h
    all_goals
      have hl := encStrList_inj h; simp at hl; rcases hl with ⟨rfl, rfl⟩; rfl

/-! ### 3. Canonical Normal Form AST (`NormItem` & `CanonicalMeaning`) -/

def canonicalBinderDeBruijn : String := "_db0"

/-- Normalizes `AtomicClaim` (`universalNeg` `∀x.¬P(x)` ↦ `negExistential` `¬∃x.P(x)`). -/
def normalizeAtomicClaim : AtomicClaim → AtomicClaim
  | .quantClaim (.universalNeg sg ev) => .quantClaim (.negExistential sg ev)
  | other => other

theorem normalizeAtomicClaim_semEq (c : AtomicClaim) :
    AtomicSemEq (normalizeAtomicClaim c) c := by
  cases c with
  | quantClaim qf =>
    cases qf <;> first | exact .deMorgan_negEx_univNeg _ _ | exact .refl _
  | _ => exact .refl _

theorem normalizeAtomicClaim_idem (c : AtomicClaim) :
    normalizeAtomicClaim (normalizeAtomicClaim c) = normalizeAtomicClaim c := by
  cases c with
  | quantClaim qf => cases qf <;> rfl
  | _ => rfl

theorem atomicSemEq_implies_normalize_eq {c₁ c₂ : AtomicClaim}
    (h : AtomicSemEq c₁ c₂) :
    normalizeAtomicClaim c₁ = normalizeAtomicClaim c₂ := by
  cases h <;> rfl

/-- Irreducible conjunct in canonical normal form (`normAtom` or ordered `normContrastive`). -/
inductive NormItem where
  | normAtom
      (scope   : SemanticScope)
      (claim   : AtomicClaim)
      (presups : List PresupItem)
  | normContrastive
      (assocItems metaItems : List NormItem)
      (sharedExp sharedOut  : String)

mutual
  def encNormItem : NormItem → List Nat
    | .normAtom sc cl ps =>
      0 :: packNatField (encScope sc) ++ packNatField (encAtomicClaim cl) ++ encPresupList ps
    | .normContrastive aItems mItems shExp shOut =>
      1 :: packNatField (encNormItemList aItems) ++
           packNatField (encNormItemList mItems) ++
           encStrList [shExp, shOut]

  def encNormItemList : List NormItem → List Nat
    | [] => []
    | x :: xs => packNatField (encNormItem x) ++ encNormItemList xs
end

mutual
  theorem encNormItem_inj (x y : NormItem) (h : encNormItem x = encNormItem y) : x = y := by
    cases x with
    | normAtom sc1 cl1 ps1 =>
      cases y with
      | normContrastive _ _ _ _ => simp [encNormItem] at h
      | normAtom sc2 cl2 ps2 =>
        unfold encNormItem at h
        simp only [List.cons_append, List.cons.injEq, List.append_assoc, true_and] at h
        have ⟨hsc, hrest1⟩ := packNatField_append_inj h
        have ⟨hcl, hps⟩ := packNatField_append_inj hrest1
        rw [encScope_inj hsc, encAtomicClaim_inj hcl, encPresupList_inj hps]
    | normContrastive a1 m1 e1 o1 =>
      cases y with
      | normAtom _ _ _ => simp [encNormItem] at h
      | normContrastive a2 m2 e2 o2 =>
        unfold encNormItem at h
        simp only [List.cons_append, List.cons.injEq, List.append_assoc, true_and] at h
        have ⟨ha, hrest1⟩ := packNatField_append_inj h
        have ⟨hm, hstr⟩ := packNatField_append_inj hrest1
        have hso := encStrList_inj hstr
        simp at hso
        rcases hso with ⟨rfl, rfl⟩
        rw [encNormItemList_inj a1 a2 ha, encNormItemList_inj m1 m2 hm]

  theorem encNormItemList_inj (xs ys : List NormItem) (h : encNormItemList xs = encNormItemList ys) :
      xs = ys := by
    cases xs with
    | nil =>
      cases ys with
      | nil => rfl
      | cons _ _ => simp [encNormItemList, packNatField] at h
    | cons x rxs =>
      cases ys with
      | nil => simp [encNormItemList, packNatField] at h
      | cons y rys =>
        unfold encNormItemList at h
        have ⟨hx, hr⟩ := packNatField_append_inj h
        rw [encNormItem_inj x y hx, encNormItemList_inj rxs rys hr]
end

def eqListNatBool : List Nat → List Nat → Bool
  | [], [] => true
  | x :: xs, y :: ys => (x == y) && eqListNatBool xs ys
  | _, _ => false

theorem eqListNatBool_iff (xs ys : List Nat) :
    eqListNatBool xs ys = true ↔ xs = ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp [eqListNatBool]
  | cons x rxs ih =>
    cases ys with
    | nil => simp [eqListNatBool]
    | cons y rys =>
      unfold eqListNatBool
      rw [Bool.and_eq_true, beq_iff_eq, ih]
      simp

instance : DecidableEq NormItem := fun x y =>
  if h : eqListNatBool (encNormItem x) (encNormItem y) = true then
    isTrue (encNormItem_inj x y ((eqListNatBool_iff _ _).mp h))
  else
    isFalse (fun heq => h ((eqListNatBool_iff _ _).mpr (congrArg encNormItem heq)))

/-- Canonical Meaning (`CanonicalMeaning`): non-empty, sorted, duplicate-free `symConj` list of `NormItem`s. -/
structure CanonicalMeaning where
  items : List NormItem
  deriving DecidableEq

/-- Fast pure-`Bool` equality on `CanonicalMeaning` (avoids propositional proof construction in kernel WHNF). -/
def canonicalMeaningEqBool (c₁ c₂ : CanonicalMeaning) : Bool :=
  eqListNatBool (encNormItemList c₁.items) (encNormItemList c₂.items)

theorem canonicalMeaningEqBool_iff (c₁ c₂ : CanonicalMeaning) :
    canonicalMeaningEqBool c₁ c₂ = true ↔ c₁ = c₂ := by
  cases c₁ with
  | mk items1 =>
    cases c₂ with
    | mk items2 =>
      unfold canonicalMeaningEqBool
      dsimp only
      rw [eqListNatBool_iff]
      constructor
      · intro h
        rw [encNormItemList_inj items1 items2 h]
      · intro h
        injection h with hi
        rw [hi]

def normItemOrder : StrictKeyOrder NormItem :=
  { key := encNormItem, inj := encNormItem_inj }

/-! ### 4. Executable Normalizer (`normalizeMeaning`) & Canonical Embedding (`embedCanonical`, `N`) -/

def normalizeToItems : RawSemanticTerm → List NormItem
  | .scopedAtom sc _binder claim presups =>
    [NormItem.normAtom sc (normalizeAtomicClaim claim) (dedupSort presupOrder presups)]
  | .symConj l r =>
    sortedUnion normItemOrder (normalizeToItems l) (normalizeToItems r)
  | .contrastivePair aSide mSide shExp shOut =>
    [NormItem.normContrastive (normalizeToItems aSide) (normalizeToItems mSide) shExp shOut]

/-- **Executable Semantic Normalizer (`normalizeMeaning : RawSemanticTerm → CanonicalMeaning`)**. -/
def normalizeMeaning (m : RawSemanticTerm) : CanonicalMeaning :=
  { items := normalizeToItems m }

theorem normalizeToItems_nonempty (m : RawSemanticTerm) :
    normalizeToItems m ≠ [] := by
  induction m with
  | scopedAtom _ _ _ _ => simp [normalizeToItems]
  | symConj l r ihl _ =>
    exact sortedUnion_nonempty_left normItemOrder (normalizeToItems r) ihl
  | contrastivePair _ _ _ _ => simp [normalizeToItems]

theorem normalizeToItems_sorted (m : RawSemanticTerm) :
    SortedStrict normItemOrder (normalizeToItems m) := by
  induction m with
  | scopedAtom _ _ _ _ => exact ⟨by simp, trivial⟩
  | symConj l r _ ihr =>
    exact sortedUnion_sorted normItemOrder (normalizeToItems l) ihr
  | contrastivePair _ _ _ _ => exact ⟨by simp, trivial⟩

mutual
  def embedNormItem : NormItem → RawSemanticTerm
    | .normAtom sc claim presups =>
      .scopedAtom sc canonicalBinderDeBruijn claim presups
    | .normContrastive aItems mItems shExp shOut =>
      .contrastivePair (embedNormItemList aItems) (embedNormItemList mItems) shExp shOut

  def embedNormItemList : List NormItem → RawSemanticTerm
    | [] => .scopedAtom .unrestrictedPop canonicalBinderDeBruijn (.quantClaim (.negExistential "" "")) []
    | [x] => embedNormItem x
    | x :: y :: rest => .symConj (embedNormItem x) (embedNormItemList (y :: rest))
end

def embedCanonical (c : CanonicalMeaning) : RawSemanticTerm :=
  embedNormItemList c.items

/-- Endomorphic Normalizer `N : RawSemanticTerm → RawSemanticTerm` (`N(m) = embedCanonical (normalizeMeaning m)`). -/
def N (m : RawSemanticTerm) : RawSemanticTerm :=
  embedCanonical (normalizeMeaning m)

/- Declarative Characterization of Canonical Normal Terms (`IsCanonicalNorm`). -/
mutual
  def WellFormedNormItem : NormItem → Prop
    | .normAtom _ claim presups =>
      normalizeAtomicClaim claim = claim ∧ SortedStrict presupOrder presups
    | .normContrastive aItems mItems _ _ =>
      aItems ≠ [] ∧ SortedStrict normItemOrder aItems ∧ WellFormedNormItemList aItems ∧
      mItems ≠ [] ∧ SortedStrict normItemOrder mItems ∧ WellFormedNormItemList mItems

  def WellFormedNormItemList : List NormItem → Prop
    | [] => True
    | x :: xs => WellFormedNormItem x ∧ WellFormedNormItemList xs
end

def IsCanonicalNorm (m : RawSemanticTerm) : Prop :=
  ∃ items : List NormItem,
    items ≠ [] ∧
    SortedStrict normItemOrder items ∧
    WellFormedNormItemList items ∧
    m = embedNormItemList items

/-! ### 5. Proof of All Five `D01` / `PO-C1-03` Theorems -/

/-- **Theorem `D01.1` (`normalizeMeaning_terminates`)**: Total termination on all `RawSemanticTerm`s. -/
theorem normalizeMeaning_terminates (m : RawSemanticTerm) :
    ∃ c : CanonicalMeaning, normalizeMeaning m = c :=
  ⟨_, rfl⟩

private theorem semEq_embedInsert (x : NormItem) (ys : List NormItem) (hne : ys ≠ []) :
    SemEq (embedNormItemList (sortedInsert normItemOrder x ys))
          (.symConj (embedNormItem x) (embedNormItemList ys)) := by
  induction ys with
  | nil => exact False.elim (hne rfl)
  | cons y rys ih =>
    cases rys with
    | nil =>
      unfold sortedInsert
      by_cases hxy : normItemOrder.lt x y = true
      · rw [if_pos hxy]
        exact .refl _
      · rw [if_neg hxy]
        by_cases hyx : normItemOrder.lt y x = true
        · rw [if_pos hyx]
          unfold sortedInsert embedNormItemList
          exact .symConj_comm (embedNormItem y) (embedNormItem x)
        · rw [if_neg hyx]
          rcases normItemOrder.lt_trichotomy x y with h1 | rfl | h2
          · exact False.elim (hxy h1)
          · unfold embedNormItemList
            exact .symm (.symConj_idem (embedNormItem x))
          · exact False.elim (hyx h2)
    | cons y2 rtail =>
      unfold sortedInsert
      by_cases hxy : normItemOrder.lt x y = true
      · rw [if_pos hxy]
        exact .refl _
      · rw [if_neg hxy]
        by_cases hyx : normItemOrder.lt y x = true
        · rw [if_pos hyx]
          have hne_rec : sortedInsert normItemOrder x (y2 :: rtail) ≠ [] :=
            sortedInsert_nonempty normItemOrder x (y2 :: rtail)
          cases hins : sortedInsert normItemOrder x (y2 :: rtail) with
          | nil => exact False.elim (hne_rec hins)
          | cons z rzs =>
            have hstep : SemEq (embedNormItemList (z :: rzs))
                               (.symConj (embedNormItem x) (embedNormItemList (y2 :: rtail))) := by
              rw [← hins]
              exact ih (by simp)
            have h1 : SemEq (embedNormItemList (y :: z :: rzs))
                            (.symConj (embedNormItem y) (.symConj (embedNormItem x) (embedNormItemList (y2 :: rtail)))) :=
              .symConj_congr (.refl _) hstep
            -- Swap `y` and `x` via associativity & commutativity of `symConj`:
            have hswap : SemEq (.symConj (embedNormItem y) (.symConj (embedNormItem x) (embedNormItemList (y2 :: rtail))))
                               (.symConj (embedNormItem x) (.symConj (embedNormItem y) (embedNormItemList (y2 :: rtail)))) :=
              .trans (.symm (.symConj_assoc _ _ _))
                (.trans (.symConj_congr (.symConj_comm _ _) (.refl _))
                        (.symConj_assoc _ _ _))
            exact .trans h1 hswap
        · rw [if_neg hyx]
          rcases normItemOrder.lt_trichotomy x y with h1 | rfl | h2
          · exact False.elim (hxy h1)
          · -- `y :: y2 :: rtail` vs `x :: y :: y2 :: rtail` where `y = x`:
            change SemEq (.symConj (embedNormItem x) (embedNormItemList (y2 :: rtail)))
                         (.symConj (embedNormItem x) (.symConj (embedNormItem x) (embedNormItemList (y2 :: rtail))))
            exact .trans (.symConj_congr (.symm (.symConj_idem (embedNormItem x))) (.refl _))
                         (.symConj_assoc _ _ _)
          · exact False.elim (hyx h2)

private theorem semEq_embedUnion (xs ys : List NormItem) (hx : xs ≠ []) (hy : ys ≠ []) :
    SemEq (embedNormItemList (sortedUnion normItemOrder xs ys))
          (.symConj (embedNormItemList xs) (embedNormItemList ys)) := by
  induction xs with
  | nil => exact False.elim (hx rfl)
  | cons x rxs ih =>
    cases rxs with
    | nil =>
      simp only [sortedUnion, embedNormItemList]
      exact semEq_embedInsert x ys hy
    | cons x2 rtail =>
      unfold sortedUnion
      have hne_u : sortedUnion normItemOrder (x2 :: rtail) ys ≠ [] :=
        sortedUnion_nonempty_left normItemOrder ys (by simp)
      have hins := semEq_embedInsert x (sortedUnion normItemOrder (x2 :: rtail) ys) hne_u
      have hih := ih (by simp)
      have hcongr : SemEq (.symConj (embedNormItem x) (embedNormItemList (sortedUnion normItemOrder (x2 :: rtail) ys)))
                          (.symConj (embedNormItem x) (.symConj (embedNormItemList (x2 :: rtail)) (embedNormItemList ys))) :=
        .symConj_congr (.refl _) hih
      exact .trans hins (.trans hcongr (.symm (.symConj_assoc _ _ _)))

/--
  **Theorem `D01.2a` (`N_preserves_SemEq`)**:
  Every normalized meaning `N m` is semantically equivalent (`SemEq (N m) m`) to the input `m`!
-/
theorem N_preserves_SemEq (m : RawSemanticTerm) :
    SemEq (N m) m := by
  unfold N embedCanonical normalizeMeaning
  dsimp only
  induction m with
  | scopedAtom sc binder claim presups =>
    unfold normalizeToItems embedNormItemList embedNormItem
    apply SemEq.atom_equiv
    · exact normalizeAtomicClaim_semEq claim
    · intro p
      exact mem_dedupSort_iff presupOrder presups p
  | symConj l r ihl ihr =>
    unfold normalizeToItems
    have hu := semEq_embedUnion (normalizeToItems l) (normalizeToItems r)
                 (normalizeToItems_nonempty l) (normalizeToItems_nonempty r)
    exact .trans hu (.symConj_congr ihl ihr)
  | contrastivePair aSide mSide shExp shOut iha ihm =>
    unfold normalizeToItems embedNormItemList embedNormItem
    exact .contrastive_congr shExp shOut iha ihm

/--
  **Theorem `D01.2b` (`N_preserves_Denotes`)**:
  Normalization preserves model-theoretic truth (`Denotes W (N m) ↔ Denotes W m`) in every
  extensional clinical world `W`!
-/
theorem N_preserves_Denotes (m : RawSemanticTerm) (W : SemanticWorld)
    (hExt : ExtensionalContrastiveWorld W) :
    Denotes W (N m) ↔ Denotes W m :=
  semEq_sound_for_denotes (N_preserves_SemEq m) W hExt

private theorem normalizeToItems_wellFormed (m : RawSemanticTerm) :
    WellFormedNormItemList (normalizeToItems m) := by
  induction m with
  | scopedAtom sc binder claim presups =>
    unfold normalizeToItems WellFormedNormItemList WellFormedNormItem
    exact ⟨⟨normalizeAtomicClaim_idem claim, dedupSort_sorted presupOrder presups⟩, trivial⟩
  | symConj l r ihl ihr =>
    unfold normalizeToItems
    have hmem_wf : ∀ z, z ∈ sortedUnion normItemOrder (normalizeToItems l) (normalizeToItems r) → WellFormedNormItem z := by
      have list_wf_mem : ∀ {xs : List NormItem}, WellFormedNormItemList xs → ∀ z ∈ xs, WellFormedNormItem z := by
        intro xs hwf z hz
        induction xs with
        | nil => simp at hz
        | cons h t ih_m =>
          rcases List.mem_cons.mp hz with rfl | ht
          · exact hwf.1
          · exact ih_m hwf.2 ht
      intro z hz
      rcases (mem_sortedUnion_iff normItemOrder _ _ z).mp hz with hl | hr
      · exact list_wf_mem ihl z hl
      · exact list_wf_mem ihr z hr
    generalize sortedUnion normItemOrder (normalizeToItems l) (normalizeToItems r) = us at hmem_wf
    induction us with
    | nil => trivial
    | cons u rus ih_u =>
      exact ⟨hmem_wf u (List.Mem.head rus), ih_u (fun z hz => hmem_wf z (List.Mem.tail u hz))⟩
  | contrastivePair aSide mSide shExp shOut iha ihm =>
    unfold normalizeToItems WellFormedNormItemList WellFormedNormItem
    exact ⟨⟨normalizeToItems_nonempty aSide, normalizeToItems_sorted aSide, iha,
            normalizeToItems_nonempty mSide, normalizeToItems_sorted mSide, ihm⟩,
           trivial⟩

mutual
  theorem normalize_embedNormItem (item : NormItem) (hwf : WellFormedNormItem item) :
      normalizeToItems (embedNormItem item) = [item] := by
    cases item with
    | normAtom sc claim presups =>
      rcases hwf with ⟨hcl_id, hps_sort⟩
      unfold embedNormItem normalizeToItems
      have hps_id : dedupSort presupOrder presups = presups :=
        sortedStrict_ext presupOrder (dedupSort_sorted presupOrder presups) hps_sort
          (mem_dedupSort_iff presupOrder presups)
      rw [hcl_id, hps_id]
    | normContrastive aItems mItems shExp shOut =>
      rcases hwf with ⟨ha_ne, ha_sort, ha_wf, hm_ne, hm_sort, hm_wf⟩
      unfold embedNormItem normalizeToItems
      rw [normalize_embedNormItemList aItems ha_ne ha_sort ha_wf,
          normalize_embedNormItemList mItems hm_ne hm_sort hm_wf]

  theorem normalize_embedNormItemList (items : List NormItem)
      (hne : items ≠ []) (hsort : SortedStrict normItemOrder items)
      (hwf : WellFormedNormItemList items) :
      normalizeToItems (embedNormItemList items) = items := by
    cases items with
    | nil => exact False.elim (hne rfl)
    | cons x rxs =>
      cases rxs with
      | nil =>
        unfold embedNormItemList
        exact normalize_embedNormItem x hwf.1
      | cons y rtail =>
        unfold embedNormItemList normalizeToItems
        rcases hwf with ⟨hwf_x, hwf_rest⟩
        rcases hsort with ⟨hx_lt, hsort_rest⟩
        have hx_eq := normalize_embedNormItem x hwf_x
        have hrest_eq := normalize_embedNormItemList (y :: rtail) (by simp) hsort_rest hwf_rest
        rw [hx_eq, hrest_eq]
        simp only [sortedUnion, sortedInsert]
        have hxy : normItemOrder.lt x y = true := hx_lt y (List.Mem.head rtail)
        rw [if_pos hxy]
end

/-- **Theorem `D01.3a` (`normalizeMeaning_embed_id`)**: Normalizing an embedded normal form is the identity! -/
theorem normalizeMeaning_embed_id (m : RawSemanticTerm) :
    normalizeMeaning (N m) = normalizeMeaning m := by
  unfold N embedCanonical normalizeMeaning
  dsimp only
  rw [normalize_embedNormItemList (normalizeToItems m)
        (normalizeToItems_nonempty m)
        (normalizeToItems_sorted m)
        (normalizeToItems_wellFormed m)]

/-- **Theorem `D01.3b` (`N_idempotent`)**: Strict Idempotence `N(N(m)) = N(m)`! -/
theorem N_idempotent (m : RawSemanticTerm) :
    N (N m) = N m :=
  congrArg embedCanonical (normalizeMeaning_embed_id m)

/-- **Theorem `D01.4` (`isCanonicalNorm_iff_fixedPoint`)**: `IsCanonicalNorm m ↔ N m = m`! -/
theorem isCanonicalNorm_iff_fixedPoint (m : RawSemanticTerm) :
    IsCanonicalNorm m ↔ N m = m := by
  constructor
  · rintro ⟨items, hne, hsort, hwf, rfl⟩
    unfold N embedCanonical normalizeMeaning
    dsimp only
    rw [normalize_embedNormItemList items hne hsort hwf]
  · intro hfix
    refine ⟨normalizeToItems m, normalizeToItems_nonempty m,
            normalizeToItems_sorted m, normalizeToItems_wellFormed m, ?_⟩
    exact hfix.symm

/--
  **Theorem `D01.5a` (`normalizeMeaning_eq_implies_semEq` — Mandatory `F-P3C-D01` Soundness Direction)**:
  `normalizeMeaning m₁ = normalizeMeaning m₂ ⟹ SemEq m₁ m₂`!
-/
theorem normalizeMeaning_eq_implies_semEq {m₁ m₂ : RawSemanticTerm}
    (heq : normalizeMeaning m₁ = normalizeMeaning m₂) :
    SemEq m₁ m₂ := by
  have h1 : SemEq (N m₁) m₁ := N_preserves_SemEq m₁
  have h2 : SemEq (N m₂) m₂ := N_preserves_SemEq m₂
  have hn_eq : N m₁ = N m₂ := by unfold N; rw [heq]
  rw [hn_eq] at h1
  exact .trans (.symm h1) h2

/--
  **Theorem `D01.5b` (`semEq_implies_normalizeMeaning_eq` — Complete Canonical Uniqueness Direction)**:
  `SemEq m₁ m₂ ⟹ normalizeMeaning m₁ = normalizeMeaning m₂`!
  Every `SemEq` equivalence class has a UNIQUE canonical normal form!
-/
theorem semEq_implies_normalizeMeaning_eq {m₁ m₂ : RawSemanticTerm}
    (h : SemEq m₁ m₂) :
    normalizeMeaning m₁ = normalizeMeaning m₂ := by
  suffices hitems : normalizeToItems m₁ = normalizeToItems m₂ by
    unfold normalizeMeaning; rw [hitems]
  induction h with
  | refl _ => rfl
  | symm _ ih => exact ih.symm
  | trans _ _ ih1 ih2 => exact ih1.trans ih2
  | atom_equiv sc b1 b2 c1 c2 ps1 ps2 hc hps =>
    unfold normalizeToItems
    have hc_eq := atomicSemEq_implies_normalize_eq hc
    have hps_eq : dedupSort presupOrder ps1 = dedupSort presupOrder ps2 := by
      apply sortedStrict_ext presupOrder (dedupSort_sorted presupOrder ps1) (dedupSort_sorted presupOrder ps2)
      intro p
      rw [mem_dedupSort_iff, mem_dedupSort_iff]
      exact hps p
    rw [hc_eq, hps_eq]
  | symConj_congr _ _ ihl ihr =>
    unfold normalizeToItems
    rw [ihl, ihr]
  | symConj_comm a b =>
    unfold normalizeToItems
    apply sortedStrict_ext normItemOrder
      (sortedUnion_sorted normItemOrder _ (normalizeToItems_sorted b))
      (sortedUnion_sorted normItemOrder _ (normalizeToItems_sorted a))
    intro z
    rw [mem_sortedUnion_iff, mem_sortedUnion_iff]
    exact Or.comm
  | symConj_assoc a b c =>
    simp only [normalizeToItems]
    apply sortedStrict_ext normItemOrder
      (sortedUnion_sorted normItemOrder _ (normalizeToItems_sorted c))
      (sortedUnion_sorted normItemOrder _ (sortedUnion_sorted normItemOrder _ (normalizeToItems_sorted c)))
    intro z
    simp only [mem_sortedUnion_iff]
    exact or_assoc
  | symConj_idem a =>
    change sortedUnion normItemOrder (normalizeToItems a) (normalizeToItems a) = normalizeToItems a
    apply sortedStrict_ext normItemOrder
      (sortedUnion_sorted normItemOrder _ (normalizeToItems_sorted a))
      (normalizeToItems_sorted a)
    intro z
    rw [mem_sortedUnion_iff]
    exact or_self_iff
  | contrastive_congr shExp shOut _ _ iha ihm =>
    unfold normalizeToItems
    rw [iha, ihm]

/--
  **Master `F-P3C-D01` Exact Equivalence Theorem (`semEq_iff_normalizeMeaning_eq`)**:
  `m₁ ∼_sem m₂  ⟺  normalizeMeaning m₁ = normalizeMeaning m₂`!
-/
theorem semEq_iff_normalizeMeaning_eq (m₁ m₂ : RawSemanticTerm) :
    SemEq m₁ m₂ ↔ normalizeMeaning m₁ = normalizeMeaning m₂ :=
  ⟨semEq_implies_normalizeMeaning_eq, normalizeMeaning_eq_implies_semEq⟩

end PneumaOmega.P3C
