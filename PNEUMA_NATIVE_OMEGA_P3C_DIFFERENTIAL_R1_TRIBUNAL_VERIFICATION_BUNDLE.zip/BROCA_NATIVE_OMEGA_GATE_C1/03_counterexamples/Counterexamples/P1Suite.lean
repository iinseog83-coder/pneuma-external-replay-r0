/-
  BROCA-NATIVE Ω — Gate C1-P1
  Counterexamples/P1Suite.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies, zero `native_decide`)
  Formalizes & kernel-verifies all P1-D adversarial counterexamples (`CE`) and matched
  same-contract positive controls (`PC`).
  Note: `P1-C` (`Int128` fixed-width overflow) is NOT_AUTHORIZED under `AUTH-C1-P1` and is
  explicitly excluded per authorization charter; decimal scale budget overflow (`d > maxScale`)
  is verified on exact mathematical integers/naturals.
-/
import DetachedChecker

namespace BrocaOmega.P1.Counterexamples

open BrocaOmega.P1
open BrocaOmega.P1.Checker

/-- Default Gate C0-R1 / P1 decimal precision ceiling (`d ≤ 8`). -/
abbrev defaultMaxScale : Nat := 8

/-! ### 1. Compile-Time Kernel-Verified Counterexample & Positive Control Theorems (`P1-D`) -/

/-- `P1D-01 (PC)`: `1 / 3` rounded to 1 decimal place -> `0.3` (`Accept`). -/
theorem p1d_01_pos_one_third_accept :
    checkOutcomeTag 1 3 { negSign := false, absMantissa := 3, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 3, scale10 := 1 } := rfl

/-- `P1D-01 (CE)`: `1 / 3` rounded to 1 decimal place -> `0.4` (`Reject: roundingMismatch 3 4`). -/
theorem p1d_01_neg_one_third_reject :
    checkOutcomeTag 1 3 { negSign := false, absMantissa := 4, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch 3 4) := rfl

/-- `P1D-02 (PC)`: `100 / 3` (`k=1, N=3` percentage) to 1 decimal place -> `33.3` (`Accept`). -/
theorem p1d_02_pos_pct_one_third_accept :
    checkOutcomeTag 100 3 { negSign := false, absMantissa := 333, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 333, scale10 := 1 } := rfl

/-- `P1D-02 (CE)`: `100 / 3` to 1 decimal place -> `33.4` (`Reject: roundingMismatch 333 334`). -/
theorem p1d_02_neg_pct_one_third_reject :
    checkOutcomeTag 100 3 { negSign := false, absMantissa := 334, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch 333 334) := rfl

/-- `P1D-03 (PC)`: `-1.25` (`-5 / 4`) to 1 decimal place -> `-1.3` (`Accept`, ties away from zero). -/
theorem p1d_03_pos_neg_tie_away_accept :
    checkOutcomeTag (-5) 4 { negSign := true, absMantissa := 13, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := -13, scale10 := 1 } := rfl

/-- `P1D-03 (CE)`: `-1.25` (`-5 / 4`) to 1 decimal place -> `-1.2` (`Reject`, wrong half-toward-+∞ rule!). -/
theorem p1d_03_neg_neg_tie_toward_pos_inf_reject :
    checkOutcomeTag (-5) 4 { negSign := true, absMantissa := 12, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch (-13) (-12)) := rfl

/-- `P1D-04 (CE)`: Zero denominator `1 / 0` -> `Reject: zeroDenominator`. -/
theorem p1d_04_neg_zero_denominator_reject :
    checkOutcomeTag 1 0 { negSign := false, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .error .zeroDenominator := rfl

/-- `P1D-04 (PC)`: Zero numerator `0 / 7` normalizes to `0 / 1` and accepts `+0.0`. -/
theorem p1d_04_pos_zero_numerator_canonical_accept :
    checkOutcomeTag 0 7 { negSign := false, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 0, scale10 := 1 } := rfl

/-- `P1D-05 (CE)`: Negative zero `-0.0` (`0 / 1`, `negSign = true, absMantissa = 0`) -> `Reject: negativeZeroForbidden`. -/
theorem p1d_05_neg_minus_zero_reject :
    checkOutcomeTag 0 1 { negSign := true, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .error .negativeZeroForbidden := rfl

/-- `P1D-05 (PC)`: Same contract `0 / 1` with `+0.0` (`negSign = false, absMantissa = 0`) -> `Accept`. -/
theorem p1d_05_pos_plus_zero_accept :
    checkOutcomeTag 0 1 { negSign := false, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 0, scale10 := 1 } := rfl

/-- `P1D-06 (CE)`: Scale bound exceeded (`d = 9 > maxScale = 8`) -> `Reject: scaleBoundExceeded 9 8`. -/
theorem p1d_06_neg_scale_overflow_reject :
    checkOutcomeTag 1 3 { negSign := false, absMantissa := 333333333, scale10 := 9 } 9 defaultMaxScale =
      .error (.scaleBoundExceeded 9 8) := rfl

/-- `P1D-06 (PC)`: Exact boundary `d = 8 ≤ maxScale = 8` (`≤` admissible!) -> `Accept`. -/
theorem p1d_06_pos_scale_at_boundary_accept :
    checkOutcomeTag 1 3 { negSign := false, absMantissa := 33333333, scale10 := 8 } 8 defaultMaxScale =
      .ok { mantissa := 33333333, scale10 := 8 } := rfl

/-- `P1D-07 (CE)`: Format precision mismatch (`1 / 1` expecting `d = 2` `"1.00"`, given `d = 1` `"1.0"`) -> `Reject`. -/
theorem p1d_07_neg_format_precision_mismatch_reject :
    checkOutcomeTag 1 1 { negSign := false, absMantissa := 10, scale10 := 1 } 2 defaultMaxScale =
      .error (.formatScaleMismatch 2 1) := rfl

/-- `P1D-07 (PC)`: Same contract `1 / 1` expecting `d = 2` with `"1.00"` (`mantissa = 100, scale = 2`) -> `Accept`. -/
theorem p1d_07_pos_format_precision_exact_accept :
    checkOutcomeTag 1 1 { negSign := false, absMantissa := 100, scale10 := 2 } 2 defaultMaxScale =
      .ok { mantissa := 100, scale10 := 2 } := rfl

/-- `P1D-08 (Boundary Trio)`: Exact `+1.25` (`5/4`), just below `+1.2495` (`2499/2000`), and `-0.05` (`-1/20`). -/
theorem p1d_08_halfway_neighborhood_precision :
    -- +1.25 -> +1.3 accepted, +1.2 rejected
    checkOutcomeTag 5 4 { negSign := false, absMantissa := 13, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 13, scale10 := 1 } ∧
    checkOutcomeTag 5 4 { negSign := false, absMantissa := 12, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch 13 12) ∧
    -- +2499/2000 = +1.2495 (< 1.25) -> +1.2 accepted, +1.3 rejected
    checkOutcomeTag 2499 2000 { negSign := false, absMantissa := 12, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := 12, scale10 := 1 } ∧
    checkOutcomeTag 2499 2000 { negSign := false, absMantissa := 13, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch 12 13) ∧
    -- -1/20 = -0.05 -> -0.1 accepted, +0.0 rejected
    checkOutcomeTag (-1) 20 { negSign := true, absMantissa := 1, scale10 := 1 } 1 defaultMaxScale =
      .ok { mantissa := -1, scale10 := 1 } ∧
    checkOutcomeTag (-1) 20 { negSign := false, absMantissa := 0, scale10 := 1 } 1 defaultMaxScale =
      .error (.roundingMismatch (-1) 0) :=
  ⟨rfl, rfl, rfl, rfl, rfl, rfl⟩

/-! ### 2. Structured Test Case Table for Executable Audit Reporting -/

structure P1TestCase where
  testId        : String
  role          : String  -- "PC" or "CE"
  rawNum        : Int
  rawDen        : Nat
  rawToken      : RawDecToken
  expectedScale : Nat
  maxScale      : Nat
  expected      : Except P1ArithRejectReason DecLit

def allP1TestCases : List P1TestCase :=
  [ { testId := "P1D-01-PC", role := "PC", rawNum := 1, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 3, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 3, scale10 := 1 } },
    { testId := "P1D-01-CE", role := "CE", rawNum := 1, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 4, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch 3 4) },
    { testId := "P1D-02-PC", role := "PC", rawNum := 100, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 333, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 333, scale10 := 1 } },
    { testId := "P1D-02-CE", role := "CE", rawNum := 100, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 334, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch 333 334) },
    { testId := "P1D-03-PC", role := "PC", rawNum := -5, rawDen := 4,
      rawToken := { negSign := true, absMantissa := 13, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := -13, scale10 := 1 } },
    { testId := "P1D-03-CE", role := "CE", rawNum := -5, rawDen := 4,
      rawToken := { negSign := true, absMantissa := 12, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch (-13) (-12)) },
    { testId := "P1D-04-CE", role := "CE", rawNum := 1, rawDen := 0,
      rawToken := { negSign := false, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error .zeroDenominator },
    { testId := "P1D-04-PC", role := "PC", rawNum := 0, rawDen := 7,
      rawToken := { negSign := false, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 0, scale10 := 1 } },
    { testId := "P1D-05-CE", role := "CE", rawNum := 0, rawDen := 1,
      rawToken := { negSign := true, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error .negativeZeroForbidden },
    { testId := "P1D-05-PC", role := "PC", rawNum := 0, rawDen := 1,
      rawToken := { negSign := false, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 0, scale10 := 1 } },
    { testId := "P1D-06-CE", role := "CE", rawNum := 1, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 333333333, scale10 := 9 },
      expectedScale := 9, maxScale := 8, expected := .error (.scaleBoundExceeded 9 8) },
    { testId := "P1D-06-PC", role := "PC", rawNum := 1, rawDen := 3,
      rawToken := { negSign := false, absMantissa := 33333333, scale10 := 8 },
      expectedScale := 8, maxScale := 8, expected := .ok { mantissa := 33333333, scale10 := 8 } },
    { testId := "P1D-07-CE", role := "CE", rawNum := 1, rawDen := 1,
      rawToken := { negSign := false, absMantissa := 10, scale10 := 1 },
      expectedScale := 2, maxScale := 8, expected := .error (.formatScaleMismatch 2 1) },
    { testId := "P1D-07-PC", role := "PC", rawNum := 1, rawDen := 1,
      rawToken := { negSign := false, absMantissa := 100, scale10 := 2 },
      expectedScale := 2, maxScale := 8, expected := .ok { mantissa := 100, scale10 := 2 } },
    { testId := "P1D-08A-PC", role := "PC", rawNum := 5, rawDen := 4,
      rawToken := { negSign := false, absMantissa := 13, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 13, scale10 := 1 } },
    { testId := "P1D-08A-CE", role := "CE", rawNum := 5, rawDen := 4,
      rawToken := { negSign := false, absMantissa := 12, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch 13 12) },
    { testId := "P1D-08B-PC", role := "PC", rawNum := 2499, rawDen := 2000,
      rawToken := { negSign := false, absMantissa := 12, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := 12, scale10 := 1 } },
    { testId := "P1D-08B-CE", role := "CE", rawNum := 2499, rawDen := 2000,
      rawToken := { negSign := false, absMantissa := 13, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch 12 13) },
    { testId := "P1D-08C-PC", role := "PC", rawNum := -1, rawDen := 20,
      rawToken := { negSign := true, absMantissa := 1, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .ok { mantissa := -1, scale10 := 1 } },
    { testId := "P1D-08C-CE", role := "CE", rawNum := -1, rawDen := 20,
      rawToken := { negSign := false, absMantissa := 0, scale10 := 1 },
      expectedScale := 1, maxScale := 8, expected := .error (.roundingMismatch (-1) 0) }
  ]

def exceptEq (a b : Except P1ArithRejectReason DecLit) : Bool :=
  match a, b with
  | .ok x, .ok y => decide (x = y)
  | .error e1, .error e2 => decide (e1 = e2)
  | _, _ => false

def runSingleCase (tc : P1TestCase) : Bool :=
  let actual := checkOutcomeTag tc.rawNum tc.rawDen tc.rawToken tc.expectedScale tc.maxScale
  exceptEq actual tc.expected

theorem allP1TestCases_pass : (allP1TestCases.all runSingleCase) = true := rfl

end BrocaOmega.P1.Counterexamples
