/-
  BROCA-NATIVE Ω — Gate C1-P1
  DetachedChecker/P1ArithmeticChecker.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies)
  Implements the detached exact rational & rounding verification gate with a private
  `CertifiedRoundingWitness` constructor, plus end-to-end soundness and completeness theorems.
  Note: `P1-C` (Int128/UInt128 fixed-width optimization) is strictly excluded per `AUTH-C1-P1`.
-/
import FormalSpec

namespace BrocaOmega.P1.Checker

/-- Canonical `ExactRat` constructor given a proof `0 < den`. -/
def mkCanonicalRat (num : Int) (den : Nat) (hpos : 0 < den) :
    { r : ExactRat // ExactRat.RatValEq num den r.num r.den } :=
  let g := Nat.gcd num.natAbs den
  have hg_pos : 0 < g := Nat.gcd_pos_of_pos_right num.natAbs hpos
  have hg_le : g ≤ den := Nat.le_of_dvd hpos (Nat.gcd_dvd_right num.natAbs den)
  let r : ExactRat :=
    { num := ExactRat.divByGcdInt num g
      den := den / g
      den_pos := Nat.div_pos hg_le hg_pos
      reduced := by
        rw [ExactRat.divByGcdInt_natAbs]
        exact ExactRat.gcd_div_gcd_eq_one hpos }
  have heq : ExactRat.RatValEq num den r.num r.den := by
    unfold ExactRat.RatValEq
    dsimp [r]
    have hdvd_n : g ∣ num.natAbs := Nat.gcd_dvd_left num.natAbs den
    have hdvd_d : g ∣ den := Nat.gcd_dvd_right num.natAbs den
    have hn : ExactRat.divByGcdInt num g * (g : Int) = num := ExactRat.divByGcdInt_mul_cancel hdvd_n
    have hd_nat : (den / g) * g = den := Nat.div_mul_cancel hdvd_d
    have hd : ((den / g : Nat) : Int) * (g : Int) = (den : Int) := by exact_mod_cast hd_nat
    have hstep1 : num * ((den / g : Nat) : Int) =
        (ExactRat.divByGcdInt num g * (g : Int)) * ((den / g : Nat) : Int) :=
      congrArg (· * ((den / g : Nat) : Int)) hn.symm
    calc
      num * ((den / g : Nat) : Int)
          = (ExactRat.divByGcdInt num g * (g : Int)) * ((den / g : Nat) : Int) := hstep1
      _ = ExactRat.divByGcdInt num g * (((den / g : Nat) : Int) * (g : Int)) := by
            rw [Int.mul_assoc, Int.mul_comm (g : Int)]
      _ = ExactRat.divByGcdInt num g * (den : Int) := by rw [hd]
  ⟨r, heq⟩

/-- Proof-carrying token admission wrapper binding both `mantissa` and `scale10` directly to `raw`. -/
def admitRawTokenChecked (raw : RawDecToken) (maxScale : Nat) :
    Except P1ArithRejectReason
      { surf : DecLit //
        ¬(raw.negSign = true ∧ raw.absMantissa = 0) ∧
        surf.mantissa = raw.toSignedInt ∧
        surf.scale10 = raw.scale10 ∧
        surf.scale10 ≤ maxScale } :=
  if hneg0 : (raw.negSign && raw.absMantissa == 0) = true then
    .error .negativeZeroForbidden
  else if hover : raw.scale10 > maxScale then
    .error (.scaleBoundExceeded raw.scale10 maxScale)
  else
    have hno_neg0 : ¬(raw.negSign = true ∧ raw.absMantissa = 0) := by
      rintro ⟨hns, ha0⟩
      apply hneg0
      simp [hns, ha0]
    have hle : raw.scale10 ≤ maxScale := by omega
    .ok ⟨{ mantissa := raw.toSignedInt, scale10 := raw.scale10 }, ⟨hno_neg0, rfl, rfl, hle⟩⟩

/--
  Kernel-sealed proof-carrying rounding witness.
  `private mk` ensures untrusted callers cannot construct `CertifiedRoundingWitness` directly.
-/
structure CertifiedRoundingWitness
    (rawNum : Int) (rawDen : Nat) (rawSurface : RawDecToken) (expectedScale maxScale : Nat) where
  private mk ::
  canonicalRat   : ExactRat
  surfaceLit     : DecLit
  h_den_pos      : 0 < rawDen
  h_no_neg0      : ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0)
  h_raw_mantissa : surfaceLit.mantissa = rawSurface.toSignedInt
  h_raw_scale    : rawSurface.scale10 = expectedScale
  h_rat_equiv    : ExactRat.RatValEq rawNum rawDen canonicalRat.num canonicalRat.den
  h_scale_eq     : surfaceLit.scale10 = expectedScale
  h_scale_le     : expectedScale ≤ maxScale
  h_round_rat    : ValidRoundAwz canonicalRat.num canonicalRat.den surfaceLit.mantissa expectedScale
  h_round_raw    : ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale

/--
  Detached P1 Verification Gate (`verifyRoundingWitness`):
  Uses `Decidable` reflection on `ValidRoundAwz` over unbounded `Int`/`Nat`.
-/
def verifyRoundingWitness
    (rawNum : Int) (rawDen : Nat) (rawSurface : RawDecToken)
    (expectedScale maxScale : Nat) :
    Except P1ArithRejectReason
      (CertifiedRoundingWitness rawNum rawDen rawSurface expectedScale maxScale) :=
  if hden : 0 < rawDen then
    match admitRawTokenChecked rawSurface maxScale with
    | .error e => .error e
    | .ok sub =>
      let surf := sub.1
      let hno_neg0 := sub.2.1
      let hmant := sub.2.2.1
      let hsurf_raw := sub.2.2.2.1
      let hsurf_le := sub.2.2.2.2
      if hscale : surf.scale10 = expectedScale then
        let ratPair := mkCanonicalRat rawNum rawDen hden
        let rat := ratPair.1
        let hrat_eq := ratPair.2
        if hround : ValidRoundAwz rat.num rat.den surf.mantissa expectedScale then
          have hraw_surf : ValidRoundAwz rawNum rawDen surf.mantissa expectedScale :=
            (validRoundAwz_iff_of_ratValEq hden rat.den_pos hrat_eq surf.mantissa expectedScale).mpr hround
          have hraw_tok : ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale :=
            hmant ▸ hraw_surf
          .ok
            { canonicalRat := rat
              surfaceLit := surf
              h_den_pos := hden
              h_no_neg0 := hno_neg0
              h_raw_mantissa := hmant
              h_raw_scale := hsurf_raw.symm.trans hscale
              h_rat_equiv := hrat_eq
              h_scale_eq := hscale
              h_scale_le := hscale ▸ hsurf_le
              h_round_rat := hround
              h_round_raw := hraw_tok }
        else
          let expectedM := roundHalfAwayFromZero rat.num rat.den expectedScale
          .error (.roundingMismatch expectedM surf.mantissa)
      else
        .error (.formatScaleMismatch expectedScale surf.scale10)
  else
    .error .zeroDenominator

/--
  Detached P1 Kernel Soundness Theorem:
  Every `CertifiedRoundingWitness` admitted by `verifyRoundingWitness` guarantees directly on `rawSurface`:
  1. Positive denominator (`0 < rawDen`)
  2. Absence of `-0.0` (`¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0)`)
  3. Exact precision match & bound (`rawSurface.scale10 = expectedScale ≤ maxScale`)
  4. `ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale`
  5. Exact `RoundHalfAwayFromZero` functional equality (`rawSurface.toSignedInt = roundHalfAwayFromZero ...`)
  6. Universal closest-integer metric optimality (`IsNearestIntHalfAway`)!
-/
theorem verifyRoundingWitness_sound
    {rawNum : Int} {rawDen : Nat} {rawSurface : RawDecToken}
    {expectedScale maxScale : Nat}
    {cert : CertifiedRoundingWitness rawNum rawDen rawSurface expectedScale maxScale}
    (_hok : verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale = .ok cert) :
    0 < rawDen ∧
    ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0) ∧
    rawSurface.scale10 = expectedScale ∧
    expectedScale ≤ maxScale ∧
    ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale ∧
    rawSurface.toSignedInt = roundHalfAwayFromZero rawNum rawDen expectedScale ∧
    IsNearestIntHalfAway rawNum rawDen expectedScale rawSurface.toSignedInt := by
  have hfn : rawSurface.toSignedInt = roundHalfAwayFromZero rawNum rawDen expectedScale :=
    (validRoundAwz_iff_eq_roundHalfAway cert.h_den_pos rawSurface.toSignedInt expectedScale).mp
      cert.h_round_raw
  have hnear : IsNearestIntHalfAway rawNum rawDen expectedScale rawSurface.toSignedInt :=
    (validRoundAwz_iff_isNearestIntHalfAway cert.h_den_pos rawSurface.toSignedInt expectedScale).mp
      cert.h_round_raw
  exact ⟨cert.h_den_pos, cert.h_no_neg0, cert.h_raw_scale, cert.h_scale_le,
         cert.h_round_raw, hfn, hnear⟩

/--
  Detached P1 Kernel Relative Completeness Theorem:
  Any well-formed `rawSurface` within scale bounds whose signed mantissa satisfies `ValidRoundAwz`
  is deterministically accepted (`∃ cert, verifyRoundingWitness ... = .ok cert`).
-/
theorem verifyRoundingWitness_complete
    {rawNum : Int} {rawDen : Nat} {rawSurface : RawDecToken}
    {expectedScale maxScale : Nat}
    (hden : 0 < rawDen)
    (hno_neg0 : ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0))
    (hsc : rawSurface.scale10 = expectedScale)
    (hle : expectedScale ≤ maxScale)
    (hraw : ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale) :
    ∃ cert, verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale = .ok cert := by
  unfold verifyRoundingWitness admitRawTokenChecked
  rw [dif_pos hden]
  have hneg0_false : ¬((rawSurface.negSign && rawSurface.absMantissa == 0) = true) := by
    intro h
    apply hno_neg0
    cases hns : rawSurface.negSign <;> simp [hns] at h ⊢
    exact h
  have hover_false : ¬(rawSurface.scale10 > maxScale) := by omega
  rw [dif_neg hneg0_false, dif_neg hover_false]
  dsimp
  rw [dif_pos hsc]
  let ratPair := mkCanonicalRat rawNum rawDen hden
  have hrat_round : ValidRoundAwz ratPair.1.num ratPair.1.den rawSurface.toSignedInt expectedScale :=
    (validRoundAwz_iff_of_ratValEq hden ratPair.1.den_pos ratPair.2 _ expectedScale).mp hraw
  rw [dif_pos hrat_round]
  exact ⟨_, rfl⟩

/-- Pure error-projection helper for adversarial counterexample verification (`isError` / exact error tag). -/
def checkOutcomeTag
    (rawNum : Int) (rawDen : Nat) (rawSurface : RawDecToken)
    (expectedScale maxScale : Nat) : Except P1ArithRejectReason DecLit :=
  match verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale with
  | .ok cert => .ok cert.surfaceLit
  | .error e => .error e

end BrocaOmega.P1.Checker
