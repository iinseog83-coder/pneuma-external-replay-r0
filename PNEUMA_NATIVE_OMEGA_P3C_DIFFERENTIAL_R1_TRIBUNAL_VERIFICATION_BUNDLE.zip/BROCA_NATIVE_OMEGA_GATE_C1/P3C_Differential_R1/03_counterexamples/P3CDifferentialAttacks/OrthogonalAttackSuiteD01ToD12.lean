/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate B`, `Gate D`, `Gate OPT-B`, `Gate OPT-C`)
  03_counterexamples/P3CDifferentialAttacks/OrthogonalAttackSuiteD01ToD12.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`,
                         zero `sorry`, zero `native_decide`, zero custom axioms)

  Implements the 28 symmetric `(PC, CE)` vectors (`14` pairs `D01` ~ `D14`) under:
    - `Gate OPT-A` (`verdictHead_compare_encode` / `verdictHead_compare_canon` + separate
                    `F-DIFF-OPT-02` full unprojected witness fidelity),
    - `Gate OPT-B` (`GateDVerdictTag` finite decision algebra preserving exact 28 verdict semantics
                    `F-DIFF-OPT-03`, while keeping `D13` as raw literal `String` decoder `by decide` tests),
    - `Gate OPT-C` (Shared parsing witnesses strictly bound to identical 5-tuple `ProvenanceContext` values
                    `(catalog, numCfg, scopeEnv, budget, rawBytes)` — zero cross-context reuse).
-/
import P3CDifferentialChecker

namespace PneumaOmega.P3C.DifferentialR1.Attacks

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks
open PneumaOmega.P3C.DifferentialR1

/-! ### 1. Finite Decision Algebra (`Gate OPT-B` / `F-DIFF-OPT-03`) -/

inductive GateDVerdictTag where
  | v_d01_pc | v_d01_ce
  | v_d02_pc | v_d02_ce
  | v_d03_pc | v_d03_ce
  | v_d04_pc | v_d04_ce
  | v_d05_pc | v_d05_ce
  | v_d06_pc | v_d06_ce
  | v_d07_pc | v_d07_ce
  | v_d08_pc | v_d08_ce
  | v_d09_pc | v_d09_ce
  | v_d10_pc | v_d10_ce
  | v_d11_pc | v_d11_ce
  | v_d12_pc | v_d12_ce
  | v_d13_pc | v_d13_ce
  | v_d14_pc | v_d14_ce
  | v_unexpectedFailure
  deriving DecidableEq, Repr

/-- Exact 1-to-1 string rendering preserving every `D01`~`D14` verdict label (`F-DIFF-OPT-03`). -/
def renderGateDTag : GateDVerdictTag → String
  | .v_d01_pc => "RAW_DISTINCT_AND_CANON_MATCH(SPEC_GROUNDED)"
  | .v_d01_ce => "MISMATCH_WITNESS:G16_CHILD_SWAP_DETECTED"
  | .v_d02_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):T2_DUAL_READINGS_BOUND"
  | .v_d02_ce => "EXTRACTION_FAILURE_VERIFIED(T1_alt3 & G11_alt2)"
  | .v_d03_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):ROOT_AND_CHILD_SPANS_EXACT"
  | .v_d03_ce => "MISMATCH_WITNESS(spanIntegrityStage):SPAN_SHIFT_CAUGHT"
  | .v_d04_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):ASCII_BYTE_EQ_CODEPOINT_61"
  | .v_d04_ce => "OOD_BLOCKED_BEFORE_SPAN(2B_0xC3 & 3B_0xE2)"
  | .v_d05_pc => "QUANTIFIER_FORMS_SEPARATED(G11!=G12)"
  | .v_d05_ce => "MISMATCH_WITNESS(Scope & Polarity) & T5_TRAP_REJECTED"
  | .v_d06_pc => "G09_CONSENSUS_VS_T3_WH_FACTIVE_REJECTED"
  | .v_d06_ce => "MISMATCH_WITNESS:PRESUPPOSITION_DROP_OR_ADD_CAUGHT"
  | .v_d07_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):CAUSAL_DIRECTIONAL_CANONICAL"
  | .v_d07_ce => "MISMATCH_WITNESS:CAUSAL_NE_ASSOC_AND_NE_NEUTRAL"
  | .v_d08_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):G04_TEMPORAL_ROUNDTRIP"
  | .v_d08_ce => "MISMATCH_WITNESS:TEMPORAL_REVERSAL_CAUGHT"
  | .v_d09_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):G16_CONTRASTIVE_FOREST_OK"
  | .v_d09_ce => "BOUNDARY_SEPARATED(P3B_EmptyParse & P3C_InvalidAnchor & SymConj!=Contrastive)"
  | .v_d10_pc => "MATCH_STRUCTURAL(SPEC_GROUNDED):OPTIONAL_FIELDS_ROUNDTRIP_INTACT"
  | .v_d10_ce => "MISMATCH_WITNESS:DROPPED_OPTIONAL_FIELDS_CAUGHT(cov & pVal)"
  | .v_d11_pc => "ALL_5_EXTRACTION_DIAG_FAMILIES_ROUNDTRIPPED"
  | .v_d11_ce => "FAILURE_DISGUISE_AND_RAW_SUBMIT_REJECTED"
  | .v_d12_pc => "PROVENANCE_R1_ADMITS_AUTHENTIC_DECODED_WIRE"
  | .v_d12_ce => "PROVENANCE_R1_REJECTS_CROSS_CONTEXT_AND_SPOOFED_WIRE"
  | .v_d13_pc => "VALID_CANONICAL_WIRE_DECODED"
  | .v_d13_ce => "ALL_6_MALFORMED_WIRE_CLASSES_REJECTED"
  | .v_d14_pc => "MATCH_STRUCTURAL(MODEL_ASSUMPTION):SEPARATED_FROM_SPEC_GROUNDED"
  | .v_d14_ce => "SPECIFICATION_HELD_AND_RESOURCE_OVERFLOW_SEPARATED"
  | .v_unexpectedFailure => "UNEXPECTED_FAILURE"

/-! ### 2. `Gate OPT-C` — Exact 5-Tuple Shared Parsing Witnesses (`(catalog, numCfg, scopeEnv, budget, rawBytes)`) -/

/-- Definitional 5-field identity between `runP3COnContext (mkStdCtx ...)` and `runP3COnStr` (`Gate OPT-C`). -/
theorem runP3COnContext_mkStdCtx_eq (env : ScopeEnv) (budget : ResourceBudget) (s : String) :
    runP3COnContext (mkStdCtx env budget s) = runP3COnStr env budget s := rfl

theorem shared_ctxT2_ambiguous_ok : isAmbiguousDual (runP3COnContext ctxT2) = true := by
  unfold ctxT2; rw [runP3COnContext_mkStdCtx_eq]; exact ce03_ok

theorem shared_ctxG09_consensus_ok :
    isConsensusSingleEq (runP3COnContext ctxG09) expectedCanonG09 = true := by
  unfold ctxG09; rw [runP3COnContext_mkStdCtx_eq]; exact pc03_ok

theorem shared_ctxT3_trap_ok :
    isTrapRejectedSingle (runP3COnContext ctxT3) .whFactivePresuppositionForbidden = true := by
  unfold ctxT3; rw [runP3COnContext_mkStdCtx_eq]; exact ce04_ok

theorem shared_ctxT5_trap_ok :
    isTrapRejectedSingle (runP3COnContext ctxT5) .unscopedClauseForbidden = true := by
  unfold ctxT5; rw [runP3COnContext_mkStdCtx_eq]; exact ce06_ok

theorem shared_ctxT2Overflow_ok :
    runP3COnContext ctxT2Overflow =
      .upstreamRejected (.resourceOverflow (.maxReadingsExceeded 2 1)) := by
  unfold ctxT2Overflow; rw [runP3COnContext_mkStdCtx_eq]; exact eq_of_beq ce15_ok

private theorem parseStatus_overflow_of_runP3C (ctx : ProvenanceContext) (r : OverflowReason)
    (h : runP3COnContext ctx = .upstreamRejected (.resourceOverflow r)) :
    eqStrBool (observeSurfaceE2E ctx).parseStatus "RESOURCE_OVERFLOW" = true := by
  rw [observeSurfaceE2E_isResourceOverflow]
  unfold runP3COnContext certifySemanticConsensus at h
  cases hp : parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | resourceOverflow _ => rfl
  | outOfDomain _ => rw [hp] at h; nomatch h
  | enumerated T =>
    rw [hp] at h; dsimp only at h
    unfold evalForestPure at h
    cases T with
    | nil => nomatch h
    | cons t0 ts =>
      dsimp only at h
      cases hex : extractAllMeanings ctx.scopeEnv (t0 :: ts) with
      | error _ => rw [hex] at h; nomatch h
      | ok pairs =>
        rw [hex] at h
        cases pairs with
        | nil => nomatch h
        | cons p1 rest =>
          dsimp only at h
          cases hdiv : findDivergentReading p1.1 p1.2 (normalizeMeaning p1.2) rest with
          | some _ => rw [hdiv] at h; nomatch h
          | none =>
            rw [hdiv] at h
            cases htrap : findForestTrapViolation (t0 :: ts) with
            | some _ => rw [htrap] at h; nomatch h
            | none => rw [htrap] at h; nomatch h

theorem shared_ctxT2Overflow_parse_overflow :
    eqStrBool (observeSurfaceE2E ctxT2Overflow).parseStatus "RESOURCE_OVERFLOW" = true :=
  parseStatus_overflow_of_runP3C ctxT2Overflow (.maxReadingsExceeded 2 1) shared_ctxT2Overflow_ok

def expectedCanonG12 : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.quantClaim (.properPart "sub_dm_pl" "ev_stroke")) [])

-- Shared exact-context witness for `ctxG12` (`Gate OPT-C`: verified once, bound to exact `ctxG12` 5-tuple).
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in
theorem shared_ctxG12_consensus_ok :
    isConsensusSingleEq (runP3COnContext ctxG12) expectedCanonG12 = true := by decide

def envMismatchedCohort : ScopeEnv :=
  { cohortId := "coh_other_registry", expectedDesignHead := "des_study", quoteIsolation := .sentenceAtomic }

def ctxG11BadCohort : ProvenanceContext :=
  mkStdCtx envMismatchedCohort defaultParseBudget sG11

def isUpstreamEmptyParse : SemanticNormOutcome → Bool
  | .upstreamRejected .emptyParseSet => true
  | _                                => false

-- Shared exact-context witness for `ctxG11BadCohort` (`P3-B checkSide` `.emptyParseSet` boundary).
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in
theorem shared_ctxG11BadCohort_empty_ok :
    isUpstreamEmptyParse (runP3COnContext ctxG11BadCohort) = true := by decide

/-! ### 3. Parameterized Single-Scrutinee Wire Predicates (Eliminating Nested `match` Motives) -/

def checkForestExtDiagWire (env : ScopeEnv) (T : List ConcreteParseTree)
    (expected : ExtractionFailureDiag) : Bool :=
  match decodeForestOutcomeWire env T with
  | .ok (.semanticExtractionFailure _ e) => eqExtractionDiagBool e.diag expected
  | _ => false

theorem checkForestExtDiagWire_eq (env : ScopeEnv) (T : List ConcreteParseTree)
    (expected : ExtractionFailureDiag) :
    checkForestExtDiagWire env T expected =
      match evalForestPure env T with
      | .semanticExtractionFailure _ e => eqExtractionDiagBool e.diag expected
      | _ => false := by
  unfold checkForestExtDiagWire
  rw [decodeForestOutcomeWire_eq]
  cases evalForestPure env T <;> rfl

def checkForestSingleConsensusWire (env : ScopeEnv) (T : List ConcreteParseTree) : Bool :=
  match decodeForestOutcomeWire env T with
  | .ok out => isConsensusSingle out
  | .error _ => false

theorem checkForestSingleConsensusWire_eq (env : ScopeEnv) (T : List ConcreteParseTree) :
    checkForestSingleConsensusWire env T = isConsensusSingle (evalForestPure env T) := by
  unfold checkForestSingleConsensusWire
  rw [decodeForestOutcomeWire_eq]

def checkSurfaceSingleConsensusWire (ctx : ProvenanceContext) (expected : CanonicalMeaning) : Bool :=
  match decodeSurfaceOutcomeWire ctx with
  | .ok out => isConsensusSingleEq out expected
  | .error _ => false

theorem checkSurfaceSingleConsensusWire_eq (ctx : ProvenanceContext) (expected : CanonicalMeaning) :
    checkSurfaceSingleConsensusWire ctx expected =
      isConsensusSingleEq (runP3COnContext ctx) expected := by
  unfold checkSurfaceSingleConsensusWire
  rw [decodeSurfaceOutcomeWire_eq]

def checkSurfaceTrapWire (ctx : ProvenanceContext) (expectedDiag : TrapPolicyDiag) : Bool :=
  match decodeSurfaceOutcomeWire ctx with
  | .ok out => isTrapRejectedSingle out expectedDiag
  | .error _ => false

theorem checkSurfaceTrapWire_eq (ctx : ProvenanceContext) (expectedDiag : TrapPolicyDiag) :
    checkSurfaceTrapWire ctx expectedDiag =
      isTrapRejectedSingle (runP3COnContext ctx) expectedDiag := by
  unfold checkSurfaceTrapWire
  rw [decodeSurfaceOutcomeWire_eq]

def checkSurfaceEmptyParseWire (ctx : ProvenanceContext) : Bool :=
  match decodeSurfaceOutcomeWire ctx with
  | .ok out => isUpstreamEmptyParse out
  | .error _ => false

theorem checkSurfaceEmptyParseWire_eq (ctx : ProvenanceContext) :
    checkSurfaceEmptyParseWire ctx = isUpstreamEmptyParse (runP3COnContext ctx) := by
  unfold checkSurfaceEmptyParseWire
  rw [decodeSurfaceOutcomeWire_eq]

def checkSurfaceOodByteWire (ctx : ProvenanceContext) (expectedByte : UInt8) : Bool :=
  (match decodeSurfaceOutcomeWire ctx with
   | .ok (.upstreamRejected (.outOfDomain (.nonPrintableAsciiByte b))) => b == expectedByte
   | _ => false) &&
  ((observeSurfaceE2E ctx).codepointLenOpt == none)

theorem checkSurfaceOodByteWire_eq (ctx : ProvenanceContext) (expectedByte : UInt8) :
    checkSurfaceOodByteWire ctx expectedByte =
      ((match runP3COnContext ctx with
        | .upstreamRejected (.outOfDomain (.nonPrintableAsciiByte b)) => b == expectedByte
        | _ => false) &&
       ((match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
         | .enumerated _ => some (decodeAsciiBytes ctx.rawBytes).toList.length
         | _ => none) == none)) := by
  unfold checkSurfaceOodByteWire
  rw [decodeSurfaceOutcomeWire_eq, observeSurfaceE2E_codepointLenOpt]
  cases runP3COnContext ctx with
  | upstreamRejected d =>
    cases d with
    | outOfDomain od => cases od <;> rfl
    | _ => rfl
  | _ => rfl

def checkSurfaceOverflowWire (ctx : ProvenanceContext) (expected : OverflowReason) : Bool :=
  (match decodeSurfaceOutcomeWire ctx with
   | .ok (.upstreamRejected (.resourceOverflow r)) => r == expected
   | _ => false) &&
  eqStrBool (observeSurfaceE2E ctx).parseStatus "RESOURCE_OVERFLOW"

theorem checkSurfaceOverflowWire_eq (ctx : ProvenanceContext) (expected : OverflowReason) :
    checkSurfaceOverflowWire ctx expected =
      ((match runP3COnContext ctx with
        | .upstreamRejected (.resourceOverflow r) => r == expected
        | _ => false) &&
       eqStrBool (observeSurfaceE2E ctx).parseStatus "RESOURCE_OVERFLOW") := by
  unfold checkSurfaceOverflowWire
  rw [decodeSurfaceOutcomeWire_eq]
  cases runP3COnContext ctx with
  | upstreamRejected d => cases d <;> rfl
  | _ => rfl

def checkCanonRoundtripWire (c : CanonicalMeaning) : Bool :=
  match decodeWire canonicalMeaningWireCodec (encodeWire canonicalMeaningWireCodec c) with
  | .ok c' => canonicalMeaningEqBool c' c
  | .error _ => false

theorem checkCanonRoundtripWire_eq (c : CanonicalMeaning) :
    checkCanonRoundtripWire c = canonicalMeaningEqBool c c := by
  unfold checkCanonRoundtripWire
  rw [encodeWire_decodeWire_roundtrip]

def checkSemanticInjectRoundtripOk (m : RawSemanticTerm) : Bool :=
  (decodeSemanticInjectCanonWire m).isOk

theorem checkSemanticInjectRoundtripOk_eq (m : RawSemanticTerm) :
    checkSemanticInjectRoundtripOk m = true := by
  unfold checkSemanticInjectRoundtripOk
  rw [decodeSemanticInjectCanonWire_eq]
  rfl

def checkForestReplayRejectWire (targetCtx claimedCtx : ProvenanceContext)
    (env : ScopeEnv) (T : List ConcreteParseTree) (expected : ProvenanceRejectReason) : Bool :=
  match verifyForestWireReplayProj targetCtx claimedCtx env T with
  | .error (.inr r) => r == expected
  | _ => false

theorem checkForestReplayRejectWire_eq (targetCtx claimedCtx : ProvenanceContext)
    (env : ScopeEnv) (T : List ConcreteParseTree) (expected : ProvenanceRejectReason) :
    checkForestReplayRejectWire targetCtx claimedCtx env T expected =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := evalForestPure env T } with
      | .error r => r == expected
      | .ok _    => false := by
  unfold checkForestReplayRejectWire
  rw [verifyForestWireReplayProj_eq]
  cases verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := evalForestPure env T } <;> rfl

def checkSurfaceReplayRejectWire (targetCtx claimedCtx srcCtx : ProvenanceContext)
    (expected : ProvenanceRejectReason) : Bool :=
  match verifySurfaceWireReplayProj targetCtx claimedCtx srcCtx with
  | .error (.inr r) => r == expected
  | _ => false

theorem checkSurfaceReplayRejectWire_eq (targetCtx claimedCtx srcCtx : ProvenanceContext)
    (expected : ProvenanceRejectReason) :
    checkSurfaceReplayRejectWire targetCtx claimedCtx srcCtx expected =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := runP3COnContext srcCtx } with
      | .error r => r == expected
      | .ok _    => false := by
  unfold checkSurfaceReplayRejectWire
  rw [verifySurfaceWireReplayProj_eq]
  cases verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := runP3COnContext srcCtx } <;> rfl

/-! ### 4. Synthetic Trees, Contexts & Semantic Terms for `FOREST_INJECT` and `SEMANTIC_INJECT` -/

private def spDummy : CodepointSpan := ⟨0, 1⟩

def synthValidG16Tree : ConcreteParseTree :=
  let assocCore := ConcreteParseTree.mkTree .Gen_G03_AssocUnadj 1 .clause1 spDummy
    [ .slotTok .expLevel .activeExp "exp_intens" "intensive therapy" spDummy,
      .slotTok .expLevel .refExp "exp_std" "standard care" spDummy,
      .slotTok .assocDir .direction "inversely" "inversely" spDummy,
      .slotTok .outTerm .outcome "out_mi" "myocardial infarction" spDummy,
      .slotTok .ratioMetric .metric1 "hr" "hazard ratio" spDummy,
      .slotTok .numericLit .numEst "0.75" "0.75" spDummy,
      .slotTok .numericLit .numCILevel "95" "95" spDummy,
      .slotTok .numericLit .numCILow "0.61" "0.61" spDummy,
      .slotTok .numericLit .numCIHigh "0.92" "0.92" spDummy ]
  let embOk := ConcreteParseTree.mkTree .Env_EmbeddedCausal 1 .clause2 spDummy
    [ .slotTok .expLevel .activeExp "exp_intens" "intensive therapy" spDummy,
      .slotTok .intervVerbPres .verb "reduces" "reduces" spDummy,
      .slotTok .outTerm .outcome "out_mi" "myocardial infarction" spDummy ]
  let metaCore := ConcreteParseTree.mkTree .Gen_G09_MetaNonEstab 1 .clause2 spDummy
    [ .slotTok .sourceId .source "src_trialA" "Trial-A" spDummy, .childSub embOk ]
  let sc1 := ConcreteParseTree.mkTree .Env_ScopedAssoc 1 .clause1 spDummy
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" spDummy, .childSub assocCore ]
  let sc2 := ConcreteParseTree.mkTree .Env_ScopedContrastMeta 1 .clause2 spDummy
    [ .slotTok .designNoun .design "des_study" "study" spDummy, .childSub metaCore ]
  ConcreteParseTree.mkTree .Gen_G16_DocContrastive 1 .clause1 spDummy [ .childSub sc1, .childSub sc2 ]

def synthSwappedChildrenG16Tree : ConcreteParseTree :=
  match synthValidG16Tree with
  | .mkTree p alt loc sp [c1, c2] => .mkTree p alt loc sp [c2, c1]
  | other => other

def synthG11IllegalAlt2Tree : ConcreteParseTree :=
  let coreBad := ConcreteParseTree.mkTree .Gen_G11_QuantZero 2 .clause1 spDummy
    [ .slotTok .subgroupPlural .subgroup "sub_dm_pl" "diabetic" spDummy,
      .slotTok .eventTerm .eventA "ev_stroke" "stroke" spDummy ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedInitial 1 .clause1 spDummy
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" spDummy, .childSub coreBad ]
  ConcreteParseTree.mkTree .Env_DocSingle 1 .clause1 spDummy [ .childSub sc ]

def perturbRootSpan (t : ConcreteParseTree) : ConcreteParseTree :=
  match t with
  | .mkTree p alt loc sp args => .mkTree p alt loc ⟨sp.startCp, sp.endCp + 1⟩ args

def synthMissingChildrenG15aTree : ConcreteParseTree :=
  ConcreteParseTree.mkTree .Gen_G15a_DocConjAtomic 1 .clause1 spDummy []

def ctxUtf8_2B : ProvenanceContext := { ctxG11 with rawBytes := [0x49, 0x6E, 0x20, 0xC3, 0xA9] }
def ctxUtf8_3B : ProvenanceContext := { ctxG11 with rawBytes := [0x49, 0x6E, 0x20, 0xE2, 0x89, 0xA4] }

def termD04Scoped : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
def termD05Unscoped : RawSemanticTerm :=
  .scopedAtom .unrestrictedPop "u_unscoped" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
def termD05NegUniv : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.negUniversal "sub_dm_pl" "ev_stroke")) []
def termD06Clean : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") []
def termD06WithPresup : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi")
    [.factiveCausal "exp_intens" "reduces" "out_mi"]
def termD07CausalDir : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.intervClaim (.directional "reduce") "assump_exch" "hr" "exp_intens" "exp_std" "out_mi" "0.75" "95" "0.61" "0.92" (some "0.006")) []
def termD09AssocSide : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") []
def termD09MetaSide : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "y_repeat"
    (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") []
def termD09Contrast : RawSemanticTerm :=
  .contrastivePair termD09AssocSide termD09MetaSide "exp_intens" "out_mi"
def termD09SymConj : RawSemanticTerm :=
  .symConj termD09AssocSide termD09MetaSide
def termD10WithCov : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" (some "cov_age_risk") none "0.75" "95" "0.61" "0.92") []
def termD10DropCov : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") []
def termD10Med : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.descDist .medianIQR "meas_sbp" "128" "118" (some "139")) []
def termD10DropP : RawSemanticTerm :=
  .scopedAtom (.cohortBound "coh_primary") "x_init"
    (.intervClaim (.directional "reduce") "assump_exch" "hr" "exp_intens" "exp_std" "out_mi" "0.75" "95" "0.61" "0.92" none) []

/-! ### 5. Deterministic Evaluation Verdicts Across `D01` ~ `D14` (`28` Vectors) -/

-- D01: Parse Child Order Swap (`G-15a`/`G-15b` raw != vs canonical ==; `G-16` contrastive child swap !=)
def d01_pc_tag : GateDVerdictTag :=
  match extractRawMeaning envDiscourse synthTreeG15a_AB,
        extractRawMeaning envDiscourse synthTreeG15b_BA with
  | .ok m1, .ok m2 =>
    if (verdictHead (compareWirePayloads rawMeaningWireCodec .MODEL_ASSUMPTION "S0-R2.2:G15" .rawExtractionStage
          (encodeWire rawMeaningWireCodec m1) (encodeWire rawMeaningWireCodec m2)) == .mismatchWitness .rawExtractionStage) &&
       (compareCanonicalValuesWire .SPEC_GROUNDED "S0-R2.2:G15" .canonicalNormStage
          (normalizeMeaning m1) (normalizeMeaning m2) == .matchStructural .SPEC_GROUNDED) then
      .v_d01_pc
    else .v_unexpectedFailure
  | _, _ => .v_unexpectedFailure

def d01_ce_tag : GateDVerdictTag :=
  match extractRawMeaning envDiscourse synthValidG16Tree,
        extractRawMeaning envDiscourse synthSwappedChildrenG16Tree with
  | .ok mValid, .ok mSwapped =>
    if compareCanonicalValuesWire .SPEC_GROUNDED "S0-R2:G16" .canonicalNormStage
         (normalizeMeaning mValid) (normalizeMeaning mSwapped) == .mismatchWitness .canonicalNormStage then
      .v_d01_ce
    else .v_unexpectedFailure
  | _, _ => .v_unexpectedFailure

-- D02: `readingAlt` Perturbation (`T2` dual readings preserved vs `alt=3` & `G-11 alt=2` rejected)
def d02_pc_tag : GateDVerdictTag :=
  if checkSurfaceDualAmbiguousWire ctxT2 then .v_d02_pc else .v_unexpectedFailure

def d02_ce_tag : GateDVerdictTag :=
  if checkForestExtDiagWire envAtomic [synthInvalidAlt3Tree] (.unsupportedReadingAlt .Trap_T1_AllNot 3) &&
     checkForestExtDiagWire envAtomic [synthG11IllegalAlt2Tree] (.unsupportedReadingAlt .Gen_G11_QuantZero 2) then
    .v_d02_ce
  else .v_unexpectedFailure

-- D03: `CodepointSpan` Offset Perturbation (`SURFACE_E2E` valid spans vs `+1` span shift `MISMATCH_WITNESS`)
def d03_pc_tag : GateDVerdictTag :=
  if checkSurfaceRootSpanWire ctxG01 then .v_d03_pc else .v_unexpectedFailure

def d03_ce_tag : GateDVerdictTag :=
  if verdictHead (compareWirePayloads parseTreeWireCodec .SPEC_GROUNDED "S0-R2.1:Span" .spanIntegrityStage
       (encodeWire parseTreeWireCodec synthTreeG15a_AB)
       (encodeWire parseTreeWireCodec (perturbRootSpan synthTreeG15a_AB))) ==
       .mismatchWitness .spanIntegrityStage then
    .v_d03_ce
  else .v_unexpectedFailure

-- D04: Byte Length vs Codepoint Length (`ASCII` `byteLen == cpLen == 61` vs UTF-8 `"é"` 2B/1CP & `"≤"` 3B/1CP `OutOfDomain`)
def d04_pc_tag : GateDVerdictTag :=
  if (ctxG11.rawBytes.length == 61) &&
     ((ctxG11.rawBytes.map (fun b => Char.ofNat b.toNat)).length == 61) &&
     (utf8ByteLenOfChars (ctxG11.rawBytes.map (fun b => Char.ofNat b.toNat)) == 61) &&
     checkSemanticInjectRoundtripOk termD04Scoped then
    .v_d04_pc
  else .v_unexpectedFailure

def d04_ce_tag : GateDVerdictTag :=
  if checkSurfaceOodByteWire ctxUtf8_2B 0xC3 &&
     checkSurfaceOodByteWire ctxUtf8_3B 0xE2 &&
     (utf8ByteLenOfChar (Char.ofNat 0xE9) == 2) &&
     (utf8ByteLenOfChar (Char.ofNat 0x2264) == 3) then
    .v_d04_ce
  else .v_unexpectedFailure

-- D05: Scope, Polarity & Quantifier Perturbation (`G-11 != G-12` vs `T5` unscoped & `QuantPredForm` swaps)
def d05_pc_tag : GateDVerdictTag :=
  if compareSingleSurfaceCanonsWire ctxG11 ctxG12 .SPEC_GROUNDED "S0-R2:G11_G12" .canonicalNormStage ==
       some (.mismatchWitness .canonicalNormStage) then
    .v_d05_pc
  else .v_unexpectedFailure

def d05_ce_tag : GateDVerdictTag :=
  if (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:Scope" .canonicalNormStage termD04Scoped termD05Unscoped ==
        .mismatchWitness .canonicalNormStage) &&
     (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:Polarity" .canonicalNormStage termD04Scoped termD05NegUniv ==
        .mismatchWitness .canonicalNormStage) &&
     checkSurfaceTrapWire ctxT5 .unscopedClauseForbidden then
    .v_d05_ce
  else .v_unexpectedFailure

-- D06: Factive Presupposition Drop / Injection (`G-09` vs `T3` trap & injected presupposition on `G-09`)
def d06_pc_tag : GateDVerdictTag :=
  if checkSurfaceSingleConsensusWire ctxG09 expectedCanonG09 &&
     checkSurfaceTrapWire ctxT3 .whFactivePresuppositionForbidden then
    .v_d06_pc
  else .v_unexpectedFailure

def d06_ce_tag : GateDVerdictTag :=
  if compareSemanticInjectCanonsWire .SPEC_GROUNDED "P0-A05:T2_Presup" .canonicalNormStage
       termD06Clean termD06WithPresup == .mismatchWitness .canonicalNormStage then
    .v_d06_ce
  else .v_unexpectedFailure

-- D07: Causal Modality vs Associative Modality Substitution
def d07_pc_tag : GateDVerdictTag :=
  if checkSemanticInjectIdempWire termD07CausalDir then .v_d07_pc else .v_unexpectedFailure

def d07_ce_tag : GateDVerdictTag :=
  if (compareCanonicalValuesWire .SPEC_GROUNDED "GateC0-R1:F-C0-07" .canonicalNormStage expectedCanonG06a expectedCanonG03 ==
        .mismatchWitness .canonicalNormStage) &&
     (compareCanonicalValuesWire .SPEC_GROUNDED "GateC0-R1:F-C0-07" .canonicalNormStage expectedCanonG06a expectedCanonG06b ==
        .mismatchWitness .canonicalNormStage) then
    .v_d07_ce
  else .v_unexpectedFailure

-- D08: Temporal Precedence Reversal (`G-04` `ev_stroke < ev_aki` vs `ev_aki < ev_stroke`)
def d08_pc_tag : GateDVerdictTag :=
  if checkCanonRoundtripWire expectedCanonG04_AB then .v_d08_pc else .v_unexpectedFailure

def d08_ce_tag : GateDVerdictTag :=
  if compareCanonicalValuesWire .SPEC_GROUNDED "S0-R2:G04" .canonicalNormStage
       expectedCanonG04_AB expectedCanonG04_BA == .mismatchWitness .canonicalNormStage then
    .v_d08_ce
  else .v_unexpectedFailure

-- D09: `G-15` Symmetric Conjunction vs `G-16` Contrastive & Boundary Separation (`F-DIFF-P0-03`)
def d09_pc_tag : GateDVerdictTag :=
  if checkForestSingleConsensusWire envDiscourse [synthValidG16Tree] then
    .v_d09_pc
  else .v_unexpectedFailure

def d09_ce_tag : GateDVerdictTag :=
  if checkSurfaceEmptyParseWire ctxG11BadCohort &&
     checkForestExtDiagWire envDiscourse [synthBadAnchorG16Tree] (.invalidContrastiveAnchor .Gen_G16_DocContrastive) &&
     (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:G15_vs_G16" .canonicalNormStage
        termD09Contrast termD09SymConj == .mismatchWitness .canonicalNormStage) then
    .v_d09_ce
  else .v_unexpectedFailure

-- D10: Canonical Optional Field Omission (`covariatesOpt`, `pValOpt`, `disp2Opt`)
def d10_pc_tag : GateDVerdictTag :=
  if checkSemanticInjectRoundtripOk termD10WithCov &&
     checkSemanticInjectRoundtripOk termD10Med then
    .v_d10_pc
  else .v_unexpectedFailure

def d10_ce_tag : GateDVerdictTag :=
  if (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:G14" .canonicalNormStage
        termD10WithCov termD10DropCov == .mismatchWitness .canonicalNormStage) &&
     (compareSemanticInjectCanonsWire .SPEC_GROUNDED "S0-R2:G06a" .canonicalNormStage
        termD07CausalDir termD10DropP == .mismatchWitness .canonicalNormStage) then
    .v_d10_ce
  else .v_unexpectedFailure

-- D11: All Remaining `ExtractionFailureDiag` Branches & Failure-to-Consensus Wire Disguise Rejection
def d11_pc_tag : GateDVerdictTag :=
  if checkForestExtDiagWire envAtomic [synthMissingChildrenG15aTree]
       (.malformedParseNode .Gen_G15a_DocConjAtomic "expected_two_child_subtrees") &&
     checkForestExtDiagWire envMismatchedCohort [synthTreeG15a_AB]
       (.mismatchedScopeCohort "coh_primary" "coh_other_registry") &&
     checkForestExtDiagWire envMismatchedDesign [synthTreeG15b_BA]
       (.unresolvedAnaphoricScope "des_study" "des_other_registry") then
    .v_d11_pc
  else .v_unexpectedFailure

def d11_ce_tag : GateDVerdictTag :=
  if checkForestReplayRejectWire ctxG15b ctxG15b envMismatchedDesign [synthTreeG15b_BA] .nonConsensusOutcomeSubmitted &&
     (verdictHead (compareWirePayloads outcomeWireCodec .SPEC_GROUNDED "F-P3C-D02:5Way" .outcomeGateStage
        (encodeWire outcomeWireCodec (evalForestPure envMismatchedDesign [synthTreeG15b_BA]))
        (encodeWire outcomeWireCodec (.consensus [synthTreeG15b_BA] expectedCanonG15Conj))) ==
        .mismatchWitness .outcomeGateStage) then
    .v_d11_ce
  else .v_unexpectedFailure

-- D12: `Provenance R1` Cross-Context Wire Replay (`PO-DIFF-08`)
def d12_pc_tag : GateDVerdictTag :=
  if (verifyDecodedOutcomeWireAgainstProvenance ctxG01 ctxG01 (observeSurfaceE2E ctxG01).outcomeWire).isOk then
    .v_d12_pc
  else .v_unexpectedFailure

def d12_ce_tag : GateDVerdictTag :=
  if checkSurfaceReplayRejectWire ctxG11 ctxG01 ctxG01 .rawBytesMismatch &&
     checkSurfaceReplayRejectWire ctxG11 ctxG11 ctxG01 .substitutedCanonicalMeaning then
    .v_d12_ce
  else .v_unexpectedFailure

-- D13: Malformed / Non-Canonical Wire Rejection (`Corrigendum F-DIFF-P0-01` & `Gate OPT-B` Mandatory Literal `decide`)
def d13_pc_tag : GateDVerdictTag :=
  let validSpanWire := encodeWire spanWireCodec ⟨12, 48⟩
  match decodeWire spanWireCodec validSpanWire with
  | .ok sp => if sp == ⟨12, 48⟩ then .v_d13_pc else .v_unexpectedFailure
  | .error _ => .v_unexpectedFailure

def d13_ce_tag : GateDVerdictTag :=
  let badVer   := decodeWire spanWireCodec "DIFFV0;CodepointSpan;CodepointSpan.mk;N#12;N#48;"
  let badType  := decodeWire spanWireCodec "DIFFV1;CanonicalMeaning;CodepointSpan.mk;N#12;N#48;"
  let badZero  := decodeWire spanWireCodec "DIFFV1;CodepointSpan;CodepointSpan.mk;N#01;N#48;"
  let noSemi   := decodeWire spanWireCodec "DIFFV1;CodepointSpan;CodepointSpan.mk;N#12;N#48"
  let trailing := decodeWire spanWireCodec "DIFFV1;CodepointSpan;CodepointSpan.mk;N#12;N#48;EXTRA;"
  let badStrBytes := decodeWire rawMeaningWireCodec
    "DIFFV1;RawSemanticTerm;RawSemanticTerm.scopedAtom;SemanticScope.unrestrictedPop;STR;N#1;N#1;C#233;AtomicClaim.quantClaim;QuantPredForm.existentialPos;STR;N#1;N#1;C#97;STR;N#1;N#1;C#98;PresupList.nil;"
  match badVer, badType, badZero, noSemi, trailing, badStrBytes with
  | .error (.invalidVersionHeader "DIFFV0"),
    .error (.typeTagMismatch "CodepointSpan" "CanonicalMeaning"),
    .error (.leadingZeroInNatToken "N#01"),
    .error .unterminatedTokenMissingSemicolon,
    .error (.trailingUnconsumedTokens 1),
    .error (.stringByteVsCodepointMismatch 1 2) =>
    .v_d13_ce
  | _, _, _, _, _, _ => .v_unexpectedFailure

-- D14: 5-Valued `DiffVerdict` Algebra (`MODEL_ASSUMPTION` vs `SPECIFICATION_HELD` vs `RESOURCE_OVERFLOW`)
def d14_pc_tag : GateDVerdictTag :=
  if verdictHead (compareWirePayloads rawMeaningWireCodec .MODEL_ASSUMPTION "P3C:SurfaceBinderConvention" .rawExtractionStage
       (encodeWire rawMeaningWireCodec termD04Scoped)
       (encodeWire rawMeaningWireCodec termD04Scoped)) == .matchStructural .MODEL_ASSUMPTION then
    .v_d14_pc
  else .v_unexpectedFailure

def d14_ce_tag : GateDVerdictTag :=
  if (verdictHead (compareWirePayloads canonicalMeaningWireCodec .SPEC_UNDEFINED
        "S0-R2:G01_RightCensored_KM_AJ" .canonicalNormStage
        (encodeWire canonicalMeaningWireCodec expectedCanonG01)
        (encodeWire canonicalMeaningWireCodec expectedCanonG01)) == .specificationHeld) &&
     checkSurfaceOverflowWire ctxT2Overflow (.maxReadingsExceeded 2 1) then
    .v_d14_ce
  else .v_unexpectedFailure

/-! ### 6. Pure `unfold + rw` Kernel Proofs Across All 28 Vectors (`0` `sorry`, `0` `native_decide`) -/

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d01_pc_ok : d01_pc_tag = .v_d01_pc := by
  unfold d01_pc_tag
  simp only [compareCanonicalValuesWire_eq, verdictHead_compare_encode]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d01_ce_ok : d01_ce_tag = .v_d01_ce := by
  unfold d01_ce_tag
  simp only [compareCanonicalValuesWire_eq]
  decide

theorem d02_pc_ok : d02_pc_tag = .v_d02_pc := by
  unfold d02_pc_tag
  rw [checkSurfaceDualAmbiguousWire_eq_isAmbiguousDual, shared_ctxT2_ambiguous_ok]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d02_ce_ok : d02_ce_tag = .v_d02_ce := by
  unfold d02_ce_tag
  rw [checkForestExtDiagWire_eq, checkForestExtDiagWire_eq]
  decide

theorem d03_pc_ok : d03_pc_tag = .v_d03_pc := by
  unfold d03_pc_tag
  rw [checkSurfaceRootSpanWire_of_single_consensus ctxG01 expectedCanonG01 ctxG01_consensus_ok]
  rfl

theorem d03_ce_ok : d03_ce_tag = .v_d03_ce := by
  unfold d03_ce_tag
  have hne : synthTreeG15a_AB ≠ perturbRootSpan synthTreeG15a_AB := by
    intro h
    have hsp : synthTreeG15a_AB.span = (perturbRootSpan synthTreeG15a_AB).span :=
      congrArg ConcreteParseTree.span h
    revert hsp; decide
  rw [verdictHead_compare_encode_of_ne parseTreeWireCodec .SPEC_GROUNDED "S0-R2.1:Span"
        .spanIntegrityStage (by decide) hne]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d04_pc_ok : d04_pc_tag = .v_d04_pc := by
  unfold d04_pc_tag
  rw [checkSemanticInjectRoundtripOk_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d04_ce_ok : d04_ce_tag = .v_d04_ce := by
  unfold d04_ce_tag
  rw [checkSurfaceOodByteWire_eq, checkSurfaceOodByteWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d05_pc_ok : d05_pc_tag = .v_d05_pc := by
  unfold d05_pc_tag
  rw [compareSingleSurfaceCanonsWire_of_single_consensus ctxG11 ctxG12
        expectedCanonG11 expectedCanonG12 .SPEC_GROUNDED "S0-R2:G11_G12" .canonicalNormStage
        ctxG11_consensus_ok shared_ctxG12_consensus_ok]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d05_ce_ok : d05_ce_tag = .v_d05_ce := by
  unfold d05_ce_tag
  rw [compareSemanticInjectCanonsWire_eq, compareSemanticInjectCanonsWire_eq,
      checkSurfaceTrapWire_eq, shared_ctxT5_trap_ok]
  decide

theorem d06_pc_ok : d06_pc_tag = .v_d06_pc := by
  unfold d06_pc_tag
  rw [checkSurfaceSingleConsensusWire_eq, checkSurfaceTrapWire_eq,
      shared_ctxG09_consensus_ok, shared_ctxT3_trap_ok]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d06_ce_ok : d06_ce_tag = .v_d06_ce := by
  unfold d06_ce_tag
  rw [compareSemanticInjectCanonsWire_eq]
  decide

theorem d07_pc_ok : d07_pc_tag = .v_d07_pc := by
  unfold d07_pc_tag
  rw [checkSemanticInjectIdempWire_eq_true]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d07_ce_ok : d07_ce_tag = .v_d07_ce := by
  unfold d07_ce_tag
  rw [compareCanonicalValuesWire_eq, compareCanonicalValuesWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d08_pc_ok : d08_pc_tag = .v_d08_pc := by
  unfold d08_pc_tag
  rw [checkCanonRoundtripWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d08_ce_ok : d08_ce_tag = .v_d08_ce := by
  unfold d08_ce_tag
  rw [compareCanonicalValuesWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d09_pc_ok : d09_pc_tag = .v_d09_pc := by
  unfold d09_pc_tag
  rw [checkForestSingleConsensusWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d09_ce_ok : d09_ce_tag = .v_d09_ce := by
  unfold d09_ce_tag
  rw [checkSurfaceEmptyParseWire_eq, checkForestExtDiagWire_eq,
      compareSemanticInjectCanonsWire_eq, shared_ctxG11BadCohort_empty_ok]
  decide

theorem d10_pc_ok : d10_pc_tag = .v_d10_pc := by
  unfold d10_pc_tag
  rw [checkSemanticInjectRoundtripOk_eq, checkSemanticInjectRoundtripOk_eq]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d10_ce_ok : d10_ce_tag = .v_d10_ce := by
  unfold d10_ce_tag
  rw [compareSemanticInjectCanonsWire_eq, compareSemanticInjectCanonsWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d11_pc_ok : d11_pc_tag = .v_d11_pc := by
  unfold d11_pc_tag
  rw [checkForestExtDiagWire_eq, checkForestExtDiagWire_eq, checkForestExtDiagWire_eq]
  decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d11_ce_ok : d11_ce_tag = .v_d11_ce := by
  unfold d11_ce_tag
  have hne : evalForestPure envMismatchedDesign [synthTreeG15b_BA] ≠
               .consensus [synthTreeG15b_BA] expectedCanonG15Conj := by
    have htag : outcomeBranchOf (evalForestPure envMismatchedDesign [synthTreeG15b_BA]) =
                  .tagSemanticExtractionFailure := by decide
    intro heq
    rw [heq] at htag
    nomatch htag
  rw [checkForestReplayRejectWire_eq,
      verdictHead_compare_encode_of_ne outcomeWireCodec .SPEC_GROUNDED "F-P3C-D02:5Way"
        .outcomeGateStage (by decide) hne]
  unfold verifyClaimPure
  have hcm : checkContextMatch ctxG15b ctxG15b = none :=
    (checkContextMatch_none_iff ctxG15b ctxG15b).mpr rfl
  rw [hcm]
  decide

theorem d12_pc_ok : d12_pc_tag = .v_d12_pc := by
  unfold d12_pc_tag
  have hexec : runP3COnContext ctxG01 = .consensus certG01.trees certG01.canonical :=
    certG01.hExecProvenance
  rw [observeSurfaceE2E_outcomeWire, hexec]
  have hok : verifyDecodedOutcomeWireAgainstProvenance ctxG01 ctxG01
               (encodeWire outcomeWireCodec (.consensus certG01.trees certG01.canonical)) =
             .ok certG01 :=
    ((provenance_boundary_preserved_across_wire ctxG01 ctxG01 _).1 certG01).mpr
      ⟨rfl, rfl, certG01.hExecProvenance⟩
  rw [hok]
  rfl

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d12_ce_ok : d12_ce_tag = .v_d12_ce := by
  unfold d12_ce_tag
  rw [checkSurfaceReplayRejectWire_eq, checkSurfaceReplayRejectWire_eq]
  have hexec01 : runP3COnContext ctxG01 = .consensus certG01.trees expectedCanonG01 := by
    rw [← certG01_canonical_eq]; exact certG01.hExecProvenance
  have hexec11 : certifySemanticConsensus ctxG11.catalog ctxG11.numCfg ctxG11.scopeEnv
                   ctxG11.budget ctxG11.rawBytes = .consensus certG11.trees expectedCanonG11 := by
    rw [← extractAdmittedCert_canonical_eq ctxG11 expectedCanonG11 ctxG11_consensus_ok]
    exact certG11.hExecProvenance
  have hcm11 : checkContextMatch ctxG11 ctxG11 = none :=
    (checkContextMatch_none_iff ctxG11 ctxG11).mpr rfl
  rw [hexec01]
  unfold verifyClaimPure
  simp only [hcm11, hexec11]
  decide

-- Mandatory literal wire `String` decoder verification via pure kernel `decide` (`Gate OPT-B`):
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem d13_pc_ok : d13_pc_tag = .v_d13_pc := by decide

set_option maxHeartbeats 2400000 in
set_option maxRecDepth 16384 in
theorem d13_ce_ok : d13_ce_tag = .v_d13_ce := by decide

theorem d13_literal_decoder_strings_ok :
    eqStrBool (renderGateDTag d13_pc_tag) "VALID_CANONICAL_WIRE_DECODED" = true ∧
    eqStrBool (renderGateDTag d13_ce_tag) "ALL_6_MALFORMED_WIRE_CLASSES_REJECTED" = true := by
  rw [d13_pc_ok, d13_ce_ok]
  decide

theorem d14_pc_ok : d14_pc_tag = .v_d14_pc := by
  unfold d14_pc_tag
  rw [verdictHead_compare_encode_self]
  rfl

theorem d14_ce_ok : d14_ce_tag = .v_d14_ce := by
  unfold d14_ce_tag
  rw [verdictHead_compare_encode_self, checkSurfaceOverflowWire_eq,
      shared_ctxT2Overflow_ok, shared_ctxT2Overflow_parse_overflow]
  rfl

/-! ### 7. Structured 28-Vector Audit Table & Master Suite Theorem (`F-DIFF-OPT-03`) -/

structure DiffAttackCase where
  caseId             : String
  attackFamily       : String
  polarity           : String
  pathClass          : ObservationPathClass
  epistemicGrade     : OracleEpistemicGrade
  r0SpecAnchor       : String
  firstBoundary      : FirstBlockingBoundary
  targetObligation   : String
  expectedTag        : GateDVerdictTag
  actualTag          : GateDVerdictTag
  deriving Repr

def DiffAttackCase.expectedVerdictTag (c : DiffAttackCase) : String :=
  renderGateDTag c.expectedTag

def DiffAttackCase.actualVerdictTag (c : DiffAttackCase) : String :=
  renderGateDTag c.actualTag

def DiffAttackCase.passed (c : DiffAttackCase) : Bool :=
  c.actualTag == c.expectedTag

def mkDiffCase (cid fam pol : String) (pcls : ObservationPathClass) (grd : OracleEpistemicGrade)
    (anc : String) (bnd : FirstBlockingBoundary) (obl : String)
    (exp act : GateDVerdictTag) : DiffAttackCase :=
  { caseId           := cid
    attackFamily     := fam
    polarity         := pol
    pathClass        := pcls
    epistemicGrade   := grd
    r0SpecAnchor     := anc
    firstBoundary    := bnd
    targetObligation := obl
    expectedTag      := exp
    actualTag        := act }

def allDiffAttackCases : List DiffAttackCase :=
  [ mkDiffCase "PC-DIFF-01" "D01_ChildOrderSwap"      "PC" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2.2:G15"          .p3cCanonicalNormalizer     "PO-DIFF-04 / PO-DIFF-05" .v_d01_pc d01_pc_tag,
    mkDiffCase "CE-DIFF-01" "D01_ChildOrderSwap"      "CE" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2:G16"            .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d01_ce d01_ce_tag,
    mkDiffCase "PC-DIFF-02" "D02_ReadingAltPerturb"   "PC" .SURFACE_E2E     .SPEC_GROUNDED    "P0-A05:T2_DualAlt"    .p3cConsensusAndTrapGate    "PO-DIFF-04 / PO-DIFF-06" .v_d02_pc d02_pc_tag,
    mkDiffCase "CE-DIFF-02" "D02_ReadingAltPerturb"   "CE" .FOREST_INJECT   .SPEC_GROUNDED    "P0-A05:AltBounds"     .p3cRawTreeExtractor        "PO-DIFF-04 / PO-DIFF-06" .v_d02_ce d02_ce_tag,
    mkDiffCase "PC-DIFF-03" "D03_SpanOffsetPerturb"   "PC" .SURFACE_E2E     .SPEC_GROUNDED    "S0-R2.1:Span"         .p3bGrammarAndCheckSide     "PO-DIFF-02 / PO-DIFF-03" .v_d03_pc d03_pc_tag,
    mkDiffCase "CE-DIFF-03" "D03_SpanOffsetPerturb"   "CE" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2.1:Span"         .diffV1CanonicalWireDecoder  "PO-DIFF-02 / PO-DIFF-07" .v_d03_ce d03_ce_tag,
    mkDiffCase "PC-DIFF-04" "D04_ByteVsCodepoint"     "PC" .SURFACE_E2E     .SPEC_GROUNDED    "GateC0-R1:F-C0-03"    .p3bStrictAsciiDomain       "PO-DIFF-03"              .v_d04_pc d04_pc_tag,
    mkDiffCase "CE-DIFF-04" "D04_ByteVsCodepoint"     "CE" .SURFACE_E2E     .SPEC_GROUNDED    "GateC0-R1:F-C0-03"    .p3bStrictAsciiDomain       "PO-DIFF-03 / PO-DIFF-06" .v_d04_ce d04_ce_tag,
    mkDiffCase "PC-DIFF-05" "D05_ScopePolarityQuant"  "PC" .SURFACE_E2E     .SPEC_GROUNDED    "S0-R2:G11_G12"        .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d05_pc d05_pc_tag,
    mkDiffCase "CE-DIFF-05" "D05_ScopePolarityQuant"  "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:T1_T5_Scope"    .p3cConsensusAndTrapGate    "PO-DIFF-05 / PO-DIFF-06" .v_d05_ce d05_ce_tag,
    mkDiffCase "PC-DIFF-06" "D06_FactivePresup"       "PC" .SURFACE_E2E     .SPEC_GROUNDED    "S0-R2:G09_vs_T3"      .p3cConsensusAndTrapGate    "PO-DIFF-05 / PO-DIFF-06" .v_d06_pc d06_pc_tag,
    mkDiffCase "CE-DIFF-06" "D06_FactivePresup"       "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "P0-A05:T2_Presup"     .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d06_ce d06_ce_tag,
    mkDiffCase "PC-DIFF-07" "D07_CausalVsAssocModal"  "PC" .SEMANTIC_INJECT .SPEC_GROUNDED    "GateC0-R1:F-C0-07"    .p3cCanonicalNormalizer     "PO-DIFF-05"              .v_d07_pc d07_pc_tag,
    mkDiffCase "CE-DIFF-07" "D07_CausalVsAssocModal"  "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "GateC0-R1:F-C0-07"    .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d07_ce d07_ce_tag,
    mkDiffCase "PC-DIFF-08" "D08_TemporalReversal"    "PC" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:G04"            .p3cCanonicalNormalizer     "PO-DIFF-01 / PO-DIFF-05" .v_d08_pc d08_pc_tag,
    mkDiffCase "CE-DIFF-08" "D08_TemporalReversal"    "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:G04"            .p3cCanonicalNormalizer     "PO-DIFF-05 / PO-DIFF-07" .v_d08_ce d08_ce_tag,
    mkDiffCase "PC-DIFF-09" "D09_SymConjVsContrast"   "PC" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2:G16"            .p3cConsensusAndTrapGate    "PO-DIFF-04 / PO-DIFF-05" .v_d09_pc d09_pc_tag,
    mkDiffCase "CE-DIFF-09" "D09_SymConjVsContrast"   "CE" .FOREST_INJECT   .SPEC_GROUNDED    "S0-R2:G15_vs_G16"     .p3bGrammarAndCheckSide     "PO-DIFF-04 / PO-DIFF-06" .v_d09_ce d09_ce_tag,
    mkDiffCase "PC-DIFF-10" "D10_OptionalFieldDrop"   "PC" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:G02b_G14"       .diffV1CanonicalWireDecoder  "PO-DIFF-01 / PO-DIFF-05" .v_d10_pc d10_pc_tag,
    mkDiffCase "CE-DIFF-10" "D10_OptionalFieldDrop"   "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "S0-R2:G06a_G14"       .p3cCanonicalNormalizer     "PO-DIFF-02 / PO-DIFF-05" .v_d10_ce d10_ce_tag,
    mkDiffCase "PC-DIFF-11" "D11_ExtractionDiag5Way"  "PC" .FOREST_INJECT   .MODEL_ASSUMPTION "P3C:ExtractorDiags"   .p3cRawTreeExtractor        "PO-DIFF-04 / PO-DIFF-06" .v_d11_pc d11_pc_tag,
    mkDiffCase "CE-DIFF-11" "D11_ExtractionDiag5Way"  "CE" .FOREST_INJECT   .SPEC_GROUNDED    "F-P3C-D02:5Way"       .provenanceR1WhiteboxReplay  "PO-DIFF-06 / PO-DIFF-08" .v_d11_ce d11_ce_tag,
    mkDiffCase "PC-DIFF-12" "D12_ProvenanceReplay"    "PC" .SURFACE_E2E     .SPEC_GROUNDED    "F-P3C-01:Provenance"  .provenanceR1WhiteboxReplay  "PO-DIFF-08"              .v_d12_pc d12_pc_tag,
    mkDiffCase "CE-DIFF-12" "D12_ProvenanceReplay"    "CE" .SURFACE_E2E     .SPEC_GROUNDED    "F-P3C-01:Provenance"  .provenanceR1WhiteboxReplay  "PO-DIFF-08"              .v_d12_ce d12_ce_tag,
    mkDiffCase "PC-DIFF-13" "D13_CanonicalWireGate"   "PC" .SEMANTIC_INJECT .SPEC_GROUNDED    "F-DIFF-P0-01:WireV1"  .diffV1CanonicalWireDecoder  "PO-DIFF-01 / PO-DIFF-02" .v_d13_pc d13_pc_tag,
    mkDiffCase "CE-DIFF-13" "D13_CanonicalWireGate"   "CE" .SEMANTIC_INJECT .SPEC_GROUNDED    "F-DIFF-P0-01:WireV1"  .diffV1CanonicalWireDecoder  "PO-DIFF-01 / PO-DIFF-03" .v_d13_ce d13_ce_tag,
    mkDiffCase "PC-DIFF-14" "D14_VerdictGradeAlgebra" "PC" .SEMANTIC_INJECT .MODEL_ASSUMPTION "F-DIFF-P0-02:Grades"  .p3cRawTreeExtractor        "PO-DIFF-07"              .v_d14_pc d14_pc_tag,
    mkDiffCase "CE-DIFF-14" "D14_VerdictGradeAlgebra" "CE" .SURFACE_E2E     .SPEC_UNDEFINED   "S0-R2:G01_RightCens"  .p3bBoundedResourceGate     "PO-DIFF-07"              .v_d14_ce d14_ce_tag ]

private theorem diff_list_all_eq_true {α : Type} (p : α → Bool) (xs : List α) :
    xs.all p = true ↔ ∀ x ∈ xs, p x = true := by
  induction xs with
  | nil => simp [List.all]
  | cons a rest ih =>
    simp only [List.all, Bool.and_eq_true, ih]
    constructor
    · rintro ⟨ha, hrest⟩ x hx
      rcases List.mem_cons.mp hx with rfl | hm
      · exact ha
      · exact hrest x hm
    · intro hall
      exact ⟨hall a (List.Mem.head rest), fun x hx => hall x (List.Mem.tail a hx)⟩

theorem allDiffAttackCases_pass :
    allDiffAttackCases.length = 28 ∧
    ∀ c ∈ allDiffAttackCases,
      c.passed = true ∧
      c.actualTag = c.expectedTag ∧
      c.actualVerdictTag = c.expectedVerdictTag := by
  have hall : ∀ c ∈ allDiffAttackCases, c.passed = true := by
    apply (diff_list_all_eq_true DiffAttackCase.passed allDiffAttackCases).mp
    dsimp only [allDiffAttackCases, mkDiffCase, DiffAttackCase.passed, List.all]
    rw [d01_pc_ok, d01_ce_ok, d02_pc_ok, d02_ce_ok, d03_pc_ok, d03_ce_ok, d04_pc_ok, d04_ce_ok,
        d05_pc_ok, d05_ce_ok, d06_pc_ok, d06_ce_ok, d07_pc_ok, d07_ce_ok, d08_pc_ok, d08_ce_ok,
        d09_pc_ok, d09_ce_ok, d10_pc_ok, d10_ce_ok, d11_pc_ok, d11_ce_ok, d12_pc_ok, d12_ce_ok,
        d13_pc_ok, d13_ce_ok, d14_pc_ok, d14_ce_ok]
    decide
  refine ⟨rfl, ?_⟩
  intro c hc
  have hp := hall c hc
  have htag : c.actualTag = c.expectedTag := eq_of_beq hp
  exact ⟨hp, htag, congrArg renderGateDTag htag⟩

end PneumaOmega.P3C.DifferentialR1.Attacks
