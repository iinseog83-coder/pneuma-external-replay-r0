/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1
  Root export for `P3CDifferentialChecker`
-/
import P3CDifferentialChecker.DifferentialTraceObserver
