/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate B` & `Gate C` Path A Stage Observer)
  02_detached_checker/P3CDifferentialChecker/DifferentialTraceObserver.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`)

  Implements:
    1. `Path A` read-only execution observers for all three `Corrigendum F-DIFF-P0-03` classes:
       - `observeSurfaceE2E`     (`SURFACE_E2E`: `parseAllBounded -> extractRawMeaning -> normalizeMeaning -> certifySemanticConsensus`)
       - `observeForestInject`   (`FOREST_INJECT`: internal `extractRawMeaning` / `evalForestPure` on injected trees)
       - `observeSemanticInject` (`SEMANTIC_INJECT`: internal `RawSemanticTerm -> CanonicalMeaning` normalizer trace)
    2. `PO-DIFF-03b` (`multibyte_utf8_byte_excluded_from_strictAsciiDomain` + upstream fail-closed bridge).
    3. `PO-DIFF-04` (`extraction_result_wire_fidelity`: lossless `.ok`/`.error` & `ForestExtractionError` wire preservation).
    4. `PO-DIFF-05` (`canonical_meaning_wire_fidelity`: lossless `CanonicalMeaning` wire bijection + `SemEq` equivalence).
-/
import P3CDifferentialSpec

namespace PneumaOmega.P3C.DifferentialR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.ProvenanceR1

/-! ### 1. Three-Class Read-Only Execution Observers (`Path A` — `F-DIFF-P0-03`) -/

structure SurfaceTraceBundle where
  byteLen                : Nat
  codepointLenOpt        : Option Nat
  parseStatus            : String
  forestWireOpt          : Option String
  spansWithinBounds      : Bool
  perTreeExtractionWires : List String
  perTreeCanonicalWires  : List String
  outcomeWire            : String
  deriving DecidableEq, Repr

/--
  **`SURFACE_E2E` Observer (`observeSurfaceE2E`)**:
  Calls frozen `parseAllBounded`, `extractRawMeaning`, `normalizeMeaning`, and `certifySemanticConsensus`
  on `ctx` without modifying any upstream module, emitting full `PNEUMA-DIFF-SER-V1` stage wires.
-/
def observeSurfaceE2E (ctx : ProvenanceContext) : SurfaceTraceBundle :=
  match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | .outOfDomain d =>
    { byteLen                := ctx.rawBytes.length
      codepointLenOpt        := none
      parseStatus            := "OUT_OF_DOMAIN"
      forestWireOpt          := none
      spansWithinBounds      := true
      perTreeExtractionWires := []
      perTreeCanonicalWires  := []
      outcomeWire            := encodeWire outcomeWireCodec (.upstreamRejected (.outOfDomain d)) }
  | .resourceOverflow b =>
    { byteLen                := ctx.rawBytes.length
      codepointLenOpt        := none
      parseStatus            := "RESOURCE_OVERFLOW"
      forestWireOpt          := none
      spansWithinBounds      := true
      perTreeExtractionWires := []
      perTreeCanonicalWires  := []
      outcomeWire            := encodeWire outcomeWireCodec (.upstreamRejected (.resourceOverflow b)) }
  | .enumerated T =>
    let docStr := decodeAsciiBytes ctx.rawBytes
    let cpLen  := docStr.toList.length
    let extRes := T.map (extractRawMeaning ctx.scopeEnv)
    let extWires := extRes.map (encodeWire singleExtractionResWireCodec)
    let canonWires := extRes.foldr (fun r acc =>
      match r with
      | .ok m    => encodeWire canonicalMeaningWireCodec (normalizeMeaning m) :: acc
      | .error _ => acc) []
    { byteLen                := ctx.rawBytes.length
      codepointLenOpt        := some cpLen
      parseStatus            := "ENUMERATED"
      forestWireOpt          := some (encodeWire parseForestWireCodec T)
      spansWithinBounds      := T.all (checkTreeSpansWithin 0 cpLen)
      perTreeExtractionWires := extWires
      perTreeCanonicalWires  := canonWires
      outcomeWire            := encodeWire outcomeWireCodec (evalForestPure ctx.scopeEnv T) }

structure ForestInjectTraceBundle where
  forestWire             : String
  perTreeExtractionWires : List String
  forestOutcomeWire      : String
  deriving DecidableEq, Repr

/--
  **`FOREST_INJECT` Observer (`observeForestInject`)**:
  Directly injects an explicit `List ConcreteParseTree` into frozen `P3-C` internal `extractRawMeaning`
  and `evalForestPure` (strictly separated from `parseAllBounded` per `Gate B4` & `F-DIFF-P0-03`).
-/
def observeForestInject (env : ScopeEnv) (injectedForest : List ConcreteParseTree) :
    ForestInjectTraceBundle :=
  { forestWire             := encodeWire parseForestWireCodec injectedForest
    perTreeExtractionWires := injectedForest.map (fun t =>
      encodeWire singleExtractionResWireCodec (extractRawMeaning env t))
    forestOutcomeWire      := encodeWire outcomeWireCodec (evalForestPure env injectedForest) }

structure SemanticInjectTraceBundle where
  rawWire                 : String
  canonicalWire           : String
  idempotentCanonicalWire : String
  deriving DecidableEq, Repr

/--
  **`SEMANTIC_INJECT` Observer (`observeSemanticInject`)**:
  Directly observes `RawSemanticTerm` and its canonical normal form `normalizeMeaning` + idempotence.
-/
def observeSemanticInject (rawTerm : RawSemanticTerm) : SemanticInjectTraceBundle :=
  let c1 := normalizeMeaning rawTerm
  let c2 := normalizeMeaning (embedCanonical c1)
  { rawWire                 := encodeWire rawMeaningWireCodec rawTerm
    canonicalWire           := encodeWire canonicalMeaningWireCodec c1
    idempotentCanonicalWire := encodeWire canonicalMeaningWireCodec c2 }

/-! ### 2. `PO-DIFF-03b` — Multi-Byte UTF-8 Exclusion & Upstream Domain Boundary Integrity -/

/--
  **`PO-DIFF-03b` (`multibyte_utf8_excluded_and_upstream_failClosed`)**:
  1. Any byte `b ∈ rawBytes` with `0x80 ≤ b.toNat` (every multi-byte UTF-8 lead/continuation byte,
     where raw byte count diverges from Unicode codepoint count) falsifies `StrictAsciiDomainSupported rawBytes`.
  2. Whenever `parseAllBounded` rejects `rawBytes` with `.outOfDomain d` or `.resourceOverflow r`,
     `certifySemanticConsensus` deterministically returns `.upstreamRejected` and never emits `.consensus`.
-/
theorem multibyte_utf8_excluded_and_upstream_failClosed :
    (∀ (bs : List UInt8) (b : UInt8),
       b ∈ bs → 0x80 ≤ b.toNat → ¬ StrictAsciiDomainSupported bs) ∧
    (∀ (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
       (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) (d : OutOfDomainDiag),
       parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d →
       certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected (.outOfDomain d)) := by
  refine ⟨?_, ?_⟩
  · intro bs b hmem hge hdom
    rcases hdom with ⟨_, hall⟩
    have hb : IsPrintableAsciiByte b := hall b hmem
    rcases b with ⟨⟨v, _⟩⟩
    rcases hb with ⟨_, hhi⟩
    have hv_hi : v ≤ 0x7E := hhi
    dsimp only [UInt8.toNat, BitVec.toNat] at hge
    omega
  · intro cat numCfg env budget rawBytes d hout
    exact (certifySemanticConsensus_upstream_failClosed cat numCfg env budget rawBytes).1 d hout

/-! ### 3. `PO-DIFF-04` — Extraction Result Fidelity Across Normal & Injected Malformed Trees -/

/--
  **`PO-DIFF-04` (`extraction_result_wire_fidelity`)**:
  1. Single-tree extraction `extractRawMeaning env t` (`Except ExtractionFailureDiag RawSemanticTerm`)
     roundtrips losslessly through `singleExtractionResWireCodec`, never conflating `.ok m` and `.error d`.
  2. `ForestExtractionError` (`failedTree` + `diag`) roundtrips losslessly through `forestExtractionErrWireCodec`.
  3. Whenever `evalForestPure env T = .semanticExtractionFailure T' err`, `T' = T`, `err.failedTree ∈ T`,
     `extractRawMeaning env err.failedTree = .error err.diag`, and `decodeWire outcomeWireCodec` recovers
     the exact `.semanticExtractionFailure T err` structure!
-/
theorem extraction_result_wire_fidelity :
    (∀ (env : ScopeEnv) (t : ConcreteParseTree),
       decodeWire singleExtractionResWireCodec
         (encodeWire singleExtractionResWireCodec (extractRawMeaning env t)) =
         .ok (extractRawMeaning env t)) ∧
    (∀ (d : ExtractionFailureDiag) (m : RawSemanticTerm),
       encodeWire singleExtractionResWireCodec (.error d) ≠
         encodeWire singleExtractionResWireCodec (.ok m)) ∧
    (∀ (err : ForestExtractionError),
       decodeWire forestExtractionErrWireCodec (encodeWire forestExtractionErrWireCodec err) = .ok err) ∧
    (∀ (env : ScopeEnv) (T T' : List ConcreteParseTree) (err : ForestExtractionError),
       evalForestPure env T = .semanticExtractionFailure T' err →
       T' = T ∧
       err.failedTree ∈ T ∧
       extractRawMeaning env err.failedTree = .error err.diag ∧
       decodeWire outcomeWireCodec
         (encodeWire outcomeWireCodec (.semanticExtractionFailure T' err)) =
         .ok (.semanticExtractionFailure T err)) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro env t
    exact encodeWire_decodeWire_roundtrip singleExtractionResWireCodec (extractRawMeaning env t)
  · intro d m heq
    have h := encodeWire_injective singleExtractionResWireCodec heq
    contradiction
  · intro err
    exact encodeWire_decodeWire_roundtrip forestExtractionErrWireCodec err
  · intro env T T' err heval
    cases T with
    | nil => simp [evalForestPure] at heval
    | cons hd tl =>
      unfold evalForestPure at heval
      cases hext : extractAllMeanings env (hd :: tl) with
      | error e0 =>
        rw [hext] at heval
        injection heval with hT herr
        subst T'; subst e0
        have ⟨hmem, hfail⟩ := extractAllMeanings_err_sound hext
        exact ⟨rfl, hmem, hfail, encodeWire_decodeWire_roundtrip outcomeWireCodec _⟩
      | ok pairs =>
        rw [hext] at heval
        cases pairs with
        | nil => contradiction
        | cons p1 rest =>
          rcases p1 with ⟨t1, m1⟩
          dsimp only at heval
          cases hdiv : findDivergentReading t1 m1 (normalizeMeaning m1) rest with
          | some _ => rw [hdiv] at heval; contradiction
          | none =>
            rw [hdiv] at heval
            dsimp only at heval
            cases htrap : findForestTrapViolation (hd :: tl) <;> rw [htrap] at heval <;> contradiction

/-! ### 4. `PO-DIFF-05` — Canonical Meaning Fidelity & `SemEq` Exact Correspondence -/

/--
  **`PO-DIFF-05` (`canonical_meaning_wire_fidelity`)**:
  1. Every `c : CanonicalMeaning` roundtrips losslessly (`decodeWire ... = .ok c`).
  2. Wire equality is equivalent to structural `CanonicalMeaning` equality (`encodeWire c₁ = encodeWire c₂ ↔ c₁ = c₂`).
  3. For all `m₁, m₂ : RawSemanticTerm`, canonical wire equality of `normalizeMeaning m₁` and
     `normalizeMeaning m₂` holds **if and only if** `SemEq m₁ m₂` (`m₁ ∼_sem m₂`), AND
     `(observeSemanticInject m₁).idempotentCanonicalWire = (observeSemanticInject m₁).canonicalWire`!
-/
theorem canonical_meaning_wire_fidelity :
    (∀ c : CanonicalMeaning,
       decodeWire canonicalMeaningWireCodec (encodeWire canonicalMeaningWireCodec c) = .ok c) ∧
    (∀ c₁ c₂ : CanonicalMeaning,
       encodeWire canonicalMeaningWireCodec c₁ = encodeWire canonicalMeaningWireCodec c₂ ↔ c₁ = c₂) ∧
    (∀ m₁ m₂ : RawSemanticTerm,
       encodeWire canonicalMeaningWireCodec (normalizeMeaning m₁) =
         encodeWire canonicalMeaningWireCodec (normalizeMeaning m₂) ↔ SemEq m₁ m₂) ∧
    (∀ m : RawSemanticTerm,
       (observeSemanticInject m).idempotentCanonicalWire = (observeSemanticInject m).canonicalWire) := by
  refine ⟨encodeWire_decodeWire_roundtrip canonicalMeaningWireCodec, ?_, ?_, ?_⟩
  · intro c₁ c₂
    exact ⟨encodeWire_injective canonicalMeaningWireCodec, fun h => by rw [h]⟩
  · intro m₁ m₂
    constructor
    · intro hwire
      have hnorm : normalizeMeaning m₁ = normalizeMeaning m₂ :=
        encodeWire_injective canonicalMeaningWireCodec hwire
      exact (semEq_iff_normalizeMeaning_eq m₁ m₂).mpr hnorm
    · intro hsem
      have hnorm : normalizeMeaning m₁ = normalizeMeaning m₂ :=
        (semEq_iff_normalizeMeaning_eq m₁ m₂).mp hsem
      rw [hnorm]
  · intro m
    unfold observeSemanticInject
    dsimp only
    have hidem : normalizeMeaning (embedCanonical (normalizeMeaning m)) = normalizeMeaning m :=
      normalizeMeaning_embed_id m
    rw [hidem]

/-! ### 5. Equational Bridge Lemmas Avoiding Redundant `ByteArray.IsValidUTF8` Unfolding in Kernel WHNF -/

theorem eqStrBool_encodeWire {α : Type} [DecidableEq α] (C : CanonicalWireCodec α) (x y : α) :
    eqStrBool (encodeWire C x) (encodeWire C y) = (x == y) := by
  by_cases h : x = y
  · subst h
    have ht : eqStrBool (encodeWire C x) (encodeWire C x) = true := (eqStrBool_iff _ _).mpr rfl
    simp [ht]
  · have hne : encodeWire C x ≠ encodeWire C y := fun he => h (encodeWire_injective C he)
    have hf : eqStrBool (encodeWire C x) (encodeWire C y) = false :=
      Bool.eq_false_iff.mpr (fun ht => hne ((eqStrBool_iff _ _).mp ht))
    have hbeq : (x == y) = false := beq_false_of_ne h
    rw [hf, hbeq]

theorem compareWirePayloads_encodeWire {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
      match grade with
      | .SPEC_UNDEFINED =>
        .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held"
      | _ =>
        if x == y then
          .MATCH_STRUCTURAL grade
        else
          let leanWire := encodeWire C x
          let oracleWire := encodeWire C y
          let lToks := match splitSemiChars leanWire.toList.length leanWire.toList with | .ok ts => ts | .error _ => []
          let oToks := match splitSemiChars oracleWire.toList.length oracleWire.toList with | .ok ts => ts | .error _ => []
          .MISMATCH_WITNESS stage (firstDivergentTokIdx 0 lToks oToks) leanWire oracleWire := by
  cases grade with
  | SPEC_UNDEFINED => rfl
  | SPEC_GROUNDED =>
    simp only [compareWirePayloads, encodeWire_decodeWire_roundtrip, eqStrBool_encodeWire]; rfl
  | MODEL_ASSUMPTION =>
    simp only [compareWirePayloads, encodeWire_decodeWire_roundtrip, eqStrBool_encodeWire]; rfl

theorem verifyDecodedOutcomeWire_encodeWire (targetCtx claimedCtx : ProvenanceContext)
    (out : SemanticNormOutcome) :
    verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx (encodeWire outcomeWireCodec out) =
      match verifyUntrustedConsensusClaim targetCtx { claimedCtx := claimedCtx, claimedOutcome := out } with
      | .error pe => .error (.inr pe)
      | .ok cert  => .ok cert := by
  unfold verifyDecodedOutcomeWireAgainstProvenance
  rw [encodeWire_decodeWire_roundtrip]
  rfl

theorem observeSurfaceE2E_outcomeWire (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).outcomeWire = encodeWire outcomeWireCodec (runP3COnContext ctx) := by
  unfold observeSurfaceE2E runP3COnContext certifySemanticConsensus
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;> rfl

theorem observeSurfaceE2E_parseStatus (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).parseStatus =
      match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
      | .outOfDomain _      => "OUT_OF_DOMAIN"
      | .resourceOverflow _ => "RESOURCE_OVERFLOW"
      | .enumerated _       => "ENUMERATED" := by
  unfold observeSurfaceE2E
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;> rfl

theorem observeSurfaceE2E_codepointLenOpt (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).codepointLenOpt =
      match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
      | .enumerated _ => some (decodeAsciiBytes ctx.rawBytes).toList.length
      | _             => none := by
  unfold observeSurfaceE2E
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;> rfl

theorem observeSurfaceE2E_extWires_length (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).perTreeExtractionWires.length =
      match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
      | .enumerated T => T.length
      | _             => 0 := by
  unfold observeSurfaceE2E
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;> simp

theorem observeSurfaceE2E_elim_forest {β : Type} (ctx : ProvenanceContext)
    (f : Nat → Except DecodeRejectDiag (List ConcreteParseTree) → Bool → β) (dflt : β) :
    (match (observeSurfaceE2E ctx).codepointLenOpt, (observeSurfaceE2E ctx).forestWireOpt with
     | some cpLen, some fWire =>
       f cpLen (decodeWire parseForestWireCodec fWire) (observeSurfaceE2E ctx).spansWithinBounds
     | _, _ => dflt) =
    (match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
     | .enumerated T =>
       let cpLen := (decodeAsciiBytes ctx.rawBytes).toList.length
       f cpLen (.ok T) (T.all (checkTreeSpansWithin 0 cpLen))
     | _ => dflt) := by
  unfold observeSurfaceE2E
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;>
    simp [encodeWire_decodeWire_roundtrip]

def extractSurfaceCanonList (ctx : ProvenanceContext) : List CanonicalMeaning :=
  match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | .enumerated T =>
    (T.map (extractRawMeaning ctx.scopeEnv)).foldr (fun r acc =>
      match r with
      | .ok m    => normalizeMeaning m :: acc
      | .error _ => acc) []
  | _ => []

theorem observeSurfaceE2E_perTreeCanonicalWires (ctx : ProvenanceContext) :
    (observeSurfaceE2E ctx).perTreeCanonicalWires =
      (extractSurfaceCanonList ctx).map (encodeWire canonicalMeaningWireCodec) := by
  unfold observeSurfaceE2E extractSurfaceCanonList
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | outOfDomain _ => rfl
  | resourceOverflow _ => rfl
  | enumerated T =>
    dsimp only
    induction (T.map (extractRawMeaning ctx.scopeEnv)) with
    | nil => rfl
    | cons r rs ih =>
      cases r <;> simp [List.foldr, ih]

theorem elim_canon_wire_pair_cmp {β : Type} (xs ys : List CanonicalMeaning)
    (grade : OracleEpistemicGrade) (anc : String) (st : DiffStage)
    (k : DiffVerdict → β) (dflt : β) :
    (match xs.map (encodeWire canonicalMeaningWireCodec),
           ys.map (encodeWire canonicalMeaningWireCodec) with
     | [c1], [c2] => k (compareWirePayloads canonicalMeaningWireCodec grade anc st c1 c2)
     | _, _ => dflt) =
    (match xs, ys with
     | [m1], [m2] =>
       k (compareWirePayloads canonicalMeaningWireCodec grade anc st
            (encodeWire canonicalMeaningWireCodec m1)
            (encodeWire canonicalMeaningWireCodec m2))
     | _, _ => dflt) := by
  cases xs with
  | nil => rfl
  | cons x1 xs' =>
    cases xs' with
    | cons _ _ => rfl
    | nil =>
      cases ys with
      | nil => rfl
      | cons y1 ys' =>
        cases ys' <;> rfl

/-! ### 6. `Gate OPT-A` — Verdict Head Projection (`F-DIFF-OPT-01`) & Full Witness Fidelity (`F-DIFF-OPT-02`) -/

/--
  Finite structural projection of `DiffVerdict` retaining verdict kind, `OracleEpistemicGrade`,
  and `DiffStage` while abstracting away multi-kilobyte wire witness strings during kernel proving.
  (Explicitly named a projection/abstraction — NOT a quotient type — per `Gate OPT-A`.)
-/
inductive DiffVerdictHead where
  | matchStructural (grade : OracleEpistemicGrade)
  | mismatchWitness (stage : DiffStage)
  | oracleFailure
  | specificationHeld
  | resourceHeld
  deriving DecidableEq, Repr

def verdictHead : DiffVerdict → DiffVerdictHead
  | .MATCH_STRUCTURAL g        => .matchStructural g
  | .MISMATCH_WITNESS st _ _ _ => .mismatchWitness st
  | .ORACLE_FAILURE _          => .oracleFailure
  | .SPECIFICATION_HELD _ _    => .specificationHeld
  | .RESOURCE_HELD _           => .resourceHeld

/--
  **`F-DIFF-OPT-01a` (`verdictHead_compare_encode`)**:
  Computable kernel reduction equation for `verdictHead (compareWirePayloads ...)`: eliminates
  wire-string construction from the right-hand side while preserving exact branch semantics.
-/
theorem verdictHead_compare_encode {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _               => if x == y then .matchStructural grade else .mismatchWitness stage := by
  rw [compareWirePayloads_encodeWire]
  cases grade with
  | SPEC_UNDEFINED => rfl
  | SPEC_GROUNDED =>
    by_cases h : (x == y) = true <;> simp [h, verdictHead]
  | MODEL_ASSUMPTION =>
    by_cases h : (x == y) = true <;> simp [h, verdictHead]

/--
  **`F-DIFF-OPT-01b` (`verdictHead_branch_preservation_iff`)**:
  Proves that `verdictHead` preserves all three canonical comparator branches (`SPEC_UNDEFINED`,
  `MATCH_STRUCTURAL`, and `MISMATCH_WITNESS`) without conflating any branch or grade.
-/
theorem verdictHead_branch_preservation_iff {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    ((verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
        .specificationHeld ↔
        grade = .SPEC_UNDEFINED ∧
        compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
          .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held") ∧
     (∀ g,
        verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
          .matchStructural g ↔
          grade ≠ .SPEC_UNDEFINED ∧ g = grade ∧ x = y ∧
          compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
            .MATCH_STRUCTURAL g) ∧
     (∀ st,
        verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
          .mismatchWitness st ↔
          grade ≠ .SPEC_UNDEFINED ∧ st = stage ∧ x ≠ y)) := by
  refine ⟨?_, ?_, ?_⟩
  · rw [verdictHead_compare_encode]
    cases grade with
    | SPEC_UNDEFINED =>
      simp [compareWirePayloads]
    | SPEC_GROUNDED =>
      by_cases h : (x == y) = true <;> simp [h]
    | MODEL_ASSUMPTION =>
      by_cases h : (x == y) = true <;> simp [h]
  · intro g
    rw [verdictHead_compare_encode]
    have ⟨hm, _⟩ := compareWirePayloads_sound_and_complete C grade r0Anchor stage x y
    cases grade with
    | SPEC_UNDEFINED => simp
    | SPEC_GROUNDED =>
      by_cases hxy : x = y
      · subst hxy
        simp only [beq_self_eq_true, ↓reduceIte, DiffVerdictHead.matchStructural.injEq, ne_eq,
                   reduceCtorEq, not_false_eq_true, true_and]
        constructor
        · rintro rfl
          exact ⟨rfl, (hm .SPEC_GROUNDED).mpr ⟨by decide, rfl, rfl⟩⟩
        · rintro ⟨hg, _⟩; exact hg.symm
      · have hbeq : (x == y) = false := beq_false_of_ne hxy
        simp [hbeq, hxy]
    | MODEL_ASSUMPTION =>
      by_cases hxy : x = y
      · subst hxy
        simp only [beq_self_eq_true, ↓reduceIte, DiffVerdictHead.matchStructural.injEq, ne_eq,
                   reduceCtorEq, not_false_eq_true, true_and]
        constructor
        · rintro rfl
          exact ⟨rfl, (hm .MODEL_ASSUMPTION).mpr ⟨by decide, rfl, rfl⟩⟩
        · rintro ⟨hg, _⟩; exact hg.symm
      · have hbeq : (x == y) = false := beq_false_of_ne hxy
        simp [hbeq, hxy]
  · intro st
    rw [verdictHead_compare_encode]
    cases grade with
    | SPEC_UNDEFINED => simp
    | SPEC_GROUNDED =>
      by_cases hxy : x = y
      · subst hxy; simp
      · have hbeq : (x == y) = false := beq_false_of_ne hxy
        simp [hbeq, hxy, eq_comm]
    | MODEL_ASSUMPTION =>
      by_cases hxy : x = y
      · subst hxy; simp
      · have hbeq : (x == y) = false := beq_false_of_ne hxy
        simp [hbeq, hxy, eq_comm]

private theorem splitSemiChars_encodeWire_tokens {α : Type} (C : CanonicalWireCodec α) (x : α) :
    splitSemiChars (encodeWire C x).toList.length (encodeWire C x).toList =
      .ok ("DIFFV1" :: C.typeTag :: C.encToks x) := by
  unfold encodeWire
  rw [String.toList_ofList]
  have hall_valid : ∀ t ∈ ("DIFFV1" :: C.typeTag :: C.encToks x), ValidToken t := by
    intro t ht
    rcases List.mem_cons.mp ht with rfl | ht2
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp ht2 with rfl | ht3
      · exact C.hTagValid
      · exact (C.hToksValid x).2 t ht3
  exact splitSemiChars_joinSemiChars _ _
    (joinSemiChars_length_ge _)
    (fun t ht => (hall_valid t ht).1)
    (fun t ht => (hall_valid t ht).2)

/--
  **`F-DIFF-OPT-02` (`compareWirePayloads_mismatch_witness_fidelity`)**:
  Separate witness-fidelity theorem proving that whenever `verdictHead` observes `.mismatchWitness st`,
  the unprojected `compareWirePayloads` retains:
    1. Exact pinpoint token-divergence locus `firstDivergentTokIdx` over the canonical token streams,
    2. Intact `leanWire = encodeWire C x` and `oracleWire = encodeWire C y` with `encodeWire C x ≠ encodeWire C y`,
    3. Lossless roundtrip recovery `decodeWire C leanWire = .ok x` and `decodeWire C oracleWire = .ok y`.
-/
theorem compareWirePayloads_mismatch_witness_fidelity {α : Type} [DecidableEq α]
    (C : CanonicalWireCodec α) (grade : OracleEpistemicGrade) (r0Anchor : String)
    (stage st : DiffStage) (x y : α)
    (hHead : verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
               .mismatchWitness st) :
    st = stage ∧
    grade ≠ .SPEC_UNDEFINED ∧
    x ≠ y ∧
    encodeWire C x ≠ encodeWire C y ∧
    compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
      .MISMATCH_WITNESS stage
        (firstDivergentTokIdx 0 ("DIFFV1" :: C.typeTag :: C.encToks x) ("DIFFV1" :: C.typeTag :: C.encToks y))
        (encodeWire C x) (encodeWire C y) ∧
    decodeWire C (encodeWire C x) = .ok x ∧
    decodeWire C (encodeWire C y) = .ok y := by
  have ⟨hg, hst, hne⟩ := ((verdictHead_branch_preservation_iff C grade r0Anchor stage x y).2.2 st).mp hHead
  have hne_wire : encodeWire C x ≠ encodeWire C y := fun hw => hne (encodeWire_injective C hw)
  have hbeq : (x == y) = false := beq_false_of_ne hne
  have hcmp :
      compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
        .MISMATCH_WITNESS stage
          (firstDivergentTokIdx 0 ("DIFFV1" :: C.typeTag :: C.encToks x) ("DIFFV1" :: C.typeTag :: C.encToks y))
          (encodeWire C x) (encodeWire C y) := by
    rw [compareWirePayloads_encodeWire]
    cases grade with
    | SPEC_UNDEFINED => exact False.elim (hg rfl)
    | SPEC_GROUNDED =>
      simp only [hbeq, Bool.false_eq_true, ↓reduceIte,
                 splitSemiChars_encodeWire_tokens C x, splitSemiChars_encodeWire_tokens C y]
    | MODEL_ASSUMPTION =>
      simp only [hbeq, Bool.false_eq_true, ↓reduceIte,
                 splitSemiChars_encodeWire_tokens C x, splitSemiChars_encodeWire_tokens C y]
  exact ⟨hst, hg, hne, hne_wire, hcmp,
         encodeWire_decodeWire_roundtrip C x,
         encodeWire_decodeWire_roundtrip C y⟩

theorem observeSurfaceE2E_isResourceOverflow (ctx : ProvenanceContext) :
    eqStrBool (observeSurfaceE2E ctx).parseStatus "RESOURCE_OVERFLOW" =
      match parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
      | .resourceOverflow _ => true
      | _                   => false := by
  rw [observeSurfaceE2E_parseStatus]
  cases parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes <;>
    (dsimp only; decide)

theorem verifyDecodedOutcomeWire_encodeWire_proj (targetCtx claimedCtx : ProvenanceContext)
    (out : SemanticNormOutcome) :
    (verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx (encodeWire outcomeWireCodec out)).map
        (fun c => (c.trees, c.canonical)) =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := out } with
      | .error pe => .error (.inr pe)
      | .ok pair  => .ok pair := by
  rw [verifyDecodedOutcomeWire_encodeWire, ← verifyUntrustedConsensusClaim_proj_eq]
  cases verifyUntrustedConsensusClaim targetCtx { claimedCtx := claimedCtx, claimedOutcome := out } <;> rfl

/-! ### 7. Universal `ValidParse_GFrozen` Span Integrity & `Gate OPT-C` Surface Bridge Lemmas -/

mutual
  private theorem validParseSegs_spansWithin
      {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {syms : List BNFSymbol}
      (args : List ConcreteParseArg)
      {slots : List (BNFSlotTag × String)} {sums : List ParseSummary}
      (parentSpan : CodepointSpan)
      (hStart : parentSpan.startCp ≤ cursor)
      (hEnd : endPos = parentSpan.endCp)
      (h : ValidParseSegs cat numCfg env Y loc cursor syms args endPos slots sums) :
      cursor ≤ endPos ∧ checkArgSpansWithin parentSpan args = true := by
    match syms, args with
    | [], [] =>
      rcases h with ⟨_, rfl, _, _⟩
      exact ⟨Nat.le_refl _, rfl⟩
    | .term _ :: restSyms, .litTok _ sp :: restArgs =>
      rcases h with ⟨_, hspStart, hmatch, hrest⟩
      have hspLe : sp.startCp ≤ sp.endCp := by
        have hlen := hmatch.1; omega
      have ⟨hrestLe, hrestOk⟩ :=
        validParseSegs_spansWithin restArgs parentSpan (by omega) hEnd hrest
      refine ⟨by omega, ?_⟩
      simp only [checkArgSpansWithin, Bool.and_eq_true, decide_eq_true_eq]
      exact ⟨⟨⟨by omega, hspLe⟩, by omega⟩, hrestOk⟩
    | .lexSlot _ _ :: restSyms, .slotTok _ _ _ _ sp :: restArgs =>
      rcases h with ⟨_, _, _, hspStart, hmatch, _, _, hrest⟩
      have hspLe : sp.startCp ≤ sp.endCp := by
        have hlen := hmatch.1; omega
      have ⟨hrestLe, hrestOk⟩ :=
        validParseSegs_spansWithin restArgs parentSpan (by omega) hEnd hrest
      refine ⟨by omega, ?_⟩
      simp only [checkArgSpansWithin, Bool.and_eq_true, decide_eq_true_eq]
      exact ⟨⟨⟨by omega, hspLe⟩, by omega⟩, hrestOk⟩
    | .nonterm _ _ :: restSyms, .childSub sub :: restArgs =>
      rcases h with ⟨_, _, hsubStart, hnode, _, hrest⟩
      have ⟨hsubLe, hsubArgs⟩ := validParseNode_spansWithin sub hnode
      have ⟨hrestLe, hrestOk⟩ :=
        validParseSegs_spansWithin restArgs parentSpan (by omega) hEnd hrest
      refine ⟨by omega, ?_⟩
      cases sub with
      | mkTree _ _ _ subSp subArgs =>
        dsimp only [ConcreteParseTree.span] at hsubStart hsubLe hsubArgs hrestLe
        simp only [checkArgSpansWithin, checkTreeSpansWithin, Bool.and_eq_true, decide_eq_true_eq]
        exact ⟨⟨⟨⟨by omega, hsubLe⟩, by omega⟩, hsubArgs⟩, hrestOk⟩

  private theorem validParseNode_spansWithin
      {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {nt : BNFNonterm}
      (tree : ConcreteParseTree) {sum : ParseSummary}
      (h : ValidParseNode cat numCfg env Y loc nt tree sum) :
      tree.span.startCp ≤ tree.span.endCp ∧
      match tree with
      | .mkTree _ _ _ sp args => checkArgSpansWithin sp args = true := by
    cases tree with
    | mkTree p alt loc' sp args =>
      rcases h with ⟨_, _, _, _, _, _, hsegs, _, _⟩
      have ⟨hle, hok⟩ := validParseSegs_spansWithin args sp (Nat.le_refl _) rfl hsegs
      exact ⟨hle, hok⟩
end

/--
  **Universal Span Integrity Theorem (`validParse_GFrozen_spansWithin`)**:
  Every parse tree `tree` satisfying `ValidParse_GFrozen` has root span `⟨0, rawBytes.length⟩`
  and satisfies `checkTreeSpansWithin 0 rawBytes.length tree = true`.
-/
theorem validParse_GFrozen_spansWithin
    {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {env : ScopeEnv} {rawBytes : List UInt8} {tree : ConcreteParseTree}
    (h : ValidParse_GFrozen cat numCfg env rawBytes tree) :
    tree.span = ⟨0, rawBytes.length⟩ ∧
    checkTreeSpansWithin 0 rawBytes.length tree = true := by
  rcases h with ⟨hdom, hroot, sum, hnode⟩
  have hlen : (decodeAsciiBytes rawBytes).toList.length = rawBytes.length :=
    (strictAscii_byte_eq_codepoint_length rawBytes hdom).1
  rw [hlen] at hroot
  have ⟨hle, hargs⟩ := validParseNode_spansWithin tree hnode
  refine ⟨hroot, ?_⟩
  cases tree with
  | mkTree p alt loc sp args =>
    dsimp only [ConcreteParseTree.span] at hroot hle hargs
    subst hroot
    simp only [checkTreeSpansWithin, Bool.and_eq_true, decide_eq_true_eq]
    exact ⟨⟨⟨Nat.zero_le _, Nat.zero_le _⟩, Nat.le_refl _⟩, hargs⟩

def checkSurfaceRootSpanWire (ctx : ProvenanceContext) : Bool :=
  let tr := observeSurfaceE2E ctx
  match tr.codepointLenOpt, tr.forestWireOpt with
  | some cpLen, some fWire =>
    match decodeWire parseForestWireCodec fWire with
    | .ok [ConcreteParseTree.mkTree _ _ _ rootSp _] =>
      tr.spansWithinBounds && (cpLen == ctx.rawBytes.length) && (rootSp == ⟨0, cpLen⟩)
    | _ => false
  | _, _ => false

theorem evalForestPure_trees_eq {env : ScopeEnv} {T T' : List ConcreteParseTree} {c : CanonicalMeaning}
    (h : evalForestPure env T = .consensus T' c) :
    T' = T := by
  unfold evalForestPure at h
  cases T with
  | nil => contradiction
  | cons t0 ts =>
    dsimp only at h
    cases hex : extractAllMeanings env (t0 :: ts) with
    | error _ => rw [hex] at h; contradiction
    | ok pairs =>
      rw [hex] at h
      cases pairs with
      | nil => contradiction
      | cons p1 rest =>
        dsimp only at h
        cases hdiv : findDivergentReading p1.1 p1.2 (normalizeMeaning p1.2) rest with
        | some _ => rw [hdiv] at h; contradiction
        | none =>
          rw [hdiv] at h
          cases htrap : findForestTrapViolation (t0 :: ts) with
          | some _ => rw [htrap] at h; contradiction
          | none =>
            rw [htrap] at h
            injection h with hT _
            exact hT.symm

theorem evalForestPure_ambiguous_trees_eq {env : ScopeEnv} {T T' : List ConcreteParseTree}
    {w : AmbiguityRefutationWitness}
    (h : evalForestPure env T = .ambiguousReadings T' w) :
    T' = T := by
  unfold evalForestPure at h
  cases T with
  | nil => contradiction
  | cons t0 ts =>
    dsimp only at h
    cases hex : extractAllMeanings env (t0 :: ts) with
    | error _ => rw [hex] at h; contradiction
    | ok pairs =>
      rw [hex] at h
      cases pairs with
      | nil => contradiction
      | cons p1 rest =>
        dsimp only at h
        cases hdiv : findDivergentReading p1.1 p1.2 (normalizeMeaning p1.2) rest with
        | none =>
          rw [hdiv] at h
          cases htrap : findForestTrapViolation (t0 :: ts) with
          | some _ => rw [htrap] at h; contradiction
          | none => rw [htrap] at h; contradiction
        | some w' =>
          rw [hdiv] at h
          injection h with hT _
          exact hT.symm

theorem checkSurfaceRootSpanWire_of_single_consensus (ctx : ProvenanceContext)
    (expected : CanonicalMeaning)
    (h : PneumaOmega.P3C.Counterexamples.isConsensusSingleEq (runP3COnContext ctx) expected = true) :
    checkSurfaceRootSpanWire ctx = true := by
  unfold checkSurfaceRootSpanWire observeSurfaceE2E
  unfold runP3COnContext certifySemanticConsensus at h
  cases hp : parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | outOfDomain d => rw [hp] at h; contradiction
  | resourceOverflow r => rw [hp] at h; contradiction
  | enumerated T =>
    rw [hp] at h
    dsimp only at h ⊢
    rw [encodeWire_decodeWire_roundtrip]
    have hsc := parseAllBounded_enumerated_sound_and_complete
      ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes T hp
    have hcp : (decodeAsciiBytes ctx.rawBytes).toList.length = ctx.rawBytes.length :=
      (strictAscii_byte_eq_codepoint_length ctx.rawBytes hsc.1).1
    rw [hcp]
    cases hev : evalForestPure ctx.scopeEnv T with
    | ambiguousReadings _ _ => rw [hev] at h; contradiction
    | semanticExtractionFailure _ _ => rw [hev] at h; contradiction
    | trapPolicyRejected _ _ _ => rw [hev] at h; contradiction
    | upstreamRejected _ => rw [hev] at h; contradiction
    | consensus T' c =>
      rw [hev] at h
      unfold PneumaOmega.P3C.Counterexamples.isConsensusSingleEq at h
      cases T' with
      | nil => contradiction
      | cons t1 ts =>
        cases ts with
        | cons _ _ => contradiction
        | nil =>
          have hT : [t1] = T := evalForestPure_trees_eq hev
          subst hT
          have hv : ValidParse_GFrozen ctx.catalog ctx.numCfg ctx.scopeEnv ctx.rawBytes t1 :=
            (hsc.2.2.2.2 t1).mp (List.Mem.head [])
          have ⟨hroot, hwithin⟩ := validParse_GFrozen_spansWithin hv
          cases t1 with
          | mkTree p alt loc rootSp args =>
            dsimp only [ConcreteParseTree.span] at hroot
            subst hroot
            simp [List.all, hwithin]

def checkSurfaceDualAmbiguousWire (ctx : ProvenanceContext) : Bool :=
  let tr := observeSurfaceE2E ctx
  match decodeWire outcomeWireCodec tr.outcomeWire with
  | .ok (.ambiguousReadings [t1, t2] w) =>
    (tr.perTreeExtractionWires.length == 2) && (!parseTreeEqBool t1 t2) && w.isDivergent
  | _ => false

theorem checkSurfaceDualAmbiguousWire_eq_isAmbiguousDual (ctx : ProvenanceContext) :
    checkSurfaceDualAmbiguousWire ctx =
      PneumaOmega.P3C.Counterexamples.isAmbiguousDual (runP3COnContext ctx) := by
  dsimp only [checkSurfaceDualAmbiguousWire]
  rw [observeSurfaceE2E_outcomeWire, encodeWire_decodeWire_roundtrip, observeSurfaceE2E_extWires_length]
  unfold runP3COnContext certifySemanticConsensus PneumaOmega.P3C.Counterexamples.isAmbiguousDual
  cases hp : parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | outOfDomain _ => rfl
  | resourceOverflow _ => rfl
  | enumerated T =>
    dsimp only
    cases hev : evalForestPure ctx.scopeEnv T with
    | consensus _ _ => rfl
    | semanticExtractionFailure _ _ => rfl
    | trapPolicyRejected _ _ _ => rfl
    | upstreamRejected _ => rfl
    | ambiguousReadings T' w =>
      have hT : T' = T := evalForestPure_ambiguous_trees_eq hev
      subst T'
      cases T with
      | nil => rfl
      | cons t1 ts =>
        cases ts with
        | nil => rfl
        | cons t2 ts2 =>
          cases ts2 <;> simp

def compareSingleSurfaceCanonsWire (ctx₁ ctx₂ : ProvenanceContext)
    (grade : OracleEpistemicGrade) (anc : String) (st : DiffStage) : Option DiffVerdictHead :=
  let tr1 := observeSurfaceE2E ctx₁
  let tr2 := observeSurfaceE2E ctx₂
  match tr1.perTreeCanonicalWires, tr2.perTreeCanonicalWires with
  | [c1], [c2] => some (verdictHead (compareWirePayloads canonicalMeaningWireCodec grade anc st c1 c2))
  | _, _ => none

theorem extractSurfaceCanonList_of_single_consensus (ctx : ProvenanceContext)
    (expected : CanonicalMeaning)
    (h : PneumaOmega.P3C.Counterexamples.isConsensusSingleEq (runP3COnContext ctx) expected = true) :
    extractSurfaceCanonList ctx = [expected] := by
  unfold extractSurfaceCanonList
  unfold runP3COnContext certifySemanticConsensus at h
  cases hp : parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | outOfDomain _ => rw [hp] at h; contradiction
  | resourceOverflow _ => rw [hp] at h; contradiction
  | enumerated T =>
    rw [hp] at h
    dsimp only at h ⊢
    cases hev : evalForestPure ctx.scopeEnv T with
    | ambiguousReadings _ _ => rw [hev] at h; contradiction
    | semanticExtractionFailure _ _ => rw [hev] at h; contradiction
    | trapPolicyRejected _ _ _ => rw [hev] at h; contradiction
    | upstreamRejected _ => rw [hev] at h; contradiction
    | consensus T' c =>
      rw [hev] at h
      unfold PneumaOmega.P3C.Counterexamples.isConsensusSingleEq at h
      cases T' with
      | nil => contradiction
      | cons t1 ts =>
        cases ts with
        | cons _ _ => contradiction
        | nil =>
          have hc : c = expected := (canonicalMeaningEqBool_iff c expected).mp h
          have hT : [t1] = T := evalForestPure_trees_eq hev
          subst hT; subst hc
          unfold evalForestPure extractAllMeanings at hev
          dsimp only at hev
          cases hex : extractRawMeaning ctx.scopeEnv t1 with
          | error _ => rw [hex] at hev; contradiction
          | ok m1 =>
            rw [hex] at hev
            dsimp only [findDivergentReading] at hev
            cases htrap : findForestTrapViolation [t1] with
            | some _ => rw [htrap] at hev; contradiction
            | none =>
              rw [htrap] at hev
              injection hev with _ hm
              simp [hex, hm]

theorem verdictHead_compare_encode_self {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x : α) :
    verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C x)) =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _               => .matchStructural grade := by
  rw [verdictHead_compare_encode]
  cases grade <;> simp

theorem verdictHead_compare_encode_of_ne {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) {x y : α}
    (hg : grade ≠ .SPEC_UNDEFINED) (hne : x ≠ y) :
    verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
      .mismatchWitness stage := by
  exact ((verdictHead_branch_preservation_iff C grade r0Anchor stage x y).2.2 stage).mpr ⟨hg, rfl, hne⟩

theorem verdictHead_compare_canon (grade : OracleEpistemicGrade) (r0Anchor : String)
    (stage : DiffStage) (x y : CanonicalMeaning) :
    verdictHead (compareWirePayloads canonicalMeaningWireCodec grade r0Anchor stage
      (encodeWire canonicalMeaningWireCodec x) (encodeWire canonicalMeaningWireCodec y)) =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _ => if canonicalMeaningEqBool x y then .matchStructural grade else .mismatchWitness stage := by
  have hb : (x == y) = canonicalMeaningEqBool x y :=
    Bool.eq_iff_iff.mpr (by rw [beq_iff_eq, canonicalMeaningEqBool_iff])
  rw [verdictHead_compare_encode]
  cases grade <;> simp [hb]

def eqExtractionDiagBool : ExtractionFailureDiag → ExtractionFailureDiag → Bool
  | .malformedParseNode p1 d1, .malformedParseNode p2 d2 => (p1 == p2) && eqStrBool d1 d2
  | .unsupportedReadingAlt p1 a1, .unsupportedReadingAlt p2 a2 => (p1 == p2) && (a1 == a2)
  | .mismatchedScopeCohort f1 e1, .mismatchedScopeCohort f2 e2 => eqStrBool f1 f2 && eqStrBool e1 e2
  | .unresolvedAnaphoricScope f1 e1, .unresolvedAnaphoricScope f2 e2 => eqStrBool f1 f2 && eqStrBool e1 e2
  | .invalidContrastiveAnchor p1, .invalidContrastiveAnchor p2 => p1 == p2
  | _, _ => false

theorem eqExtractionDiagBool_iff (d₁ d₂ : ExtractionFailureDiag) :
    eqExtractionDiagBool d₁ d₂ = true ↔ d₁ = d₂ := by
  cases d₁ <;> cases d₂ <;>
    simp [eqExtractionDiagBool, Bool.and_eq_true, beq_iff_eq, eqStrBool_iff]

theorem compareSingleSurfaceCanonsWire_of_single_consensus
    (ctx₁ ctx₂ : ProvenanceContext) (c₁ c₂ : CanonicalMeaning)
    (grade : OracleEpistemicGrade) (anc : String) (st : DiffStage)
    (h₁ : PneumaOmega.P3C.Counterexamples.isConsensusSingleEq (runP3COnContext ctx₁) c₁ = true)
    (h₂ : PneumaOmega.P3C.Counterexamples.isConsensusSingleEq (runP3COnContext ctx₂) c₂ = true) :
    compareSingleSurfaceCanonsWire ctx₁ ctx₂ grade anc st =
      some (match grade with
            | .SPEC_UNDEFINED => .specificationHeld
            | _ => if canonicalMeaningEqBool c₁ c₂ then .matchStructural grade else .mismatchWitness st) := by
  dsimp only [compareSingleSurfaceCanonsWire]
  rw [observeSurfaceE2E_perTreeCanonicalWires ctx₁,
      observeSurfaceE2E_perTreeCanonicalWires ctx₂,
      extractSurfaceCanonList_of_single_consensus ctx₁ c₁ h₁,
      extractSurfaceCanonList_of_single_consensus ctx₂ c₂ h₂]
  simp only [List.map, verdictHead_compare_canon]

/-! ### 8. `let`-Free Named Wire Observation Combinators (`Gate OPT-A/B`: Zero Kernel `dsimp` Overhead) -/

def decodeSurfaceOutcomeWire (ctx : ProvenanceContext) : Except DecodeRejectDiag SemanticNormOutcome :=
  decodeWire outcomeWireCodec (observeSurfaceE2E ctx).outcomeWire

theorem decodeSurfaceOutcomeWire_eq (ctx : ProvenanceContext) :
    decodeSurfaceOutcomeWire ctx = .ok (runP3COnContext ctx) := by
  unfold decodeSurfaceOutcomeWire
  rw [observeSurfaceE2E_outcomeWire, encodeWire_decodeWire_roundtrip]

def decodeForestOutcomeWire (env : ScopeEnv) (T : List ConcreteParseTree) :
    Except DecodeRejectDiag SemanticNormOutcome :=
  decodeWire outcomeWireCodec (observeForestInject env T).forestOutcomeWire

theorem decodeForestOutcomeWire_eq (env : ScopeEnv) (T : List ConcreteParseTree) :
    decodeForestOutcomeWire env T = .ok (evalForestPure env T) :=
  encodeWire_decodeWire_roundtrip outcomeWireCodec (evalForestPure env T)

def decodeSemanticInjectCanonWire (m : RawSemanticTerm) :
    Except DecodeRejectDiag CanonicalMeaning :=
  decodeWire canonicalMeaningWireCodec (observeSemanticInject m).canonicalWire

theorem decodeSemanticInjectCanonWire_eq (m : RawSemanticTerm) :
    decodeSemanticInjectCanonWire m = .ok (normalizeMeaning m) :=
  encodeWire_decodeWire_roundtrip canonicalMeaningWireCodec (normalizeMeaning m)

def checkSemanticInjectIdempWire (m : RawSemanticTerm) : Bool :=
  eqStrBool (observeSemanticInject m).canonicalWire (observeSemanticInject m).idempotentCanonicalWire

theorem checkSemanticInjectIdempWire_eq_true (m : RawSemanticTerm) :
    checkSemanticInjectIdempWire m = true := by
  unfold checkSemanticInjectIdempWire
  rw [canonical_meaning_wire_fidelity.2.2.2 m]
  exact (eqStrBool_iff _ _).mpr rfl

def compareSemanticInjectCanonsWire (grade : OracleEpistemicGrade) (anc : String)
    (st : DiffStage) (m₁ m₂ : RawSemanticTerm) : DiffVerdictHead :=
  verdictHead (compareWirePayloads canonicalMeaningWireCodec grade anc st
    (observeSemanticInject m₁).canonicalWire
    (observeSemanticInject m₂).canonicalWire)

theorem compareSemanticInjectCanonsWire_eq (grade : OracleEpistemicGrade) (anc : String)
    (st : DiffStage) (m₁ m₂ : RawSemanticTerm) :
    compareSemanticInjectCanonsWire grade anc st m₁ m₂ =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _ =>
        if canonicalMeaningEqBool (normalizeMeaning m₁) (normalizeMeaning m₂) then
          .matchStructural grade
        else
          .mismatchWitness st :=
  verdictHead_compare_canon grade anc st (normalizeMeaning m₁) (normalizeMeaning m₂)

def compareCanonicalValuesWire (grade : OracleEpistemicGrade) (anc : String)
    (st : DiffStage) (c₁ c₂ : CanonicalMeaning) : DiffVerdictHead :=
  verdictHead (compareWirePayloads canonicalMeaningWireCodec grade anc st
    (encodeWire canonicalMeaningWireCodec c₁)
    (encodeWire canonicalMeaningWireCodec c₂))

theorem compareCanonicalValuesWire_eq (grade : OracleEpistemicGrade) (anc : String)
    (st : DiffStage) (c₁ c₂ : CanonicalMeaning) :
    compareCanonicalValuesWire grade anc st c₁ c₂ =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _ => if canonicalMeaningEqBool c₁ c₂ then .matchStructural grade else .mismatchWitness st :=
  verdictHead_compare_canon grade anc st c₁ c₂

def verifySurfaceWireReplayProj (targetCtx claimedCtx srcCtx : ProvenanceContext) :
    Except (Sum DecodeRejectDiag ProvenanceRejectReason) (List ConcreteParseTree × CanonicalMeaning) :=
  (verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx
    (observeSurfaceE2E srcCtx).outcomeWire).map (fun c => (c.trees, c.canonical))

theorem verifySurfaceWireReplayProj_eq (targetCtx claimedCtx srcCtx : ProvenanceContext) :
    verifySurfaceWireReplayProj targetCtx claimedCtx srcCtx =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := runP3COnContext srcCtx } with
      | .error pe => .error (.inr pe)
      | .ok pair  => .ok pair := by
  unfold verifySurfaceWireReplayProj
  rw [observeSurfaceE2E_outcomeWire, verifyDecodedOutcomeWire_encodeWire_proj]

def verifyForestWireReplayProj (targetCtx claimedCtx : ProvenanceContext)
    (env : ScopeEnv) (T : List ConcreteParseTree) :
    Except (Sum DecodeRejectDiag ProvenanceRejectReason) (List ConcreteParseTree × CanonicalMeaning) :=
  (verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx
    (observeForestInject env T).forestOutcomeWire).map (fun c => (c.trees, c.canonical))

theorem verifyForestWireReplayProj_eq (targetCtx claimedCtx : ProvenanceContext)
    (env : ScopeEnv) (T : List ConcreteParseTree) :
    verifyForestWireReplayProj targetCtx claimedCtx env T =
      match verifyClaimPure targetCtx { claimedCtx := claimedCtx, claimedOutcome := evalForestPure env T } with
      | .error pe => .error (.inr pe)
      | .ok pair  => .ok pair :=
  verifyDecodedOutcomeWire_encodeWire_proj targetCtx claimedCtx (evalForestPure env T)

end PneumaOmega.P3C.DifferentialR1
