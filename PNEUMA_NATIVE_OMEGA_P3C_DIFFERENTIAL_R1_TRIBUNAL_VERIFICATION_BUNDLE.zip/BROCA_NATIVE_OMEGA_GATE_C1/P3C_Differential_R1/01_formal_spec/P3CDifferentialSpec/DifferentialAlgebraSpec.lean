/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Corrigendum R0`: `F-DIFF-P0-02..04` & `PO-DIFF-06..08`)
  01_formal_spec/P3CDifferentialSpec/DifferentialAlgebraSpec.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`)

  Defines:
    1. `OracleEpistemicGrade` (`SPEC_GROUNDED` | `MODEL_ASSUMPTION` | `SPEC_UNDEFINED` — `F-DIFF-P0-02`).
    2. `ObservationPathClass` (`SURFACE_E2E` | `FOREST_INJECT` | `SEMANTIC_INJECT` — `F-DIFF-P0-03`).
    3. Closed 5-way `DiffVerdict` (`MATCH_STRUCTURAL` | `MISMATCH_WITNESS` | `ORACLE_FAILURE` |
       `SPECIFICATION_HELD` | `RESOURCE_HELD` — `F-DIFF-P0-04`), never collapsing non-matches into `PASS`.
    4. Typed wire differential comparator `compareWirePayloads` with `PO-DIFF-07` (`Differential Scope Soundness`)
       and `PO-DIFF-08` (`Provenance Boundary Preservation`).
-/
import P3CDifferentialSpec.TypedWireFormatV1

namespace PneumaOmega.P3C.DifferentialR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.ProvenanceR1

/-! ### 1. Epistemic Grades (`F-DIFF-P0-02`) & Observation Path Classes (`F-DIFF-P0-03`) -/

inductive OracleEpistemicGrade where
  | SPEC_GROUNDED      -- Directly determined by frozen `Architecture Freeze R0` text/tables
  | MODEL_ASSUMPTION   -- Model-relative convention formalized in `P3-C` beyond raw `R0` prose
  | SPEC_UNDEFINED     -- Underspecified in `R0` -> must yield `SPECIFICATION_HELD`
  deriving DecidableEq, Repr

inductive ObservationPathClass where
  | SURFACE_E2E        -- End-to-end surface bytes through `parseAllBounded -> P3-C -> Provenance R1`
  | FOREST_INJECT      -- Direct `ConcreteParseTree` / forest injection into `P3-C` internal gates
  | SEMANTIC_INJECT    -- Direct `RawSemanticTerm` / `CanonicalMeaning` / wire payload perturbation
  deriving DecidableEq, Repr

inductive FirstBlockingBoundary where
  | p3bStrictAsciiDomain
  | p3bBoundedResourceGate
  | p3bGrammarAndCheckSide
  | p3cRawTreeExtractor
  | p3cCanonicalNormalizer
  | p3cConsensusAndTrapGate
  | diffV1CanonicalWireDecoder
  | provenanceR1WhiteboxReplay
  deriving DecidableEq, Repr

/-! ### 2. Closed 5-Valued Differential Result Algebra (`DiffVerdict` — `F-DIFF-P0-04`) -/

inductive DiffStage where
  | wireDecodeStage
  | parseForestStage
  | spanIntegrityStage
  | rawExtractionStage
  | canonicalNormStage
  | outcomeGateStage
  | provenanceReplayStage
  deriving DecidableEq, Repr

inductive DiffVerdict where
  | MATCH_STRUCTURAL   (grade : OracleEpistemicGrade)
  | MISMATCH_WITNESS   (stage : DiffStage) (fieldLocus : String) (leanWire oracleWire : String)
  | ORACLE_FAILURE     (reason : String)
  | SPECIFICATION_HELD (r0Anchor : String) (detail : String)
  | RESOURCE_HELD      (budgetDetail : String)
  deriving DecidableEq, Repr

/-- Pinpoints the first token index where two wire strings diverge. -/
def firstDivergentTokIdx : Nat → List String → List String → String
  | idx, [], [] => s!"tok#{idx}:identical"
  | idx, _ :: _, [] => s!"tok#{idx}:lean_longer"
  | idx, [], _ :: _ => s!"tok#{idx}:oracle_longer"
  | idx, x :: xs, y :: ys =>
    if eqStrBool x y then firstDivergentTokIdx (idx + 1) xs ys
    else s!"tok#{idx}({x} != {y})"

/--
  **Typed Canonical Wire Differential Comparator (`compareWirePayloads`)**:
  - Never collapses `SPEC_UNDEFINED` into `MATCH_STRUCTURAL`: returns `SPECIFICATION_HELD`.
  - Decodes BOTH `leanWire` and `oracleWire` via `decodeWire C` (verifying both belong to `L_valid(C)`).
  - Returns `MATCH_STRUCTURAL grade` iff `grade ≠ .SPEC_UNDEFINED`, both wires are valid canonical encodings,
    and `leanWire = oracleWire` (which by `PO-DIFF-02` guarantees exact Lean value equality `x = y`!).
-/
def compareWirePayloads {α : Type} (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage)
    (leanWire oracleWire : String) : DiffVerdict :=
  match grade with
  | .SPEC_UNDEFINED =>
    .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held"
  | _ =>
    match decodeWire C leanWire with
    | .error eLean =>
      .ORACLE_FAILURE s!"lean_wire_decode_failed:{reprStr eLean}"
    | .ok _ =>
      match decodeWire C oracleWire with
      | .error eOracle =>
        .ORACLE_FAILURE s!"oracle_wire_decode_failed:{reprStr eOracle}"
      | .ok _ =>
        if eqStrBool leanWire oracleWire then
          .MATCH_STRUCTURAL grade
        else
          let lToks := match splitSemiChars leanWire.toList.length leanWire.toList with | .ok ts => ts | .error _ => []
          let oToks := match splitSemiChars oracleWire.toList.length oracleWire.toList with | .ok ts => ts | .error _ => []
          .MISMATCH_WITNESS stage (firstDivergentTokIdx 0 lToks oToks) leanWire oracleWire

/--
  **`PO-DIFF-07` (`Differential Scope Soundness`)**:
  1. `compareWirePayloads C grade anchor stage (encodeWire C x) (encodeWire C y) = .MATCH_STRUCTURAL g`
     holds **if and only if** `grade ≠ .SPEC_UNDEFINED`, `g = grade`, and `x = y` (exact structural equality
     of computational data `α` — explicitly NOT claiming clinical truth or `Prop` proof byte-equality!).
  2. Whenever `grade ≠ .SPEC_UNDEFINED` and `x ≠ y`, `compareWirePayloads` deterministically produces
     `.MISMATCH_WITNESS stage locus (encodeWire C x) (encodeWire C y)`!
-/
theorem compareWirePayloads_sound_and_complete {α : Type} (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    ((∀ g, compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
             .MATCH_STRUCTURAL g ↔ (grade ≠ .SPEC_UNDEFINED ∧ g = grade ∧ x = y)) ∧
     (grade ≠ .SPEC_UNDEFINED → x ≠ y →
       ∃ locus : String,
         compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
           .MISMATCH_WITNESS stage locus (encodeWire C x) (encodeWire C y))) := by
  refine ⟨?_, ?_⟩
  · intro g
    cases grade with
    | SPEC_UNDEFINED =>
      simp [compareWirePayloads]
    | SPEC_GROUNDED =>
      unfold compareWirePayloads
      rw [encodeWire_decodeWire_roundtrip C x, encodeWire_decodeWire_roundtrip C y]
      dsimp only
      by_cases heq : eqStrBool (encodeWire C x) (encodeWire C y) = true
      · rw [if_pos heq]
        have hxy : x = y := encodeWire_injective C ((eqStrBool_iff _ _).mp heq)
        simp [hxy, eq_comm]
      · rw [if_neg heq]
        constructor
        · intro h; contradiction
        · rintro ⟨_, _, rfl⟩
          exact False.elim (heq ((eqStrBool_iff _ _).mpr rfl))
    | MODEL_ASSUMPTION =>
      unfold compareWirePayloads
      rw [encodeWire_decodeWire_roundtrip C x, encodeWire_decodeWire_roundtrip C y]
      dsimp only
      by_cases heq : eqStrBool (encodeWire C x) (encodeWire C y) = true
      · rw [if_pos heq]
        have hxy : x = y := encodeWire_injective C ((eqStrBool_iff _ _).mp heq)
        simp [hxy, eq_comm]
      · rw [if_neg heq]
        constructor
        · intro h; contradiction
        · rintro ⟨_, _, rfl⟩
          exact False.elim (heq ((eqStrBool_iff _ _).mpr rfl))
  · intro hgrade hne
    have hneq_wire : eqStrBool (encodeWire C x) (encodeWire C y) = false := by
      apply Bool.eq_false_iff.mpr
      intro heq
      exact hne (encodeWire_injective C ((eqStrBool_iff _ _).mp heq))
    cases grade with
    | SPEC_UNDEFINED => exact False.elim (hgrade rfl)
    | SPEC_GROUNDED =>
      unfold compareWirePayloads
      rw [encodeWire_decodeWire_roundtrip C x, encodeWire_decodeWire_roundtrip C y]
      dsimp only
      rw [hneq_wire]
      exact ⟨_, rfl⟩
    | MODEL_ASSUMPTION =>
      unfold compareWirePayloads
      rw [encodeWire_decodeWire_roundtrip C x, encodeWire_decodeWire_roundtrip C y]
      dsimp only
      rw [hneq_wire]
      exact ⟨_, rfl⟩

/-! ### 3. `PO-DIFF-06` (`Five-Way Outcome Tag Separation`) & `PO-DIFF-08` (`Provenance Boundary`) -/

inductive OutcomeBranchTag where
  | tagConsensus
  | tagAmbiguousReadings
  | tagSemanticExtractionFailure
  | tagTrapPolicyRejected
  | tagUpstreamRejected
  deriving DecidableEq, Repr

def outcomeBranchOf : SemanticNormOutcome → OutcomeBranchTag
  | .consensus _ _                 => .tagConsensus
  | .ambiguousReadings _ _         => .tagAmbiguousReadings
  | .semanticExtractionFailure _ _ => .tagSemanticExtractionFailure
  | .trapPolicyRejected _ _ _      => .tagTrapPolicyRejected
  | .upstreamRejected _            => .tagUpstreamRejected

/--
  **`PO-DIFF-06` (`Five-Way Outcome Separation Across Wire Serialization`)**:
  Two `SemanticNormOutcome` values with distinct 5-way branch tags NEVER collide under `encodeWire`,
  and decoding any `encodeWire outcomeWireCodec out` preserves the exact 5-way branch tag and payload!
-/
theorem outcome_wire_preserves_five_way_separation (o₁ o₂ : SemanticNormOutcome) :
    (outcomeBranchOf o₁ ≠ outcomeBranchOf o₂ →
       encodeWire outcomeWireCodec o₁ ≠ encodeWire outcomeWireCodec o₂) ∧
    (∀ o', decodeWire outcomeWireCodec (encodeWire outcomeWireCodec o₁) = .ok o' →
       o' = o₁ ∧ outcomeBranchOf o' = outcomeBranchOf o₁) := by
  refine ⟨?_, ?_⟩
  · intro hne heq
    have ho : o₁ = o₂ := encodeWire_injective outcomeWireCodec heq
    subst ho
    exact hne rfl
  · intro o' hd
    have hrt := encodeWire_decodeWire_roundtrip outcomeWireCodec o₁
    rw [hrt] at hd
    injection hd with heq
    subst heq
    exact ⟨rfl, rfl⟩

/--
  Reconstructs an `UntrustedConsensusClaim` from a decoded `SemanticNormOutcome` wire payload and a
  claimed `ProvenanceContext`, then submits it to `ProvenanceR1.verifyUntrustedConsensusClaim`.
-/
def verifyDecodedOutcomeWireAgainstProvenance (targetCtx claimedCtx : ProvenanceContext)
    (wirePayload : String) :
    Except (Sum DecodeRejectDiag ProvenanceRejectReason) (CertifiedSemanticConsensus targetCtx) :=
  match decodeWire outcomeWireCodec wirePayload with
  | .error de => .error (.inl de)
  | .ok decodedOut =>
    match verifyUntrustedConsensusClaim targetCtx { claimedCtx := claimedCtx, claimedOutcome := decodedOut } with
    | .error pe => .error (.inr pe)
    | .ok cert  => .ok cert

/--
  **`PO-DIFF-08` (`Provenance Boundary Preservation`)**:
  Decoding a valid `PNEUMA-DIFF-SER-V1` `SemanticNormOutcome` string NEVER bypasses `Provenance R1`:
  1. `verifyDecodedOutcomeWireAgainstProvenance` admits `cert : CertifiedSemanticConsensus targetCtx`
     **iff** `claimedCtx = targetCtx`, `wirePayload = encodeWire outcomeWireCodec (.consensus cert.trees cert.canonical)`,
     and actual `P3-C` execution `ExecProvenanceSpec targetCtx cert.trees cert.canonical` holds!
  2. Any context mismatch (`claimedCtx ≠ targetCtx`) or any serialized non-consensus / forged outcome is rejected!
-/
theorem provenance_boundary_preserved_across_wire (targetCtx claimedCtx : ProvenanceContext)
    (wirePayload : String) :
    ((∀ cert : CertifiedSemanticConsensus targetCtx,
        verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx wirePayload = .ok cert ↔
          claimedCtx = targetCtx ∧
          wirePayload = encodeWire outcomeWireCodec (.consensus cert.trees cert.canonical) ∧
          ExecProvenanceSpec targetCtx cert.trees cert.canonical) ∧
     (claimedCtx ≠ targetCtx →
        ∃ err, verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx wirePayload = .error err)) := by
  refine ⟨?_, ?_⟩
  · intro cert
    unfold verifyDecodedOutcomeWireAgainstProvenance
    constructor
    · intro hok
      cases hd : decodeWire outcomeWireCodec wirePayload with
      | error _ => rw [hd] at hok; contradiction
      | ok dOut =>
        rw [hd] at hok
        dsimp only at hok
        cases hv : verifyUntrustedConsensusClaim targetCtx { claimedCtx := claimedCtx, claimedOutcome := dOut } with
        | error _ => rw [hv] at hok; contradiction
        | ok cert' =>
          rw [hv] at hok
          injection hok with hce
          subst cert'
          have ⟨hcl, hexec, _⟩ := (replay_faithfulness_iff targetCtx).1
            { claimedCtx := claimedCtx, claimedOutcome := dOut } cert hv
          unfold exportUntrustedClaim at hcl
          injection hcl with hctx hdout
          have hwire : encodeWire outcomeWireCodec dOut = wirePayload :=
            (decodeWire_ok_iff_encodeWire_eq outcomeWireCodec wirePayload dOut).mp hd
          rw [hdout] at hwire
          exact ⟨hctx, hwire.symm, hexec⟩
    · rintro ⟨hctx, rfl, _⟩
      subst claimedCtx
      rw [encodeWire_decodeWire_roundtrip outcomeWireCodec (.consensus cert.trees cert.canonical)]
      dsimp only
      have hcomp := (replay_faithfulness_iff targetCtx).2 cert
      unfold exportUntrustedClaim at hcomp
      rw [hcomp]
  · intro hne
    unfold verifyDecodedOutcomeWireAgainstProvenance
    cases hd : decodeWire outcomeWireCodec wirePayload with
    | error de => exact ⟨.inl de, rfl⟩
    | ok dOut =>
      dsimp only
      have ⟨r, hr⟩ := input_binding_replay_rejects_context_mismatch targetCtx
        { claimedCtx := claimedCtx, claimedOutcome := dOut } hne
      rw [hr]
      exact ⟨.inr r, rfl⟩

end PneumaOmega.P3C.DifferentialR1
