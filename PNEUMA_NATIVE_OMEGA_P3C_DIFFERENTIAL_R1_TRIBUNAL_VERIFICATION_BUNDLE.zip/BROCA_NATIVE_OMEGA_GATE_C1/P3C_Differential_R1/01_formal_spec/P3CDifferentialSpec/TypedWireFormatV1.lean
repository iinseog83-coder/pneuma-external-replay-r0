/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate A` & `Corrigendum R0` `F-DIFF-P0-01` / `PO-DIFF-01..06`)
  01_formal_spec/P3CDifferentialSpec/TypedWireFormatV1.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`)

  Implements `PNEUMA-DIFF-SER-V1` Canonical Prefix-Free Typed Serialization:
    1. Explicit separation between arbitrary `String` and valid canonical encodings `ValidWireEncoding C s`.
    2. Generic `CanonicalWireCodec α` proving:
       - `PO-DIFF-01a` (`Roundtrip`)            : `decodeWire C (encodeWire C x) = .ok x`
       - `PO-DIFF-01b` (`Canonical Uniqueness`) : `decodeWire C s = .ok x ↔ encodeWire C x = s`
       - `PO-DIFF-01c` (`Malformed Rejection`)  : `(∀ x, encodeWire C x ≠ s) → ∃ e, decodeWire C s = .error e`
       - `PO-DIFF-02`  (`Encoding Injectivity`) : `encodeWire C x = encodeWire C y → x = y`
    3. Explicit `cpLen` AND `utf8ByteLen` on every serialized string (`STR;N#<cpLen>;N#<utf8Bytes>;...`),
       plus `PO-DIFF-03` (`Span Unit Integrity`) proving 1-byte = 1-codepoint on `StrictAsciiDomainSupported`
       and deterministic `.outOfDomain` rejection on multi-byte UTF-8 (`>= 0x80`).
    4. Full codecs for `CodepointSpan`, `ConcreteParseTree`, `List ConcreteParseTree`, `RawSemanticTerm`,
       `CanonicalMeaning`, `ForestExtractionError`, extraction `Except` results, and 5-way `SemanticNormOutcome`.
-/
import P3CProvenanceObligations

namespace PneumaOmega.P3C.DifferentialR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C

/-! ### 1. Deterministic Wire Decode Rejection Diagnostics (`F-DIFF-P0-01`) -/

inductive DecodeRejectDiag where
  | emptyWirePayload
  | unterminatedTokenMissingSemicolon
  | emptyTokenSegment
  | missingHeaderTokens
  | invalidVersionHeader        (found : String)
  | typeTagMismatch             (expected found : String)
  | unexpectedEndOfTokens       (context : String)
  | recursionFuelExhausted
  | malformedNatToken           (found : String)
  | leadingZeroInNatToken       (found : String)
  | uint8OutOfRange             (val : Nat)
  | malformedCharToken          (found : String)
  | invalidUnicodeScalar        (val : Nat)
  | stringByteVsCodepointMismatch (declaredBytes actualBytes : Nat)
  | unknownConstructorTag       (typeName found : String)
  | trailingUnconsumedTokens    (remainingCount : Nat)
  | nonCanonicalWireEncoding
  deriving DecidableEq, Repr

/-! ### 2. Semicolon-Delimited Token Framing Over `List Char` (`DIFFV1;<TypeTag>;<toks...>;`) -/

def joinSemiChars : List String → List Char
  | []      => []
  | t :: ts => t.toList ++ (';' :: joinSemiChars ts)

def readUntilSemi : List Char → Option (List Char × List Char)
  | []      => none
  | c :: cs =>
    if c == ';' then some ([], cs)
    else
      match readUntilSemi cs with
      | none           => none
      | some (tok, rs) => some (c :: tok, rs)

theorem readUntilSemi_append (tok rest : List Char) (hno : ';' ∉ tok) :
    readUntilSemi (tok ++ (';' :: rest)) = some (tok, rest) := by
  induction tok with
  | nil => rfl
  | cons c cs ih =>
    have hc : c ≠ ';' := fun heq => hno (by rw [heq]; exact List.Mem.head cs)
    have hcs : ';' ∉ cs := fun hm => hno (List.Mem.tail c hm)
    simp only [List.cons_append, readUntilSemi]
    have hbeq : (c == ';') = false := beq_false_of_ne hc
    rw [hbeq, ih hcs]
    rfl

def splitSemiChars (fuel : Nat) (cs : List Char) : Except DecodeRejectDiag (List String) :=
  match fuel, cs with
  | _, [] => .ok []
  | 0, _ :: _ => .error .recursionFuelExhausted
  | f + 1, _ :: _ =>
    match readUntilSemi cs with
    | none => .error .unterminatedTokenMissingSemicolon
    | some ([], _) => .error .emptyTokenSegment
    | some (c :: tokTail, rest) =>
      match splitSemiChars f rest with
      | .error e  => .error e
      | .ok tails => .ok (String.ofList (c :: tokTail) :: tails)

theorem joinSemiChars_length_ge (ts : List String) :
    ts.length ≤ (joinSemiChars ts).length := by
  induction ts with
  | nil => simp [joinSemiChars]
  | cons t rest ih =>
    simp only [joinSemiChars, List.length_append, List.length_cons]
    omega

theorem splitSemiChars_joinSemiChars (ts : List String) (fuel : Nat)
    (hfuel : ts.length ≤ fuel)
    (hnonempty : ∀ t ∈ ts, t ≠ "")
    (hnosemi : ∀ t ∈ ts, ';' ∉ t.toList) :
    splitSemiChars fuel (joinSemiChars ts) = .ok ts := by
  induction ts generalizing fuel with
  | nil =>
    cases fuel <;> rfl
  | cons t rest ih =>
    cases fuel with
    | zero => simp at hfuel
    | succ f =>
      have ht_ne : t ≠ "" := hnonempty t (List.Mem.head rest)
      have ht_ns : ';' ∉ t.toList := hnosemi t (List.Mem.head rest)
      have htl_ne : t.toList ≠ [] := by
        intro hemp
        apply ht_ne
        have h1 : String.ofList t.toList = String.ofList [] := congrArg String.ofList hemp
        simpa using h1
      cases hchars : t.toList with
      | nil => exact False.elim (htl_ne hchars)
      | cons c0 ctail =>
        have hns' : ';' ∉ (c0 :: ctail) := by rw [← hchars]; exact ht_ns
        have hjoin : joinSemiChars (t :: rest) = (c0 :: ctail) ++ (';' :: joinSemiChars rest) := by
          simp [joinSemiChars, hchars]
        rw [hjoin]
        simp only [List.cons_append, splitSemiChars]
        have hread : readUntilSemi (c0 :: (ctail ++ ';' :: joinSemiChars rest)) =
                     some (c0 :: ctail, joinSemiChars rest) := by
          simpa [List.cons_append] using readUntilSemi_append (c0 :: ctail) (joinSemiChars rest) hns'
        rw [hread]
        dsimp only
        have hf_rest : rest.length ≤ f := by simp at hfuel; omega
        have hrec := ih f hf_rest
          (fun x hx => hnonempty x (List.Mem.tail t hx))
          (fun x hx => hnosemi x (List.Mem.tail t hx))
        rw [hrec]
        have hstr : String.ofList (c0 :: ctail) = t := by
          rw [← hchars, String.ofList_toList]
        rw [hstr]

/-! ### 3. Generic `CanonicalWireCodec` & `PO-DIFF-01` / `PO-DIFF-02` Metatheorems -/

def ValidToken (t : String) : Prop :=
  t ≠ "" ∧ ';' ∉ t.toList

def checkValidTokenBool (t : String) : Bool :=
  (!t.isEmpty) && (!(t.toList.contains ';'))

theorem checkValidTokenBool_sound {t : String} (h : checkValidTokenBool t = true) :
    ValidToken t := by
  unfold checkValidTokenBool at h
  rw [Bool.and_eq_true] at h
  rcases h with ⟨hne, hnc⟩
  refine ⟨?_, ?_⟩
  · intro heq; subst heq; simp at hne
  · intro hmem
    have hc : t.toList.contains ';' = true := List.elem_eq_true_of_mem hmem
    rw [hc] at hnc; contradiction

structure CanonicalWireCodec (α : Type) where
  typeTag      : String
  encToks      : α → List String
  parseToks    : Nat → List String → Except DecodeRejectDiag (α × List String)
  hTagValid    : ValidToken typeTag
  hToksValid   : ∀ (x : α), (encToks x ≠ []) ∧ (∀ t ∈ encToks x, ValidToken t)
  hParsePrefix : ∀ (x : α) (rest : List String) (fuel : Nat),
    (encToks x).length ≤ fuel →
    parseToks fuel (encToks x ++ rest) = .ok (x, rest)

/-- Canonical `PNEUMA-DIFF-SER-V1` encoder (`"DIFFV1;<TypeTag>;<tok_1>;...;<tok_k>;"`). -/
def encodeWire {α : Type} (C : CanonicalWireCodec α) (x : α) : String :=
  String.ofList (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x))

/-- Declarative membership in the canonical wire language `L_valid(C)` (`F-DIFF-P0-01`). -/
def ValidWireEncoding {α : Type} (C : CanonicalWireCodec α) (s : String) : Prop :=
  ∃ x : α, encodeWire C x = s

/--
  Canonical `PNEUMA-DIFF-SER-V1` decoder:
  Parses tokens, rejects any malformed/truncated/trailing/non-canonical input with a pinpoint
  `DecodeRejectDiag`, and accepts iff `s` is the unique canonical encoding of `x` (`F-DIFF-P0-01`).
-/
def decodeWire {α : Type} (C : CanonicalWireCodec α) (s : String) : Except DecodeRejectDiag α :=
  if s.toList.isEmpty then
    .error .emptyWirePayload
  else
    match splitSemiChars s.toList.length s.toList with
    | .error e => .error e
    | .ok toks =>
      match toks with
      | ver :: ttag :: body =>
        if !eqStrBool ver "DIFFV1" then
          .error (.invalidVersionHeader ver)
        else if !eqStrBool ttag C.typeTag then
          .error (.typeTagMismatch C.typeTag ttag)
        else
          match C.parseToks body.length body with
          | .error e => .error e
          | .ok (val, rem) =>
            match rem with
            | _ :: _ => .error (.trailingUnconsumedTokens rem.length)
            | [] =>
              if eqStrBool (encodeWire C val) s then
                .ok val
              else
                .error .nonCanonicalWireEncoding
      | _ => .error .missingHeaderTokens

/-- **`PO-DIFF-01a` (`Roundtrip`)**: Every value `x : α` decodes back to `.ok x`. -/
theorem encodeWire_decodeWire_roundtrip {α : Type} (C : CanonicalWireCodec α) (x : α) :
    decodeWire C (encodeWire C x) = .ok x := by
  unfold decodeWire encodeWire
  rw [String.toList_ofList]
  have hne_cs : (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)).isEmpty = false := by
    simp [joinSemiChars]
  rw [hne_cs]
  have hall_valid : ∀ t ∈ ("DIFFV1" :: C.typeTag :: C.encToks x), ValidToken t := by
    intro t ht
    rcases List.mem_cons.mp ht with rfl | ht2
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp ht2 with rfl | ht3
      · exact C.hTagValid
      · exact (C.hToksValid x).2 t ht3
  have hlen : ("DIFFV1" :: C.typeTag :: C.encToks x).length ≤
              (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)).length :=
    joinSemiChars_length_ge _
  have hsplit : splitSemiChars (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)).length
                  (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)) =
                .ok ("DIFFV1" :: C.typeTag :: C.encToks x) :=
    splitSemiChars_joinSemiChars _ _ hlen
      (fun t ht => (hall_valid t ht).1)
      (fun t ht => (hall_valid t ht).2)
  have hparse : C.parseToks (C.encToks x).length (C.encToks x) = .ok (x, []) := by
    simpa using C.hParsePrefix x [] (C.encToks x).length (Nat.le_refl _)
  have hver : eqStrBool "DIFFV1" "DIFFV1" = true := (eqStrBool_iff _ _).mpr rfl
  have httag : eqStrBool C.typeTag C.typeTag = true := (eqStrBool_iff _ _).mpr rfl
  have henc_eq : eqStrBool (String.ofList (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x)))
                   (String.ofList (joinSemiChars ("DIFFV1" :: C.typeTag :: C.encToks x))) = true :=
    (eqStrBool_iff _ _).mpr rfl
  simp only [hsplit, hver, httag, hparse, henc_eq, Bool.not_true, Bool.false_eq_true, ↓reduceIte]

/--
  **`PO-DIFF-01b` (`Canonical Encoding Uniqueness` — `Corrigendum F-DIFF-P0-01`)**:
  `decodeWire C s` returns `.ok x` **if and only if** `s` is literally equal to `encodeWire C x`!
-/
theorem decodeWire_ok_iff_encodeWire_eq {α : Type} (C : CanonicalWireCodec α)
    (s : String) (x : α) :
    decodeWire C s = .ok x ↔ encodeWire C x = s := by
  constructor
  · intro hd
    unfold decodeWire at hd
    by_cases hemp : s.toList.isEmpty = true
    · rw [if_pos hemp] at hd; contradiction
    · rw [if_neg hemp] at hd
      cases hsp : splitSemiChars s.toList.length s.toList with
      | error _ => rw [hsp] at hd; contradiction
      | ok toks =>
        rw [hsp] at hd
        cases toks with
        | nil => contradiction
        | cons ver rest1 =>
          cases rest1 with
          | nil => contradiction
          | cons ttag body =>
            dsimp only at hd
            by_cases hv : (!eqStrBool ver "DIFFV1") = true
            · rw [if_pos hv] at hd; contradiction
            · rw [if_neg hv] at hd
              by_cases ht : (!eqStrBool ttag C.typeTag) = true
              · rw [if_pos ht] at hd; contradiction
              · rw [if_neg ht] at hd
                cases hp : C.parseToks body.length body with
                | error _ => rw [hp] at hd; contradiction
                | ok pair =>
                  rw [hp] at hd
                  rcases pair with ⟨val, rem⟩
                  cases rem with
                  | cons _ _ => contradiction
                  | nil =>
                    dsimp only at hd
                    by_cases hc : eqStrBool (encodeWire C val) s = true
                    · rw [if_pos hc] at hd
                      injection hd with hval
                      subst val
                      exact (eqStrBool_iff _ _).mp hc
                    · rw [if_neg hc] at hd; contradiction
  · intro heq
    rw [← heq]
    exact encodeWire_decodeWire_roundtrip C x

/-- **`PO-DIFF-02` (`Encoding Injectivity`)**: `encodeWire C x = encodeWire C y → x = y`. -/
theorem encodeWire_injective {α : Type} (C : CanonicalWireCodec α) {x y : α}
    (h : encodeWire C x = encodeWire C y) :
    x = y := by
  have h1 := encodeWire_decodeWire_roundtrip C x
  rw [h, encodeWire_decodeWire_roundtrip C y] at h1
  injection h1 with h2
  exact h2.symm

/--
  **`PO-DIFF-01c` (`Malformed / Non-Canonical Rejection` — `Corrigendum F-DIFF-P0-01`)**:
  Every string `s ∉ L_valid(C)` is deterministically rejected with an explicit `.error diag`!
-/
theorem malformed_wire_rejected {α : Type} (C : CanonicalWireCodec α) (s : String)
    (hInvalid : ¬ ValidWireEncoding C s) :
    ∃ err : DecodeRejectDiag, decodeWire C s = .error err := by
  cases hd : decodeWire C s with
  | error e => exact ⟨e, rfl⟩
  | ok x =>
    have heq : encodeWire C x = s := (decodeWire_ok_iff_encodeWire_eq C s x).mp hd
    exact False.elim (hInvalid ⟨x, heq⟩)

/-! ### 4. Canonical `Nat`, `UInt8`, `Char`, `String` & UTF-8 Byte-vs-Codepoint Primitives -/

def digitChar (d : Nat) : Char :=
  Char.ofNat (48 + d)

def parseDigitChar (c : Char) : Option Nat :=
  let n := c.toNat
  if 48 ≤ n && n ≤ 57 then some (n - 48) else none

theorem digitChar_props {d : Nat} (hd : d < 10) :
    parseDigitChar (digitChar d) = some d ∧ digitChar d ≠ ';' ∧ (0 < d → digitChar d ≠ '0') := by
  match d with
  | 0 => decide
  | 1 => decide
  | 2 => decide
  | 3 => decide
  | 4 => decide
  | 5 => decide
  | 6 => decide
  | 7 => decide
  | 8 => decide
  | 9 => decide
  | _ + 10 => omega

theorem parseDigitChar_digitChar {d : Nat} (hd : d < 10) :
    parseDigitChar (digitChar d) = some d :=
  (digitChar_props hd).1

theorem digitChar_ne_semi {d : Nat} (hd : d < 10) :
    digitChar d ≠ ';' :=
  (digitChar_props hd).2.1

def natToDecCharsAux : Nat → Nat → List Char
  | 0, n     => [digitChar (n % 10)]
  | f + 1, n =>
    if n < 10 then [digitChar n]
    else natToDecCharsAux f (n / 10) ++ [digitChar (n % 10)]

def natToDecChars (n : Nat) : List Char :=
  natToDecCharsAux n n

private theorem natToDecCharsAux_eq (f1 f2 n : Nat) (hf1 : n ≤ f1) (hf2 : n ≤ f2) :
    natToDecCharsAux f1 n = natToDecCharsAux f2 n := by
  induction f1 generalizing f2 n with
  | zero =>
    have hn0 : n = 0 := by omega
    subst hn0; cases f2 <;> rfl
  | succ k ih =>
    cases f2 with
    | zero =>
      have hn0 : n = 0 := by omega
      subst hn0; rfl
    | succ m =>
      simp only [natToDecCharsAux]
      by_cases hk : n < 10
      · simp [hk]
      · simp only [hk, ↓reduceIte]
        rw [ih m (n / 10) (by omega) (by omega)]

theorem natToDecChars_step (n : Nat) :
    natToDecChars n =
      if n < 10 then [digitChar n]
      else natToDecChars (n / 10) ++ [digitChar (n % 10)] := by
  cases n with
  | zero => decide
  | succ k =>
    unfold natToDecChars
    simp only [natToDecCharsAux]
    by_cases hk : k + 1 < 10
    · simp [hk]
    · simp only [hk, ↓reduceIte]
      rw [natToDecCharsAux_eq k ((k + 1) / 10) ((k + 1) / 10) (by omega) (by omega)]

theorem natToDecChars_nonempty (n : Nat) : natToDecChars n ≠ [] := by
  rw [natToDecChars_step]
  by_cases hk : n < 10
  · rw [if_pos hk]; simp
  · rw [if_neg hk]; intro h; simp at h

theorem natToDecChars_no_semi (n : Nat) : ';' ∉ natToDecChars n := by
  induction n using Nat.strongRecOn with
  | ind k ih =>
    rw [natToDecChars_step]
    by_cases hk : k < 10
    · rw [if_pos hk]
      intro hm
      rcases List.mem_cons.mp hm with heq | hnil
      · exact digitChar_ne_semi hk heq.symm
      · nomatch hnil
    · rw [if_neg hk]
      intro hm
      rcases List.mem_append.mp hm with hl | hr
      · exact ih (k / 10) (by omega) hl
      · rcases List.mem_cons.mp hr with heq | hnil
        · exact digitChar_ne_semi (Nat.mod_lt k (by omega)) heq.symm
        · nomatch hnil

theorem natToDecChars_head_ne_zero {n : Nat} (hpos : 0 < n) :
    ∀ rest, natToDecChars n ≠ '0' :: rest := by
  induction n using Nat.strongRecOn with
  | ind k ih =>
    intro rest
    rw [natToDecChars_step]
    by_cases hk : k < 10
    · rw [if_pos hk]
      intro heq
      injection heq with hc _
      exact (digitChar_props hk).2.2 hpos hc
    · rw [if_neg hk]
      intro heq
      cases hdiv : natToDecChars (k / 10) with
      | nil => exact natToDecChars_nonempty (k / 10) hdiv
      | cons c0 ctail =>
        rw [hdiv] at heq
        simp only [List.cons_append] at heq
        injection heq with hc0 _
        subst c0
        exact ih (k / 10) (by omega) (by omega) ctail hdiv

def decDigitsAcc (acc : Nat) : List Char → Option Nat
  | []      => some acc
  | c :: cs =>
    match parseDigitChar c with
    | none   => none
    | some d => decDigitsAcc (acc * 10 + d) cs

theorem decDigitsAcc_natToDecChars (n : Nat) (rest : List Char) :
    decDigitsAcc 0 (natToDecChars n ++ rest) = decDigitsAcc n rest := by
  induction n using Nat.strongRecOn generalizing rest with
  | ind k ih =>
    rw [natToDecChars_step]
    by_cases hk : k < 10
    · rw [if_pos hk]
      simp only [List.singleton_append, decDigitsAcc, parseDigitChar_digitChar hk,
                 Nat.zero_mul, Nat.zero_add]
    · rw [if_neg hk]
      rw [List.append_assoc, List.singleton_append]
      rw [ih (k / 10) (by omega) (digitChar (k % 10) :: rest)]
      have hmod : k % 10 < 10 := Nat.mod_lt k (by omega)
      simp only [decDigitsAcc, parseDigitChar_digitChar hmod]
      have hdivmod : k / 10 * 10 + k % 10 = k := by omega
      rw [hdivmod]

def encNatTok (n : Nat) : String :=
  String.ofList ('N' :: '#' :: natToDecChars n)

theorem encNatTok_valid (n : Nat) : ValidToken (encNatTok n) := by
  refine ⟨?_, ?_⟩
  · intro h
    have hl : (encNatTok n).toList = [] := by rw [h]; rfl
    simp [encNatTok, String.toList_ofList] at hl
  · intro hm
    simp only [encNatTok, String.toList_ofList, List.mem_cons] at hm
    rcases hm with h1 | h2 | h3
    · cases h1
    · cases h2
    · exact natToDecChars_no_semi n h3

def parseNatTok (tok : String) : Except DecodeRejectDiag Nat :=
  match tok.toList with
  | 'N' :: '#' :: c0 :: cs =>
    if c0 == '0' then
      if cs.isEmpty then .ok 0 else .error (.leadingZeroInNatToken tok)
    else
      match decDigitsAcc 0 (c0 :: cs) with
      | some n => .ok n
      | none   => .error (.malformedNatToken tok)
  | _ => .error (.malformedNatToken tok)

theorem parseNatTok_encNatTok (n : Nat) :
    parseNatTok (encNatTok n) = .ok n := by
  by_cases hz : n = 0
  · subst hz
    unfold parseNatTok encNatTok
    rw [String.toList_ofList]
    have h0 : natToDecChars 0 = ['0'] := by decide
    rw [h0]
    rfl
  · have hpos : 0 < n := by omega
    unfold parseNatTok encNatTok
    rw [String.toList_ofList]
    cases hd : natToDecChars n with
    | nil => exact False.elim (natToDecChars_nonempty n hd)
    | cons c0 cs =>
      by_cases hc0 : c0 = '0'
      · subst c0
        exact False.elim (natToDecChars_head_ne_zero hpos cs hd)
      · have hdec : decDigitsAcc 0 (c0 :: cs) = some n := by
          rw [← hd]
          simpa [decDigitsAcc] using decDigitsAcc_natToDecChars n []
        have hbeq : (c0 == '0') = false := beq_false_of_ne hc0
        simp only [hbeq, Bool.false_eq_true, ↓reduceIte, hdec]

def parseNatStep (toks : List String) : Except DecodeRejectDiag (Nat × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "Nat")
  | t :: rs =>
    match parseNatTok t with
    | .error e => .error e
    | .ok n    => .ok (n, rs)

theorem parseNatStep_enc (n : Nat) (rest : List String) :
    parseNatStep (encNatTok n :: rest) = .ok (n, rest) := by
  simp [parseNatStep, parseNatTok_encNatTok]

/-! ### 5. UTF-8 Byte-Length vs Unicode Codepoint-Length Primitives & `PO-DIFF-03` -/

/-- Exact RFC 3629 UTF-8 byte length of a single Unicode scalar `Char`. -/
def utf8ByteLenOfChar (c : Char) : Nat :=
  let n := c.toNat
  if n ≤ 0x7F then 1
  else if n ≤ 0x7FF then 2
  else if n ≤ 0xFFFF then 3
  else 4

def utf8ByteLenOfChars : List Char → Nat
  | []      => 0
  | c :: cs => utf8ByteLenOfChar c + utf8ByteLenOfChars cs

theorem char_ofNat_toNat (c : Char) : Char.ofNat c.toNat = c := by
  cases c with
  | mk val valid =>
    unfold Char.ofNat Char.toNat
    dsimp only
    split
    · congr
    · rename_i hnv; exact False.elim (hnv valid)

def isValidUnicodeScalarBool (n : Nat) : Bool :=
  (n < 0xD800) || ((0xDFFF < n) && (n ≤ 0x10FFFF))

theorem isValidUnicodeScalarBool_of_char (c : Char) :
    isValidUnicodeScalarBool c.toNat = true := by
  unfold isValidUnicodeScalarBool
  have hv : Char.isValidCharNat c.toNat := c.valid
  unfold Char.isValidCharNat at hv
  rcases hv with h1 | ⟨h2, h3⟩
  · simp [h1]
  · have h3' : c.toNat ≤ 0x10FFFF := by omega
    simp [h2, h3']

def encCharTok (c : Char) : String :=
  String.ofList ('C' :: '#' :: natToDecChars c.toNat)

theorem encCharTok_valid (c : Char) : ValidToken (encCharTok c) := by
  refine ⟨?_, ?_⟩
  · intro h
    have hl : (encCharTok c).toList = [] := by rw [h]; rfl
    simp [encCharTok, String.toList_ofList] at hl
  · intro hm
    simp only [encCharTok, String.toList_ofList, List.mem_cons] at hm
    rcases hm with h1 | h2 | h3
    · cases h1
    · cases h2
    · exact natToDecChars_no_semi c.toNat h3

def parseCharTok (tok : String) : Except DecodeRejectDiag Char :=
  match tok.toList with
  | 'C' :: '#' :: c0 :: cs =>
    if c0 == '0' then
      if cs.isEmpty then .ok (Char.ofNat 0) else .error (.leadingZeroInNatToken tok)
    else
      match decDigitsAcc 0 (c0 :: cs) with
      | none => .error (.malformedCharToken tok)
      | some n =>
        if isValidUnicodeScalarBool n then .ok (Char.ofNat n)
        else .error (.invalidUnicodeScalar n)
  | _ => .error (.malformedCharToken tok)

theorem parseCharTok_encCharTok (c : Char) :
    parseCharTok (encCharTok c) = .ok c := by
  by_cases hz : c.toNat = 0
  · unfold parseCharTok encCharTok
    rw [hz, String.toList_ofList]
    have h0 : natToDecChars 0 = ['0'] := by decide
    rw [h0]
    simp only [beq_self_eq_true, List.isEmpty_nil, ↓reduceIte, ← hz, char_ofNat_toNat]
  · have hpos : 0 < c.toNat := by omega
    unfold parseCharTok encCharTok
    rw [String.toList_ofList]
    cases hd : natToDecChars c.toNat with
    | nil => exact False.elim (natToDecChars_nonempty c.toNat hd)
    | cons c0 cs =>
      by_cases hc0 : c0 = '0'
      · subst c0
        exact False.elim (natToDecChars_head_ne_zero hpos cs hd)
      · have hdec : decDigitsAcc 0 (c0 :: cs) = some c.toNat := by
          rw [← hd]
          simpa [decDigitsAcc] using decDigitsAcc_natToDecChars c.toNat []
        have hv : isValidUnicodeScalarBool c.toNat = true := isValidUnicodeScalarBool_of_char c
        have hbeq : (c0 == '0') = false := beq_false_of_ne hc0
        simp only [hbeq, Bool.false_eq_true, ↓reduceIte, hdec, hv, char_ofNat_toNat]

def parseNChars : Nat → List String → Except DecodeRejectDiag (List Char × List String)
  | 0, toks => .ok ([], toks)
  | _ + 1, [] => .error (.unexpectedEndOfTokens "CharSeq")
  | k + 1, t :: ts =>
    match parseCharTok t with
    | .error e => .error e
    | .ok ch =>
      match parseNChars k ts with
      | .error e => .error e
      | .ok (chs, rem) => .ok (ch :: chs, rem)

theorem parseNChars_map (cs : List Char) (rest : List String) :
    parseNChars cs.length (cs.map encCharTok ++ rest) = .ok (cs, rest) := by
  induction cs with
  | nil => rfl
  | cons c tail ih =>
    simp only [List.length_cons, List.map_cons, List.cons_append, parseNChars,
               parseCharTok_encCharTok, ih]

/--
  Encodes `s : String` with EXPLICIT codepoint count AND UTF-8 byte count:
  `["STR", "N#<cpLen>", "N#<utf8ByteLen>", "C#<u_1>", ..., "C#<u_k>"]`.
-/
def encStrSeq (s : String) : List String :=
  let cs := s.toList
  "STR" :: encNatTok cs.length :: encNatTok (utf8ByteLenOfChars cs) :: cs.map encCharTok

theorem encStrSeq_valid (s : String) :
    encStrSeq s ≠ [] ∧ ∀ t ∈ encStrSeq s, ValidToken t := by
  refine ⟨by simp [encStrSeq], ?_⟩
  intro t ht
  simp only [encStrSeq] at ht
  rcases List.mem_cons.mp ht with rfl | ht1
  · exact checkValidTokenBool_sound (by decide)
  · rcases List.mem_cons.mp ht1 with rfl | ht2
    · exact encNatTok_valid _
    · rcases List.mem_cons.mp ht2 with rfl | ht3
      · exact encNatTok_valid _
      · rcases List.mem_map.mp ht3 with ⟨c, _, rfl⟩
        exact encCharTok_valid c

def parseStrStep (toks : List String) : Except DecodeRejectDiag (String × List String) :=
  match toks with
  | "STR" :: rest1 =>
    match parseNatStep rest1 with
    | .error e => .error e
    | .ok (cpLen, rest2) =>
      match parseNatStep rest2 with
      | .error e => .error e
      | .ok (byteLen, rest3) =>
        match parseNChars cpLen rest3 with
        | .error e => .error e
        | .ok (chars, rem) =>
          let actualBytes := utf8ByteLenOfChars chars
          if actualBytes == byteLen then
            .ok (String.ofList chars, rem)
          else
            .error (.stringByteVsCodepointMismatch byteLen actualBytes)
  | t :: _ => .error (.unknownConstructorTag "String" t)
  | []     => .error (.unexpectedEndOfTokens "String")

theorem parseStrStep_enc (s : String) (rest : List String) :
    parseStrStep (encStrSeq s ++ rest) = .ok (s, rest) := by
  simp only [encStrSeq, List.cons_append, parseStrStep, parseNatStep_enc,
             parseNChars_map, beq_self_eq_true, ↓reduceIte]
  rw [String.ofList_toList]

/-! ### 6. Finite Enum & `UInt8` / `Option` / `List` Combinators (Preserving Exact Constructor Names) -/

def parseTagExpect (typeName expected : String) (toks : List String) :
    Except DecodeRejectDiag (List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens typeName)
  | t :: rs =>
    if eqStrBool t expected then .ok rs
    else .error (.unknownConstructorTag typeName t)

theorem parseTagExpect_self (typeName expected : String) (rest : List String) :
    parseTagExpect typeName expected (expected :: rest) = .ok rest := by
  unfold parseTagExpect
  dsimp only
  rw [(eqStrBool_iff expected expected).mpr rfl]
  rfl

def encUInt8Seq (b : UInt8) : List String :=
  ["UInt8.ofNat", encNatTok b.toNat]

def parseUInt8Step (toks : List String) : Except DecodeRejectDiag (UInt8 × List String) := do
  let r1 ← parseTagExpect "UInt8" "UInt8.ofNat" toks
  let (n, r2) ← parseNatStep r1
  if n < 256 then
    .ok (UInt8.ofNat n, r2)
  else
    .error (.uint8OutOfRange n)

theorem parseUInt8Step_enc (b : UInt8) (rest : List String) :
    parseUInt8Step (encUInt8Seq b ++ rest) = .ok (b, rest) := by
  unfold encUInt8Seq parseUInt8Step
  simp only [List.cons_append, List.nil_append, Bind.bind, Except.bind,
             parseTagExpect_self, parseNatStep_enc]
  have hlt : b.toNat < 256 := UInt8.toNat_lt b
  rw [if_pos hlt]
  simp

def encOptStrSeq : Option String → List String
  | none   => ["Option.none"]
  | some s => "Option.some" :: encStrSeq s

def parseOptStrStep (toks : List String) : Except DecodeRejectDiag (Option String × List String) :=
  match toks with
  | "Option.none" :: rs => .ok (none, rs)
  | "Option.some" :: rs => do
    let (s, rem) ← parseStrStep rs
    .ok (some s, rem)
  | t :: _ => .error (.unknownConstructorTag "OptionString" t)
  | []     => .error (.unexpectedEndOfTokens "OptionString")

theorem parseOptStrStep_enc (o : Option String) (rest : List String) :
    parseOptStrStep (encOptStrSeq o ++ rest) = .ok (o, rest) := by
  cases o with
  | none => rfl
  | some s =>
    simp [encOptStrSeq, parseOptStrStep, Bind.bind, Except.bind, parseStrStep_enc]

def encOptPairStrSeq : Option (String × String) → List String
  | none          => ["Option.none"]
  | some (s1, s2) => "Option.some" :: (encStrSeq s1 ++ encStrSeq s2)

def parseOptPairStrStep (toks : List String) :
    Except DecodeRejectDiag (Option (String × String) × List String) :=
  match toks with
  | "Option.none" :: rs => .ok (none, rs)
  | "Option.some" :: rs => do
    let (s1, r1) ← parseStrStep rs
    let (s2, r2) ← parseStrStep r1
    .ok (some (s1, s2), r2)
  | t :: _ => .error (.unknownConstructorTag "OptionPairString" t)
  | []     => .error (.unexpectedEndOfTokens "OptionPairString")

theorem parseOptPairStrStep_enc (o : Option (String × String)) (rest : List String) :
    parseOptPairStrStep (encOptPairStrSeq o ++ rest) = .ok (o, rest) := by
  cases o with
  | none => rfl
  | some p =>
    rcases p with ⟨s1, s2⟩
    simp [encOptPairStrSeq, List.append_assoc, parseOptPairStrStep,
          Bind.bind, Except.bind, parseStrStep_enc]

/-! ### 7. Enum Name Tables (Exact Frozen Constructor Names) -/

def prodToWireName : FrozenParseProd → String
  | .Env_DocSingle          => "FrozenParseProd.Env_DocSingle"
  | .Env_ScopedInitial      => "FrozenParseProd.Env_ScopedInitial"
  | .Env_ScopedRepeat       => "FrozenParseProd.Env_ScopedRepeat"
  | .Env_ScopedAssoc        => "FrozenParseProd.Env_ScopedAssoc"
  | .Env_ScopedContrastMeta => "FrozenParseProd.Env_ScopedContrastMeta"
  | .Env_LiftAssoc          => "FrozenParseProd.Env_LiftAssoc"
  | .Env_LiftMeta           => "FrozenParseProd.Env_LiftMeta"
  | .Env_EmbeddedCausal     => "FrozenParseProd.Env_EmbeddedCausal"
  | .Gen_G01_DescIncidence  => "FrozenParseProd.Gen_G01_DescIncidence"
  | .Gen_G02a_DescMeanSD    => "FrozenParseProd.Gen_G02a_DescMeanSD"
  | .Gen_G02b_DescMedianIQR => "FrozenParseProd.Gen_G02b_DescMedianIQR"
  | .Gen_G03_AssocUnadj     => "FrozenParseProd.Gen_G03_AssocUnadj"
  | .Gen_G04_AssocTemp      => "FrozenParseProd.Gen_G04_AssocTemp"
  | .Gen_G05_CompRD         => "FrozenParseProd.Gen_G05_CompRD"
  | .Gen_G06a_IntervDirectional => "FrozenParseProd.Gen_G06a_IntervDirectional"
  | .Gen_G06b_IntervNeutral => "FrozenParseProd.Gen_G06b_IntervNeutral"
  | .Gen_G07_MetaNotStatSig => "FrozenParseProd.Gen_G07_MetaNotStatSig"
  | .Gen_G08_MetaEquiv      => "FrozenParseProd.Gen_G08_MetaEquiv"
  | .Gen_G09_MetaNonEstab   => "FrozenParseProd.Gen_G09_MetaNonEstab"
  | .Gen_G10_MetaUnresolved => "FrozenParseProd.Gen_G10_MetaUnresolved"
  | .Gen_G11_QuantZero      => "FrozenParseProd.Gen_G11_QuantZero"
  | .Gen_G12_QuantProperPart => "FrozenParseProd.Gen_G12_QuantProperPart"
  | .Gen_G13_QuantAtLeastOne => "FrozenParseProd.Gen_G13_QuantAtLeastOne"
  | .Gen_G14_AssocAdj       => "FrozenParseProd.Gen_G14_AssocAdj"
  | .Gen_G15a_DocConjAtomic => "FrozenParseProd.Gen_G15a_DocConjAtomic"
  | .Gen_G15b_DocConjDiscourse => "FrozenParseProd.Gen_G15b_DocConjDiscourse"
  | .Gen_G16_DocContrastive => "FrozenParseProd.Gen_G16_DocContrastive"
  | .Env_DocTrapScoped      => "FrozenParseProd.Env_DocTrapScoped"
  | .Env_ScopedTrap         => "FrozenParseProd.Env_ScopedTrap"
  | .Trap_T1_AllNot         => "FrozenParseProd.Trap_T1_AllNot"
  | .Trap_T2_ConfirmThat    => "FrozenParseProd.Trap_T2_ConfirmThat"
  | .Trap_T3_WhPresup       => "FrozenParseProd.Trap_T3_WhPresup"
  | .Trap_T4_BarePlural     => "FrozenParseProd.Trap_T4_BarePlural"
  | .Trap_T5_UnscopedDoc    => "FrozenParseProd.Trap_T5_UnscopedDoc"

def prodFromWireName (s : String) : Option FrozenParseProd :=
  allFrozenParseProds.find? (fun p => eqStrBool (prodToWireName p) s)

theorem prodToWireName_valid (p : FrozenParseProd) : ValidToken (prodToWireName p) := by
  apply checkValidTokenBool_sound
  cases p <;> decide

theorem prodFromWireName_toWireName (p : FrozenParseProd) :
    prodFromWireName (prodToWireName p) = some p := by
  cases p <;> decide

def parseProdStep (toks : List String) : Except DecodeRejectDiag (FrozenParseProd × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "FrozenParseProd")
  | t :: rs =>
    match prodFromWireName t with
    | some p => .ok (p, rs)
    | none   => .error (.unknownConstructorTag "FrozenParseProd" t)

theorem parseProdStep_enc (p : FrozenParseProd) (rest : List String) :
    parseProdStep (prodToWireName p :: rest) = .ok (p, rest) := by
  simp [parseProdStep, prodFromWireName_toWireName]

def allSlotSorts : List P3SlotSort :=
  [ .cohortSpec, .designNoun, .followUpWindow, .eventTerm, .measureTerm,
    .expLevel, .outTerm, .sourceId, .identAssump, .subgroupPlural,
    .subgroupSingular, .covariateList, .assocDir, .ratioMetric, .intervDirVerb,
    .intervVerbPres, .epistemicVerb, .whWord, .numericLit ]

def slotSortToWireName : P3SlotSort → String
  | .cohortSpec       => "P3SlotSort.cohortSpec"
  | .designNoun       => "P3SlotSort.designNoun"
  | .followUpWindow   => "P3SlotSort.followUpWindow"
  | .eventTerm        => "P3SlotSort.eventTerm"
  | .measureTerm      => "P3SlotSort.measureTerm"
  | .expLevel         => "P3SlotSort.expLevel"
  | .outTerm          => "P3SlotSort.outTerm"
  | .sourceId         => "P3SlotSort.sourceId"
  | .identAssump      => "P3SlotSort.identAssump"
  | .subgroupPlural   => "P3SlotSort.subgroupPlural"
  | .subgroupSingular => "P3SlotSort.subgroupSingular"
  | .covariateList    => "P3SlotSort.covariateList"
  | .assocDir         => "P3SlotSort.assocDir"
  | .ratioMetric      => "P3SlotSort.ratioMetric"
  | .intervDirVerb    => "P3SlotSort.intervDirVerb"
  | .intervVerbPres   => "P3SlotSort.intervVerbPres"
  | .epistemicVerb    => "P3SlotSort.epistemicVerb"
  | .whWord           => "P3SlotSort.whWord"
  | .numericLit       => "P3SlotSort.numericLit"

def slotSortFromWireName (s : String) : Option P3SlotSort :=
  allSlotSorts.find? (fun x => eqStrBool (slotSortToWireName x) s)

theorem slotSortToWireName_valid (x : P3SlotSort) : ValidToken (slotSortToWireName x) := by
  apply checkValidTokenBool_sound; cases x <;> decide

theorem slotSortFromWireName_toWireName (x : P3SlotSort) :
    slotSortFromWireName (slotSortToWireName x) = some x := by
  cases x <;> decide

def parseSlotSortStep (toks : List String) : Except DecodeRejectDiag (P3SlotSort × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "P3SlotSort")
  | t :: rs =>
    match slotSortFromWireName t with
    | some x => .ok (x, rs)
    | none   => .error (.unknownConstructorTag "P3SlotSort" t)

theorem parseSlotSortStep_enc (x : P3SlotSort) (rest : List String) :
    parseSlotSortStep (slotSortToWireName x :: rest) = .ok (x, rest) := by
  simp [parseSlotSortStep, slotSortFromWireName_toWireName]

def allBNFSlotTags : List BNFSlotTag :=
  [ .cohort, .design, .window, .eventA, .eventB, .measure, .activeExp, .refExp,
    .outcome, .source, .assumption, .subgroup, .covariates, .direction,
    .metric1, .metric2, .verb, .whComp, .numK, .numN, .numPct, .numEst,
    .numDisp1, .numDisp2, .numCILevel, .numCILow, .numCIHigh, .numPVal,
    .numAlpha, .numMarginLow, .numMarginHigh ]

def slotTagToWireName : BNFSlotTag → String
  | .cohort        => "BNFSlotTag.cohort"
  | .design        => "BNFSlotTag.design"
  | .window        => "BNFSlotTag.window"
  | .eventA        => "BNFSlotTag.eventA"
  | .eventB        => "BNFSlotTag.eventB"
  | .measure       => "BNFSlotTag.measure"
  | .activeExp     => "BNFSlotTag.activeExp"
  | .refExp        => "BNFSlotTag.refExp"
  | .outcome       => "BNFSlotTag.outcome"
  | .source        => "BNFSlotTag.source"
  | .assumption    => "BNFSlotTag.assumption"
  | .subgroup      => "BNFSlotTag.subgroup"
  | .covariates    => "BNFSlotTag.covariates"
  | .direction     => "BNFSlotTag.direction"
  | .metric1       => "BNFSlotTag.metric1"
  | .metric2       => "BNFSlotTag.metric2"
  | .verb          => "BNFSlotTag.verb"
  | .whComp        => "BNFSlotTag.whComp"
  | .numK          => "BNFSlotTag.numK"
  | .numN          => "BNFSlotTag.numN"
  | .numPct        => "BNFSlotTag.numPct"
  | .numEst        => "BNFSlotTag.numEst"
  | .numDisp1      => "BNFSlotTag.numDisp1"
  | .numDisp2      => "BNFSlotTag.numDisp2"
  | .numCILevel    => "BNFSlotTag.numCILevel"
  | .numCILow      => "BNFSlotTag.numCILow"
  | .numCIHigh     => "BNFSlotTag.numCIHigh"
  | .numPVal       => "BNFSlotTag.numPVal"
  | .numAlpha      => "BNFSlotTag.numAlpha"
  | .numMarginLow  => "BNFSlotTag.numMarginLow"
  | .numMarginHigh => "BNFSlotTag.numMarginHigh"

def slotTagFromWireName (s : String) : Option BNFSlotTag :=
  allBNFSlotTags.find? (fun x => eqStrBool (slotTagToWireName x) s)

theorem slotTagToWireName_valid (x : BNFSlotTag) : ValidToken (slotTagToWireName x) := by
  apply checkValidTokenBool_sound; cases x <;> decide

theorem slotTagFromWireName_toWireName (x : BNFSlotTag) :
    slotTagFromWireName (slotTagToWireName x) = some x := by
  cases x <;> decide

def parseSlotTagStep (toks : List String) : Except DecodeRejectDiag (BNFSlotTag × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "BNFSlotTag")
  | t :: rs =>
    match slotTagFromWireName t with
    | some x => .ok (x, rs)
    | none   => .error (.unknownConstructorTag "BNFSlotTag" t)

theorem parseSlotTagStep_enc (x : BNFSlotTag) (rest : List String) :
    parseSlotTagStep (slotTagToWireName x :: rest) = .ok (x, rest) := by
  simp [parseSlotTagStep, slotTagFromWireName_toWireName]

def locusToWireName : ClauseLocus → String
  | .clause1 => "ClauseLocus.clause1"
  | .clause2 => "ClauseLocus.clause2"

theorem locusToWireName_valid (l : ClauseLocus) : ValidToken (locusToWireName l) := by
  apply checkValidTokenBool_sound; cases l <;> decide

def parseLocusStep (toks : List String) : Except DecodeRejectDiag (ClauseLocus × List String) :=
  match toks with
  | "ClauseLocus.clause1" :: rs => .ok (.clause1, rs)
  | "ClauseLocus.clause2" :: rs => .ok (.clause2, rs)
  | t :: _ => .error (.unknownConstructorTag "ClauseLocus" t)
  | []     => .error (.unexpectedEndOfTokens "ClauseLocus")

theorem parseLocusStep_enc (l : ClauseLocus) (rest : List String) :
    parseLocusStep (locusToWireName l :: rest) = .ok (l, rest) := by
  cases l <;> rfl

def allRuleIds : List CanonicalRuleId :=
  [ .G01, .G02, .G03, .G04, .G05, .G06, .G07, .G08,
    .G09, .G10, .G11, .G12, .G13, .G14, .G15, .G16,
    .T1, .T2, .T3, .T4, .T5 ]

def ruleIdToWireName : CanonicalRuleId → String
  | .G01 => "CanonicalRuleId.G01" | .G02 => "CanonicalRuleId.G02"
  | .G03 => "CanonicalRuleId.G03" | .G04 => "CanonicalRuleId.G04"
  | .G05 => "CanonicalRuleId.G05" | .G06 => "CanonicalRuleId.G06"
  | .G07 => "CanonicalRuleId.G07" | .G08 => "CanonicalRuleId.G08"
  | .G09 => "CanonicalRuleId.G09" | .G10 => "CanonicalRuleId.G10"
  | .G11 => "CanonicalRuleId.G11" | .G12 => "CanonicalRuleId.G12"
  | .G13 => "CanonicalRuleId.G13" | .G14 => "CanonicalRuleId.G14"
  | .G15 => "CanonicalRuleId.G15" | .G16 => "CanonicalRuleId.G16"
  | .T1  => "CanonicalRuleId.T1"  | .T2  => "CanonicalRuleId.T2"
  | .T3  => "CanonicalRuleId.T3"  | .T4  => "CanonicalRuleId.T4"
  | .T5  => "CanonicalRuleId.T5"

def ruleIdFromWireName (s : String) : Option CanonicalRuleId :=
  allRuleIds.find? (fun r => eqStrBool (ruleIdToWireName r) s)

theorem ruleIdToWireName_valid (r : CanonicalRuleId) : ValidToken (ruleIdToWireName r) := by
  apply checkValidTokenBool_sound; cases r <;> decide

theorem ruleIdFromWireName_toWireName (r : CanonicalRuleId) :
    ruleIdFromWireName (ruleIdToWireName r) = some r := by
  cases r <;> decide

def parseRuleIdStep (toks : List String) : Except DecodeRejectDiag (CanonicalRuleId × List String) :=
  match toks with
  | [] => .error (.unexpectedEndOfTokens "CanonicalRuleId")
  | t :: rs =>
    match ruleIdFromWireName t with
    | some r => .ok (r, rs)
    | none   => .error (.unknownConstructorTag "CanonicalRuleId" t)

theorem parseRuleIdStep_enc (r : CanonicalRuleId) (rest : List String) :
    parseRuleIdStep (ruleIdToWireName r :: rest) = .ok (r, rest) := by
  simp [parseRuleIdStep, ruleIdFromWireName_toWireName]

/-! ### 8. `CodepointSpan` & `ConcreteParseTree` / `List ConcreteParseTree` Codecs -/

def encSpanSeq (sp : CodepointSpan) : List String :=
  ["CodepointSpan.mk", encNatTok sp.startCp, encNatTok sp.endCp]

theorem encSpanSeq_valid (sp : CodepointSpan) :
    encSpanSeq sp ≠ [] ∧ ∀ t ∈ encSpanSeq sp, ValidToken t := by
  refine ⟨by simp [encSpanSeq], ?_⟩
  intro t ht
  simp only [encSpanSeq] at ht
  rcases List.mem_cons.mp ht with rfl | h1
  · exact checkValidTokenBool_sound (by decide)
  · rcases List.mem_cons.mp h1 with rfl | h2
    · exact encNatTok_valid _
    · rcases List.mem_cons.mp h2 with rfl | h3
      · exact encNatTok_valid _
      · nomatch h3

def parseSpanStep (toks : List String) : Except DecodeRejectDiag (CodepointSpan × List String) := do
  let r1 ← parseTagExpect "CodepointSpan" "CodepointSpan.mk" toks
  let (s, r2) ← parseNatStep r1
  let (e, r3) ← parseNatStep r2
  .ok (⟨s, e⟩, r3)

theorem parseSpanStep_enc (sp : CodepointSpan) (rest : List String) :
    parseSpanStep (encSpanSeq sp ++ rest) = .ok (sp, rest) := by
  cases sp with
  | mk s e =>
    simp [encSpanSeq, parseSpanStep, Bind.bind, Except.bind, parseTagExpect_self, parseNatStep_enc]

def spanWireCodec : CanonicalWireCodec CodepointSpan where
  typeTag      := "CodepointSpan"
  encToks      := encSpanSeq
  parseToks    := fun _ toks => parseSpanStep toks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := encSpanSeq_valid
  hParsePrefix := fun x rest _ _ => parseSpanStep_enc x rest

mutual
  def encParseArgSeq : ConcreteParseArg → List String
    | .litTok txt sp =>
      "ConcreteParseArg.litTok" :: (encStrSeq txt ++ encSpanSeq sp)
    | .slotTok s tg eid lex sp =>
      "ConcreteParseArg.slotTok" :: slotSortToWireName s :: slotTagToWireName tg ::
        (encStrSeq eid ++ encStrSeq lex ++ encSpanSeq sp)
    | .childSub sub =>
      "ConcreteParseArg.childSub" :: encParseTreeSeq sub

  def encParseArgListSeq : List ConcreteParseArg → List String
    | []      => ["ArgList.nil"]
    | a :: as => "ArgList.cons" :: (encParseArgSeq a ++ encParseArgListSeq as)

  def encParseTreeSeq : ConcreteParseTree → List String
    | .mkTree prod alt loc sp args =>
      "ConcreteParseTree.mkTree" :: prodToWireName prod :: encNatTok alt ::
        locusToWireName loc :: (encSpanSeq sp ++ encParseArgListSeq args)
end

private theorem valid_list_append {xs ys : List String}
    (hx : ∀ t ∈ xs, ValidToken t) (hy : ∀ t ∈ ys, ValidToken t) :
    ∀ t ∈ xs ++ ys, ValidToken t := by
  intro t ht
  rcases List.mem_append.mp ht with h1 | h2
  · exact hx t h1
  · exact hy t h2

mutual
  theorem encParseArgSeq_valid (a : ConcreteParseArg) :
      1 ≤ (encParseArgSeq a).length ∧ ∀ t ∈ encParseArgSeq a, ValidToken t := by
    cases a with
    | litTok txt sp =>
      refine ⟨by simp [encParseArgSeq], ?_⟩
      intro t ht; simp only [encParseArgSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append (encStrSeq_valid txt).2 (encSpanSeq_valid sp).2 t hm
    | slotTok s tg eid lex sp =>
      refine ⟨by simp [encParseArgSeq], ?_⟩
      intro t ht; simp only [encParseArgSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp hm1 with rfl | hm2
        · exact slotSortToWireName_valid s
        · rcases List.mem_cons.mp hm2 with rfl | hm3
          · exact slotTagToWireName_valid tg
          · exact valid_list_append
              (valid_list_append (encStrSeq_valid eid).2 (encStrSeq_valid lex).2)
              (encSpanSeq_valid sp).2 t hm3
    | childSub sub =>
      have ⟨_, hv⟩ := encParseTreeSeq_valid sub
      refine ⟨by simp [encParseArgSeq], ?_⟩
      intro t ht; simp only [encParseArgSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact hv t hm

  theorem encParseArgListSeq_valid (args : List ConcreteParseArg) :
      1 ≤ (encParseArgListSeq args).length ∧ ∀ t ∈ encParseArgListSeq args, ValidToken t := by
    cases args with
    | nil =>
      refine ⟨by simp [encParseArgListSeq], ?_⟩
      intro t ht; simp only [encParseArgListSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hnil
      · exact checkValidTokenBool_sound (by decide)
      · nomatch hnil
    | cons a as =>
      have ⟨_, hva⟩ := encParseArgSeq_valid a
      have ⟨_, hvas⟩ := encParseArgListSeq_valid as
      refine ⟨by simp [encParseArgListSeq], ?_⟩
      intro t ht; simp only [encParseArgListSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append hva hvas t hm

  theorem encParseTreeSeq_valid (tr : ConcreteParseTree) :
      1 ≤ (encParseTreeSeq tr).length ∧ ∀ t ∈ encParseTreeSeq tr, ValidToken t := by
    cases tr with
    | mkTree prod alt loc sp args =>
      have ⟨_, hvas⟩ := encParseArgListSeq_valid args
      refine ⟨by simp [encParseTreeSeq], ?_⟩
      intro t ht; simp only [encParseTreeSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp hm1 with rfl | hm2
        · exact prodToWireName_valid prod
        · rcases List.mem_cons.mp hm2 with rfl | hm3
          · exact encNatTok_valid alt
          · rcases List.mem_cons.mp hm3 with rfl | hm4
            · exact locusToWireName_valid loc
            · exact valid_list_append (encSpanSeq_valid sp).2 hvas t hm4
end

def parseParseTreeToks : Nat → List String → Except DecodeRejectDiag (ConcreteParseTree × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, toks => do
    let r1 ← parseTagExpect "ConcreteParseTree" "ConcreteParseTree.mkTree" toks
    let (prod, r2) ← parseProdStep r1
    let (alt, r3) ← parseNatStep r2
    let (loc, r4) ← parseLocusStep r3
    let (sp, r5) ← parseSpanStep r4
    let (args, r6) ← parseParseArgListToks f r5
    .ok (.mkTree prod alt loc sp args, r6)
where
  parseParseArgToks : Nat → List String → Except DecodeRejectDiag (ConcreteParseArg × List String)
    | 0, _ => .error .recursionFuelExhausted
    | _ + 1, "ConcreteParseArg.litTok" :: rs => do
      let (txt, r1) ← parseStrStep rs
      let (sp, r2) ← parseSpanStep r1
      .ok (.litTok txt sp, r2)
    | _ + 1, "ConcreteParseArg.slotTok" :: rs => do
      let (s, r1) ← parseSlotSortStep rs
      let (tg, r2) ← parseSlotTagStep r1
      let (eid, r3) ← parseStrStep r2
      let (lex, r4) ← parseStrStep r3
      let (sp, r5) ← parseSpanStep r4
      .ok (.slotTok s tg eid lex sp, r5)
    | f + 1, "ConcreteParseArg.childSub" :: rs => do
      let (sub, r1) ← parseParseTreeToks f rs
      .ok (.childSub sub, r1)
    | _ + 1, t :: _ => .error (.unknownConstructorTag "ConcreteParseArg" t)
    | _ + 1, []     => .error (.unexpectedEndOfTokens "ConcreteParseArg")

  parseParseArgListToks : Nat → List String → Except DecodeRejectDiag (List ConcreteParseArg × List String)
    | 0, _ => .error .recursionFuelExhausted
    | _ + 1, "ArgList.nil" :: rs => .ok ([], rs)
    | f + 1, "ArgList.cons" :: rs => do
      let (a, r1) ← parseParseArgToks f rs
      let (as, r2) ← parseParseArgListToks f r1
      .ok (a :: as, r2)
    | _ + 1, t :: _ => .error (.unknownConstructorTag "ArgList" t)
    | _ + 1, []     => .error (.unexpectedEndOfTokens "ArgList")

mutual
  theorem parseParseArgToks_enc (a : ConcreteParseArg) (rest : List String) (fuel : Nat)
      (hf : (encParseArgSeq a).length ≤ fuel) :
      parseParseTreeToks.parseParseArgToks fuel (encParseArgSeq a ++ rest) = .ok (a, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encParseArgSeq_valid a
      omega
    | succ f =>
      cases a with
      | litTok txt sp =>
        simp [encParseArgSeq, List.append_assoc, parseParseTreeToks.parseParseArgToks,
              Bind.bind, Except.bind, parseStrStep_enc, parseSpanStep_enc]
      | slotTok s tg eid lex sp =>
        simp [encParseArgSeq, List.append_assoc, parseParseTreeToks.parseParseArgToks,
              Bind.bind, Except.bind, parseSlotSortStep_enc, parseSlotTagStep_enc,
              parseStrStep_enc, parseSpanStep_enc]
      | childSub sub =>
        have hsub_f : (encParseTreeSeq sub).length ≤ f := by
          simp [encParseArgSeq] at hf; omega
        simp [encParseArgSeq, parseParseTreeToks.parseParseArgToks,
              Bind.bind, Except.bind, parseParseTreeToks_enc sub rest f hsub_f]

  theorem parseParseArgListToks_enc (args : List ConcreteParseArg) (rest : List String) (fuel : Nat)
      (hf : (encParseArgListSeq args).length ≤ fuel) :
      parseParseTreeToks.parseParseArgListToks fuel (encParseArgListSeq args ++ rest) = .ok (args, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encParseArgListSeq_valid args
      omega
    | succ f =>
      cases args with
      | nil => rfl
      | cons a as =>
        have ha_f : (encParseArgSeq a).length ≤ f := by
          simp [encParseArgListSeq] at hf; omega
        have has_f : (encParseArgListSeq as).length ≤ f := by
          simp [encParseArgListSeq] at hf; omega
        simp only [encParseArgListSeq, List.cons_append, List.append_assoc,
                   parseParseTreeToks.parseParseArgListToks, Bind.bind, Except.bind]
        rw [parseParseArgToks_enc a (encParseArgListSeq as ++ rest) f ha_f]
        dsimp only
        rw [parseParseArgListToks_enc as rest f has_f]

  theorem parseParseTreeToks_enc (tr : ConcreteParseTree) (rest : List String) (fuel : Nat)
      (hf : (encParseTreeSeq tr).length ≤ fuel) :
      parseParseTreeToks fuel (encParseTreeSeq tr ++ rest) = .ok (tr, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encParseTreeSeq_valid tr
      omega
    | succ f =>
      cases tr with
      | mkTree prod alt loc sp args =>
        have hargs_f : (encParseArgListSeq args).length ≤ f := by
          simp [encParseTreeSeq] at hf; omega
        simp only [encParseTreeSeq, List.cons_append, List.append_assoc,
                   parseParseTreeToks, Bind.bind, Except.bind,
                   parseTagExpect_self, parseProdStep_enc, parseNatStep_enc,
                   parseLocusStep_enc, parseSpanStep_enc]
        rw [parseParseArgListToks_enc args rest f hargs_f]
end

def parseTreeWireCodec : CanonicalWireCodec ConcreteParseTree where
  typeTag      := "ConcreteParseTree"
  encToks      := encParseTreeSeq
  parseToks    := parseParseTreeToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun t =>
    let ⟨h1, hv⟩ := encParseTreeSeq_valid t
    ⟨by intro he; rw [he] at h1; simp at h1, hv⟩
  hParsePrefix := parseParseTreeToks_enc

def encForestSeq : List ConcreteParseTree → List String
  | []      => ["Forest.nil"]
  | t :: ts => "Forest.cons" :: (encParseTreeSeq t ++ encForestSeq ts)

theorem encForestSeq_valid (T : List ConcreteParseTree) :
    1 ≤ (encForestSeq T).length ∧ ∀ tok ∈ encForestSeq T, ValidToken tok := by
  induction T with
  | nil =>
    refine ⟨by simp [encForestSeq], ?_⟩
    intro tok h; simp [encForestSeq] at h; subst h; exact checkValidTokenBool_sound (by decide)
  | cons t ts ih =>
    refine ⟨by simp [encForestSeq], ?_⟩
    intro tok h; simp only [encForestSeq] at h
    rcases List.mem_cons.mp h with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encParseTreeSeq_valid t).2 ih.2 tok hm

def parseForestToks : Nat → List String → Except DecodeRejectDiag (List ConcreteParseTree × List String)
  | 0, _ => .error .recursionFuelExhausted
  | _ + 1, "Forest.nil" :: rs => .ok ([], rs)
  | f + 1, "Forest.cons" :: rs => do
    let (t, r1) ← parseParseTreeToks f rs
    let (ts, r2) ← parseForestToks f r1
    .ok (t :: ts, r2)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "Forest" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "Forest")

theorem parseForestToks_enc (T : List ConcreteParseTree) (rest : List String) (fuel : Nat)
    (hf : (encForestSeq T).length ≤ fuel) :
    parseForestToks fuel (encForestSeq T ++ rest) = .ok (T, rest) := by
  induction T generalizing fuel rest with
  | nil =>
    cases fuel with
    | zero => simp [encForestSeq] at hf
    | succ _ => rfl
  | cons t ts ih =>
    cases fuel with
    | zero => simp [encForestSeq] at hf
    | succ f =>
      have ht_f : (encParseTreeSeq t).length ≤ f := by simp [encForestSeq] at hf; omega
      have hts_f : (encForestSeq ts).length ≤ f := by simp [encForestSeq] at hf; omega
      simp only [encForestSeq, List.cons_append, List.append_assoc, parseForestToks,
                 Bind.bind, Except.bind]
      rw [parseParseTreeToks_enc t (encForestSeq ts ++ rest) f ht_f]
      dsimp only
      rw [ih rest f hts_f]

def parseForestWireCodec : CanonicalWireCodec (List ConcreteParseTree) where
  typeTag      := "ParseForest"
  encToks      := encForestSeq
  parseToks    := parseForestToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun T =>
    let ⟨h1, hv⟩ := encForestSeq_valid T
    ⟨by intro he; rw [he] at h1; simp at h1, hv⟩
  hParsePrefix := parseForestToks_enc

/-! ### 9. `RawSemanticTerm` & `CanonicalMeaning` Codecs (`PO-DIFF-04`, `PO-DIFF-05`) -/

def encScopeSeq : SemanticScope → List String
  | .cohortBound cid => "SemanticScope.cohortBound" :: encStrSeq cid
  | .unrestrictedPop => ["SemanticScope.unrestrictedPop"]

theorem encScopeSeq_valid (sc : SemanticScope) :
    1 ≤ (encScopeSeq sc).length ∧ ∀ t ∈ encScopeSeq sc, ValidToken t := by
  cases sc with
  | cohortBound cid =>
    refine ⟨by simp [encScopeSeq], ?_⟩
    intro t ht; simp only [encScopeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encStrSeq_valid cid).2 t hm
  | unrestrictedPop =>
    refine ⟨by simp [encScopeSeq], ?_⟩
    intro t ht; simp [encScopeSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)

def parseScopeStep (toks : List String) : Except DecodeRejectDiag (SemanticScope × List String) :=
  match toks with
  | "SemanticScope.cohortBound" :: rs => do
    let (cid, rem) ← parseStrStep rs
    .ok (.cohortBound cid, rem)
  | "SemanticScope.unrestrictedPop" :: rs => .ok (.unrestrictedPop, rs)
  | t :: _ => .error (.unknownConstructorTag "SemanticScope" t)
  | []     => .error (.unexpectedEndOfTokens "SemanticScope")

theorem parseScopeStep_enc (sc : SemanticScope) (rest : List String) :
    parseScopeStep (encScopeSeq sc ++ rest) = .ok (sc, rest) := by
  cases sc with
  | cohortBound cid => simp [encScopeSeq, parseScopeStep, Bind.bind, Except.bind, parseStrStep_enc]
  | unrestrictedPop => rfl

def encDistKind : DistStatKind → String
  | .meanSD    => "DistStatKind.meanSD"
  | .medianIQR => "DistStatKind.medianIQR"

theorem encDistKind_valid (k : DistStatKind) : ValidToken (encDistKind k) := by
  apply checkValidTokenBool_sound; cases k <;> decide

def parseDistKindStep (toks : List String) : Except DecodeRejectDiag (DistStatKind × List String) :=
  match toks with
  | "DistStatKind.meanSD" :: rs    => .ok (.meanSD, rs)
  | "DistStatKind.medianIQR" :: rs => .ok (.medianIQR, rs)
  | t :: _ => .error (.unknownConstructorTag "DistStatKind" t)
  | []     => .error (.unexpectedEndOfTokens "DistStatKind")

theorem parseDistKindStep_enc (k : DistStatKind) (rest : List String) :
    parseDistKindStep (encDistKind k :: rest) = .ok (k, rest) := by
  cases k <;> rfl

def encIntervModSeq : IntervModality → List String
  | .directional vb      => "IntervModality.directional" :: encStrSeq vb
  | .neutralNullIncluded => ["IntervModality.neutralNullIncluded"]

theorem encIntervModSeq_valid (m : IntervModality) :
    1 ≤ (encIntervModSeq m).length ∧ ∀ t ∈ encIntervModSeq m, ValidToken t := by
  cases m with
  | directional vb =>
    refine ⟨by simp [encIntervModSeq], ?_⟩
    intro t ht; simp only [encIntervModSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encStrSeq_valid vb).2 t hm
  | neutralNullIncluded =>
    refine ⟨by simp [encIntervModSeq], ?_⟩
    intro t ht; simp [encIntervModSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)

def parseIntervModStep (toks : List String) : Except DecodeRejectDiag (IntervModality × List String) :=
  match toks with
  | "IntervModality.directional" :: rs => do
    let (vb, rem) ← parseStrStep rs
    .ok (.directional vb, rem)
  | "IntervModality.neutralNullIncluded" :: rs => .ok (.neutralNullIncluded, rs)
  | t :: _ => .error (.unknownConstructorTag "IntervModality" t)
  | []     => .error (.unexpectedEndOfTokens "IntervModality")

theorem parseIntervModStep_enc (m : IntervModality) (rest : List String) :
    parseIntervModStep (encIntervModSeq m ++ rest) = .ok (m, rest) := by
  cases m with
  | directional vb => simp [encIntervModSeq, parseIntervModStep, Bind.bind, Except.bind, parseStrStep_enc]
  | neutralNullIncluded => rfl

def encQuantFormSeq : QuantPredForm → List String
  | .universalNeg sg ev        => "QuantPredForm.universalNeg" :: (encStrSeq sg ++ encStrSeq ev)
  | .negExistential sg ev      => "QuantPredForm.negExistential" :: (encStrSeq sg ++ encStrSeq ev)
  | .negUniversal sg ev        => "QuantPredForm.negUniversal" :: (encStrSeq sg ++ encStrSeq ev)
  | .properPart sg ev          => "QuantPredForm.properPart" :: (encStrSeq sg ++ encStrSeq ev)
  | .existentialPos sg ev      => "QuantPredForm.existentialPos" :: (encStrSeq sg ++ encStrSeq ev)
  | .genericUniversalPos sg ev => "QuantPredForm.genericUniversalPos" :: (encStrSeq sg ++ encStrSeq ev)

theorem encQuantFormSeq_valid (q : QuantPredForm) :
    1 ≤ (encQuantFormSeq q).length ∧ ∀ t ∈ encQuantFormSeq q, ValidToken t := by
  cases q <;> (
    refine ⟨by simp [encQuantFormSeq], ?_⟩
    intro t ht; simp only [encQuantFormSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encStrSeq_valid _).2 (encStrSeq_valid _).2 t hm)

def parseQuantFormStep (toks : List String) : Except DecodeRejectDiag (QuantPredForm × List String) :=
  match toks with
  | "QuantPredForm.universalNeg" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.universalNeg sg ev, r2)
  | "QuantPredForm.negExistential" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.negExistential sg ev, r2)
  | "QuantPredForm.negUniversal" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.negUniversal sg ev, r2)
  | "QuantPredForm.properPart" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.properPart sg ev, r2)
  | "QuantPredForm.existentialPos" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.existentialPos sg ev, r2)
  | "QuantPredForm.genericUniversalPos" :: rs => do
    let (sg, r1) ← parseStrStep rs; let (ev, r2) ← parseStrStep r1; .ok (.genericUniversalPos sg ev, r2)
  | t :: _ => .error (.unknownConstructorTag "QuantPredForm" t)
  | []     => .error (.unexpectedEndOfTokens "QuantPredForm")

theorem parseQuantFormStep_enc (q : QuantPredForm) (rest : List String) :
    parseQuantFormStep (encQuantFormSeq q ++ rest) = .ok (q, rest) := by
  cases q <;> simp [encQuantFormSeq, List.append_assoc, parseQuantFormStep,
                    Bind.bind, Except.bind, parseStrStep_enc]

def encPresupSeq : PresupItem → List String
  | .factiveCausal act vb out =>
    "PresupItem.factiveCausal" :: (encStrSeq act ++ encStrSeq vb ++ encStrSeq out)

def encPresupListSeq : List PresupItem → List String
  | []      => ["PresupList.nil"]
  | p :: ps => "PresupList.cons" :: (encPresupSeq p ++ encPresupListSeq ps)

theorem encPresupListSeq_valid (ps : List PresupItem) :
    1 ≤ (encPresupListSeq ps).length ∧ ∀ t ∈ encPresupListSeq ps, ValidToken t := by
  induction ps with
  | nil =>
    refine ⟨by simp [encPresupListSeq], ?_⟩
    intro t ht; simp [encPresupListSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | cons p rest ih =>
    cases p with
    | factiveCausal act vb out =>
      refine ⟨by simp [encPresupListSeq], ?_⟩
      intro t ht; simp only [encPresupListSeq, encPresupSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp hm1 with rfl | hm2
        · exact checkValidTokenBool_sound (by decide)
        · exact valid_list_append
            (valid_list_append (valid_list_append (encStrSeq_valid act).2 (encStrSeq_valid vb).2)
                               (encStrSeq_valid out).2)
            ih.2 t hm2

def parsePresupListToks : Nat → List String → Except DecodeRejectDiag (List PresupItem × List String)
  | 0, _ => .error .recursionFuelExhausted
  | _ + 1, "PresupList.nil" :: rs => .ok ([], rs)
  | f + 1, "PresupList.cons" :: "PresupItem.factiveCausal" :: rs => do
    let (act, r1) ← parseStrStep rs
    let (vb, r2) ← parseStrStep r1
    let (out, r3) ← parseStrStep r2
    let (ps, r4) ← parsePresupListToks f r3
    .ok (.factiveCausal act vb out :: ps, r4)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "PresupList" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "PresupList")

theorem parsePresupListToks_enc (ps : List PresupItem) (rest : List String) (fuel : Nat)
    (hf : (encPresupListSeq ps).length ≤ fuel) :
    parsePresupListToks fuel (encPresupListSeq ps ++ rest) = .ok (ps, rest) := by
  induction ps generalizing fuel rest with
  | nil =>
    cases fuel with
    | zero => simp [encPresupListSeq] at hf
    | succ _ => rfl
  | cons p tail ih =>
    cases fuel with
    | zero => simp [encPresupListSeq] at hf
    | succ f =>
      cases p with
      | factiveCausal act vb out =>
        have htf : (encPresupListSeq tail).length ≤ f := by simp [encPresupListSeq] at hf; omega
        simp only [encPresupListSeq, encPresupSeq, List.cons_append, List.append_assoc,
                   parsePresupListToks, Bind.bind, Except.bind, parseStrStep_enc]
        rw [ih rest f htf]

def encAtomicClaimSeq : AtomicClaim → List String
  | .descIncidence w e k n p =>
    "AtomicClaim.descIncidence" :: (encStrSeq w ++ encStrSeq e ++ encStrSeq k ++ encStrSeq n ++ encStrSeq p)
  | .descDist k m est d1 d2o =>
    "AtomicClaim.descDist" :: encDistKind k :: (encStrSeq m ++ encStrSeq est ++ encStrSeq d1 ++ encOptStrSeq d2o)
  | .assocClaim met dir act ref out covO tmpO est ciL ciLo ciHi =>
    "AtomicClaim.assocClaim" ::
      (encStrSeq met ++ encStrSeq dir ++ encStrSeq act ++ encStrSeq ref ++ encStrSeq out ++
       encOptStrSeq covO ++ encOptPairStrSeq tmpO ++
       encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi)
  | .compRD act ref out est ciL ciLo ciHi =>
    "AtomicClaim.compRD" ::
      (encStrSeq act ++ encStrSeq ref ++ encStrSeq out ++ encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi)
  | .intervClaim mod assump met act ref out est ciL ciLo ciHi pvO =>
    "AtomicClaim.intervClaim" ::
      (encIntervModSeq mod ++ encStrSeq assump ++ encStrSeq met ++ encStrSeq act ++ encStrSeq ref ++
       encStrSeq out ++ encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi ++ encOptStrSeq pvO)
  | .metaNotStatSig met act ref out est ciL ciLo ciHi al =>
    "AtomicClaim.metaNotStatSig" ::
      (encStrSeq met ++ encStrSeq act ++ encStrSeq ref ++ encStrSeq out ++
       encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi ++ encStrSeq al)
  | .metaEquiv met act ref out mLo mHi est ciL ciLo ciHi =>
    "AtomicClaim.metaEquiv" ::
      (encStrSeq met ++ encStrSeq act ++ encStrSeq ref ++ encStrSeq out ++ encStrSeq mLo ++ encStrSeq mHi ++
       encStrSeq est ++ encStrSeq ciL ++ encStrSeq ciLo ++ encStrSeq ciHi)
  | .metaNonEstab src act vb out =>
    "AtomicClaim.metaNonEstab" :: (encStrSeq src ++ encStrSeq act ++ encStrSeq vb ++ encStrSeq out)
  | .metaUnresolvedPolar src act vb out =>
    "AtomicClaim.metaUnresolvedPolar" :: (encStrSeq src ++ encStrSeq act ++ encStrSeq vb ++ encStrSeq out)
  | .metaWhUnresolved src ep wh act vb out =>
    "AtomicClaim.metaWhUnresolved" ::
      (encStrSeq src ++ encStrSeq ep ++ encStrSeq wh ++ encStrSeq act ++ encStrSeq vb ++ encStrSeq out)
  | .quantClaim qf =>
    "AtomicClaim.quantClaim" :: encQuantFormSeq qf

private theorem optStr_valid (o : Option String) : ∀ t ∈ encOptStrSeq o, ValidToken t := by
  cases o with
  | none => intro t ht; simp [encOptStrSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | some s =>
    intro t ht; simp only [encOptStrSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encStrSeq_valid s).2 t hm

private theorem optPairStr_valid (o : Option (String × String)) :
    ∀ t ∈ encOptPairStrSeq o, ValidToken t := by
  cases o with
  | none => intro t ht; simp [encOptPairStrSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | some p =>
    rcases p with ⟨s1, s2⟩
    intro t ht; simp only [encOptPairStrSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encStrSeq_valid s1).2 (encStrSeq_valid s2).2 t hm

theorem encAtomicClaimSeq_valid (cl : AtomicClaim) :
    1 ≤ (encAtomicClaimSeq cl).length ∧ ∀ t ∈ encAtomicClaimSeq cl, ValidToken t := by
  cases cl with
  | descIncidence w e k n p =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid w).2 (encStrSeq_valid e).2) (encStrSeq_valid k).2) (encStrSeq_valid n).2)
        (encStrSeq_valid p).2 t hm
  | descDist k m est d1 d2o =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp hm1 with rfl | hm2
      · exact encDistKind_valid k
      · exact valid_list_append (valid_list_append (valid_list_append
          (encStrSeq_valid m).2 (encStrSeq_valid est).2) (encStrSeq_valid d1).2) (optStr_valid d2o) t hm2
  | assocClaim met dir act ref out covO tmpO est ciL ciLo ciHi =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid met).2 (encStrSeq_valid dir).2) (encStrSeq_valid act).2) (encStrSeq_valid ref).2)
        (encStrSeq_valid out).2) (optStr_valid covO)) (optPairStr_valid tmpO)) (encStrSeq_valid est).2)
        (encStrSeq_valid ciL).2) (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2 t hm
  | compRD act ref out est ciL ciLo ciHi =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (encStrSeq_valid act).2 (encStrSeq_valid ref).2) (encStrSeq_valid out).2)
        (encStrSeq_valid est).2) (encStrSeq_valid ciL).2) (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2 t hm
  | intervClaim mod assump met act ref out est ciL ciLo ciHi pvO =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encIntervModSeq_valid mod).2 (encStrSeq_valid assump).2) (encStrSeq_valid met).2) (encStrSeq_valid act).2)
        (encStrSeq_valid ref).2) (encStrSeq_valid out).2) (encStrSeq_valid est).2) (encStrSeq_valid ciL).2)
        (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2) (optStr_valid pvO) t hm
  | metaNotStatSig met act ref out est ciL ciLo ciHi al =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (valid_list_append (valid_list_append (encStrSeq_valid met).2 (encStrSeq_valid act).2)
        (encStrSeq_valid ref).2) (encStrSeq_valid out).2) (encStrSeq_valid est).2) (encStrSeq_valid ciL).2)
        (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2) (encStrSeq_valid al).2 t hm
  | metaEquiv met act ref out mLo mHi est ciL ciLo ciHi =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid met).2 (encStrSeq_valid act).2) (encStrSeq_valid ref).2) (encStrSeq_valid out).2)
        (encStrSeq_valid mLo).2) (encStrSeq_valid mHi).2) (encStrSeq_valid est).2) (encStrSeq_valid ciL).2)
        (encStrSeq_valid ciLo).2) (encStrSeq_valid ciHi).2 t hm
  | metaNonEstab src act vb out =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid src).2 (encStrSeq_valid act).2) (encStrSeq_valid vb).2) (encStrSeq_valid out).2 t hm
  | metaUnresolvedPolar src act vb out =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid src).2 (encStrSeq_valid act).2) (encStrSeq_valid vb).2) (encStrSeq_valid out).2 t hm
  | metaWhUnresolved src ep wh act vb out =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append (valid_list_append
        (encStrSeq_valid src).2 (encStrSeq_valid ep).2) (encStrSeq_valid wh).2) (encStrSeq_valid act).2)
        (encStrSeq_valid vb).2) (encStrSeq_valid out).2 t hm
  | quantClaim qf =>
    refine ⟨by simp [encAtomicClaimSeq], ?_⟩
    intro t ht; simp only [encAtomicClaimSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encQuantFormSeq_valid qf).2 t hm

def parseAtomicClaimStep (toks : List String) : Except DecodeRejectDiag (AtomicClaim × List String) :=
  match toks with
  | "AtomicClaim.descIncidence" :: rs => do
    let (w, r1) ← parseStrStep rs; let (e, r2) ← parseStrStep r1
    let (k, r3) ← parseStrStep r2; let (n, r4) ← parseStrStep r3; let (p, r5) ← parseStrStep r4
    .ok (.descIncidence w e k n p, r5)
  | "AtomicClaim.descDist" :: rs => do
    let (k, r1) ← parseDistKindStep rs; let (m, r2) ← parseStrStep r1
    let (est, r3) ← parseStrStep r2; let (d1, r4) ← parseStrStep r3; let (d2o, r5) ← parseOptStrStep r4
    .ok (.descDist k m est d1 d2o, r5)
  | "AtomicClaim.assocClaim" :: rs => do
    let (met, r1) ← parseStrStep rs; let (dir, r2) ← parseStrStep r1
    let (act, r3) ← parseStrStep r2; let (ref, r4) ← parseStrStep r3; let (out, r5) ← parseStrStep r4
    let (covO, r6) ← parseOptStrStep r5; let (tmpO, r7) ← parseOptPairStrStep r6
    let (est, r8) ← parseStrStep r7; let (ciL, r9) ← parseStrStep r8
    let (ciLo, r10) ← parseStrStep r9; let (ciHi, r11) ← parseStrStep r10
    .ok (.assocClaim met dir act ref out covO tmpO est ciL ciLo ciHi, r11)
  | "AtomicClaim.compRD" :: rs => do
    let (act, r1) ← parseStrStep rs; let (ref, r2) ← parseStrStep r1; let (out, r3) ← parseStrStep r2
    let (est, r4) ← parseStrStep r3; let (ciL, r5) ← parseStrStep r4
    let (ciLo, r6) ← parseStrStep r5; let (ciHi, r7) ← parseStrStep r6
    .ok (.compRD act ref out est ciL ciLo ciHi, r7)
  | "AtomicClaim.intervClaim" :: rs => do
    let (mod, r1) ← parseIntervModStep rs; let (assump, r2) ← parseStrStep r1
    let (met, r3) ← parseStrStep r2; let (act, r4) ← parseStrStep r3; let (ref, r5) ← parseStrStep r4
    let (out, r6) ← parseStrStep r5; let (est, r7) ← parseStrStep r6; let (ciL, r8) ← parseStrStep r7
    let (ciLo, r9) ← parseStrStep r8; let (ciHi, r10) ← parseStrStep r9; let (pvO, r11) ← parseOptStrStep r10
    .ok (.intervClaim mod assump met act ref out est ciL ciLo ciHi pvO, r11)
  | "AtomicClaim.metaNotStatSig" :: rs => do
    let (met, r1) ← parseStrStep rs; let (act, r2) ← parseStrStep r1; let (ref, r3) ← parseStrStep r2
    let (out, r4) ← parseStrStep r3; let (est, r5) ← parseStrStep r4; let (ciL, r6) ← parseStrStep r5
    let (ciLo, r7) ← parseStrStep r6; let (ciHi, r8) ← parseStrStep r7; let (al, r9) ← parseStrStep r8
    .ok (.metaNotStatSig met act ref out est ciL ciLo ciHi al, r9)
  | "AtomicClaim.metaEquiv" :: rs => do
    let (met, r1) ← parseStrStep rs; let (act, r2) ← parseStrStep r1; let (ref, r3) ← parseStrStep r2
    let (out, r4) ← parseStrStep r3; let (mLo, r5) ← parseStrStep r4; let (mHi, r6) ← parseStrStep r5
    let (est, r7) ← parseStrStep r6; let (ciL, r8) ← parseStrStep r7
    let (ciLo, r9) ← parseStrStep r8; let (ciHi, r10) ← parseStrStep r9
    .ok (.metaEquiv met act ref out mLo mHi est ciL ciLo ciHi, r10)
  | "AtomicClaim.metaNonEstab" :: rs => do
    let (src, r1) ← parseStrStep rs; let (act, r2) ← parseStrStep r1
    let (vb, r3) ← parseStrStep r2; let (out, r4) ← parseStrStep r3
    .ok (.metaNonEstab src act vb out, r4)
  | "AtomicClaim.metaUnresolvedPolar" :: rs => do
    let (src, r1) ← parseStrStep rs; let (act, r2) ← parseStrStep r1
    let (vb, r3) ← parseStrStep r2; let (out, r4) ← parseStrStep r3
    .ok (.metaUnresolvedPolar src act vb out, r4)
  | "AtomicClaim.metaWhUnresolved" :: rs => do
    let (src, r1) ← parseStrStep rs; let (ep, r2) ← parseStrStep r1; let (wh, r3) ← parseStrStep r2
    let (act, r4) ← parseStrStep r3; let (vb, r5) ← parseStrStep r4; let (out, r6) ← parseStrStep r5
    .ok (.metaWhUnresolved src ep wh act vb out, r6)
  | "AtomicClaim.quantClaim" :: rs => do
    let (qf, r1) ← parseQuantFormStep rs
    .ok (.quantClaim qf, r1)
  | t :: _ => .error (.unknownConstructorTag "AtomicClaim" t)
  | []     => .error (.unexpectedEndOfTokens "AtomicClaim")

theorem parseAtomicClaimStep_enc (cl : AtomicClaim) (rest : List String) :
    parseAtomicClaimStep (encAtomicClaimSeq cl ++ rest) = .ok (cl, rest) := by
  cases cl <;> simp [encAtomicClaimSeq, List.append_assoc, parseAtomicClaimStep,
                     Bind.bind, Except.bind, parseStrStep_enc, parseDistKindStep_enc,
                     parseOptStrStep_enc, parseOptPairStrStep_enc, parseIntervModStep_enc,
                     parseQuantFormStep_enc]

def encRawTermSeq : RawSemanticTerm → List String
  | .scopedAtom sc bnd cl ps =>
    "RawSemanticTerm.scopedAtom" ::
      (encScopeSeq sc ++ encStrSeq bnd ++ encAtomicClaimSeq cl ++ encPresupListSeq ps)
  | .symConj l r =>
    "RawSemanticTerm.symConj" :: (encRawTermSeq l ++ encRawTermSeq r)
  | .contrastivePair a m shE shO =>
    "RawSemanticTerm.contrastivePair" ::
      (encRawTermSeq a ++ encRawTermSeq m ++ encStrSeq shE ++ encStrSeq shO)

theorem encRawTermSeq_valid (m : RawSemanticTerm) :
    1 ≤ (encRawTermSeq m).length ∧ ∀ t ∈ encRawTermSeq m, ValidToken t := by
  induction m with
  | scopedAtom sc bnd cl ps =>
    refine ⟨by simp [encRawTermSeq], ?_⟩
    intro t ht; simp only [encRawTermSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append
        (encScopeSeq_valid sc).2 (encStrSeq_valid bnd).2) (encAtomicClaimSeq_valid cl).2)
        (encPresupListSeq_valid ps).2 t hm
  | symConj l r ihl ihr =>
    refine ⟨by simp [encRawTermSeq], ?_⟩
    intro t ht; simp only [encRawTermSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append ihl.2 ihr.2 t hm
  | contrastivePair a ms shE shO iha ihm =>
    refine ⟨by simp [encRawTermSeq], ?_⟩
    intro t ht; simp only [encRawTermSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (valid_list_append iha.2 ihm.2)
        (encStrSeq_valid shE).2) (encStrSeq_valid shO).2 t hm

def parseRawTermToks : Nat → List String → Except DecodeRejectDiag (RawSemanticTerm × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "RawSemanticTerm.scopedAtom" :: rs => do
    let (sc, r1) ← parseScopeStep rs
    let (bnd, r2) ← parseStrStep r1
    let (cl, r3) ← parseAtomicClaimStep r2
    let (ps, r4) ← parsePresupListToks f r3
    .ok (.scopedAtom sc bnd cl ps, r4)
  | f + 1, "RawSemanticTerm.symConj" :: rs => do
    let (l, r1) ← parseRawTermToks f rs
    let (r, r2) ← parseRawTermToks f r1
    .ok (.symConj l r, r2)
  | f + 1, "RawSemanticTerm.contrastivePair" :: rs => do
    let (a, r1) ← parseRawTermToks f rs
    let (m, r2) ← parseRawTermToks f r1
    let (shE, r3) ← parseStrStep r2
    let (shO, r4) ← parseStrStep r3
    .ok (.contrastivePair a m shE shO, r4)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "RawSemanticTerm" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "RawSemanticTerm")

theorem parseRawTermToks_enc (m : RawSemanticTerm) (rest : List String) (fuel : Nat)
    (hf : (encRawTermSeq m).length ≤ fuel) :
    parseRawTermToks fuel (encRawTermSeq m ++ rest) = .ok (m, rest) := by
  induction m generalizing fuel rest with
  | scopedAtom sc bnd cl ps =>
    cases fuel with
    | zero => simp [encRawTermSeq] at hf
    | succ f =>
      have hpf : (encPresupListSeq ps).length ≤ f := by simp [encRawTermSeq] at hf; omega
      simp only [encRawTermSeq, List.cons_append, List.append_assoc, parseRawTermToks,
                 Bind.bind, Except.bind, parseScopeStep_enc, parseStrStep_enc,
                 parseAtomicClaimStep_enc]
      rw [parsePresupListToks_enc ps rest f hpf]
  | symConj l r ihl ihr =>
    cases fuel with
    | zero => simp [encRawTermSeq] at hf
    | succ f =>
      have hlf : (encRawTermSeq l).length ≤ f := by simp [encRawTermSeq] at hf; omega
      have hrf : (encRawTermSeq r).length ≤ f := by simp [encRawTermSeq] at hf; omega
      simp only [encRawTermSeq, List.cons_append, List.append_assoc, parseRawTermToks,
                 Bind.bind, Except.bind]
      rw [ihl (encRawTermSeq r ++ rest) f hlf]
      dsimp only
      rw [ihr rest f hrf]
  | contrastivePair a ms shE shO iha ihm =>
    cases fuel with
    | zero => simp [encRawTermSeq] at hf
    | succ f =>
      have haf : (encRawTermSeq a).length ≤ f := by simp [encRawTermSeq] at hf; omega
      have hmf : (encRawTermSeq ms).length ≤ f := by simp [encRawTermSeq] at hf; omega
      simp only [encRawTermSeq, List.cons_append, List.append_assoc, parseRawTermToks,
                 Bind.bind, Except.bind]
      rw [iha (encRawTermSeq ms ++ (encStrSeq shE ++ (encStrSeq shO ++ rest))) f haf]
      dsimp only
      rw [ihm (encStrSeq shE ++ (encStrSeq shO ++ rest)) f hmf]
      dsimp only
      simp [parseStrStep_enc]

def rawMeaningWireCodec : CanonicalWireCodec RawSemanticTerm where
  typeTag      := "RawSemanticTerm"
  encToks      := encRawTermSeq
  parseToks    := parseRawTermToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun m =>
    let ⟨h1, hv⟩ := encRawTermSeq_valid m
    ⟨by intro he; rw [he] at h1; simp at h1, hv⟩
  hParsePrefix := parseRawTermToks_enc

mutual
  def encNormItemSeq : NormItem → List String
    | .normAtom sc cl ps =>
      "NormItem.normAtom" :: (encScopeSeq sc ++ encAtomicClaimSeq cl ++ encPresupListSeq ps)
    | .normContrastive aItems mItems shE shO =>
      "NormItem.normContrastive" ::
        (encNormItemListSeq aItems ++ encNormItemListSeq mItems ++ encStrSeq shE ++ encStrSeq shO)

  def encNormItemListSeq : List NormItem → List String
    | []      => ["NormItemList.nil"]
    | x :: xs => "NormItemList.cons" :: (encNormItemSeq x ++ encNormItemListSeq xs)
end

mutual
  theorem encNormItemSeq_valid (it : NormItem) :
      1 ≤ (encNormItemSeq it).length ∧ ∀ t ∈ encNormItemSeq it, ValidToken t := by
    cases it with
    | normAtom sc cl ps =>
      refine ⟨by simp [encNormItemSeq], ?_⟩
      intro t ht; simp only [encNormItemSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append (valid_list_append (encScopeSeq_valid sc).2
          (encAtomicClaimSeq_valid cl).2) (encPresupListSeq_valid ps).2 t hm
    | normContrastive aItems mItems shE shO =>
      have ⟨_, hva⟩ := encNormItemListSeq_valid aItems
      have ⟨_, hvm⟩ := encNormItemListSeq_valid mItems
      refine ⟨by simp [encNormItemSeq], ?_⟩
      intro t ht; simp only [encNormItemSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append (valid_list_append (valid_list_append hva hvm)
          (encStrSeq_valid shE).2) (encStrSeq_valid shO).2 t hm

  theorem encNormItemListSeq_valid (xs : List NormItem) :
      1 ≤ (encNormItemListSeq xs).length ∧ ∀ t ∈ encNormItemListSeq xs, ValidToken t := by
    cases xs with
    | nil =>
      refine ⟨by simp [encNormItemListSeq], ?_⟩
      intro t ht; simp [encNormItemListSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
    | cons x rest =>
      have ⟨_, hvx⟩ := encNormItemSeq_valid x
      have ⟨_, hvr⟩ := encNormItemListSeq_valid rest
      refine ⟨by simp [encNormItemListSeq], ?_⟩
      intro t ht; simp only [encNormItemListSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append hvx hvr t hm
end

def parseNormItemToks : Nat → List String → Except DecodeRejectDiag (NormItem × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "NormItem.normAtom" :: rs => do
    let (sc, r1) ← parseScopeStep rs
    let (cl, r2) ← parseAtomicClaimStep r1
    let (ps, r3) ← parsePresupListToks f r2
    .ok (.normAtom sc cl ps, r3)
  | f + 1, "NormItem.normContrastive" :: rs => do
    let (aItems, r1) ← parseNormItemListToks f rs
    let (mItems, r2) ← parseNormItemListToks f r1
    let (shE, r3) ← parseStrStep r2
    let (shO, r4) ← parseStrStep r3
    .ok (.normContrastive aItems mItems shE shO, r4)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "NormItem" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "NormItem")
where
  parseNormItemListToks : Nat → List String → Except DecodeRejectDiag (List NormItem × List String)
    | 0, _ => .error .recursionFuelExhausted
    | _ + 1, "NormItemList.nil" :: rs => .ok ([], rs)
    | f + 1, "NormItemList.cons" :: rs => do
      let (x, r1) ← parseNormItemToks f rs
      let (xs, r2) ← parseNormItemListToks f r1
      .ok (x :: xs, r2)
    | _ + 1, t :: _ => .error (.unknownConstructorTag "NormItemList" t)
    | _ + 1, []     => .error (.unexpectedEndOfTokens "NormItemList")

mutual
  theorem parseNormItemToks_enc (it : NormItem) (rest : List String) (fuel : Nat)
      (hf : (encNormItemSeq it).length ≤ fuel) :
      parseNormItemToks fuel (encNormItemSeq it ++ rest) = .ok (it, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encNormItemSeq_valid it; omega
    | succ f =>
      cases it with
      | normAtom sc cl ps =>
        have hpf : (encPresupListSeq ps).length ≤ f := by simp [encNormItemSeq] at hf; omega
        simp only [encNormItemSeq, List.cons_append, List.append_assoc, parseNormItemToks,
                   Bind.bind, Except.bind, parseScopeStep_enc, parseAtomicClaimStep_enc]
        rw [parsePresupListToks_enc ps rest f hpf]
      | normContrastive aItems mItems shE shO =>
        have haf : (encNormItemListSeq aItems).length ≤ f := by simp [encNormItemSeq] at hf; omega
        have hmf : (encNormItemListSeq mItems).length ≤ f := by simp [encNormItemSeq] at hf; omega
        simp only [encNormItemSeq, List.cons_append, List.append_assoc, parseNormItemToks,
                   Bind.bind, Except.bind]
        rw [parseNormItemListToks_enc aItems (encNormItemListSeq mItems ++ (encStrSeq shE ++ (encStrSeq shO ++ rest))) f haf]
        dsimp only
        rw [parseNormItemListToks_enc mItems (encStrSeq shE ++ (encStrSeq shO ++ rest)) f hmf]
        dsimp only
        simp [parseStrStep_enc]

  theorem parseNormItemListToks_enc (xs : List NormItem) (rest : List String) (fuel : Nat)
      (hf : (encNormItemListSeq xs).length ≤ fuel) :
      parseNormItemToks.parseNormItemListToks fuel (encNormItemListSeq xs ++ rest) = .ok (xs, rest) := by
    cases fuel with
    | zero =>
      have ⟨h1, _⟩ := encNormItemListSeq_valid xs; omega
    | succ f =>
      cases xs with
      | nil => rfl
      | cons x tail =>
        have hxf : (encNormItemSeq x).length ≤ f := by simp [encNormItemListSeq] at hf; omega
        have htf : (encNormItemListSeq tail).length ≤ f := by simp [encNormItemListSeq] at hf; omega
        simp only [encNormItemListSeq, List.cons_append, List.append_assoc,
                   parseNormItemToks.parseNormItemListToks, Bind.bind, Except.bind]
        rw [parseNormItemToks_enc x (encNormItemListSeq tail ++ rest) f hxf]
        dsimp only
        rw [parseNormItemListToks_enc tail rest f htf]
end

def encCanonicalSeq (c : CanonicalMeaning) : List String :=
  "CanonicalMeaning.mk" :: encNormItemListSeq c.items

def parseCanonicalToks : Nat → List String → Except DecodeRejectDiag (CanonicalMeaning × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "CanonicalMeaning.mk" :: rs => do
    let (items, r1) ← parseNormItemToks.parseNormItemListToks f rs
    .ok (⟨items⟩, r1)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "CanonicalMeaning" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "CanonicalMeaning")

theorem parseCanonicalToks_enc (c : CanonicalMeaning) (rest : List String) (fuel : Nat)
    (hf : (encCanonicalSeq c).length ≤ fuel) :
    parseCanonicalToks fuel (encCanonicalSeq c ++ rest) = .ok (c, rest) := by
  cases fuel with
  | zero => simp [encCanonicalSeq] at hf
  | succ f =>
    cases c with
    | mk items =>
      have hif : (encNormItemListSeq items).length ≤ f := by simp [encCanonicalSeq] at hf; omega
      simp only [encCanonicalSeq, List.cons_append, parseCanonicalToks, Bind.bind, Except.bind]
      rw [parseNormItemListToks_enc items rest f hif]

def canonicalMeaningWireCodec : CanonicalWireCodec CanonicalMeaning where
  typeTag      := "CanonicalMeaning"
  encToks      := encCanonicalSeq
  parseToks    := parseCanonicalToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun c => by
    refine ⟨by simp [encCanonicalSeq], ?_⟩
    intro t ht; simp only [encCanonicalSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encNormItemListSeq_valid c.items).2 t hm
  hParsePrefix := parseCanonicalToks_enc

/-! ### 10. `ForestExtractionError`, Extraction Result & 5-Way `SemanticNormOutcome` Codecs -/

def encExtractionDiagSeq : ExtractionFailureDiag → List String
  | .malformedParseNode p det       => "ExtractionFailureDiag.malformedParseNode" :: prodToWireName p :: encStrSeq det
  | .unsupportedReadingAlt p alt    => ["ExtractionFailureDiag.unsupportedReadingAlt", prodToWireName p, encNatTok alt]
  | .mismatchedScopeCohort fnd exp  => "ExtractionFailureDiag.mismatchedScopeCohort" :: (encStrSeq fnd ++ encStrSeq exp)
  | .unresolvedAnaphoricScope fnd exp => "ExtractionFailureDiag.unresolvedAnaphoricScope" :: (encStrSeq fnd ++ encStrSeq exp)
  | .invalidContrastiveAnchor p     => ["ExtractionFailureDiag.invalidContrastiveAnchor", prodToWireName p]

theorem encExtractionDiagSeq_valid (d : ExtractionFailureDiag) :
    1 ≤ (encExtractionDiagSeq d).length ∧ ∀ t ∈ encExtractionDiagSeq d, ValidToken t := by
  cases d with
  | malformedParseNode p det =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp h1 with rfl | h2
      · exact prodToWireName_valid p
      · exact (encStrSeq_valid det).2 t h2
  | unsupportedReadingAlt p alt =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp h1 with rfl | h2
      · exact prodToWireName_valid p
      · rcases List.mem_cons.mp h2 with rfl | h3
        · exact encNatTok_valid alt
        · nomatch h3
  | mismatchedScopeCohort fnd exp =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encStrSeq_valid fnd).2 (encStrSeq_valid exp).2 t h1
  | unresolvedAnaphoricScope fnd exp =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encStrSeq_valid fnd).2 (encStrSeq_valid exp).2 t h1
  | invalidContrastiveAnchor p =>
    refine ⟨by simp [encExtractionDiagSeq], ?_⟩
    intro t ht; simp only [encExtractionDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp h1 with rfl | h2
      · exact prodToWireName_valid p
      · nomatch h2

def parseExtractionDiagStep (toks : List String) :
    Except DecodeRejectDiag (ExtractionFailureDiag × List String) :=
  match toks with
  | "ExtractionFailureDiag.malformedParseNode" :: rs => do
    let (p, r1) ← parseProdStep rs; let (det, r2) ← parseStrStep r1
    .ok (.malformedParseNode p det, r2)
  | "ExtractionFailureDiag.unsupportedReadingAlt" :: rs => do
    let (p, r1) ← parseProdStep rs; let (alt, r2) ← parseNatStep r1
    .ok (.unsupportedReadingAlt p alt, r2)
  | "ExtractionFailureDiag.mismatchedScopeCohort" :: rs => do
    let (f, r1) ← parseStrStep rs; let (e, r2) ← parseStrStep r1
    .ok (.mismatchedScopeCohort f e, r2)
  | "ExtractionFailureDiag.unresolvedAnaphoricScope" :: rs => do
    let (f, r1) ← parseStrStep rs; let (e, r2) ← parseStrStep r1
    .ok (.unresolvedAnaphoricScope f e, r2)
  | "ExtractionFailureDiag.invalidContrastiveAnchor" :: rs => do
    let (p, r1) ← parseProdStep rs
    .ok (.invalidContrastiveAnchor p, r1)
  | t :: _ => .error (.unknownConstructorTag "ExtractionFailureDiag" t)
  | []     => .error (.unexpectedEndOfTokens "ExtractionFailureDiag")

theorem parseExtractionDiagStep_enc (d : ExtractionFailureDiag) (rest : List String) :
    parseExtractionDiagStep (encExtractionDiagSeq d ++ rest) = .ok (d, rest) := by
  cases d <;> simp [encExtractionDiagSeq, List.append_assoc, parseExtractionDiagStep,
                    Bind.bind, Except.bind, parseProdStep_enc, parseStrStep_enc, parseNatStep_enc]

def encForestErrSeq (err : ForestExtractionError) : List String :=
  "ForestExtractionError.mk" :: (encParseTreeSeq err.failedTree ++ encExtractionDiagSeq err.diag)

def parseForestErrToks : Nat → List String → Except DecodeRejectDiag (ForestExtractionError × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "ForestExtractionError.mk" :: rs => do
    let (tr, r1) ← parseParseTreeToks f rs
    let (dg, r2) ← parseExtractionDiagStep r1
    .ok (⟨tr, dg⟩, r2)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "ForestExtractionError" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "ForestExtractionError")

theorem parseForestErrToks_enc (err : ForestExtractionError) (rest : List String) (fuel : Nat)
    (hf : (encForestErrSeq err).length ≤ fuel) :
    parseForestErrToks fuel (encForestErrSeq err ++ rest) = .ok (err, rest) := by
  cases fuel with
  | zero => simp [encForestErrSeq] at hf
  | succ f =>
    cases err with
    | mk tr dg =>
      have htf : (encParseTreeSeq tr).length ≤ f := by simp [encForestErrSeq] at hf; omega
      simp only [encForestErrSeq, List.cons_append, List.append_assoc, parseForestErrToks,
                 Bind.bind, Except.bind]
      rw [parseParseTreeToks_enc tr (encExtractionDiagSeq dg ++ rest) f htf]
      dsimp only
      rw [parseExtractionDiagStep_enc]

def forestExtractionErrWireCodec : CanonicalWireCodec ForestExtractionError where
  typeTag      := "ForestExtractionError"
  encToks      := encForestErrSeq
  parseToks    := parseForestErrToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun err => by
    refine ⟨by simp [encForestErrSeq], ?_⟩
    intro t ht; simp only [encForestErrSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encParseTreeSeq_valid err.failedTree).2
        (encExtractionDiagSeq_valid err.diag).2 t hm
  hParsePrefix := parseForestErrToks_enc

def encSingleExtResSeq : Except ExtractionFailureDiag RawSemanticTerm → List String
  | .error d => "Except.error" :: encExtractionDiagSeq d
  | .ok m    => "Except.ok" :: encRawTermSeq m

def parseSingleExtResToks : Nat → List String →
    Except DecodeRejectDiag (Except ExtractionFailureDiag RawSemanticTerm × List String)
  | 0, _ => .error .recursionFuelExhausted
  | _ + 1, "Except.error" :: rs => do
    let (d, r1) ← parseExtractionDiagStep rs
    .ok (.error d, r1)
  | f + 1, "Except.ok" :: rs => do
    let (m, r1) ← parseRawTermToks f rs
    .ok (.ok m, r1)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "SingleExtractionResult" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "SingleExtractionResult")

theorem parseSingleExtResToks_enc (res : Except ExtractionFailureDiag RawSemanticTerm)
    (rest : List String) (fuel : Nat) (hf : (encSingleExtResSeq res).length ≤ fuel) :
    parseSingleExtResToks fuel (encSingleExtResSeq res ++ rest) = .ok (res, rest) := by
  cases fuel with
  | zero =>
    cases res <;> simp [encSingleExtResSeq] at hf
  | succ f =>
    cases res with
    | error d =>
      simp [encSingleExtResSeq, parseSingleExtResToks, Bind.bind, Except.bind, parseExtractionDiagStep_enc]
    | ok m =>
      have hmf : (encRawTermSeq m).length ≤ f := by simp [encSingleExtResSeq] at hf; omega
      simp only [encSingleExtResSeq, List.cons_append, parseSingleExtResToks, Bind.bind, Except.bind]
      rw [parseRawTermToks_enc m rest f hmf]

def singleExtractionResWireCodec : CanonicalWireCodec (Except ExtractionFailureDiag RawSemanticTerm) where
  typeTag      := "SingleExtractionResult"
  encToks      := encSingleExtResSeq
  parseToks    := parseSingleExtResToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun res => by
    cases res with
    | error d =>
      refine ⟨by simp [encSingleExtResSeq], ?_⟩
      intro t ht; simp only [encSingleExtResSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact (encExtractionDiagSeq_valid d).2 t hm
    | ok m =>
      refine ⟨by simp [encSingleExtResSeq], ?_⟩
      intro t ht; simp only [encSingleExtResSeq] at ht
      rcases List.mem_cons.mp ht with rfl | hm
      · exact checkValidTokenBool_sound (by decide)
      · exact (encRawTermSeq_valid m).2 t hm
  hParsePrefix := parseSingleExtResToks_enc

def encTrapDiagSeq : TrapPolicyDiag → List String
  | .whFactivePresuppositionForbidden => ["TrapPolicyDiag.whFactivePresuppositionForbidden"]
  | .unscopedClauseForbidden          => ["TrapPolicyDiag.unscopedClauseForbidden"]
  | .parserOnlyTrapProduction r       => ["TrapPolicyDiag.parserOnlyTrapProduction", ruleIdToWireName r]
  | .wrapperTrapEnvelope              => ["TrapPolicyDiag.wrapperTrapEnvelope"]

theorem encTrapDiagSeq_valid (d : TrapPolicyDiag) :
    1 ≤ (encTrapDiagSeq d).length ∧ ∀ t ∈ encTrapDiagSeq d, ValidToken t := by
  cases d with
  | whFactivePresuppositionForbidden =>
    refine ⟨by simp [encTrapDiagSeq], ?_⟩
    intro t ht; simp [encTrapDiagSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | unscopedClauseForbidden =>
    refine ⟨by simp [encTrapDiagSeq], ?_⟩
    intro t ht; simp [encTrapDiagSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | parserOnlyTrapProduction r =>
    refine ⟨by simp [encTrapDiagSeq], ?_⟩
    intro t ht; simp only [encTrapDiagSeq] at ht
    rcases List.mem_cons.mp ht with rfl | h1
    · exact checkValidTokenBool_sound (by decide)
    · rcases List.mem_cons.mp h1 with rfl | h2
      · exact ruleIdToWireName_valid r
      · nomatch h2
  | wrapperTrapEnvelope =>
    refine ⟨by simp [encTrapDiagSeq], ?_⟩
    intro t ht; simp [encTrapDiagSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)

def parseTrapDiagStep (toks : List String) : Except DecodeRejectDiag (TrapPolicyDiag × List String) :=
  match toks with
  | "TrapPolicyDiag.whFactivePresuppositionForbidden" :: rs => .ok (.whFactivePresuppositionForbidden, rs)
  | "TrapPolicyDiag.unscopedClauseForbidden" :: rs => .ok (.unscopedClauseForbidden, rs)
  | "TrapPolicyDiag.parserOnlyTrapProduction" :: rs => do
    let (r, r1) ← parseRuleIdStep rs
    .ok (.parserOnlyTrapProduction r, r1)
  | "TrapPolicyDiag.wrapperTrapEnvelope" :: rs => .ok (.wrapperTrapEnvelope, rs)
  | t :: _ => .error (.unknownConstructorTag "TrapPolicyDiag" t)
  | []     => .error (.unexpectedEndOfTokens "TrapPolicyDiag")

theorem parseTrapDiagStep_enc (d : TrapPolicyDiag) (rest : List String) :
    parseTrapDiagStep (encTrapDiagSeq d ++ rest) = .ok (d, rest) := by
  cases d <;> simp [encTrapDiagSeq, parseTrapDiagStep, Bind.bind, Except.bind, parseRuleIdStep_enc]

def encUpstreamDiagSeq : UpstreamParseDiag → List String
  | .emptyParseSet => ["UpstreamParseDiag.emptyParseSet"]
  | .outOfDomain .emptyInput => ["UpstreamParseDiag.outOfDomain", "OutOfDomainDiag.emptyInput"]
  | .outOfDomain (.nonPrintableAsciiByte b) =>
    "UpstreamParseDiag.outOfDomain" :: "OutOfDomainDiag.nonPrintableAsciiByte" :: encUInt8Seq b
  | .resourceOverflow (.maxBytesExceeded act lim) =>
    ["UpstreamParseDiag.resourceOverflow", "OverflowReason.maxBytesExceeded", encNatTok act, encNatTok lim]
  | .resourceOverflow (.maxStepsExceeded lim) =>
    ["UpstreamParseDiag.resourceOverflow", "OverflowReason.maxStepsExceeded", encNatTok lim]
  | .resourceOverflow (.maxForestNodesExceeded lim) =>
    ["UpstreamParseDiag.resourceOverflow", "OverflowReason.maxForestNodesExceeded", encNatTok lim]
  | .resourceOverflow (.maxReadingsExceeded act lim) =>
    ["UpstreamParseDiag.resourceOverflow", "OverflowReason.maxReadingsExceeded", encNatTok act, encNatTok lim]

theorem encUpstreamDiagSeq_valid (d : UpstreamParseDiag) :
    1 ≤ (encUpstreamDiagSeq d).length ∧ ∀ t ∈ encUpstreamDiagSeq d, ValidToken t := by
  cases d with
  | emptyParseSet =>
    refine ⟨by simp [encUpstreamDiagSeq], ?_⟩
    intro t ht; simp [encUpstreamDiagSeq] at ht; subst ht; exact checkValidTokenBool_sound (by decide)
  | outOfDomain od =>
    cases od with
    | emptyInput =>
      refine ⟨by simp [encUpstreamDiagSeq], ?_⟩
      intro t ht; simp only [encUpstreamDiagSeq] at ht
      rcases List.mem_cons.mp ht with rfl | h1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp h1 with rfl | h2
        · exact checkValidTokenBool_sound (by decide)
        · nomatch h2
    | nonPrintableAsciiByte b =>
      refine ⟨by simp [encUpstreamDiagSeq], ?_⟩
      intro t ht; simp only [encUpstreamDiagSeq, encUInt8Seq] at ht
      rcases List.mem_cons.mp ht with rfl | h1
      · exact checkValidTokenBool_sound (by decide)
      · rcases List.mem_cons.mp h1 with rfl | h2
        · exact checkValidTokenBool_sound (by decide)
        · rcases List.mem_cons.mp h2 with rfl | h3
          · exact checkValidTokenBool_sound (by decide)
          · rcases List.mem_cons.mp h3 with rfl | h4
            · exact encNatTok_valid _
            · nomatch h4
  | resourceOverflow ov =>
    cases ov <;> (
      refine ⟨by simp [encUpstreamDiagSeq], ?_⟩
      intro t ht; simp only [encUpstreamDiagSeq] at ht
      repeat (rcases List.mem_cons.mp ht with rfl | ht; · first | exact checkValidTokenBool_sound (by decide) | exact encNatTok_valid _)
      nomatch ht)

def parseUpstreamDiagStep (toks : List String) : Except DecodeRejectDiag (UpstreamParseDiag × List String) :=
  match toks with
  | "UpstreamParseDiag.emptyParseSet" :: rs => .ok (.emptyParseSet, rs)
  | "UpstreamParseDiag.outOfDomain" :: "OutOfDomainDiag.emptyInput" :: rs =>
    .ok (.outOfDomain .emptyInput, rs)
  | "UpstreamParseDiag.outOfDomain" :: "OutOfDomainDiag.nonPrintableAsciiByte" :: rs => do
    let (b, r1) ← parseUInt8Step rs
    .ok (.outOfDomain (.nonPrintableAsciiByte b), r1)
  | "UpstreamParseDiag.resourceOverflow" :: "OverflowReason.maxBytesExceeded" :: rs => do
    let (act, r1) ← parseNatStep rs; let (lim, r2) ← parseNatStep r1
    .ok (.resourceOverflow (.maxBytesExceeded act lim), r2)
  | "UpstreamParseDiag.resourceOverflow" :: "OverflowReason.maxStepsExceeded" :: rs => do
    let (lim, r1) ← parseNatStep rs
    .ok (.resourceOverflow (.maxStepsExceeded lim), r1)
  | "UpstreamParseDiag.resourceOverflow" :: "OverflowReason.maxForestNodesExceeded" :: rs => do
    let (lim, r1) ← parseNatStep rs
    .ok (.resourceOverflow (.maxForestNodesExceeded lim), r1)
  | "UpstreamParseDiag.resourceOverflow" :: "OverflowReason.maxReadingsExceeded" :: rs => do
    let (act, r1) ← parseNatStep rs; let (lim, r2) ← parseNatStep r1
    .ok (.resourceOverflow (.maxReadingsExceeded act lim), r2)
  | t :: _ => .error (.unknownConstructorTag "UpstreamParseDiag" t)
  | []     => .error (.unexpectedEndOfTokens "UpstreamParseDiag")

theorem parseUpstreamDiagStep_enc (d : UpstreamParseDiag) (rest : List String) :
    parseUpstreamDiagStep (encUpstreamDiagSeq d ++ rest) = .ok (d, rest) := by
  cases d with
  | emptyParseSet => rfl
  | outOfDomain od =>
    cases od <;> simp [encUpstreamDiagSeq, parseUpstreamDiagStep, Bind.bind, Except.bind, parseUInt8Step_enc]
  | resourceOverflow ov =>
    cases ov <;> simp [encUpstreamDiagSeq, parseUpstreamDiagStep, Bind.bind, Except.bind, parseNatStep_enc]

def encAmbigWitnessSeq (w : AmbiguityRefutationWitness) : List String :=
  "AmbiguityRefutationWitness.mk" ::
    (encParseTreeSeq w.tree1 ++ encParseTreeSeq w.tree2 ++
     encRawTermSeq w.raw1 ++ encRawTermSeq w.raw2 ++
     encCanonicalSeq w.norm1 ++ encCanonicalSeq w.norm2)

def parseAmbigWitnessToks : Nat → List String →
    Except DecodeRejectDiag (AmbiguityRefutationWitness × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "AmbiguityRefutationWitness.mk" :: rs => do
    let (t1, r1) ← parseParseTreeToks f rs
    let (t2, r2) ← parseParseTreeToks f r1
    let (m1, r3) ← parseRawTermToks f r2
    let (m2, r4) ← parseRawTermToks f r3
    let (c1, r5) ← parseCanonicalToks f r4
    let (c2, r6) ← parseCanonicalToks f r5
    .ok (⟨t1, t2, m1, m2, c1, c2⟩, r6)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "AmbiguityRefutationWitness" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "AmbiguityRefutationWitness")

theorem parseAmbigWitnessToks_enc (w : AmbiguityRefutationWitness) (rest : List String) (fuel : Nat)
    (hf : (encAmbigWitnessSeq w).length ≤ fuel) :
    parseAmbigWitnessToks fuel (encAmbigWitnessSeq w ++ rest) = .ok (w, rest) := by
  cases fuel with
  | zero => simp [encAmbigWitnessSeq] at hf
  | succ f =>
    cases w with
    | mk t1 t2 m1 m2 c1 c2 =>
      have h1 : (encParseTreeSeq t1).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h2 : (encParseTreeSeq t2).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h3 : (encRawTermSeq m1).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h4 : (encRawTermSeq m2).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h5 : (encCanonicalSeq c1).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      have h6 : (encCanonicalSeq c2).length ≤ f := by simp [encAmbigWitnessSeq] at hf; omega
      simp only [encAmbigWitnessSeq, List.cons_append, List.append_assoc, parseAmbigWitnessToks,
                 Bind.bind, Except.bind]
      rw [parseParseTreeToks_enc t1 _ f h1]; dsimp only
      rw [parseParseTreeToks_enc t2 _ f h2]; dsimp only
      rw [parseRawTermToks_enc m1 _ f h3]; dsimp only
      rw [parseRawTermToks_enc m2 _ f h4]; dsimp only
      rw [parseCanonicalToks_enc c1 _ f h5]; dsimp only
      rw [parseCanonicalToks_enc c2 _ f h6]

def encOutcomeSeq : SemanticNormOutcome → List String
  | .consensus T c =>
    "SemanticNormOutcome.consensus" :: (encForestSeq T ++ encCanonicalSeq c)
  | .ambiguousReadings T w =>
    "SemanticNormOutcome.ambiguousReadings" :: (encForestSeq T ++ encAmbigWitnessSeq w)
  | .semanticExtractionFailure T err =>
    "SemanticNormOutcome.semanticExtractionFailure" :: (encForestSeq T ++ encForestErrSeq err)
  | .trapPolicyRejected T c d =>
    "SemanticNormOutcome.trapPolicyRejected" :: (encForestSeq T ++ encCanonicalSeq c ++ encTrapDiagSeq d)
  | .upstreamRejected d =>
    "SemanticNormOutcome.upstreamRejected" :: encUpstreamDiagSeq d

theorem encOutcomeSeq_valid (out : SemanticNormOutcome) :
    1 ≤ (encOutcomeSeq out).length ∧ ∀ t ∈ encOutcomeSeq out, ValidToken t := by
  cases out with
  | consensus T c =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encForestSeq_valid T).2 (canonicalMeaningWireCodec.hToksValid c).2 t hm
  | ambiguousReadings T w =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · apply valid_list_append (encForestSeq_valid T).2 _ t hm
      intro t2 ht2; simp only [encAmbigWitnessSeq] at ht2
      rcases List.mem_cons.mp ht2 with rfl | hw
      · exact checkValidTokenBool_sound (by decide)
      · exact valid_list_append (valid_list_append (valid_list_append (valid_list_append
          (valid_list_append (encParseTreeSeq_valid w.tree1).2 (encParseTreeSeq_valid w.tree2).2)
          (encRawTermSeq_valid w.raw1).2) (encRawTermSeq_valid w.raw2).2)
          (canonicalMeaningWireCodec.hToksValid w.norm1).2)
          (canonicalMeaningWireCodec.hToksValid w.norm2).2 t2 hw
  | semanticExtractionFailure T err =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (encForestSeq_valid T).2
        (forestExtractionErrWireCodec.hToksValid err).2 t hm
  | trapPolicyRejected T c d =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact valid_list_append (valid_list_append (encForestSeq_valid T).2
        (canonicalMeaningWireCodec.hToksValid c).2) (encTrapDiagSeq_valid d).2 t hm
  | upstreamRejected d =>
    refine ⟨by simp [encOutcomeSeq], ?_⟩
    intro t ht; simp only [encOutcomeSeq] at ht
    rcases List.mem_cons.mp ht with rfl | hm
    · exact checkValidTokenBool_sound (by decide)
    · exact (encUpstreamDiagSeq_valid d).2 t hm

def parseOutcomeToks : Nat → List String → Except DecodeRejectDiag (SemanticNormOutcome × List String)
  | 0, _ => .error .recursionFuelExhausted
  | f + 1, "SemanticNormOutcome.consensus" :: rs => do
    let (T, r1) ← parseForestToks f rs
    let (c, r2) ← parseCanonicalToks f r1
    .ok (.consensus T c, r2)
  | f + 1, "SemanticNormOutcome.ambiguousReadings" :: rs => do
    let (T, r1) ← parseForestToks f rs
    let (w, r2) ← parseAmbigWitnessToks f r1
    .ok (.ambiguousReadings T w, r2)
  | f + 1, "SemanticNormOutcome.semanticExtractionFailure" :: rs => do
    let (T, r1) ← parseForestToks f rs
    let (err, r2) ← parseForestErrToks f r1
    .ok (.semanticExtractionFailure T err, r2)
  | f + 1, "SemanticNormOutcome.trapPolicyRejected" :: rs => do
    let (T, r1) ← parseForestToks f rs
    let (c, r2) ← parseCanonicalToks f r1
    let (d, r3) ← parseTrapDiagStep r2
    .ok (.trapPolicyRejected T c d, r3)
  | _ + 1, "SemanticNormOutcome.upstreamRejected" :: rs => do
    let (d, r1) ← parseUpstreamDiagStep rs
    .ok (.upstreamRejected d, r1)
  | _ + 1, t :: _ => .error (.unknownConstructorTag "SemanticNormOutcome" t)
  | _ + 1, []     => .error (.unexpectedEndOfTokens "SemanticNormOutcome")

theorem parseOutcomeToks_enc (out : SemanticNormOutcome) (rest : List String) (fuel : Nat)
    (hf : (encOutcomeSeq out).length ≤ fuel) :
    parseOutcomeToks fuel (encOutcomeSeq out ++ rest) = .ok (out, rest) := by
  cases fuel with
  | zero =>
    have ⟨h1, _⟩ := encOutcomeSeq_valid out; omega
  | succ f =>
    cases out with
    | consensus T c =>
      have htf : (encForestSeq T).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      have hcf : (encCanonicalSeq c).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      simp only [encOutcomeSeq, List.cons_append, List.append_assoc, parseOutcomeToks, Bind.bind, Except.bind]
      rw [parseForestToks_enc T _ f htf]; dsimp only
      rw [parseCanonicalToks_enc c _ f hcf]
    | ambiguousReadings T w =>
      have htf : (encForestSeq T).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      have hwf : (encAmbigWitnessSeq w).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      simp only [encOutcomeSeq, List.cons_append, List.append_assoc, parseOutcomeToks, Bind.bind, Except.bind]
      rw [parseForestToks_enc T _ f htf]; dsimp only
      rw [parseAmbigWitnessToks_enc w _ f hwf]
    | semanticExtractionFailure T err =>
      have htf : (encForestSeq T).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      have hef : (encForestErrSeq err).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      simp only [encOutcomeSeq, List.cons_append, List.append_assoc, parseOutcomeToks, Bind.bind, Except.bind]
      rw [parseForestToks_enc T _ f htf]; dsimp only
      rw [parseForestErrToks_enc err _ f hef]
    | trapPolicyRejected T c d =>
      have htf : (encForestSeq T).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      have hcf : (encCanonicalSeq c).length ≤ f := by simp [encOutcomeSeq] at hf; omega
      simp only [encOutcomeSeq, List.cons_append, List.append_assoc, parseOutcomeToks, Bind.bind, Except.bind]
      rw [parseForestToks_enc T _ f htf]; dsimp only
      rw [parseCanonicalToks_enc c _ f hcf]; dsimp only
      rw [parseTrapDiagStep_enc]
    | upstreamRejected d =>
      simp [encOutcomeSeq, parseOutcomeToks, Bind.bind, Except.bind, parseUpstreamDiagStep_enc]

def outcomeWireCodec : CanonicalWireCodec SemanticNormOutcome where
  typeTag      := "SemanticNormOutcome"
  encToks      := encOutcomeSeq
  parseToks    := parseOutcomeToks
  hTagValid    := checkValidTokenBool_sound (by decide)
  hToksValid   := fun out =>
    let ⟨h1, hv⟩ := encOutcomeSeq_valid out
    ⟨by intro he; rw [he] at h1; simp at h1, hv⟩
  hParsePrefix := parseOutcomeToks_enc

/-! ### 11. `PO-DIFF-03` (`Span Unit Integrity`) Core Lemmas -/

theorem asciiByteToChar_utf8_len_one (b : UInt8) (hb : IsPrintableAsciiByte b) :
    utf8ByteLenOfChar (asciiByteToChar b) = 1 := by
  rcases b with ⟨⟨v, _⟩⟩
  rcases hb with ⟨_, hhi⟩
  have hv_hi : v ≤ 0x7E := hhi
  unfold asciiByteToChar utf8ByteLenOfChar
  have htn : (Char.ofNat v).toNat = v := by
    unfold Char.ofNat Char.toNat
    have hvalid : v.isValidChar := by unfold Nat.isValidChar; omega
    rw [dif_pos hvalid]
    rfl
  dsimp only [UInt8.toNat, BitVec.toNat]
  rw [htn]
  have h7f : v ≤ 0x7F := by omega
  simp [h7f]

/--
  **`PO-DIFF-03a` (`ASCII Domain Byte-Codepoint Unit Identity`)**:
  For every `rawBytes` in `P3-B`'s supported `StrictAsciiDomainSupported` domain,
  the decoded Unicode character list has `cpLen = rawBytes.length` AND `utf8ByteLen = rawBytes.length`!
-/
theorem strictAscii_byte_eq_codepoint_length (bs : List UInt8)
    (hdom : StrictAsciiDomainSupported bs) :
    (decodeAsciiBytes bs).toList.length = bs.length ∧
    utf8ByteLenOfChars (decodeAsciiBytes bs).toList = bs.length := by
  rcases hdom with ⟨hpos, hall⟩
  clear hpos
  unfold decodeAsciiBytes
  rw [String.toList_ofList, List.length_map]
  refine ⟨rfl, ?_⟩
  induction bs with
  | nil => rfl
  | cons b rest ih =>
    simp only [List.map_cons, utf8ByteLenOfChars, List.length_cons]
    have hb : IsPrintableAsciiByte b := hall b (List.Mem.head rest)
    rw [asciiByteToChar_utf8_len_one b hb]
    rw [ih (fun x hx => hall x (List.Mem.tail b hx))]
    omega

/- Tree span structural boundary check (`0 ≤ startCp ≤ endCp ≤ docCpLen` & children inside parent). -/
mutual
  def checkArgSpansWithin (parentSpan : CodepointSpan) : List ConcreteParseArg → Bool
    | [] => true
    | .litTok _ sp :: rs =>
      (parentSpan.startCp ≤ sp.startCp) && (sp.startCp ≤ sp.endCp) &&
      (sp.endCp ≤ parentSpan.endCp) && checkArgSpansWithin parentSpan rs
    | .slotTok _ _ _ _ sp :: rs =>
      (parentSpan.startCp ≤ sp.startCp) && (sp.startCp ≤ sp.endCp) &&
      (sp.endCp ≤ parentSpan.endCp) && checkArgSpansWithin parentSpan rs
    | .childSub sub :: rs =>
      checkTreeSpansWithin parentSpan.startCp parentSpan.endCp sub &&
      checkArgSpansWithin parentSpan rs

  def checkTreeSpansWithin (minCp maxCp : Nat) : ConcreteParseTree → Bool
    | .mkTree _ _ _ sp args =>
      (minCp ≤ sp.startCp) && (sp.startCp ≤ sp.endCp) && (sp.endCp ≤ maxCp) &&
      checkArgSpansWithin sp args
end

end PneumaOmega.P3C.DifferentialR1
