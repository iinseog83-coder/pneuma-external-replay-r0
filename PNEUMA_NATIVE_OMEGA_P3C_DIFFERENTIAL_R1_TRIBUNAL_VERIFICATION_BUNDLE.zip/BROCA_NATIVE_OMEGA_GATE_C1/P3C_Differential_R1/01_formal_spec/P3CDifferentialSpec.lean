/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1
  Root export for `P3CDifferentialSpec`
-/
import P3CDifferentialSpec.TypedWireFormatV1
import P3CDifferentialSpec.DifferentialAlgebraSpec
