/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1
  Root export for `P3CDifferentialObligations`
-/
import P3CDifferentialObligations.PO_DIFF_01_To_08
