/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate C`: Canonical Proof Obligations `PO-DIFF-01` ~ `PO-DIFF-08`)
  04_proof_obligations/P3CDifferentialObligations/PO_DIFF_01_To_08.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`, zero `native_decide`)

  Exports the eight kernel-checked obligations of `Gate C` + `Corrigendum R0`:
    - `PO_DIFF_01_SerializationRoundtripAndCanonicalUniqueness`
    - `PO_DIFF_02_EncodingInjectivity`
    - `PO_DIFF_03_SpanUnitIntegrity`
    - `PO_DIFF_04_ExtractionResultFidelity`
    - `PO_DIFF_05_CanonicalMeaningFidelity`
    - `PO_DIFF_06_FiveWayOutcomeSeparation`
    - `PO_DIFF_07_DifferentialScopeSoundness`
    - `PO_DIFF_08_ProvenanceBoundaryPreservation`
  Note (`Charter §2 & Gate C`): `PO-DIFF-09` (`Independent Specification Boundary`) is explicitly
  classified as an external source-dependency & R0-correspondence audit obligation (never falsely
  claimed as discharged by a self-referential Lean tautology!).
-/
import P3CDifferentialAttacks

namespace PneumaOmega.P3C.DifferentialR1.Obligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.DifferentialR1
open PneumaOmega.P3C.DifferentialR1.Attacks

/-! ### `PO-DIFF-01` — Serialization Roundtrip, Canonical Uniqueness & Malformed Rejection (`F-DIFF-P0-01`) -/

theorem PO_DIFF_01_SerializationRoundtripAndCanonicalUniqueness :
    -- 1. Roundtrip `decode(encode x) = .ok x` across all 7 target computational types:
    (∀ sp : CodepointSpan, decodeWire spanWireCodec (encodeWire spanWireCodec sp) = .ok sp) ∧
    (∀ tr : ConcreteParseTree, decodeWire parseTreeWireCodec (encodeWire parseTreeWireCodec tr) = .ok tr) ∧
    (∀ T : List ConcreteParseTree, decodeWire parseForestWireCodec (encodeWire parseForestWireCodec T) = .ok T) ∧
    (∀ m : RawSemanticTerm, decodeWire rawMeaningWireCodec (encodeWire rawMeaningWireCodec m) = .ok m) ∧
    (∀ c : CanonicalMeaning, decodeWire canonicalMeaningWireCodec (encodeWire canonicalMeaningWireCodec c) = .ok c) ∧
    (∀ e : ForestExtractionError, decodeWire forestExtractionErrWireCodec (encodeWire forestExtractionErrWireCodec e) = .ok e) ∧
    (∀ o : SemanticNormOutcome, decodeWire outcomeWireCodec (encodeWire outcomeWireCodec o) = .ok o) ∧
    -- 2. Canonical Encoding Uniqueness (`decode s = .ok x ↔ encode x = s`) & Malformed Wire Rejection:
    (∀ {α : Type} (C : CanonicalWireCodec α) (s : String) (x : α),
       decodeWire C s = .ok x ↔ encodeWire C x = s) ∧
    (∀ {α : Type} (C : CanonicalWireCodec α) (s : String),
       ¬ ValidWireEncoding C s → ∃ err : DecodeRejectDiag, decodeWire C s = .error err) :=
  ⟨encodeWire_decodeWire_roundtrip spanWireCodec,
   encodeWire_decodeWire_roundtrip parseTreeWireCodec,
   encodeWire_decodeWire_roundtrip parseForestWireCodec,
   encodeWire_decodeWire_roundtrip rawMeaningWireCodec,
   encodeWire_decodeWire_roundtrip canonicalMeaningWireCodec,
   encodeWire_decodeWire_roundtrip forestExtractionErrWireCodec,
   encodeWire_decodeWire_roundtrip outcomeWireCodec,
   fun C s x => decodeWire_ok_iff_encodeWire_eq C s x,
   fun C s h => malformed_wire_rejected C s h⟩

/-! ### `PO-DIFF-02` — Encoding Injectivity Across All Observable Computational Types -/

theorem PO_DIFF_02_EncodingInjectivity :
    (∀ x y : CodepointSpan, encodeWire spanWireCodec x = encodeWire spanWireCodec y → x = y) ∧
    (∀ x y : ConcreteParseTree, encodeWire parseTreeWireCodec x = encodeWire parseTreeWireCodec y → x = y) ∧
    (∀ x y : List ConcreteParseTree, encodeWire parseForestWireCodec x = encodeWire parseForestWireCodec y → x = y) ∧
    (∀ x y : RawSemanticTerm, encodeWire rawMeaningWireCodec x = encodeWire rawMeaningWireCodec y → x = y) ∧
    (∀ x y : CanonicalMeaning, encodeWire canonicalMeaningWireCodec x = encodeWire canonicalMeaningWireCodec y → x = y) ∧
    (∀ x y : ForestExtractionError, encodeWire forestExtractionErrWireCodec x = encodeWire forestExtractionErrWireCodec y → x = y) ∧
    (∀ x y : SemanticNormOutcome, encodeWire outcomeWireCodec x = encodeWire outcomeWireCodec y → x = y) :=
  ⟨fun _ _ h => encodeWire_injective spanWireCodec h,
   fun _ _ h => encodeWire_injective parseTreeWireCodec h,
   fun _ _ h => encodeWire_injective parseForestWireCodec h,
   fun _ _ h => encodeWire_injective rawMeaningWireCodec h,
   fun _ _ h => encodeWire_injective canonicalMeaningWireCodec h,
   fun _ _ h => encodeWire_injective forestExtractionErrWireCodec h,
   fun _ _ h => encodeWire_injective outcomeWireCodec h⟩

/-! ### `PO-DIFF-03` — Span Unit Integrity (7-Bit ASCII 1:1 Identity & Multi-Byte UTF-8 Fail-Closed) -/

theorem PO_DIFF_03_SpanUnitIntegrity :
    (∀ bs : List UInt8, StrictAsciiDomainSupported bs →
       (decodeAsciiBytes bs).toList.length = bs.length ∧
       utf8ByteLenOfChars (decodeAsciiBytes bs).toList = bs.length) ∧
    (∀ (bs : List UInt8) (b : UInt8),
       b ∈ bs → 0x80 ≤ b.toNat → ¬ StrictAsciiDomainSupported bs) ∧
    (∀ (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
       (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) (d : OutOfDomainDiag),
       parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d →
       certifySemanticConsensus cat numCfg env budget rawBytes = .upstreamRejected (.outOfDomain d)) :=
  ⟨strictAscii_byte_eq_codepoint_length,
   multibyte_utf8_excluded_and_upstream_failClosed.1,
   multibyte_utf8_excluded_and_upstream_failClosed.2⟩

/-! ### `PO-DIFF-04` — Extraction Result Fidelity Across Normal & Malformed Trees -/

theorem PO_DIFF_04_ExtractionResultFidelity :
    (∀ (env : ScopeEnv) (t : ConcreteParseTree),
       decodeWire singleExtractionResWireCodec
         (encodeWire singleExtractionResWireCodec (extractRawMeaning env t)) =
         .ok (extractRawMeaning env t)) ∧
    (∀ (d : ExtractionFailureDiag) (m : RawSemanticTerm),
       encodeWire singleExtractionResWireCodec (.error d) ≠
         encodeWire singleExtractionResWireCodec (.ok m)) ∧
    (∀ (err : ForestExtractionError),
       decodeWire forestExtractionErrWireCodec (encodeWire forestExtractionErrWireCodec err) = .ok err) ∧
    (∀ (env : ScopeEnv) (T T' : List ConcreteParseTree) (err : ForestExtractionError),
       evalForestPure env T = .semanticExtractionFailure T' err →
       T' = T ∧
       err.failedTree ∈ T ∧
       extractRawMeaning env err.failedTree = .error err.diag ∧
       decodeWire outcomeWireCodec
         (encodeWire outcomeWireCodec (.semanticExtractionFailure T' err)) =
         .ok (.semanticExtractionFailure T err)) :=
  extraction_result_wire_fidelity

/-! ### `PO-DIFF-05` — Canonical Meaning Fidelity & `SemEq` Correspondence -/

theorem PO_DIFF_05_CanonicalMeaningFidelity :
    (∀ c : CanonicalMeaning,
       decodeWire canonicalMeaningWireCodec (encodeWire canonicalMeaningWireCodec c) = .ok c) ∧
    (∀ c₁ c₂ : CanonicalMeaning,
       encodeWire canonicalMeaningWireCodec c₁ = encodeWire canonicalMeaningWireCodec c₂ ↔ c₁ = c₂) ∧
    (∀ m₁ m₂ : RawSemanticTerm,
       encodeWire canonicalMeaningWireCodec (normalizeMeaning m₁) =
         encodeWire canonicalMeaningWireCodec (normalizeMeaning m₂) ↔ SemEq m₁ m₂) ∧
    (∀ m : RawSemanticTerm,
       (observeSemanticInject m).idempotentCanonicalWire = (observeSemanticInject m).canonicalWire) :=
  canonical_meaning_wire_fidelity

/-! ### `PO-DIFF-06` — Five-Way Outcome Separation -/

theorem PO_DIFF_06_FiveWayOutcomeSeparation (o₁ o₂ : SemanticNormOutcome) :
    (outcomeBranchOf o₁ ≠ outcomeBranchOf o₂ →
       encodeWire outcomeWireCodec o₁ ≠ encodeWire outcomeWireCodec o₂) ∧
    (∀ o', decodeWire outcomeWireCodec (encodeWire outcomeWireCodec o₁) = .ok o' →
       o' = o₁ ∧ outcomeBranchOf o' = outcomeBranchOf o₁) :=
  outcome_wire_preserves_five_way_separation o₁ o₂

/-! ### `PO-DIFF-07` — Differential Scope Soundness & 5-Valued Verdict Separation (`F-DIFF-P0-04`) -/

theorem PO_DIFF_07_DifferentialScopeSoundness {α : Type} (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    ((∀ g, compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
             .MATCH_STRUCTURAL g ↔ (grade ≠ .SPEC_UNDEFINED ∧ g = grade ∧ x = y)) ∧
     (grade ≠ .SPEC_UNDEFINED → x ≠ y →
       ∃ locus : String,
         compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
           .MISMATCH_WITNESS stage locus (encodeWire C x) (encodeWire C y)) ∧
     (grade = .SPEC_UNDEFINED →
       compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
         .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held")) := by
  have ⟨hm, hmis⟩ := compareWirePayloads_sound_and_complete C grade r0Anchor stage x y
  refine ⟨hm, hmis, ?_⟩
  intro hundef
  subst hundef
  rfl

/-! ### `PO-DIFF-08` — Provenance R1 Boundary Preservation Across Wire Serialization -/

theorem PO_DIFF_08_ProvenanceBoundaryPreservation (targetCtx claimedCtx : ProvenanceContext)
    (wirePayload : String) :
    ((∀ cert : CertifiedSemanticConsensus targetCtx,
        verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx wirePayload = .ok cert ↔
          claimedCtx = targetCtx ∧
          wirePayload = encodeWire outcomeWireCodec (.consensus cert.trees cert.canonical) ∧
          ExecProvenanceSpec targetCtx cert.trees cert.canonical) ∧
     (claimedCtx ≠ targetCtx →
        ∃ err, verifyDecodedOutcomeWireAgainstProvenance targetCtx claimedCtx wirePayload = .error err)) :=
  provenance_boundary_preserved_across_wire targetCtx claimedCtx wirePayload

/-! ### `Gate D` & `Gate OPT-A..C` Obligations (`F-DIFF-OPT-01` ~ `F-DIFF-OPT-03`) -/

/--
  **`F-DIFF-OPT-01` (`Projection Soundness` — `Gate OPT-A`)**:
  `verdictHead` preserves all three canonical comparator branches (`SPEC_UNDEFINED`,
  `MATCH_STRUCTURAL`, and `MISMATCH_WITNESS`) directly from `compareWirePayloads`.
-/
theorem F_DIFF_OPT_01_ProjectionSoundness {α : Type} [DecidableEq α] (C : CanonicalWireCodec α)
    (grade : OracleEpistemicGrade) (r0Anchor : String) (stage : DiffStage) (x y : α) :
    (verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
      match grade with
      | .SPEC_UNDEFINED => .specificationHeld
      | _               => if x == y then .matchStructural grade else .mismatchWitness stage) ∧
    ((verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
        .specificationHeld ↔
        grade = .SPEC_UNDEFINED ∧
        compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
          .SPECIFICATION_HELD r0Anchor "R0_specification_underspecified_held") ∧
     (∀ g,
        verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
          .matchStructural g ↔
          grade ≠ .SPEC_UNDEFINED ∧ g = grade ∧ x = y ∧
          compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
            .MATCH_STRUCTURAL g) ∧
     (∀ st,
        verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
          .mismatchWitness st ↔
          grade ≠ .SPEC_UNDEFINED ∧ st = stage ∧ x ≠ y)) :=
  ⟨verdictHead_compare_encode C grade r0Anchor stage x y,
   verdictHead_branch_preservation_iff C grade r0Anchor stage x y⟩

/--
  **`F-DIFF-OPT-02` (`Mismatch Witness Fidelity` — `Gate OPT-A`)**:
  Whenever `verdictHead` observes `.mismatchWitness st`, the unprojected `compareWirePayloads`
  preserves exact `firstDivergentTokIdx` locus, distinct canonical wire strings, and lossless
  `decodeWire` recovery of both original Lean values `x` and `y`.
-/
theorem F_DIFF_OPT_02_MismatchWitnessFidelity {α : Type} [DecidableEq α]
    (C : CanonicalWireCodec α) (grade : OracleEpistemicGrade) (r0Anchor : String)
    (stage st : DiffStage) (x y : α)
    (hHead : verdictHead (compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y)) =
               .mismatchWitness st) :
    st = stage ∧
    grade ≠ .SPEC_UNDEFINED ∧
    x ≠ y ∧
    encodeWire C x ≠ encodeWire C y ∧
    compareWirePayloads C grade r0Anchor stage (encodeWire C x) (encodeWire C y) =
      .MISMATCH_WITNESS stage
        (firstDivergentTokIdx 0 ("DIFFV1" :: C.typeTag :: C.encToks x) ("DIFFV1" :: C.typeTag :: C.encToks y))
        (encodeWire C x) (encodeWire C y) ∧
    decodeWire C (encodeWire C x) = .ok x ∧
    decodeWire C (encodeWire C y) = .ok y :=
  compareWirePayloads_mismatch_witness_fidelity C grade r0Anchor stage st x y hHead

/--
  **`F-DIFF-OPT-03` & `Gate D` (`Finite Decision Algebra Equivalence & D13 Literal Decoder`)**:
  All 28 `D01`~`D14` vectors pass on BOTH finite `GateDVerdictTag` and rendered verdict strings,
  with `D13` directly verified by pure kernel `decide` on literal canonical & malformed wires.
-/
theorem PO_DIFF_All28OrthogonalAttackVectorsVerified :
    allDiffAttackCases.length = 28 ∧
    (∀ c ∈ allDiffAttackCases,
      c.passed = true ∧
      c.actualTag = c.expectedTag ∧
      c.actualVerdictTag = c.expectedVerdictTag) ∧
    (eqStrBool (renderGateDTag d13_pc_tag) "VALID_CANONICAL_WIRE_DECODED" = true ∧
     eqStrBool (renderGateDTag d13_ce_tag) "ALL_6_MALFORMED_WIRE_CLASSES_REJECTED" = true) :=
  ⟨allDiffAttackCases_pass.1, allDiffAttackCases_pass.2, d13_literal_decoder_strings_ok⟩

/--
  Explicit Governance & Epistemic Boundary Record (`Charter §2, §6, §7` & `OPT Directive`):
  - `PO-DIFF-09` is audited via external AST/source-dependency & R0 correspondence verification
    (never overclaimed as a self-referential Lean theorem).
  - `F-DIFF-OPT-04`: Empirical timing/memory metrics are recorded; unproven asymptotic kernel
    complexity claims (e.g. global O(1)) remain explicitly `HELD`.
  - `F-P3C-03` (semantic world / extensionality expansion), `P1-C`, `P4`, `P5`,
    `PNEUMA-FINITE-OPERATOR-R0`, and `PNEUMA Speech & Listener` remain `NOT_AUTHORIZED`.
-/
inductive DifferentialR1GovernanceBoundary where
  | f_p3c_02_internal_state_differential_scoped
  | po_diff_09_audited_by_external_dependency_and_r0_trace
  | f_diff_opt_04_asymptotic_complexity_claim_held
  | prop_proof_byte_equality_not_claimed
  | legacy_p3c_authorization_qualified_preserved
  | provenance_r1_scoped_accepted_preserved
  | f_p3c_03_semantic_model_expansion_not_authorized
  | full_r0_semantic_fidelity_and_global_nonbypass_held
  | external_independent_host_replay_held
  | p4_p5_finite_operator_speech_listener_not_authorized
  deriving DecidableEq, Repr

end PneumaOmega.P3C.DifferentialR1.Obligations
