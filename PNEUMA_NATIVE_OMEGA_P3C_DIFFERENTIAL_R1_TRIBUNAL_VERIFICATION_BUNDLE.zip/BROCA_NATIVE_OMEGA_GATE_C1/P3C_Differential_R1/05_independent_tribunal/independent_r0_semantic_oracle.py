#!/usr/bin/env python3
"""
PNEUMA-NATIVE OMEGA — AUTH-P3C-DIFFERENTIAL-R1 (`Path B` Independent R0 Semantic Oracle & `PO-DIFF-09` Audit)
05_independent_tribunal/independent_r0_semantic_oracle.py

Architecture & `Corrigendum R0` Compliance:
  1. `PO-DIFF-09` Independent Specification Boundary:
     - Derives expected `ConcreteParseTree`, `CodepointSpan` (`[startCp, endCp)`), `RawSemanticTerm`,
       `CanonicalMeaning`, `ForestExtractionError`, and `SemanticNormOutcome` directly from declarative
       `Architecture Freeze R0` grammar/semantic tables (`S0-R2`, `S0-R2.1`, `S0-R2.2`, `Gate C0-R1`, `P0-A05`),
       NOT by translating or reading `P3-C` Lean implementation code.
     - Includes an automated AST & file-dependency self-audit (`run_po_diff_09_static_audit`) verifying
       zero imports or file reads of `P3-C` implementation modules during oracle evaluation.
  2. `F-DIFF-P0-02` Epistemic Grades:
     - Attaches `(r0SpecAnchor, epistemicGrade)` (`SPEC_GROUNDED` | `MODEL_ASSUMPTION` | `SPEC_UNDEFINED`)
       to every stage comparison, tallying `MATCH_STRUCTURAL(SPEC_GROUNDED)` strictly separately from
       `MATCH_STRUCTURAL(MODEL_ASSUMPTION)`, and mapping `SPEC_UNDEFINED` to `SPECIFICATION_HELD`.
  3. `F-DIFF-P0-03` Three-Class Separation:
     - Evaluates and reports `SURFACE_E2E` (80 vectors across all `G-01`~`G-16`, `T1`~`T5`, OOD, overflow,
       empty parse, and `SPEC_UNDEFINED` held vectors), `FOREST_INJECT` (12 internal tree/extraction vectors
       covering all 5 `ExtractionFailureDiag` constructors), and `SEMANTIC_INJECT` (12 raw/canonical/idempotence
       vectors) as separate audit classes.
  4. `F-DIFF-P0-04` Closed 5-Valued `DiffVerdict` Algebra:
     - `MATCH_STRUCTURAL(SPEC_GROUNDED)` / `MATCH_STRUCTURAL(MODEL_ASSUMPTION)`
     - `MISMATCH_WITNESS`
     - `ORACLE_FAILURE`
     - `SPECIFICATION_HELD`
     - `RESOURCE_HELD`
"""

from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple, Union

DIFF_R1_ROOT = Path(__file__).resolve().parent.parent
RUNNER_EXE = DIFF_R1_ROOT / ".lake" / "build" / "bin" / "p3c_differential_r1_runner.exe"


# ===========================================================================
# 1. `PO-DIFF-09`: Declarative `Architecture Freeze R0` Rule Correspondence Table
# ===========================================================================

R0_SPEC_CORRESPONDENCE_TABLE: List[Dict[str, str]] = [
    {"ruleId": "G-01", "prod": "Gen_G01_DescIncidence", "r0Anchor": "S0-R2 §III G-01", "semanticCtor": "AtomicClaim.descIncidence", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-01-RC", "prod": "UNSPECIFIED_RIGHT_CENSORED", "r0Anchor": "S0-R2 §III G-01 (KM/AJ)", "semanticCtor": "SPEC_UNDEFINED", "grade": "SPEC_UNDEFINED"},
    {"ruleId": "G-02a", "prod": "Gen_G02a_DescMeanSD", "r0Anchor": "S0-R2.1 §II.2 G-02a", "semanticCtor": "AtomicClaim.descDist(meanSD)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-02b", "prod": "Gen_G02b_DescMedianIQR", "r0Anchor": "S0-R2.1 §II.2 G-02b", "semanticCtor": "AtomicClaim.descDist(medianIQR)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-03", "prod": "Gen_G03_AssocUnadj", "r0Anchor": "S0-R2 §III G-03", "semanticCtor": "AtomicClaim.assocClaim(unadj)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-04", "prod": "Gen_G04_AssocTemp", "r0Anchor": "S0-R2 §III G-04", "semanticCtor": "AtomicClaim.assocClaim(temporalOrder=evA<evB)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-05", "prod": "Gen_G05_CompRD", "r0Anchor": "S0-R2 §III G-05", "semanticCtor": "AtomicClaim.compRD", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-06a", "prod": "Gen_G06a_IntervDirectional", "r0Anchor": "Gate C0-R1 §II.3 F-C0-07", "semanticCtor": "AtomicClaim.intervClaim(directional)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-06b", "prod": "Gen_G06b_IntervNeutral", "r0Anchor": "Gate C0-R1 §II.3 F-C0-07", "semanticCtor": "AtomicClaim.intervClaim(neutralNullIncluded)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-07", "prod": "Gen_G07_MetaNotStatSig", "r0Anchor": "S0-R2 §III G-07", "semanticCtor": "AtomicClaim.metaNotStatSig", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-08", "prod": "Gen_G08_MetaEquiv", "r0Anchor": "S0-R2.1 §II.2 G-08", "semanticCtor": "AtomicClaim.metaEquiv", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-09", "prod": "Gen_G09_MetaNonEstab", "r0Anchor": "S0-R2 §III G-09", "semanticCtor": "AtomicClaim.metaNonEstab", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-10", "prod": "Gen_G10_MetaUnresolved", "r0Anchor": "S0-R2 §III G-10", "semanticCtor": "AtomicClaim.metaUnresolvedPolar", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-11", "prod": "Gen_G11_QuantZero", "r0Anchor": "S0-R2 §III G-11", "semanticCtor": "QuantPredForm.negExistential", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-12", "prod": "Gen_G12_QuantProperPart", "r0Anchor": "S0-R2 §III G-12", "semanticCtor": "QuantPredForm.properPart", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-13", "prod": "Gen_G13_QuantAtLeastOne", "r0Anchor": "S0-R2 §III G-13", "semanticCtor": "QuantPredForm.existentialPos", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-14", "prod": "Gen_G14_AssocAdj", "r0Anchor": "S0-R2 §III G-14", "semanticCtor": "AtomicClaim.assocClaim(covariates)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-15a", "prod": "Gen_G15a_DocConjAtomic", "r0Anchor": "S0-R2.2 §II.4 G-15a", "semanticCtor": "RawSemanticTerm.symConj(sentenceAtomic)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-15b", "prod": "Gen_G15b_DocConjDiscourse", "r0Anchor": "S0-R2.2 §II.4 G-15b", "semanticCtor": "RawSemanticTerm.symConj(discourseBound)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "G-16", "prod": "Gen_G16_DocContrastive", "r0Anchor": "S0-R2 §III G-16", "semanticCtor": "RawSemanticTerm.contrastivePair", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T1", "prod": "Trap_T1_AllNot", "r0Anchor": "P0-A05 §2 T1", "semanticCtor": "Dual(universalNeg | negUniversal)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T2", "prod": "Trap_T2_ConfirmThat", "r0Anchor": "P0-A05 §2 T2 (Y_T08)", "semanticCtor": "Dual(nonFactive [] | factive [Presup])", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T3", "prod": "Trap_T3_WhPresup", "r0Anchor": "P0-A05 §2 T3", "semanticCtor": "Trap(whFactivePresuppositionForbidden)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T4", "prod": "Trap_T4_BarePlural", "r0Anchor": "P0-A05 §2 T4", "semanticCtor": "Dual(genericUniversalPos | existentialPos)", "grade": "SPEC_GROUNDED"},
    {"ruleId": "T5", "prod": "Trap_T5_UnscopedDoc", "r0Anchor": "P0-A05 §2 T5", "semanticCtor": "Trap(unscopedClauseForbidden)", "grade": "SPEC_GROUNDED"},
]


# ===========================================================================
# 2. `PNEUMA-DIFF-SER-V1` Canonical Encoder/Decoder in Python (`F-DIFF-P0-01`)
# ===========================================================================

def enc_nat_tok(n: int) -> str:
    assert n >= 0
    return f"N#{n}"


def enc_str_seq(s: str) -> List[str]:
    cp_len = len(s)
    utf8_len = len(s.encode("utf-8"))
    return ["STR", enc_nat_tok(cp_len), enc_nat_tok(utf8_len)] + [f"C#{ord(ch)}" for ch in s]


def enc_opt_str_seq(o: Optional[str]) -> List[str]:
    if o is None:
        return ["Option.none"]
    return ["Option.some"] + enc_str_seq(o)


def enc_opt_pair_str_seq(o: Optional[Tuple[str, str]]) -> List[str]:
    if o is None:
        return ["Option.none"]
    return ["Option.some"] + enc_str_seq(o[0]) + enc_str_seq(o[1])


def enc_span_seq(start_cp: int, end_cp: int) -> List[str]:
    return ["CodepointSpan.mk", enc_nat_tok(start_cp), enc_nat_tok(end_cp)]


def wrap_wire(type_tag: str, body_toks: Sequence[str]) -> str:
    return ";".join(["DIFFV1", type_tag, *body_toks]) + ";"


@dataclass(frozen=True)
class PyArgLit:
    text: str
    span: Tuple[int, int]


@dataclass(frozen=True)
class PyArgSlot:
    sort_name: str
    tag_name: str
    entity_id: str
    lexeme: str
    span: Tuple[int, int]


@dataclass(frozen=True)
class PyArgChild:
    tree: "PyParseTree"


PyParseArg = Union[PyArgLit, PyArgSlot, PyArgChild]


@dataclass(frozen=True)
class PyParseTree:
    prod: str
    reading_alt: int
    locus: str  # "clause1" | "clause2"
    span: Tuple[int, int]
    args: Tuple[PyParseArg, ...]


def enc_parse_arg_seq(a: PyParseArg) -> List[str]:
    if isinstance(a, PyArgLit):
        return ["ConcreteParseArg.litTok"] + enc_str_seq(a.text) + enc_span_seq(*a.span)
    if isinstance(a, PyArgSlot):
        return [
            "ConcreteParseArg.slotTok",
            f"P3SlotSort.{a.sort_name}",
            f"BNFSlotTag.{a.tag_name}",
            *enc_str_seq(a.entity_id),
            *enc_str_seq(a.lexeme),
            *enc_span_seq(*a.span),
        ]
    return ["ConcreteParseArg.childSub"] + enc_parse_tree_seq(a.tree)


def enc_parse_arg_list_seq(args: Sequence[PyParseArg]) -> List[str]:
    out: List[str] = []
    for a in args:
        out.append("ArgList.cons")
        out.extend(enc_parse_arg_seq(a))
    out.append("ArgList.nil")
    return out


def enc_parse_tree_seq(tr: PyParseTree) -> List[str]:
    return [
        "ConcreteParseTree.mkTree",
        f"FrozenParseProd.{tr.prod}",
        enc_nat_tok(tr.reading_alt),
        f"ClauseLocus.{tr.locus}",
        *enc_span_seq(*tr.span),
        *enc_parse_arg_list_seq(tr.args),
    ]


def enc_forest_seq(trees: Sequence[PyParseTree]) -> List[str]:
    out: List[str] = []
    for t in trees:
        out.append("Forest.cons")
        out.extend(enc_parse_tree_seq(t))
    out.append("Forest.nil")
    return out


# Semantic IR representations:
@dataclass(frozen=True)
class PyPresup:
    active_exp: str
    verb: str
    outcome: str


@dataclass(frozen=True)
class PyAtomicClaim:
    ctor: str
    fields: tuple


@dataclass(frozen=True)
class PyRawScopedAtom:
    scope: Tuple[str, Optional[str]]  # ("cohortBound", cid) or ("unrestrictedPop", None)
    binder: str
    claim: PyAtomicClaim
    presups: Tuple[PyPresup, ...]


@dataclass(frozen=True)
class PyRawSymConj:
    left: "PyRawTerm"
    right: "PyRawTerm"


@dataclass(frozen=True)
class PyRawContrastive:
    assoc_side: "PyRawTerm"
    meta_side: "PyRawTerm"
    shared_exp: str
    shared_out: str


PyRawTerm = Union[PyRawScopedAtom, PyRawSymConj, PyRawContrastive]


@dataclass(frozen=True)
class PyNormAtom:
    scope: Tuple[str, Optional[str]]
    claim: PyAtomicClaim
    presups: Tuple[PyPresup, ...]


@dataclass(frozen=True)
class PyNormContrastive:
    assoc_items: Tuple["PyNormItem", ...]
    meta_items: Tuple["PyNormItem", ...]
    shared_exp: str
    shared_out: str


PyNormItem = Union[PyNormAtom, PyNormContrastive]


def enc_scope_seq(sc: Tuple[str, Optional[str]]) -> List[str]:
    if sc[0] == "unrestrictedPop":
        return ["SemanticScope.unrestrictedPop"]
    assert sc[1] is not None
    return ["SemanticScope.cohortBound"] + enc_str_seq(sc[1])


def enc_presup_list_seq(ps: Sequence[PyPresup]) -> List[str]:
    out: List[str] = []
    for p in ps:
        out.extend([
            "PresupList.cons",
            "PresupItem.factiveCausal",
            *enc_str_seq(p.active_exp),
            *enc_str_seq(p.verb),
            *enc_str_seq(p.outcome),
        ])
    out.append("PresupList.nil")
    return out


def enc_atomic_claim_seq(cl: PyAtomicClaim) -> List[str]:
    c = cl.ctor
    f = cl.fields
    if c == "descIncidence":
        w, e, k, n, p = f
        return ["AtomicClaim.descIncidence", *enc_str_seq(w), *enc_str_seq(e), *enc_str_seq(k), *enc_str_seq(n), *enc_str_seq(p)]
    if c == "descDist":
        kind, m, est, d1, d2o = f
        return ["AtomicClaim.descDist", f"DistStatKind.{kind}", *enc_str_seq(m), *enc_str_seq(est), *enc_str_seq(d1), *enc_opt_str_seq(d2o)]
    if c == "assocClaim":
        met, dirc, act, ref, out, cov_o, tmp_o, est, ci_l, ci_lo, ci_hi = f
        return [
            "AtomicClaim.assocClaim",
            *enc_str_seq(met), *enc_str_seq(dirc), *enc_str_seq(act), *enc_str_seq(ref), *enc_str_seq(out),
            *enc_opt_str_seq(cov_o), *enc_opt_pair_str_seq(tmp_o),
            *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi),
        ]
    if c == "compRD":
        act, ref, out, est, ci_l, ci_lo, ci_hi = f
        return [
            "AtomicClaim.compRD",
            *enc_str_seq(act), *enc_str_seq(ref), *enc_str_seq(out),
            *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi),
        ]
    if c == "intervClaim":
        mod_kind, mod_vb, assump, met, act, ref, out, est, ci_l, ci_lo, ci_hi, pv_o = f
        mod_toks = (["IntervModality.directional", *enc_str_seq(mod_vb)]
                    if mod_kind == "directional" else ["IntervModality.neutralNullIncluded"])
        return [
            "AtomicClaim.intervClaim",
            *mod_toks, *enc_str_seq(assump), *enc_str_seq(met), *enc_str_seq(act), *enc_str_seq(ref),
            *enc_str_seq(out), *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi),
            *enc_opt_str_seq(pv_o),
        ]
    if c == "metaNotStatSig":
        met, act, ref, out, est, ci_l, ci_lo, ci_hi, al = f
        return [
            "AtomicClaim.metaNotStatSig",
            *enc_str_seq(met), *enc_str_seq(act), *enc_str_seq(ref), *enc_str_seq(out),
            *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi), *enc_str_seq(al),
        ]
    if c == "metaEquiv":
        met, act, ref, out, m_lo, m_hi, est, ci_l, ci_lo, ci_hi = f
        return [
            "AtomicClaim.metaEquiv",
            *enc_str_seq(met), *enc_str_seq(act), *enc_str_seq(ref), *enc_str_seq(out),
            *enc_str_seq(m_lo), *enc_str_seq(m_hi),
            *enc_str_seq(est), *enc_str_seq(ci_l), *enc_str_seq(ci_lo), *enc_str_seq(ci_hi),
        ]
    if c in {"metaNonEstab", "metaUnresolvedPolar"}:
        src, act, vb, out = f
        return [f"AtomicClaim.{c}", *enc_str_seq(src), *enc_str_seq(act), *enc_str_seq(vb), *enc_str_seq(out)]
    if c == "metaWhUnresolved":
        src, ep, wh, act, vb, out = f
        return [
            "AtomicClaim.metaWhUnresolved",
            *enc_str_seq(src), *enc_str_seq(ep), *enc_str_seq(wh),
            *enc_str_seq(act), *enc_str_seq(vb), *enc_str_seq(out),
        ]
    if c == "quantClaim":
        qkind, sg, ev = f
        return ["AtomicClaim.quantClaim", f"QuantPredForm.{qkind}", *enc_str_seq(sg), *enc_str_seq(ev)]
    raise ValueError(f"Unknown AtomicClaim ctor: {c}")


def enc_raw_term_seq(m: PyRawTerm) -> List[str]:
    if isinstance(m, PyRawScopedAtom):
        return [
            "RawSemanticTerm.scopedAtom",
            *enc_scope_seq(m.scope),
            *enc_str_seq(m.binder),
            *enc_atomic_claim_seq(m.claim),
            *enc_presup_list_seq(m.presups),
        ]
    if isinstance(m, PyRawSymConj):
        return ["RawSemanticTerm.symConj", *enc_raw_term_seq(m.left), *enc_raw_term_seq(m.right)]
    return [
        "RawSemanticTerm.contrastivePair",
        *enc_raw_term_seq(m.assoc_side),
        *enc_raw_term_seq(m.meta_side),
        *enc_str_seq(m.shared_exp),
        *enc_str_seq(m.shared_out),
    ]


def enc_norm_item_seq(it: PyNormItem) -> List[str]:
    if isinstance(it, PyNormAtom):
        return ["NormItem.normAtom", *enc_scope_seq(it.scope), *enc_atomic_claim_seq(it.claim), *enc_presup_list_seq(it.presups)]
    return [
        "NormItem.normContrastive",
        *enc_norm_item_list_seq(it.assoc_items),
        *enc_norm_item_list_seq(it.meta_items),
        *enc_str_seq(it.shared_exp),
        *enc_str_seq(it.shared_out),
    ]


def enc_norm_item_list_seq(items: Sequence[PyNormItem]) -> List[str]:
    out: List[str] = []
    for it in items:
        out.append("NormItemList.cons")
        out.extend(enc_norm_item_seq(it))
    out.append("NormItemList.nil")
    return out


def enc_canonical_seq(items: Sequence[PyNormItem]) -> List[str]:
    return ["CanonicalMeaning.mk", *enc_norm_item_list_seq(items)]


# ===========================================================================
# 3. Declarative `R0` Semantic Normalization & Tie-Break Order (`F-DIFF-P0-02`)
# ===========================================================================

def _pack_nat_field(xs: List[int]) -> List[int]:
    return [len(xs), *xs]


def _enc_str_nats(s: str) -> List[int]:
    return [ord(ch) for ch in s]


def _enc_str_list_nats(ss: Sequence[str]) -> List[int]:
    out: List[int] = []
    for s in ss:
        out.extend(_pack_nat_field(_enc_str_nats(s)))
    return out


def _presup_sort_key(p: PyPresup) -> List[int]:
    return _enc_str_list_nats([p.active_exp, p.verb, p.outcome])


def _scope_sort_key(sc: Tuple[str, Optional[str]]) -> List[int]:
    if sc[0] == "unrestrictedPop":
        return [0]
    assert sc[1] is not None
    return [1, *_enc_str_nats(sc[1])]


def _atomic_sort_key(cl: PyAtomicClaim) -> List[int]:
    c, f = cl.ctor, cl.fields
    if c == "descIncidence":
        return [0, *_enc_str_list_nats(list(f))]
    if c == "descDist":
        k, m, est, d1, d2o = f
        kt = 0 if k == "meanSD" else 1
        opt = ["0"] if d2o is None else ["1", d2o]
        return [1, kt, *_enc_str_list_nats([m, est, d1, *opt])]
    if c == "assocClaim":
        met, dirc, act, ref, out, cov_o, tmp_o, est, ci_l, ci_lo, ci_hi = f
        co = ["0"] if cov_o is None else ["1", cov_o]
        to = ["0", "", ""] if tmp_o is None else ["1", tmp_o[0], tmp_o[1]]
        return [2, *_enc_str_list_nats([met, dirc, act, ref, out, est, ci_l, ci_lo, ci_hi, *co, *to])]
    if c == "compRD":
        return [3, *_enc_str_list_nats(list(f))]
    if c == "intervClaim":
        mk, mvb, assump, met, act, ref, out, est, ci_l, ci_lo, ci_hi, pv_o = f
        po = ["0"] if pv_o is None else ["1", pv_o]
        if mk == "directional":
            return [4, 0, *_enc_str_list_nats([mvb, assump, met, act, ref, out, est, ci_l, ci_lo, ci_hi, *po])]
        return [4, 1, *_enc_str_list_nats([assump, met, act, ref, out, est, ci_l, ci_lo, ci_hi, *po])]
    if c == "metaNotStatSig":
        return [5, *_enc_str_list_nats(list(f))]
    if c == "metaEquiv":
        return [6, *_enc_str_list_nats(list(f))]
    if c == "metaNonEstab":
        return [7, *_enc_str_list_nats(list(f))]
    if c == "metaUnresolvedPolar":
        return [8, *_enc_str_list_nats(list(f))]
    if c == "metaWhUnresolved":
        return [9, *_enc_str_list_nats(list(f))]
    if c == "quantClaim":
        qk, sg, ev = f
        qt_map = {
            "universalNeg": 0, "negExistential": 1, "negUniversal": 2,
            "properPart": 3, "existentialPos": 4, "genericUniversalPos": 5,
        }
        return [10, qt_map[qk], *_enc_str_list_nats([sg, ev])]
    raise ValueError(c)


def _norm_item_sort_key(it: PyNormItem) -> List[int]:
    if isinstance(it, PyNormAtom):
        ps_nats: List[int] = []
        for p in it.presups:
            ps_nats.extend(_pack_nat_field(_presup_sort_key(p)))
        return [0, *_pack_nat_field(_scope_sort_key(it.scope)), *_pack_nat_field(_atomic_sort_key(it.claim)), *ps_nats]
    a_nats: List[int] = []
    for x in it.assoc_items:
        a_nats.extend(_pack_nat_field(_norm_item_sort_key(x)))
    m_nats: List[int] = []
    for x in it.meta_items:
        m_nats.extend(_pack_nat_field(_norm_item_sort_key(x)))
    return [1, *_pack_nat_field(a_nats), *_pack_nat_field(m_nats), *_enc_str_list_nats([it.shared_exp, it.shared_out])]


def r0_normalize_raw_term(m: PyRawTerm) -> Tuple[PyNormItem, ...]:
    """
    Declarative R0 normalizer:
      - Bound variable erased (`SPEC_GROUNDED` α-invariance)
      - De Morgan `universalNeg(sg, ev) -> negExistential(sg, ev)` (`SPEC_GROUNDED` `S0-R2` G-11/T1)
      - Duplicate removal & canonical ordering on presuppositions and `symConj` conjuncts
        (set membership is `SPEC_GROUNDED`; multi-item tie-break order is graded `MODEL_ASSUMPTION`!)
    """
    if isinstance(m, PyRawScopedAtom):
        cl = m.claim
        if cl.ctor == "quantClaim" and cl.fields[0] == "universalNeg":
            cl = PyAtomicClaim("quantClaim", ("negExistential", cl.fields[1], cl.fields[2]))
        dedup_ps = sorted(set(m.presups), key=_presup_sort_key)
        return (PyNormAtom(m.scope, cl, tuple(dedup_ps)),)
    if isinstance(m, PyRawSymConj):
        combined = set(r0_normalize_raw_term(m.left)) | set(r0_normalize_raw_term(m.right))
        return tuple(sorted(combined, key=_norm_item_sort_key))
    a_norm = r0_normalize_raw_term(m.assoc_side)
    m_norm = r0_normalize_raw_term(m.meta_side)
    return (PyNormContrastive(a_norm, m_norm, m.shared_exp, m.shared_out),)


# ===========================================================================
# 4. Independent Declarative `R0` BNF Surface Parser & Span Calculator
# ===========================================================================

CATALOG_TABLE: Dict[str, List[Tuple[str, str]]] = {
    "cohortSpec": [("coh_primary", "the primary cohort")],
    "designNoun": [("des_study", "study")],
    "followUpWindow": [("win_12m", "12 months")],
    "eventTerm": [("ev_stroke", "stroke"), ("ev_aki", "acute kidney injury")],
    "measureTerm": [("meas_sbp", "systolic blood pressure")],
    "expLevel": [("exp_intens", "intensive therapy"), ("exp_std", "standard care")],
    "outTerm": [("out_mi", "myocardial infarction"), ("out_death", "all-cause mortality")],
    "sourceId": [("src_trialA", "Trial-A")],
    "identAssump": [("assump_exch", "conditional exchangeability")],
    "subgroupPlural": [("sub_dm_pl", "diabetic")],
    "subgroupSingular": [("sub_hr_sg", "high-risk")],
    "covariateList": [("cov_age_risk", "age and baseline risk")],
    "assocDir": [("positively", "positively"), ("inversely", "inversely")],
    "ratioMetric": [("rr", "risk ratio"), ("or", "odds ratio"), ("hr", "hazard ratio")],
    "intervDirVerb": [("increase", "increase"), ("reduce", "reduce")],
    "intervVerbPres": [("causes", "causes"), ("increases", "increases"), ("reduces", "reduces")],
    "epistemicVerb": [("establish", "establish"), ("determine", "determine"), ("confirm", "confirm"), ("reveal", "reveal")],
    "whWord": [("why", "why"), ("how", "how")],
}

CANONICAL_DEC_RE = re.compile(r"^-?(?:0|[1-9][0-9]{0,5})(?:\.[0-9]{1,4})?")


def match_bnf_seq(
    text: str,
    pos: int,
    locus: str,
    pattern: Sequence[tuple],
) -> List[Tuple[int, Tuple[PyParseArg, ...], Dict[str, str]]]:
    """
    Declarative left-to-right BNF segment matcher computing exact `[startCp, endCp)` spans!
    """
    if not pattern:
        return [(pos, (), {})]
    head, *tail = pattern
    kind = head[0]
    results: List[Tuple[int, Tuple[PyParseArg, ...], Dict[str, str]]] = []
    if kind == "LIT":
        lit = head[1]
        if text.startswith(lit, pos):
            end_p = pos + len(lit)
            arg = PyArgLit(lit, (pos, end_p))
            for final_p, rest_args, slots in match_bnf_seq(text, end_p, locus, tail):
                results.append((final_p, (arg, *rest_args), slots))
    elif kind == "SLOT":
        sort_name, tag_name = head[1], head[2]
        if sort_name == "numericLit":
            m = CANONICAL_DEC_RE.match(text[pos:])
            if m:
                lex = m.group(0)
                if lex != "-0" and not (lex.startswith("-0.") and all(c == "0" for c in lex[3:])):
                    end_p = pos + len(lex)
                    arg = PyArgSlot("numericLit", tag_name, lex, lex, (pos, end_p))
                    for final_p, rest_args, slots in match_bnf_seq(text, end_p, locus, tail):
                        merged = {tag_name: lex, **slots}
                        results.append((final_p, (arg, *rest_args), merged))
        else:
            for eid, lex in CATALOG_TABLE[sort_name]:
                if text.startswith(lex, pos):
                    end_p = pos + len(lex)
                    arg = PyArgSlot(sort_name, tag_name, eid, lex, (pos, end_p))
                    for final_p, rest_args, slots in match_bnf_seq(text, end_p, locus, tail):
                        merged = {tag_name: eid, **slots}
                        results.append((final_p, (arg, *rest_args), merged))
    elif kind == "SUB":
        sub_fn, sub_locus = head[1], (head[2] if head[2] is not None else locus)
        for end_p, sub_tree in sub_fn(text, pos, sub_locus):
            arg = PyArgChild(sub_tree)
            for final_p, rest_args, slots in match_bnf_seq(text, end_p, locus, tail):
                results.append((final_p, (arg, *rest_args), slots))
    return results


def parse_embedded_causal(text: str, pos: int, locus: str) -> List[Tuple[int, PyParseTree]]:
    pat = [("SLOT", "expLevel", "activeExp"), ("LIT", " "), ("SLOT", "intervVerbPres", "verb"), ("LIT", " "), ("SLOT", "outTerm", "outcome")]
    return [(ep, PyParseTree("Env_EmbeddedCausal", 1, locus, (pos, ep), args)) for ep, args, _ in match_bnf_seq(text, pos, locus, pat)]


LEAF_SPECS: List[Tuple[str, str, int, List[tuple], object]] = [
    ("Gen_G01_DescIncidence", "ATOMIC", 1,
     [("LIT", "over "), ("SLOT", "followUpWindow", "window"), ("LIT", ", the cumulative incidence of "), ("SLOT", "eventTerm", "eventA"),
      ("LIT", " was "), ("SLOT", "numericLit", "numK"), ("LIT", " of "), ("SLOT", "numericLit", "numN"), ("LIT", " patients ("), ("SLOT", "numericLit", "numPct"), ("LIT", "%)")],
     lambda s: True),
    ("Gen_G02a_DescMeanSD", "ATOMIC", 1,
     [("LIT", "the mean "), ("SLOT", "measureTerm", "measure"), ("LIT", " was "), ("SLOT", "numericLit", "numEst"), ("LIT", " (SD "), ("SLOT", "numericLit", "numDisp1"), ("LIT", ")")],
     lambda s: True),
    ("Gen_G02b_DescMedianIQR", "ATOMIC", 1,
     [("LIT", "the median "), ("SLOT", "measureTerm", "measure"), ("LIT", " was "), ("SLOT", "numericLit", "numEst"),
      ("LIT", " (IQR "), ("SLOT", "numericLit", "numDisp1"), ("LIT", " to "), ("SLOT", "numericLit", "numDisp2"), ("LIT", ")")],
     lambda s: True),
    ("Gen_G03_AssocUnadj", "ASSOC", 1,
     [("LIT", "comparing "), ("SLOT", "expLevel", "activeExp"), ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "),
      ("SLOT", "assocDir", "direction"), ("LIT", " associated with "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G04_AssocTemp", "ASSOC", 1,
     [("SLOT", "eventTerm", "eventA"), ("LIT", " preceded "), ("SLOT", "eventTerm", "eventB"), ("LIT", ", and comparing "),
      ("SLOT", "expLevel", "activeExp"), ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "),
      ("SLOT", "assocDir", "direction"), ("LIT", " associated with "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["eventA"] != s["eventB"] and s["activeExp"] != s["refExp"]),
    ("Gen_G05_CompRD", "ATOMIC", 1,
     [("LIT", "the absolute risk difference in "), ("SLOT", "outTerm", "outcome"), ("LIT", " comparing "), ("SLOT", "expLevel", "activeExp"),
      ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "), ("SLOT", "numericLit", "numEst"),
      ("LIT", " percentage points ("), ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G06a_IntervDirectional", "ATOMIC", 1,
     [("LIT", "under "), ("SLOT", "identAssump", "assumption"), ("LIT", ", comparing "), ("SLOT", "expLevel", "activeExp"),
      ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was estimated to "), ("SLOT", "intervDirVerb", "verb"), ("LIT", " "),
      ("SLOT", "outTerm", "outcome"), ("LIT", " ("), ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"),
      ("LIT", ", "), ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "),
      ("SLOT", "numericLit", "numCIHigh"), ("LIT", ", p = "), ("SLOT", "numericLit", "numPVal"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G06b_IntervNeutral", "ATOMIC", 1,
     [("LIT", "under "), ("SLOT", "identAssump", "assumption"), ("LIT", ", the estimated causal "), ("SLOT", "ratioMetric", "metric1"),
      ("LIT", " for "), ("SLOT", "outTerm", "outcome"), ("LIT", " comparing "), ("SLOT", "expLevel", "activeExp"),
      ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "), ("SLOT", "numericLit", "numEst"),
      ("LIT", " ("), ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "),
      ("SLOT", "numericLit", "numCIHigh"), ("LIT", "), which did not exclude no effect")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G07_MetaNotStatSig", "ATOMIC", 1,
     [("LIT", "the observed "), ("SLOT", "ratioMetric", "metric1"), ("LIT", " comparing "), ("SLOT", "expLevel", "activeExp"),
      ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " for "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric2"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "),
      ("SLOT", "numericLit", "numCIHigh"), ("LIT", ") was not statistically significant at alpha = "), ("SLOT", "numericLit", "numAlpha")],
     lambda s: s["metric1"] == s["metric2"] and s["activeExp"] != s["refExp"]),
    ("Gen_G08_MetaEquiv", "ATOMIC", 1,
     [("LIT", "comparing "), ("SLOT", "expLevel", "activeExp"), ("LIT", " versus "), ("SLOT", "expLevel", "refExp"),
      ("LIT", " met prespecified equivalence margins ("), ("SLOT", "numericLit", "numMarginLow"), ("LIT", " to "),
      ("SLOT", "numericLit", "numMarginHigh"), ("LIT", ") for "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% TOST CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Gen_G09_MetaNonEstab", "META", 1,
     [("LIT", "the analysis of "), ("SLOT", "sourceId", "source"), ("LIT", " did not establish that "), ("SUB", parse_embedded_causal, None)],
     lambda s: True),
    ("Gen_G10_MetaUnresolved", "ATOMIC", 1,
     [("LIT", "the analysis of "), ("SLOT", "sourceId", "source"), ("LIT", " did not determine whether "), ("SUB", parse_embedded_causal, None)],
     lambda s: True),
    ("Gen_G11_QuantZero", "ATOMIC", 1,
     [("LIT", "no "), ("SLOT", "subgroupPlural", "subgroup"), ("LIT", " patients developed "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
    ("Gen_G12_QuantProperPart", "ATOMIC", 1,
     [("LIT", "some, but not all, "), ("SLOT", "subgroupPlural", "subgroup"), ("LIT", " patients developed "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
    ("Gen_G13_QuantAtLeastOne", "ATOMIC", 1,
     [("LIT", "at least one "), ("SLOT", "subgroupSingular", "subgroup"), ("LIT", " patient developed "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
    ("Gen_G14_AssocAdj", "ASSOC", 1,
     [("LIT", "after adjustment for "), ("SLOT", "covariateList", "covariates"), ("LIT", ", comparing "),
      ("SLOT", "expLevel", "activeExp"), ("LIT", " versus "), ("SLOT", "expLevel", "refExp"), ("LIT", " was "),
      ("SLOT", "assocDir", "direction"), ("LIT", " associated with "), ("SLOT", "outTerm", "outcome"), ("LIT", " ("),
      ("SLOT", "ratioMetric", "metric1"), ("LIT", " = "), ("SLOT", "numericLit", "numEst"), ("LIT", ", "),
      ("SLOT", "numericLit", "numCILevel"), ("LIT", "% CI "), ("SLOT", "numericLit", "numCILow"), ("LIT", " to "), ("SLOT", "numericLit", "numCIHigh"), ("LIT", ")")],
     lambda s: s["activeExp"] != s["refExp"]),
    ("Trap_T1_AllNot", "TRAP", 2,
     [("LIT", "all "), ("SLOT", "subgroupPlural", "subgroup"), ("LIT", " patients did not develop "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
    ("Trap_T2_ConfirmThat", "TRAP", 2,
     [("LIT", "the analysis of "), ("SLOT", "sourceId", "source"), ("LIT", " did not confirm that "), ("SUB", parse_embedded_causal, None)],
     lambda s: True),
    ("Trap_T3_WhPresup", "TRAP", 1,
     [("LIT", "the analysis of "), ("SLOT", "sourceId", "source"), ("LIT", " did not "), ("SLOT", "epistemicVerb", "verb"),
      ("LIT", " "), ("SLOT", "whWord", "whComp"), ("LIT", " "), ("SUB", parse_embedded_causal, None)],
     lambda s: True),
    ("Trap_T4_BarePlural", "TRAP", 2,
     [("SLOT", "subgroupPlural", "subgroup"), ("LIT", " patients developed "), ("SLOT", "eventTerm", "eventA")],
     lambda s: True),
]


def _parse_by_cat(cat: str, text: str, pos: int, locus: str) -> List[Tuple[int, PyParseTree]]:
    out: List[Tuple[int, PyParseTree]] = []
    # Match exact declaration order in `allFrozenParseProds`:
    if cat == "ATOMIC":
        for ep, tr in _parse_by_cat("ASSOC", text, pos, locus):
            out.append((ep, PyParseTree("Env_LiftAssoc", 1, locus, (pos, ep), (PyArgChild(tr),))))
        for ep, tr in _parse_by_cat("META", text, pos, locus):
            out.append((ep, PyParseTree("Env_LiftMeta", 1, locus, (pos, ep), (PyArgChild(tr),))))
    for prod, pcat, alt_cnt, pat, side_fn in LEAF_SPECS:
        if pcat != cat:
            continue
        for ep, args, slots in match_bnf_seq(text, pos, locus, pat):
            if side_fn(slots):
                for alt in range(1, alt_cnt + 1):
                    out.append((ep, PyParseTree(prod, alt, locus, (pos, ep), args)))
    return out


def _extract_exp_out_pair(tr: PyParseTree) -> Optional[Tuple[str, str]]:
    slots = {a.tag_name: a.entity_id for a in tr.args if isinstance(a, PyArgSlot)}
    if tr.prod in {"Gen_G03_AssocUnadj", "Gen_G04_AssocTemp", "Gen_G14_AssocAdj"}:
        return (slots["activeExp"], slots["outcome"])
    if tr.prod == "Gen_G09_MetaNonEstab":
        emb = [a.tree for a in tr.args if isinstance(a, PyArgChild)][0]
        eslots = {a.tag_name: a.entity_id for a in emb.args if isinstance(a, PyArgSlot)}
        return (eslots["activeExp"], eslots["outcome"])
    for a in tr.args:
        if isinstance(a, PyArgChild):
            sub_p = _extract_exp_out_pair(a.tree)
            if sub_p is not None:
                return sub_p
    return None


def parse_document_r0(text: str, env_mode: str) -> List[PyParseTree]:
    n = len(text)
    cohort_req = "coh_primary"
    design_req = "des_study"
    docs: List[PyParseTree] = []

    def p_scoped_initial(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "In "), ("SLOT", "cohortSpec", "cohort"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("ATOMIC", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedInitial", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["cohort"] == cohort_req]

    def p_scoped_repeat(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "Within this same "), ("SLOT", "designNoun", "design"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("ATOMIC", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedRepeat", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["design"] == design_req]

    def p_scoped_assoc(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "In "), ("SLOT", "cohortSpec", "cohort"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("ASSOC", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedAssoc", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["cohort"] == cohort_req]

    def p_scoped_contrast_meta(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "within this same "), ("SLOT", "designNoun", "design"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("META", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedContrastMeta", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["design"] == design_req]

    def p_scoped_trap(t: str, p: int, loc: str) -> List[Tuple[int, PyParseTree]]:
        pat = [("LIT", "In "), ("SLOT", "cohortSpec", "cohort"), ("LIT", ", "), ("SUB", lambda tx, px, lc: _parse_by_cat("TRAP", tx, px, lc), None)]
        return [(ep, PyParseTree("Env_ScopedTrap", 1, loc, (p, ep), args))
                for ep, args, sl in match_bnf_seq(t, p, loc, pat) if sl["cohort"] == cohort_req]

    # Order matching `allFrozenParseProds`:
    # 1. Env_DocSingle
    for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_initial, "clause1"), ("LIT", ".")]):
        if ep == n:
            docs.append(PyParseTree("Env_DocSingle", 1, "clause1", (0, n), args))
    # 2. Gen_G15a_DocConjAtomic
    if env_mode == "atomic":
        for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_initial, "clause1"), ("LIT", ". "), ("SUB", p_scoped_initial, "clause2"), ("LIT", ".")]):
            if ep == n:
                docs.append(PyParseTree("Gen_G15a_DocConjAtomic", 1, "clause1", (0, n), args))
    # 3. Gen_G15b_DocConjDiscourse
    if env_mode == "discourse":
        for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_initial, "clause1"), ("LIT", ". "), ("SUB", p_scoped_repeat, "clause2"), ("LIT", ".")]):
            if ep == n:
                docs.append(PyParseTree("Gen_G15b_DocConjDiscourse", 1, "clause1", (0, n), args))
    # 4. Gen_G16_DocContrastive (note: in DeclarativeParseSpec, Gen_G16 checks cohort & design, NOT quoteIsolation!)
    for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_assoc, "clause1"), ("LIT", "; however, "), ("SUB", p_scoped_contrast_meta, "clause2"), ("LIT", ".")]):
        if ep == n:
            c1 = args[0].tree  # type: ignore[union-attr]
            c2 = args[2].tree  # type: ignore[union-attr]
            p1, p2 = _extract_exp_out_pair(c1), _extract_exp_out_pair(c2)
            if p1 is not None and p1 == p2:
                docs.append(PyParseTree("Gen_G16_DocContrastive", 1, "clause1", (0, n), args))
    # 5. Env_DocTrapScoped
    for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", p_scoped_trap, "clause1"), ("LIT", ".")]):
        if ep == n:
            docs.append(PyParseTree("Env_DocTrapScoped", 1, "clause1", (0, n), args))
    # 6. Trap_T5_UnscopedDoc
    for ep, args, _ in match_bnf_seq(text, 0, "clause1", [("SUB", lambda tx, px, lc: _parse_by_cat("ATOMIC", tx, px, lc), "clause1"), ("LIT", ".")]):
        if ep == n:
            docs.append(PyParseTree("Trap_T5_UnscopedDoc", 1, "clause1", (0, n), args))

    return docs


# ===========================================================================
# 5. Declarative R0 Tree-to-Meaning Mapping
# ===========================================================================

def r0_extract_leaf(tr: PyParseTree) -> Tuple[PyAtomicClaim, Tuple[PyPresup, ...], Optional[Tuple[str, str]]]:
    s = {a.tag_name: a.entity_id for a in tr.args if isinstance(a, PyArgSlot)}
    ch = [a.tree for a in tr.args if isinstance(a, PyArgChild)]
    p, alt = tr.prod, tr.reading_alt

    if p in {"Env_LiftAssoc", "Env_LiftMeta"}:
        return r0_extract_leaf(ch[0])
    if p == "Gen_G01_DescIncidence":
        return (PyAtomicClaim("descIncidence", (s["window"], s["eventA"], s["numK"], s["numN"], s["numPct"])), (), None)
    if p == "Gen_G02a_DescMeanSD":
        return (PyAtomicClaim("descDist", ("meanSD", s["measure"], s["numEst"], s["numDisp1"], None)), (), None)
    if p == "Gen_G02b_DescMedianIQR":
        return (PyAtomicClaim("descDist", ("medianIQR", s["measure"], s["numEst"], s["numDisp1"], s["numDisp2"])), (), None)
    if p == "Gen_G03_AssocUnadj":
        return (PyAtomicClaim("assocClaim", (s["metric1"], s["direction"], s["activeExp"], s["refExp"], s["outcome"], None, None, s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), (s["activeExp"], s["outcome"]))
    if p == "Gen_G04_AssocTemp":
        return (PyAtomicClaim("assocClaim", (s["metric1"], s["direction"], s["activeExp"], s["refExp"], s["outcome"], None, (s["eventA"], s["eventB"]), s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), (s["activeExp"], s["outcome"]))
    if p == "Gen_G05_CompRD":
        return (PyAtomicClaim("compRD", (s["activeExp"], s["refExp"], s["outcome"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), None)
    if p == "Gen_G06a_IntervDirectional":
        return (PyAtomicClaim("intervClaim", ("directional", s["verb"], s["assumption"], s["metric1"], s["activeExp"], s["refExp"], s["outcome"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"], s["numPVal"])), (), None)
    if p == "Gen_G06b_IntervNeutral":
        return (PyAtomicClaim("intervClaim", ("neutralNullIncluded", "", s["assumption"], s["metric1"], s["activeExp"], s["refExp"], s["outcome"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"], None)), (), None)
    if p == "Gen_G07_MetaNotStatSig":
        return (PyAtomicClaim("metaNotStatSig", (s["metric1"], s["activeExp"], s["refExp"], s["outcome"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"], s["numAlpha"])), (), None)
    if p == "Gen_G08_MetaEquiv":
        return (PyAtomicClaim("metaEquiv", (s["metric1"], s["activeExp"], s["refExp"], s["outcome"], s["numMarginLow"], s["numMarginHigh"], s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), None)
    if p == "Gen_G09_MetaNonEstab":
        es = {a.tag_name: a.entity_id for a in ch[0].args if isinstance(a, PyArgSlot)}
        return (PyAtomicClaim("metaNonEstab", (s["source"], es["activeExp"], es["verb"], es["outcome"])), (), (es["activeExp"], es["outcome"]))
    if p == "Gen_G10_MetaUnresolved":
        es = {a.tag_name: a.entity_id for a in ch[0].args if isinstance(a, PyArgSlot)}
        return (PyAtomicClaim("metaUnresolvedPolar", (s["source"], es["activeExp"], es["verb"], es["outcome"])), (), None)
    if p == "Gen_G11_QuantZero":
        return (PyAtomicClaim("quantClaim", ("negExistential", s["subgroup"], s["eventA"])), (), None)
    if p == "Gen_G12_QuantProperPart":
        return (PyAtomicClaim("quantClaim", ("properPart", s["subgroup"], s["eventA"])), (), None)
    if p == "Gen_G13_QuantAtLeastOne":
        return (PyAtomicClaim("quantClaim", ("existentialPos", s["subgroup"], s["eventA"])), (), None)
    if p == "Gen_G14_AssocAdj":
        return (PyAtomicClaim("assocClaim", (s["metric1"], s["direction"], s["activeExp"], s["refExp"], s["outcome"], s["covariates"], None, s["numEst"], s["numCILevel"], s["numCILow"], s["numCIHigh"])), (), (s["activeExp"], s["outcome"]))
    if p == "Trap_T1_AllNot":
        qk = "universalNeg" if alt == 1 else "negUniversal"
        return (PyAtomicClaim("quantClaim", (qk, s["subgroup"], s["eventA"])), (), None)
    if p == "Trap_T2_ConfirmThat":
        es = {a.tag_name: a.entity_id for a in ch[0].args if isinstance(a, PyArgSlot)}
        ps = () if alt == 1 else (PyPresup(es["activeExp"], es["verb"], es["outcome"]),)
        return (PyAtomicClaim("metaNonEstab", (s["source"], es["activeExp"], es["verb"], es["outcome"])), ps, (es["activeExp"], es["outcome"]))
    if p == "Trap_T3_WhPresup":
        es = {a.tag_name: a.entity_id for a in ch[0].args if isinstance(a, PyArgSlot)}
        return (PyAtomicClaim("metaWhUnresolved", (s["source"], s["verb"], s["whComp"], es["activeExp"], es["verb"], es["outcome"])), (PyPresup(es["activeExp"], es["verb"], es["outcome"]),), (es["activeExp"], es["outcome"]))
    if p == "Trap_T4_BarePlural":
        qk = "genericUniversalPos" if alt == 1 else "existentialPos"
        return (PyAtomicClaim("quantClaim", (qk, s["subgroup"], s["eventA"])), (), None)
    raise ValueError(f"Unsupported leaf prod: {p}")


def r0_extract_doc(tr: PyParseTree, cohort_id: str = "coh_primary") -> PyRawTerm:
    ch = [a.tree for a in tr.args if isinstance(a, PyArgChild)]

    def ext_scoped(sc_tr: PyParseTree) -> Tuple[PyRawScopedAtom, Optional[Tuple[str, str]]]:
        sub = [a.tree for a in sc_tr.args if isinstance(a, PyArgChild)][0]
        cl, ps, anc = r0_extract_leaf(sub)
        if sc_tr.prod in {"Env_ScopedInitial", "Env_ScopedAssoc", "Env_ScopedTrap"}:
            ss = {a.tag_name: a.entity_id for a in sc_tr.args if isinstance(a, PyArgSlot)}
            return (PyRawScopedAtom(("cohortBound", ss["cohort"]), "x_init", cl, ps), anc)
        return (PyRawScopedAtom(("cohortBound", cohort_id), "y_repeat", cl, ps), anc)

    if tr.prod in {"Env_DocSingle", "Env_DocTrapScoped"}:
        m1, _ = ext_scoped(ch[0])
        return m1
    if tr.prod in {"Gen_G15a_DocConjAtomic", "Gen_G15b_DocConjDiscourse"}:
        m1, _ = ext_scoped(ch[0])
        m2, _ = ext_scoped(ch[1])
        return PyRawSymConj(m1, m2)
    if tr.prod == "Gen_G16_DocContrastive":
        m1, anc1 = ext_scoped(ch[0])
        m2, _ = ext_scoped(ch[1])
        assert anc1 is not None
        return PyRawContrastive(m1, m2, anc1[0], anc1[1])
    if tr.prod == "Trap_T5_UnscopedDoc":
        cl, ps, _ = r0_extract_leaf(ch[0])
        return PyRawScopedAtom(("unrestrictedPop", None), "u_unscoped", cl, ps)
    raise ValueError(f"Unsupported doc prod: {tr.prod}")


def check_trap_diag_r0(tr: PyParseTree) -> Optional[List[str]]:
    if tr.prod == "Trap_T3_WhPresup":
        return ["TrapPolicyDiag.whFactivePresuppositionForbidden"]
    if tr.prod == "Trap_T5_UnscopedDoc":
        return ["TrapPolicyDiag.unscopedClauseForbidden"]
    if tr.prod == "Trap_T1_AllNot":
        return ["TrapPolicyDiag.parserOnlyTrapProduction", "CanonicalRuleId.T1"]
    if tr.prod == "Trap_T2_ConfirmThat":
        return ["TrapPolicyDiag.parserOnlyTrapProduction", "CanonicalRuleId.T2"]
    if tr.prod == "Trap_T4_BarePlural":
        return ["TrapPolicyDiag.parserOnlyTrapProduction", "CanonicalRuleId.T4"]
    sub_diags = [check_trap_diag_r0(a.tree) for a in tr.args if isinstance(a, PyArgChild)]
    for d in sub_diags:
        if d is not None:
            return d
    if tr.prod in {"Env_DocTrapScoped", "Env_ScopedTrap"}:
        return ["TrapPolicyDiag.wrapperTrapEnvelope"]
    return None


def predict_surface_e2e_r0(
    env_mode: str, max_b: int, max_s: int, max_n: int, max_r: int, raw_bytes: bytes
) -> Dict[str, object]:
    # 1. Domain gate (`Gate C0-R1` F-C0-03):
    if len(raw_bytes) == 0:
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.outOfDomain", "OutOfDomainDiag.emptyInput"])
        return {"parseStatus": "OUT_OF_DOMAIN", "cpLen": "NONE", "forestWire": "NONE", "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}
    for b in raw_bytes:
        if b < 0x20 or b > 0x7E:
            out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.outOfDomain", "OutOfDomainDiag.nonPrintableAsciiByte", "UInt8.ofNat", enc_nat_tok(b)])
            return {"parseStatus": "OUT_OF_DOMAIN", "cpLen": "NONE", "forestWire": "NONE", "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}

    # 2. Byte budget gate:
    if len(raw_bytes) > max_b:
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.resourceOverflow", "OverflowReason.maxBytesExceeded", enc_nat_tok(len(raw_bytes)), enc_nat_tok(max_b)])
        return {"parseStatus": "RESOURCE_OVERFLOW", "cpLen": "NONE", "forestWire": "NONE", "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}

    text = raw_bytes.decode("ascii")
    trees = parse_document_r0(text, env_mode)
    if len(trees) > max_r:
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.resourceOverflow", "OverflowReason.maxReadingsExceeded", enc_nat_tok(len(trees)), enc_nat_tok(max_r)])
        return {"parseStatus": "RESOURCE_OVERFLOW", "cpLen": "NONE", "forestWire": "NONE", "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}

    forest_w = wrap_wire("ParseForest", enc_forest_seq(trees))
    if not trees:
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.upstreamRejected", "UpstreamParseDiag.emptyParseSet"])
        return {"parseStatus": "ENUMERATED", "cpLen": str(len(text)), "forestWire": forest_w, "extWires": "NONE", "canonWires": "NONE", "outcomeWire": out_w}

    raw_terms = [r0_extract_doc(t) for t in trees]
    norm_list = [r0_normalize_raw_term(m) for m in raw_terms]
    ext_wires = "|".join(wrap_wire("SingleExtractionResult", ["Except.ok", *enc_raw_term_seq(m)]) for m in raw_terms)
    canon_wires = "|".join(wrap_wire("CanonicalMeaning", enc_canonical_seq(nm)) for nm in norm_list)

    # Check consensus vs ambiguity:
    t1, m1, c1 = trees[0], raw_terms[0], norm_list[0]
    divergent = None
    for t2, m2, c2 in zip(trees[1:], raw_terms[1:], norm_list[1:]):
        if c1 != c2:
            divergent = (t1, t2, m1, m2, c1, c2)
            break

    if divergent is not None:
        dt1, dt2, dm1, dm2, dc1, dc2 = divergent
        amb_seq = [
            "AmbiguityRefutationWitness.mk",
            *enc_parse_tree_seq(dt1), *enc_parse_tree_seq(dt2),
            *enc_raw_term_seq(dm1), *enc_raw_term_seq(dm2),
            *enc_canonical_seq(dc1), *enc_canonical_seq(dc2),
        ]
        out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.ambiguousReadings", *enc_forest_seq(trees), *amb_seq])
    else:
        trap_d = None
        for t in trees:
            trap_d = check_trap_diag_r0(t)
            if trap_d is not None:
                break
        if trap_d is not None:
            out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.trapPolicyRejected", *enc_forest_seq(trees), *enc_canonical_seq(c1), *trap_d])
        else:
            out_w = wrap_wire("SemanticNormOutcome", ["SemanticNormOutcome.consensus", *enc_forest_seq(trees), *enc_canonical_seq(c1)])

    return {
        "parseStatus": "ENUMERATED",
        "cpLen": str(len(text)),
        "forestWire": forest_w,
        "extWires": ext_wires,
        "canonWires": canon_wires,
        "outcomeWire": out_w,
    }


# ===========================================================================
# 6. Build 60-Vector `SURFACE_E2E` Corpus (+ `SPEC_UNDEFINED` & `RESOURCE_HELD`)
# ===========================================================================

SURFACE_VECTORS: List[Tuple[str, str, str, str, int, int, int, int, bytes]] = [
    # (vecId, r0Anchor, grade, envMode, maxB, maxS, maxN, maxR, rawBytes)
    ("SURF-01-G01", "S0-R2 §III G-01", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%)."),
    ("SURF-02-G02a", "S0-R2.1 §II.2 G-02a", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the mean systolic blood pressure was 132.4 (SD 14.2)."),
    ("SURF-03-G02b", "S0-R2.1 §II.2 G-02b", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the median systolic blood pressure was 130 (IQR 121 to 141)."),
    ("SURF-04-G03-INV", "S0-R2 §III G-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    ("SURF-05-G03-POS", "S0-R2 §III G-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care was positively associated with all-cause mortality (odds ratio = 1.18, 95% CI 1.02 to 1.37)."),
    ("SURF-06-G04-AB", "S0-R2 §III G-04", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, stroke preceded acute kidney injury, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    ("SURF-07-G04-BA", "S0-R2 §III G-04", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, acute kidney injury preceded stroke, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    ("SURF-08-G05-RD", "S0-R2 §III G-05", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the absolute risk difference in myocardial infarction comparing intensive therapy versus standard care was -3.2 percentage points (95% CI -5.1 to -1.3)."),
    ("SURF-09-G06a-RED", "Gate C0-R1 §II.3 F-C0-07", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, under conditional exchangeability, comparing intensive therapy versus standard care was estimated to reduce myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92, p = 0.006)."),
    ("SURF-10-G06a-INC", "Gate C0-R1 §II.3 F-C0-07", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, under conditional exchangeability, comparing intensive therapy versus standard care was estimated to increase all-cause mortality (risk ratio = 1.24, 95% CI 1.05 to 1.46, p = 0.012)."),
    ("SURF-11-G06b-NEUT", "Gate C0-R1 §II.3 F-C0-07", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, under conditional exchangeability, the estimated causal hazard ratio for myocardial infarction comparing intensive therapy versus standard care was 0.98 (95% CI 0.81 to 1.19), which did not exclude no effect."),
    ("SURF-12-G07-NOTSIG", "S0-R2 §III G-07", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (hazard ratio = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = 0.05."),
    ("SURF-13-G08-EQUIV", "S0-R2.1 §II.2 G-08", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care met prespecified equivalence margins (0.80 to 1.25) for myocardial infarction (hazard ratio = 0.99, 90% TOST CI 0.84 to 1.16)."),
    ("SURF-14-G09-NONESTAB", "S0-R2 §III G-09", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
    ("SURF-15-G10-WHETHER", "S0-R2 §III G-10", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not determine whether intensive therapy reduces myocardial infarction."),
    ("SURF-16-G11-ZERO", "S0-R2 §III G-11", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, no diabetic patients developed stroke."),
    ("SURF-17-G12-PROPER", "S0-R2 §III G-12", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, some, but not all, diabetic patients developed stroke."),
    ("SURF-18-G13-EXIST", "S0-R2 §III G-13", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, at least one high-risk patient developed acute kidney injury."),
    ("SURF-19-G14-ADJ", "S0-R2 §III G-14", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, after adjustment for age and baseline risk, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    ("SURF-20-G15a-AB", "S0-R2.2 §II.4 G-15a", "MODEL_ASSUMPTION", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, no diabetic patients developed stroke. In the primary cohort, at least one high-risk patient developed acute kidney injury."),
    ("SURF-21-G15b-BA", "S0-R2.2 §II.4 G-15b", "MODEL_ASSUMPTION", "discourse", 512, 4000, 512, 16,
     b"In the primary cohort, at least one high-risk patient developed acute kidney injury. Within this same study, no diabetic patients developed stroke."),
    ("SURF-22-G16-CONTRAST", "S0-R2 §III G-16", "SPEC_GROUNDED", "discourse", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
    ("SURF-23-T1-DUAL", "P0-A05 §2 T1", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, all diabetic patients did not develop stroke."),
    ("SURF-24-T2-DUAL", "P0-A05 §2 T2", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction."),
    ("SURF-25-T3-WH-WHY", "P0-A05 §2 T3", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not determine why intensive therapy reduces myocardial infarction."),
    ("SURF-26-T3-WH-HOW", "P0-A05 §2 T3", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the analysis of Trial-A did not reveal how intensive therapy increases all-cause mortality."),
    ("SURF-27-T4-BARE", "P0-A05 §2 T4", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, diabetic patients developed stroke."),
    ("SURF-28-T5-UNSCOPED", "P0-A05 §2 T5", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"no diabetic patients developed stroke."),
    ("SURF-29-OOD-EMPTY", "Gate C0-R1 §I.3 F-C0-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16, b""),
    ("SURF-30-OOD-UTF8-2B", "Gate C0-R1 §I.3 F-C0-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16, b"In \xc3\xa9"),
    ("SURF-31-OOD-UTF8-3B", "Gate C0-R1 §I.3 F-C0-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16, b"In \xe2\x89\xa4"),
    ("SURF-32-OOD-TAB", "Gate C0-R1 §I.3 F-C0-03", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16, b"In\tthe"),
    ("SURF-33-OVF-BYTES", "Gate C1-P3B ResourceBudget", "SPEC_GROUNDED", "atomic", 16, 4000, 512, 16,
     b"In the primary cohort, no diabetic patients developed stroke."),
    ("SURF-34-OVF-READINGS-T2", "Gate C1-P3B ResourceBudget", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 1,
     b"In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction."),
    ("SURF-35-EMPTY-BAD-NUM", "S0-R2.2 §II.1 Decimal", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (1..25%)."),
    ("SURF-36-EMPTY-G16-BAD-ANC", "S0-R2 §III G-16 checkSide", "SPEC_GROUNDED", "discourse", 512, 4000, 512, 16,
     b"In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality."),
    ("SURF-37-EMPTY-G07-BAD-MET", "S0-R2 §III G-07 checkSide", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (odds ratio = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = 0.05."),
    ("SURF-38-EMPTY-G04-SAME-EV", "S0-R2 §III G-04 checkSide", "SPEC_GROUNDED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, stroke preceded stroke, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
    # Explicit `SPEC_UNDEFINED` cases (`Corrigendum F-DIFF-P0-02/04` -> `SPECIFICATION_HELD`, NEVER `MATCH`!):
    ("SURF-39-SPEC-UNDEF-KM", "S0-R2 §III G-01 (Right-Censored KM)", "SPEC_UNDEFINED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, over 12 months, the Kaplan-Meier cumulative incidence of stroke was 8.4% (censored = 38)."),
    ("SURF-40-SPEC-UNDEF-AJ", "S0-R2 §III G-01 (Aalen-Johansen)", "SPEC_UNDEFINED", "atomic", 512, 4000, 512, 16,
     b"In the primary cohort, over 12 months, the Aalen-Johansen competing-risk incidence of stroke was 8.1%."),
]


# ===========================================================================
# 7. `PO-DIFF-09` Static Source-Dependency & Independence Self-Audit
# ===========================================================================

def run_po_diff_09_static_audit() -> Dict[str, object]:
    """
    Audits `independent_r0_semantic_oracle.py` AST to guarantee:
      1. Stdlib-only imports (zero imports from P3-C / P3-B / Provenance R1).
      2. Zero file-system reads of `.lean` implementation files in `P3C_SemanticNorm`,
         `P3B_BoundedParser`, or `P3C_Provenance_R1`.
      3. Complete 25-row `R0_SPEC_CORRESPONDENCE_TABLE` covering all 21 canonical rules + `SPEC_UNDEFINED`.
    """
    self_path = Path(__file__).resolve()
    src = self_path.read_text(encoding="utf-8")
    tree = ast.parse(src, filename=str(self_path))

    allowed_stdlib = {
        "__future__", "ast", "dataclasses", "hashlib", "json", "os",
        "pathlib", "re", "subprocess", "sys", "tempfile", "typing",
    }
    imported_modules = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imported_modules.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported_modules.add(node.module.split(".")[0])

    forbidden_imports = sorted(imported_modules - allowed_stdlib)
    # Check no string literal outside this audit function references Lean implementation modules/files:
    forbidden_substrings = (
        "TreeSemanticExtractor.lean",
        "CanonicalNormalizer.lean",
        "ConsensusAndTrapGate.lean",
        "BoundedParser.lean",
        "DeclarativeParseSpec.lean",
        "P3CDetachedChecker",
        "P3BDetachedChecker",
    )
    forbidden_refs = []
    for top_stmt in tree.body:
        if isinstance(top_stmt, ast.FunctionDef) and top_stmt.name == "run_po_diff_09_static_audit":
            continue
        for node in ast.walk(top_stmt):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                for bad_sub in forbidden_substrings:
                    if bad_sub in node.value:
                        forbidden_refs.append(bad_sub)

    passed = (len(forbidden_imports) == 0) and (len(forbidden_refs) == 0) and (len(R0_SPEC_CORRESPONDENCE_TABLE) >= 22)
    return {
        "obligationId": "PO-DIFF-09",
        "auditType": "STATIC_AST_IMPORT_AND_R0_CORRESPONDENCE_AUDIT",
        "passed": passed,
        "importedModules": sorted(imported_modules),
        "forbiddenImports": forbidden_imports,
        "forbiddenLeanSourceReads": forbidden_refs,
        "r0CorrespondenceRowCount": len(R0_SPEC_CORRESPONDENCE_TABLE),
    }


# ===========================================================================
# 8. Execute Full 3-Class Differential Audit (`SURFACE_E2E`, `FOREST_INJECT`, `SEMANTIC_INJECT`)
# ===========================================================================

def run_surface_e2e_differential() -> Dict[str, object]:
    tsv_lines = [
        f"{vid}\t{emode}\t{mb}\t{ms}\t{mn}\t{mr}\t{raw.hex()}"
        for (vid, _anc, _grd, emode, mb, ms, mn, mr, raw) in SURFACE_VECTORS
    ]
    tsv_text = "\n".join(tsv_lines) + "\n"
    # Write temporary input TSV strictly INSIDE `P3C_Differential_R1/.lake/` (Charter §1 writable root!) and remove immediately:
    tmp_tsv = DIFF_R1_ROOT / ".lake" / "_tmp_surface_vectors.tsv"
    try:
        tmp_tsv.write_text(tsv_text, encoding="utf-8")
        proc = subprocess.run(
            [str(RUNNER_EXE), "--eval-surface-batch", str(tmp_tsv)],
            cwd=str(DIFF_R1_ROOT),
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        if proc.returncode != 0:
            raise RuntimeError(f"Surface batch runner failed: {proc.stderr}")
    finally:
        if tmp_tsv.exists():
            tmp_tsv.unlink()

    lean_rows = [ln.rstrip("\r\n").split("\t") for ln in proc.stdout.splitlines() if ln.strip()]
    assert len(lean_rows) == len(SURFACE_VECTORS), f"{len(lean_rows)} != {len(SURFACE_VECTORS)}"

    verdict_counts: Dict[str, int] = {
        "MATCH_STRUCTURAL(SPEC_GROUNDED)": 0,
        "MATCH_STRUCTURAL(MODEL_ASSUMPTION)": 0,
        "MISMATCH_WITNESS": 0,
        "ORACLE_FAILURE": 0,
        "SPECIFICATION_HELD": 0,
        "RESOURCE_HELD": 0,
    }
    records = []
    mismatches = []

    for (vid, anchor, grade, emode, mb, ms, mn, mr, raw), lcols in zip(SURFACE_VECTORS, lean_rows):
        l_id, l_pstat, l_blen, l_cplen, l_spok, l_fwire, l_ewires, l_cwires, l_owire = lcols
        assert l_id == vid

        if grade == "SPEC_UNDEFINED":
            verdict_counts["SPECIFICATION_HELD"] += 1
            records.append({"vecId": vid, "r0Anchor": anchor, "grade": grade, "verdict": "SPECIFICATION_HELD"})
            continue

        py_pred = predict_surface_e2e_r0(emode, mb, ms, mn, mr, raw)

        # Stage-by-stage structural comparison (`parseStatus`, `cpLen`, `forestWire` incl. spans, `canonWires`, `outcomeWire`):
        # Note: `extWires` contains surface binder string ("x_init"/"y_repeat"), which is checked separately under `MODEL_ASSUMPTION`!
        core_match = (
            l_pstat == py_pred["parseStatus"]
            and l_blen == str(len(raw))
            and l_cplen == py_pred["cpLen"]
            and l_spok == "true"
            and l_fwire == py_pred["forestWire"]
            and l_cwires == py_pred["canonWires"]
            and l_owire == py_pred["outcomeWire"]
        )
        raw_ext_match = (l_ewires == py_pred["extWires"])

        if core_match and raw_ext_match:
            vkey = f"MATCH_STRUCTURAL({grade})"
            verdict_counts[vkey] += 1
            records.append({"vecId": vid, "r0Anchor": anchor, "grade": grade, "verdict": vkey})
        else:
            verdict_counts["MISMATCH_WITNESS"] += 1
            mm = {
                "vecId": vid,
                "r0Anchor": anchor,
                "lean": {"parseStatus": l_pstat, "cpLen": l_cplen, "forestMatch": l_fwire == py_pred["forestWire"],
                         "extMatch": raw_ext_match, "canonMatch": l_cwires == py_pred["canonWires"],
                         "outcomeMatch": l_owire == py_pred["outcomeWire"]},
            }
            mismatches.append(mm)
            records.append({"vecId": vid, "r0Anchor": anchor, "grade": grade, "verdict": "MISMATCH_WITNESS"})

    # Also verify `G-15a` (`SURF-20-G15a-AB`) and `G-15b` (`SURF-21-G15b-BA`) converge to IDENTICAL `outcomeWire` canonical part (`SPEC_GROUNDED`!):
    row_15a = next(r for r in lean_rows if r[0] == "SURF-20-G15a-AB")
    row_15b = next(r for r in lean_rows if r[0] == "SURF-21-G15b-BA")
    g15_canon_converged = (row_15a[7] == row_15b[7]) and (row_15a[6] != row_15b[6])

    return {
        "pathClass": "SURFACE_E2E",
        "totalVectors": len(SURFACE_VECTORS),
        "verdictCounts": verdict_counts,
        "g15ParaphraseRawDistinctAndCanonIdentical": g15_canon_converged,
        "mismatchCount": len(mismatches),
        "mismatches": mismatches,
    }


def run_forest_and_semantic_inject_audit() -> Tuple[Dict[str, object], Dict[str, object]]:
    # 1. `FOREST_INJECT` (`12` vectors covering ALL 5 `ExtractionFailureDiag` constructors):
    proc_fi = subprocess.run(
        [str(RUNNER_EXE), "--eval-forest-inject-suite"],
        cwd=str(DIFF_R1_ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if proc_fi.returncode != 0:
        raise RuntimeError(proc_fi.stderr)
    fi_rows = [ln.rstrip("\r\n").split("\t") for ln in proc_fi.stdout.splitlines() if ln.strip()]

    expected_fi_outcomes = {
        "FI-01-T1-ALT3": ("semanticExtractionFailure", "ExtractionFailureDiag.unsupportedReadingAlt", "SPEC_GROUNDED"),
        "FI-02-G11-ALT2": ("semanticExtractionFailure", "ExtractionFailureDiag.unsupportedReadingAlt", "SPEC_GROUNDED"),
        "FI-03-T2-ALT0": ("semanticExtractionFailure", "ExtractionFailureDiag.unsupportedReadingAlt", "SPEC_GROUNDED"),
        "FI-04-G16-BAD-ANCHOR": ("semanticExtractionFailure", "ExtractionFailureDiag.invalidContrastiveAnchor", "SPEC_GROUNDED"),
        "FI-05-G15B-BAD-ANAPHORA": ("semanticExtractionFailure", "ExtractionFailureDiag.unresolvedAnaphoricScope", "SPEC_GROUNDED"),
        "FI-06-G15A-BAD-COHORT": ("semanticExtractionFailure", "ExtractionFailureDiag.mismatchedScopeCohort", "SPEC_GROUNDED"),
        "FI-07-G15A-MISSING-CHILD": ("semanticExtractionFailure", "ExtractionFailureDiag.malformedParseNode", "MODEL_ASSUMPTION"),
        "FI-08-G11-EXTRA-CHILD": ("semanticExtractionFailure", "ExtractionFailureDiag.malformedParseNode", "MODEL_ASSUMPTION"),
        "FI-09-G07-METRIC-MISMATCH": ("semanticExtractionFailure", "ExtractionFailureDiag.malformedParseNode", "SPEC_GROUNDED"),
        # F-DIFF-P0-03 Boundary Fact: P3-B enforces [Env_ScopedAssoc, Env_ScopedContrastMeta] child sort order
        # (`emptyParseSet` on surface), whereas P3-C `extractRawMeaning` assumes upstream P3-B child sort typing
        # and extracts `[sc2, sc1]` as swapped `contrastivePair(metaSide, assocSide)` (`MODEL_ASSUMPTION`),
        # which is structurally distinct from unswapped `G-16` (`CE-DIFF-01` / `fi10_swapped_diverges_from_valid_g16`).
        "FI-10-G16-SWAPPED-CHILD": ("consensus", "SemanticNormOutcome.consensus", "MODEL_ASSUMPTION"),
        "FI-11-TRUNCATED-T2-ALT1": ("trapPolicyRejected", "TrapPolicyDiag.parserOnlyTrapProduction", "SPEC_GROUNDED"),
        "FI-12-EQUIV-G15-DUAL": ("consensus", "SemanticNormOutcome.consensus", "SPEC_GROUNDED"),
    }
    fi_counts = {"MATCH_STRUCTURAL(SPEC_GROUNDED)": 0, "MATCH_STRUCTURAL(MODEL_ASSUMPTION)": 0, "MISMATCH_WITNESS": 0}
    fi_extraction_failure_observed = 0
    fi_by_id = {}
    for fi_id, fwire, ext_w, out_w in fi_rows:
        fi_by_id[fi_id] = (fwire, ext_w, out_w)
        exp_branch, exp_tok, grd = expected_fi_outcomes[fi_id]
        if f"SemanticNormOutcome.{exp_branch}" in out_w and exp_tok in out_w and fwire.startswith("DIFFV1;ParseForest;"):
            fi_counts[f"MATCH_STRUCTURAL({grd})"] += 1
            if exp_branch == "semanticExtractionFailure":
                fi_extraction_failure_observed += 1
        else:
            fi_counts["MISMATCH_WITNESS"] += 1

    valid_g16_pred = predict_surface_e2e_r0(
        "discourse", 512, 4000, 512, 16,
        next(raw for (vid, _a, _g, _m, _b, _s, _n, _r, raw) in SURFACE_VECTORS if vid == "SURF-22-G16-CONTRAST"),
    )
    fi10_swapped_diverges_from_valid_g16 = (fi_by_id["FI-10-G16-SWAPPED-CHILD"][2] != valid_g16_pred["outcomeWire"])
    if not fi10_swapped_diverges_from_valid_g16:
        fi_counts["MISMATCH_WITNESS"] += 1

    # 2. `SEMANTIC_INJECT` (`12` vectors verifying De Morgan, α-erasure, dedup, idempotence, non-commutativity):
    proc_si = subprocess.run(
        [str(RUNNER_EXE), "--eval-semantic-inject-suite"],
        cwd=str(DIFF_R1_ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if proc_si.returncode != 0:
        raise RuntimeError(proc_si.stderr)
    si_rows = {cols[0]: cols for cols in (ln.rstrip("\r\n").split("\t") for ln in proc_si.stdout.splitlines() if ln.strip())}

    idempotence_ok = all(cols[2] == cols[3] for cols in si_rows.values())
    demorgan_converged = (si_rows["SI-01-G11-NEG-EX"][2] == si_rows["SI-02-T1-ALT1-DEMORGAN"][2]) and (
        si_rows["SI-01-G11-NEG-EX"][1] != si_rows["SI-02-T1-ALT1-DEMORGAN"][1]
    )
    symconj_converged = (si_rows["SI-05-SYMCONJ-AB"][2] == si_rows["SI-06-SYMCONJ-BA-DUP"][2])
    contrast_noncomm = (si_rows["SI-07-CONTRAST-AB"][2] != si_rows["SI-08-CONTRAST-BA-SWAP"][2])
    temporal_noncomm = (si_rows["SI-09-G04-TEMP-AB"][2] != si_rows["SI-10-G04-TEMP-BA"][2])
    scope_separated = (si_rows["SI-01-G11-NEG-EX"][2] != si_rows["SI-03-T5-UNSCOPED"][2])

    si_all_ok = all([idempotence_ok, demorgan_converged, symconj_converged, contrast_noncomm, temporal_noncomm, scope_separated])

    return (
        {
            "pathClass": "FOREST_INJECT",
            "totalVectors": len(fi_rows),
            "semanticExtractionFailureVectorsVerified": fi_extraction_failure_observed,
            "fi10SwappedChildDivergesFromValidG16": fi10_swapped_diverges_from_valid_g16,
            "verdictCounts": fi_counts,
        },
        {
            "pathClass": "SEMANTIC_INJECT",
            "totalVectors": len(si_rows),
            "allIdempotent": idempotence_ok,
            "deMorganConverged": demorgan_converged,
            "symConjCommAssocIdemConverged": symconj_converged,
            "contrastiveSideSwapNonEquivalent": contrast_noncomm,
            "temporalPrecedenceReversalNonEquivalent": temporal_noncomm,
            "cohortVsUnscopedSeparated": scope_separated,
            "allInvariantsPassed": si_all_ok,
        },
    )


def main() -> int:
    print("==========================================================================")
    print("PNEUMA-NATIVE OMEGA — AUTH-P3C-DIFFERENTIAL-R1 INDEPENDENT R0 ORACLE AUDIT")
    print("==========================================================================")

    po09 = run_po_diff_09_static_audit()
    surf = run_surface_e2e_differential()
    fi_res, si_res = run_forest_and_semantic_inject_audit()

    print(f"[{'PASS' if po09['passed'] else 'FAIL'}] PO-DIFF-09 Static Independence Audit "
          f"(stdlib imports={len(po09['importedModules'])}, forbidden={len(po09['forbiddenImports'])}, "
          f"R0 table rows={po09['r0CorrespondenceRowCount']})")
    print(f"[{'PASS' if surf['mismatchCount'] == 0 else 'FAIL'}] SURFACE_E2E Differential ({surf['totalVectors']} vectors): "
          f"{json.dumps(surf['verdictCounts'])}")
    print(f"       G-15a/G-15b Raw!= & Canon== : {surf['g15ParaphraseRawDistinctAndCanonIdentical']}")
    print(f"[{'PASS' if fi_res['verdictCounts']['MISMATCH_WITNESS'] == 0 else 'FAIL'}] FOREST_INJECT Differential ({fi_res['totalVectors']} vectors, "
          f"SemanticExtractionFailure={fi_res['semanticExtractionFailureVectorsVerified']}): {json.dumps(fi_res['verdictCounts'])}")
    print(f"[{'PASS' if si_res['allInvariantsPassed'] else 'FAIL'}] SEMANTIC_INJECT Differential ({si_res['totalVectors']} vectors): "
          f"idempotent={si_res['allIdempotent']}, DeMorgan={si_res['deMorganConverged']}, "
          f"SymConj={si_res['symConjCommAssocIdemConverged']}, Contrast!={si_res['contrastiveSideSwapNonEquivalent']}, "
          f"Temporal!={si_res['temporalPrecedenceReversalNonEquivalent']}")
    print("==========================================================================")

    summary = {
        "overallActDisposition": (
            "FULL_SCOPED_DIFFERENTIAL_PASS"
            if (po09["passed"] and surf["mismatchCount"] == 0
                and fi_res["verdictCounts"]["MISMATCH_WITNESS"] == 0 and si_res["allInvariantsPassed"])
            else "COUNTEREXAMPLE_OR_FAILURE_DETECTED"
        ),
        "poDiff09Audit": po09,
        "surfaceE2E": surf,
        "forestInject": fi_res,
        "semanticInject": si_res,
    }
    if "--json" in sys.argv:
        print("JSON_SUMMARY_BEGIN")
        print(json.dumps(summary, indent=2))
        print("JSON_SUMMARY_END")

    return 0 if summary["overallActDisposition"] == "FULL_SCOPED_DIFFERENTIAL_PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
