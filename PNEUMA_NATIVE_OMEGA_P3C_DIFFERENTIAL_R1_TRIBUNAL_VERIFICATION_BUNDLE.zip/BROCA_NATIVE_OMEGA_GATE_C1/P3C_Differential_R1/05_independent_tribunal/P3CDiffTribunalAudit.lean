/-
  PNEUMA-NATIVE Ω — AUTH-P3C-DIFFERENTIAL-R1 (`Gate E` Tribunal Audit & Full-Internal-State CLI)
  05_independent_tribunal/P3CDiffTribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, `Provenance R1`, zero `sorry`)

  1. Emits `#print axioms` on all exported `PO-DIFF-01` ~ `PO-DIFF-08` and `Gate D` theorems
     (`0` `sorryAx`, `0` `Lean.ofReduceBool`, `0` custom axioms).
  2. Provides CLI executable `p3c_differential_r1_runner`:
     - Default mode                  : executes & prints all 28 `Gate D` (`D01`~`D14`) vectors.
     - `--export-fixed-json`         : exports JSON report of all 28 `D01`~`D14` vectors.
     - `--eval-surface-batch <tsv>`  : emits full `PNEUMA-DIFF-SER-V1` stage wires (`ConcreteParseTree`,
                                       `CodepointSpan`, `RawSemanticTerm`, `CanonicalMeaning`, `SemanticNormOutcome`)
                                       on external hex-encoded `SURFACE_E2E` inputs.
     - `--eval-forest-inject-suite`  : emits full `PNEUMA-DIFF-SER-V1` wires across 12 `FOREST_INJECT`
                                       cases covering all 5 `ExtractionFailureDiag` constructors & edge forests.
     - `--eval-semantic-inject-suite`: emits full `PNEUMA-DIFF-SER-V1` wires across 12 `SEMANTIC_INJECT`
                                       raw/canonical/idempotence perturbation cases.
-/
import P3CDifferentialObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks
open PneumaOmega.P3C.DifferentialR1
open PneumaOmega.P3C.DifferentialR1.Attacks
open PneumaOmega.P3C.DifferentialR1.Obligations

/-! ### 1. Kernel Axiom Fingerprint Audit (`#print axioms`) -/

#print axioms PO_DIFF_01_SerializationRoundtripAndCanonicalUniqueness
#print axioms PO_DIFF_02_EncodingInjectivity
#print axioms PO_DIFF_03_SpanUnitIntegrity
#print axioms PO_DIFF_04_ExtractionResultFidelity
#print axioms PO_DIFF_05_CanonicalMeaningFidelity
#print axioms PO_DIFF_06_FiveWayOutcomeSeparation
#print axioms PO_DIFF_07_DifferentialScopeSoundness
#print axioms PO_DIFF_08_ProvenanceBoundaryPreservation
#print axioms F_DIFF_OPT_01_ProjectionSoundness
#print axioms F_DIFF_OPT_02_MismatchWitnessFidelity
#print axioms PO_DIFF_All28OrthogonalAttackVectorsVerified

/-! ### 2. Formatting & Hex TSV Helpers (`SURFACE_E2E`, `FOREST_INJECT`, `SEMANTIC_INJECT`) -/

private def renderPathClass : ObservationPathClass → String
  | .SURFACE_E2E     => "SURFACE_E2E"
  | .FOREST_INJECT   => "FOREST_INJECT"
  | .SEMANTIC_INJECT => "SEMANTIC_INJECT"

private def renderGrade : OracleEpistemicGrade → String
  | .SPEC_GROUNDED    => "SPEC_GROUNDED"
  | .MODEL_ASSUMPTION => "MODEL_ASSUMPTION"
  | .SPEC_UNDEFINED   => "SPEC_UNDEFINED"

private def renderBoundary : FirstBlockingBoundary → String
  | .p3bStrictAsciiDomain       => "P3B_StrictAsciiDomain"
  | .p3bBoundedResourceGate     => "P3B_BoundedResourceGate"
  | .p3bGrammarAndCheckSide     => "P3B_GrammarAndCheckSide"
  | .p3cRawTreeExtractor        => "P3C_RawTreeExtractor"
  | .p3cCanonicalNormalizer     => "P3C_CanonicalNormalizer"
  | .p3cConsensusAndTrapGate    => "P3C_ConsensusAndTrapGate"
  | .diffV1CanonicalWireDecoder => "DIFFV1_WireDecoder"
  | .provenanceR1WhiteboxReplay => "ProvenanceR1_Replay"

private def hexDigitVal (c : Char) : Option Nat :=
  if ('0' ≤ c) && (c ≤ '9') then some (c.toNat - '0'.toNat)
  else if ('a' ≤ c) && (c ≤ 'f') then some (10 + (c.toNat - 'a'.toNat))
  else if ('A' ≤ c) && (c ≤ 'F') then some (10 + (c.toNat - 'A'.toNat))
  else none

private def decodeHexChars : List Char → Option (List UInt8)
  | [] => some []
  | c1 :: c2 :: rest =>
    match hexDigitVal c1, hexDigitVal c2, decodeHexChars rest with
    | some v1, some v2, some tail => some (UInt8.ofNat (v1 * 16 + v2) :: tail)
    | _, _, _ => none
  | [_] => none

private def stripCR (s : String) : String :=
  String.ofList (s.toList.filter (fun c => c != '\r'))

private def parseNatSimple (s : String) : Nat :=
  s.toNat?.getD 0

private def evalSurfaceBatchLine (line : String) : Option String :=
  let clean := stripCR line
  if clean.isEmpty then none
  else
    match clean.splitOn "\t" with
    | [vecId, envStr, maxBStr, maxSStr, maxNStr, maxRStr, hexPayload] =>
      let env := if envStr == "discourse" then envDiscourse else envAtomic
      let budget : ResourceBudget :=
        { maxBytes       := parseNatSimple maxBStr
          maxSteps       := parseNatSimple maxSStr
          maxForestNodes := parseNatSimple maxNStr
          maxReadings    := parseNatSimple maxRStr }
      match decodeHexChars hexPayload.toList with
      | none => some s!"{vecId}\tERR:INVALID_HEX"
      | some rawBytes =>
        let ctx : ProvenanceContext :=
          { catalog  := p3cTestCatalog
            numCfg   := frozenR22NumericConfig
            scopeEnv := env
            budget   := budget
            rawBytes := rawBytes }
        let tr := observeSurfaceE2E ctx
        let cpStr := match tr.codepointLenOpt with | some k => toString k | none => "NONE"
        let fStr  := match tr.forestWireOpt with | some w => w | none => "NONE"
        let extJoined   := if tr.perTreeExtractionWires.isEmpty then "NONE" else String.intercalate "|" tr.perTreeExtractionWires
        let canonJoined := if tr.perTreeCanonicalWires.isEmpty then "NONE" else String.intercalate "|" tr.perTreeCanonicalWires
        some (String.intercalate "\t"
          [vecId, tr.parseStatus, toString tr.byteLen, cpStr, toString tr.spansWithinBounds,
           fStr, extJoined, canonJoined, tr.outcomeWire])
    | _ => some "ERR:MALFORMED_LINE"

/-! ### 3. Curated `FOREST_INJECT` (`12` Cases) & `SEMANTIC_INJECT` (`12` Cases) Export Suites -/

private def sp0 : CodepointSpan := ⟨0, 1⟩

private def synthT2Alt0BadTree : ConcreteParseTree :=
  let emb := ConcreteParseTree.mkTree .Env_EmbeddedCausal 1 .clause1 sp0
    [ .slotTok .expLevel .activeExp "exp_intens" "intensive therapy" sp0,
      .slotTok .intervVerbPres .verb "reduces" "reduces" sp0,
      .slotTok .outTerm .outcome "out_mi" "myocardial infarction" sp0 ]
  let t2Bad := ConcreteParseTree.mkTree .Trap_T2_ConfirmThat 0 .clause1 sp0
    [ .slotTok .sourceId .source "src_trialA" "Trial-A" sp0, .childSub emb ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedTrap 1 .clause1 sp0
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" sp0, .childSub t2Bad ]
  ConcreteParseTree.mkTree .Env_DocTrapScoped 1 .clause1 sp0 [ .childSub sc ]

private def synthLeafUnexpectedChildTree : ConcreteParseTree :=
  let dummyLeaf := ConcreteParseTree.mkTree .Gen_G11_QuantZero 1 .clause1 sp0 []
  let badG11 := ConcreteParseTree.mkTree .Gen_G11_QuantZero 1 .clause1 sp0
    [ .slotTok .subgroupPlural .subgroup "sub_dm_pl" "diabetic" sp0,
      .slotTok .eventTerm .eventA "ev_stroke" "stroke" sp0,
      .childSub dummyLeaf ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedInitial 1 .clause1 sp0
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" sp0, .childSub badG11 ]
  ConcreteParseTree.mkTree .Env_DocSingle 1 .clause1 sp0 [ .childSub sc ]

private def synthG07MismatchedMetricsTree : ConcreteParseTree :=
  let badG07 := ConcreteParseTree.mkTree .Gen_G07_MetaNotStatSig 1 .clause1 sp0
    [ .slotTok .ratioMetric .metric1 "hr" "hazard ratio" sp0,
      .slotTok .expLevel .activeExp "exp_intens" "intensive therapy" sp0,
      .slotTok .expLevel .refExp "exp_std" "standard care" sp0,
      .slotTok .outTerm .outcome "out_mi" "myocardial infarction" sp0,
      .slotTok .ratioMetric .metric2 "or" "odds ratio" sp0,
      .slotTok .numericLit .numEst "0.94" "0.94" sp0,
      .slotTok .numericLit .numCILevel "95" "95" sp0,
      .slotTok .numericLit .numCILow "0.79" "0.79" sp0,
      .slotTok .numericLit .numCIHigh "1.12" "1.12" sp0,
      .slotTok .numericLit .numAlpha "0.05" "0.05" sp0 ]
  let sc := ConcreteParseTree.mkTree .Env_ScopedInitial 1 .clause1 sp0
    [ .slotTok .cohortSpec .cohort "coh_primary" "the primary cohort" sp0, .childSub badG07 ]
  ConcreteParseTree.mkTree .Env_DocSingle 1 .clause1 sp0 [ .childSub sc ]

private def forestInjectCases : List (String × ScopeEnv × List ConcreteParseTree) :=
  [ ("FI-01-T1-ALT3",             envAtomic,           [synthInvalidAlt3Tree]),
    ("FI-02-G11-ALT2",            envAtomic,           [synthG11IllegalAlt2Tree]),
    ("FI-03-T2-ALT0",             envAtomic,           [synthT2Alt0BadTree]),
    ("FI-04-G16-BAD-ANCHOR",      envDiscourse,        [synthBadAnchorG16Tree]),
    ("FI-05-G15B-BAD-ANAPHORA",   envMismatchedDesign, [synthTreeG15b_BA]),
    ("FI-06-G15A-BAD-COHORT",     envMismatchedCohort, [synthTreeG15a_AB]),
    ("FI-07-G15A-MISSING-CHILD",  envAtomic,           [synthMissingChildrenG15aTree]),
    ("FI-08-G11-EXTRA-CHILD",     envAtomic,           [synthLeafUnexpectedChildTree]),
    ("FI-09-G07-METRIC-MISMATCH", envAtomic,           [synthG07MismatchedMetricsTree]),
    ("FI-10-G16-SWAPPED-CHILD",   envDiscourse,        [synthSwappedChildrenG16Tree]),
    ("FI-11-TRUNCATED-T2-ALT1",   envAtomic,           [synthTruncatedT2Alt1]),
    ("FI-12-EQUIV-G15-DUAL",      envDiscourse,        [synthTreeG15a_AB, synthTreeG15b_BA]) ]

private def semanticInjectCases : List (String × RawSemanticTerm) :=
  let pA := PresupItem.factiveCausal "exp_intens" "reduces" "out_mi"
  let pB := PresupItem.factiveCausal "exp_intens" "increases" "out_death"
  let atomG11 := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
  let atomT1Alt1 := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "z_alt1"
    (.quantClaim (.universalNeg "sub_dm_pl" "ev_stroke")) []
  let atomG13 := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "y_repeat"
    (.quantClaim (.existentialPos "sub_hr_sg" "ev_aki")) []
  let assocSide := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") []
  let metaSide := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "y_repeat"
    (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") []
  [ ("SI-01-G11-NEG-EX",          atomG11),
    ("SI-02-T1-ALT1-DEMORGAN",    atomT1Alt1),
    ("SI-03-T5-UNSCOPED",         .scopedAtom .unrestrictedPop "u_unscoped" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []),
    ("SI-04-PRESUP-DEDUP-SORT",   .scopedAtom (.cohortBound "coh_primary") "b_custom" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") [pB, pA, pB]),
    ("SI-05-SYMCONJ-AB",          .symConj atomG11 atomG13),
    ("SI-06-SYMCONJ-BA-DUP",      .symConj atomG13 (.symConj atomT1Alt1 atomG13)),
    ("SI-07-CONTRAST-AB",         .contrastivePair assocSide metaSide "exp_intens" "out_mi"),
    ("SI-08-CONTRAST-BA-SWAP",    .contrastivePair metaSide assocSide "exp_intens" "out_mi"),
    ("SI-09-G04-TEMP-AB",         .scopedAtom (.cohortBound "coh_primary") "x_init" (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none (some ("ev_stroke", "ev_aki")) "0.75" "95" "0.61" "0.92") []),
    ("SI-10-G04-TEMP-BA",         .scopedAtom (.cohortBound "coh_primary") "x_init" (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none (some ("ev_aki", "ev_stroke")) "0.75" "95" "0.61" "0.92") []),
    ("SI-11-G06A-CAUSAL-DIR",     .scopedAtom (.cohortBound "coh_primary") "x_init" (.intervClaim (.directional "reduce") "assump_exch" "hr" "exp_intens" "exp_std" "out_mi" "0.75" "95" "0.61" "0.92" (some "0.006")) []),
    ("SI-12-G08-META-EQUIV",      .scopedAtom (.cohortBound "coh_primary") "x_init" (.metaEquiv "hr" "exp_intens" "exp_std" "out_mi" "0.80" "1.25" "0.99" "90" "0.84" "1.16") []) ]

private def checkUnprojectedWitness {α : Type} [DecidableEq α] (wId : String)
    (C : CanonicalWireCodec α) (stage : DiffStage) (x y : α) : String × Bool × String :=
  let wx := encodeWire C x
  let wy := encodeWire C y
  match compareWirePayloads C .SPEC_GROUNDED wId stage wx wy with
  | .MISMATCH_WITNESS st locus lWire oWire =>
    let decOk := match decodeWire C lWire, decodeWire C oWire with
      | .ok x', .ok y' => (x' == x) && (y' == y)
      | _, _           => false
    let ok := (st == stage) && (!eqStrBool lWire oWire) && decOk && (!locus.isEmpty)
    (wId, ok, s!"stage={reprStr st} | locus={locus} | leanBytes={lWire.utf8ByteSize} | oracleBytes={oWire.utf8ByteSize} | roundtrip={decOk}")
  | other => (wId, false, s!"UNEXPECTED:{reprStr other}")

private def unprojectedWitnessChecks : List (String × Bool × String) :=
  let mScoped   := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
  let mUnscoped := RawSemanticTerm.scopedAtom .unrestrictedPop "u_unscoped" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) []
  let mClean    := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") []
  let mPresup   := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.metaNonEstab "src_trialA" "exp_intens" "reduces" "out_mi") [.factiveCausal "exp_intens" "reduces" "out_mi"]
  let mWithCov  := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" (some "cov_age_risk") none "0.75" "95" "0.61" "0.92") []
  let mDropCov  := RawSemanticTerm.scopedAtom (.cohortBound "coh_primary") "x_init" (.assocClaim "hr" "inversely" "exp_intens" "exp_std" "out_mi" none none "0.75" "95" "0.61" "0.92") []
  [ checkUnprojectedWitness "OPT02-W1-SPAN-SHIFT" parseTreeWireCodec .spanIntegrityStage
      synthTreeG15a_AB (perturbRootSpan synthTreeG15a_AB),
    checkUnprojectedWitness "OPT02-W2-SCOPE-DROP" canonicalMeaningWireCodec .canonicalNormStage
      (normalizeMeaning mScoped) (normalizeMeaning mUnscoped),
    checkUnprojectedWitness "OPT02-W3-PRESUP-INJECT" canonicalMeaningWireCodec .canonicalNormStage
      (normalizeMeaning mClean) (normalizeMeaning mPresup),
    checkUnprojectedWitness "OPT02-W4-CAUSAL-VS-ASSOC" canonicalMeaningWireCodec .canonicalNormStage
      expectedCanonG06a expectedCanonG03,
    checkUnprojectedWitness "OPT02-W5-TEMPORAL-SWAP" canonicalMeaningWireCodec .canonicalNormStage
      expectedCanonG04_AB expectedCanonG04_BA,
    checkUnprojectedWitness "OPT02-W6-OPT-COV-DROP" canonicalMeaningWireCodec .canonicalNormStage
      (normalizeMeaning mWithCov) (normalizeMeaning mDropCov),
    checkUnprojectedWitness "OPT02-W7-OUTCOME-5WAY" outcomeWireCodec .outcomeGateStage
      (evalForestPure envMismatchedDesign [synthTreeG15b_BA])
      (.consensus [synthTreeG15b_BA] expectedCanonG15Conj) ]

private def exportFixedJson : String :=
  let rows := allDiffAttackCases.map fun c =>
    s!"  \{\"caseId\": \"{c.caseId}\", \"attackFamily\": \"{c.attackFamily}\", \"polarity\": \"{c.polarity}\", \"pathClass\": \"{renderPathClass c.pathClass}\", \"epistemicGrade\": \"{renderGrade c.epistemicGrade}\", \"r0SpecAnchor\": \"{c.r0SpecAnchor}\", \"firstBoundary\": \"{renderBoundary c.firstBoundary}\", \"targetObligation\": \"{c.targetObligation}\", \"expectedVerdictTag\": \"{c.expectedVerdictTag}\", \"actualVerdictTag\": \"{c.actualVerdictTag}\", \"passed\": {c.passed}}"
  "[\n" ++ String.intercalate ",\n" rows ++ "\n]"

def main (args : List String) : IO UInt32 := do
  match args with
  | ["--export-fixed-json"] =>
    IO.println exportFixedJson
    return 0
  | ["--eval-surface-batch", path] =>
    let content ← IO.FS.readFile path
    for line in content.splitOn "\n" do
      match evalSurfaceBatchLine line with
      | some out => IO.println out
      | none     => pure ()
    return 0
  | ["--eval-forest-inject-suite"] =>
    for (fiId, env, forest) in forestInjectCases do
      let tr := observeForestInject env forest
      let extJoined := if tr.perTreeExtractionWires.isEmpty then "NONE" else String.intercalate "|" tr.perTreeExtractionWires
      IO.println (String.intercalate "\t" [fiId, tr.forestWire, extJoined, tr.forestOutcomeWire])
    return 0
  | ["--eval-semantic-inject-suite"] =>
    for (siId, rawTerm) in semanticInjectCases do
      let tr := observeSemanticInject rawTerm
      IO.println (String.intercalate "\t" [siId, tr.rawWire, tr.canonicalWire, tr.idempotentCanonicalWire])
    return 0
  | _ =>
    IO.println "=========================================================================="
    IO.println "PNEUMA-NATIVE OMEGA — AUTH-P3C-DIFFERENTIAL-R1 (FULL INTERNAL DIFFERENTIAL)"
    IO.println "Scope     : F-P3C-02 + Corrigendum R0 F-DIFF-P0-01..04 (P3C_Differential_R1)"
    IO.println "Toolchain : Lean 4.33.1 Core (Init + Frozen P2..P3-C + Provenance R1, 0 sorry)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for c in allDiffAttackCases do
      let status := if c.passed then "PASS" else "FAIL"
      if c.passed then passCount := passCount + 1
      IO.println s!"[{status}] {c.caseId} | {c.attackFamily} | {renderPathClass c.pathClass} | {renderGrade c.epistemicGrade} | {c.r0SpecAnchor} | {c.actualVerdictTag}"
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"TOTAL CURATED ORTHOGONAL VECTORS : {passCount}/{allDiffAttackCases.length} PASSED"
    IO.println "--------------------------------------------------------------------------"
    IO.println "F-DIFF-OPT-02 UNPROJECTED FULL WIRE WITNESS VERIFICATION:"
    let mut witPass : Nat := 0
    for (wId, wOk, wDetail) in unprojectedWitnessChecks do
      let wStat := if wOk then "PASS" else "FAIL"
      if wOk then witPass := witPass + 1
      IO.println s!"[{wStat}] {wId} | {wDetail}"
    IO.println s!"TOTAL UNPROJECTED WITNESS CHECKS : {witPass}/{unprojectedWitnessChecks.length} PASSED"
    if (passCount == allDiffAttackCases.length) && (witPass == unprojectedWitnessChecks.length) then
      return 0
    else
      return 1
