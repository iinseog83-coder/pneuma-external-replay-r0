/-
  BROCA-NATIVE Ω — Gate C1-P1
  ProofObligations/PO_C1_04a_Arithmetic.lean
  Canonical Theorem Index for `AUTH-C1-P1` (`PO-C1-04` Arithmetic Sub-Obligation ONLY).

  SCOPE BOUNDARY DECLARATION:
  - PROVED IN THIS MODULE (`PO-C1-04a` Exact Unbounded Rational & Rounding Foundation):
      * `P1_ExactRat_CanonicalZero`: `num = 0 → den = 1 ∧ r = ExactRat.zero`
      * `P1_ExactRat_UniqueCanonical`: `r₁ = r₂ ↔ r₁.num * r₂.den = r₂.num * r₁.den`
      * `P1_DecLit_NegZeroRejected`: `-0.0` unconditionally rejected at ingress
      * `P1_DecLit_ValVsFmtSeparation`: `valEq` is an equivalence relation strictly coarser than `fmtEq`
      * `P1_ValidRoundAwz_Iff_EuclideanQuotient`: `ValidRoundAwz p q m d ↔ m = roundHalfAwayFromZero p q d` (`q > 0`)
      * `P1_ValidRoundAwz_Iff_NearestIntMetric`: `ValidRoundAwz p q m d ↔ IsNearestIntHalfAway p q d m` (`q > 0`)
      * `P1_ValidRoundAwz_Deterministic`: uniqueness of `m`
      * `P1_ValidRoundAwz_SignSymmetry`: `R(-p, q, d) = -R(p, q, d)` and `ValidRoundAwz (-p) q (-m) d ↔ ValidRoundAwz p q m d`
      * `P1_HalfwayBoundarySafety`: exact `+0.5` and `-0.5` break strictly away from zero
      * `P1_DetachedGate_SoundAndComplete`: `verifyRoundingWitness_sound` and `verifyRoundingWitness_complete`
  - EXPLICITLY HELD / NOT AUTHORIZED:
      * `P1-C` (`Int128` / `UInt128` fixed-width arithmetic optimization): NOT_AUTHORIZED
      * `PO-C1-04b` (Clinical/statistical commitment & evidence witness verification — P4): HELD
      * `PO-C1-01, 02, 03, 05, 06` and `Master Soundness` (P2, P3, P5): HELD
      * Scientific/clinical validity of external datasets: OUT_OF_SCOPE
-/
import FormalSpec
import DetachedChecker
import Counterexamples

namespace BrocaOmega.P1.Obligations

open BrocaOmega.P1
open BrocaOmega.P1.Checker

/-- 1. Canonical Zero & Coprime Uniqueness of `ExactRat`. -/
theorem P1_ExactRat_CanonicalZero (r : ExactRat) (h : r.num = 0) :
    r.den = 1 ∧ r = ExactRat.zero :=
  ⟨ExactRat.den_eq_one_of_num_eq_zero r h, ExactRat.eq_zero_of_num_eq_zero r h⟩

theorem P1_ExactRat_ExtensionalUniqueness (r₁ r₂ : ExactRat) :
    r₁ = r₂ ↔ ExactRat.RatValEq r₁.num r₁.den r₂.num r₂.den :=
  ExactRat.ext_iff_ratValEq r₁ r₂

/-- 2. Core Equivalence (`P1-B` Primary Target): `ValidRoundAwz ↔ roundHalfAwayFromZero`. -/
theorem P1_ValidRoundAwz_Iff_RoundHalfAway {p : Int} {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz p q m d ↔ m = roundHalfAwayFromZero p q d :=
  validRoundAwz_iff_eq_roundHalfAway hq m d

/-- 3. Non-Circular Metric Equivalence: `ValidRoundAwz ↔ IsNearestIntHalfAway` (∀ k ∈ ℤ). -/
theorem P1_ValidRoundAwz_Iff_NearestIntMetric {p : Int} {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz p q m d ↔ IsNearestIntHalfAway p q d m :=
  validRoundAwz_iff_isNearestIntHalfAway hq m d

/-- 4. Determinism, Sign Symmetry, and Zero Canonicalization. -/
theorem P1_ValidRoundAwz_Unique {p : Int} {q : Nat} {m₁ m₂ : Int} {d : Nat}
    (h₁ : ValidRoundAwz p q m₁ d) (h₂ : ValidRoundAwz p q m₂ d) : m₁ = m₂ :=
  validRoundAwz_unique h₁ h₂

theorem P1_RoundHalfAway_SignSymmetry (p : Int) (q d : Nat) :
    roundHalfAwayFromZero (-p) q d = - roundHalfAwayFromZero p q d ∧
    ∀ m : Int, (ValidRoundAwz (-p) q (-m) d ↔ ValidRoundAwz p q m d) :=
  ⟨roundHalfAwayFromZero_neg p q d, fun m => validRoundAwz_neg_iff p q m d⟩

theorem P1_RoundHalfAway_ZeroCanonical {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    roundHalfAwayFromZero 0 q d = 0 ∧ (ValidRoundAwz 0 q m d ↔ m = 0) :=
  ⟨roundHalfAwayFromZero_zero q d, validRoundAwz_zero_iff hq m d⟩

/-- 5. Exact Halfway (`±0.5`) Tie-Breaking Away From Zero. -/
theorem P1_ExactHalfway_TiesAwayFromZero {p : Int} {q : Nat} {k : Int} {d : Nat}
    (hq : 0 < q) (hk : 0 ≤ k) :
    (2 * pow10Int d * p = (q : Int) * (2 * k + 1) →
      ValidRoundAwz p q (k + 1) d ∧ ¬ ValidRoundAwz p q k d) ∧
    (2 * pow10Int d * (-p) = (q : Int) * (2 * k + 1) →
      ValidRoundAwz p q (-(k + 1)) d ∧ ¬ ValidRoundAwz p q (-k) d) :=
  ⟨exact_pos_halfway_boundary hq hk, exact_neg_halfway_boundary hq hk⟩

/-- 6. End-to-End Detached P1 Gate Soundness & Relative Completeness. -/
theorem P1_DetachedGate_Sound
    {rawNum : Int} {rawDen : Nat} {rawSurface : RawDecToken}
    {expectedScale maxScale : Nat}
    {cert : CertifiedRoundingWitness rawNum rawDen rawSurface expectedScale maxScale}
    (hok : verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale = .ok cert) :
    0 < rawDen ∧
    ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0) ∧
    rawSurface.scale10 = expectedScale ∧
    expectedScale ≤ maxScale ∧
    ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale ∧
    rawSurface.toSignedInt = roundHalfAwayFromZero rawNum rawDen expectedScale ∧
    IsNearestIntHalfAway rawNum rawDen expectedScale rawSurface.toSignedInt :=
  verifyRoundingWitness_sound hok

theorem P1_DetachedGate_Complete
    {rawNum : Int} {rawDen : Nat} {rawSurface : RawDecToken}
    {expectedScale maxScale : Nat}
    (hden : 0 < rawDen)
    (hno_neg0 : ¬(rawSurface.negSign = true ∧ rawSurface.absMantissa = 0))
    (hsc : rawSurface.scale10 = expectedScale)
    (hle : expectedScale ≤ maxScale)
    (hraw : ValidRoundAwz rawNum rawDen rawSurface.toSignedInt expectedScale) :
    ∃ cert, verifyRoundingWitness rawNum rawDen rawSurface expectedScale maxScale = .ok cert :=
  verifyRoundingWitness_complete hden hno_neg0 hsc hle hraw

end BrocaOmega.P1.Obligations
