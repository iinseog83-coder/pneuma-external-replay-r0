/-
  BROCA-NATIVE Ω — Gate C1-P1
  FormalSpec/Arithmetic/ExactRat.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies)
  Scope: AUTH-C1-P1 ONLY (Unbounded exact rational & decimal literal representation; NO P1-C Int128)
-/

namespace BrocaOmega.P1

/--
  Canonical exact rational number `p / q` with `q > 0`, `gcd(|p|, q) = 1`.
  Note: When `num = 0`, `Nat.gcd 0 den = den = 1` automatically forces canonical zero `0 / 1`.
-/
structure ExactRat where
  num : Int
  den : Nat
  den_pos : 0 < den
  reduced : Nat.gcd num.natAbs den = 1
  deriving DecidableEq, Repr

namespace ExactRat

/-- Canonical zero rational `0 / 1`. -/
def zero : ExactRat :=
  { num := 0
    den := 1
    den_pos := by decide
    reduced := by decide }

/-- Canonical zero theorem: any `ExactRat` with `num = 0` must have `den = 1`. -/
theorem den_eq_one_of_num_eq_zero (r : ExactRat) (h : r.num = 0) : r.den = 1 := by
  have hgcd : Nat.gcd r.num.natAbs r.den = 1 := r.reduced
  rw [h] at hgcd
  simpa [Int.natAbs] using hgcd

/-- Canonical zero uniqueness: any `ExactRat` with `num = 0` equals `ExactRat.zero`. -/
theorem eq_zero_of_num_eq_zero (r : ExactRat) (h : r.num = 0) : r = zero := by
  have hd : r.den = 1 := den_eq_one_of_num_eq_zero r h
  cases r with
  | mk n d hp hr =>
    simp at h hd
    subst h hd
    rfl

/-- Exact negation of an `ExactRat`, preserving `den > 0` and coprimality. -/
def neg (r : ExactRat) : ExactRat :=
  { num := -r.num
    den := r.den
    den_pos := r.den_pos
    reduced := by
      rw [Int.natAbs_neg]
      exact r.reduced }

@[simp]
theorem neg_num (r : ExactRat) : r.neg.num = -r.num := rfl

@[simp]
theorem neg_den (r : ExactRat) : r.neg.den = r.den := rfl

theorem neg_neg (r : ExactRat) : r.neg.neg = r := by
  cases r with
  | mk n d hp hr =>
    simp [neg, Int.neg_neg]

@[simp]
theorem neg_zero : zero.neg = zero := rfl

/-- Cross-multiplication mathematical value equivalence between arbitrary `(p₁, q₁)` and `(p₂, q₂)`. -/
def RatValEq (p₁ : Int) (q₁ : Nat) (p₂ : Int) (q₂ : Nat) : Prop :=
  p₁ * (q₂ : Int) = p₂ * (q₁ : Int)

instance (p₁ : Int) (q₁ : Nat) (p₂ : Int) (q₂ : Nat) : Decidable (RatValEq p₁ q₁ p₂ q₂) :=
  inferInstanceAs (Decidable (p₁ * (q₂ : Int) = p₂ * (q₁ : Int)))

/-- Helper lemma: dividing positive `a, b` by `Nat.gcd a b` yields coprime naturals. -/
theorem gcd_div_gcd_eq_one {a b : Nat} (hb : 0 < b) :
    Nat.gcd (a / Nat.gcd a b) (b / Nat.gcd a b) = 1 := by
  let g := Nat.gcd a b
  have hg_pos : 0 < g := Nat.gcd_pos_of_pos_right a hb
  have h1 : Nat.gcd (a / g) (b / g) * g = Nat.gcd (a / g * g) (b / g * g) := by
    symm
    exact Nat.gcd_mul_right (a / g) g (b / g)
  have ha : a / g * g = a := Nat.div_mul_cancel (Nat.gcd_dvd_left a b)
  have hbb : b / g * g = b := Nat.div_mul_cancel (Nat.gcd_dvd_right a b)
  rw [ha, hbb] at h1
  have h2 : Nat.gcd (a / g) (b / g) * g = 1 * g := by
    simpa [g] using h1
  exact Nat.eq_of_mul_eq_mul_right hg_pos h2

/-- Helper: sign-preserving exact integer division by a divisor of `n.natAbs`. -/
def divByGcdInt (n : Int) (g : Nat) : Int :=
  if 0 ≤ n then
    Nat.cast (n.natAbs / g)
  else
    - Nat.cast (n.natAbs / g)

theorem divByGcdInt_natAbs (n : Int) (g : Nat) :
    (divByGcdInt n g).natAbs = n.natAbs / g := by
  unfold divByGcdInt
  split
  · exact Int.natAbs_natCast (n.natAbs / g)
  · rw [Int.natAbs_neg]
    exact Int.natAbs_natCast (n.natAbs / g)

theorem divByGcdInt_mul_cancel {n : Int} {g : Nat} (hdvd : g ∣ n.natAbs) :
    divByGcdInt n g * (g : Int) = n := by
  have hnat : n.natAbs / g * g = n.natAbs := Nat.div_mul_cancel hdvd
  have hcast : (Nat.cast (n.natAbs / g) : Int) * (g : Int) = (n.natAbs : Int) := by
    rw [← Int.natCast_mul, hnat]
  unfold divByGcdInt
  split
  case isTrue hnonneg =>
    rw [hcast]
    omega
  case isFalse hneg =>
    rw [Int.neg_mul, hcast]
    omega

/--
  Total validated constructor for `ExactRat`:
  - Rejects `den = 0` (`none`)
  - Normalizes `(num, den)` to reduced coprime form with `0/q ↦ 0/1`.
-/
def mkExactRat? (num : Int) (den : Nat) : Option ExactRat :=
  if hpos : 0 < den then
    let g := Nat.gcd num.natAbs den
    have hg_pos : 0 < g := Nat.gcd_pos_of_pos_right num.natAbs hpos
    have hg_le : g ≤ den := Nat.le_of_dvd hpos (Nat.gcd_dvd_right num.natAbs den)
    have hden_div_pos : 0 < den / g := Nat.div_pos hg_le hg_pos
    some
      { num := divByGcdInt num g
        den := den / g
        den_pos := hden_div_pos
        reduced := by
          rw [divByGcdInt_natAbs]
          exact gcd_div_gcd_eq_one hpos }
  else
    none

@[simp]
theorem mkExactRat?_zero_den (num : Int) : mkExactRat? num 0 = none := rfl

theorem mkExactRat?_some_of_pos (num : Int) {den : Nat} (hpos : 0 < den) :
    ∃ r : ExactRat, mkExactRat? num den = some r ∧ RatValEq num den r.num r.den := by
  unfold mkExactRat?
  rw [dif_pos hpos]
  refine ⟨_, rfl, ?_⟩
  unfold RatValEq
  dsimp
  let g := Nat.gcd num.natAbs den
  have hdvd_n : g ∣ num.natAbs := Nat.gcd_dvd_left num.natAbs den
  have hdvd_d : g ∣ den := Nat.gcd_dvd_right num.natAbs den
  have hn : divByGcdInt num g * (g : Int) = num := divByGcdInt_mul_cancel hdvd_n
  have hd_nat : (den / g) * g = den := Nat.div_mul_cancel hdvd_d
  have hd : ((den / g : Nat) : Int) * (g : Int) = (den : Int) := by
    exact_mod_cast hd_nat
  have hstep1 : num * ((den / g : Nat) : Int) = (divByGcdInt num g * (g : Int)) * ((den / g : Nat) : Int) :=
    congrArg (· * ((den / g : Nat) : Int)) hn.symm
  calc
    num * ((den / g : Nat) : Int)
        = (divByGcdInt num g * (g : Int)) * ((den / g : Nat) : Int) := hstep1
    _ = divByGcdInt num g * (((den / g : Nat) : Int) * (g : Int)) := by
          rw [Int.mul_assoc, Int.mul_comm (g : Int)]
    _ = divByGcdInt num g * (den : Int) := by rw [hd]

/-- Coprime naturals with equal cross-product are equal. -/
theorem eq_of_coprime_mul_eq {a₁ b₁ a₂ b₂ : Nat}
    (hb₁ : 0 < b₁) (hb₂ : 0 < b₂)
    (hc₁ : Nat.gcd a₁ b₁ = 1) (hc₂ : Nat.gcd a₂ b₂ = 1)
    (heq : a₁ * b₂ = a₂ * b₁) : a₁ = a₂ ∧ b₁ = b₂ := by
  have hdvd₁ : b₁ ∣ a₁ * b₂ := ⟨a₂, by rw [heq, Nat.mul_comm]⟩
  have hb₁_dvd_b₂ : b₁ ∣ b₂ := Nat.Coprime.dvd_of_dvd_mul_left (Nat.Coprime.symm hc₁) hdvd₁
  have hdvd₂ : b₂ ∣ a₂ * b₁ := ⟨a₁, by rw [← heq, Nat.mul_comm]⟩
  have hb₂_dvd_b₁ : b₂ ∣ b₁ := Nat.Coprime.dvd_of_dvd_mul_left (Nat.Coprime.symm hc₂) hdvd₂
  have hb_eq : b₁ = b₂ := Nat.dvd_antisymm hb₁_dvd_b₂ hb₂_dvd_b₁
  subst hb_eq
  have ha_eq : a₁ = a₂ := Nat.eq_of_mul_eq_mul_right hb₁ heq
  exact ⟨ha_eq, rfl⟩

/-- Canonical uniqueness of `ExactRat`: equal rational value iff structurally identical! -/
theorem ext_iff_ratValEq (r₁ r₂ : ExactRat) :
    r₁ = r₂ ↔ RatValEq r₁.num r₁.den r₂.num r₂.den := by
  constructor
  · intro h
    subst h
    rfl
  · intro hval
    unfold RatValEq at hval
    have habs : (r₁.num * (r₂.den : Int)).natAbs = (r₂.num * (r₁.den : Int)).natAbs :=
      congrArg Int.natAbs hval
    rw [Int.natAbs_mul, Int.natAbs_mul, Int.natAbs_natCast, Int.natAbs_natCast] at habs
    have ⟨ha, hb⟩ := eq_of_coprime_mul_eq r₁.den_pos r₂.den_pos r₁.reduced r₂.reduced habs
    rw [← hb] at hval
    have hnum : r₁.num = r₂.num := by
      have hsub : (r₁.num - r₂.num) * (r₁.den : Int) = 0 := by
        rw [Int.sub_mul, hval, Int.sub_self]
      have hd_pos : 0 < r₁.den := r₁.den_pos
      cases Int.mul_eq_zero.mp hsub with
      | inl h0 => omega
      | inr hd0 => omega
    cases r₁ with
    | mk n₁ d₁ hp₁ hr₁ =>
      cases r₂ with
      | mk n₂ d₂ hp₂ hr₂ =>
        simp at hnum hb
        subst hnum hb
        rfl

end ExactRat
end BrocaOmega.P1
