/-
  BROCA-NATIVE Ω — Gate C1-P1
  FormalSpec/Arithmetic/Rounding.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies)
  Proves the 3-way equivalence between:
    1. `ValidRoundAwz` (Division-free integer cross-multiplication kernel predicate)
    2. `roundHalfAwayFromZero` (Total Euclidean quotient rounding function)
    3. `IsNearestIntHalfAway` (Universal ∀ k ∈ ℤ closest-integer distance & tie-breaking spec)
  plus determinism, sign symmetry, zero canonicalization, scale invariance, and 0.5 boundary safety.
-/
import FormalSpec.Arithmetic.DecLit

namespace BrocaOmega.P1

/-- Exact integer power of 10: `10 ^ d` in `Int` (avoids `↑(10 ^ d)` vs `10 ^ d` cast friction). -/
abbrev pow10Int (d : Nat) : Int := ((10 ^ d : Nat) : Int)

theorem pow10Int_pos (d : Nat) : 0 < pow10Int d :=
  DecLit.pow10_int_pos d

/--
  Gate C0-R1 Division-Free Cross-Multiplication Rounding Predicate (`RoundHalfAwayFromZero`).
  Verifies whether `m * 10^(-d)` is the half-away-from-zero rounding of `p / q` (`q > 0`).
-/
def ValidRoundAwz (p : Int) (q : Nat) (m : Int) (d : Nat) : Prop :=
  0 < q ∧
  ((p = 0 ∧ m = 0) ∨
   (0 < p ∧ 0 ≤ m ∧
     (q : Int) * (2 * m - 1) ≤ 2 * pow10Int d * p ∧
     2 * pow10Int d * p < (q : Int) * (2 * m + 1)) ∨
   (p < 0 ∧ m ≤ 0 ∧
     (q : Int) * (-2 * m - 1) ≤ 2 * pow10Int d * (-p) ∧
     2 * pow10Int d * (-p) < (q : Int) * (-2 * m + 1)))

instance (p : Int) (q : Nat) (m : Int) (d : Nat) : Decidable (ValidRoundAwz p q m d) := by
  unfold ValidRoundAwz
  infer_instance

/-- Euclidean quotient core on non-negative magnitudes: `(2 * 10^d * absP + q) / (2 * q)`. -/
def roundHalfAwayNat (absP : Nat) (q : Nat) (d : Nat) : Nat :=
  (2 * (10 ^ d) * absP + q) / (2 * q)

/--
  Total reference function for `RoundHalfAwayFromZero(10^d * p / q)`.
-/
def roundHalfAwayFromZero (p : Int) (q : Nat) (d : Nat) : Int :=
  if q = 0 then 0
  else if p = 0 then 0
  else if 0 < p then
    Nat.cast (roundHalfAwayNat p.natAbs q d)
  else
    - Nat.cast (roundHalfAwayNat p.natAbs q d)

/--
  Scaled rational distance `|2 * 10^d * p - 2 * q * k| = 2 * q * |10^d * (p / q) - k|`.
-/
def scaledDist2Q (p : Int) (q : Nat) (d : Nat) (k : Int) : Nat :=
  (2 * pow10Int d * p - 2 * (q : Int) * k).natAbs

/--
  Independent Declarative Metric Specification (`IsNearestIntHalfAway`):
  `m` minimizes exact rational distance to `10^d * (p / q)` across all `k ∈ ℤ`,
  and breaks exact `0.5` halfway ties strictly away from zero (`k.natAbs < m.natAbs`).
-/
def IsNearestIntHalfAway (p : Int) (q : Nat) (d : Nat) (m : Int) : Prop :=
  0 < q ∧
  (∀ k : Int, scaledDist2Q p q d m ≤ scaledDist2Q p q d k) ∧
  (∀ k : Int, scaledDist2Q p q d k = scaledDist2Q p q d m → k ≠ m → k.natAbs < m.natAbs)

/-! ### Bilinear Ring Identities & Euclidean Division Uniqueness Lemmas -/

private theorem expand_q_two_m_sub_one (q m : Int) :
    q * (2 * m - 1) = 2 * (q * m) - q := by
  rw [Int.mul_sub, Int.mul_one, ← Int.mul_assoc, Int.mul_comm q 2, Int.mul_assoc]

private theorem expand_q_two_m_add_one (q m : Int) :
    q * (2 * m + 1) = 2 * (q * m) + q := by
  rw [Int.mul_add, Int.mul_one, ← Int.mul_assoc, Int.mul_comm q 2, Int.mul_assoc]

/-- Natural-number Euclidean quotient characterization: `N / B = m ↔ B * m ≤ N ∧ N < B * (m + 1)`. -/
theorem nat_div_eq_iff_bounds {N B m : Nat} (hB : 0 < B) :
    N / B = m ↔ B * m ≤ N ∧ N < B * (m + 1) := by
  constructor
  · intro hdiv
    have hmod : N % B < B := Nat.mod_lt N hB
    have halg : B * (N / B) + N % B = N := Nat.div_add_mod N B
    rw [hdiv] at halg
    rw [Nat.mul_add, Nat.mul_one]
    omega
  · rintro ⟨hlo, hhi⟩
    have hmod : N % B < B := Nat.mod_lt N hB
    have halg : B * (N / B) + N % B = N := Nat.div_add_mod N B
    let qv := N / B
    have hqv_eq : N / B = qv := rfl
    rw [hqv_eq] at halg ⊢
    by_cases hlt : qv < m
    · have hle1 : qv + 1 ≤ m := hlt
      have hmul : B * (qv + 1) ≤ B * m := Nat.mul_le_mul_left B hle1
      rw [Nat.mul_add, Nat.mul_one] at hmul
      omega
    · by_cases hgt : m < qv
      · have hle2 : m + 1 ≤ qv := hgt
        have hmul : B * (m + 1) ≤ B * qv := Nat.mul_le_mul_left B hle2
        omega
      · omega

/-- Core bridge between `(A + q) / (2 * q) = m` and `q * (2m - 1) ≤ A < q * (2m + 1)`. -/
theorem nat_halfway_div_iff_int_bounds {A q m : Nat} (hq : 0 < q) :
    (A + q) / (2 * q) = m ↔
      (q : Int) * (2 * (m : Int) - 1) ≤ (A : Int) ∧ (A : Int) < (q : Int) * (2 * (m : Int) + 1) := by
  have h2q : 0 < 2 * q := by omega
  rw [nat_div_eq_iff_bounds h2q]
  have he1 : (q : Int) * (2 * (m : Int) - 1) = 2 * ((q : Int) * (m : Int)) - (q : Int) :=
    expand_q_two_m_sub_one (q : Int) (m : Int)
  have he2 : (q : Int) * (2 * (m : Int) + 1) = 2 * ((q : Int) * (m : Int)) + (q : Int) :=
    expand_q_two_m_add_one (q : Int) (m : Int)
  have hcast1 : (((2 * q) * m : Nat) : Int) = 2 * ((q : Int) * (m : Int)) := by
    rw [Int.natCast_mul, Int.natCast_mul, Int.mul_assoc]; rfl
  have hcast2 : (((2 * q) * (m + 1) : Nat) : Int) = 2 * ((q : Int) * (m : Int)) + 2 * (q : Int) := by
    rw [Nat.mul_add, Nat.mul_one, Int.natCast_add, hcast1, Int.natCast_mul]; rfl
  constructor
  · rintro ⟨hlo_nat, hhi_nat⟩
    have hlo_i : (((2 * q) * m : Nat) : Int) ≤ ((A + q : Nat) : Int) := Int.ofNat_le.mpr hlo_nat
    have hhi_i : ((A + q : Nat) : Int) < (((2 * q) * (m + 1) : Nat) : Int) := Int.ofNat_lt.mpr hhi_nat
    rw [hcast1, Int.natCast_add] at hlo_i
    rw [hcast2, Int.natCast_add] at hhi_i
    rw [he1, he2]
    omega
  · rintro ⟨hlo_i, hhi_i⟩
    rw [he1] at hlo_i
    rw [he2] at hhi_i
    have hlo_c : (((2 * q) * m : Nat) : Int) ≤ ((A + q : Nat) : Int) := by
      rw [hcast1, Int.natCast_add]; omega
    have hhi_c : ((A + q : Nat) : Int) < (((2 * q) * (m + 1) : Nat) : Int) := by
      rw [hcast2, Int.natCast_add]; omega
    exact ⟨Int.ofNat_le.mp hlo_c, Int.ofNat_lt.mp hhi_c⟩

/--
  THEOREM 1 (Main Equivalence — `PO-C1-04a` Core):
  For all `p ∈ ℤ`, `q > 0`, `m ∈ ℤ`, `d ∈ ℕ`:
  `ValidRoundAwz p q m d ↔ m = roundHalfAwayFromZero p q d`.
-/
theorem validRoundAwz_iff_eq_roundHalfAway {p : Int} {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz p q m d ↔ m = roundHalfAwayFromZero p q d := by
  have hq_ne : q ≠ 0 := Nat.ne_of_gt hq
  by_cases hp0 : p = 0
  · subst hp0
    unfold ValidRoundAwz roundHalfAwayFromZero
    simp [hq, hq_ne]
  · by_cases hpos : 0 < p
    · have hp_not_lt : ¬(p < 0) := by omega
      have hp_abs : ((p.natAbs : Nat) : Int) = p := Int.natAbs_of_nonneg (Int.le_of_lt hpos)
      let A : Nat := 2 * (10 ^ d) * p.natAbs
      have hA : (A : Int) = 2 * pow10Int d * p := by
        dsimp [A, pow10Int]
        rw [hp_abs]
      constructor
      · intro hv
        rcases hv with ⟨_, h0 | hp_branch | hn_branch⟩
        · exact absurd h0.1 hp0
        · rcases hp_branch with ⟨_, hm_nonneg, hlo, hhi⟩
          let mNat := m.natAbs
          have hm_eq : ((mNat : Nat) : Int) = m := Int.natAbs_of_nonneg hm_nonneg
          rw [← hm_eq, ← hA] at hlo hhi
          have hdiv : roundHalfAwayNat p.natAbs q d = mNat :=
            (nat_halfway_div_iff_int_bounds hq).mpr ⟨hlo, hhi⟩
          unfold roundHalfAwayFromZero
          rw [if_neg hq_ne, if_neg hp0, if_pos hpos, hdiv]
          exact hm_eq.symm
        · exact absurd hn_branch.1 hp_not_lt
      · intro hm_eq
        unfold roundHalfAwayFromZero at hm_eq
        rw [if_neg hq_ne, if_neg hp0, if_pos hpos] at hm_eq
        subst hm_eq
        let mNat := roundHalfAwayNat p.natAbs q d
        have ⟨hlo, hhi⟩ := (nat_halfway_div_iff_int_bounds (A := A) (m := mNat) hq).mp rfl
        rw [hA] at hlo hhi
        exact ⟨hq, Or.inr (Or.inl ⟨hpos, Int.natCast_nonneg mNat, hlo, hhi⟩)⟩
    · have hneg : p < 0 := by omega
      have hp_abs : ((p.natAbs : Nat) : Int) = -p := by omega
      let A : Nat := 2 * (10 ^ d) * p.natAbs
      have hA : (A : Int) = 2 * pow10Int d * (-p) := by
        dsimp [A, pow10Int]
        rw [hp_abs]
      constructor
      · intro hv
        rcases hv with ⟨_, h0 | hp_branch | hn_branch⟩
        · exact absurd h0.1 hp0
        · exact absurd hp_branch.1 hpos
        · rcases hn_branch with ⟨_, hm_nonpos, hlo, hhi⟩
          let mNat := m.natAbs
          have hm_abs : ((mNat : Nat) : Int) = -m := by omega
          have h1 : (q : Int) * (-2 * m - 1) = (q : Int) * (2 * (mNat : Int) - 1) :=
            congrArg ((q : Int) * ·) (by omega)
          have h2 : (q : Int) * (-2 * m + 1) = (q : Int) * (2 * (mNat : Int) + 1) :=
            congrArg ((q : Int) * ·) (by omega)
          rw [h1, ← hA] at hlo
          rw [h2, ← hA] at hhi
          have hdiv : roundHalfAwayNat p.natAbs q d = mNat :=
            (nat_halfway_div_iff_int_bounds hq).mpr ⟨hlo, hhi⟩
          unfold roundHalfAwayFromZero
          rw [if_neg hq_ne, if_neg hp0, if_neg hpos, hdiv]
          omega
      · intro hm_eq
        unfold roundHalfAwayFromZero at hm_eq
        rw [if_neg hq_ne, if_neg hp0, if_neg hpos] at hm_eq
        subst hm_eq
        let mNat := roundHalfAwayNat p.natAbs q d
        have ⟨hlo, hhi⟩ := (nat_halfway_div_iff_int_bounds (A := A) (m := mNat) hq).mp rfl
        rw [hA] at hlo hhi
        have h1 : (q : Int) * (-2 * -((mNat : Nat) : Int) - 1) = (q : Int) * (2 * (mNat : Int) - 1) :=
          congrArg ((q : Int) * ·) (by omega)
        have h2 : (q : Int) * (-2 * -((mNat : Nat) : Int) + 1) = (q : Int) * (2 * (mNat : Int) + 1) :=
          congrArg ((q : Int) * ·) (by omega)
        have hm_le : -((mNat : Nat) : Int) ≤ 0 := by omega
        refine ⟨hq, Or.inr (Or.inr ⟨hneg, hm_le, ?_, ?_⟩)⟩
        · rw [h1]; exact hlo
        · rw [h2]; exact hhi

/-- Specialization of Main Equivalence directly to `ExactRat`. -/
theorem ExactRat.validRoundAwz_iff (r : ExactRat) (m : Int) (d : Nat) :
    ValidRoundAwz r.num r.den m d ↔ m = roundHalfAwayFromZero r.num r.den d :=
  validRoundAwz_iff_eq_roundHalfAway r.den_pos m d

/-! ### Determinism, Totality, Sign Symmetry, Zero Canonicalization -/

/-- Determinism: for given `(p, q, d)`, at most one integer `m` satisfies `ValidRoundAwz`. -/
theorem validRoundAwz_unique {p : Int} {q : Nat} {m₁ m₂ : Int} {d : Nat}
    (h₁ : ValidRoundAwz p q m₁ d) (h₂ : ValidRoundAwz p q m₂ d) : m₁ = m₂ := by
  have hq : 0 < q := h₁.1
  rw [validRoundAwz_iff_eq_roundHalfAway hq] at h₁ h₂
  exact h₁.trans h₂.symm

/-- Totality: `roundHalfAwayFromZero` always produces a valid witness when `q > 0`. -/
theorem validRoundAwz_roundHalfAway {p : Int} {q : Nat} (hq : 0 < q) (d : Nat) :
    ValidRoundAwz p q (roundHalfAwayFromZero p q d) d :=
  (validRoundAwz_iff_eq_roundHalfAway hq _ d).mpr rfl

/-- Sign Symmetry of `roundHalfAwayFromZero`: `R(-p, q, d) = - R(p, q, d)`. -/
theorem roundHalfAwayFromZero_neg (p : Int) (q : Nat) (d : Nat) :
    roundHalfAwayFromZero (-p) q d = - roundHalfAwayFromZero p q d := by
  by_cases hq : q = 0
  · unfold roundHalfAwayFromZero; rw [if_pos hq, if_pos hq]; rfl
  · by_cases hp0 : p = 0
    · subst hp0; unfold roundHalfAwayFromZero; simp [hq]
    · by_cases hpos : 0 < p
      · have hneg : ¬(0 < -p) := by omega
        have hne : -p ≠ 0 := by omega
        unfold roundHalfAwayFromZero
        rw [if_neg hq, if_neg hne, if_neg hneg, if_neg hq, if_neg hp0, if_pos hpos, Int.natAbs_neg]
      · have hpos_neg : 0 < -p := by omega
        have hne : -p ≠ 0 := by omega
        unfold roundHalfAwayFromZero
        rw [if_neg hq, if_neg hne, if_pos hpos_neg, if_neg hq, if_neg hp0, if_neg hpos,
            Int.natAbs_neg, Int.neg_neg]

/-- Sign Symmetry on `ExactRat`: `R(-r, d) = - R(r, d)`. -/
theorem ExactRat.roundHalfAway_neg (r : ExactRat) (d : Nat) :
    roundHalfAwayFromZero r.neg.num r.neg.den d = - roundHalfAwayFromZero r.num r.den d := by
  simp [roundHalfAwayFromZero_neg]

/-- Sign Symmetry of `ValidRoundAwz`: `ValidRoundAwz (-p) q (-m) d ↔ ValidRoundAwz p q m d`. -/
theorem validRoundAwz_neg_iff (p : Int) (q : Nat) (m : Int) (d : Nat) :
    ValidRoundAwz (-p) q (-m) d ↔ ValidRoundAwz p q m d := by
  by_cases hq : 0 < q
  · rw [validRoundAwz_iff_eq_roundHalfAway hq, validRoundAwz_iff_eq_roundHalfAway hq,
        roundHalfAwayFromZero_neg]
    omega
  · unfold ValidRoundAwz
    simp [hq]

/-- Zero Canonicalization: rounding `0 / q` (`q > 0`) at any precision `d` yields `0`. -/
@[simp]
theorem roundHalfAwayFromZero_zero (q d : Nat) :
    roundHalfAwayFromZero 0 q d = 0 := by
  unfold roundHalfAwayFromZero
  split <;> rfl

theorem validRoundAwz_zero_iff {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz 0 q m d ↔ m = 0 := by
  rw [validRoundAwz_iff_eq_roundHalfAway hq, roundHalfAwayFromZero_zero]

/-! ### Metric Optimality Equivalence (`ValidRoundAwz ↔ IsNearestIntHalfAway`) -/

private theorem pos_bounds_imply_nearest {P q m : Int}
    (hP : 0 < P) (hq : 0 < q) (hm : 0 ≤ m)
    (hlo : q * (2 * m - 1) ≤ 2 * P) (hhi : 2 * P < q * (2 * m + 1)) :
    (∀ k : Int, (2 * P - 2 * q * m).natAbs ≤ (2 * P - 2 * q * k).natAbs) ∧
    (∀ k : Int, (2 * P - 2 * q * k).natAbs = (2 * P - 2 * q * m).natAbs → k ≠ m → k.natAbs < m.natAbs) := by
  have he_lo : 2 * (q * m) - q ≤ 2 * P := by rw [← expand_q_two_m_sub_one]; exact hlo
  have he_hi : 2 * P < 2 * (q * m) + q := by rw [← expand_q_two_m_add_one]; exact hhi
  have h2qm : 2 * q * m = 2 * (q * m) := Int.mul_assoc 2 q m
  constructor
  · intro k
    have h2qk : 2 * q * k = 2 * (q * k) := Int.mul_assoc 2 q k
    rw [h2qm, h2qk]
    by_cases hkm : k = m
    · subst hkm; exact Nat.le_refl _
    · by_cases hk_gt : m + 1 ≤ k
      · have hqk : q * m + q ≤ q * k := by
          have : q * (m + 1) ≤ q * k := Int.mul_le_mul_of_nonneg_left hk_gt (by omega)
          rw [Int.mul_add, Int.mul_one] at this; exact this
        omega
      · by_cases hk_eq : k = m - 1
        · subst hk_eq
          have hqk : q * (m - 1) = q * m - q := by rw [Int.mul_sub, Int.mul_one]
          rw [hqk]
          omega
        · have hk_le : k ≤ m - 2 := by omega
          have hqk : q * k ≤ q * m - 2 * q := by
            have : q * k ≤ q * (m - 2) := Int.mul_le_mul_of_nonneg_left hk_le (by omega)
            have hsub : q * (m - 2) = q * m - 2 * q := by
              rw [Int.mul_sub, Int.mul_comm q 2]
            rw [hsub] at this; exact this
          omega
  · intro k hdist hne
    have h2qk : 2 * q * k = 2 * (q * k) := Int.mul_assoc 2 q k
    rw [h2qm, h2qk] at hdist
    by_cases hk_gt : m + 1 ≤ k
    · have hqk : q * m + q ≤ q * k := by
        have : q * (m + 1) ≤ q * k := Int.mul_le_mul_of_nonneg_left hk_gt (by omega)
        rw [Int.mul_add, Int.mul_one] at this; exact this
      omega
    · by_cases hk_eq : k = m - 1
      · subst hk_eq
        have hqk : q * (m - 1) = q * m - q := by rw [Int.mul_sub, Int.mul_one]
        rw [hqk] at hdist
        -- When m = 0, 2*P ≥ 2 and q ≥ 1 make |2P + 2q| = |2P| impossible!
        have hm1 : 1 ≤ m := by
          by_cases hm0 : m = 0
          · subst hm0; simp at he_lo he_hi hdist; omega
          · omega
        omega
      · have hk_le : k ≤ m - 2 := by omega
        have hqk : q * k ≤ q * m - 2 * q := by
          have : q * k ≤ q * (m - 2) := Int.mul_le_mul_of_nonneg_left hk_le (by omega)
          have hsub : q * (m - 2) = q * m - 2 * q := by
            rw [Int.mul_sub, Int.mul_comm q 2]
          rw [hsub] at this; exact this
        omega

/-- Forward Lemma: `ValidRoundAwz → IsNearestIntHalfAway`. -/
theorem validRoundAwz_implies_isNearest {p : Int} {q : Nat} {m : Int} {d : Nat}
    (hv : ValidRoundAwz p q m d) : IsNearestIntHalfAway p q d m := by
  have hq : 0 < q := hv.1
  have hq_int : (0 : Int) < (q : Int) := Int.ofNat_lt.mpr hq
  refine ⟨hq, ?_⟩
  rcases hv with ⟨_, hzero | hpos | hneg⟩
  · rcases hzero with ⟨hp0, hm0⟩
    subst hp0 hm0
    unfold scaledDist2Q
    constructor
    · intro k; simp
    · intro k hdist hne
      simp at hdist
      have hqk : (2 * (q : Int)) * k = 0 := by omega
      cases Int.mul_eq_zero.mp hqk with
      | inl h => omega
      | inr h => exact absurd h hne
  · rcases hpos with ⟨hp, hm, hlo, hhi⟩
    let P : Int := pow10Int d * p
    have hP_pos : 0 < P := Int.mul_pos (pow10Int_pos d) hp
    have h2P : 2 * pow10Int d * p = 2 * P := Int.mul_assoc 2 (pow10Int d) p
    rw [h2P] at hlo hhi
    have ⟨hd1, hd2⟩ := pos_bounds_imply_nearest hP_pos hq_int hm hlo hhi
    unfold scaledDist2Q
    simp only [h2P]
    exact ⟨hd1, hd2⟩
  · rcases hneg with ⟨hp, hm, hlo, hhi⟩
    let P : Int := pow10Int d * (-p)
    have hP_pos : 0 < P := Int.mul_pos (pow10Int_pos d) (by omega)
    have h2P : 2 * pow10Int d * (-p) = 2 * P := Int.mul_assoc 2 (pow10Int d) (-p)
    rw [h2P] at hlo hhi
    have hm_neg_nonneg : 0 ≤ -m := by omega
    have hlo' : (q : Int) * (2 * (-m) - 1) ≤ 2 * P := by
      have h1 : (q : Int) * (2 * (-m) - 1) = (q : Int) * (-2 * m - 1) := congrArg ((q : Int) * ·) (by omega)
      rw [h1]; exact hlo
    have hhi' : 2 * P < (q : Int) * (2 * (-m) + 1) := by
      have h2 : (q : Int) * (2 * (-m) + 1) = (q : Int) * (-2 * m + 1) := congrArg ((q : Int) * ·) (by omega)
      rw [h2]; exact hhi
    have ⟨hd1, hd2⟩ := pos_bounds_imply_nearest hP_pos hq_int hm_neg_nonneg hlo' hhi'
    have hsym : ∀ k : Int, scaledDist2Q p q d k = (2 * P - 2 * (q : Int) * (-k)).natAbs := by
      intro k
      unfold scaledDist2Q
      have hp1 : 2 * P = - (2 * pow10Int d * p) := by
        dsimp [P]
        rw [← Int.mul_assoc, Int.mul_neg]
      have hk1 : 2 * (q : Int) * (-k) = - (2 * (q : Int) * k) := Int.mul_neg _ _
      have hdiff : 2 * pow10Int d * p - 2 * (q : Int) * k = - (2 * P - 2 * (q : Int) * (-k)) := by
        omega
      rw [hdiff, Int.natAbs_neg]
    constructor
    · intro k
      rw [hsym m, hsym k]
      exact hd1 (-k)
    · intro k heq_dist hne
      rw [hsym k, hsym m] at heq_dist
      have hlt := hd2 (-k) heq_dist (by omega)
      simpa [Int.natAbs_neg] using hlt

/--
  THEOREM 2 (Metric Adequacy — Non-Circular Closest-Integer Equivalence):
  `ValidRoundAwz p q m d ↔ IsNearestIntHalfAway p q d m`.
-/
theorem validRoundAwz_iff_isNearestIntHalfAway {p : Int} {q : Nat} (hq : 0 < q) (m : Int) (d : Nat) :
    ValidRoundAwz p q m d ↔ IsNearestIntHalfAway p q d m := by
  constructor
  · exact validRoundAwz_implies_isNearest
  · intro hnear
    let m₀ := roundHalfAwayFromZero p q d
    have hv₀ : ValidRoundAwz p q m₀ d := validRoundAwz_roundHalfAway hq d
    have hnear₀ : IsNearestIntHalfAway p q d m₀ := validRoundAwz_implies_isNearest hv₀
    by_cases heq : m = m₀
    · rw [heq]; exact hv₀
    · have hle1 : scaledDist2Q p q d m ≤ scaledDist2Q p q d m₀ := hnear.2.1 m₀
      have hle2 : scaledDist2Q p q d m₀ ≤ scaledDist2Q p q d m := hnear₀.2.1 m
      have hdist_eq : scaledDist2Q p q d m₀ = scaledDist2Q p q d m := Nat.le_antisymm hle2 hle1
      have hlt1 : m₀.natAbs < m.natAbs := hnear.2.2 m₀ hdist_eq (Ne.symm heq)
      have hlt2 : m.natAbs < m₀.natAbs := hnear₀.2.2 m hdist_eq.symm heq
      omega

/-! ### Exact 0.5 Boundary & Scale-Invariance Theorems -/

private theorem pos_of_pos_mul_left {a b : Int} (ha : 0 < a) (hab : 0 < a * b) : 0 < b := by
  by_cases hb : 0 < b
  · exact hb
  · have hle : b ≤ 0 := by omega
    have hnp : a * b ≤ 0 := Int.mul_nonpos_of_nonneg_of_nonpos (Int.le_of_lt ha) hle
    omega

/-- Exact positive 0.5 boundary (`10^d * p / q = k + 0.5`, `k ≥ 0`): rounds AWAY from zero to `k + 1`, rejecting `k`. -/
theorem exact_pos_halfway_boundary {p : Int} {q : Nat} {k : Int} {d : Nat}
    (hq : 0 < q) (hk : 0 ≤ k)
    (hhalf : 2 * pow10Int d * p = (q : Int) * (2 * k + 1)) :
    ValidRoundAwz p q (k + 1) d ∧ ¬ ValidRoundAwz p q k d := by
  have hpow2 : 0 < 2 * pow10Int d := by have := pow10Int_pos d; omega
  have hrhs : 0 < (q : Int) * (2 * k + 1) := Int.mul_pos (Int.ofNat_lt.mpr hq) (by omega)
  have hp_pos : 0 < p := pos_of_pos_mul_left hpow2 (by omega)
  have hlo : (q : Int) * (2 * (k + 1) - 1) ≤ 2 * pow10Int d * p := by
    have : 2 * (k + 1) - 1 = 2 * k + 1 := by omega
    rw [this, hhalf]; exact Int.le_refl _
  have hhi : 2 * pow10Int d * p < (q : Int) * (2 * (k + 1) + 1) := by
    rw [hhalf]
    exact Int.mul_lt_mul_of_pos_left (by omega) (Int.ofNat_lt.mpr hq)
  have hv : ValidRoundAwz p q (k + 1) d := ⟨hq, Or.inr (Or.inl ⟨hp_pos, by omega, hlo, hhi⟩)⟩
  refine ⟨hv, ?_⟩
  intro hvk
  have heq := validRoundAwz_unique hv hvk
  omega

/-- Exact negative -0.5 boundary (`10^d * p / q = -(k + 0.5)`, `k ≥ 0`): rounds AWAY from zero to `-(k + 1)`, rejecting `-k`. -/
theorem exact_neg_halfway_boundary {p : Int} {q : Nat} {k : Int} {d : Nat}
    (hq : 0 < q) (hk : 0 ≤ k)
    (hhalf : 2 * pow10Int d * (-p) = (q : Int) * (2 * k + 1)) :
    ValidRoundAwz p q (-(k + 1)) d ∧ ¬ ValidRoundAwz p q (-k) d := by
  have ⟨hv, hnv⟩ := exact_pos_halfway_boundary (p := -p) hq hk hhalf
  have hv_neg : ValidRoundAwz p q (-(k + 1)) d := by
    have h := (validRoundAwz_neg_iff (-p) q (k + 1) d).mpr hv
    simpa [Int.neg_neg] using h
  refine ⟨hv_neg, ?_⟩
  intro hvk
  have hk_pos : ValidRoundAwz (-p) q k d := by
    have h := (validRoundAwz_neg_iff p q (-k) d).mpr hvk
    simpa [Int.neg_neg] using h
  exact hnv hk_pos

/-- Strictly below positive halfway (`q*(2k - 1) ≤ 2*10^d*p < q*(2k + 1)` with `p > 0, k ≥ 0`): accepts `k`, rejects `k + 1`. -/
theorem strictly_below_pos_halfway {p : Int} {q : Nat} {k : Int} {d : Nat}
    (hq : 0 < q) (hp : 0 < p) (hk : 0 ≤ k)
    (hlo : (q : Int) * (2 * k - 1) ≤ 2 * pow10Int d * p)
    (hhi : 2 * pow10Int d * p < (q : Int) * (2 * k + 1)) :
    ValidRoundAwz p q k d ∧ ¬ ValidRoundAwz p q (k + 1) d := by
  have hv : ValidRoundAwz p q k d := ⟨hq, Or.inr (Or.inl ⟨hp, hk, hlo, hhi⟩)⟩
  refine ⟨hv, ?_⟩
  intro hv_succ
  have heq := validRoundAwz_unique hv hv_succ
  omega

/-- Scale Invariance: equal fractions `(p₁, q₁)` and `(p₂, q₂)` (`q₁, q₂ > 0`) have identical `ValidRoundAwz` behavior. -/
theorem validRoundAwz_of_ratValEq {p₁ p₂ : Int} {q₁ q₂ : Nat} (hq₁ : 0 < q₁) (hq₂ : 0 < q₂)
    (heq : ExactRat.RatValEq p₁ q₁ p₂ q₂) (m : Int) (d : Nat) :
    ValidRoundAwz p₁ q₁ m d → ValidRoundAwz p₂ q₂ m d := by
  unfold ExactRat.RatValEq at heq
  have hq1_int : (0 : Int) < (q₁ : Int) := Int.ofNat_lt.mpr hq₁
  have hq2_int : (0 : Int) < (q₂ : Int) := Int.ofNat_lt.mpr hq₂
  rintro ⟨_, hzero | hpos | hneg⟩
  · rcases hzero with ⟨hp1, hm⟩
    subst hp1 hm
    simp at heq
    have hp2 : p₂ = 0 := by
      cases Int.mul_eq_zero.mp heq.symm with
      | inl h => exact h
      | inr h => omega
    exact ⟨hq₂, Or.inl ⟨hp2, rfl⟩⟩
  · rcases hpos with ⟨hp1, hm, hlo, hhi⟩
    have hprod_pos : 0 < (q₁ : Int) * p₂ := by
      have : 0 < p₁ * (q₂ : Int) := Int.mul_pos hp1 hq2_int
      rw [heq, Int.mul_comm] at this
      exact this
    have hp2 : 0 < p₂ := pos_of_pos_mul_left hq1_int hprod_pos
    have hmul_eq : (q₁ : Int) * (2 * pow10Int d * p₂) = (q₂ : Int) * (2 * pow10Int d * p₁) := by
      calc
        (q₁ : Int) * (2 * pow10Int d * p₂)
            = (2 * pow10Int d) * ((q₁ : Int) * p₂) := by
                rw [← Int.mul_assoc, Int.mul_comm (q₁ : Int) (2 * pow10Int d), Int.mul_assoc]
        _ = (2 * pow10Int d) * (p₂ * (q₁ : Int)) := by rw [Int.mul_comm (q₁ : Int) p₂]
        _ = (2 * pow10Int d) * (p₁ * (q₂ : Int)) := by rw [heq]
        _ = (q₂ : Int) * (2 * pow10Int d * p₁) := by
                rw [← Int.mul_assoc, Int.mul_comm (2 * pow10Int d * p₁) (q₂ : Int)]
    have hcomm_q : ∀ x : Int, (q₂ : Int) * ((q₁ : Int) * x) = (q₁ : Int) * ((q₂ : Int) * x) := by
      intro x
      rw [← Int.mul_assoc, Int.mul_comm (q₂ : Int) (q₁ : Int), Int.mul_assoc]
    have hlo2 : (q₂ : Int) * (2 * m - 1) ≤ 2 * pow10Int d * p₂ := by
      have h1 : (q₁ : Int) * ((q₂ : Int) * (2 * m - 1)) ≤ (q₁ : Int) * (2 * pow10Int d * p₂) := by
        rw [← hcomm_q, hmul_eq]
        exact Int.mul_le_mul_of_nonneg_left hlo (Int.le_of_lt hq2_int)
      exact Int.le_of_mul_le_mul_left h1 hq1_int
    have hhi2 : 2 * pow10Int d * p₂ < (q₂ : Int) * (2 * m + 1) := by
      have h1 : (q₁ : Int) * (2 * pow10Int d * p₂) < (q₁ : Int) * ((q₂ : Int) * (2 * m + 1)) := by
        rw [← hcomm_q, hmul_eq]
        exact Int.mul_lt_mul_of_pos_left hhi hq2_int
      exact Int.lt_of_mul_lt_mul_left h1 (Int.le_of_lt hq1_int)
    exact ⟨hq₂, Or.inr (Or.inl ⟨hp2, hm, hlo2, hhi2⟩)⟩
  · rcases hneg with ⟨hp1, hm, hlo, hhi⟩
    have hneg_pos1 : 0 < -p₁ := by omega
    have hprod_pos : 0 < (q₁ : Int) * (-p₂) := by
      have : 0 < (-p₁) * (q₂ : Int) := Int.mul_pos hneg_pos1 hq2_int
      have heq_neg : (-p₁) * (q₂ : Int) = (q₁ : Int) * (-p₂) := by
        rw [Int.neg_mul, heq, Int.mul_comm, ← Int.mul_neg]
      rw [heq_neg] at this
      exact this
    have hneg_pos2 : 0 < -p₂ := pos_of_pos_mul_left hq1_int hprod_pos
    have hp2 : p₂ < 0 := by omega
    have hmul_eq : (q₁ : Int) * (2 * pow10Int d * (-p₂)) = (q₂ : Int) * (2 * pow10Int d * (-p₁)) := by
      have heq_neg : (-p₂) * (q₁ : Int) = (-p₁) * (q₂ : Int) := by
        rw [Int.neg_mul, Int.neg_mul, heq]
      calc
        (q₁ : Int) * (2 * pow10Int d * (-p₂))
            = (2 * pow10Int d) * ((q₁ : Int) * (-p₂)) := by
                rw [← Int.mul_assoc, Int.mul_comm (q₁ : Int) (2 * pow10Int d), Int.mul_assoc]
        _ = (2 * pow10Int d) * ((-p₂) * (q₁ : Int)) := by rw [Int.mul_comm (q₁ : Int) (-p₂)]
        _ = (2 * pow10Int d) * ((-p₁) * (q₂ : Int)) := by rw [heq_neg]
        _ = (q₂ : Int) * (2 * pow10Int d * (-p₁)) := by
                rw [← Int.mul_assoc, Int.mul_comm (2 * pow10Int d * (-p₁)) (q₂ : Int)]
    have hcomm_q : ∀ x : Int, (q₂ : Int) * ((q₁ : Int) * x) = (q₁ : Int) * ((q₂ : Int) * x) := by
      intro x
      rw [← Int.mul_assoc, Int.mul_comm (q₂ : Int) (q₁ : Int), Int.mul_assoc]
    have hlo2 : (q₂ : Int) * (-2 * m - 1) ≤ 2 * pow10Int d * (-p₂) := by
      have h1 : (q₁ : Int) * ((q₂ : Int) * (-2 * m - 1)) ≤ (q₁ : Int) * (2 * pow10Int d * (-p₂)) := by
        rw [← hcomm_q, hmul_eq]
        exact Int.mul_le_mul_of_nonneg_left hlo (Int.le_of_lt hq2_int)
      exact Int.le_of_mul_le_mul_left h1 hq1_int
    have hhi2 : 2 * pow10Int d * (-p₂) < (q₂ : Int) * (-2 * m + 1) := by
      have h1 : (q₁ : Int) * (2 * pow10Int d * (-p₂)) < (q₁ : Int) * ((q₂ : Int) * (-2 * m + 1)) := by
        rw [← hcomm_q, hmul_eq]
        exact Int.mul_lt_mul_of_pos_left hhi hq2_int
      exact Int.lt_of_mul_lt_mul_left h1 (Int.le_of_lt hq1_int)
    exact ⟨hq₂, Or.inr (Or.inr ⟨hp2, hm, hlo2, hhi2⟩)⟩

theorem validRoundAwz_iff_of_ratValEq {p₁ p₂ : Int} {q₁ q₂ : Nat} (hq₁ : 0 < q₁) (hq₂ : 0 < q₂)
    (heq : ExactRat.RatValEq p₁ q₁ p₂ q₂) (m : Int) (d : Nat) :
    ValidRoundAwz p₁ q₁ m d ↔ ValidRoundAwz p₂ q₂ m d :=
  ⟨validRoundAwz_of_ratValEq hq₁ hq₂ heq m d,
   validRoundAwz_of_ratValEq hq₂ hq₁ heq.symm m d⟩

end BrocaOmega.P1
