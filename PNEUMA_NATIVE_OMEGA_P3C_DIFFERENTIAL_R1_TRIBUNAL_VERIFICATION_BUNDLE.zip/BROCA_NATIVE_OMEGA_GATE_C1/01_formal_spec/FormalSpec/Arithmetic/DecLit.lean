/-
  BROCA-NATIVE Ω — Gate C1-P1
  FormalSpec/Arithmetic/DecLit.lean
  Pure Lean 4.33.1 Core (Init only, zero external dependencies)
  Formalizes surface decimal tokens, negative-zero rejection, scale bounds,
  and the distinction between value equivalence (`valEq`) and format equality (`fmtEq`).
-/
import FormalSpec.Arithmetic.ExactRat

namespace BrocaOmega.P1

/-- Explicit rejection reasons for Gate C1-P1 exact arithmetic & rounding checks. -/
inductive P1ArithRejectReason where
  | zeroDenominator
  | negativeZeroForbidden
  | scaleBoundExceeded (observed : Nat) (maxAllowed : Nat)
  | formatScaleMismatch (expectedScale : Nat) (observedScale : Nat)
  | roundingMismatch (expectedMantissa : Int) (observedMantissa : Int)
  deriving DecidableEq, Repr

/--
  Untrusted raw surface decimal representation prior to ingress validation.
  Explicitly preserves `negSign` separately from `absMantissa` so malformed `-0` / `-0.0`
  inputs (`negSign = true ∧ absMantissa = 0`) are observable and deterministically rejected.
-/
structure RawDecToken where
  negSign     : Bool
  absMantissa : Nat
  scale10     : Nat
  deriving DecidableEq, Repr

namespace RawDecToken

/-- Mathematical signed integer represented by `RawDecToken` (when well-formed). -/
def toSignedInt (raw : RawDecToken) : Int :=
  if raw.negSign then - Int.ofNat raw.absMantissa else Int.ofNat raw.absMantissa

end RawDecToken

/--
  Validated canonical surface decimal literal representing `mantissa * 10^(-scale10)`.
  Negative zero cannot exist as a distinct value in `Int` (`-0 = 0`), and ingress
  blocks `RawDecToken` with `negSign = true ∧ absMantissa = 0`.
-/
structure DecLit where
  mantissa : Int
  scale10  : Nat
  deriving DecidableEq, Repr

namespace DecLit

/-- Ingress validator converting `RawDecToken` to `DecLit` under scale bound `maxScale`. -/
def admitRawToken (raw : RawDecToken) (maxScale : Nat) : Except P1ArithRejectReason DecLit :=
  if raw.negSign && raw.absMantissa == 0 then
    .error .negativeZeroForbidden
  else if raw.scale10 > maxScale then
    .error (.scaleBoundExceeded raw.scale10 maxScale)
  else
    let signedMantissa : Int :=
      if raw.negSign then - Int.ofNat raw.absMantissa else Int.ofNat raw.absMantissa
    .ok { mantissa := signedMantissa, scale10 := raw.scale10 }

/-- Theorem: `-0.0` (`negSign = true, absMantissa = 0`) is unconditionally rejected for any `maxScale`. -/
theorem admitRawToken_rejects_neg_zero (s maxScale : Nat) :
    admitRawToken { negSign := true, absMantissa := 0, scale10 := s } maxScale =
      .error .negativeZeroForbidden := rfl

/-- Theorem: any non-neg-zero token exceeding `maxScale` is rejected with `scaleBoundExceeded`. -/
theorem admitRawToken_rejects_scale_overflow (raw : RawDecToken) (maxScale : Nat)
    (hno_neg_zero : ¬(raw.negSign = true ∧ raw.absMantissa = 0))
    (hover : maxScale < raw.scale10) :
    admitRawToken raw maxScale = .error (.scaleBoundExceeded raw.scale10 maxScale) := by
  unfold admitRawToken
  have hcond1 : (raw.negSign && raw.absMantissa == 0) = false := by
    cases hns : raw.negSign
    · simp
    · simp
      intro h0
      exact hno_neg_zero ⟨hns, h0⟩
  rw [hcond1]
  simp [hover]

/-- Mathematical value equality: `m₁ * 10^(-s₁) = m₂ * 10^(-s₂)` iff `m₁ * 10^s₂ = m₂ * 10^s₁`. -/
def valEq (x y : DecLit) : Prop :=
  x.mantissa * ((10 ^ y.scale10 : Nat) : Int) = y.mantissa * ((10 ^ x.scale10 : Nat) : Int)

instance (x y : DecLit) : Decidable (valEq x y) :=
  inferInstanceAs (Decidable (x.mantissa * ((10 ^ y.scale10 : Nat) : Int) =
    y.mantissa * ((10 ^ x.scale10 : Nat) : Int)))

/-- Format equality: both mantissa AND significant decimal places (`scale10`) match identically. -/
def fmtEq (x y : DecLit) : Prop :=
  x.mantissa = y.mantissa ∧ x.scale10 = y.scale10

instance (x y : DecLit) : Decidable (fmtEq x y) :=
  inferInstanceAs (Decidable (x.mantissa = y.mantissa ∧ x.scale10 = y.scale10))

theorem fmtEq_iff_eq (x y : DecLit) : fmtEq x y ↔ x = y := by
  cases x; cases y
  simp [fmtEq]

theorem fmtEq_implies_valEq {x y : DecLit} (h : fmtEq x y) : valEq x y := by
  rcases h with ⟨hm, hs⟩
  unfold valEq
  rw [hm, hs]

theorem valEq_refl (x : DecLit) : valEq x x := rfl

theorem valEq_symm {x y : DecLit} (h : valEq x y) : valEq y x := h.symm

theorem pow10_pos (n : Nat) : 0 < 10 ^ n := by
  induction n with
  | zero => decide
  | succ k ih => omega

theorem pow10_int_pos (n : Nat) : (0 : Int) < ((10 ^ n : Nat) : Int) :=
  Int.ofNat_lt.mpr (pow10_pos n)

theorem valEq_trans {x y z : DecLit} (hxy : valEq x y) (hyz : valEq y z) : valEq x z := by
  unfold valEq at *
  have hy_pos : (0 : Int) < ((10 ^ y.scale10 : Nat) : Int) := pow10_int_pos y.scale10
  have hmul :
      (x.mantissa * ((10 ^ z.scale10 : Nat) : Int) - z.mantissa * ((10 ^ x.scale10 : Nat) : Int)) *
        ((10 ^ y.scale10 : Nat) : Int) = 0 := by
    calc
      (x.mantissa * ((10 ^ z.scale10 : Nat) : Int) - z.mantissa * ((10 ^ x.scale10 : Nat) : Int)) *
          ((10 ^ y.scale10 : Nat) : Int)
          = (x.mantissa * ((10 ^ y.scale10 : Nat) : Int)) * ((10 ^ z.scale10 : Nat) : Int) -
            (z.mantissa * ((10 ^ y.scale10 : Nat) : Int)) * ((10 ^ x.scale10 : Nat) : Int) := by
              rw [Int.sub_mul, Int.mul_assoc, Int.mul_comm ((10 ^ z.scale10 : Nat) : Int), ← Int.mul_assoc,
                  Int.mul_assoc z.mantissa, Int.mul_comm ((10 ^ x.scale10 : Nat) : Int), ← Int.mul_assoc]
      _ = (y.mantissa * ((10 ^ x.scale10 : Nat) : Int)) * ((10 ^ z.scale10 : Nat) : Int) -
            (y.mantissa * ((10 ^ z.scale10 : Nat) : Int)) * ((10 ^ x.scale10 : Nat) : Int) := by
              rw [hxy, hyz.symm]
      _ = 0 := by
          rw [Int.mul_assoc, Int.mul_comm ((10 ^ x.scale10 : Nat) : Int), ← Int.mul_assoc, Int.sub_self]
  cases Int.mul_eq_zero.mp hmul with
  | inl hdiff => omega
  | inr hpow0 => omega

/-- Explicit separation proof: `1.0` and `1.00` are value-equal (`valEq`) but NOT format-equal (`fmtEq`). -/
theorem one_point_zero_valEq_not_fmtEq :
    valEq { mantissa := 10, scale10 := 1 } { mantissa := 100, scale10 := 2 } ∧
    ¬ fmtEq { mantissa := 10, scale10 := 1 } { mantissa := 100, scale10 := 2 } := by
  decide

/-- Canonical embedding of any `DecLit` into `ExactRat`. -/
def toExactRat (x : DecLit) : ExactRat :=
  let den := 10 ^ x.scale10
  have hpos : 0 < den := pow10_pos x.scale10
  let g := Nat.gcd x.mantissa.natAbs den
  have hg_pos : 0 < g := Nat.gcd_pos_of_pos_right x.mantissa.natAbs hpos
  have hg_le : g ≤ den := Nat.le_of_dvd hpos (Nat.gcd_dvd_right x.mantissa.natAbs den)
  { num := ExactRat.divByGcdInt x.mantissa g
    den := den / g
    den_pos := Nat.div_pos hg_le hg_pos
    reduced := by
      rw [ExactRat.divByGcdInt_natAbs]
      exact ExactRat.gcd_div_gcd_eq_one hpos }

end DecLit
end BrocaOmega.P1
