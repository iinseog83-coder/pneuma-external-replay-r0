/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: Independent Frozen BNF Specification)
  01_formal_spec/P3FormalSpec/FrozenBNF.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  Gate A Deliverable:
  Extracted DIRECTLY from the read-only frozen specification lineage:
    - `S0-R2` (§III: 16 generator rules `G-01`~`G-16` + 5 trap rules `T1`~`T5`)
    - `S0-R2.1` (§II.1~2: DAG stratification, `ExpContrast`, `MeanSD`/`MedianIQR`, TOST CI)
    - `S0-R2.2` (§II.4: `sentence_atomic` vs `discourse_bound` `G-15`, `G-06` estimation modality)
    - `Gate C0-R1` / `Architecture Freeze R0` (§II.3: `G-06a` directional vs `G-06b` neutral)
    - `Gate C1-P0` (`P0-A05`: `21` canonical rule IDs, `readingAlt` semantic index `1..altCount`,
      `T1`~`T5` canonical slot productions, and explicit `UNSPECIFIED_IN_R0` ledger)

  CRITICAL NON-CIRCULARITY GUARANTEE:
  This module does NOT import, copy, or reverse-engineer `P2`'s `ruleSignature`.
-/
import P3FormalSpec.StrictLexicalSpec

namespace BrocaOmega.P3A

/-! ### 1. Canonical 21 Rule Families (`G-01`~`G-16` Generator vs `T1`~`T5` Parser-Only Traps) -/

/--
  Exact 21-member rule ID set frozen in `Gate C1-P0` (`P0-A05` §1.B):
  `16` canonical generator families (`G01`..`G16`) + `5` adversarial parser-only trap rules (`T1`..`T5`).
-/
inductive CanonicalRuleId where
  | G01 | G02 | G03 | G04 | G05 | G06 | G07 | G08
  | G09 | G10 | G11 | G12 | G13 | G14 | G15 | G16
  | T1  | T2  | T3  | T4  | T5
  deriving DecidableEq, Repr

/-- Generator membership (`G_gen ⊂ G_parse`): `true` iff `r ∈ {G01 .. G16}`. -/
def CanonicalRuleId.isGeneratorRule : CanonicalRuleId → Bool
  | .T1 | .T2 | .T3 | .T4 | .T5 => false
  | _ => true

/-- Trap membership (`G_trap = G_parse \ G_gen`): `true` iff `r ∈ {T1 .. T5}`. -/
def CanonicalRuleId.isParserOnlyTrap (r : CanonicalRuleId) : Bool :=
  !r.isGeneratorRule

/--
  Semantic reading multiplicity `altCount(ruleId)` frozen in `S0-R2` & `Gate C1-P0` (`P0-A05` §1.B):
  - `G01`..`G16` have `1` canonical reading.
  - `T1` (`all ... not`), `T2` (`did not confirm that`), and `T4` (bare plural) have `2` readings.
  - `T3` (`why/how` presupposition) and `T5` (unscoped clause) have `1` trap reading.
  `readingAlt` is a semantic reading index `1 .. altCount(ruleId)`, NOT a separate syntax rule!
-/
def CanonicalRuleId.readingAltCount : CanonicalRuleId → Nat
  | .T1 => 2
  | .T2 => 2
  | .T4 => 2
  | _   => 1

/-- Declarative validity of a `(ruleId, readingAlt)` pair (`P0-A05` §1.B). -/
def ValidReadingSelection (r : CanonicalRuleId) (readingAlt : Nat) : Prop :=
  1 ≤ readingAlt ∧ readingAlt ≤ r.readingAltCount

def checkReadingSelectionBool (r : CanonicalRuleId) (readingAlt : Nat) : Bool :=
  (1 ≤ readingAlt) && (readingAlt ≤ r.readingAltCount)

theorem checkReadingSelectionBool_iff (r : CanonicalRuleId) (readingAlt : Nat) :
    checkReadingSelectionBool r readingAlt = true ↔ ValidReadingSelection r readingAlt := by
  unfold checkReadingSelectionBool ValidReadingSelection
  simp [Bool.and_eq_true]

theorem all_generator_rules_unique_reading (r : CanonicalRuleId)
    (hgen : r.isGeneratorRule = true) :
    r.readingAltCount = 1 := by
  cases r <;> simp [CanonicalRuleId.isGeneratorRule] at hgen <;> rfl

/-! ### 2. Acyclic Nonterminal Hierarchy of `G_parse` (`S0-R2.1` §II.1 + `P0-A05` §2) -/

inductive BNFNonterm where
  | embeddedCausal      -- Level 0: `<ExpLevel> " " <IntervVerbPres> " " <OutTerm>`
  | assocCore           -- Level 1: `G-03`, `G-04`, `G-14`
  | metaNonEstabCore    -- Level 1: `G-09`
  | atomicCore          -- Level 2: `G-01`~`G-14` single-clause cores
  | trapCore            -- Level 2: `T1`~`T4` scoped trap cores
  | scopedInitial       -- Level 3: `"In " <CohortSpec> ", " <AtomicCore>`
  | scopedRepeat        -- Level 3: `"Within this same " <DesignNoun> ", " <AtomicCore>`
  | scopedAssoc         -- Level 3: `"In " <CohortSpec> ", " <AssocCore>`
  | scopedContrastMeta  -- Level 3: `"within this same " <DesignNoun> ", " <MetaNonEstabCore>`
  | scopedTrapClause    -- Level 3: `"In " <CohortSpec> ", " <TrapCore>`
  | controlledDocument  -- Level 4: Root `ControlledDocument` (`G_gen` docs + `T1`~`T5` trap docs)
  deriving DecidableEq, Repr

def BNFNonterm.level : BNFNonterm → Nat
  | .embeddedCausal     => 0
  | .assocCore          => 1
  | .metaNonEstabCore   => 1
  | .atomicCore         => 2
  | .trapCore           => 2
  | .scopedInitial      => 3
  | .scopedRepeat       => 3
  | .scopedAssoc        => 3
  | .scopedContrastMeta => 3
  | .scopedTrapClause   => 3
  | .controlledDocument => 4

/-! ### 3. Independent BNF Symbols, Side-Condition Tags & Provenance Status -/

/-- Typed slot occurrence in a BNF RHS (carries semantic positional tag + lexical `P3SlotSort`). -/
inductive BNFSlotTag where
  | cohort
  | design
  | window
  | eventA
  | eventB
  | measure
  | activeExp
  | refExp
  | outcome
  | source
  | assumption
  | subgroup
  | covariates
  | direction
  | metric1
  | metric2
  | verb
  | whComp
  | numK
  | numN
  | numPct
  | numEst
  | numDisp1
  | numDisp2
  | numCILevel
  | numCILow
  | numCIHigh
  | numPVal
  | numAlpha
  | numMarginLow
  | numMarginHigh
  deriving DecidableEq, Repr

/-- Right-hand-side BNF symbol (terminal literal, typed slot, or child nonterminal). -/
inductive BNFSymbol where
  | term    (lit : String)
  | lexSlot (sort : P3SlotSort) (tag : BNFSlotTag)
  | nonterm (nt : BNFNonterm) (clauseIdx : Nat) -- 0 = inherited, 1 = s₁, 2 = s₂
  deriving DecidableEq, Repr

/-- Explicit side-condition obligations tracked in `S0-R2.1`, `S0-R2.2`, and `Gate C0-R1`. -/
inductive FrozenSideCond where
  | cohortMatchesEnv
  | designNounResolvesToCohort
  | distinctActiveAndRefLevels
  | distinctTemporalEvents
  | repeatedRatioMetricAgreement
  | sentenceAtomicBothCohortsMatch
  | discourseBoundCohortAndDesignMatch
  | contrastiveSharedExpOutPair
  | uncensoredFixedWindowComplete   -- G-01 uncensored 100*k/N precondition (`S0-R2.2` §II.4.3)
  | ciExcludesNullAndPBelowAlpha    -- G-06a precondition (`Gate C0-R1` §II.3)
  | ciIncludesNull                  -- G-06b precondition (`Gate C0-R1` §II.3)
  | concordantNonSigPAndCI          -- G-07 precondition (`S0-R2.2` §II.4.5)
  | tostCIInsidePrespecifiedMargins -- G-08 precondition (`S0-R2.1` §II.2.3)
  | unscopedClauseLacksInOrWithin   -- T5 trap precondition (`P0-A05` §2)
  deriving DecidableEq, Repr

/-- Explicit provenance fidelity classification against `Architecture Freeze R0`. -/
inductive R0ProvenanceStatus where
  | exactFrozenInR0
  | exactDependentSplitInR0
  | canonicalizedFromP0A05Reference  -- `T1`~`T5` slot completions fixed in `Gate C1-P0` `P0-A05`
  deriving DecidableEq, Repr

/-- Complete independent BNF production record with source traceability. -/
structure BNFProduction where
  prodId         : String
  canonicalOwner : Option CanonicalRuleId -- `none` for structural nonterminal wrappers
  isGenerator    : Bool
  lhs            : BNFNonterm
  rhs            : List BNFSymbol
  sideConds      : List FrozenSideCond
  sourceDoc      : String
  sourceSection  : String
  r0Status       : R0ProvenanceStatus
  deriving DecidableEq, Repr

/-! ### 4. Complete Independent Frozen BNF Table (`G-01`~`G-16` + Envelopes + `T1`~`T5`) -/

def independentFrozenBNF : List BNFProduction :=
  [ -- (A) Document & Clause Structural Wrappers (`S0-R2.1` §II.1 + `P0-A05` §2)
    { prodId := "ENV-DOC-SINGLE", canonicalOwner := none, isGenerator := true,
      lhs := .controlledDocument,
      rhs := [.nonterm .scopedInitial 1, .term "."],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 ControlledDocument (line 40)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-SCOPED-INITIAL", canonicalOwner := none, isGenerator := true,
      lhs := .scopedInitial,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .atomicCore 0],
      sideConds := [.cohortMatchesEnv],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 ScopedAtomic (line 45)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-SCOPED-REPEAT", canonicalOwner := none, isGenerator := true,
      lhs := .scopedRepeat,
      rhs := [.term "Within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .atomicCore 0],
      sideConds := [.designNounResolvesToCohort],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "§II.1 line 46 & §II.4.1 line 88",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-SCOPED-ASSOC", canonicalOwner := none, isGenerator := true,
      lhs := .scopedAssoc,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .assocCore 0],
      sideConds := [.cohortMatchesEnv],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 ScopedAssoc (line 47)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-SCOPED-CONTRAST-META", canonicalOwner := none, isGenerator := true,
      lhs := .scopedContrastMeta,
      rhs := [.term "within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .metaNonEstabCore 0],
      sideConds := [.designNounResolvesToCohort],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 RepeatScopedMeta (line 48)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-LIFT-ASSOC", canonicalOwner := none, isGenerator := true,
      lhs := .atomicCore,
      rhs := [.nonterm .assocCore 0],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 AtomicCore (lines 54, 55, 65)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-LIFT-META", canonicalOwner := none, isGenerator := true,
      lhs := .atomicCore,
      rhs := [.nonterm .metaNonEstabCore 0],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 AtomicCore (line 60)",
      r0Status := .exactFrozenInR0 },

    { prodId := "ENV-EMBEDDED-CAUSAL", canonicalOwner := none, isGenerator := true,
      lhs := .embeddedCausal,
      rhs := [.lexSlot .expLevel .activeExp, .term " ", .lexSlot .intervVerbPres .verb, .term " ", .lexSlot .outTerm .outcome],
      sideConds := [],
      sourceDoc := "S0-R2.1 / P0-A05", sourceSection := "S0-R2.1 §II.2.1 line 79 & P0-A05 §2 line 46",
      r0Status := .exactFrozenInR0 },

    -- (B) Canonical Generator Rules `G-01` ~ `G-16` (`G_gen`)
    { prodId := "G-01-UNCENSORED", canonicalOwner := some .G01, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "over ", .lexSlot .followUpWindow .window,
               .term ", the cumulative incidence of ", .lexSlot .eventTerm .eventA,
               .term " was ", .lexSlot .numericLit .numK,
               .term " of ", .lexSlot .numericLit .numN,
               .term " patients (", .lexSlot .numericLit .numPct, .term "%)" ],
      sideConds := [.uncensoredFixedWindowComplete],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "S0-R2.1 §II.2.2 line 84 & S0-R2.2 §II.4.3 line 92",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-02A-MEAN-SD", canonicalOwner := some .G02, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the mean ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (SD ", .lexSlot .numericLit .numDisp1, .term ")" ],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.2.2 DistSummarySpec MeanSD (line 87)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-02B-MEDIAN-IQR", canonicalOwner := some .G02, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the median ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (IQR ", .lexSlot .numericLit .numDisp1,
               .term " to ", .lexSlot .numericLit .numDisp2, .term ")" ],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.2.2 DistSummarySpec MedianIQR (line 88)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-03-ASSOC-UNADJ", canonicalOwner := some .G03, isGenerator := true,
      lhs := .assocCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-03 & S0-R2.1 §II.2.3 ExpContrast (line 91)",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-04-ASSOC-TEMP", canonicalOwner := some .G04, isGenerator := true,
      lhs := .assocCore,
      rhs := [ .lexSlot .eventTerm .eventA, .term " preceded ", .lexSlot .eventTerm .eventB,
               .term ", and comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctTemporalEvents, .distinctActiveAndRefLevels],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-04 & S0-R2.1 §III line 106",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-05-COMP-RD", canonicalOwner := some .G05, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the absolute risk difference in ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " percentage points (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-05 + S0-R2.1 §II.2.3 ExpContrast",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-06A-INTERV-DIRECTIONAL", canonicalOwner := some .G06, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was estimated to ", .lexSlot .intervDirVerb .verb,
               .term " ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ", p = ", .lexSlot .numericLit .numPVal, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels, .ciExcludesNullAndPBelowAlpha],
      sourceDoc := "Gate C0-R1", sourceSection := "§II.3 F-C0-07 G-06a (line 61)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-06B-INTERV-NEUTRAL", canonicalOwner := some .G06, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", the estimated causal ", .lexSlot .ratioMetric .metric1,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term "), which did not exclude no effect" ],
      sideConds := [.distinctActiveAndRefLevels, .ciIncludesNull],
      sourceDoc := "Gate C0-R1", sourceSection := "§II.3 F-C0-07 G-06b (line 62)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-07-META-NOT-STAT-SIG", canonicalOwner := some .G07, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the observed ", .lexSlot .ratioMetric .metric1,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric2,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ") was not statistically significant at alpha = ",
               .lexSlot .numericLit .numAlpha ],
      sideConds := [.repeatedRatioMetricAgreement, .distinctActiveAndRefLevels, .concordantNonSigPAndCI],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "S0-R2.1 §II.1 line 58 & S0-R2.2 §II.4.5 line 98",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-08-META-EQUIV", canonicalOwner := some .G08, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " met prespecified equivalence margins (",
               .lexSlot .numericLit .numMarginLow, .term " to ", .lexSlot .numericLit .numMarginHigh,
               .term ") for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% TOST CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels, .tostCIInsidePrespecifiedMargins],
      sourceDoc := "S0-R2.1", sourceSection := "§II.2.3 TOST Equivalence (line 95)",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-09-META-NON-ESTAB", canonicalOwner := some .G09, isGenerator := true,
      lhs := .metaNonEstabCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not establish that ", .nonterm .embeddedCausal 0 ],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.1 line 60 & §III line 109",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-10-META-UNRESOLVED", canonicalOwner := some .G10, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not determine whether ", .nonterm .embeddedCausal 0 ],
      sideConds := [],
      sourceDoc := "S0-R2.1", sourceSection := "§II.2.1 F-R2-04 (line 79)",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-11-QUANT-ZERO", canonicalOwner := some .G11, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "no ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-11 (line 89) & S0-R2.1 line 62",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-12-QUANT-PROPER-PART", canonicalOwner := some .G12, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "some, but not all, ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-12 (line 90) & S0-R2.1 line 63",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-13-QUANT-AT-LEAST-ONE", canonicalOwner := some .G13, isGenerator := true,
      lhs := .atomicCore,
      rhs := [ .term "at least one ", .lexSlot .subgroupSingular .subgroup,
               .term " patient developed ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-13 (line 91) & S0-R2.1 line 64",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-14-ASSOC-ADJ", canonicalOwner := some .G14, isGenerator := true,
      lhs := .assocCore,
      rhs := [ .term "after adjustment for ", .lexSlot .covariateList .covariates,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      sideConds := [.distinctActiveAndRefLevels],
      sourceDoc := "S0-R2 / S0-R2.1", sourceSection := "S0-R2 §III G-14 (line 92) & S0-R2.1 line 65",
      r0Status := .exactFrozenInR0 },

    { prodId := "G-15A-DOC-CONJ-ATOMIC", canonicalOwner := some .G15, isGenerator := true,
      lhs := .controlledDocument,
      rhs := [ .nonterm .scopedInitial 1, .term ". ", .nonterm .scopedInitial 2, .term "." ],
      sideConds := [.sentenceAtomicBothCohortsMatch],
      sourceDoc := "S0-R2.2", sourceSection := "§II.4.1 F-R2.1-05 sentence_atomic (line 87)",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-15B-DOC-CONJ-DISCOURSE", canonicalOwner := some .G15, isGenerator := true,
      lhs := .controlledDocument,
      rhs := [ .nonterm .scopedInitial 1, .term ". ", .nonterm .scopedRepeat 2, .term "." ],
      sideConds := [.discourseBoundCohortAndDesignMatch],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "S0-R2.1 §II.1 line 41 & S0-R2.2 §II.4.1 line 88",
      r0Status := .exactDependentSplitInR0 },

    { prodId := "G-16-DOC-CONTRASTIVE", canonicalOwner := some .G16, isGenerator := true,
      lhs := .controlledDocument,
      rhs := [ .nonterm .scopedAssoc 1, .term "; however, ", .nonterm .scopedContrastMeta 2, .term "." ],
      sideConds := [.contrastiveSharedExpOutPair],
      sourceDoc := "S0-R2.1 / S0-R2.2", sourceSection := "S0-R2.1 §II.1 line 42 & S0-R2.2 §II.4.2 line 90",
      r0Status := .exactFrozenInR0 },

    -- (C) Parser-Only Adversarial Trap Rules `T1` ~ `T5` (`G_parse \ G_gen`, `P0-A05` §2)
    { prodId := "ENV-DOC-TRAP-SCOPED", canonicalOwner := none, isGenerator := false,
      lhs := .controlledDocument,
      rhs := [.nonterm .scopedTrapClause 1, .term "."],
      sideConds := [],
      sourceDoc := "Gate C1-P0 (P0-A05)", sourceSection := "§2 Scoped Trap Envelope (lines 45-48)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "ENV-SCOPED-TRAP", canonicalOwner := none, isGenerator := false,
      lhs := .scopedTrapClause,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .trapCore 0],
      sideConds := [.cohortMatchesEnv],
      sourceDoc := "Gate C1-P0 (P0-A05)", sourceSection := "§2 Scoped Trap Prefix (lines 45-48)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T1-TRAP-ALL-NOT", canonicalOwner := some .T1, isGenerator := false,
      lhs := .trapCore,
      rhs := [ .term "all ", .lexSlot .subgroupPlural .subgroup,
               .term " patients did not develop ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 45 & AC-P0-04 T-01 line 125 (altCount=2)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T2-TRAP-CONFIRM-THAT", canonicalOwner := some .T2, isGenerator := false,
      lhs := .trapCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not confirm that ", .nonterm .embeddedCausal 0 ],
      sideConds := [],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 46 (altCount=2)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T3-TRAP-WH-PRESUP", canonicalOwner := some .T3, isGenerator := false,
      lhs := .trapCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not ", .lexSlot .epistemicVerb .verb,
               .term " ", .lexSlot .whWord .whComp,
               .term " ", .nonterm .embeddedCausal 0 ],
      sideConds := [],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 47 (altCount=1)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T4-TRAP-BARE-PLURAL", canonicalOwner := some .T4, isGenerator := false,
      lhs := .trapCore,
      rhs := [ .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      sideConds := [],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 48 & S0-R2 IV.04 (altCount=2)",
      r0Status := .canonicalizedFromP0A05Reference },

    { prodId := "T5-TRAP-UNSCOPED-DOC", canonicalOwner := some .T5, isGenerator := false,
      lhs := .controlledDocument,
      rhs := [ .nonterm .atomicCore 1, .term "." ],
      sideConds := [.unscopedClauseLacksInOrWithin],
      sourceDoc := "S0-R2 / Gate C1-P0 (P0-A05)", sourceSection := "P0-A05 §2 line 49 (altCount=1)",
      r0Status := .canonicalizedFromP0A05Reference } ]

/-! ### 5. Explicit `HELD` Ledger for R0-Underspecified Grammar Details (Zero Arbitrary Invention) -/

inductive R0UnspecifiedGrammarItem where
  | G01_RightCensored_KM_AJ_SurfaceTemplate -- Required conceptually in S0-R2.2 line 93, English BNF template not given in R0
  | G05_S0R2_BetweenAnd_Draft_Superseded    -- S0-R2 line 73 had `between..and`; superseded by S0-R2.1 line 91 `comparing..versus`
  | G14_CovariateList_InternalElementCap    -- S0-R2.1 mentioned K_max=12; P0 Task P0-01 marked K_cov UNSPECIFIED_IN_R0
  |NumericTrailingDotPolicy_R0RegexExcludes -- `1.` excluded by S0-R2.2 `(\.[0-9]{1,4})?`, kept fail-closed REJECT
  deriving DecidableEq, Repr

/-! ### 6. Machine-Checked Structural Invariants on `independentFrozenBNF` -/

/-- Check that every child nonterminal in a production has strictly lower `level` than `lhs`. -/
def isProductionAcyclicBool (p : BNFProduction) : Bool :=
  p.rhs.all fun sym =>
    match sym with
    | .nonterm childNt _ => decide (childNt.level < p.lhs.level)
    | _ => true

theorem all_independentFrozenBNF_acyclic :
    independentFrozenBNF.all isProductionAcyclicBool = true := by
  decide

/-- Every canonical rule `r` in `{G01..G16, T1..T5}` is represented in `independentFrozenBNF` with matching `isGenerator` flag! -/
def isCanonicalRuleCoveredBool (r : CanonicalRuleId) : Bool :=
  independentFrozenBNF.any fun p =>
    (p.canonicalOwner == some r) && (p.isGenerator == r.isGeneratorRule)

theorem all_21_canonical_rules_covered :
    ∀ r : CanonicalRuleId, isCanonicalRuleCoveredBool r = true := by
  intro r
  cases r <;> decide

/-- Generator-vs-Trap Partition Invariant: No production owned by `T1..T5` is marked `isGenerator = true`. -/
theorem trap_productions_never_in_generator :
    independentFrozenBNF.all (fun p =>
      match p.canonicalOwner with
      | some r => p.isGenerator == r.isGeneratorRule
      | none   => true) = true := by
  decide

end BrocaOmega.P3A
