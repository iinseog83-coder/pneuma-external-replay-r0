/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: Strict Lexical Gate & Independent BNF)
  01_formal_spec/P3FormalSpec/StrictLexicalSpec.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  Defines the algorithm-independent declarative specifications (`Prop`) for Gate B & Gate C:
    1. Raw UTF-8 & Strict 7-bit Printable ASCII Profile (`Gate C0-R1` §I.3 `F-C0-03`)
    2. Canonical Decimal Surface Grammar (`S0-R2.2` §II.1 + `Gate C0-R1` §II.1 `F-C0-01`)
       with exact structural decomposition & round-trip rendering uniqueness
    3. Closed Entity Catalog (`S0-R2.2` §II.2 + `Gate C0` `F-R2.2-02` Global Surface Injectivity)
       and Syncategorematic Reserved-Keyword Disjointness (`S0-R2.1` §I.1)
    4. Slot-relative conjunction `LexicallyValid ∧ NumericallyWellFormed ∧ EntityCatalogBound`
-/

namespace BrocaOmega.P3A

/-! ### 1. Typed Slot Categories Across Frozen `G-01` ~ `G-16` and `T1` ~ `T5` -/

/--
  Complete closed enumeration of lexical slot categories in `Architecture Freeze R0`
  (`G-01`~`G-16` generator slots + `T3` trap-only `epistemicVerb` and `whWord` slots).
-/
inductive P3SlotSort where
  -- Open domain entity/phrase slots (must be bound in `ClosedEntityCatalog`):
  | cohortSpec
  | designNoun
  | followUpWindow
  | eventTerm
  | measureTerm
  | expLevel
  | outTerm
  | sourceId
  | identAssump
  | subgroupPlural
  | subgroupSingular
  | covariateList
  -- Closed functional lexicon slots (fixed finite R0 tables):
  | assocDir         -- "positively" | "inversely"
  | ratioMetric      -- "risk ratio" | "odds ratio" | "hazard ratio"
  | intervDirVerb    -- "increase" | "reduce"
  | intervVerbPres   -- "causes" | "increases" | "reduces"
  | epistemicVerb    -- T3 trap verb: "establish" | "determine" | "confirm" | "reveal"
  | whWord           -- T3 trap wh-complementizer: "why" | "how"
  -- Numeric literal slot (validated by Canonical Decimal Surface Grammar):
  | numericLit
  deriving DecidableEq, Repr

/-- Classifies how a `P3SlotSort` is lexically governed in `Architecture Freeze R0`. -/
inductive SlotRegime where
  | openEntityCatalog
  | closedFunctionalEnum
  | canonicalDecimal
  deriving DecidableEq, Repr

def P3SlotSort.regime : P3SlotSort → SlotRegime
  | .cohortSpec       => .openEntityCatalog
  | .designNoun       => .openEntityCatalog
  | .followUpWindow   => .openEntityCatalog
  | .eventTerm        => .openEntityCatalog
  | .measureTerm      => .openEntityCatalog
  | .expLevel         => .openEntityCatalog
  | .outTerm          => .openEntityCatalog
  | .sourceId         => .openEntityCatalog
  | .identAssump      => .openEntityCatalog
  | .subgroupPlural   => .openEntityCatalog
  | .subgroupSingular => .openEntityCatalog
  | .covariateList    => .openEntityCatalog
  | .assocDir         => .closedFunctionalEnum
  | .ratioMetric      => .closedFunctionalEnum
  | .intervDirVerb    => .closedFunctionalEnum
  | .intervVerbPres   => .closedFunctionalEnum
  | .epistemicVerb    => .closedFunctionalEnum
  | .whWord           => .closedFunctionalEnum
  | .numericLit       => .canonicalDecimal

/-! ### 2. Raw UTF-8 & Strict 7-Bit Printable ASCII Ingress Profile (`F-C0-03`) -/

/-- Printable 7-bit ASCII byte (`0x20 .. 0x7E`, excluding control chars, tabs, newlines, and `>= 0x80`). -/
def IsPrintableAsciiByte (b : UInt8) : Prop :=
  (0x20 : UInt8) ≤ b ∧ b ≤ (0x7E : UInt8)

/-- Pure byte-to-ASCII-Char conversion (total on `[0x20, 0x7E]`). -/
def asciiByteToChar (b : UInt8) : Char :=
  Char.ofNat b.toNat

def decodeAsciiBytes (bs : List UInt8) : String :=
  String.ofList (bs.map asciiByteToChar)

/--
  Declarative Ingress Profile (`Gate C0-R1` §I.3 `StrictProfileNFC` for English `D_0`):
  1. Non-empty byte sequence within resource cap `maxBytes`.
  2. Every byte is in printable 7-bit ASCII `[0x20, 0x7E]`.
     Note: Because every byte is `< 0x80`, the sequence is guaranteed valid single-byte UTF-8,
     contains zero surrogates or overlong sequences, contains zero Unicode combining marks
     (hence trivially in Unicode NFC with `verifiedBytes = rawBytes`), and eliminates Cyrillic/Greek homoglyphs.
-/
def StrictAsciiUTF8Valid (maxBytes : Nat) (rawBytes : List UInt8) : Prop :=
  0 < rawBytes.length ∧
  rawBytes.length ≤ maxBytes ∧
  ∀ b ∈ rawBytes, IsPrintableAsciiByte b

/-! ### 3. Reserved Syncategorematic Structural Barrier (`S0-R2.1` §I.1) -/

/--
  Declarative contiguous sublist relation (`needle` occurs as a contiguous slice of `haystack`).
-/
def IsContigSublist {α : Type} (needle haystack : List α) : Prop :=
  ∃ pre post : List α, haystack = pre ++ needle ++ post

/--
  Reserved syncategorematic delimiters & clause markers from `S0-R2.1` §I.1 and `P0-A05`.
  Forbidden as contiguous substrings inside any open entity catalog lexeme so clause and slot
  boundaries cannot be forged or spoofed.
-/
def reservedStructuralDelimiters : List String :=
  [ ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same",
    "In ", " why ", " how " ]

def DisjointFromReservedDelimiters (s : String) : Prop :=
  ∀ bad ∈ reservedStructuralDelimiters, ¬ IsContigSublist bad.toList s.toList

/-- Leading/trailing space hygiene for slot lexemes (prevents boundary token fusion). -/
def HasTrimmedOuterSpaces (cs : List Char) : Prop :=
  cs ≠ [] ∧ cs.head? ≠ some ' ' ∧ cs.getLast? ≠ some ' '

/-! ### 4. Canonical Decimal Surface Grammar (`S0-R2.2` §II.1 + `F-C0-01`) -/

/--
  Explicit digit-length policy configuration (`S0-R2.2` line 36 `[0-9]{1,7}(\.[0-9]{1,4})?`
  vs `Gate C1-P0` `d <= 8`). Parameterizing `NumericGateConfig` avoids hardcoding unverified
  constants while defaulting to the frozen `S0-R2.2` `(7, 4)` profile.
-/
structure NumericGateConfig where
  maxIntDigits  : Nat
  maxFracDigits : Nat
  deriving DecidableEq, Repr

/-- Frozen `S0-R2.2` §II.1 line 36 profile (`1..7` integer digits, `1..4` fractional digits). -/
def frozenR22NumericConfig : NumericGateConfig :=
  { maxIntDigits := 7, maxFracDigits := 4 }

def IsAsciiDigitChar (c : Char) : Prop :=
  '0'.toNat ≤ c.toNat ∧ c.toNat ≤ '9'.toNat

/-- Base-10 natural value of a list of ASCII digit characters (big-endian). -/
def digitsToNat : List Char → Nat
  | [] => 0
  | c :: cs =>
    let acc := c.toNat - '0'.toNat
    cs.foldl (fun n d => n * 10 + (d.toNat - '0'.toNat)) acc

/-- Exact parsed decimal surface token (bridging raw ASCII surface to `(mantissa : Int, scale10 : Nat)`). -/
structure ParsedDecLit where
  neg        : Bool
  intDigits  : List Char
  fracDigits : List Char
  deriving DecidableEq, Repr

/-- Canonical surface rendering of a `ParsedDecLit` (used to prove exact round-trip identity!). -/
def ParsedDecLit.renderChars (d : ParsedDecLit) : List Char :=
  (if d.neg then ['-'] else []) ++
  d.intDigits ++
  (if d.fracDigits.isEmpty then [] else '.' :: d.fracDigits)

def ParsedDecLit.render (d : ParsedDecLit) : String :=
  String.ofList d.renderChars

/-- Exact unrounded mathematical `(mantissa, scale10)` projection compatible with `P1` `DecLit`. -/
def ParsedDecLit.absMantissaNat (d : ParsedDecLit) : Nat :=
  digitsToNat (d.intDigits ++ d.fracDigits)

def ParsedDecLit.mantissaInt (d : ParsedDecLit) : Int :=
  if d.neg then - (Int.ofNat d.absMantissaNat) else Int.ofNat d.absMantissaNat

def ParsedDecLit.scale10 (d : ParsedDecLit) : Nat :=
  d.fracDigits.length

/--
  **Declarative Canonical Decimal Surface Specification (`DecSurfaceSpec`)**:
  A string `s` is a valid canonical decimal literal with decomposition `d : ParsedDecLit` iff:
  1. `d.renderChars = s.toList` (exact character-by-character structural round-trip:
     at most one `'.'`, optional leading `'-'`, NO `'+'`, NO `'e'`/`'E'`, NO trailing `'.'` like `"1."`,
     and NO leading `'.'` like `".25"` because `intDigits` is non-empty and `'.'` only appears when
     `fracDigits` is non-empty!).
  2. `1 ≤ d.intDigits.length ≤ cfg.maxIntDigits`, all ASCII digits `'0'..'9'`.
  3. Canonical integer leading-zero rule: if `1 < d.intDigits.length`, the leading digit is NOT `'0'`
     (rejects `"00"`, `"001.25"`, `"-00.5"`, while allowing `"0"` and `"0.25"`).
  4. `d.fracDigits.length ≤ cfg.maxFracDigits`, all ASCII digits `'0'..'9'`.
  5. Canonical zero sign rule (`F-C0-01` negative-zero ban): if all integer and fractional digits
     are `'0'` (`d.absMantissaNat = 0`), then `d.neg = false` (rejects `"-0"`, `"-0.0"`, `"-0.00"`).
-/
def DecSurfaceSpec (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit) : Prop :=
  d.renderChars = s.toList ∧
  1 ≤ d.intDigits.length ∧
  d.intDigits.length ≤ cfg.maxIntDigits ∧
  (∀ c ∈ d.intDigits, IsAsciiDigitChar c) ∧
  (1 < d.intDigits.length → d.intDigits.head? ≠ some '0') ∧
  d.fracDigits.length ≤ cfg.maxFracDigits ∧
  (∀ c ∈ d.fracDigits, IsAsciiDigitChar c) ∧
  (d.absMantissaNat = 0 → d.neg = false)

/-! ### 5. Closed Functional Lexicon & Closed Entity Catalog (`F-R2.2-02`) -/

/-- Canonical `(sort, entityId, lexeme)` triples for closed functional slots in `R0`. -/
def closedFunctionalEntries : List (P3SlotSort × String × String) :=
  [ (.assocDir,       "positively",   "positively"),
    (.assocDir,       "inversely",    "inversely"),
    (.ratioMetric,    "rr",           "risk ratio"),
    (.ratioMetric,    "or",           "odds ratio"),
    (.ratioMetric,    "hr",           "hazard ratio"),
    (.intervDirVerb,  "increase",     "increase"),
    (.intervDirVerb,  "reduce",       "reduce"),
    (.intervVerbPres, "causes",       "causes"),
    (.intervVerbPres, "increases",    "increases"),
    (.intervVerbPres, "reduces",      "reduces"),
    (.epistemicVerb,  "establish",    "establish"),
    (.epistemicVerb,  "determine",    "determine"),
    (.epistemicVerb,  "confirm",      "confirm"),
    (.epistemicVerb,  "reveal",       "reveal"),
    (.whWord,         "why",          "why"),
    (.whWord,         "how",          "how") ]

/-- Single entry in a `ClosedEntityCatalog`. -/
structure CatalogEntry where
  sort     : P3SlotSort
  entityId : String
  lexeme   : String
  deriving DecidableEq, Repr

/--
  Closed Entity Catalog (`OntologyLexicon` in `Gate C0-R1`).
  Note (`Gate C1-P0` Task P0-01): Production clinical ontology entries are `UNSPECIFIED_IN_R0`,
  so the gate takes `ClosedEntityCatalog` explicitly and verifies all `R0` structural/injectivity
  invariants (`ValidEntityCatalog`) before admitting any open-entity binding!
-/
structure ClosedEntityCatalog where
  entries : List CatalogEntry
  deriving DecidableEq, Repr

/--
  Declarative Well-Formedness of a `ClosedEntityCatalog` (`S0-R2.1` + `S0-R2.2` + `F-R2.2-02`):
  1. Every entry belongs to an `.openEntityCatalog` sort.
  2. Both `entityId` and `lexeme` are non-empty printable ASCII with trimmed outer spaces.
  3. Every `lexeme` is disjoint from `reservedStructuralDelimiters`.
  4. Unique `(sort, entityId)` key: an `entityId` within a sort maps to at most one `lexeme`.
  5. **Global Canonical Surface Injectivity (`F-R2.2-02`)**: distinct entries NEVER share the same
     `lexeme`, even across different `P3SlotSort`s (`e₁.lexeme = e₂.lexeme → e₁ = e₂`).
-/
def ValidEntityCatalog (cat : ClosedEntityCatalog) : Prop :=
  (∀ e ∈ cat.entries,
    e.sort.regime = .openEntityCatalog ∧
    0 < e.entityId.toList.length ∧
    (∀ c ∈ e.entityId.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
    HasTrimmedOuterSpaces e.lexeme.toList ∧
    (∀ c ∈ e.lexeme.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
    DisjointFromReservedDelimiters e.lexeme) ∧
  (∀ e₁ ∈ cat.entries, ∀ e₂ ∈ cat.entries,
    e₁.sort = e₂.sort → e₁.entityId = e₂.entityId → e₁.lexeme = e₂.lexeme) ∧
  (∀ e₁ ∈ cat.entries, ∀ e₂ ∈ cat.entries,
    e₁.lexeme = e₂.lexeme → e₁ = e₂)

/-! ### 6. Untrusted Raw Slot Candidate & Declarative Target Predicates (`Gate IV`) -/

/-- Untrusted raw lexical slot candidate submitted to the Strict Lexical Gate. -/
structure RawSlotCandidate where
  sort     : P3SlotSort
  entityId : String
  rawBytes : List UInt8
  deriving DecidableEq, Repr

def RawSlotCandidate.decodedStr (cand : RawSlotCandidate) : String :=
  decodeAsciiBytes cand.rawBytes

/--
  1. `LexicallyValid`:
     Raw bytes pass `StrictAsciiUTF8Valid`, `entityId` is non-empty printable ASCII, outer spaces
     are trimmed, and if `cand.sort` is an open-entity sort, `decodedStr` contains zero reserved
     syncategorematic delimiters.
-/
def LexicallyValid (maxBytes : Nat) (cand : RawSlotCandidate) : Prop :=
  StrictAsciiUTF8Valid maxBytes cand.rawBytes ∧
  0 < cand.entityId.toList.length ∧
  (∀ c ∈ cand.entityId.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
  HasTrimmedOuterSpaces cand.decodedStr.toList ∧
  (cand.sort.regime = .openEntityCatalog → DisjointFromReservedDelimiters cand.decodedStr)

/--
  2. `NumericallyWellFormed` (Slot-Relative per Mandate §IV):
     Applies iff `cand.sort = .numericLit`: there exists a unique canonical `ParsedDecLit`
     satisfying `DecSurfaceSpec numCfg cand.decodedStr d`, and `cand.entityId` equals the
     canonical surface string `cand.decodedStr`.
-/
def NumericallyWellFormed (numCfg : NumericGateConfig) (cand : RawSlotCandidate) : Prop :=
  cand.sort = .numericLit →
    cand.entityId = cand.decodedStr ∧
    ∃ d : ParsedDecLit, DecSurfaceSpec numCfg cand.decodedStr d

/--
  3. `EntityCatalogBound` (Slot-Relative per Mandate §IV):
     - For `.openEntityCatalog` sorts: the catalog itself satisfies `ValidEntityCatalog cat` AND
       `⟨cand.sort, cand.entityId, cand.decodedStr⟩ ∈ cat.entries`.
     - For `.closedFunctionalEnum` sorts: `(cand.sort, cand.entityId, cand.decodedStr) ∈ closedFunctionalEntries`.
     - For `.canonicalDecimal` (`.numericLit`): vacuous (`True`), governed by `NumericallyWellFormed`.
-/
def EntityCatalogBound (cat : ClosedEntityCatalog) (cand : RawSlotCandidate) : Prop :=
  match cand.sort.regime with
  | .openEntityCatalog =>
    ValidEntityCatalog cat ∧
    CatalogEntry.mk cand.sort cand.entityId cand.decodedStr ∈ cat.entries
  | .closedFunctionalEnum =>
    (cand.sort, cand.entityId, cand.decodedStr) ∈ closedFunctionalEntries
  | .canonicalDecimal =>
    True

end BrocaOmega.P3A
