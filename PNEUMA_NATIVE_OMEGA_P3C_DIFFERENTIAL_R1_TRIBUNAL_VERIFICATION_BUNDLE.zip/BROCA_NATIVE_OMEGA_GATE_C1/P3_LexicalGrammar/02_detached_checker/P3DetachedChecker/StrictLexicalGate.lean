/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: Strict Lexical Gate & Soundness Proofs)
  02_detached_checker/P3DetachedChecker/StrictLexicalGate.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `sorry`, zero `native_decide`)

  Gate B & Gate C Deliverable:
  1. Separates executable `Bool` / `Except` validators from declarative `Prop` specifications
     defined in `P3FormalSpec.StrictLexicalSpec`.
  2. Encapsulates `VerifiedIngressText` and `CertifiedLexicalSlot` with `private mk ::`
     so non-authoritative `LexicalRejectDiag` carries zero capability to construct witnesses.
  3. Proves both `admitLexicalSlot_sound` (`Accepted(x) -> LexicallyValid ∧ NumericallyWellFormed ∧ EntityCatalogBound`)
     and `admitLexicalSlot_complete`, plus general rejection theorems for multi-dot (`1..25`, `1.2.3`),
     trailing-dot (`1.`), and negative-zero (`-0.0`) surfaces.
-/
import P3FormalSpec

namespace BrocaOmega.P3A

/-! ### 1. Non-Authoritative Structured Rejection Diagnostics -/

inductive LexicalRejectDiag where
  | emptyRawBytes
  | inputLengthExceeded            (actual maxBytes : Nat)
  | nonPrintableAsciiOrInvalidUtf8 (byteVal : UInt8)
  | emptyOrNonAsciiEntityId
  | untrimmedOuterWhitespace
  | reservedKeywordLeak            (keyword : String)
  | explicitPlusForbidden
  | leadingDecimalPoint
  | trailingDecimalPoint
  | multipleDecimalPoints
  | invalidNumericCharOrExponent   (ch : Char)
  | redundantLeadingZero
  | numericPrecisionBoundExceeded  (intLen fracLen : Nat)
  | negativeZeroForbidden
  | numericEntityIdMismatch
  | invalidEntityCatalog
  | entityCatalogMismatch
  | closedFunctionalLexiconMismatch
  | invalidRuleOrReadingAlt
  | parserOnlyTrapRuleInGenerator
  deriving DecidableEq, Repr

/-! ### 2. Generic `List.all` / Membership / Sublist Helper Lemmas -/

theorem list_all_eq_true {α : Type} (p : α → Bool) (xs : List α) :
    xs.all p = true ↔ ∀ x ∈ xs, p x = true := by
  induction xs with
  | nil => simp
  | cons h t ih => simp [List.all, Bool.and_eq_true, ih]

def memDecListBool {α : Type} [DecidableEq α] (a : α) : List α → Bool
  | [] => false
  | x :: xs => (x == a) || memDecListBool a xs

theorem memDecListBool_iff {α : Type} [DecidableEq α] (a : α) (xs : List α) :
    memDecListBool a xs = true ↔ a ∈ xs := by
  induction xs with
  | nil => simp [memDecListBool]
  | cons x rest ih =>
    unfold memDecListBool
    rw [Bool.or_eq_true, beq_iff_eq, ih, List.mem_cons]
    constructor
    · rintro (rfl | hm)
      · exact Or.inl rfl
      · exact Or.inr hm
    · rintro (rfl | hm)
      · exact Or.inl rfl
      · exact Or.inr hm

def isPrefixListBool {α : Type} [DecidableEq α] : List α → List α → Bool
  | [], _ => true
  | _ :: _, [] => false
  | n :: ns, h :: hs => (n == h) && isPrefixListBool ns hs

theorem isPrefixListBool_iff {α : Type} [DecidableEq α] (needle haystack : List α) :
    isPrefixListBool needle haystack = true ↔ ∃ post : List α, haystack = needle ++ post := by
  induction needle generalizing haystack with
  | nil =>
    exact ⟨fun _ => ⟨haystack, rfl⟩, fun _ => rfl⟩
  | cons n ns ih =>
    cases haystack with
    | nil =>
      unfold isPrefixListBool
      constructor
      · intro hf; contradiction
      · rintro ⟨_, h⟩; simp at h
    | cons h hs =>
      unfold isPrefixListBool
      rw [Bool.and_eq_true, beq_iff_eq, ih]
      constructor
      · rintro ⟨rfl, post, rfl⟩
        exact ⟨post, rfl⟩
      · rintro ⟨post, heq⟩
        injection heq with h1 h2
        exact ⟨h1.symm, post, h2⟩

def containsSublistBool {α : Type} [DecidableEq α] (needle : List α) : List α → Bool
  | [] => needle.isEmpty
  | h :: hs => isPrefixListBool needle (h :: hs) || containsSublistBool needle hs

theorem containsSublistBool_iff {α : Type} [DecidableEq α] (needle haystack : List α) :
    containsSublistBool needle haystack = true ↔ IsContigSublist needle haystack := by
  induction haystack with
  | nil =>
    unfold containsSublistBool IsContigSublist
    cases needle with
    | nil =>
      exact ⟨fun _ => ⟨[], [], rfl⟩, fun _ => rfl⟩
    | cons a as =>
      constructor
      · intro hf; contradiction
      · rintro ⟨pre, post, h⟩
        cases pre <;> simp at h
  | cons h hs ih =>
    unfold containsSublistBool
    rw [Bool.or_eq_true, isPrefixListBool_iff, ih]
    unfold IsContigSublist
    constructor
    · intro hor
      rcases hor with ⟨post, heq⟩ | ⟨pre, post, heq⟩
      · exact ⟨[], post, by simpa using heq⟩
      · exact ⟨h :: pre, post, by simp [heq]⟩
    · rintro ⟨pre, post, heq⟩
      cases pre with
      | nil =>
        left
        exact ⟨post, by simpa using heq⟩
      | cons p ps =>
        simp at heq
        right
        exact ⟨ps, post, by simpa [List.append_assoc] using heq.2⟩

/-! ### 3. Raw UTF-8 / Printable 7-Bit ASCII Ingress Gate (`F-C0-03`) -/

def isPrintableAsciiByteBool (b : UInt8) : Bool :=
  ((0x20 : UInt8) ≤ b) && (b ≤ (0x7E : UInt8))

theorem isPrintableAsciiByteBool_iff (b : UInt8) :
    isPrintableAsciiByteBool b = true ↔ IsPrintableAsciiByte b := by
  unfold isPrintableAsciiByteBool IsPrintableAsciiByte
  simp [Bool.and_eq_true]

def findBadAsciiByte : List UInt8 → Option UInt8
  | [] => none
  | b :: bs => if isPrintableAsciiByteBool b then findBadAsciiByte bs else some b

theorem findBadAsciiByte_eq_none_iff (bs : List UInt8) :
    findBadAsciiByte bs = none ↔ ∀ b ∈ bs, IsPrintableAsciiByte b := by
  induction bs with
  | nil => simp [findBadAsciiByte]
  | cons b rest ih =>
    unfold findBadAsciiByte
    split
    · rename_i hok
      rw [ih]
      have hb : IsPrintableAsciiByte b := (isPrintableAsciiByteBool_iff b).mp hok
      constructor
      · intro hall x hx
        rcases List.mem_cons.mp hx with rfl | hmem
        · exact hb
        · exact hall x hmem
      · intro hall x hx
        exact hall x (List.Mem.tail b hx)
    · rename_i hbad
      constructor
      · intro h; contradiction
      · intro hall
        exfalso
        exact hbad ((isPrintableAsciiByteBool_iff b).mpr (hall b (List.Mem.head rest)))

def checkStrictAsciiIngress (maxBytes : Nat) (rawBytes : List UInt8) : Except LexicalRejectDiag Unit :=
  if rawBytes.isEmpty then
    .error .emptyRawBytes
  else if maxBytes < rawBytes.length then
    .error (.inputLengthExceeded rawBytes.length maxBytes)
  else
    match findBadAsciiByte rawBytes with
    | some bad => .error (.nonPrintableAsciiOrInvalidUtf8 bad)
    | none     => .ok ()

theorem checkStrictAsciiIngress_iff (maxBytes : Nat) (rawBytes : List UInt8) :
    checkStrictAsciiIngress maxBytes rawBytes = .ok () ↔ StrictAsciiUTF8Valid maxBytes rawBytes := by
  unfold checkStrictAsciiIngress StrictAsciiUTF8Valid
  cases rawBytes with
  | nil =>
    simp
  | cons b bs =>
    have hne : (b :: bs).isEmpty = false := rfl
    rw [if_neg (by simp [hne])]
    by_cases hlen : maxBytes < (b :: bs).length
    · rw [if_pos hlen]
      constructor
      · intro h; contradiction
      · rintro ⟨_, hle, _⟩; omega
    · rw [if_neg hlen]
      have hle : (b :: bs).length ≤ maxBytes := by omega
      have hpos : 0 < (b :: bs).length := by simp
      cases hbad : findBadAsciiByte (b :: bs) with
      | some bad =>
        constructor
        · intro h; contradiction
        · rintro ⟨_, _, hall⟩
          have hnone := (findBadAsciiByte_eq_none_iff (b :: bs)).mpr hall
          rw [hbad] at hnone
          contradiction
      | none =>
        have hall := (findBadAsciiByte_eq_none_iff (b :: bs)).mp hbad
        exact ⟨fun _ => ⟨hpos, hle, hall⟩, fun _ => rfl⟩

/-- Sealed ingress text witness (`private mk ::`). -/
structure VerifiedIngressText (maxBytes : Nat) where
  private mk ::
  rawBytes  : List UInt8
  decoded   : String
  hDecoded  : decoded = decodeAsciiBytes rawBytes
  hValid    : StrictAsciiUTF8Valid maxBytes rawBytes

def admitStrictAsciiIngress (maxBytes : Nat) (rawBytes : List UInt8) :
    Except LexicalRejectDiag (VerifiedIngressText maxBytes) :=
  match h : checkStrictAsciiIngress maxBytes rawBytes with
  | .error e => .error e
  | .ok ()   =>
    .ok ⟨rawBytes, decodeAsciiBytes rawBytes, rfl,
         (checkStrictAsciiIngress_iff maxBytes rawBytes).mp h⟩

theorem admitStrictAsciiIngress_sound (maxBytes : Nat) (rawBytes : List UInt8)
    (w : VerifiedIngressText maxBytes)
    (hok : admitStrictAsciiIngress maxBytes rawBytes = .ok w) :
    w.rawBytes = rawBytes ∧ StrictAsciiUTF8Valid maxBytes rawBytes := by
  unfold admitStrictAsciiIngress at hok
  split at hok
  · contradiction
  · rename_i h
    injection hok with hw
    have hraw : w.rawBytes = rawBytes := by rw [← hw]
    exact ⟨hraw, (checkStrictAsciiIngress_iff maxBytes rawBytes).mp h⟩

/-! ### 4. Outer-Space Hygiene, ASCII String & Reserved-Keyword Barrier Checkers -/

def isPrintableAsciiCharBool (c : Char) : Bool :=
  ((0x20 : UInt32) ≤ c.val) && (c.val ≤ (0x7E : UInt32))

theorem isPrintableAsciiCharBool_iff (c : Char) :
    isPrintableAsciiCharBool c = true ↔ (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32) := by
  unfold isPrintableAsciiCharBool
  simp [Bool.and_eq_true]

def checkAsciiEntityIdBool (eid : String) : Bool :=
  !eid.toList.isEmpty && eid.toList.all isPrintableAsciiCharBool

theorem checkAsciiEntityIdBool_iff (eid : String) :
    checkAsciiEntityIdBool eid = true ↔
      0 < eid.toList.length ∧ ∀ c ∈ eid.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32) := by
  unfold checkAsciiEntityIdBool
  rw [Bool.and_eq_true, list_all_eq_true]
  cases hcs : eid.toList with
  | nil => simp
  | cons c cs =>
    constructor
    · rintro ⟨_, hall⟩
      refine ⟨by simp, fun x hx => (isPrintableAsciiCharBool_iff x).mp (hall x hx)⟩
    · rintro ⟨_, hall⟩
      refine ⟨rfl, fun x hx => (isPrintableAsciiCharBool_iff x).mpr (hall x hx)⟩

def checkTrimmedSpacesBool (cs : List Char) : Bool :=
  !cs.isEmpty && (cs.head? != some ' ') && (cs.getLast? != some ' ')

theorem checkTrimmedSpacesBool_iff (cs : List Char) :
    checkTrimmedSpacesBool cs = true ↔ HasTrimmedOuterSpaces cs := by
  unfold checkTrimmedSpacesBool HasTrimmedOuterSpaces
  cases cs with
  | nil => simp
  | cons c rest =>
    simp [Bool.and_eq_true, bne_iff_ne]

def findReservedDelimiter (s : String) : Option String :=
  reservedStructuralDelimiters.find? (fun bad => containsSublistBool bad.toList s.toList)

theorem findReservedDelimiter_eq_none_iff (s : String) :
    findReservedDelimiter s = none ↔ DisjointFromReservedDelimiters s := by
  unfold findReservedDelimiter DisjointFromReservedDelimiters
  rw [List.find?_eq_none]
  constructor
  · intro h bad hmem hsub
    have hfalse := h bad hmem
    exact hfalse ((containsSublistBool_iff bad.toList s.toList).mpr hsub)
  · intro h bad hmem htrue
    exact h bad hmem ((containsSublistBool_iff bad.toList s.toList).mp htrue)

/-! ### 5. Canonical Decimal Surface Parser & Soundness/Completeness (`F-P2-02` Resolution) -/

def isAsciiDigitBool (c : Char) : Bool :=
  ('0'.toNat ≤ c.toNat) && (c.toNat ≤ '9'.toNat)

theorem isAsciiDigitBool_iff (c : Char) :
    isAsciiDigitBool c = true ↔ IsAsciiDigitChar c := by
  unfold isAsciiDigitBool IsAsciiDigitChar
  simp [Bool.and_eq_true]

def findInvalidNumBodyChar : List Char → Option Char
  | [] => none
  | c :: cs =>
    if isAsciiDigitBool c || (c == '.') then findInvalidNumBodyChar cs else some c

theorem findInvalidNumBodyChar_eq_none_iff (cs : List Char) :
    findInvalidNumBodyChar cs = none ↔ ∀ c ∈ cs, IsAsciiDigitChar c ∨ c = '.' := by
  induction cs with
  | nil => simp [findInvalidNumBodyChar]
  | cons c rest ih =>
    unfold findInvalidNumBodyChar
    split
    · rename_i hok
      rw [ih]
      simp [Bool.or_eq_true, isAsciiDigitBool_iff, beq_iff_eq] at hok
      constructor
      · intro hall x hx
        rcases List.mem_cons.mp hx with rfl | hm
        · exact hok
        · exact hall x hm
      · intro hall x hx
        exact hall x (List.Mem.tail c hx)
    · rename_i hbad
      constructor
      · intro h; contradiction
      · intro hall
        exfalso
        have hc := hall c (List.Mem.head rest)
        simp [Bool.or_eq_true, isAsciiDigitBool_iff, beq_iff_eq] at hbad
        rcases hc with hd | hdot
        · exact hbad.1 hd
        · exact hbad.2 hdot

/-- Splits a character list on `'.'` into `(noDot intCs)` | `(oneDot intCs fracCs)` | `manyDots`. -/
inductive DotSplit where
  | noDot    (intCs : List Char)
  | oneDot   (intCs fracCs : List Char)
  | manyDots
  deriving DecidableEq, Repr

def splitDots : List Char → DotSplit
  | [] => .noDot []
  | c :: rest =>
    if c == '.' then
      match splitDots rest with
      | .noDot frac => .oneDot [] frac
      | _           => .manyDots
    else
      match splitDots rest with
      | .noDot ints       => .noDot (c :: ints)
      | .oneDot ints frac => .oneDot (c :: ints) frac
      | .manyDots         => .manyDots

theorem splitDots_noDot_props {body ints : List Char}
    (h : splitDots body = .noDot ints) :
    body = ints ∧ '.' ∉ ints := by
  induction body generalizing ints with
  | nil =>
    simp [splitDots] at h
    subst ints
    exact ⟨rfl, by simp⟩
  | cons c rest ih =>
    unfold splitDots at h
    by_cases hc : c == '.'
    · rw [if_pos hc] at h
      split at h <;> contradiction
    · rw [if_neg hc] at h
      have hne : c ≠ '.' := by simpa [beq_iff_eq] using hc
      split at h
      · rename_i rInts hr
        injection h with heq
        subst ints
        have ⟨hrest_eq, hnot_dot⟩ := ih hr
        subst rest
        refine ⟨rfl, ?_⟩
        intro hmem
        rcases List.mem_cons.mp hmem with hhead | htail
        · exact hne hhead.symm
        · exact hnot_dot htail
      · contradiction
      · contradiction

theorem splitDots_oneDot_props {body ints frac : List Char}
    (h : splitDots body = .oneDot ints frac) :
    body = ints ++ '.' :: frac ∧ '.' ∉ ints ∧ '.' ∉ frac := by
  induction body generalizing ints frac with
  | nil =>
    simp [splitDots] at h
  | cons c rest ih =>
    unfold splitDots at h
    by_cases hc : c == '.'
    · rw [if_pos hc] at h
      have heq_dot : c = '.' := by simpa [beq_iff_eq] using hc
      subst c
      split at h
      · rename_i rFrac hr
        injection h with hi hf
        subst ints; subst frac
        have ⟨hrest_eq, hnot_dot⟩ := splitDots_noDot_props hr
        subst rest
        exact ⟨rfl, by simp, hnot_dot⟩
      · contradiction
    · rw [if_neg hc] at h
      have hne : c ≠ '.' := by simpa [beq_iff_eq] using hc
      split at h
      · contradiction
      · rename_i rInts rFrac hr
        injection h with hi hf
        subst ints; subst frac
        have ⟨hrest_eq, hni, hnf⟩ := ih hr
        subst rest
        refine ⟨rfl, ?_, hnf⟩
        intro hmem
        rcases List.mem_cons.mp hmem with hhead | htail
        · exact hne hhead.symm
        · exact hni htail
      · contradiction

theorem splitDots_of_no_dot {ints : List Char} (hnot : '.' ∉ ints) :
    splitDots ints = .noDot ints := by
  induction ints with
  | nil => rfl
  | cons c rest ih =>
    have hc : (c == '.') = false := beq_eq_false_iff_ne.mpr (fun heq => hnot (heq ▸ List.Mem.head rest))
    have hr : '.' ∉ rest := fun hm => hnot (List.Mem.tail c hm)
    simp [splitDots, hc, ih hr]

theorem splitDots_of_one_dot {ints frac : List Char}
    (hni : '.' ∉ ints) (hnf : '.' ∉ frac) :
    splitDots (ints ++ '.' :: frac) = .oneDot ints frac := by
  induction ints with
  | nil =>
    unfold splitDots
    simp [splitDots_of_no_dot hnf]
  | cons c rest ih =>
    have hc : (c == '.') = false := beq_eq_false_iff_ne.mpr (fun heq => hni (heq ▸ List.Mem.head rest))
    have hr : '.' ∉ rest := fun hm => hni (List.Mem.tail c hm)
    unfold splitDots
    simp [hc, ih hr]

/-- Checks digit-part constraints after sign & dot splitting. -/
def checkParsedBodyParts (cfg : NumericGateConfig) (neg : Bool) (body : List Char) :
    Except LexicalRejectDiag ParsedDecLit :=
  if body.isEmpty then
    .error (.invalidNumericCharOrExponent '-')
  else
    match findInvalidNumBodyChar body with
    | some badCh => .error (.invalidNumericCharOrExponent badCh)
    | none =>
      match splitDots body with
      | .manyDots => .error .multipleDecimalPoints
      | .noDot intCs =>
        if intCs.isEmpty then
          .error .leadingDecimalPoint
        else if (1 < intCs.length) && (intCs.head? == some '0') then
          .error .redundantLeadingZero
        else if cfg.maxIntDigits < intCs.length then
          .error (.numericPrecisionBoundExceeded intCs.length 0)
        else
          let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := [] }
          if neg && (d.absMantissaNat == 0) then
            .error .negativeZeroForbidden
          else
            .ok d
      | .oneDot intCs fracCs =>
        if intCs.isEmpty then
          .error .leadingDecimalPoint
        else if fracCs.isEmpty then
          .error .trailingDecimalPoint
        else if (1 < intCs.length) && (intCs.head? == some '0') then
          .error .redundantLeadingZero
        else if (cfg.maxIntDigits < intCs.length) || (cfg.maxFracDigits < fracCs.length) then
          .error (.numericPrecisionBoundExceeded intCs.length fracCs.length)
        else
          let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := fracCs }
          if neg && (d.absMantissaNat == 0) then
            .error .negativeZeroForbidden
          else
            .ok d

/--
  Executable Canonical Decimal Surface Parser (`Gate B`):
  Rejects `+1.25`, `1..25`, `1.2.3`, `1.`, `.25`, `001.25`, `-0.0`, `1e-3`, and precision overflows.
-/
def parseCanonicalDecSurface (cfg : NumericGateConfig) (s : String) :
    Except LexicalRejectDiag ParsedDecLit :=
  match s.toList with
  | [] => .error (.invalidNumericCharOrExponent ' ')
  | c0 :: tail0 =>
    if c0 == '+' then
      .error .explicitPlusForbidden
    else if c0 == '-' then
      checkParsedBodyParts cfg true tail0
    else
      checkParsedBodyParts cfg false (c0 :: tail0)

private theorem digits_of_body_no_dot {body part : List Char}
    (hall : ∀ c ∈ body, IsAsciiDigitChar c ∨ c = '.')
    (hsub : ∀ c ∈ part, c ∈ body)
    (hnodot : '.' ∉ part) :
    ∀ c ∈ part, IsAsciiDigitChar c := by
  intro c hc
  rcases hall c (hsub c hc) with hd | hdot
  · exact hd
  · exfalso; exact hnodot (hdot ▸ hc)

private theorem checkParsedBodyParts_sound (cfg : NumericGateConfig) (neg : Bool)
    (body : List Char) (s : String) (d : ParsedDecLit)
    (hsurf : s.toList = (if neg then ['-'] else []) ++ body)
    (hok : checkParsedBodyParts cfg neg body = .ok d) :
    DecSurfaceSpec cfg s d := by
  unfold checkParsedBodyParts at hok
  split at hok
  · contradiction
  · cases hinv : findInvalidNumBodyChar body with
    | some _ => rw [hinv] at hok; contradiction
    | none =>
      rw [hinv] at hok
      have hall_body := (findInvalidNumBodyChar_eq_none_iff body).mp hinv
      cases hsp : splitDots body with
      | manyDots => rw [hsp] at hok; contradiction
      | noDot intCs =>
        rw [hsp] at hok
        dsimp at hok
        have ⟨hbody_eq, hnodot⟩ := splitDots_noDot_props hsp
        split at hok
        · contradiction
        · rename_i hint_ne
          split at hok
          · contradiction
          · rename_i hno_lz
            split at hok
            · contradiction
            · rename_i hint_bound
              split at hok
              · contradiction
              · rename_i hno_negz
                injection hok with hd
                rw [← hd]
                unfold DecSurfaceSpec ParsedDecLit.renderChars
                dsimp
                have hlen_pos : 1 ≤ intCs.length := by
                  cases intCs with | nil => simp at hint_ne | cons _ _ => simp
                have hdigits : ∀ c ∈ intCs, IsAsciiDigitChar c :=
                  digits_of_body_no_dot hall_body (fun c hc => hbody_eq ▸ hc) hnodot
                refine ⟨?_, hlen_pos, by omega, hdigits, ?_, by simp, by simp, ?_⟩
                · rw [hsurf, hbody_eq]
                  simp
                · intro hgt hhead
                  apply hno_lz
                  simp [hgt, hhead]
                · intro hz
                  cases neg with
                  | false => rfl
                  | true =>
                    exfalso
                    apply hno_negz
                    simpa [Bool.and_eq_true] using hz
      | oneDot intCs fracCs =>
        rw [hsp] at hok
        dsimp at hok
        have ⟨hbody_eq, hnodot_i, hnodot_f⟩ := splitDots_oneDot_props hsp
        split at hok
        · contradiction
        · rename_i hint_ne
          split at hok
          · contradiction
          · rename_i hfrac_ne
            split at hok
            · contradiction
            · rename_i hno_lz
              split at hok
              · contradiction
              · rename_i hbounds
                split at hok
                · contradiction
                · rename_i hno_negz
                  injection hok with hd
                  rw [← hd]
                  unfold DecSurfaceSpec ParsedDecLit.renderChars
                  dsimp
                  have hlen_pos : 1 ≤ intCs.length := by
                    cases intCs with | nil => simp at hint_ne | cons _ _ => simp
                  simp [Bool.or_eq_true] at hbounds
                  have hdigits_i : ∀ c ∈ intCs, IsAsciiDigitChar c :=
                    digits_of_body_no_dot hall_body
                      (fun c hc => hbody_eq ▸ List.mem_append_left ('.' :: fracCs) hc) hnodot_i
                  have hdigits_f : ∀ c ∈ fracCs, IsAsciiDigitChar c :=
                    digits_of_body_no_dot hall_body
                      (fun c hc => hbody_eq ▸ List.mem_append_right intCs (List.Mem.tail '.' hc)) hnodot_f
                  refine ⟨?_, hlen_pos, by omega, hdigits_i, ?_, by omega, hdigits_f, ?_⟩
                  · rw [hsurf, hbody_eq]
                    simp [hfrac_ne, List.append_assoc]
                  · intro hgt hhead
                    apply hno_lz
                    simp [hgt, hhead]
                  · intro hz
                    cases neg with
                    | false => rfl
                    | true =>
                      exfalso
                      apply hno_negz
                      simpa [Bool.and_eq_true] using hz

/-- **Soundness of `parseCanonicalDecSurface` (`Gate B/C`)**: every accepted token satisfies `DecSurfaceSpec`! -/
theorem parseCanonicalDecSurface_sound (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hok : parseCanonicalDecSurface cfg s = .ok d) :
    DecSurfaceSpec cfg s d := by
  unfold parseCanonicalDecSurface at hok
  cases hcs : s.toList with
  | nil => rw [hcs] at hok; contradiction
  | cons c0 tail0 =>
    rw [hcs] at hok
    dsimp at hok
    by_cases hp : c0 == '+'
    · rw [if_pos hp] at hok; contradiction
    · rw [if_neg hp] at hok
      by_cases hm : c0 == '-'
      · rw [if_pos hm] at hok
        have hc_eq : c0 = '-' := by simpa [beq_iff_eq] using hm
        subst c0
        exact checkParsedBodyParts_sound cfg true tail0 s d hcs hok
      · rw [if_neg hm] at hok
        exact checkParsedBodyParts_sound cfg false (c0 :: tail0) s d (by simpa using hcs) hok

private theorem digit_ne_dot {c : Char} (hd : IsAsciiDigitChar c) : c ≠ '.' := by
  unfold IsAsciiDigitChar at hd
  intro heq; subst c
  have h0 : '0'.toNat = 48 := rfl
  have hdot : '.'.toNat = 46 := rfl
  omega

private theorem digit_ne_plus {c : Char} (hd : IsAsciiDigitChar c) : c ≠ '+' := by
  unfold IsAsciiDigitChar at hd
  intro heq; subst c
  have h0 : '0'.toNat = 48 := rfl
  have hp : '+'.toNat = 43 := rfl
  omega

private theorem digit_ne_minus {c : Char} (hd : IsAsciiDigitChar c) : c ≠ '-' := by
  unfold IsAsciiDigitChar at hd
  intro heq; subst c
  have h0 : '0'.toNat = 48 := rfl
  have hm : '-'.toNat = 45 := rfl
  omega

private theorem checkParsedBodyParts_complete (cfg : NumericGateConfig) (neg : Bool)
    (intCs fracCs : List Char)
    (hint_ge : 1 ≤ intCs.length)
    (hint_le : intCs.length ≤ cfg.maxIntDigits)
    (hdig_i : ∀ c ∈ intCs, IsAsciiDigitChar c)
    (hno_lz : 1 < intCs.length → intCs.head? ≠ some '0')
    (hfrac_le : fracCs.length ≤ cfg.maxFracDigits)
    (hdig_f : ∀ c ∈ fracCs, IsAsciiDigitChar c)
    (hzero_sign : (ParsedDecLit.mk neg intCs fracCs).absMantissaNat = 0 → neg = false) :
    checkParsedBodyParts cfg neg (intCs ++ (if fracCs.isEmpty then [] else '.' :: fracCs)) =
      .ok ⟨neg, intCs, fracCs⟩ := by
  cases intCs with
  | nil => simp at hint_ge
  | cons i0 irest =>
    have hnodot_i : '.' ∉ (i0 :: irest) := fun hm => digit_ne_dot (hdig_i '.' hm) rfl
    have hnodot_f : '.' ∉ fracCs := fun hm => digit_ne_dot (hdig_f '.' hm) rfl
    have hlz_false : ((1 < (i0 :: irest).length) && ((i0 :: irest).head? == some '0')) = false := by
      by_cases hgt : 1 < (i0 :: irest).length
      · have hne0 : (i0 :: irest).head? ≠ some '0' := hno_lz hgt
        cases hhead : (i0 :: irest).head? == some '0'
        · simp [Bool.and_false]
        · exfalso; exact hne0 (beq_iff_eq.mp hhead)
      · have hd_false : decide (1 < (i0 :: irest).length) = false := decide_eq_false hgt
        rw [hd_false, Bool.false_and]
    have hint_not_gt : ¬ (cfg.maxIntDigits < (i0 :: irest).length) := by omega
    have hnz : (neg && ((ParsedDecLit.mk neg (i0 :: irest) fracCs).absMantissaNat == 0)) = false := by
      cases neg with
      | false => rfl
      | true =>
        simp only [Bool.true_and, beq_eq_false_iff_ne]
        intro hz
        have hf := hzero_sign hz
        contradiction
    cases fracCs with
    | nil =>
      have hbody_ok : findInvalidNumBodyChar (i0 :: irest) = none := by
        apply (findInvalidNumBodyChar_eq_none_iff _).mpr
        intro c hc
        exact Or.inl (hdig_i c hc)
      have hsp := splitDots_of_no_dot hnodot_i
      simp only [List.isEmpty_nil, ↓reduceIte, List.append_nil]
      unfold checkParsedBodyParts
      rw [if_neg (by simp), hbody_ok]
      change (match splitDots (i0 :: irest) with
        | .manyDots => Except.error LexicalRejectDiag.multipleDecimalPoints
        | .noDot intCs =>
          if intCs.isEmpty then Except.error LexicalRejectDiag.leadingDecimalPoint
          else if (1 < intCs.length) && (intCs.head? == some '0') then Except.error LexicalRejectDiag.redundantLeadingZero
          else if cfg.maxIntDigits < intCs.length then Except.error (LexicalRejectDiag.numericPrecisionBoundExceeded intCs.length 0)
          else
            let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := [] }
            if neg && (d.absMantissaNat == 0) then Except.error LexicalRejectDiag.negativeZeroForbidden
            else Except.ok d
        | .oneDot intCs fracCs =>
          if intCs.isEmpty then Except.error LexicalRejectDiag.leadingDecimalPoint
          else if fracCs.isEmpty then Except.error LexicalRejectDiag.trailingDecimalPoint
          else if (1 < intCs.length) && (intCs.head? == some '0') then Except.error LexicalRejectDiag.redundantLeadingZero
          else if (cfg.maxIntDigits < intCs.length) || (cfg.maxFracDigits < fracCs.length) then
            Except.error (LexicalRejectDiag.numericPrecisionBoundExceeded intCs.length fracCs.length)
          else
            let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := fracCs }
            if neg && (d.absMantissaNat == 0) then Except.error LexicalRejectDiag.negativeZeroForbidden
            else Except.ok d) = Except.ok ⟨neg, i0 :: irest, []⟩
      rw [hsp]
      dsimp only
      rw [if_neg (by simp), if_neg (by rw [hlz_false]; decide), if_neg hint_not_gt, if_neg (by rw [hnz]; decide)]
    | cons f0 frest =>
      have hbody_ok : findInvalidNumBodyChar ((i0 :: irest) ++ '.' :: f0 :: frest) = none := by
        apply (findInvalidNumBodyChar_eq_none_iff _).mpr
        intro c hc
        rcases List.mem_append.mp hc with hi | hf
        · exact Or.inl (hdig_i c hi)
        · rcases List.mem_cons.mp hf with rfl | hfm
          · exact Or.inr rfl
          · exact Or.inl (hdig_f c hfm)
      have hsp := splitDots_of_one_dot hnodot_i hnodot_f
      have hf_not_gt : ¬ (cfg.maxFracDigits < (f0 :: frest).length) := by omega
      have hbounds_false : ((cfg.maxIntDigits < (i0 :: irest).length) || (cfg.maxFracDigits < (f0 :: frest).length)) = false := by
        rw [decide_eq_false hint_not_gt, decide_eq_false hf_not_gt]
        rfl
      simp only [List.isEmpty_cons, Bool.false_eq_true, ↓reduceIte]
      unfold checkParsedBodyParts
      have hne_body : ¬ (((i0 :: irest) ++ '.' :: f0 :: frest).isEmpty = true) := by simp
      rw [if_neg hne_body, hbody_ok]
      change (match splitDots ((i0 :: irest) ++ '.' :: f0 :: frest) with
        | .manyDots => Except.error LexicalRejectDiag.multipleDecimalPoints
        | .noDot intCs =>
          if intCs.isEmpty then Except.error LexicalRejectDiag.leadingDecimalPoint
          else if (1 < intCs.length) && (intCs.head? == some '0') then Except.error LexicalRejectDiag.redundantLeadingZero
          else if cfg.maxIntDigits < intCs.length then Except.error (LexicalRejectDiag.numericPrecisionBoundExceeded intCs.length 0)
          else
            let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := [] }
            if neg && (d.absMantissaNat == 0) then Except.error LexicalRejectDiag.negativeZeroForbidden
            else Except.ok d
        | .oneDot intCs fracCs =>
          if intCs.isEmpty then Except.error LexicalRejectDiag.leadingDecimalPoint
          else if fracCs.isEmpty then Except.error LexicalRejectDiag.trailingDecimalPoint
          else if (1 < intCs.length) && (intCs.head? == some '0') then Except.error LexicalRejectDiag.redundantLeadingZero
          else if (cfg.maxIntDigits < intCs.length) || (cfg.maxFracDigits < fracCs.length) then
            Except.error (LexicalRejectDiag.numericPrecisionBoundExceeded intCs.length fracCs.length)
          else
            let d : ParsedDecLit := { neg := neg, intDigits := intCs, fracDigits := fracCs }
            if neg && (d.absMantissaNat == 0) then Except.error LexicalRejectDiag.negativeZeroForbidden
            else Except.ok d) = Except.ok ⟨neg, i0 :: irest, f0 :: frest⟩
      rw [hsp]
      dsimp only
      rw [if_neg (by simp), if_neg (by simp), if_neg (by rw [hlz_false]; decide),
          if_neg (by rw [hbounds_false]; decide), if_neg (by rw [hnz]; decide)]

/-- **Completeness of `parseCanonicalDecSurface` (`Gate B/C`)**: every `DecSurfaceSpec` string is accepted! -/
theorem parseCanonicalDecSurface_complete (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hspec : DecSurfaceSpec cfg s d) :
    parseCanonicalDecSurface cfg s = .ok d := by
  rcases d with ⟨neg, intCs, fracCs⟩
  rcases hspec with ⟨hrend, hint_ge, hint_le, hdig_i, hno_lz, hfrac_le, hdig_f, hzero_sign⟩
  dsimp at hint_ge hint_le hdig_i hno_lz hfrac_le hdig_f hzero_sign
  have hbody := checkParsedBodyParts_complete cfg neg intCs fracCs
    hint_ge hint_le hdig_i hno_lz hfrac_le hdig_f hzero_sign
  unfold parseCanonicalDecSurface
  rw [← hrend]
  cases neg with
  | true =>
    unfold ParsedDecLit.renderChars
    dsimp
    exact hbody
  | false =>
    cases intCs with
    | nil => simp at hint_ge
    | cons i0 irest =>
      have hi0 : IsAsciiDigitChar i0 := hdig_i i0 (List.Mem.head irest)
      have hp : (i0 == '+') = false := beq_eq_false_iff_ne.mpr (digit_ne_plus hi0)
      have hm : (i0 == '-') = false := beq_eq_false_iff_ne.mpr (digit_ne_minus hi0)
      unfold ParsedDecLit.renderChars
      dsimp
      rw [if_neg (by simp [hp]), if_neg (by simp [hm])]
      exact hbody

/-! ### Universal Rejection Theorems for Malformed Numeric Surfaces (`F-P2-02` Explicit Proof) -/

def countChar (target : Char) : List Char → Nat
  | [] => 0
  | c :: cs => (if c = target then 1 else 0) + countChar target cs

theorem countChar_append (target : Char) (xs ys : List Char) :
    countChar target (xs ++ ys) = countChar target xs + countChar target ys := by
  induction xs with
  | nil => simp [countChar]
  | cons x rest ih => simp [countChar, ih, Nat.add_assoc]

theorem countChar_eq_zero_of_not_mem {target : Char} {xs : List Char} (hnot : target ∉ xs) :
    countChar target xs = 0 := by
  induction xs with
  | nil => rfl
  | cons x rest ih =>
    have hx : x ≠ target := fun heq => hnot (heq ▸ List.Mem.head rest)
    have hr : target ∉ rest := fun hm => hnot (List.Mem.tail x hm)
    simp [countChar, hx, ih hr]

/-- **Theorem (`F-P2-02a`): Multi-dot strings (`1..25`, `1.2.3`) NEVER satisfy `DecSurfaceSpec`!** -/
theorem decSurfaceSpec_rejects_multiple_dots (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hmulti : 2 ≤ countChar '.' s.toList) :
    ¬ DecSurfaceSpec cfg s d := by
  rintro ⟨hrend, _, _, hdig_i, _, _, hdig_f, _⟩
  rw [← hrend] at hmulti
  unfold ParsedDecLit.renderChars at hmulti
  rw [countChar_append, countChar_append] at hmulti
  have hsign_zero : countChar '.' (if d.neg then ['-'] else []) = 0 := by
    cases d.neg <;> decide
  have hint_zero : countChar '.' d.intDigits = 0 :=
    countChar_eq_zero_of_not_mem (fun hm => digit_ne_dot (hdig_i '.' hm) rfl)
  have hfrac_le_one : countChar '.' (if d.fracDigits.isEmpty then [] else '.' :: d.fracDigits) ≤ 1 := by
    cases hfe : d.fracDigits with
    | nil => simp [countChar]
    | cons f0 frest =>
      have hf_zero : countChar '.' (f0 :: frest) = 0 :=
        countChar_eq_zero_of_not_mem (fun hm => digit_ne_dot (hdig_f '.' (hfe ▸ hm)) rfl)
      dsimp only [List.isEmpty_cons, Bool.false_eq_true, ↓reduceIte]
      change (if '.' = '.' then 1 else 0) + countChar '.' (f0 :: frest) ≤ 1
      rw [if_pos rfl, hf_zero]
      omega
  omega

/-- **Theorem (`F-P2-02b`): Trailing-dot strings (`1.`) NEVER satisfy `DecSurfaceSpec`!** -/
theorem decSurfaceSpec_rejects_trailing_dot (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (htrail : s.toList.getLast? = some '.') :
    ¬ DecSurfaceSpec cfg s d := by
  rintro ⟨hrend, hint_ge, _, hdig_i, _, _, hdig_f, _⟩
  rw [← hrend] at htrail
  unfold ParsedDecLit.renderChars at htrail
  cases hfe : d.fracDigits with
  | nil =>
    simp [hfe] at htrail
    cases hi : d.intDigits with
    | nil => rw [hi] at hint_ge; simp at hint_ge
    | cons i0 irest =>
      rw [hi] at htrail
      simp at htrail
      have hmem : '.' ∈ (i0 :: irest) := List.mem_of_getLast? htrail
      rw [← hi] at hmem
      exact digit_ne_dot (hdig_i '.' hmem) rfl
  | cons f0 frest =>
    simp [hfe] at htrail
    have hmem : '.' ∈ (f0 :: frest) := List.mem_of_getLast? htrail
    rw [← hfe] at hmem
    exact digit_ne_dot (hdig_f '.' hmem) rfl

/-! ### 6. Closed Entity Catalog Validator & Slot-Level Strict Lexical Gate (`Gate B/C`) -/

def checkCatalogEntryValidBool (e : CatalogEntry) : Bool :=
  (e.sort.regime == .openEntityCatalog) &&
  checkAsciiEntityIdBool e.entityId &&
  checkTrimmedSpacesBool e.lexeme.toList &&
  e.lexeme.toList.all isPrintableAsciiCharBool &&
  (findReservedDelimiter e.lexeme).isNone

theorem checkCatalogEntryValidBool_iff (e : CatalogEntry) :
    checkCatalogEntryValidBool e = true ↔
      e.sort.regime = .openEntityCatalog ∧
      0 < e.entityId.toList.length ∧
      (∀ c ∈ e.entityId.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
      HasTrimmedOuterSpaces e.lexeme.toList ∧
      (∀ c ∈ e.lexeme.toList, (0x20 : UInt32) ≤ c.val ∧ c.val ≤ (0x7E : UInt32)) ∧
      DisjointFromReservedDelimiters e.lexeme := by
  unfold checkCatalogEntryValidBool
  rw [Bool.and_eq_true, Bool.and_eq_true, Bool.and_eq_true, Bool.and_eq_true,
      beq_iff_eq, checkAsciiEntityIdBool_iff, checkTrimmedSpacesBool_iff,
      list_all_eq_true, Option.isNone_iff_eq_none, findReservedDelimiter_eq_none_iff]
  constructor
  · rintro ⟨⟨⟨⟨h1, h2, h3⟩, h4⟩, h5⟩, h6⟩
    exact ⟨h1, h2, h3, h4, fun c hc => (isPrintableAsciiCharBool_iff c).mp (h5 c hc), h6⟩
  · rintro ⟨h1, h2, h3, h4, h5, h6⟩
    exact ⟨⟨⟨⟨h1, h2, h3⟩, h4⟩, fun c hc => (isPrintableAsciiCharBool_iff c).mpr (h5 c hc)⟩, h6⟩

def checkValidEntityCatalogBool (cat : ClosedEntityCatalog) : Bool :=
  cat.entries.all checkCatalogEntryValidBool &&
  cat.entries.all (fun e₁ =>
    cat.entries.all (fun e₂ =>
      !((e₁.sort == e₂.sort) && (e₁.entityId == e₂.entityId)) || (e₁.lexeme == e₂.lexeme))) &&
  cat.entries.all (fun e₁ =>
    cat.entries.all (fun e₂ =>
      !(e₁.lexeme == e₂.lexeme) || (e₁ == e₂)))

theorem checkValidEntityCatalogBool_iff (cat : ClosedEntityCatalog) :
    checkValidEntityCatalogBool cat = true ↔ ValidEntityCatalog cat := by
  unfold checkValidEntityCatalogBool ValidEntityCatalog
  rw [Bool.and_eq_true, Bool.and_eq_true]
  simp only [list_all_eq_true]
  constructor
  · rintro ⟨⟨hent, hkey⟩, hinj⟩
    refine ⟨?_, ?_, ?_⟩
    · intro e he
      exact (checkCatalogEntryValidBool_iff e).mp (hent e he)
    · intro e₁ he₁ e₂ he₂ hs hid
      have h := hkey e₁ he₁ e₂ he₂
      have hk : ((e₁.sort == e₂.sort) && (e₁.entityId == e₂.entityId)) = true := by
        simp [hs, hid]
      rw [hk] at h
      simpa [beq_iff_eq] using h
    · intro e₁ he₁ e₂ he₂ hlex
      have h := hinj e₁ he₁ e₂ he₂
      have hl : (e₁.lexeme == e₂.lexeme) = true := beq_iff_eq.mpr hlex
      rw [hl] at h
      simpa [beq_iff_eq] using h
  · rintro ⟨hent, hkey, hinj⟩
    refine ⟨⟨?_, ?_⟩, ?_⟩
    · intro e he
      exact (checkCatalogEntryValidBool_iff e).mpr (hent e he)
    · intro e₁ he₁ e₂ he₂
      cases hs : e₁.sort == e₂.sort
      · simp
      · cases hid : e₁.entityId == e₂.entityId
        · simp
        · simp [beq_iff_eq.mpr (hkey e₁ he₁ e₂ he₂ (beq_iff_eq.mp hs) (beq_iff_eq.mp hid))]
    · intro e₁ he₁ e₂ he₂
      cases hl : e₁.lexeme == e₂.lexeme
      · simp
      · simp [beq_iff_eq.mpr (hinj e₁ he₁ e₂ he₂ (beq_iff_eq.mp hl))]

/-- Sealed proof-carrying witness for an accepted lexical slot (`private mk ::`). -/
structure CertifiedLexicalSlot (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate) where
  private mk ::
  verifiedStr  : String
  parsedNumber : Option ParsedDecLit
  hStrEq       : verifiedStr = cand.decodedStr
  hLexValid    : LexicallyValid maxBytes cand
  hNumValid    : NumericallyWellFormed numCfg cand
  hCatBound    : EntityCatalogBound cat cand

inductive LexicalSlotOutcome (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate) where
  | accepted (witness : CertifiedLexicalSlot cat numCfg maxBytes cand)
  | rejected (diag : LexicalRejectDiag)

def LexicalSlotOutcome.isAccepted {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {maxBytes : Nat} {cand : RawSlotCandidate} :
    LexicalSlotOutcome cat numCfg maxBytes cand → Bool
  | .accepted _ => true
  | .rejected _ => false

def LexicalSlotOutcome.diag? {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {maxBytes : Nat} {cand : RawSlotCandidate} :
    LexicalSlotOutcome cat numCfg maxBytes cand → Option LexicalRejectDiag
  | .accepted _ => none
  | .rejected d => some d

/--
  Pure Computational Slot Validator (`evalLexicalSlot`):
  Computes `(verifiedStr, parsedNumber)` with zero embedded proof terms so kernel reduction
  is blazing fast and free of dependent-match rewrite obstructions.
-/
def evalLexicalSlot (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate) :
    Except LexicalRejectDiag (String × Option ParsedDecLit) :=
  match checkStrictAsciiIngress maxBytes cand.rawBytes with
  | .error e => .error e
  | .ok () =>
    if !checkAsciiEntityIdBool cand.entityId then
      .error .emptyOrNonAsciiEntityId
    else
      let s := cand.decodedStr
      if !checkTrimmedSpacesBool s.toList then
        .error .untrimmedOuterWhitespace
      else
        match cand.sort.regime with
        | .openEntityCatalog =>
          match findReservedDelimiter s with
          | some badKw => .error (.reservedKeywordLeak badKw)
          | none =>
            if !checkValidEntityCatalogBool cat then
              .error .invalidEntityCatalog
            else if memDecListBool ⟨cand.sort, cand.entityId, s⟩ cat.entries then
              .ok (s, none)
            else
              .error .entityCatalogMismatch
        | .closedFunctionalEnum =>
          if memDecListBool (cand.sort, cand.entityId, s) closedFunctionalEntries then
            .ok (s, none)
          else
            .error .closedFunctionalLexiconMismatch
        | .canonicalDecimal =>
          if cand.entityId != s then
            .error .numericEntityIdMismatch
          else
            match parseCanonicalDecSurface numCfg s with
            | .error e => .error e
            | .ok d    => .ok (s, some d)

theorem evalLexicalSlot_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (payload : String × Option ParsedDecLit)
    (hok : evalLexicalSlot cat numCfg maxBytes cand = .ok payload) :
    payload.1 = cand.decodedStr ∧
    LexicallyValid maxBytes cand ∧
    NumericallyWellFormed numCfg cand ∧
    EntityCatalogBound cat cand := by
  unfold evalLexicalSlot at hok
  cases hing : checkStrictAsciiIngress maxBytes cand.rawBytes with
  | error e => rw [hing] at hok; contradiction
  | ok u =>
    rw [hing] at hok
    dsimp at hok
    cases heid : checkAsciiEntityIdBool cand.entityId with
    | false => rw [heid] at hok; contradiction
    | true =>
      rw [heid] at hok
      dsimp at hok
      cases htrim : checkTrimmedSpacesBool cand.decodedStr.toList with
      | false => rw [htrim] at hok; contradiction
      | true =>
        rw [htrim] at hok
        dsimp at hok
        have hing_v := (checkStrictAsciiIngress_iff maxBytes cand.rawBytes).mp hing
        have heid_v := (checkAsciiEntityIdBool_iff cand.entityId).mp heid
        have htrim_v := (checkTrimmedSpacesBool_iff cand.decodedStr.toList).mp htrim
        cases hreg : cand.sort.regime with
        | openEntityCatalog =>
          rw [hreg] at hok
          dsimp at hok
          cases hkw : findReservedDelimiter cand.decodedStr with
          | some badKw => rw [hkw] at hok; contradiction
          | none =>
            rw [hkw] at hok
            dsimp at hok
            cases hcat : checkValidEntityCatalogBool cat with
            | false => rw [hcat] at hok; contradiction
            | true =>
              rw [hcat] at hok
              dsimp at hok
              cases hmem : memDecListBool ⟨cand.sort, cand.entityId, cand.decodedStr⟩ cat.entries with
              | false => rw [hmem] at hok; contradiction
              | true =>
                rw [hmem] at hok
                dsimp at hok
                injection hok with hp
                rw [← hp]
                refine ⟨rfl, ⟨hing_v, heid_v.1, heid_v.2, htrim_v,
                        fun _ => (findReservedDelimiter_eq_none_iff cand.decodedStr).mp hkw⟩,
                        fun hnum => by rw [hnum] at hreg; contradiction, ?_⟩
                unfold EntityCatalogBound
                rw [hreg]
                exact ⟨(checkValidEntityCatalogBool_iff cat).mp hcat,
                       (memDecListBool_iff _ cat.entries).mp hmem⟩
        | closedFunctionalEnum =>
          rw [hreg] at hok
          dsimp at hok
          cases hfunc : memDecListBool (cand.sort, cand.entityId, cand.decodedStr) closedFunctionalEntries with
          | false => rw [hfunc] at hok; contradiction
          | true =>
            rw [hfunc] at hok
            dsimp at hok
            injection hok with hp
            rw [← hp]
            refine ⟨rfl, ⟨hing_v, heid_v.1, heid_v.2, htrim_v,
                    fun hopen => by rw [hreg] at hopen; contradiction⟩,
                    fun hnum => by rw [hnum] at hreg; contradiction, ?_⟩
            unfold EntityCatalogBound
            rw [hreg]
            exact (memDecListBool_iff _ closedFunctionalEntries).mp hfunc
        | canonicalDecimal =>
          rw [hreg] at hok
          dsimp at hok
          cases hid_eq : (cand.entityId != cand.decodedStr) with
          | true => rw [hid_eq] at hok; contradiction
          | false =>
            rw [hid_eq] at hok
            dsimp at hok
            have heq_id : cand.entityId = cand.decodedStr := by simpa [bne_eq_false_iff_eq] using hid_eq
            cases hdec : parseCanonicalDecSurface numCfg cand.decodedStr with
            | error e => rw [hdec] at hok; contradiction
            | ok d =>
              rw [hdec] at hok
              injection hok with hp
              rw [← hp]
              refine ⟨rfl, ⟨hing_v, heid_v.1, heid_v.2, htrim_v,
                      fun hopen => by rw [hreg] at hopen; contradiction⟩,
                      fun _ => ⟨heq_id, d, parseCanonicalDecSurface_sound numCfg cand.decodedStr d hdec⟩, ?_⟩
              unfold EntityCatalogBound
              rw [hreg]
              trivial

theorem evalLexicalSlot_complete
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (hLex : LexicallyValid maxBytes cand)
    (hNum : NumericallyWellFormed numCfg cand)
    (hBound : EntityCatalogBound cat cand) :
    ∃ payload, evalLexicalSlot cat numCfg maxBytes cand = .ok payload := by
  rcases hLex with ⟨hing_v, heid_len, heid_ch, htrim_v, hdisj_v⟩
  have hing : checkStrictAsciiIngress maxBytes cand.rawBytes = .ok () :=
    (checkStrictAsciiIngress_iff maxBytes cand.rawBytes).mpr hing_v
  have heid : checkAsciiEntityIdBool cand.entityId = true :=
    (checkAsciiEntityIdBool_iff cand.entityId).mpr ⟨heid_len, heid_ch⟩
  have htrim : checkTrimmedSpacesBool cand.decodedStr.toList = true :=
    (checkTrimmedSpacesBool_iff cand.decodedStr.toList).mpr htrim_v
  unfold evalLexicalSlot
  rw [hing]
  simp only [heid, Bool.not_true, Bool.false_eq_true, ↓reduceIte, htrim]
  unfold EntityCatalogBound at hBound
  cases hreg : cand.sort.regime with
  | openEntityCatalog =>
    rw [hreg] at hBound
    dsimp at hBound ⊢
    rcases hBound with ⟨hcat_v, hmem_v⟩
    have hkw : findReservedDelimiter cand.decodedStr = none :=
      (findReservedDelimiter_eq_none_iff cand.decodedStr).mpr (hdisj_v hreg)
    have hcat : checkValidEntityCatalogBool cat = true :=
      (checkValidEntityCatalogBool_iff cat).mpr hcat_v
    have hmem : memDecListBool ⟨cand.sort, cand.entityId, cand.decodedStr⟩ cat.entries = true :=
      (memDecListBool_iff _ cat.entries).mpr hmem_v
    simp [hkw, hcat, hmem]
  | closedFunctionalEnum =>
    rw [hreg] at hBound
    dsimp at hBound ⊢
    have hfunc : memDecListBool (cand.sort, cand.entityId, cand.decodedStr) closedFunctionalEntries = true :=
      (memDecListBool_iff _ closedFunctionalEntries).mpr hBound
    simp [hfunc]
  | canonicalDecimal =>
    dsimp
    have hsort_num : cand.sort = .numericLit := by
      cases hs : cand.sort <;> simp [hs, P3SlotSort.regime] at hreg
      rfl
    rcases hNum hsort_num with ⟨heid_eq, d, hdec_spec⟩
    have hdec_ok : parseCanonicalDecSurface numCfg cand.decodedStr = .ok d :=
      parseCanonicalDecSurface_complete numCfg cand.decodedStr d hdec_spec
    simp [heid_eq, hdec_ok]

/--
  **Top-Level Strict Lexical Gate (`admitLexicalSlot`)**:
  Lifts `evalLexicalSlot` into the sealed proof-carrying `CertifiedLexicalSlot` witness (`private mk ::`).
-/
def admitLexicalSlot (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate) :
    LexicalSlotOutcome cat numCfg maxBytes cand :=
  match h : evalLexicalSlot cat numCfg maxBytes cand with
  | .error e      => .rejected e
  | .ok payload =>
    let hs := evalLexicalSlot_sound cat numCfg maxBytes cand payload h
    .accepted ⟨payload.1, payload.2, hs.1, hs.2.1, hs.2.2.1, hs.2.2.2⟩

/-! ### 7. Master Gate C Soundness & Relative Completeness Theorems -/

/--
  **Master Theorem (`admitLexicalSlot_sound` — Mandate §IV)**:
  `admitLexicalSlot cat numCfg maxBytes cand = .accepted w` implies:
    `LexicallyValid maxBytes cand ∧ NumericallyWellFormed numCfg cand ∧ EntityCatalogBound cat cand`
-/
theorem admitLexicalSlot_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (w : CertifiedLexicalSlot cat numCfg maxBytes cand)
    (_hAcc : admitLexicalSlot cat numCfg maxBytes cand = .accepted w) :
    w.verifiedStr = cand.decodedStr ∧
    LexicallyValid maxBytes cand ∧
    NumericallyWellFormed numCfg cand ∧
    EntityCatalogBound cat cand :=
  ⟨w.hStrEq, w.hLexValid, w.hNumValid, w.hCatBound⟩

/--
  **Relative Completeness (`admitLexicalSlot_complete`)**:
  Any candidate satisfying `LexicallyValid`, `NumericallyWellFormed`, and `EntityCatalogBound`
  is deterministically accepted by `admitLexicalSlot` (non-vacuity guarantee).
-/
theorem admitLexicalSlot_complete
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (hLex : LexicallyValid maxBytes cand)
    (hNum : NumericallyWellFormed numCfg cand)
    (hBound : EntityCatalogBound cat cand) :
    ∃ w : CertifiedLexicalSlot cat numCfg maxBytes cand,
      admitLexicalSlot cat numCfg maxBytes cand = .accepted w := by
  rcases evalLexicalSlot_complete cat numCfg maxBytes cand hLex hNum hBound with ⟨payload, hok⟩
  unfold admitLexicalSlot
  split
  · rename_i e herr
    rw [hok] at herr
    contradiction
  · exact ⟨_, rfl⟩

/-! ### 8. Grammar Rule & `readingAlt` Admission Gate (`Gate A` Executable Binding) -/

def verifyRuleReadingGate (requireGeneratorOnly : Bool) (r : CanonicalRuleId) (readingAlt : Nat) :
    Except LexicalRejectDiag Unit :=
  if requireGeneratorOnly && !r.isGeneratorRule then
    .error .parserOnlyTrapRuleInGenerator
  else if checkReadingSelectionBool r readingAlt then
    .ok ()
  else
    .error .invalidRuleOrReadingAlt

theorem verifyRuleReadingGate_sound (requireGeneratorOnly : Bool) (r : CanonicalRuleId) (readingAlt : Nat)
    (hok : verifyRuleReadingGate requireGeneratorOnly r readingAlt = .ok ()) :
    (requireGeneratorOnly = true → r.isGeneratorRule = true) ∧
    ValidReadingSelection r readingAlt := by
  unfold verifyRuleReadingGate at hok
  split at hok
  · contradiction
  · rename_i hnot_trap
    split at hok
    · rename_i hsel
      refine ⟨?_, (checkReadingSelectionBool_iff r readingAlt).mp hsel⟩
      intro hreq
      cases hg : r.isGeneratorRule
      · simp [hreq, hg] at hnot_trap
      · rfl
    · contradiction

end BrocaOmega.P3A
