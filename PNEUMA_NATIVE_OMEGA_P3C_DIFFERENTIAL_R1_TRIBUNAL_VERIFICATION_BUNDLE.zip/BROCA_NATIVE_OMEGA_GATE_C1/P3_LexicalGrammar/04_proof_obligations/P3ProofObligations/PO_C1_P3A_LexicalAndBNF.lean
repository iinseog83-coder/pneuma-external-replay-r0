/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: Proof Obligation & Held Status Ledger)
  04_proof_obligations/P3ProofObligations/PO_C1_P3A_LexicalAndBNF.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `sorry`, zero custom `axiom`)

  Canonical Export Ledger for `AUTH-C1-P3-A`:
    1. Gate A: `P3A_FrozenBNF_Acyclic`, `P3A_All21CanonicalRulesCovered`, `P3A_TrapPartitionSound`,
               `P3A_GeneratorBNF_Matches_P2`, `P3A_P2_Excludes_Traps`, `P3A_RuleReadingGate_Sound`
    2. Gate B/C: `P3A_StrictAsciiIngress_Sound`, `P3A_CanonicalDecimal_Sound`, `P3A_CanonicalDecimal_Complete`,
                 `P3A_RejectsMultiDot`, `P3A_RejectsTrailingDot`,
                 `P3A_StrictLexicalSlot_Sound`, `P3A_StrictLexicalSlot_Complete`
    3. Gate D: `P3A_All32CounterexamplePairs_Verified`
    4. Explicit Governance & Residual `HELD` / `NOT_AUTHORIZED` Locks (zero premature promotion).
-/
import P3FormalSpec
import P3DetachedChecker
import P3Counterexamples

namespace BrocaOmega.P3A.ProofObligations

/-! ### 1. Gate A — Independent Frozen BNF & `P2` Correspondence Theorems -/

theorem P3A_FrozenBNF_Acyclic :
    independentFrozenBNF.all isProductionAcyclicBool = true :=
  all_independentFrozenBNF_acyclic

theorem P3A_All21CanonicalRulesCovered (r : CanonicalRuleId) :
    isCanonicalRuleCoveredBool r = true :=
  all_21_canonical_rules_covered r

theorem P3A_TrapPartitionSound :
    independentFrozenBNF.all (fun p =>
      match p.canonicalOwner with
      | some r => p.isGenerator == r.isGeneratorRule
      | none   => true) = true :=
  trap_productions_never_in_generator

theorem P3A_GeneratorBNF_Matches_P2 :
    (generatorBNFSubset.map fun p => (p.lhs, p.rhs)) =
    (p2RuleSnapshots.map fun s => (s.lhs, s.rhs)) :=
  p3_generator_bnf_matches_p2_snapshots

theorem P3A_P2_Excludes_Traps :
    trapBNFSubset.all (fun tp =>
      p2RuleSnapshots.all (fun s => !((tp.lhs == s.lhs) && (tp.rhs == s.rhs)))) = true :=
  p2_snapshots_exclude_all_trap_productions

theorem P3A_RuleReadingGate_Sound (requireGeneratorOnly : Bool) (r : CanonicalRuleId) (readingAlt : Nat)
    (hok : verifyRuleReadingGate requireGeneratorOnly r readingAlt = .ok ()) :
    (requireGeneratorOnly = true → r.isGeneratorRule = true) ∧
    ValidReadingSelection r readingAlt :=
  verifyRuleReadingGate_sound requireGeneratorOnly r readingAlt hok

/-! ### 2. Gate B & Gate C — Strict Lexical, Decimal & Closed Catalog Soundness/Completeness -/

theorem P3A_StrictAsciiIngress_Sound (maxBytes : Nat) (rawBytes : List UInt8)
    (w : VerifiedIngressText maxBytes)
    (hok : admitStrictAsciiIngress maxBytes rawBytes = .ok w) :
    w.rawBytes = rawBytes ∧ StrictAsciiUTF8Valid maxBytes rawBytes :=
  admitStrictAsciiIngress_sound maxBytes rawBytes w hok

theorem P3A_CanonicalDecimal_Sound (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hok : parseCanonicalDecSurface cfg s = .ok d) :
    DecSurfaceSpec cfg s d :=
  parseCanonicalDecSurface_sound cfg s d hok

theorem P3A_CanonicalDecimal_Complete (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hspec : DecSurfaceSpec cfg s d) :
    parseCanonicalDecSurface cfg s = .ok d :=
  parseCanonicalDecSurface_complete cfg s d hspec

theorem P3A_RejectsMultiDot (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (hmulti : 2 ≤ countChar '.' s.toList) :
    ¬ DecSurfaceSpec cfg s d :=
  decSurfaceSpec_rejects_multiple_dots cfg s d hmulti

theorem P3A_RejectsTrailingDot (cfg : NumericGateConfig) (s : String) (d : ParsedDecLit)
    (htrail : s.toList.getLast? = some '.') :
    ¬ DecSurfaceSpec cfg s d :=
  decSurfaceSpec_rejects_trailing_dot cfg s d htrail

/--
  **Master `AUTH-C1-P3-A` Soundness Theorem (Mandate §IV)**:
  `Accepted(x) -> LexicallyValid(x) ∧ NumericallyWellFormed(x) ∧ EntityCatalogBound(x)`
-/
theorem P3A_StrictLexicalSlot_Sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (w : CertifiedLexicalSlot cat numCfg maxBytes cand)
    (hAcc : admitLexicalSlot cat numCfg maxBytes cand = .accepted w) :
    w.verifiedStr = cand.decodedStr ∧
    LexicallyValid maxBytes cand ∧
    NumericallyWellFormed numCfg cand ∧
    EntityCatalogBound cat cand :=
  admitLexicalSlot_sound cat numCfg maxBytes cand w hAcc

theorem P3A_StrictLexicalSlot_Complete
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxBytes : Nat) (cand : RawSlotCandidate)
    (hLex : LexicallyValid maxBytes cand)
    (hNum : NumericallyWellFormed numCfg cand)
    (hBound : EntityCatalogBound cat cand) :
    ∃ w : CertifiedLexicalSlot cat numCfg maxBytes cand,
      admitLexicalSlot cat numCfg maxBytes cand = .accepted w :=
  admitLexicalSlot_complete cat numCfg maxBytes cand hLex hNum hBound

/-! ### 3. Gate D — Compile-Time Kernel Verification of 32 Symmetric Vectors -/

theorem P3A_All32CounterexamplePairs_Verified :
    Counterexamples.allP3ACases.all Counterexamples.P3ATestCase.runCheck = true :=
  Counterexamples.allP3ACases_verified

/-! ### 4. Explicit Governance & Residual `HELD` / `NOT_AUTHORIZED` Locks -/

inductive GateDisposition where
  | scopedLocalSourceVerified
  | evidenceSubmittedPendingTribunalHeld
  | heldExternalReplay
  | heldUnspecifiedInR0
  | notAuthorized
  deriving DecidableEq, Repr

def status_P1_ExternalReplay                : GateDisposition := .heldExternalReplay
def status_P2_ExternalReplay                : GateDisposition := .heldExternalReplay
def status_F_P2_01_FrozenGrammarEquivalence : GateDisposition := .evidenceSubmittedPendingTribunalHeld
def status_F_P2_02_LexicalAndEntityBinding  : GateDisposition := .evidenceSubmittedPendingTribunalHeld
def status_R0_G01CensoredSurface            : GateDisposition := .heldUnspecifiedInR0
def status_R0_ProductionOntologyEntries     : GateDisposition := .heldUnspecifiedInR0
def status_P3A_StrictLexicalAndBNF          : GateDisposition := .scopedLocalSourceVerified
def status_P3B_BoundedParser_PO_C1_01       : GateDisposition := .notAuthorized
def status_P3C_SemanticNorm_PO_C1_03        : GateDisposition := .notAuthorized
def status_P1C_Int128FastPath               : GateDisposition := .notAuthorized
def status_P4_ClinicalEvidence              : GateDisposition := .notAuthorized
def status_P5_SnapshotAdmission             : GateDisposition := .notAuthorized
def status_Pneuma_S3_S4_Integration         : GateDisposition := .notAuthorized

end BrocaOmega.P3A.ProofObligations
