#!/usr/bin/env python3
"""
BROCA-NATIVE OMEGA — AUTH-C1-P3-A (`P3_LexicalGrammar`: Differential Oracle & P2 Disk Audit)
05_independent_tribunal/differential_oracle_p3a.py

Clean-room Python 3.11 differential verification harness (`Gate D` / Mandate §V):
1. Cross-verifies `P2CorrespondenceAudit.lean`'s 27-entry `p2RuleSnapshots` directly against
   `P2_DerivationReplay/01_formal_spec/P2FormalSpec/GrammarG16.lean` on disk (read-only).
2. Verifies 1-to-1 `Result_Lean(x) == Result_Python(x)` differential parity on all 32 fixed
   `(PC, CE)` vectors exported by `p3a_tribunal_runner.exe --export-fixed-json`.
3. Generates 300 deterministic serialized vectors (`seed = 2026112203`: 240 adversarial
   mutations + 60 valid boundary cases), feeds the EXACT SAME serialized batch file to BOTH
   `p3a_tribunal_runner.exe --eval-batch` and the Python clean-room oracle, and separately
   reports Lean<->Python parity, Lean rejection rate, and Python rejection rate.
"""

from __future__ import annotations

import json
import pathlib
import random
import re
import subprocess
import sys
import tempfile
from typing import Any

OPEN_SORTS = {
    "cohortSpec", "designNoun", "followUpWindow", "eventTerm", "measureTerm",
    "expLevel", "outTerm", "sourceId", "identAssump", "subgroupPlural",
    "subgroupSingular", "covariateList",
}

CLOSED_FUNC_ENTRIES = {
    ("assocDir", "positively", "positively"),
    ("assocDir", "inversely", "inversely"),
    ("ratioMetric", "rr", "risk ratio"),
    ("ratioMetric", "or", "odds ratio"),
    ("ratioMetric", "hr", "hazard ratio"),
    ("intervDirVerb", "increase", "increase"),
    ("intervDirVerb", "reduce", "reduce"),
    ("intervVerbPres", "causes", "causes"),
    ("intervVerbPres", "increases", "increases"),
    ("intervVerbPres", "reduces", "reduces"),
    ("epistemicVerb", "establish", "establish"),
    ("epistemicVerb", "determine", "determine"),
    ("epistemicVerb", "confirm", "confirm"),
    ("epistemicVerb", "reveal", "reveal"),
    ("whWord", "why", "why"),
    ("whWord", "how", "how"),
}

RESERVED_DELIMITERS = [
    ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same",
    "In ", " why ", " how ",
]

REF_VALID_CATALOG = [
    ("cohortSpec", "cohort_primary", "the primary cohort"),
    ("designNoun", "design_rct", "randomized trial"),
    ("designNoun", "design_obs", "observational study"),
    ("followUpWindow", "win_24m", "24 months"),
    ("eventTerm", "evt_hf", "heart failure"),
    ("measureTerm", "meas_sbp", "systolic blood pressure"),
    ("expLevel", "exp_intensive", "intensive therapy"),
    ("expLevel", "exp_std", "standard care"),
    ("outTerm", "out_mi", "myocardial infarction"),
    ("sourceId", "src_trialA", "Trial-A"),
    ("identAssump", "assump_exch", "conditional exchangeability"),
    ("subgroupPlural", "sub_lowrisk", "low-risk"),
    ("subgroupSingular", "sub_frail", "frail"),
    ("covariateList", "cov_age_hba1c", "age and baseline HbA1c"),
]

POISONED_CATALOG = REF_VALID_CATALOG + [
    ("cohortSpec", "cohort_dup_surf", "randomized trial"),
]

RULE_ALT_COUNTS = {
    **{f"G{i:02d}": 1 for i in range(1, 17)},
    "T1": 2, "T2": 2, "T3": 1, "T4": 2, "T5": 1,
}

MAX_INT_DIGITS = 7
MAX_FRAC_DIGITS = 4


def decode_hex_bytes(h: str) -> bytes:
    if h == "-":
        return b""
    return bytes.fromhex(h)


def decode_hex_ascii_str(h: str) -> str:
    bs = decode_hex_bytes(h)
    return "".join(chr(b) for b in bs)


def encode_hex_bytes(bs: bytes) -> str:
    return bs.hex() if bs else "-"


def py_valid_catalog(entries: list[tuple[str, str, str]]) -> bool:
    for srt, eid, lex in entries:
        if srt not in OPEN_SORTS:
            return False
        if not eid or not all(0x20 <= ord(c) <= 0x7E for c in eid):
            return False
        if not lex or lex[0] == " " or lex[-1] == " ":
            return False
        if not all(0x20 <= ord(c) <= 0x7E for c in lex):
            return False
        if any(bad in lex for bad in RESERVED_DELIMITERS):
            return False
    # Key uniqueness & global canonical surface injectivity (`F-R2.2-02`)
    for i, e1 in enumerate(entries):
        for j, e2 in enumerate(entries):
            if e1[0] == e2[0] and e1[1] == e2[1] and e1[2] != e2[2]:
                return False
            if e1[2] == e2[2] and e1 != e2:
                return False
    return True


def py_parse_canonical_decimal(s: str) -> tuple[bool, str]:
    if not s:
        return False, "invalidNumericCharOrExponent"
    if s[0] == "+":
        return False, "explicitPlusForbidden"
    if s[0] == "-":
        neg = True
        body = s[1:]
    else:
        neg = False
        body = s
    if not body:
        return False, "invalidNumericCharOrExponent"
    for ch in body:
        if not ("0" <= ch <= "9" or ch == "."):
            return False, "invalidNumericCharOrExponent"
    dot_count = body.count(".")
    if dot_count >= 2:
        return False, "multipleDecimalPoints"
    if dot_count == 0:
        int_cs, frac_cs = body, ""
        if not int_cs:
            return False, "leadingDecimalPoint"
        if len(int_cs) > 1 and int_cs[0] == "0":
            return False, "redundantLeadingZero"
        if len(int_cs) > MAX_INT_DIGITS:
            return False, "numericPrecisionBoundExceeded"
        if neg and int(int_cs) == 0:
            return False, "negativeZeroForbidden"
        return True, "NONE"
    # dot_count == 1
    int_cs, frac_cs = body.split(".", 1)
    if not int_cs:
        return False, "leadingDecimalPoint"
    if not frac_cs:
        return False, "trailingDecimalPoint"
    if len(int_cs) > 1 and int_cs[0] == "0":
        return False, "redundantLeadingZero"
    if len(int_cs) > MAX_INT_DIGITS or len(frac_cs) > MAX_FRAC_DIGITS:
        return False, "numericPrecisionBoundExceeded"
    if neg and int(int_cs + frac_cs) == 0:
        return False, "negativeZeroForbidden"
    return True, "NONE"


def py_eval_slot(
    use_poisoned: bool,
    max_bytes: int,
    sort_name: str,
    eid_str: str,
    raw_bytes: bytes,
) -> tuple[bool, str]:
    if len(raw_bytes) == 0:
        return False, "emptyRawBytes"
    if len(raw_bytes) > max_bytes:
        return False, "inputLengthExceeded"
    for b in raw_bytes:
        if not (0x20 <= b <= 0x7E):
            return False, "nonPrintableAsciiOrInvalidUtf8"
    if not eid_str or not all(0x20 <= ord(c) <= 0x7E for c in eid_str):
        return False, "emptyOrNonAsciiEntityId"
    s = "".join(chr(b) for b in raw_bytes)
    if not s or s[0] == " " or s[-1] == " ":
        return False, "untrimmedOuterWhitespace"

    if sort_name in OPEN_SORTS:
        for bad in RESERVED_DELIMITERS:
            if bad in s:
                return False, "reservedKeywordLeak"
        cat = POISONED_CATALOG if use_poisoned else REF_VALID_CATALOG
        if not py_valid_catalog(cat):
            return False, "invalidEntityCatalog"
        if (sort_name, eid_str, s) in cat:
            return True, "NONE"
        return False, "entityCatalogMismatch"

    if sort_name == "numericLit":
        if eid_str != s:
            return False, "numericEntityIdMismatch"
        return py_parse_canonical_decimal(s)

    # Closed functional enum
    if (sort_name, eid_str, s) in CLOSED_FUNC_ENTRIES:
        return True, "NONE"
    return False, "closedFunctionalLexiconMismatch"


def py_eval_rule(req_gen_only: bool, rule_name: str, reading_alt: int) -> tuple[bool, str]:
    is_gen = rule_name.startswith("G")
    if req_gen_only and not is_gen:
        return False, "parserOnlyTrapRuleInGenerator"
    alt_max = RULE_ALT_COUNTS[rule_name]
    if 1 <= reading_alt <= alt_max:
        return True, "NONE"
    return False, "invalidRuleOrReadingAlt"


def verify_p2_disk_snapshot_fidelity(gate_root: pathlib.Path) -> tuple[int, int]:
    """Read-only verification that P3's p2RuleSnapshots matches P2's GrammarG16.lean on disk."""
    p2_grammar = (
        gate_root / "P2_DerivationReplay" / "01_formal_spec" / "P2FormalSpec" / "GrammarG16.lean"
    ).read_text(encoding="utf-8")
    p3_audit = (
        gate_root / "P3_LexicalGrammar" / "01_formal_spec" / "P3FormalSpec" / "P2CorrespondenceAudit.lean"
    ).read_text(encoding="utf-8")

    # Extract `(ruleName -> code)` specifically from `def FrozenGenRule.toCode`
    tocode_section = p2_grammar.split("def FrozenGenRule.toCode")[1].split("def decodeFrozenRule")[0]
    p2_code_matches = re.findall(r"\|\s*\.([A-Za-z0-9_]+)\s*=>\s*(\d+)", tocode_section)
    p2_codes = {name: int(code) for name, code in p2_code_matches}

    # Extract `(p2Code, p2Name)` from P3 `p2RuleSnapshots`
    p3_snap_matches = re.findall(
        r"p2Code\s*:=\s*(\d+),\s*p2Name\s*:=\s*\"([A-Za-z0-9_]+)\"", p3_audit
    )
    p3_snaps = {name: int(code) for code, name in p3_snap_matches}

    if p2_codes != p3_snaps or len(p2_codes) != 27:
        raise RuntimeError(f"P2 code mismatch: disk={p2_codes} vs p3={p3_snaps}")

    # Also check every literal terminal string `.lit "..."` per rule in P2 matches `.term "..."` in P3
    matched = 0
    for name in sorted(p2_codes):
        p2_block_m = re.search(
            rf"\|\s*\.{name}\s*=>\s*\{{(.*?)(?=\n\s*\|\s*\.|\n/-!)", p2_grammar, re.S
        )
        p3_block_m = re.search(
            rf'p2Name\s*:=\s*"{name}".*?rhs\s*:=\s*\[(.*?)\]\s*\}}', p3_audit, re.S
        )
        if not p2_block_m or not p3_block_m:
            raise RuntimeError(f"Could not locate rule block for {name}")
        p2_lits = re.findall(r'\.lit\s+"([^"]*)"', p2_block_m.group(1))
        p3_terms = re.findall(r'\.term\s+"([^"]*)"', p3_block_m.group(1))
        p2_slots = re.findall(r"\.slot\s+\.([A-Za-z0-9_]+)\s+\.([A-Za-z0-9_]+)", p2_block_m.group(1))
        p3_slots = re.findall(r"\.lexSlot\s+\.([A-Za-z0-9_]+)\s+\.([A-Za-z0-9_]+)", p3_block_m.group(1))
        if p2_lits != p3_terms or p2_slots != p3_slots:
            raise RuntimeError(
                f"Segment mismatch on {name}: P2=({p2_lits}, {p2_slots}) vs P3=({p3_terms}, {p3_slots})"
            )
        matched += 1
    return matched, 27


def generate_mutation_batch(seed: int = 2026112203) -> list[dict[str, Any]]:
    """Generates 240 adversarial mutations + 60 valid boundary cases = 300 serialized records."""
    rng = random.Random(seed)
    records: list[dict[str, Any]] = []

    # 60 valid boundary records (numbers, open catalog entries, closed functional entries, valid rules)
    for i in range(60):
        kind_mod = i % 4
        cid = f"MUT-VALID-{i+1:03d}"
        if kind_mod == 0:
            int_val = rng.randint(0, 9999999)
            frac_len = rng.randint(0, 4)
            if frac_len == 0:
                s = f"-{int_val}" if (int_val > 0 and i % 2 == 1) else f"{int_val}"
            else:
                frac = "".join(str(rng.randint(0, 9)) for _ in range(frac_len))
                neg_ok = (int_val > 0 or int(frac) > 0) and (i % 2 == 1)
                s = f"-{int_val}.{frac}" if neg_ok else f"{int_val}.{frac}"
            records.append({
                "caseId": cid, "adversarial": False,
                "tsv": f"SLOT\t{cid}\t0\t64\tnumericLit\t{encode_hex_bytes(s.encode('ascii'))}\t{encode_hex_bytes(s.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, "numericLit", s, s.encode("ascii")),
            })
        elif kind_mod == 1:
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            records.append({
                "caseId": cid, "adversarial": False,
                "tsv": f"SLOT\t{cid}\t0\t64\t{srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, srt, eid, lex.encode("ascii")),
            })
        elif kind_mod == 2:
            func_list = sorted(CLOSED_FUNC_ENTRIES)
            srt, eid, lex = func_list[i % len(func_list)]
            records.append({
                "caseId": cid, "adversarial": False,
                "tsv": f"SLOT\t{cid}\t0\t64\t{srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, srt, eid, lex.encode("ascii")),
            })
        else:
            rname = rng.choice(list(RULE_ALT_COUNTS.keys()))
            req_gen = rname.startswith("G")
            alt = rng.randint(1, RULE_ALT_COUNTS[rname])
            records.append({
                "caseId": cid, "adversarial": False,
                "tsv": f"RULE\t{cid}\t{1 if req_gen else 0}\t{rname}\t{alt}",
                "pyArgs": ("RULE", req_gen, rname, alt),
            })

    # 240 adversarial mutations across 12 distinct attack classes (20 each)
    bad_Numerics = [
        "1..25", "0..5", "1.2.3", "12.34.56", "1.", "99.", ".25", "-.5",
        "+1.25", "+0", "00", "001.25", "-00.1", "-0", "-0.0", "-0.000",
        "1e-3", "2E4", "12345678", "1.12345",
    ]
    for i in range(240):
        cid = f"MUT-ADV-{i+1:03d}"
        cls = i % 12
        if cls in (0, 1, 2):
            s = bad_Numerics[(i // 3) % len(bad_Numerics)]
            raw = s.encode("ascii")
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\tnumericLit\t{encode_hex_bytes(raw)}\t{encode_hex_bytes(raw)}",
                "pyArgs": ("SLOT", False, 64, "numericLit", s, raw),
            })
        elif cls == 3:
            # Numeric entityId mismatch
            s = f"{rng.randint(1, 99)}.{rng.randint(0, 9)}"
            eid = s + "0"
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\tnumericLit\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(s.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, "numericLit", eid, s.encode("ascii")),
            })
        elif cls == 4:
            # Valid lexeme + wrong entityId
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            wrong_eid = eid + "_forged"
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\t{srt}\t{encode_hex_bytes(wrong_eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, srt, wrong_eid, lex.encode("ascii")),
            })
        elif cls == 5:
            # Valid entityId & lexeme + wrong SlotSort
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            other_sorts = [x for x in sorted(OPEN_SORTS) if x != srt]
            wrong_srt = other_sorts[i % len(other_sorts)]
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\t{wrong_srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, wrong_srt, eid, lex.encode("ascii")),
            })
        elif cls == 6:
            # Reserved syncategorematic delimiter leak
            kw = RESERVED_DELIMITERS[i % len(RESERVED_DELIMITERS)]
            lex = f"entity {kw} tail".strip()
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\texpLevel\t{encode_hex_bytes(b'exp_intensive')}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 64, "expLevel", "exp_intensive", lex.encode("ascii")),
            })
        elif cls == 7:
            # Non-ASCII / invalid UTF-8 / control bytes (`0x00`, `0x09`, `0x7F`, `0xD0 0xBE`, `0xFF`)
            bad_byte = rng.choice([0x00, 0x09, 0x0A, 0x1F, 0x7F, 0x80, 0xD0, 0xFF])
            raw = b"Trial" + bytes([bad_byte]) + b"A"
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\tsourceId\t{encode_hex_bytes(b'src_trialA')}\t{encode_hex_bytes(raw)}",
                "pyArgs": ("SLOT", False, 64, "sourceId", "src_trialA", raw),
            })
        elif cls == 8:
            # Untrimmed leading/trailing space or empty raw bytes
            raw = b"" if i % 2 == 0 else b" intensive therapy"
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t64\texpLevel\t{encode_hex_bytes(b'exp_intensive')}\t{encode_hex_bytes(raw)}",
                "pyArgs": ("SLOT", False, 64, "expLevel", "exp_intensive", raw),
            })
        elif cls == 9:
            # Poisoned catalog violating Global Surface Injectivity (`F-R2.2-02`)
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t1\t64\t{srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", True, 64, srt, eid, lex.encode("ascii")),
            })
        elif cls == 10:
            # Input byte length exceeding budget `maxBytes = 4`
            srt, eid, lex = REF_VALID_CATALOG[i % len(REF_VALID_CATALOG)]
            records.append({
                "caseId": cid, "adversarial": True,
                "tsv": f"SLOT\t{cid}\t0\t4\t{srt}\t{encode_hex_bytes(eid.encode('ascii'))}\t{encode_hex_bytes(lex.encode('ascii'))}",
                "pyArgs": ("SLOT", False, 4, srt, eid, lex.encode("ascii")),
            })
        else:
            # Trap rule in generator OR invalid readingAlt (`0` or `> altCount`)
            if i % 2 == 0:
                trap = rng.choice(["T1", "T2", "T3", "T4", "T5"])
                records.append({
                    "caseId": cid, "adversarial": True,
                    "tsv": f"RULE\t{cid}\t1\t{trap}\t1",
                    "pyArgs": ("RULE", True, trap, 1),
                })
            else:
                rname = rng.choice(list(RULE_ALT_COUNTS.keys()))
                bad_alt = 0 if (i // 2) % 2 == 0 else RULE_ALT_COUNTS[rname] + 1
                records.append({
                    "caseId": cid, "adversarial": True,
                    "tsv": f"RULE\t{cid}\t0\t{rname}\t{bad_alt}",
                    "pyArgs": ("RULE", False, rname, bad_alt),
                })

    return records


def main() -> int:
    p3_root = pathlib.Path(__file__).resolve().parent.parent
    gate_root = p3_root.parent
    exe_path = p3_root / ".lake" / "build" / "bin" / "p3a_tribunal_runner.exe"
    if not exe_path.exists():
        print(f"ERROR: Missing executable {exe_path}", file=sys.stderr)
        return 2

    # 1. Read-only disk audit of P2 GrammarG16.lean vs P3 P2CorrespondenceAudit.lean
    p2_matched, p2_total = verify_p2_disk_snapshot_fidelity(gate_root)

    # 2. Fixed 32-vector suite 1-to-1 differential check
    fixed_proc = subprocess.run([str(exe_path), "--export-fixed-json"], capture_output=True, text=True, check=True)
    fixed_cases: list[dict[str, Any]] = json.loads(fixed_proc.stdout)

    print("==========================================================================")
    print("PYTHON 3.11 INDEPENDENT DIFFERENTIAL ORACLE — BROCA-NATIVE OMEGA P3-A")
    print(f"Read-Only P2 Disk Snapshot Verification : {p2_matched} / {p2_total} EXACT RULE MATCH")
    print("==========================================================================")

    fixed_mismatches = 0
    for tc in fixed_cases:
        pl = tc["payload"]
        if pl["kind"] == "SLOT":
            py_acc, py_tag = py_eval_slot(
                pl["usePoisonedCat"],
                pl["maxBytes"],
                pl["sort"],
                decode_hex_ascii_str(pl["entityIdHex"]),
                decode_hex_bytes(pl["rawBytesHex"]),
            )
        else:
            py_acc, py_tag = py_eval_rule(pl["requireGenOnly"], pl["rule"], pl["readingAlt"])

        lean_acc = tc["leanAccepted"]
        lean_tag = tc["leanDiagTag"]
        ok = (py_acc == lean_acc) and (py_tag == lean_tag)
        mark = "PARITY_OK" if ok else "MISMATCH"
        print(f"[{mark}] {tc['caseId']} | Lean=({lean_acc}, {lean_tag}) | Python=({py_acc}, {py_tag})")
        if not ok:
            fixed_mismatches += 1

    # 3. True bidirectional 300-vector serialized batch differential test (`Lean <-> Python` 1:1!)
    batch_records = generate_mutation_batch(seed=2026112203)
    with tempfile.TemporaryDirectory() as tmpdir:
        tsv_path = pathlib.Path(tmpdir) / "p3a_batch_300.tsv"
        tsv_path.write_text("\n".join(r["tsv"] for r in batch_records) + "\n", encoding="utf-8")
        batch_proc = subprocess.run(
            [str(exe_path), "--eval-batch", str(tsv_path)],
            capture_output=True, text=True, check=True,
        )
        lean_batch_out: list[dict[str, Any]] = json.loads(batch_proc.stdout)

    assert len(lean_batch_out) == len(batch_records), "Batch output count mismatch!"
    batch_mismatches = 0
    lean_adv_rej = 0
    py_adv_rej = 0
    adv_total = 0
    lean_val_acc = 0
    py_val_acc = 0
    val_total = 0

    for rec, lean_res in zip(batch_records, lean_batch_out):
        assert rec["caseId"] == lean_res["caseId"]
        args = rec["pyArgs"]
        if args[0] == "SLOT":
            py_acc, py_tag = py_eval_slot(args[1], args[2], args[3], args[4], args[5])
        else:
            py_acc, py_tag = py_eval_rule(args[1], args[2], args[3])

        lean_acc = lean_res["leanAccepted"]
        lean_tag = lean_res["leanDiagTag"]
        if (py_acc != lean_acc) or (py_tag != lean_tag):
            batch_mismatches += 1
            print(f"[BATCH_MISMATCH] {rec['caseId']}: Lean=({lean_acc}, {lean_tag}) vs Py=({py_acc}, {py_tag})")

        if rec["adversarial"]:
            adv_total += 1
            if not lean_acc:
                lean_adv_rej += 1
            if not py_acc:
                py_adv_rej += 1
        else:
            val_total += 1
            if lean_acc:
                lean_val_acc += 1
            if py_acc:
                py_val_acc += 1

    print("--------------------------------------------------------------------------")
    print(f"Fixed Curated Lean <-> Python Parity     : {len(fixed_cases) - fixed_mismatches} / {len(fixed_cases)} EXACT MATCH")
    print(f"External Batch Lean <-> Python Parity    : {len(batch_records) - batch_mismatches} / {len(batch_records)} EXACT MATCH (seed=2026112203)")
    print(f"Lean Adversarial Mutation Rejections     : {lean_adv_rej} / {adv_total}")
    print(f"Python Adversarial Mutation Rejections   : {py_adv_rej} / {adv_total}")
    print(f"Valid Boundary Mutation Acceptances      : Lean={lean_val_acc}/{val_total}, Python={py_val_acc}/{val_total}")
    print(f"P2 GrammarG16.lean Disk Snapshot Match   : {p2_matched} / {p2_total}")
    print("==========================================================================")

    if (
        fixed_mismatches == 0
        and batch_mismatches == 0
        and lean_adv_rej == adv_total
        and py_adv_rej == adv_total
        and lean_val_acc == val_total
        and py_val_acc == val_total
    ):
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
