/-
  BROCA-NATIVE Ω — AUTH-C1-P3-A (`P3_LexicalGrammar`: 16 Symmetric `(PC, CE)` Pairs = 32 Vectors)
  03_counterexamples/P3Counterexamples/P3ASuite.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `native_decide`)

  Gate D Deliverable:
  Exercises `admitLexicalSlot` and `verifyRuleReadingGate` directly (exact proof-to-execution binding)
  across all numeric, UTF-8/ASCII, entity-catalog, surface-injectivity, keyword-barrier, and BNF
  trap/readingAlt boundaries specified in the `AUTH-C1-P3-A` Mandate.
-/
import P3DetachedChecker

namespace BrocaOmega.P3A.Counterexamples

/-- Pure kernel-reducible ASCII byte encoder for test vector construction (avoids opaque `@[extern]` `String.toUTF8`). -/
def strToUtf8Bytes (s : String) : List UInt8 :=
  s.toList.map (fun c => UInt8.ofNat c.toNat)

/-- Canonical surface-injective reference entity catalog for `P3-A` test vectors (`ValidEntityCatalog`). -/
def refValidCatalog : ClosedEntityCatalog :=
  { entries :=
      [ { sort := .cohortSpec,       entityId := "cohort_primary", lexeme := "the primary cohort" },
        { sort := .designNoun,       entityId := "design_rct",     lexeme := "randomized trial" },
        { sort := .designNoun,       entityId := "design_obs",     lexeme := "observational study" },
        { sort := .followUpWindow,   entityId := "win_24m",        lexeme := "24 months" },
        { sort := .eventTerm,        entityId := "evt_hf",         lexeme := "heart failure" },
        { sort := .measureTerm,      entityId := "meas_sbp",       lexeme := "systolic blood pressure" },
        { sort := .expLevel,         entityId := "exp_intensive",  lexeme := "intensive therapy" },
        { sort := .expLevel,         entityId := "exp_std",        lexeme := "standard care" },
        { sort := .outTerm,          entityId := "out_mi",         lexeme := "myocardial infarction" },
        { sort := .sourceId,         entityId := "src_trialA",     lexeme := "Trial-A" },
        { sort := .identAssump,      entityId := "assump_exch",    lexeme := "conditional exchangeability" },
        { sort := .subgroupPlural,   entityId := "sub_lowrisk",    lexeme := "low-risk" },
        { sort := .subgroupSingular, entityId := "sub_frail",      lexeme := "frail" },
        { sort := .covariateList,    entityId := "cov_age_hba1c",  lexeme := "age and baseline HbA1c" } ] }

/-- Poisoned catalog violating Global Surface Injectivity (`F-R2.2-02`): `"randomized trial"` in 2 sorts! -/
def poisonedAmbiguousCatalog : ClosedEntityCatalog :=
  { entries :=
      refValidCatalog.entries ++
      [ { sort := .cohortSpec, entityId := "cohort_dup_surf", lexeme := "randomized trial" } ] }

theorem refValidCatalog_is_valid : checkValidEntityCatalogBool refValidCatalog = true := by decide
theorem poisonedCatalog_is_invalid : checkValidEntityCatalogBool poisonedAmbiguousCatalog = false := by decide

/-- Unified test case covering both `admitLexicalSlot` and `verifyRuleReadingGate`. -/
inductive P3ATestPayload where
  | slotCheck
      (usePoisonedCat : Bool)
      (maxBytes       : Nat)
      (cand           : RawSlotCandidate)
  | ruleReadingCheck
      (requireGenOnly : Bool)
      (rule           : CanonicalRuleId)
      (readingAlt     : Nat)
  deriving DecidableEq, Repr

structure P3ATestCase where
  caseId       : String
  pairGroup    : String
  isPositive   : Bool
  payload      : P3ATestPayload
  expectedPass : Bool
  expectedDiag : Option LexicalRejectDiag
  deriving DecidableEq, Repr

/-- Executes the EXACT proved gate functions (`admitLexicalSlot` / `verifyRuleReadingGate`)! -/
def P3ATestCase.evalActual (tc : P3ATestCase) : Bool × Option LexicalRejectDiag :=
  match tc.payload with
  | .slotCheck usePoison maxB cand =>
    let cat := if usePoison then poisonedAmbiguousCatalog else refValidCatalog
    let out := admitLexicalSlot cat frozenR22NumericConfig maxB cand
    (out.isAccepted, out.diag?)
  | .ruleReadingCheck reqGen r alt =>
    match verifyRuleReadingGate reqGen r alt with
    | .ok ()   => (true, none)
    | .error d => (false, some d)

def P3ATestCase.runCheck (tc : P3ATestCase) : Bool :=
  let (acc, diagOpt) := tc.evalActual
  (acc == tc.expectedPass) && (diagOpt == tc.expectedDiag)

def mkNumSlot (eid s : String) : RawSlotCandidate :=
  { sort := .numericLit, entityId := eid, rawBytes := strToUtf8Bytes s }

def mkEntSlot (srt : P3SlotSort) (eid s : String) : RawSlotCandidate :=
  { sort := srt, entityId := eid, rawBytes := strToUtf8Bytes s }

/-! ### 16 Symmetric `(PC, CE)` Pairs (`32` Curated Vectors) -/

-- Pair 01: `1.25` vs `1..25` (Double decimal point — `F-P2-02`)
def pc01 : P3ATestCase :=
  { caseId := "PC-P3A-01", pairGroup := "PAIR-01-MULTI-DOT-1", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "1.25" "1.25"),
    expectedPass := true, expectedDiag := none }

def ce01 : P3ATestCase :=
  { caseId := "CE-P3A-01", pairGroup := "PAIR-01-MULTI-DOT-1", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "1..25" "1..25"),
    expectedPass := false, expectedDiag := some .multipleDecimalPoints }

-- Pair 02: `-1.25` vs `1.2.3` (Multi-segment decimal — `F-P2-02`)
def pc02 : P3ATestCase :=
  { caseId := "PC-P3A-02", pairGroup := "PAIR-02-MULTI-DOT-2", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "-1.25" "-1.25"),
    expectedPass := true, expectedDiag := none }

def ce02 : P3ATestCase :=
  { caseId := "CE-P3A-02", pairGroup := "PAIR-02-MULTI-DOT-2", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "1.2.3" "1.2.3"),
    expectedPass := false, expectedDiag := some .multipleDecimalPoints }

-- Pair 03: `0.0` vs `-0.0` (Negative zero ban — `F-C0-01`)
def pc03 : P3ATestCase :=
  { caseId := "PC-P3A-03", pairGroup := "PAIR-03-NEG-ZERO", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0.0" "0.0"),
    expectedPass := true, expectedDiag := none }

def ce03 : P3ATestCase :=
  { caseId := "CE-P3A-03", pairGroup := "PAIR-03-NEG-ZERO", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "-0.0" "-0.0"),
    expectedPass := false, expectedDiag := some .negativeZeroForbidden }

-- Pair 04: `1.0` vs `1.` (Trailing decimal point excluded by `S0-R2.2` `(\.[0-9]{1,4})?`)
def pc04 : P3ATestCase :=
  { caseId := "PC-P3A-04", pairGroup := "PAIR-04-TRAILING-DOT", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "1.0" "1.0"),
    expectedPass := true, expectedDiag := none }

def ce04 : P3ATestCase :=
  { caseId := "CE-P3A-04", pairGroup := "PAIR-04-TRAILING-DOT", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "1." "1."),
    expectedPass := false, expectedDiag := some .trailingDecimalPoint }

-- Pair 05: `0.25` vs `.25` (Leading decimal point)
def pc05 : P3ATestCase :=
  { caseId := "PC-P3A-05", pairGroup := "PAIR-05-LEADING-DOT", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0.25" "0.25"),
    expectedPass := true, expectedDiag := none }

def ce05 : P3ATestCase :=
  { caseId := "CE-P3A-05", pairGroup := "PAIR-05-LEADING-DOT", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot ".25" ".25"),
    expectedPass := false, expectedDiag := some .leadingDecimalPoint }

-- Pair 06: `128.4` vs `+1.25` (Explicit leading `+` sign policy)
def pc06 : P3ATestCase :=
  { caseId := "PC-P3A-06", pairGroup := "PAIR-06-EXPLICIT-PLUS", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "128.4" "128.4"),
    expectedPass := true, expectedDiag := none }

def ce06 : P3ATestCase :=
  { caseId := "CE-P3A-06", pairGroup := "PAIR-06-EXPLICIT-PLUS", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "+1.25" "+1.25"),
    expectedPass := false, expectedDiag := some .explicitPlusForbidden }

-- Pair 07: `0.002` vs `001.25` (Redundant leading zero)
def pc07 : P3ATestCase :=
  { caseId := "PC-P3A-07", pairGroup := "PAIR-07-LEADING-ZERO", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0.002" "0.002"),
    expectedPass := true, expectedDiag := none }

def ce07 : P3ATestCase :=
  { caseId := "CE-P3A-07", pairGroup := "PAIR-07-LEADING-ZERO", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "001.25" "001.25"),
    expectedPass := false, expectedDiag := some .redundantLeadingZero }

-- Pair 08: `0` vs `1e-3` (Scientific exponent notation)
def pc08 : P3ATestCase :=
  { caseId := "PC-P3A-08", pairGroup := "PAIR-08-EXPONENT", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0" "0"),
    expectedPass := true, expectedDiag := none }

def ce08 : P3ATestCase :=
  { caseId := "CE-P3A-08", pairGroup := "PAIR-08-EXPONENT", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "1e-3" "1e-3"),
    expectedPass := false, expectedDiag := some (.invalidNumericCharOrExponent 'e') }

-- Pair 09: `9999999.9999` vs `12345678.1` (`S0-R2.2` `(7, 4)` digit cap)
def pc09 : P3ATestCase :=
  { caseId := "PC-P3A-09", pairGroup := "PAIR-09-PRECISION-CAP", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "9999999.9999" "9999999.9999"),
    expectedPass := true, expectedDiag := none }

def ce09 : P3ATestCase :=
  { caseId := "CE-P3A-09", pairGroup := "PAIR-09-PRECISION-CAP", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "12345678.1" "12345678.1"),
    expectedPass := false, expectedDiag := some (.numericPrecisionBoundExceeded 8 1) }

-- Pair 10: Numeric `entityId == lexeme` vs Forged numeric `entityId`
def pc10 : P3ATestCase :=
  { caseId := "PC-P3A-10", pairGroup := "PAIR-10-NUMERIC-ID-BIND", isPositive := true,
    payload := .slotCheck false 64 (mkNumSlot "0.78" "0.78"),
    expectedPass := true, expectedDiag := none }

def ce10 : P3ATestCase :=
  { caseId := "CE-P3A-10", pairGroup := "PAIR-10-NUMERIC-ID-BIND", isPositive := false,
    payload := .slotCheck false 64 (mkNumSlot "0.99" "0.78"),
    expectedPass := false, expectedDiag := some .numericEntityIdMismatch }

-- Pair 11: Valid `entityId` + `lexeme` vs Valid `lexeme` + Wrong `entityId` (Mandate §2.B)
def pc11 : P3ATestCase :=
  { caseId := "PC-P3A-11", pairGroup := "PAIR-11-WRONG-ENTITY-ID", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .expLevel "exp_intensive" "intensive therapy"),
    expectedPass := true, expectedDiag := none }

def ce11 : P3ATestCase :=
  { caseId := "CE-P3A-11", pairGroup := "PAIR-11-WRONG-ENTITY-ID", isPositive := false,
    payload := .slotCheck false 64 (mkEntSlot .expLevel "exp_std" "intensive therapy"),
    expectedPass := false, expectedDiag := some .entityCatalogMismatch }

-- Pair 12: Valid `entityId` + `SlotSort` vs Valid `entityId` + Wrong `SlotSort` (Mandate §2.B)
def pc12 : P3ATestCase :=
  { caseId := "PC-P3A-12", pairGroup := "PAIR-12-WRONG-SLOT-SORT", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .cohortSpec "cohort_primary" "the primary cohort"),
    expectedPass := true, expectedDiag := none }

def ce12 : P3ATestCase :=
  { caseId := "CE-P3A-12", pairGroup := "PAIR-12-WRONG-SLOT-SORT", isPositive := false,
    payload := .slotCheck false 64 (mkEntSlot .designNoun "cohort_primary" "the primary cohort"),
    expectedPass := false, expectedDiag := some .entityCatalogMismatch }

-- Pair 13: Clean open entity vs Syncategorematic keyword smuggling (`"did not"`)
def pc13 : P3ATestCase :=
  { caseId := "PC-P3A-13", pairGroup := "PAIR-13-KEYWORD-LEAK", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .outTerm "out_mi" "myocardial infarction"),
    expectedPass := true, expectedDiag := none }

def ce13 : P3ATestCase :=
  { caseId := "CE-P3A-13", pairGroup := "PAIR-13-KEYWORD-LEAK", isPositive := false,
    payload := .slotCheck false 64 (mkEntSlot .outTerm "out_mi" "infarction did not recur"),
    expectedPass := false, expectedDiag := some (.reservedKeywordLeak "did not") }

-- Pair 14: Printable 7-bit ASCII vs Cyrillic UTF-8 Homoglyph `'о'` (`0xD0, 0xBE` — `F-C0-03`)
def pc14 : P3ATestCase :=
  { caseId := "PC-P3A-14", pairGroup := "PAIR-14-UTF8-HOMOGLYPH", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .sourceId "src_trialA" "Trial-A"),
    expectedPass := true, expectedDiag := none }

def ce14 : P3ATestCase :=
  { caseId := "CE-P3A-14", pairGroup := "PAIR-14-UTF8-HOMOGLYPH", isPositive := false,
    payload := .slotCheck false 64
      { sort := .sourceId, entityId := "src_trialA",
        rawBytes := [0x54, 0x72, 0xD0, 0xBE, 0x61, 0x6C] }, -- 'T','r', Cyrillic 'о', 'a','l'
    expectedPass := false, expectedDiag := some (.nonPrintableAsciiOrInvalidUtf8 0xD0) }

-- Pair 15: Surface-Injective Catalog vs Cross-Sort Duplicate-Lexeme Catalog (`F-R2.2-02`)
def pc15 : P3ATestCase :=
  { caseId := "PC-P3A-15", pairGroup := "PAIR-15-CATALOG-INJECTIVITY", isPositive := true,
    payload := .slotCheck false 64 (mkEntSlot .designNoun "design_rct" "randomized trial"),
    expectedPass := true, expectedDiag := none }

def ce15 : P3ATestCase :=
  { caseId := "CE-P3A-15", pairGroup := "PAIR-15-CATALOG-INJECTIVITY", isPositive := false,
    payload := .slotCheck true 64 (mkEntSlot .designNoun "design_rct" "randomized trial"),
    expectedPass := false, expectedDiag := some .invalidEntityCatalog }

-- Pair 16: `T2` Dual Reading (`alt=2` in parser) vs `T2` Claimed as Generator Rule (`Gate A`)
def pc16 : P3ATestCase :=
  { caseId := "PC-P3A-16", pairGroup := "PAIR-16-TRAP-READING-ALT", isPositive := true,
    payload := .ruleReadingCheck false .T2 2,
    expectedPass := true, expectedDiag := none }

def ce16 : P3ATestCase :=
  { caseId := "CE-P3A-16", pairGroup := "PAIR-16-TRAP-READING-ALT", isPositive := false,
    payload := .ruleReadingCheck true .T2 1,
    expectedPass := false, expectedDiag := some .parserOnlyTrapRuleInGenerator }

def allP3ACases : List P3ATestCase :=
  [ pc01, ce01, pc02, ce02, pc03, ce03, pc04, ce04,
    pc05, ce05, pc06, ce06, pc07, ce07, pc08, ce08,
    pc09, ce09, pc10, ce10, pc11, ce11, pc12, ce12,
    pc13, ce13, pc14, ce14, pc15, ce15, pc16, ce16 ]

/-- All 32 symmetric `(PC, CE)` vectors verified at compile time with pure `decide` (0 `native_decide`)! -/
theorem allP3ACases_verified : allP3ACases.all P3ATestCase.runCheck = true := by
  decide

end BrocaOmega.P3A.Counterexamples
