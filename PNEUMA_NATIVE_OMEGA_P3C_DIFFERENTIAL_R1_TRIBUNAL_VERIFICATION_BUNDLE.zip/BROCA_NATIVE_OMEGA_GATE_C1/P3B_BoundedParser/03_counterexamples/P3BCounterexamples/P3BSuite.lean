/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`Gate C.4` Non-Vacuity & `Gate E` Counterexample Suite)
  03_counterexamples/P3BCounterexamples/P3BSuite.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  Verifies 28 curated positive controls & adversarial counterexamples via Lean's kernel `decide`:
    - Positive non-vacuity parses across `G-01`, `G-03`, `G-09`, `G-15b`, `G-16` (`|T| = 1`)
    - Multi-reading trap preservation (`T2` `|T| = 2` `[alt=1, alt=2]`, `T1` `|T| = 2`, `T4` `|T| = 2`,
      plus `T3` and `T5` parser-only traps)
    - Strict 3-state separation:
        * `enumerated []` on in-domain grammatically/lexically/side-condition invalid inputs
        * `outOfDomain` on empty / non-7-bit-ASCII inputs
        * `resourceOverflow` on all 4 `ResourceBudget` bounds (`maxBytes`, `maxSteps`, `maxForestNodes`,
          and `maxReadings = 1` on `T2` proving non-truncation fail-closed!)
    - End-to-end `BridgeSound` & `ProjectionFaithful` verification (`verifyBridgedDerivation` accepting
      valid `P3-A` + `P2` certificates while blocking `1..25` multi-dot bypass, `entityId` spoofing,
      `T2` trap rule injection, and projection tampering).
-/
import P3BDetachedChecker

namespace BrocaOmega.P3B.Counterexamples

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B

/-! ### 1. Reference Closed Entity Catalog & Scope Environments (Strictly Within `R0` Sorts) -/

/-- Clean catalog obeying `F-R2.2-02` Global Canonical Surface Injectivity (`checkValidEntityCatalogBool = true`). -/
def strictTestCatalog : ClosedEntityCatalog :=
  { entries :=
      [ { sort := .cohortSpec,       entityId := "coh_primary", lexeme := "the primary cohort" },
        { sort := .designNoun,       entityId := "des_study",   lexeme := "study" },
        { sort := .followUpWindow,   entityId := "win_12m",     lexeme := "12 months" },
        { sort := .eventTerm,        entityId := "ev_stroke",   lexeme := "stroke" },
        { sort := .eventTerm,        entityId := "ev_aki",      lexeme := "acute kidney injury" },
        { sort := .expLevel,         entityId := "exp_intens",  lexeme := "intensive therapy" },
        { sort := .expLevel,         entityId := "exp_std",     lexeme := "standard care" },
        { sort := .outTerm,          entityId := "out_mi",      lexeme := "myocardial infarction" },
        { sort := .outTerm,          entityId := "out_death",   lexeme := "all-cause mortality" },
        { sort := .sourceId,         entityId := "src_trialA",  lexeme := "Trial-A" },
        { sort := .subgroupPlural,   entityId := "sub_dm_pl",   lexeme := "diabetic" },
        { sort := .subgroupSingular, entityId := "sub_hr_sg",   lexeme := "high-risk" } ] }

theorem strictTestCatalog_valid :
    ValidEntityCatalog strictTestCatalog :=
  (checkValidEntityCatalogBool_iff strictTestCatalog).mp (by decide)

def envAtomic : ScopeEnv :=
  { cohortId := "coh_primary", expectedDesignHead := "des_study", quoteIsolation := .sentenceAtomic }

def envDiscourse : ScopeEnv :=
  { cohortId := "coh_primary", expectedDesignHead := "des_study", quoteIsolation := .discourseBound }

/-! ### 2. Canonical Reading Signature Extractor for `ConcreteParseTree` -/

mutual
  def findPrimaryReadingSegs : List ConcreteParseArg → Option (CanonicalRuleId × Nat × Bool)
    | [] => none
    | .litTok _ _ :: rest => findPrimaryReadingSegs rest
    | .slotTok _ _ _ _ _ :: rest => findPrimaryReadingSegs rest
    | .childSub sub :: rest =>
      match extractPrimaryReading sub with
      | some r => some r
      | none   => findPrimaryReadingSegs rest

  /-- Extracts `(canonicalOwnerRule, readingAlt, isGenerator)` of the primary rule node in pre-order. -/
  def extractPrimaryReading : ConcreteParseTree → Option (CanonicalRuleId × Nat × Bool)
    | .mkTree p alt _ _ args =>
      let sig := frozenProdSig p
      match sig.ownerRule with
      | some r => some (r, alt, sig.isGenerator)
      | none   => findPrimaryReadingSegs args
end

def runParserOnStr (env : ScopeEnv) (budget : ResourceBudget) (s : String) : BoundedParseResult :=
  parseAllBounded strictTestCatalog frozenR22NumericConfig env budget (strToAsciiBytes s)

/-! ### 3. Concrete Non-Vacuity Theorems (`Gate C.4` — Kernel-Proved via `decide`) -/

def sG01 : String :=
  "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%)."

def sG03 : String :=
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."

def sG09 : String :=
  "In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."

def sG15b : String :=
  "In the primary cohort, no diabetic patients developed stroke. Within this same study, at least one high-risk patient developed acute kidney injury."

def sG16 : String :=
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."

/-- Mandatory `T2` Dual-Reading Sentence (`Y_T08` from `Architecture Freeze R0` / `P0-A05`). -/
def sT2_DualReading : String :=
  "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction."

def sT1_DualReading : String :=
  "In the primary cohort, all diabetic patients did not develop stroke."

def sT3_WhTrap : String :=
  "In the primary cohort, the analysis of Trial-A did not determine why intensive therapy reduces myocardial infarction."

def sT4_DualReading : String :=
  "In the primary cohort, diabetic patients developed stroke."

def sT5_Unscoped : String :=
  "no diabetic patients developed stroke."

def checkSingleGeneratorParse (env : ScopeEnv) (s : String) (expectedRule : CanonicalRuleId) : Bool :=
  match runParserOnStr env defaultParseBudget s with
  | .enumerated [t] =>
    eqStrBool (reconstructParseYield t) s &&
    (extractPrimaryReading t == some (expectedRule, 1, true))
  | _ => false

def checkDualTrapReadingsRes (res : BoundedParseResult) (s : String) (expectedTrap : CanonicalRuleId) : Bool :=
  match res with
  | .enumerated [t1, t2] =>
    (!parseTreeEqBool t1 t2) &&
    eqStrBool (reconstructParseYield t1) s &&
    eqStrBool (reconstructParseYield t2) s &&
    (extractPrimaryReading t1 == some (expectedTrap, 1, false)) &&
    (extractPrimaryReading t2 == some (expectedTrap, 2, false))
  | _ => false

/--
  Verifies that `parseAllBounded` enumerates EXACTLY 2 distinct `ConcreteParseTree`s
  `[t1, t2]` (`!parseTreeEqBool t1 t2`) with `readingAlt = 1` and `readingAlt = 2` for a 2-reading trap (`T1`, `T2`, `T4`).
-/
def checkDualTrapReadings (env : ScopeEnv) (s : String) (expectedTrap : CanonicalRuleId) : Bool :=
  checkDualTrapReadingsRes (runParserOnStr env defaultParseBudget s) s expectedTrap

theorem checkDualTrapReadingsRes_sound (res : BoundedParseResult) (s : String) (expectedTrap : CanonicalRuleId)
    (h : checkDualTrapReadingsRes res s expectedTrap = true) :
    ∃ t1 t2 : ConcreteParseTree,
      res = .enumerated [t1, t2] ∧
      t1 ≠ t2 ∧
      extractPrimaryReading t1 = some (expectedTrap, 1, false) ∧
      extractPrimaryReading t2 = some (expectedTrap, 2, false) := by
  cases res with
  | outOfDomain _ => contradiction
  | resourceOverflow _ => contradiction
  | enumerated ts =>
    cases ts with
    | nil => contradiction
    | cons t1 r1 =>
      cases r1 with
      | nil => contradiction
      | cons t2 r2 =>
        cases r2 with
        | cons _ _ => contradiction
        | nil =>
          unfold checkDualTrapReadingsRes at h
          simp only [Bool.and_eq_true, Bool.not_eq_true', beq_iff_eq] at h
          have hfalse : parseTreeEqBool t1 t2 = false := h.1.1.1.1
          have hext1 : extractPrimaryReading t1 = some (expectedTrap, 1, false) := h.1.2
          have hext2 : extractPrimaryReading t2 = some (expectedTrap, 2, false) := h.2
          have hne : t1 ≠ t2 := by
            intro heq
            rw [(parseTreeEqBool_iff t1 t2).mpr heq] at hfalse
            contradiction
          exact ⟨t1, t2, rfl, hne, hext1, hext2⟩

def checkSingleTrapReading (env : ScopeEnv) (s : String) (expectedTrap : CanonicalRuleId) : Bool :=
  match runParserOnStr env defaultParseBudget s with
  | .enumerated [t] =>
    eqStrBool (reconstructParseYield t) s &&
    (extractPrimaryReading t == some (expectedTrap, 1, false))
  | _ => false

set_option maxRecDepth 16384 in
/-- **Gate C.4a Non-Vacuity**: Concrete `G-01` valid parse witness (`|T| = 1`). -/
theorem nonvacuous_G01_enumerated :
    checkSingleGeneratorParse envAtomic sG01 .G01 = true := by decide

set_option maxRecDepth 16384 in
private theorem nonvacuous_T2_bool :
    checkDualTrapReadings envAtomic sT2_DualReading .T2 = true := by decide

/-- **Gate C.4b Non-Vacuity**: Concrete `T2` dual-reading witness (`|T| = 2`, `τ₁ ≠ τ₂`, `alt = 1, 2`). -/
theorem nonvacuous_T2_two_distinct_readings :
    checkDualTrapReadings envAtomic sT2_DualReading .T2 = true ∧
    (∃ t1 t2 : ConcreteParseTree,
      runParserOnStr envAtomic defaultParseBudget sT2_DualReading = .enumerated [t1, t2] ∧
      t1 ≠ t2 ∧
      extractPrimaryReading t1 = some (.T2, 1, false) ∧
      extractPrimaryReading t2 = some (.T2, 2, false)) :=
  ⟨nonvacuous_T2_bool,
   checkDualTrapReadingsRes_sound (runParserOnStr envAtomic defaultParseBudget sT2_DualReading)
     sT2_DualReading .T2 nonvacuous_T2_bool⟩

/-! ### 4. Concrete Bridge Certificates & Adversarial Bypass/Tamper Fixtures (`Gate D / Gate E`) -/

def sBridgeG11 : String :=
  "In the primary cohort, no diabetic patients developed stroke."

def deltaBridgeG11 : List ObligationToken :=
  [ { oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } },
    { oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_stroke" } } ]

def validRawCertG11 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 61⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 60⟩
          [{ oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G11_QuantZero.toCode ⟨23, 60⟩
                [{ oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_stroke" } }]
                [ .litSpan "no " ⟨23, 26⟩,
                  .slotLeaf { sort := .subgroupPlural, role := .subgroup, entityId := "sub_dm_pl",
                              lexeme := "diabetic", span := ⟨26, 34⟩ },
                  .litSpan " patients developed " ⟨34, 54⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_stroke",
                              lexeme := "stroke", span := ⟨54, 60⟩ } ]) ]),
      .litSpan "." ⟨60, 61⟩ ]

def spoofedEntityCertG11 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 61⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 60⟩
          [{ oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G11_QuantZero.toCode ⟨23, 60⟩
                [{ oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_aki" } }]
                [ .litSpan "no " ⟨23, 26⟩,
                  .slotLeaf { sort := .subgroupPlural, role := .subgroup, entityId := "sub_dm_pl",
                              lexeme := "diabetic", span := ⟨26, 34⟩ },
                  .litSpan " patients developed " ⟨34, 54⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_aki",
                              lexeme := "stroke", span := ⟨54, 60⟩ } ]) ]),
      .litSpan "." ⟨60, 61⟩ ]

def spoofedDeltaG11 : List ObligationToken :=
  [ { oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } },
    { oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_aki" } } ]

def deltaBridgeG01 : List ObligationToken :=
  [ { oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } },
    { oblId := 11, spec := { locus := .clause1, kind := .descIncidence, target := "win_12m:ev_stroke:42/500=8.4" } } ]

def validRawCertG01 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 104⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 103⟩
          [{ oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G01_DescIncidence.toCode ⟨23, 103⟩
                [{ oblId := 11, spec := { locus := .clause1, kind := .descIncidence, target := "win_12m:ev_stroke:42/500=8.4" } }]
                [ .litSpan "over " ⟨23, 28⟩,
                  .slotLeaf { sort := .followUpWindow, role := .window, entityId := "win_12m",
                              lexeme := "12 months", span := ⟨28, 37⟩ },
                  .litSpan ", the cumulative incidence of " ⟨37, 67⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_stroke",
                              lexeme := "stroke", span := ⟨67, 73⟩ },
                  .litSpan " was " ⟨73, 78⟩,
                  .slotLeaf { sort := .numericLit, role := .numK, entityId := "42",
                              lexeme := "42", span := ⟨78, 80⟩ },
                  .litSpan " of " ⟨80, 84⟩,
                  .slotLeaf { sort := .numericLit, role := .numN, entityId := "500",
                              lexeme := "500", span := ⟨84, 87⟩ },
                  .litSpan " patients (" ⟨87, 98⟩,
                  .slotLeaf { sort := .numericLit, role := .numPct, entityId := "8.4",
                              lexeme := "8.4", span := ⟨98, 101⟩ },
                  .litSpan "%)" ⟨101, 103⟩ ]) ]),
      .litSpan "." ⟨103, 104⟩ ]

def sBadMultiDotG01 : String :=
  "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (1..25%)."

def badMultiDotCertG01 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 106⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 105⟩
          [{ oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G01_DescIncidence.toCode ⟨23, 105⟩
                [{ oblId := 11, spec := { locus := .clause1, kind := .descIncidence, target := "win_12m:ev_stroke:42/500=1..25" } }]
                [ .litSpan "over " ⟨23, 28⟩,
                  .slotLeaf { sort := .followUpWindow, role := .window, entityId := "win_12m",
                              lexeme := "12 months", span := ⟨28, 37⟩ },
                  .litSpan ", the cumulative incidence of " ⟨37, 67⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_stroke",
                              lexeme := "stroke", span := ⟨67, 73⟩ },
                  .litSpan " was " ⟨73, 78⟩,
                  .slotLeaf { sort := .numericLit, role := .numK, entityId := "42",
                              lexeme := "42", span := ⟨78, 80⟩ },
                  .litSpan " of " ⟨80, 84⟩,
                  .slotLeaf { sort := .numericLit, role := .numN, entityId := "500",
                              lexeme := "500", span := ⟨84, 87⟩ },
                  .litSpan " patients (" ⟨87, 98⟩,
                  .slotLeaf { sort := .numericLit, role := .numPct, entityId := "1..25",
                              lexeme := "1..25", span := ⟨98, 103⟩ },
                  .litSpan "%)" ⟨103, 105⟩ ]) ]),
      .litSpan "." ⟨105, 106⟩ ]

def badMultiDotDeltaG01 : List ObligationToken :=
  [ { oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } },
    { oblId := 11, spec := { locus := .clause1, kind := .descIncidence, target := "win_12m:ev_stroke:42/500=1..25" } } ]

def tamperedSpanCertG11 : UntrustedDerivCert :=
  .mkNode 1 FrozenGenRule.DocSingle.toCode ⟨0, 61⟩ []
    [ .childNode
        (.mkNode 2 FrozenGenRule.ScopedInitial.toCode ⟨0, 59⟩
          [{ oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "coh_primary" } }]
          [ .litSpan "In " ⟨0, 3⟩,
            .slotLeaf { sort := .cohortSpec, role := .cohort, entityId := "coh_primary",
                        lexeme := "the primary cohort", span := ⟨3, 21⟩ },
            .litSpan ", " ⟨21, 23⟩,
            .childNode
              (.mkNode 3 FrozenGenRule.G11_QuantZero.toCode ⟨23, 60⟩
                [{ oblId := 2, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_dm_pl:ev_stroke" } }]
                [ .litSpan "no " ⟨23, 26⟩,
                  .slotLeaf { sort := .subgroupPlural, role := .subgroup, entityId := "sub_dm_pl",
                              lexeme := "diabetic", span := ⟨26, 34⟩ },
                  .litSpan " patients developed " ⟨34, 54⟩,
                  .slotLeaf { sort := .eventTerm, role := .eventA, entityId := "ev_stroke",
                              lexeme := "stroke", span := ⟨54, 60⟩ } ]) ]),
      .litSpan "." ⟨60, 61⟩ ]

def trapInjectedCert : UntrustedDerivCert :=
  .mkNode 1 902 ⟨0, 61⟩ [] []

/-! ### 5. Unified 28-Vector `(PC, CE)` Verification Table (`Gate E`) -/

def evalBridgeVerdict (env : ScopeEnv) (rawBytes : List UInt8)
    (delta : List ObligationToken) (cert : UntrustedDerivCert) : Bool × Option BridgeRejectDiag :=
  match verifyBridgedDerivation strictTestCatalog frozenR22NumericConfig env 512 rawBytes delta cert with
  | .ok _    => (true, none)
  | .error e => (false, some e)

def checkTamperedProjectionDetected : Bool :=
  match certifyDerivTree strictTestCatalog frozenR22NumericConfig 61 validRawCertG11 with
  | .error _ => false
  | .ok x    =>
    checkProjectionFaithfulBool x (lowerToP2Cert x) &&
    !checkProjectionFaithfulBool x tamperedSpanCertG11

structure P3BTestCase where
  caseId      : String
  pairGroup   : String
  description : String
  passed      : Bool
  verdictTag  : String
  deriving DecidableEq, Repr

def pc01_b : Bool := checkSingleGeneratorParse envAtomic sG01 .G01
def ce01_b : Bool := runParserOnStr envAtomic defaultParseBudget sBadMultiDotG01 == .enumerated []
def pc02_b : Bool := checkSingleGeneratorParse envAtomic sG03 .G03
def ce02_b : Bool := runParserOnStr envAtomic defaultParseBudget
  "In the primary cohort, comparing intensive therapy versus intensive therapy was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)." == .enumerated []
def pc03_b : Bool := checkSingleGeneratorParse envAtomic sG09 .G09
def ce03_b : Bool := runParserOnStr envAtomic defaultParseBudget
  "In the primary cohort, intensive therapy cured myocardial infarction." == .enumerated []
def pc04_b : Bool := checkSingleGeneratorParse envDiscourse sG15b .G15
def ce04_b : Bool := runParserOnStr envAtomic defaultParseBudget sG15b == .enumerated []
def pc05_b : Bool := checkSingleGeneratorParse envDiscourse sG16 .G16
def ce05_b : Bool := runParserOnStr envDiscourse defaultParseBudget
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality." == .enumerated []
def pc06_b : Bool := checkDualTrapReadings envAtomic sT2_DualReading .T2
def ce06_b : Bool := runParserOnStr envAtomic { defaultParseBudget with maxReadings := 1 } sT2_DualReading ==
  .resourceOverflow (.maxReadingsExceeded 2 1)
def pc07_b : Bool := checkDualTrapReadings envAtomic sT1_DualReading .T1
def ce07_b : Bool := runParserOnStr envAtomic { defaultParseBudget with maxBytes := 20 } sT1_DualReading ==
  .resourceOverflow (.maxBytesExceeded 68 20)
def pc08_b : Bool := checkSingleTrapReading envAtomic sT3_WhTrap .T3
def ce08_b : Bool := runParserOnStr envAtomic { defaultParseBudget with maxSteps := 5 } sT3_WhTrap ==
  .resourceOverflow (.maxStepsExceeded 5)
def pc09_b : Bool := checkDualTrapReadings envAtomic sT4_DualReading .T4
def ce09_b : Bool := runParserOnStr envAtomic { defaultParseBudget with maxForestNodes := 1 } sT4_DualReading ==
  .resourceOverflow (.maxForestNodesExceeded 1)
def pc10_b : Bool := checkSingleTrapReading envAtomic sT5_Unscoped .T5
def ce10_b : Bool := parseAllBounded strictTestCatalog frozenR22NumericConfig envAtomic defaultParseBudget [] ==
  .outOfDomain .emptyInput
def pc11_b : Bool := checkSingleGeneratorParse envAtomic sBridgeG11 .G11
def ce11_b : Bool := parseAllBounded strictTestCatalog frozenR22NumericConfig envAtomic defaultParseBudget
  ([0x49, 0x6E, 0x20, 0xC3, 0xA9]) == .outOfDomain (.nonPrintableAsciiByte 0xC3)
def pc12_b : Bool := (evalBridgeVerdict envAtomic (strToAsciiBytes sG01) deltaBridgeG01 validRawCertG01).1
def ce12_b : Bool :=
  let v := evalBridgeVerdict envAtomic (strToAsciiBytes sBadMultiDotG01) badMultiDotDeltaG01 badMultiDotCertG01
  (!v.1) && (v.2 == some (.slotLexicalRejected 3 .multipleDecimalPoints))
def pc13_b : Bool := (evalBridgeVerdict envAtomic (strToAsciiBytes sBridgeG11) deltaBridgeG11 validRawCertG11).1
def ce13_b : Bool :=
  let v := evalBridgeVerdict envAtomic (strToAsciiBytes sBridgeG11) spoofedDeltaG11 spoofedEntityCertG11
  (!v.1) && (v.2 == some (.slotLexicalRejected 3 .entityCatalogMismatch))
def pc14_b : Bool := checkTamperedProjectionDetected
def ce14_b : Bool :=
  let v := evalBridgeVerdict envAtomic (strToAsciiBytes sBridgeG11) [] trapInjectedCert
  (!v.1) && (v.2 == some (.forgedOrTrapRuleCode 1 902))

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc01_ok : pc01_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce01_ok : ce01_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc02_ok : pc02_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce02_ok : ce02_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc03_ok : pc03_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce03_ok : ce03_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc04_ok : pc04_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce04_ok : ce04_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem pc05_ok : pc05_b = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem ce05_ok : ce05_b = true := by decide
set_option maxRecDepth 16384 in theorem pc06_ok : pc06_b = true := by decide
set_option maxRecDepth 16384 in theorem ce06_ok : ce06_b = true := by decide
set_option maxRecDepth 16384 in theorem pc07_ok : pc07_b = true := by decide
set_option maxRecDepth 16384 in theorem ce07_ok : ce07_b = true := by decide
set_option maxRecDepth 16384 in theorem pc08_ok : pc08_b = true := by decide
set_option maxRecDepth 16384 in theorem ce08_ok : ce08_b = true := by decide
set_option maxRecDepth 16384 in theorem pc09_ok : pc09_b = true := by decide
set_option maxRecDepth 16384 in theorem ce09_ok : ce09_b = true := by decide
set_option maxRecDepth 16384 in theorem pc10_ok : pc10_b = true := by decide
set_option maxRecDepth 16384 in theorem ce10_ok : ce10_b = true := by decide
set_option maxRecDepth 16384 in theorem pc11_ok : pc11_b = true := by decide
set_option maxRecDepth 16384 in theorem ce11_ok : ce11_b = true := by decide
set_option maxRecDepth 16384 in theorem pc12_ok : pc12_b = true := by decide
set_option maxRecDepth 16384 in theorem ce12_ok : ce12_b = true := by decide
set_option maxRecDepth 16384 in theorem pc13_ok : pc13_b = true := by decide
set_option maxRecDepth 16384 in theorem ce13_ok : ce13_b = true := by decide
set_option maxRecDepth 16384 in theorem pc14_ok : pc14_b = true := by decide
set_option maxRecDepth 16384 in theorem ce14_ok : ce14_b = true := by decide

def allP3BCases : List P3BTestCase :=
  [ { caseId := "PC-P3B-01", pairGroup := "PAIR-01-G01-PARSE",
      description := "Valid G-01 incidence sentence enumerated uniquely (|T|=1)",
      passed := pc01_b, verdictTag := "ENUMERATED_1(G01:alt1)" },
    { caseId := "CE-P3B-01", pairGroup := "PAIR-01-G01-PARSE",
      description := "G-01 sentence with multi-dot numeric 1..25% yields Enumerated([])",
      passed := ce01_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-02", pairGroup := "PAIR-02-G03-SIDECOND",
      description := "Valid G-03 association sentence enumerated uniquely (|T|=1)",
      passed := pc02_b, verdictTag := "ENUMERATED_1(G03:alt1)" },
    { caseId := "CE-P3B-02", pairGroup := "PAIR-02-G03-SIDECOND",
      description := "G-03 activeExp == refExp side-condition violation yields Enumerated([])",
      passed := ce02_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-03", pairGroup := "PAIR-03-G09-VS-GRAMMAR",
      description := "Valid G-09 non-establishment sentence enumerated uniquely (|T|=1)",
      passed := pc03_b, verdictTag := "ENUMERATED_1(G09:alt1)" },
    { caseId := "CE-P3B-03", pairGroup := "PAIR-03-G09-VS-GRAMMAR",
      description := "In-domain ungrammatical verb 'cured' yields Enumerated([]) (NOT OutOfDomain)",
      passed := ce03_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-04", pairGroup := "PAIR-04-G15-DISCOURSE",
      description := "Valid G-15b discourse-bound two-clause document enumerated uniquely (|T|=1)",
      passed := pc04_b, verdictTag := "ENUMERATED_1(G15:alt1)" },
    { caseId := "CE-P3B-04", pairGroup := "PAIR-04-G15-DISCOURSE",
      description := "G-15b under sentenceAtomic quoteIsolation yields Enumerated([])",
      passed := ce04_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-05", pairGroup := "PAIR-05-G16-CONTRAST",
      description := "Valid G-16 contrastive two-clause document enumerated uniquely (|T|=1)",
      passed := pc05_b, verdictTag := "ENUMERATED_1(G16:alt1)" },
    { caseId := "CE-P3B-05", pairGroup := "PAIR-05-G16-CONTRAST",
      description := "G-16 with mismatched clause-2 outcome yields Enumerated([])",
      passed := ce05_b, verdictTag := "ENUMERATED_0" },
    { caseId := "PC-P3B-06", pairGroup := "PAIR-06-T2-DUAL-READING",
      description := "T2 'did not confirm that' enumerates BOTH distinct readings [alt=1, alt=2] (|T|=2)",
      passed := pc06_b, verdictTag := "ENUMERATED_2(T2:alt1,T2:alt2)" },
    { caseId := "CE-P3B-06", pairGroup := "PAIR-06-T2-DUAL-READING",
      description := "T2 under maxReadings=1 fails closed with ResourceOverflow(maxReadingsExceeded 2 1)",
      passed := ce06_b, verdictTag := "OVERFLOW(maxReadingsExceeded:2>1)" },
    { caseId := "PC-P3B-07", pairGroup := "PAIR-07-T1-AND-MAXBYTES",
      description := "T1 'all ... did not' enumerates BOTH distinct readings [alt=1, alt=2] (|T|=2)",
      passed := pc07_b, verdictTag := "ENUMERATED_2(T1:alt1,T1:alt2)" },
    { caseId := "CE-P3B-07", pairGroup := "PAIR-07-T1-AND-MAXBYTES",
      description := "Valid ASCII input exceeding maxBytes=20 yields ResourceOverflow(maxBytesExceeded)",
      passed := ce07_b, verdictTag := "OVERFLOW(maxBytesExceeded:68>20)" },
    { caseId := "PC-P3B-08", pairGroup := "PAIR-08-T3-AND-MAXSTEPS",
      description := "T3 wh-presupposition trap ('did not determine why') enumerated as trap (|T|=1)",
      passed := pc08_b, verdictTag := "ENUMERATED_1(T3:alt1)" },
    { caseId := "CE-P3B-08", pairGroup := "PAIR-08-T3-AND-MAXSTEPS",
      description := "Tight maxSteps=5 fails closed with ResourceOverflow(maxStepsExceeded 5)",
      passed := ce08_b, verdictTag := "OVERFLOW(maxStepsExceeded:5)" },
    { caseId := "PC-P3B-09", pairGroup := "PAIR-09-T4-AND-MAXNODES",
      description := "T4 bare-plural trap enumerates BOTH distinct readings [alt=1, alt=2] (|T|=2)",
      passed := pc09_b, verdictTag := "ENUMERATED_2(T4:alt1,T4:alt2)" },
    { caseId := "CE-P3B-09", pairGroup := "PAIR-09-T4-AND-MAXNODES",
      description := "Tight maxForestNodes=1 on 2-reading T4 fails closed with ResourceOverflow(maxForestNodesExceeded 1)",
      passed := ce09_b, verdictTag := "OVERFLOW(maxForestNodesExceeded:1)" },
    { caseId := "PC-P3B-10", pairGroup := "PAIR-10-T5-AND-DOMAIN-EMPTY",
      description := "T5 unscoped sentence enumerated as parser-only trap (|T|=1)",
      passed := pc10_b, verdictTag := "ENUMERATED_1(T5:alt1)" },
    { caseId := "CE-P3B-10", pairGroup := "PAIR-10-T5-AND-DOMAIN-EMPTY",
      description := "Empty raw byte sequence yields OutOfDomain(emptyInput)",
      passed := ce10_b, verdictTag := "OUT_OF_DOMAIN(emptyInput)" },
    { caseId := "PC-P3B-11", pairGroup := "PAIR-11-DOMAIN-NONASCII",
      description := "Clean 7-bit ASCII G-11 sentence enumerated uniquely (|T|=1)",
      passed := pc11_b, verdictTag := "ENUMERATED_1(G11:alt1)" },
    { caseId := "CE-P3B-11", pairGroup := "PAIR-11-DOMAIN-NONASCII",
      description := "Non-7-bit-ASCII byte 0xC3 yields OutOfDomain(nonPrintableAsciiByte 0xC3)",
      passed := ce11_b, verdictTag := "OUT_OF_DOMAIN(nonPrintableAsciiByte:195)" },
    { caseId := "PC-P3B-12", pairGroup := "PAIR-12-BRIDGE-MULTIDOT",
      description := "End-to-end BridgeSound gate accepts valid P3-A + P2 G-01 certificate",
      passed := pc12_b, verdictTag := "BRIDGE_ACCEPTED" },
    { caseId := "CE-P3B-12", pairGroup := "PAIR-12-BRIDGE-MULTIDOT",
      description := "End-to-end BridgeSound gate blocks multi-dot 1..25 numeric bypass via P3-A admitLexicalSlot",
      passed := ce12_b, verdictTag := "BRIDGE_REJECTED(slotLexicalRejected:multipleDecimalPoints)" },
    { caseId := "PC-P3B-13", pairGroup := "PAIR-13-BRIDGE-ENTITY-SPOOF",
      description := "End-to-end BridgeSound gate accepts valid P3-A + P2 G-11 certificate",
      passed := pc13_b, verdictTag := "BRIDGE_ACCEPTED" },
    { caseId := "CE-P3B-13", pairGroup := "PAIR-13-BRIDGE-ENTITY-SPOOF",
      description := "End-to-end BridgeSound gate blocks spoofed entityId ('ev_aki' on 'stroke') via P3-A catalog",
      passed := ce13_b, verdictTag := "BRIDGE_REJECTED(slotLexicalRejected:entityCatalogMismatch)" },
    { caseId := "PC-P3B-14", pairGroup := "PAIR-14-PROJECTION-AND-TRAP",
      description := "ProjectionFaithful holds on lowerToP2Cert(x) and rejects span-tampered projection",
      passed := pc14_b, verdictTag := "PROJECTION_FAITHFUL_VERIFIED" },
    { caseId := "CE-P3B-14", pairGroup := "PAIR-14-PROJECTION-AND-TRAP",
      description := "End-to-end BridgeSound gate blocks T2 trap rule code 902 injection",
      passed := ce14_b, verdictTag := "BRIDGE_REJECTED(forgedOrTrapRuleCode:902)" } ]

/-- Kernel-checked theorem (`decide`, ZERO `native_decide`): ALL 28 `(PC, CE)` vectors pass! -/
theorem allP3BCases_verified :
    (allP3BCases.all (·.passed)) = true ∧ allP3BCases.length = 28 := by
  refine ⟨?_, rfl⟩
  simp [allP3BCases, List.all,
        pc01_ok, ce01_ok, pc02_ok, ce02_ok, pc03_ok, ce03_ok, pc04_ok, ce04_ok,
        pc05_ok, ce05_ok, pc06_ok, ce06_ok, pc07_ok, ce07_ok, pc08_ok, ce08_ok,
        pc09_ok, ce09_ok, pc10_ok, ce10_ok, pc11_ok, ce11_ok, pc12_ok, ce12_ok,
        pc13_ok, ce13_ok, pc14_ok, ce14_ok]

end BrocaOmega.P3B.Counterexamples
