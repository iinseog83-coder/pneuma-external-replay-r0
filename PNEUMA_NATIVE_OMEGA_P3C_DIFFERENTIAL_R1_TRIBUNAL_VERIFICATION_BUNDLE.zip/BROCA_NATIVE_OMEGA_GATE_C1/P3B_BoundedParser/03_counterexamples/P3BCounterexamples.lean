/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` & `BridgeSound`)
  03_counterexamples/P3BCounterexamples.lean
-/
import P3BCounterexamples.P3BSuite
