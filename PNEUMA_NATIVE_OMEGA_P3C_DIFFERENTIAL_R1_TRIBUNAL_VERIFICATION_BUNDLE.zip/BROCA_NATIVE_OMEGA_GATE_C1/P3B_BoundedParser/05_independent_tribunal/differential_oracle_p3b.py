#!/usr/bin/env python3
"""
BROCA-NATIVE OMEGA — AUTH-C1-P3-B Independent Clean-Room Differential Oracle
05_independent_tribunal/differential_oracle_p3b.py
Python 3.11 Standard Library Only (zero external packages)

Verifies true 1-to-1 input-by-input equivalence (`Result_Lean(x) == Result_Python(x)`):
  1. Fixed 28-vector `(PC, CE)` suite exported by `p3b_tribunal_runner.exe --export-fixed-json`.
  2. External 250-vector serialized TSV batch evaluated identically by BOTH this clean-room
     Python 3.11 bounded parser & `p3b_tribunal_runner.exe --eval-batch <tsv_path>`, covering:
       - All valid generator sentences (`G-01` ~ `G-16`, including `G-02a/b`, `G-06a/b`, `G-15a/b`, `G-16`)
       - All parser-only trap sentences (`T1` ~ `T5`), verifying `|T| = 2` (`alt1, alt2`) on `T1`, `T2`, `T4`
       - In-domain grammatical, side-condition, and `P3-A` lexical/numeric rejections (`ENUM:0:`)
       - Character-profile `OutOfDomain` boundary cases (`OOD:emptyInput`, `OOD:nonPrintableAsciiByte`)
       - Formal `ResourceBudget` exhaustion sweeps across ALL 4 dimensions (`maxBytes`, `maxSteps`,
         `maxForestNodes`, `maxReadings`) confirming fail-closed `OVF:...` parity!
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Optional, Tuple


# ---------------------------------------------------------------------------
# 1. Clean-Room P3-A Strict Lexical Gate & Reference Catalog
# ---------------------------------------------------------------------------

RESERVED_DELIMITERS: List[str] = [
    ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same",
    "In ", " why ", " how ",
]

OPEN_ENTITY_SORTS = {
    "cohortSpec", "designNoun", "followUpWindow", "eventTerm", "measureTerm",
    "expLevel", "outTerm", "sourceId", "identAssump", "subgroupPlural",
    "subgroupSingular", "covariateList",
}

CLOSED_FUNCTIONAL_ENTRIES: List[Tuple[str, str, str]] = [
    ("assocDir",       "positively", "positively"),
    ("assocDir",       "inversely",  "inversely"),
    ("ratioMetric",    "rr",         "risk ratio"),
    ("ratioMetric",    "or",         "odds ratio"),
    ("ratioMetric",    "hr",         "hazard ratio"),
    ("intervDirVerb",  "increase",   "increase"),
    ("intervDirVerb",  "reduce",     "reduce"),
    ("intervVerbPres", "causes",     "causes"),
    ("intervVerbPres", "increases",  "increases"),
    ("intervVerbPres", "reduces",    "reduces"),
    ("epistemicVerb",  "establish",  "establish"),
    ("epistemicVerb",  "determine",  "determine"),
    ("epistemicVerb",  "confirm",    "confirm"),
    ("epistemicVerb",  "reveal",     "reveal"),
    ("whWord",         "why",        "why"),
    ("whWord",         "how",        "how"),
]

STRICT_TEST_CATALOG: List[Tuple[str, str, str]] = [
    ("cohortSpec",       "coh_primary", "the primary cohort"),
    ("designNoun",       "des_study",   "study"),
    ("followUpWindow",   "win_12m",     "12 months"),
    ("eventTerm",        "ev_stroke",   "stroke"),
    ("eventTerm",        "ev_aki",      "acute kidney injury"),
    ("expLevel",         "exp_intens",  "intensive therapy"),
    ("expLevel",         "exp_std",     "standard care"),
    ("outTerm",          "out_mi",      "myocardial infarction"),
    ("outTerm",          "out_death",   "all-cause mortality"),
    ("sourceId",         "src_trialA",  "Trial-A"),
    ("subgroupPlural",   "sub_dm_pl",   "diabetic"),
    ("subgroupSingular", "sub_hr_sg",   "high-risk"),
]


def is_printable_ascii_str(s: str) -> bool:
    return len(s) > 0 and all(0x20 <= ord(c) <= 0x7E for c in s)


def has_trimmed_spaces(s: str) -> bool:
    return len(s) > 0 and s[0] != " " and s[-1] != " "


def check_valid_catalog(entries: List[Tuple[str, str, str]]) -> bool:
    for srt, eid, lex in entries:
        if srt not in OPEN_ENTITY_SORTS:
            return False
        if not is_printable_ascii_str(eid) or not is_printable_ascii_str(lex):
            return False
        if not has_trimmed_spaces(lex):
            return False
        if any(bad in lex for bad in RESERVED_DELIMITERS):
            return False
    for i, (s1, id1, l1) in enumerate(entries):
        for j, (s2, id2, l2) in enumerate(entries):
            if s1 == s2 and id1 == id2 and l1 != l2:
                return False
            if l1 == l2 and (s1, id1, l1) != (s2, id2, l2):
                return False
    return True


def is_canonical_decimal(s: str, max_int: int = 7, max_frac: int = 4) -> bool:
    if not s or s[0] == "+":
        return False
    neg = False
    body = s
    if s[0] == "-":
        neg = True
        body = s[1:]
    if not body:
        return False
    if any(not (("0" <= c <= "9") or c == ".") for c in body):
        return False
    parts = body.split(".")
    if len(parts) > 2:
        return False
    int_part = parts[0]
    if not int_part:
        return False
    if len(int_part) > 1 and int_part[0] == "0":
        return False
    if len(int_part) > max_int:
        return False
    frac_part = ""
    if len(parts) == 2:
        frac_part = parts[1]
        if not frac_part or len(frac_part) > max_frac:
            return False
    abs_val = int(int_part + frac_part)
    if neg and abs_val == 0:
        return False
    return True


def valid_slot_entity_ids(max_slot_bytes: int, srt: str, lex: str) -> List[str]:
    if not lex or len(lex) > max_slot_bytes:
        return []
    if not is_printable_ascii_str(lex) or not has_trimmed_spaces(lex):
        return []
    if srt in OPEN_ENTITY_SORTS:
        cands = [eid for (es, eid, el) in STRICT_TEST_CATALOG if es == srt and el == lex]
    elif srt == "numericLit":
        cands = [lex]
    else:
        cands = [eid for (es, eid, el) in CLOSED_FUNCTIONAL_ENTRIES if es == srt and el == lex]

    out: List[str] = []
    cat_ok = check_valid_catalog(STRICT_TEST_CATALOG)
    for eid in cands:
        if not is_printable_ascii_str(eid):
            continue
        if srt in OPEN_ENTITY_SORTS:
            if any(bad in lex for bad in RESERVED_DELIMITERS):
                continue
            if cat_ok and (srt, eid, lex) in STRICT_TEST_CATALOG:
                out.append(eid)
        elif srt == "numericLit":
            if eid == lex and is_canonical_decimal(lex, 7, 4):
                out.append(eid)
        else:
            if (srt, eid, lex) in CLOSED_FUNCTIONAL_ENTRIES:
                out.append(eid)
    return out


# ---------------------------------------------------------------------------
# 2. Clean-Room Frozen 34-Production Grammar (`G-01`~`G-16` + `T1`~`T5`)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SymTerm:
    lit: str


@dataclass(frozen=True)
class SymSlot:
    sort: str
    tag: str


@dataclass(frozen=True)
class SymNonterm:
    nt: str
    clause_idx: int


Symbol = SymTerm | SymSlot | SymNonterm


@dataclass(frozen=True)
class ParseSummaryPy:
    cohort_id: Optional[str] = None
    design_id: Optional[str] = None
    exp_out_pair: Optional[Tuple[str, str]] = None
    embedded_key: Optional[str] = None
    starts_in_within: bool = False


@dataclass(frozen=True)
class ScopeEnvPy:
    cohort_id: str
    expected_design_head: str
    quote_isolation: str  # "sentenceAtomic" | "discourseBound"


def lookup_tag(slots: List[Tuple[str, str]], tag: str) -> str:
    for k, v in slots:
        if k == tag:
            return v
    return ""


@dataclass(frozen=True)
class ProdSpecPy:
    name: str
    owner_rule: Optional[str]
    is_generator: bool
    alt_count: int
    lhs: str
    rhs: Tuple[Symbol, ...]
    check_side: Callable[[ScopeEnvPy, List[Tuple[str, str]], List[ParseSummaryPy]], bool]
    mk_sum: Callable[[List[Tuple[str, str]], List[ParseSummaryPy]], ParseSummaryPy]


FROZEN_PRODS: List[ProdSpecPy] = [
    ProdSpecPy(
        "Env_DocSingle", None, True, 1, "controlledDocument",
        (SymNonterm("scopedInitial", 1), SymTerm(".")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_ScopedInitial", None, True, 1, "scopedInitial",
        (SymTerm("In "), SymSlot("cohortSpec", "cohort"), SymTerm(", "), SymNonterm("atomicCore", 0)),
        lambda env, s, _c: lookup_tag(s, "cohort") == env.cohort_id,
        lambda s, c: ParseSummaryPy(
            cohort_id=lookup_tag(s, "cohort"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_ScopedRepeat", None, True, 1, "scopedRepeat",
        (SymTerm("Within this same "), SymSlot("designNoun", "design"), SymTerm(", "), SymNonterm("atomicCore", 0)),
        lambda env, s, _c: lookup_tag(s, "design") == env.expected_design_head,
        lambda s, c: ParseSummaryPy(
            design_id=lookup_tag(s, "design"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_ScopedAssoc", None, True, 1, "scopedAssoc",
        (SymTerm("In "), SymSlot("cohortSpec", "cohort"), SymTerm(", "), SymNonterm("assocCore", 0)),
        lambda env, s, _c: lookup_tag(s, "cohort") == env.cohort_id,
        lambda s, c: ParseSummaryPy(
            cohort_id=lookup_tag(s, "cohort"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_ScopedContrastMeta", None, True, 1, "scopedContrastMeta",
        (SymTerm("within this same "), SymSlot("designNoun", "design"), SymTerm(", "), SymNonterm("metaNonEstabCore", 0)),
        lambda env, s, _c: lookup_tag(s, "design") == env.expected_design_head,
        lambda s, c: ParseSummaryPy(
            design_id=lookup_tag(s, "design"),
            exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None,
            starts_in_within=True,
        ),
    ),
    ProdSpecPy(
        "Env_LiftAssoc", None, True, 1, "atomicCore",
        (SymNonterm("assocCore", 0),),
        lambda _e, _s, _c: True,
        lambda _s, c: c[0] if len(c) == 1 else ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_LiftMeta", None, True, 1, "atomicCore",
        (SymNonterm("metaNonEstabCore", 0),),
        lambda _e, _s, _c: True,
        lambda _s, c: c[0] if len(c) == 1 else ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_EmbeddedCausal", None, True, 1, "embeddedCausal",
        (SymSlot("expLevel", "activeExp"), SymTerm(" "), SymSlot("intervVerbPres", "verb"), SymTerm(" "), SymSlot("outTerm", "outcome")),
        lambda _e, _s, _c: True,
        lambda s, _c: ParseSummaryPy(
            exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome")),
            embedded_key=f"{lookup_tag(s, 'activeExp')}:{lookup_tag(s, 'verb')}:{lookup_tag(s, 'outcome')}",
        ),
    ),
    ProdSpecPy(
        "Gen_G01_DescIncidence", "G01", True, 1, "atomicCore",
        (SymTerm("over "), SymSlot("followUpWindow", "window"), SymTerm(", the cumulative incidence of "),
         SymSlot("eventTerm", "eventA"), SymTerm(" was "), SymSlot("numericLit", "numK"),
         SymTerm(" of "), SymSlot("numericLit", "numN"), SymTerm(" patients ("),
         SymSlot("numericLit", "numPct"), SymTerm("%)")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G02a_DescMeanSD", "G02", True, 1, "atomicCore",
        (SymTerm("the mean "), SymSlot("measureTerm", "measure"), SymTerm(" was "),
         SymSlot("numericLit", "numEst"), SymTerm(" (SD "), SymSlot("numericLit", "numDisp1"), SymTerm(")")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G02b_DescMedianIQR", "G02", True, 1, "atomicCore",
        (SymTerm("the median "), SymSlot("measureTerm", "measure"), SymTerm(" was "),
         SymSlot("numericLit", "numEst"), SymTerm(" (IQR "), SymSlot("numericLit", "numDisp1"),
         SymTerm(" to "), SymSlot("numericLit", "numDisp2"), SymTerm(")")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G03_AssocUnadj", "G03", True, 1, "assocCore",
        (SymTerm("comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("assocDir", "direction"),
         SymTerm(" associated with "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda s, _c: ParseSummaryPy(exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome"))),
    ),
    ProdSpecPy(
        "Gen_G04_AssocTemp", "G04", True, 1, "assocCore",
        (SymSlot("eventTerm", "eventA"), SymTerm(" preceded "), SymSlot("eventTerm", "eventB"),
         SymTerm(", and comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("assocDir", "direction"),
         SymTerm(" associated with "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: (lookup_tag(s, "eventA") != lookup_tag(s, "eventB")) and (lookup_tag(s, "activeExp") != lookup_tag(s, "refExp")),
        lambda s, _c: ParseSummaryPy(exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome"))),
    ),
    ProdSpecPy(
        "Gen_G05_CompRD", "G05", True, 1, "atomicCore",
        (SymTerm("the absolute risk difference in "), SymSlot("outTerm", "outcome"),
         SymTerm(" comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("numericLit", "numEst"),
         SymTerm(" percentage points ("), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G06a_IntervDirectional", "G06", True, 1, "atomicCore",
        (SymTerm("under "), SymSlot("identAssump", "assumption"), SymTerm(", comparing "),
         SymSlot("expLevel", "activeExp"), SymTerm(" versus "), SymSlot("expLevel", "refExp"),
         SymTerm(" was estimated to "), SymSlot("intervDirVerb", "verb"), SymTerm(" "),
         SymSlot("outTerm", "outcome"), SymTerm(" ("), SymSlot("ratioMetric", "metric1"),
         SymTerm(" = "), SymSlot("numericLit", "numEst"), SymTerm(", "),
         SymSlot("numericLit", "numCILevel"), SymTerm("% CI "), SymSlot("numericLit", "numCILow"),
         SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(", p = "),
         SymSlot("numericLit", "numPVal"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G06b_IntervNeutral", "G06", True, 1, "atomicCore",
        (SymTerm("under "), SymSlot("identAssump", "assumption"), SymTerm(", the estimated causal "),
         SymSlot("ratioMetric", "metric1"), SymTerm(" for "), SymSlot("outTerm", "outcome"),
         SymTerm(" comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("numericLit", "numEst"),
         SymTerm(" ("), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"),
         SymTerm("), which did not exclude no effect")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G07_MetaNotStatSig", "G07", True, 1, "atomicCore",
        (SymTerm("the observed "), SymSlot("ratioMetric", "metric1"), SymTerm(" comparing "),
         SymSlot("expLevel", "activeExp"), SymTerm(" versus "), SymSlot("expLevel", "refExp"),
         SymTerm(" for "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric2"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"),
         SymTerm(") was not statistically significant at alpha = "), SymSlot("numericLit", "numAlpha")),
        lambda _e, s, _c: (lookup_tag(s, "metric1") == lookup_tag(s, "metric2")) and (lookup_tag(s, "activeExp") != lookup_tag(s, "refExp")),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G08_MetaEquiv", "G08", True, 1, "atomicCore",
        (SymTerm("comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" met prespecified equivalence margins ("),
         SymSlot("numericLit", "numMarginLow"), SymTerm(" to "), SymSlot("numericLit", "numMarginHigh"),
         SymTerm(") for "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% TOST CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G09_MetaNonEstab", "G09", True, 1, "metaNonEstabCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not establish that "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, c: ParseSummaryPy(exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None),
    ),
    ProdSpecPy(
        "Gen_G10_MetaUnresolved", "G10", True, 1, "atomicCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not determine whether "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G11_QuantZero", "G11", True, 1, "atomicCore",
        (SymTerm("no "), SymSlot("subgroupPlural", "subgroup"),
         SymTerm(" patients developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G12_QuantProperPart", "G12", True, 1, "atomicCore",
        (SymTerm("some, but not all, "), SymSlot("subgroupPlural", "subgroup"),
         SymTerm(" patients developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G13_QuantAtLeastOne", "G13", True, 1, "atomicCore",
        (SymTerm("at least one "), SymSlot("subgroupSingular", "subgroup"),
         SymTerm(" patient developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G14_AssocAdj", "G14", True, 1, "assocCore",
        (SymTerm("after adjustment for "), SymSlot("covariateList", "covariates"),
         SymTerm(", comparing "), SymSlot("expLevel", "activeExp"), SymTerm(" versus "),
         SymSlot("expLevel", "refExp"), SymTerm(" was "), SymSlot("assocDir", "direction"),
         SymTerm(" associated with "), SymSlot("outTerm", "outcome"), SymTerm(" ("),
         SymSlot("ratioMetric", "metric1"), SymTerm(" = "), SymSlot("numericLit", "numEst"),
         SymTerm(", "), SymSlot("numericLit", "numCILevel"), SymTerm("% CI "),
         SymSlot("numericLit", "numCILow"), SymTerm(" to "), SymSlot("numericLit", "numCIHigh"), SymTerm(")")),
        lambda _e, s, _c: lookup_tag(s, "activeExp") != lookup_tag(s, "refExp"),
        lambda s, _c: ParseSummaryPy(exp_out_pair=(lookup_tag(s, "activeExp"), lookup_tag(s, "outcome"))),
    ),
    ProdSpecPy(
        "Gen_G15a_DocConjAtomic", "G15", True, 1, "controlledDocument",
        (SymNonterm("scopedInitial", 1), SymTerm(". "), SymNonterm("scopedInitial", 2), SymTerm(".")),
        lambda env, _s, c: len(c) == 2 and env.quote_isolation == "sentenceAtomic" and c[0].cohort_id == env.cohort_id and c[1].cohort_id == env.cohort_id,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G15b_DocConjDiscourse", "G15", True, 1, "controlledDocument",
        (SymNonterm("scopedInitial", 1), SymTerm(". "), SymNonterm("scopedRepeat", 2), SymTerm(".")),
        lambda env, _s, c: len(c) == 2 and env.quote_isolation == "discourseBound" and c[0].cohort_id == env.cohort_id and c[1].design_id == env.expected_design_head,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Gen_G16_DocContrastive", "G16", True, 1, "controlledDocument",
        (SymNonterm("scopedAssoc", 1), SymTerm("; however, "), SymNonterm("scopedContrastMeta", 2), SymTerm(".")),
        lambda env, _s, c: (
            len(c) == 2
            and c[0].cohort_id == env.cohort_id
            and c[1].design_id == env.expected_design_head
            and c[0].exp_out_pair is not None
            and c[0].exp_out_pair == c[1].exp_out_pair
        ),
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_DocTrapScoped", None, False, 1, "controlledDocument",
        (SymNonterm("scopedTrapClause", 1), SymTerm(".")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Env_ScopedTrap", None, False, 1, "scopedTrapClause",
        (SymTerm("In "), SymSlot("cohortSpec", "cohort"), SymTerm(", "), SymNonterm("trapCore", 0)),
        lambda env, s, _c: lookup_tag(s, "cohort") == env.cohort_id,
        lambda s, _c: ParseSummaryPy(cohort_id=lookup_tag(s, "cohort"), starts_in_within=True),
    ),
    ProdSpecPy(
        "Trap_T1_AllNot", "T1", False, 2, "trapCore",
        (SymTerm("all "), SymSlot("subgroupPlural", "subgroup"),
         SymTerm(" patients did not develop "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Trap_T2_ConfirmThat", "T2", False, 2, "trapCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not confirm that "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, c: ParseSummaryPy(exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None),
    ),
    ProdSpecPy(
        "Trap_T3_WhPresup", "T3", False, 1, "trapCore",
        (SymTerm("the analysis of "), SymSlot("sourceId", "source"),
         SymTerm(" did not "), SymSlot("epistemicVerb", "verb"),
         SymTerm(" "), SymSlot("whWord", "whComp"), SymTerm(" "), SymNonterm("embeddedCausal", 0)),
        lambda _e, _s, _c: True,
        lambda _s, c: ParseSummaryPy(exp_out_pair=c[0].exp_out_pair if len(c) == 1 else None),
    ),
    ProdSpecPy(
        "Trap_T4_BarePlural", "T4", False, 2, "trapCore",
        (SymSlot("subgroupPlural", "subgroup"), SymTerm(" patients developed "), SymSlot("eventTerm", "eventA")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
    ProdSpecPy(
        "Trap_T5_UnscopedDoc", "T5", False, 1, "controlledDocument",
        (SymNonterm("atomicCore", 1), SymTerm(".")),
        lambda _e, _s, _c: True,
        lambda _s, _c: ParseSummaryPy(),
    ),
]

PRODS_BY_NAME = {p.name: p for p in FROZEN_PRODS}


# ---------------------------------------------------------------------------
# 3. Clean-Room Metered Bounded Exhaustive Parser (`parse_all_bounded_py`)
# ---------------------------------------------------------------------------

class OverflowEx(Exception):
    def __init__(self, tag: str) -> None:
        super().__init__(tag)
        self.tag = tag


@dataclass(frozen=True)
class TreeNodePy:
    prod_name: str
    reading_alt: int
    locus: str
    span: Tuple[int, int]
    args: Tuple[object, ...]


def extract_primary_reading_py(t: TreeNodePy) -> str:
    spec = PRODS_BY_NAME[t.prod_name]
    if spec.owner_rule is not None:
        gtag = "gen" if spec.is_generator else "trap"
        return f"{spec.owner_rule}:alt{t.reading_alt}:{gtag}"
    for a in t.args:
        if isinstance(a, TreeNodePy):
            res = extract_primary_reading_py(a)
            if res != "WRAPPER:alt1:gen":
                return res
    return "WRAPPER:alt1:gen"


def candidate_splits_py(y: str, cursor: int, end_pos: int, rest_syms: Tuple[Symbol, ...]) -> List[int]:
    if not rest_syms:
        return [end_pos] if cursor <= end_pos else []
    head = rest_syms[0]
    if isinstance(head, SymTerm):
        lit = head.lit
        n = len(lit)
        if end_pos < cursor:
            return []
        return [
            mid for mid in range(cursor, end_pos + 1)
            if mid + n <= end_pos and y[mid:mid + n] == lit
        ]
    if end_pos < cursor:
        return []
    return list(range(cursor, end_pos + 1))


def parse_all_bounded_py(
    env: ScopeEnvPy,
    max_bytes: int,
    max_steps: int,
    max_forest_nodes: int,
    max_readings: int,
    raw_bytes: bytes,
) -> str:
    if len(raw_bytes) == 0:
        return "OOD:emptyInput"
    for b in raw_bytes:
        if b < 0x20 or b > 0x7E:
            return f"OOD:nonPrintableAsciiByte:{b}"
    if len(raw_bytes) > max_bytes:
        return f"OVF:maxBytesExceeded:{len(raw_bytes)}:{max_bytes}"

    y = raw_bytes.decode("ascii")
    steps_used = 0
    nodes_used = 0

    def tick_step() -> None:
        nonlocal steps_used
        steps_used += 1
        if steps_used > max_steps:
            raise OverflowEx(f"OVF:maxStepsExceeded:{max_steps}")

    def tick_nodes(k: int) -> None:
        nonlocal nodes_used
        nodes_used += k
        if nodes_used > max_forest_nodes:
            raise OverflowEx(f"OVF:maxForestNodesExceeded:{max_forest_nodes}")

    def clause_override(c_idx: int, loc: str) -> str:
        if c_idx == 1:
            return "clause1"
        if c_idx == 2:
            return "clause2"
        return loc

    def enum_segs(
        child_fuel: int, loc: str, cursor: int, syms: Tuple[Symbol, ...], end_pos: int
    ) -> List[Tuple[Tuple[object, ...], List[Tuple[str, str]], List[ParseSummaryPy]]]:
        tick_step()
        if not syms:
            if cursor <= len(y) and end_pos == cursor:
                return [((), [], [])]
            return []
        sym = syms[0]
        rest = syms[1:]
        if isinstance(sym, SymTerm):
            lit = sym.lit
            end_lit = cursor + len(lit)
            if end_lit <= len(y) and y[cursor:end_lit] == lit:
                tails = enum_segs(child_fuel, loc, end_lit, rest, end_pos)
                return [
                    ((("LIT", lit, (cursor, end_lit)),) + r_args, r_slots, r_sums)
                    for (r_args, r_slots, r_sums) in tails
                ]
            return []
        if isinstance(sym, SymSlot):
            if end_pos <= len(y):
                out = []
                for mid in candidate_splits_py(y, cursor, end_pos, rest):
                    if cursor <= mid <= len(y):
                        lex = y[cursor:mid]
                        valid_eids = valid_slot_entity_ids(len(y), sym.sort, lex)
                        if not valid_eids:
                            continue
                        tails = enum_segs(child_fuel, loc, mid, rest, end_pos)
                        for eid in valid_eids:
                            for (r_args, r_slots, r_sums) in tails:
                                out.append((
                                    (("SLOT", sym.sort, sym.tag, eid, lex, (cursor, mid)),) + r_args,
                                    [(sym.tag, eid)] + r_slots,
                                    r_sums,
                                ))
                return out
            return []
        if isinstance(sym, SymNonterm):
            c_loc = clause_override(sym.clause_idx, loc)
            out = []
            for mid in candidate_splits_py(y, cursor, end_pos, rest):
                children = enum_node(child_fuel, c_loc, sym.nt, cursor, mid)
                if not children:
                    continue
                tails = enum_segs(child_fuel, loc, mid, rest, end_pos)
                for (sub_tree, sub_sum) in children:
                    for (r_args, r_slots, r_sums) in tails:
                        out.append((
                            (sub_tree,) + r_args,
                            r_slots,
                            [sub_sum] + r_sums,
                        ))
            return out
        return []

    def enum_node(
        fuel: int, expected_loc: str, expected_nt: str, start_pos: int, end_pos: int
    ) -> List[Tuple[TreeNodePy, ParseSummaryPy]]:
        tick_step()
        if fuel == 0:
            return []
        out: List[Tuple[TreeNodePy, ParseSummaryPy]] = []
        for p in FROZEN_PRODS:
            if p.lhs == expected_nt:
                seg_results = enum_segs(fuel - 1, expected_loc, start_pos, p.rhs, end_pos)
                for (args, slots, sums) in seg_results:
                    if p.check_side(env, slots, sums):
                        out_sum = p.mk_sum(slots, sums)
                        alts = list(range(1, p.alt_count + 1))
                        tick_nodes(len(alts))
                        for alt in alts:
                            out.append((
                                TreeNodePy(p.name, alt, expected_loc, (start_pos, end_pos), args),
                                out_sum,
                            ))
        return out

    try:
        raw_pairs = enum_node(5, "clause1", "controlledDocument", 0, len(y))
    except OverflowEx as ex:
        return ex.tag

    dedup: List[TreeNodePy] = []
    for t, _ in raw_pairs:
        if t not in dedup:
            dedup.append(t)

    if len(dedup) > max_readings:
        return f"OVF:maxReadingsExceeded:{len(dedup)}:{max_readings}"

    sigs = ",".join(extract_primary_reading_py(t) for t in dedup)
    return f"ENUM:{len(dedup)}:{sigs}"


# ---------------------------------------------------------------------------
# 4. External 250-Vector Batch Construction & 1:1 Lean <-> Python Verification
# ---------------------------------------------------------------------------

def build_batch_vectors() -> List[Tuple[str, str, int, int, int, int, bytes]]:
    vecs: List[Tuple[str, str, int, int, int, int, bytes]] = []

    def add(vid: str, mode: str, mb: int, ms: int, mn: int, mr: int, raw: bytes) -> None:
        vecs.append((vid, mode, mb, ms, mn, mr, raw))

    def add_str(vid: str, mode: str, s: str, mb: int = 512, ms: int = 4000, mn: int = 512, mr: int = 16) -> None:
        add(vid, mode, mb, ms, mn, mr, s.encode("ascii"))

    # (1) Valid Generator Core & Multi-Clause Sentences (20 vectors)
    valid_sentences = [
        ("GEN-G01-A", "atomic", "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%)."),
        ("GEN-G01-B", "atomic", "In the primary cohort, over 12 months, the cumulative incidence of acute kidney injury was 0 of 120 patients (0%)."),
        ("GEN-G03-HR", "atomic", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("GEN-G03-RR", "atomic", "In the primary cohort, comparing intensive therapy versus standard care was positively associated with all-cause mortality (risk ratio = 1.18, 95% CI 1.02 to 1.37)."),
        ("GEN-G03-OR", "atomic", "In the primary cohort, comparing standard care versus intensive therapy was positively associated with myocardial infarction (odds ratio = 1.33, 95% CI 1.08 to 1.64)."),
        ("GEN-G04-A", "atomic", "In the primary cohort, stroke preceded acute kidney injury, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("GEN-G05-A", "atomic", "In the primary cohort, the absolute risk difference in myocardial infarction comparing intensive therapy versus standard care was -2.4 percentage points (95% CI -4.1 to -0.7)."),
        ("GEN-G07-A", "atomic", "In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (hazard ratio = 0.91, 95% CI 0.78 to 1.06) was not statistically significant at alpha = 0.05."),
        ("GEN-G08-A", "atomic", "In the primary cohort, comparing intensive therapy versus standard care met prespecified equivalence margins (-1.5 to 1.5) for myocardial infarction (risk ratio = 1.01, 90% TOST CI 0.94 to 1.08)."),
        ("GEN-G09-A", "atomic", "In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
        ("GEN-G09-B", "atomic", "In the primary cohort, the analysis of Trial-A did not establish that standard care increases all-cause mortality."),
        ("GEN-G10-A", "atomic", "In the primary cohort, the analysis of Trial-A did not determine whether intensive therapy causes myocardial infarction."),
        ("GEN-G11-A", "atomic", "In the primary cohort, no diabetic patients developed stroke."),
        ("GEN-G12-A", "atomic", "In the primary cohort, some, but not all, diabetic patients developed stroke."),
        ("GEN-G13-A", "atomic", "In the primary cohort, at least one high-risk patient developed acute kidney injury."),
        ("GEN-G15A-1", "atomic", "In the primary cohort, no diabetic patients developed stroke. In the primary cohort, at least one high-risk patient developed acute kidney injury."),
        ("GEN-G15B-1", "discourse", "In the primary cohort, no diabetic patients developed stroke. Within this same study, at least one high-risk patient developed acute kidney injury."),
        ("GEN-G15B-2", "discourse", "In the primary cohort, some, but not all, diabetic patients developed stroke. Within this same study, no diabetic patients developed acute kidney injury."),
        ("GEN-G16-1", "discourse", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
        ("GEN-G16-2", "discourse", "In the primary cohort, comparing standard care versus intensive therapy was positively associated with all-cause mortality (risk ratio = 1.25, 95% CI 1.04 to 1.51); however, within this same study, the analysis of Trial-A did not establish that standard care increases all-cause mortality."),
    ]
    for vid, mode, s in valid_sentences:
        add_str(vid, mode, s)

    # (2) Trap Sentences & Dual-Reading Non-Collapse Checks (`T1`~`T5`: 15 vectors)
    trap_sentences = [
        ("TRAP-T1-A", "atomic", "In the primary cohort, all diabetic patients did not develop stroke."),
        ("TRAP-T1-B", "atomic", "In the primary cohort, all diabetic patients did not develop acute kidney injury."),
        ("TRAP-T2-A", "atomic", "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction."),
        ("TRAP-T2-B", "atomic", "In the primary cohort, the analysis of Trial-A did not confirm that standard care causes all-cause mortality."),
        ("TRAP-T2-C", "atomic", "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy increases all-cause mortality."),
        ("TRAP-T3-WHY-EST", "atomic", "In the primary cohort, the analysis of Trial-A did not establish why intensive therapy reduces myocardial infarction."),
        ("TRAP-T3-WHY-DET", "atomic", "In the primary cohort, the analysis of Trial-A did not determine why intensive therapy reduces myocardial infarction."),
        ("TRAP-T3-HOW-CONF", "atomic", "In the primary cohort, the analysis of Trial-A did not confirm how intensive therapy reduces myocardial infarction."),
        ("TRAP-T3-HOW-REV", "atomic", "In the primary cohort, the analysis of Trial-A did not reveal how standard care increases all-cause mortality."),
        ("TRAP-T4-A", "atomic", "In the primary cohort, diabetic patients developed stroke."),
        ("TRAP-T4-B", "atomic", "In the primary cohort, diabetic patients developed acute kidney injury."),
        ("TRAP-T5-G11", "atomic", "no diabetic patients developed stroke."),
        ("TRAP-T5-G12", "atomic", "some, but not all, diabetic patients developed stroke."),
        ("TRAP-T5-G13", "atomic", "at least one high-risk patient developed acute kidney injury."),
        ("TRAP-T5-G09", "atomic", "the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
    ]
    for vid, mode, s in trap_sentences:
        add_str(vid, mode, s)

    # (3) Adversarial Malformed Numerics Embedded in Full Sentences (`P3-A` Strict Gate: 45 vectors)
    bad_nums = [
        "1..25", "1.2.3", "0..5", "1.", "42.", ".25", ".05", "+1.25", "+42",
        "-0", "-0.0", "-0.00", "-0.0000", "00", "01", "001.25", "-01.5",
        "1e-3", "1E4", "2.5e2", "12345678", "1.12345", "-12345678", "1,000",
        "NaN", "Inf", "-Inf", "1.2.3.4", "..", "-", "8.4 ", " 8.4", "1_000",
        "0x10", "1/2", "8.40001", "99999999", "00.5", "-.5", "5.", "+0",
        "1..0", "0.1.2", "3.14159", "10000000",
    ]
    for idx, bn in enumerate(bad_nums):
        s = f"In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients ({bn}%)."
        add_str(f"BADNUM-{idx+1:02d}", "atomic", s)

    # (4) Adversarial Side-Condition, Catalog, Terminal & Structural Mutations (60 vectors)
    structural_mutations = [
        # Side-condition failures
        ("SC-G03-SAME-EXP", "atomic", "In the primary cohort, comparing intensive therapy versus intensive therapy was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("SC-G04-SAME-EVT", "atomic", "In the primary cohort, stroke preceded stroke, and comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("SC-G04-SAME-EXP", "atomic", "In the primary cohort, stroke preceded acute kidney injury, and comparing standard care versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92)."),
        ("SC-G05-SAME-EXP", "atomic", "In the primary cohort, the absolute risk difference in myocardial infarction comparing standard care versus standard care was 0 percentage points (95% CI -1.0 to 1.0)."),
        ("SC-G07-METRIC-MISMATCH", "atomic", "In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (risk ratio = 0.91, 95% CI 0.78 to 1.06) was not statistically significant at alpha = 0.05."),
        ("SC-G08-SAME-EXP", "atomic", "In the primary cohort, comparing intensive therapy versus intensive therapy met prespecified equivalence margins (-1.5 to 1.5) for myocardial infarction (risk ratio = 1.01, 90% TOST CI 0.94 to 1.08)."),
        ("SC-G15A-WRONG-MODE", "discourse", "In the primary cohort, no diabetic patients developed stroke. In the primary cohort, at least one high-risk patient developed acute kidney injury."),
        ("SC-G15B-WRONG-MODE", "atomic", "In the primary cohort, no diabetic patients developed stroke. Within this same study, at least one high-risk patient developed acute kidney injury."),
        ("SC-G16-OUT-MISMATCH", "discourse", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality."),
        ("SC-G16-EXP-MISMATCH", "discourse", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that standard care reduces myocardial infarction."),
        # Unknown entities / wrong sort swaps / missing punctuation / recursive G-15 attempts
        ("LEX-UNKNOWN-COHORT", "atomic", "In the secondary cohort, no diabetic patients developed stroke."),
        ("LEX-UNKNOWN-DESIGN", "discourse", "In the primary cohort, no diabetic patients developed stroke. Within this same trial, no diabetic patients developed stroke."),
        ("LEX-SORT-SWAP-1", "atomic", "In the primary cohort, no high-risk patients developed stroke."),
        ("LEX-SORT-SWAP-2", "atomic", "In the primary cohort, at least one diabetic patient developed stroke."),
        ("LEX-SORT-SWAP-3", "atomic", "In the primary cohort, no diabetic patients developed myocardial infarction."),
        ("LEX-SORT-SWAP-4", "atomic", "In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces stroke."),
        ("SYN-NO-PERIOD", "atomic", "In the primary cohort, no diabetic patients developed stroke"),
        ("SYN-DOUBLE-PERIOD", "atomic", "In the primary cohort, no diabetic patients developed stroke.."),
        ("SYN-TRIPLE-CLAUSE-G15", "atomic", "In the primary cohort, no diabetic patients developed stroke. In the primary cohort, no diabetic patients developed stroke. In the primary cohort, no diabetic patients developed stroke."),
        ("SYN-NESTED-G16", "discourse", "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction; however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction."),
    ]
    for vid, mode, s in structural_mutations:
        add_str(vid, mode, s)

    # Generate 40 additional systematic terminal/keyword perturbations
    base_g11 = "In the primary cohort, no diabetic patients developed stroke."
    for i in range(40):
        pos = (i * 3) % len(base_g11)
        mutated = base_g11[:pos] + "X" + base_g11[pos:]
        add_str(f"PERTURB-G11-{i+1:02d}", "atomic", mutated)

    # (5) OutOfDomain Raw Byte Vectors (30 vectors: empty, control chars, tabs/newlines, UTF-8 multibyte, 0x7F..0xFF)
    add("OOD-EMPTY", "atomic", 512, 4000, 512, 16, b"")
    bad_byte_vals = [
        0x00, 0x01, 0x07, 0x08, 0x09, 0x0A, 0x0D, 0x1B, 0x1F, 0x7F,
        0x80, 0x81, 0x9F, 0xA0, 0xB5, 0xC0, 0xC2, 0xC3, 0xCE, 0xD0,
        0xE0, 0xE2, 0xED, 0xF0, 0xF4, 0xF8, 0xFC, 0xFE, 0xFF,
    ]
    for idx, bval in enumerate(bad_byte_vals):
        payload = b"In the primary cohort, " + bytes([bval]) + b" stroke."
        add(f"OOD-BYTE-{idx+1:02d}", "atomic", 512, 4000, 512, 16, payload)

    # (6) ResourceBudget Exhaustion Sweeps Across ALL 4 Dimensions (80 vectors!)
    s_t2 = "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction.".encode("ascii")
    s_t1 = "In the primary cohort, all diabetic patients did not develop stroke.".encode("ascii")
    s_t4 = "In the primary cohort, diabetic patients developed stroke.".encode("ascii")
    s_g01 = "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%).".encode("ascii")

    # 6a. maxBytes sweep (20 vectors)
    for idx, mb in enumerate([0, 1, 10, 20, 40, 57, 58, 67, 68, 103, 104, 112, 113, 200]):
        target = s_t4 if idx % 3 == 0 else (s_t1 if idx % 3 == 1 else s_g01)
        add(f"BUDGET-BYTES-{idx+1:02d}", "atomic", mb, 4000, 512, 16, target)
    for idx in range(6):
        add(f"BUDGET-BYTES-EXTRA-{idx+1:02d}", "atomic", 50 + idx * 10, 4000, 512, 16, s_t2)

    # 6b. maxSteps sweep (25 vectors from 0 up to 500!)
    for idx, ms in enumerate([0, 1, 2, 3, 5, 8, 12, 15, 20, 25, 30, 40, 50, 60, 75, 90, 110, 130, 160, 200, 250, 300, 400, 600, 1000]):
        target = s_t2 if idx % 2 == 0 else s_g01
        add(f"BUDGET-STEPS-{idx+1:02d}", "atomic", 512, ms, 512, 16, target)

    # 6c. maxForestNodes sweep (20 vectors: 0..10 on G-11, T2, T4, G-16)
    for idx, mn in enumerate([0, 1, 2, 3, 4, 5, 6, 7, 8, 10]):
        add(f"BUDGET-NODES-T2-{idx+1:02d}", "atomic", 512, 4000, mn, 16, s_t2)
        add(f"BUDGET-NODES-G01-{idx+1:02d}", "atomic", 512, 4000, mn, 16, s_g01)

    # 6d. maxReadings sweep (15 vectors: 0, 1, 2, 3 on 0-reading, 1-reading, and 2-reading inputs!)
    s_invalid = b"In the primary cohort, intensive therapy cured myocardial infarction."
    for mr in [0, 1, 2, 3, 5]:
        add(f"BUDGET-READ-T2-{mr}", "atomic", 512, 4000, 512, mr, s_t2)
        add(f"BUDGET-READ-G01-{mr}", "atomic", 512, 4000, 512, mr, s_g01)
        add(f"BUDGET-READ-INV-{mr}", "atomic", 512, 4000, 512, mr, s_invalid)

    assert len(vecs) == 250, f"Expected 250 batch vectors, got {len(vecs)}"
    return vecs


def main() -> int:
    pkg_root = Path(__file__).resolve().parent.parent
    exe_path = pkg_root / ".lake" / "build" / "bin" / "p3b_tribunal_runner.exe"
    if not exe_path.exists():
        exe_alt = pkg_root / ".lake" / "build" / "bin" / "p3b_tribunal_runner"
        if exe_alt.exists():
            exe_path = exe_alt
        else:
            print(f"[FATAL] Lean executable not found at {exe_path}", file=sys.stderr)
            return 1

    # 1. Verify Fixed 28-Vector `(PC, CE)` Suite via `--export-fixed-json`
    proc_fixed = subprocess.run(
        [str(exe_path), "--export-fixed-json"],
        capture_output=True,
        text=True,
        check=True,
    )
    fixed_cases = json.loads(proc_fixed.stdout)
    if len(fixed_cases) != 28:
        print(f"[FAIL] Expected 28 fixed cases, got {len(fixed_cases)}", file=sys.stderr)
        return 1
    fixed_passed = sum(1 for c in fixed_cases if c["passed"] is True)
    if fixed_passed != 28:
        print(f"[FAIL] Fixed Lean suite passed {fixed_passed}/28", file=sys.stderr)
        return 1

    # Cross-check key fixed cases independently in Python
    env_atomic = ScopeEnvPy("coh_primary", "des_study", "sentenceAtomic")
    py_t2_default = parse_all_bounded_py(
        env_atomic, 512, 4000, 512, 16,
        b"In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction.",
    )
    assert py_t2_default == "ENUM:2:T2:alt1:trap,T2:alt2:trap", f"Unexpected T2 Python result: {py_t2_default}"

    py_t2_mr1 = parse_all_bounded_py(
        env_atomic, 512, 4000, 512, 1,
        b"In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction.",
    )
    assert py_t2_mr1 == "OVF:maxReadingsExceeded:2:1", f"Unexpected T2 mr=1 result: {py_t2_mr1}"

    # 2. True 1-to-1 External Serialized Batch Differential Verification (`250` vectors)
    batch_vecs = build_batch_vectors()
    env_discourse = ScopeEnvPy("coh_primary", "des_study", "discourseBound")

    py_outcomes = {}
    tsv_lines: List[str] = []
    for vid, mode, mb, ms, mn, mr, raw in batch_vecs:
        env_obj = env_discourse if mode == "discourse" else env_atomic
        py_outcomes[vid] = parse_all_bounded_py(env_obj, mb, ms, mn, mr, raw)
        tsv_lines.append(f"{vid}\t{mode}\t{mb}\t{ms}\t{mn}\t{mr}\t{raw.hex()}")

    with tempfile.NamedTemporaryFile("w", suffix=".tsv", delete=False, encoding="utf-8", newline="\n") as tf:
        tf.write("\n".join(tsv_lines) + "\n")
        tsv_path = Path(tf.name)

    try:
        proc_batch = subprocess.run(
            [str(exe_path), "--eval-batch", str(tsv_path)],
            capture_output=True,
            text=True,
            check=True,
        )
    finally:
        tsv_path.unlink(missing_ok=True)

    lean_lines = [ln.strip() for ln in proc_batch.stdout.splitlines() if ln.strip()]
    if len(lean_lines) != len(batch_vecs):
        print(f"[FAIL] Batch line count mismatch: Lean={len(lean_lines)}, Python={len(batch_vecs)}", file=sys.stderr)
        return 1

    mismatches: List[str] = []
    enum_pos_cnt = 0
    enum_zero_cnt = 0
    ood_cnt = 0
    ovf_cnt = 0

    for ln in lean_lines:
        vid, lean_res = ln.split("\t", 1)
        py_res = py_outcomes[vid]
        if lean_res != py_res:
            mismatches.append(f"  {vid}: Lean='{lean_res}' != Python='{py_res}'")
        if lean_res.startswith("ENUM:0:"):
            enum_zero_cnt += 1
        elif lean_res.startswith("ENUM:"):
            enum_pos_cnt += 1
        elif lean_res.startswith("OOD:"):
            ood_cnt += 1
        elif lean_res.startswith("OVF:"):
            ovf_cnt += 1

    print("==========================================================================")
    print("BROCA-NATIVE OMEGA — P3-B PYTHON 3.11 1:1 DIFFERENTIAL ORACLE REPORT")
    print("==========================================================================")
    print(f"Fixed Curated (PC, CE) Suite Parity : {fixed_passed}/28 PASSED")
    print(f"External Serialized Batch Vectors   : {len(batch_vecs) - len(mismatches)}/{len(batch_vecs)} EXACT 1:1 PARITY")
    print(f"  - Valid Enumerated Parses (|T|>=1): {enum_pos_cnt}")
    print(f"  - In-Domain Invalid (ENUM:0:)     : {enum_zero_cnt}")
    print(f"  - OutOfDomain Rejections (OOD:)   : {ood_cnt}")
    print(f"  - ResourceOverflow Fail-Closed    : {ovf_cnt}")
    print("==========================================================================")

    if mismatches:
        print("[FAIL] Differential Mismatches Detected:", file=sys.stderr)
        for m in mismatches[:20]:
            print(m, file=sys.stderr)
        return 1

    print("DIFFERENTIAL ORACLE VERDICT: 100% EXACT 1:1 PARITY (0 MISMATCHES)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
