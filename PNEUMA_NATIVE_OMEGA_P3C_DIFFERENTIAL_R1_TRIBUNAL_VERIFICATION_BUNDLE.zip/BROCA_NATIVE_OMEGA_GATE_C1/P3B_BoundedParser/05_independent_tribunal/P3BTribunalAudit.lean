/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` & `BridgeSound` Independent Tribunal Runner)
  05_independent_tribunal/P3BTribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  1. Emits compile-time `#print axioms` audit across all 20 exported `P3-B` proof obligations.
  2. Provides executable CLI (`p3b_tribunal_runner`) supporting:
       - Default human-readable verification table of all 28 curated `(PC, CE)` vectors
       - `--export-fixed-json`: JSON export of the 28 curated vectors
       - `--eval-batch <tsv_path>`: True 1-to-1 serialized batch evaluation of `parseAllBounded`
         for differential parity verification against the clean-room Python 3.11 oracle.
-/
import P3BProofObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open BrocaOmega.P3B.Counterexamples
open BrocaOmega.P3B.ProofObligations

/-! ### 1. Compile-Time Axiom Footprint Audit (`#print axioms` — Zero `sorryAx`, Zero `ofReduceBool`) -/

#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_InterleavedGrammarEq
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_MatchesP3AFrozenBNF
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalSideCondEq
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalIntrinsicOblsEq
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_F_P3A_01_UniversalSummaryEq
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_FrozenParseGrammarAcyclic
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserTerminates
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_OutOfDomainBoundarySound
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserSoundness
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_BoundedParserExhaustiveCompleteness
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_EnumeratedEmptySound
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_ResourceOverflowFailClosed
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_NonVacuous_G01_Witness
#print axioms BrocaOmega.P3B.ProofObligations.PO_C1_01_NonVacuous_T2_DualReadings
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_LowerToP2Cert_ProjectionFaithful
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_ProjectionFaithful_CheckerIff
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_BridgeSound
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_BridgeSound_MemEnumeratedForest
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_VerifyBridgedDerivation_Sound
#print axioms BrocaOmega.P3B.ProofObligations.PO_P3B_All28CounterexampleVectors_Verified

/-! ### 2. Canonical Formatting & Hex-TSV Batch Evaluator for 1:1 Differential Parity -/

private def ruleIdToStr : CanonicalRuleId → String
  | .G01 => "G01" | .G02 => "G02" | .G03 => "G03" | .G04 => "G04"
  | .G05 => "G05" | .G06 => "G06" | .G07 => "G07" | .G08 => "G08"
  | .G09 => "G09" | .G10 => "G10" | .G11 => "G11" | .G12 => "G12"
  | .G13 => "G13" | .G14 => "G14" | .G15 => "G15" | .G16 => "G16"
  | .T1  => "T1"  | .T2  => "T2"  | .T3  => "T3"  | .T4  => "T4" | .T5 => "T5"

private def formatTreeSig (t : ConcreteParseTree) : String :=
  match extractPrimaryReading t with
  | some (r, alt, isGen) =>
    let gTag := if isGen then "gen" else "trap"
    s!"{ruleIdToStr r}:alt{alt}:{gTag}"
  | none => "WRAPPER:alt1:gen"

private def joinComma : List String → String
  | [] => ""
  | [x] => x
  | x :: xs => x ++ "," ++ joinComma xs

private def formatParseResult (res : BoundedParseResult) : String :=
  match res with
  | .outOfDomain .emptyInput =>
    "OOD:emptyInput"
  | .outOfDomain (.nonPrintableAsciiByte b) =>
    s!"OOD:nonPrintableAsciiByte:{b.toNat}"
  | .resourceOverflow (.maxBytesExceeded act mx) =>
    s!"OVF:maxBytesExceeded:{act}:{mx}"
  | .resourceOverflow (.maxStepsExceeded mx) =>
    s!"OVF:maxStepsExceeded:{mx}"
  | .resourceOverflow (.maxForestNodesExceeded mx) =>
    s!"OVF:maxForestNodesExceeded:{mx}"
  | .resourceOverflow (.maxReadingsExceeded act mx) =>
    s!"OVF:maxReadingsExceeded:{act}:{mx}"
  | .enumerated ts =>
    let sigs := joinComma (ts.map formatTreeSig)
    s!"ENUM:{ts.length}:{sigs}"

private def hexDigitVal (c : Char) : Option Nat :=
  if ('0' ≤ c) && (c ≤ '9') then some (c.toNat - '0'.toNat)
  else if ('a' ≤ c) && (c ≤ 'f') then some (10 + (c.toNat - 'a'.toNat))
  else if ('A' ≤ c) && (c ≤ 'F') then some (10 + (c.toNat - 'A'.toNat))
  else none

private def decodeHexChars : List Char → Option (List UInt8)
  | [] => some []
  | c1 :: c2 :: rest =>
    match hexDigitVal c1, hexDigitVal c2, decodeHexChars rest with
    | some v1, some v2, some tail => some (UInt8.ofNat (v1 * 16 + v2) :: tail)
    | _, _, _ => none
  | [_] => none

private def stripCR (s : String) : String :=
  String.ofList (s.toList.filter (fun c => c != '\r'))

private def parseNatSimple (s : String) : Nat :=
  s.toNat?.getD 0

private def evalBatchLine (line : String) : Option String :=
  let clean := stripCR line
  if clean.isEmpty then none
  else
    match clean.splitOn "\t" with
    | [vecId, modeStr, maxBStr, maxSStr, maxNStr, maxRStr, hexPayload] =>
      let env := if modeStr == "discourse" then envDiscourse else envAtomic
      let budget : ResourceBudget :=
        { maxBytes       := parseNatSimple maxBStr
          maxSteps       := parseNatSimple maxSStr
          maxForestNodes := parseNatSimple maxNStr
          maxReadings    := parseNatSimple maxRStr }
      match decodeHexChars hexPayload.toList with
      | none => some s!"{vecId}\tERR:INVALID_HEX"
      | some rawBytes =>
        let res := parseAllBounded strictTestCatalog frozenR22NumericConfig env budget rawBytes
        some s!"{vecId}\t{formatParseResult res}"
    | _ => some "ERR:MALFORMED_LINE"

private def exportFixedJson : String :=
  let items := allP3BCases.map fun c =>
    s!"  \{\"caseId\": \"{c.caseId}\", \"pairGroup\": \"{c.pairGroup}\", \"passed\": {c.passed}, \"verdictTag\": \"{c.verdictTag}\"}"
  "[\n" ++ String.intercalate ",\n" items ++ "\n]"

def main (args : List String) : IO UInt32 := do
  match args with
  | ["--export-fixed-json"] =>
    IO.println exportFixedJson
    return 0
  | ["--eval-batch", path] =>
    let content ← IO.FS.readFile path
    for line in content.splitOn "\n" do
      match evalBatchLine line with
      | some out => IO.println out
      | none     => pure ()
    return 0
  | _ =>
    IO.println "=========================================================================="
    IO.println "BROCA-NATIVE OMEGA — AUTH-C1-P3-B BOUNDED PARSER & BRIDGE VERIFICATION"
    IO.println "Scope     : PO-C1-01 Bounded Exhaustive Parser + BridgeSound + F-P3A-01"
    IO.println "Toolchain : Lean 4.33.1 Core (Init + Frozen P2/P3-A, 0 sorry, 0 ofReduceBool)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for c in allP3BCases do
      let status := if c.passed then "PASS" else "FAIL"
      if c.passed then passCount := passCount + 1
      IO.println s!"[{status}] {c.caseId} ({c.pairGroup}) => {c.verdictTag}"
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"TOTAL CURATED VECTORS : {passCount}/{allP3BCases.length} PASSED"
    if passCount == allP3BCases.length then
      return 0
    else
      return 1
