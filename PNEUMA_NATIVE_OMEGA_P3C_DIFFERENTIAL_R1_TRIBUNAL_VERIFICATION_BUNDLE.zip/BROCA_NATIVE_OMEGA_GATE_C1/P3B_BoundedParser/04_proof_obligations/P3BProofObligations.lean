/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` & `BridgeSound`)
  04_proof_obligations/P3BProofObligations.lean
-/
import P3BProofObligations.PO_C1_01_And_Bridge
