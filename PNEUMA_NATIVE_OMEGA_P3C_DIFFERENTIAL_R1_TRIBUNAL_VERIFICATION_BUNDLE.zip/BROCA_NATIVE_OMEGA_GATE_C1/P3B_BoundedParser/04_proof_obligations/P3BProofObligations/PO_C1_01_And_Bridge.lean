/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` Bounded Parser & `BridgeSound` Proof Obligations)
  04_proof_obligations/P3BProofObligations/PO_C1_01_And_Bridge.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  Exports the canonical machine-checked proof obligations across `Gate A` ~ `Gate F`:
    - Gate A (`F-P3A-01`):
        1. `PO_P3B_F_P3A_01_InterleavedGrammarEq`
        2. `PO_P3B_F_P3A_01_MatchesP3AFrozenBNF`
        3. `PO_P3B_F_P3A_01_UniversalSideCondEq`
        4. `PO_P3B_F_P3A_01_UniversalIntrinsicOblsEq`
        5. `PO_P3B_F_P3A_01_UniversalSummaryEq`
        6. `PO_P3B_FrozenParseGrammarAcyclic`
    - Gate B & Gate C (`PO-C1-01`):
        7. `PO_C1_01_BoundedParserTerminates`
        8. `PO_C1_01_OutOfDomainBoundarySound`
        9. `PO_C1_01_BoundedParserSoundness`
       10. `PO_C1_01_BoundedParserExhaustiveCompleteness`
       11. `PO_C1_01_EnumeratedEmptySound`
       12. `PO_C1_01_ResourceOverflowFailClosed`
       13. `PO_C1_01_NonVacuous_G01_Witness`
       14. `PO_C1_01_NonVacuous_T2_DualReadings`
    - Gate D (`BridgeSound` + `ProjectionFaithful` on Actual Frozen `P3-A` & `P2`):
       15. `PO_P3B_LowerToP2Cert_ProjectionFaithful`
       16. `PO_P3B_ProjectionFaithful_CheckerIff`
       17. `PO_P3B_BridgeSound`
       18. `PO_P3B_BridgeSound_MemEnumeratedForest`
       19. `PO_P3B_VerifyBridgedDerivation_Sound`
    - Gate E (`28` Kernel-Proved `(PC, CE)` Vectors):
       20. `PO_P3B_All28CounterexampleVectors_Verified`
    - Gate F (Explicit Residual `HELD` & `NOT_AUTHORIZED` Governance Locks)
-/
import P3BCounterexamples

namespace BrocaOmega.P3B.ProofObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open BrocaOmega.P3B.Counterexamples

/-! ### 1. Gate A — `F-P3A-01` Full Grammar, Side-Condition & Obligation Correspondence -/

theorem PO_P3B_F_P3A_01_InterleavedGrammarEq (r : FrozenGenRule) :
    fromP2Nonterm (ruleSignature r).lhsCat = (frozenProdSig (fromP2Rule r)).lhs ∧
    ((ruleSignature r).segments.map fromP2RuleSegment) = (frozenProdSig (fromP2Rule r)).rhs :=
  f_p3a_01_p2_ruleSignature_matches_p3b_interleaved r

theorem PO_P3B_F_P3A_01_MatchesP3AFrozenBNF :
    (allFrozenParseProds.map fun p =>
      let sig := frozenProdSig p
      (sig.ownerRule, sig.isGenerator, sig.lhs, sig.rhs)) =
    (independentFrozenBNF.map fun b =>
      (b.canonicalOwner, b.isGenerator, b.lhs, b.rhs)) :=
  f_p3a_01_p3b_matches_p3a_independentFrozenBNF

theorem PO_P3B_F_P3A_01_UniversalSideCondEq
    (r : FrozenGenRule) (env : ScopeEnv)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).checkSide env (mapP2Slots slots) (sums.map mapP2Summary) =
    (ruleSignature r).checkSideCond env slots sums :=
  f_p3a_01_universal_sidecond_equivalence r env slots sums

theorem PO_P3B_F_P3A_01_UniversalIntrinsicOblsEq
    (r : FrozenGenRule) (loc : ClauseLocus)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).intrinsicObls loc (mapP2Slots slots) (sums.map mapP2Summary) =
    (ruleSignature r).intrinsicObls loc slots sums :=
  f_p3a_01_universal_intrinsicObls_equivalence r loc slots sums

theorem PO_P3B_F_P3A_01_UniversalSummaryEq
    (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).mkSum (mapP2Slots slots) (sums.map mapP2Summary) =
    mapP2Summary ((ruleSignature r).mkSummary slots sums) :=
  fromP2Rule_mkSum_eq_mapP2Summary r slots sums

theorem PO_P3B_FrozenParseGrammarAcyclic
    (p : FrozenParseProd) (nt : BNFNonterm) (cIdx : Nat)
    (hmem : BNFSymbol.nonterm nt cIdx ∈ (frozenProdSig p).rhs) :
    nt.level < (frozenProdSig p).lhs.level :=
  frozenProdSig_child_level_lt p nt cIdx hmem

/-! ### 2. Gate B & Gate C — `PO-C1-01` Bounded Exhaustive Parser Soundness & Completeness -/

theorem PO_C1_01_BoundedParserTerminates
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) :
    ∃ res : BoundedParseResult, parseAllBounded cat numCfg env budget rawBytes = res :=
  parseAllBounded_terminates cat numCfg env budget rawBytes

theorem PO_C1_01_OutOfDomainBoundarySound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (d : OutOfDomainDiag)
    (hood : parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d) :
    ¬ StrictAsciiDomainSupported rawBytes :=
  parseAllBounded_outOfDomain_sound cat numCfg env budget rawBytes d hood

theorem PO_C1_01_BoundedParserSoundness
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree)
    (henum : parseAllBounded cat numCfg env budget rawBytes = .enumerated T) :
    ∀ τ ∈ T, ValidParse_GFrozen cat numCfg env rawBytes τ :=
  parseAllBounded_sound cat numCfg env budget rawBytes T henum

theorem PO_C1_01_BoundedParserExhaustiveCompleteness
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree)
    (henum : parseAllBounded cat numCfg env budget rawBytes = .enumerated T) :
    StrictAsciiDomainSupported rawBytes ∧
    rawBytes.length ≤ budget.maxBytes ∧
    T.length ≤ budget.maxReadings ∧
    NoDupTrees T ∧
    (∀ τ : ConcreteParseTree, τ ∈ T ↔ ValidParse_GFrozen cat numCfg env rawBytes τ) :=
  parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes T henum

theorem PO_C1_01_EnumeratedEmptySound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (hempty : parseAllBounded cat numCfg env budget rawBytes = .enumerated []) :
    StrictAsciiDomainSupported rawBytes ∧
    ∀ τ : ConcreteParseTree, ¬ ValidParse_GFrozen cat numCfg env rawBytes τ :=
  parseAllBounded_empty_sound cat numCfg env budget rawBytes hempty

theorem PO_C1_01_ResourceOverflowFailClosed
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (b : OverflowReason)
    (hov : parseAllBounded cat numCfg env budget rawBytes = .resourceOverflow b) :
    admitBoundedParse cat numCfg env budget rawBytes = .error (.overflowFailClosed b) ∧
    (∀ T, parseAllBounded cat numCfg env budget rawBytes ≠ .enumerated T) :=
  resourceOverflow_failClosed cat numCfg env budget rawBytes b hov

theorem PO_C1_01_NonVacuous_G01_Witness :
    checkSingleGeneratorParse envAtomic sG01 .G01 = true :=
  nonvacuous_G01_enumerated

theorem PO_C1_01_NonVacuous_T2_DualReadings :
    checkDualTrapReadings envAtomic sT2_DualReading .T2 = true ∧
    (∃ t1 t2 : ConcreteParseTree,
      runParserOnStr envAtomic defaultParseBudget sT2_DualReading = .enumerated [t1, t2] ∧
      t1 ≠ t2 ∧
      extractPrimaryReading t1 = some (.T2, 1, false) ∧
      extractPrimaryReading t2 = some (.T2, 2, false)) :=
  nonvacuous_T2_two_distinct_readings

/-! ### 3. Gate D — `BridgeSound` & `ProjectionFaithful` Over Actual Frozen `P3-A` & `P2` -/

theorem PO_P3B_LowerToP2Cert_ProjectionFaithful {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) :
    ProjectionFaithful x (lowerToP2Cert x) :=
  lowerToP2Cert_projectionFaithful x

theorem PO_P3B_ProjectionFaithful_CheckerIff {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
    (π : BrocaOmega.P2.UntrustedDerivCert) :
    checkProjectionFaithfulBool x π = true ↔ ProjectionFaithful x π :=
  checkProjectionFaithfulBool_iff x π

theorem PO_P3B_BridgeSound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (x : LexicallyCertifiedDerivTree cat numCfg Y.toList.length)
    (π : BrocaOmega.P2.UntrustedDerivCert)
    (wP2 : BrocaOmega.P2.CertifiedDerivation env Y deltaIn)
    (hFaithful : ProjectionFaithful x π)
    (hReplay : BrocaOmega.P2.replayDerivation env Y deltaIn π = .accepted wP2) :
    let τ_x := certTreeToParseTree x .clause1
    AllTreeSlotsP3ACertified x ∧
    reconstructCertYield x = Y ∧
    ObligationsConservedOnCert x deltaIn ∧
    LocusTargetBoundOnCert x ∧
    collectCertSpans x = collectP2Spans π ∧
    (frozenProdSig τ_x.prod).isGenerator = true ∧
    τ_x.span = ⟨0, Y.toList.length⟩ ∧
    (∃ sum3 : ParseSummary,
      ValidParseNode cat numCfg env Y.toList .clause1 .controlledDocument τ_x sum3) :=
  BridgeSound cat numCfg env Y deltaIn x π wP2 hFaithful hReplay

theorem PO_P3B_BridgeSound_MemEnumeratedForest
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget)
    (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (wIng : BrocaOmega.P3A.VerifiedIngressText maxIngressBytes)
    (hIng : BrocaOmega.P3A.admitStrictAsciiIngress maxIngressBytes rawBytes = .ok wIng)
    (deltaIn : List ObligationToken)
    (x : LexicallyCertifiedDerivTree cat numCfg wIng.decoded.toList.length)
    (π : BrocaOmega.P2.UntrustedDerivCert)
    (wP2 : BrocaOmega.P2.CertifiedDerivation env wIng.decoded deltaIn)
    (hFaithful : ProjectionFaithful x π)
    (hReplay : BrocaOmega.P2.replayDerivation env wIng.decoded deltaIn π = .accepted wP2) :
    let τ_x := certTreeToParseTree x .clause1
    ValidParse_GFrozen cat numCfg env rawBytes τ_x ∧
    (∀ T : List ConcreteParseTree,
      parseAllBounded cat numCfg env budget rawBytes = .enumerated T → τ_x ∈ T) :=
  BridgeSound_mem_enumerated_forest cat numCfg env budget maxIngressBytes rawBytes
    wIng hIng deltaIn x π wP2 hFaithful hReplay

theorem PO_P3B_VerifyBridgedDerivation_Sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (deltaIn : List ObligationToken) (rawCandidate : BrocaOmega.P2.UntrustedDerivCert)
    (w : CertifiedBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn)
    (hok : verifyBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn rawCandidate = .ok w) :
    ProjectionFaithful w.certTree w.loweredCert ∧
    AllTreeSlotsP3ACertified w.certTree ∧
    reconstructCertYield w.certTree = w.ingressWitness.decoded ∧
    ObligationsConservedOnCert w.certTree deltaIn ∧
    LocusTargetBoundOnCert w.certTree ∧
    ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree w.certTree .clause1) :=
  verifyBridgedDerivation_sound cat numCfg env maxIngressBytes rawBytes deltaIn rawCandidate w hok

/-! ### 4. Gate E — All 28 Curated `(PC, CE)` Vectors Verified via Pure `decide` -/

theorem PO_P3B_All28CounterexampleVectors_Verified :
    (allP3BCases.all (·.passed)) = true ∧ allP3BCases.length = 28 :=
  allP3BCases_verified

/-! ### 5. Gate F — Explicit Governance Locks (`HELD` & `NOT_AUTHORIZED` Preserved) -/

inductive GovernanceDisposition where
  | EVIDENCE_SUBMITTED_PENDING_TRIBUNAL_HELD
  | HELD_EXTERNAL_KERNEL_REPLAY
  | HELD_UNSPECIFIED_IN_R0
  | NOT_AUTHORIZED
  deriving DecidableEq, Repr

def status_F_P3A_01_FullCorrespondence : GovernanceDisposition :=
  .EVIDENCE_SUBMITTED_PENDING_TRIBUNAL_HELD

def status_F_P3A_02_BridgeSoundness : GovernanceDisposition :=
  .EVIDENCE_SUBMITTED_PENDING_TRIBUNAL_HELD

def status_P1_P2_P3A_ExternalKernelReplay : GovernanceDisposition :=
  .HELD_EXTERNAL_KERNEL_REPLAY

def status_G01_RightCensoredSurface_And_ProductionCatalog : GovernanceDisposition :=
  .HELD_UNSPECIFIED_IN_R0

def status_P1C_P3C_P4_P5_Pneuma : GovernanceDisposition :=
  .NOT_AUTHORIZED

end BrocaOmega.P3B.ProofObligations
