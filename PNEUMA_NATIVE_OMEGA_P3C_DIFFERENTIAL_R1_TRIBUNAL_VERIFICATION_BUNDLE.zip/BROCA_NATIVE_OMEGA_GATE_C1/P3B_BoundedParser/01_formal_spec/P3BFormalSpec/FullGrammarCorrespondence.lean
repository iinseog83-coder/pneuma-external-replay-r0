/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`F-P3A-01`: Full Grammar, Side-Condition & Obligation Correspondence)
  01_formal_spec/P3BFormalSpec/FullGrammarCorrespondence.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2FormalSpec` & `P3FormalSpec`)

  Resolves `F-P3A-01` directly on the ACTUAL frozen `BrocaOmega.P2.ruleSignature` and
  `BrocaOmega.P3A.independentFrozenBNF` definitions (zero intermediate snapshot copies!):
    1. Exact bijective correspondence between `P2.FrozenGenRule` (`27` constructors) and the `27`
       generator productions of `FrozenParseProd`, while all `7` trap productions map to `none`.
    2. Exact interleaved `(lhs, rhs)` sequence equality (terminals, typed slots, AND child nonterminals
       with `ClauseLocus` overrides in exact order) across `P2.ruleSignature`, `P3A.independentFrozenBNF`,
       and `P3B.frozenProdSig`.
    3. Universally quantified side-condition equality (`checkSide == P2.checkSideCond`) for ALL
       `env`, `slots`, and `sums`.
    4. Universally quantified intrinsic-obligation equality (`intrinsicObls == P2.intrinsicObls`)
       for ALL `loc`, `slots`, and `sums`, plus `NodeSummary` homomorphism!
-/
import P3BFormalSpec.DeclarativeParseSpec

namespace BrocaOmega.P3B

open BrocaOmega.P2
open BrocaOmega.P3A

/-! ### 1. Exact Bijections Across `P2` ↔ `P3-A` ↔ `P3-B` Types -/

def fromP2Rule : FrozenGenRule → FrozenParseProd
  | .DocSingle              => .Env_DocSingle
  | .ScopedInitial          => .Env_ScopedInitial
  | .ScopedRepeatDiscourse  => .Env_ScopedRepeat
  | .ScopedAssoc            => .Env_ScopedAssoc
  | .ScopedContrastMeta     => .Env_ScopedContrastMeta
  | .LiftAssocToAtomic      => .Env_LiftAssoc
  | .LiftMetaToAtomic       => .Env_LiftMeta
  | .EmbeddedCausal         => .Env_EmbeddedCausal
  | .G01_DescIncidence      => .Gen_G01_DescIncidence
  | .G02a_DescMeanSD        => .Gen_G02a_DescMeanSD
  | .G02b_DescMedianIQR     => .Gen_G02b_DescMedianIQR
  | .G03_AssocUnadj         => .Gen_G03_AssocUnadj
  | .G04_AssocTemp          => .Gen_G04_AssocTemp
  | .G05_CompRD             => .Gen_G05_CompRD
  | .G06a_IntervDirectional => .Gen_G06a_IntervDirectional
  | .G06b_IntervNeutral     => .Gen_G06b_IntervNeutral
  | .G07_MetaNotStatSig     => .Gen_G07_MetaNotStatSig
  | .G08_MetaEquiv          => .Gen_G08_MetaEquiv
  | .G09_MetaNonEstab       => .Gen_G09_MetaNonEstab
  | .G10_MetaUnresolved     => .Gen_G10_MetaUnresolved
  | .G11_QuantZero          => .Gen_G11_QuantZero
  | .G12_QuantProperPart    => .Gen_G12_QuantProperPart
  | .G13_QuantAtLeastOne    => .Gen_G13_QuantAtLeastOne
  | .G14_AssocAdj           => .Gen_G14_AssocAdj
  | .G15_DocConjAtomic      => .Gen_G15a_DocConjAtomic
  | .G15_DocConjDiscourse   => .Gen_G15b_DocConjDiscourse
  | .G16_DocContrastive     => .Gen_G16_DocContrastive

def toP2Rule? : FrozenParseProd → Option FrozenGenRule
  | .Env_DocSingle             => some .DocSingle
  | .Env_ScopedInitial         => some .ScopedInitial
  | .Env_ScopedRepeat          => some .ScopedRepeatDiscourse
  | .Env_ScopedAssoc           => some .ScopedAssoc
  | .Env_ScopedContrastMeta    => some .ScopedContrastMeta
  | .Env_LiftAssoc             => some .LiftAssocToAtomic
  | .Env_LiftMeta              => some .LiftMetaToAtomic
  | .Env_EmbeddedCausal        => some .EmbeddedCausal
  | .Gen_G01_DescIncidence     => some .G01_DescIncidence
  | .Gen_G02a_DescMeanSD       => some .G02a_DescMeanSD
  | .Gen_G02b_DescMedianIQR    => some .G02b_DescMedianIQR
  | .Gen_G03_AssocUnadj        => some .G03_AssocUnadj
  | .Gen_G04_AssocTemp         => some .G04_AssocTemp
  | .Gen_G05_CompRD            => some .G05_CompRD
  | .Gen_G06a_IntervDirectional => some .G06a_IntervDirectional
  | .Gen_G06b_IntervNeutral    => some .G06b_IntervNeutral
  | .Gen_G07_MetaNotStatSig    => some .G07_MetaNotStatSig
  | .Gen_G08_MetaEquiv         => some .G08_MetaEquiv
  | .Gen_G09_MetaNonEstab      => some .G09_MetaNonEstab
  | .Gen_G10_MetaUnresolved    => some .G10_MetaUnresolved
  | .Gen_G11_QuantZero         => some .G11_QuantZero
  | .Gen_G12_QuantProperPart   => some .G12_QuantProperPart
  | .Gen_G13_QuantAtLeastOne   => some .G13_QuantAtLeastOne
  | .Gen_G14_AssocAdj          => some .G14_AssocAdj
  | .Gen_G15a_DocConjAtomic    => some .G15_DocConjAtomic
  | .Gen_G15b_DocConjDiscourse => some .G15_DocConjDiscourse
  | .Gen_G16_DocContrastive    => some .G16_DocContrastive
  | _                          => none

theorem toP2Rule_fromP2Rule (r : FrozenGenRule) :
    toP2Rule? (fromP2Rule r) = some r := by
  cases r <;> rfl

theorem toP2Rule_isSome_iff_isGenerator (p : FrozenParseProd) :
    (toP2Rule? p).isSome = (frozenProdSig p).isGenerator := by
  cases p <;> rfl

def fromP2Nonterm : NontermCat → BNFNonterm
  | .embeddedCausal     => .embeddedCausal
  | .assocCore          => .assocCore
  | .metaNonEstabCore   => .metaNonEstabCore
  | .atomicCore         => .atomicCore
  | .scopedInitial      => .scopedInitial
  | .scopedRepeat       => .scopedRepeat
  | .scopedAssoc        => .scopedAssoc
  | .scopedContrastMeta => .scopedContrastMeta
  | .documentRoot       => .controlledDocument

def fromP2SlotSort : SlotSort → P3SlotSort
  | .cohortSpec       => .cohortSpec
  | .designNoun       => .designNoun
  | .followUpWindow   => .followUpWindow
  | .eventTerm        => .eventTerm
  | .measureTerm      => .measureTerm
  | .expLevel         => .expLevel
  | .outTerm          => .outTerm
  | .sourceId         => .sourceId
  | .identAssump      => .identAssump
  | .subgroupPlural   => .subgroupPlural
  | .subgroupSingular => .subgroupSingular
  | .covariateList    => .covariateList
  | .assocDir         => .assocDir
  | .ratioMetric      => .ratioMetric
  | .intervDirVerb    => .intervDirVerb
  | .intervVerbPres   => .intervVerbPres
  | .numericLit       => .numericLit

def toP2SlotSort? : P3SlotSort → Option SlotSort
  | .cohortSpec       => some .cohortSpec
  | .designNoun       => some .designNoun
  | .followUpWindow   => some .followUpWindow
  | .eventTerm        => some .eventTerm
  | .measureTerm      => some .measureTerm
  | .expLevel         => some .expLevel
  | .outTerm          => some .outTerm
  | .sourceId         => some .sourceId
  | .identAssump      => some .identAssump
  | .subgroupPlural   => some .subgroupPlural
  | .subgroupSingular => some .subgroupSingular
  | .covariateList    => some .covariateList
  | .assocDir         => some .assocDir
  | .ratioMetric      => some .ratioMetric
  | .intervDirVerb    => some .intervDirVerb
  | .intervVerbPres   => some .intervVerbPres
  | .numericLit       => some .numericLit
  | .epistemicVerb    => none
  | .whWord           => none

theorem toP2SlotSort_fromP2SlotSort (s : SlotSort) :
    toP2SlotSort? (fromP2SlotSort s) = some s := by
  cases s <;> rfl

def fromP2SlotRole : SlotRole → BNFSlotTag
  | .cohort        => .cohort
  | .design        => .design
  | .window        => .window
  | .eventA        => .eventA
  | .eventB        => .eventB
  | .measure       => .measure
  | .activeExp     => .activeExp
  | .refExp        => .refExp
  | .outcome       => .outcome
  | .source        => .source
  | .assumption    => .assumption
  | .subgroup      => .subgroup
  | .covariates    => .covariates
  | .direction     => .direction
  | .metric1       => .metric1
  | .metric2       => .metric2
  | .verb          => .verb
  | .numK          => .numK
  | .numN          => .numN
  | .numPct        => .numPct
  | .numEst        => .numEst
  | .numDisp1      => .numDisp1
  | .numDisp2      => .numDisp2
  | .numCILevel    => .numCILevel
  | .numCILow      => .numCILow
  | .numCIHigh     => .numCIHigh
  | .numPVal       => .numPVal
  | .numAlpha      => .numAlpha
  | .numMarginLow  => .numMarginLow
  | .numMarginHigh => .numMarginHigh

def toP2SlotRole? : BNFSlotTag → Option SlotRole
  | .cohort        => some .cohort
  | .design        => some .design
  | .window        => some .window
  | .eventA        => some .eventA
  | .eventB        => some .eventB
  | .measure       => some .measure
  | .activeExp     => some .activeExp
  | .refExp        => some .refExp
  | .outcome       => some .outcome
  | .source        => some .source
  | .assumption    => some .assumption
  | .subgroup      => some .subgroup
  | .covariates    => some .covariates
  | .direction     => some .direction
  | .metric1       => some .metric1
  | .metric2       => some .metric2
  | .verb          => some .verb
  | .numK          => some .numK
  | .numN          => some .numN
  | .numPct        => some .numPct
  | .numEst        => some .numEst
  | .numDisp1      => some .numDisp1
  | .numDisp2      => some .numDisp2
  | .numCILevel    => some .numCILevel
  | .numCILow      => some .numCILow
  | .numCIHigh     => some .numCIHigh
  | .numPVal       => some .numPVal
  | .numAlpha      => some .numAlpha
  | .numMarginLow  => some .numMarginLow
  | .numMarginHigh => some .numMarginHigh
  | .whComp        => none

theorem fromP2SlotRole_injective {r1 r2 : SlotRole}
    (h : fromP2SlotRole r1 = fromP2SlotRole r2) : r1 = r2 := by
  cases r1 <;> cases r2 <;> first | rfl | contradiction

def fromP2LocusOpt : Option ClauseLocus → Nat
  | none          => 0
  | some .clause1 => 1
  | some .clause2 => 2

theorem clauseOverrideOfIdx_fromP2LocusOpt (locOpt : Option ClauseLocus) :
    clauseOverrideOfIdx (fromP2LocusOpt locOpt) = locOpt := by
  cases locOpt with
  | none => rfl
  | some l => cases l <;> rfl

def fromP2RuleSegment : RuleSegment → BNFSymbol
  | .lit txt         => .term txt
  | .slot srt rl     => .lexSlot (fromP2SlotSort srt) (fromP2SlotRole rl)
  | .child cat locOp => .nonterm (fromP2Nonterm cat) (fromP2LocusOpt locOp)

def mapP2Slots (slots : List (SlotRole × String)) : List (BNFSlotTag × String) :=
  slots.map (fun p => (fromP2SlotRole p.1, p.2))

def mapP2Summary (s : NodeSummary) : ParseSummary :=
  { cohortId      := s.cohortIdOpt
    designId      := s.designIdOpt
    expOutPair    := s.expOutPairOpt
    embeddedKey   := s.embeddedKey
    startsWithInOrWithin := s.cohortIdOpt.isSome || s.designIdOpt.isSome }

/-! ### 2. `F-P3A-01` Theorem 1: Exact Interleaved `(lhs, rhs)` Correspondence Across `P2`, `P3-A`, and `P3-B` -/

/--
  Proves directly on `BrocaOmega.P2.ruleSignature` that for EVERY `r : FrozenGenRule`,
  the translated LHS nonterminal and FULL INTERLEAVED RHS sequence (`.lit`, `.slot`, `.child`)
  equal `P3B`'s `frozenProdSig (fromP2Rule r)`!
-/
theorem f_p3a_01_p2_ruleSignature_matches_p3b_interleaved (r : FrozenGenRule) :
    fromP2Nonterm (ruleSignature r).lhsCat = (frozenProdSig (fromP2Rule r)).lhs ∧
    ((ruleSignature r).segments.map fromP2RuleSegment) = (frozenProdSig (fromP2Rule r)).rhs := by
  cases r <;> decide

/--
  Proves that ALL 34 productions in `P3B.allFrozenParseProds` match `P3A.independentFrozenBNF`
  1-to-1 in exact `(ownerRule, isGenerator, lhs, rhs)` order!
-/
theorem f_p3a_01_p3b_matches_p3a_independentFrozenBNF :
    (allFrozenParseProds.map fun p =>
      let sig := frozenProdSig p
      (sig.ownerRule, sig.isGenerator, sig.lhs, sig.rhs)) =
    (independentFrozenBNF.map fun b =>
      (b.canonicalOwner, b.isGenerator, b.lhs, b.rhs)) := by
  decide

/-! ### 3. `F-P3A-01` Theorem 2: Universal Side-Condition, Intrinsic-Obligation & Summary Equivalence -/

theorem lookupTagVal_mapP2Slots (slots : List (SlotRole × String)) (rl : SlotRole) :
    lookupTagVal (mapP2Slots slots) (fromP2SlotRole rl) = lookupRoleVal slots rl := by
  induction slots with
  | nil => rfl
  | cons hd tl ih =>
    unfold mapP2Slots lookupTagVal lookupRoleVal
    simp only [List.map_cons, List.find?_cons]
    by_cases h : hd.1 = rl
    · have htag : (fromP2SlotRole hd.1 == fromP2SlotRole rl) = true := by simp [h]
      have hrl  : (hd.1 == rl) = true := by simp [h]
      rw [htag, hrl]
    · have htag : (fromP2SlotRole hd.1 == fromP2SlotRole rl) = false :=
        beq_eq_false_iff_ne.mpr (fun heq => h (fromP2SlotRole_injective heq))
      have hrl  : (hd.1 == rl) = false := beq_eq_false_iff_ne.mpr h
      rw [htag, hrl]
      exact ih

theorem fromP2_of_toP2 {tag : BNFSlotTag} {rl : SlotRole}
    (h : toP2SlotRole? tag = some rl) : fromP2SlotRole rl = tag := by
  cases tag <;> simp [toP2SlotRole?] at h <;> subst rl <;> rfl

theorem toP2_none_eq_whComp {tag : BNFSlotTag}
    (h : toP2SlotRole? tag = none) : tag = .whComp := by
  cases tag <;> simp [toP2SlotRole?] at h <;> rfl

@[simp]
theorem lookupTagVal_mapP2Slots_all (slots : List (SlotRole × String)) (tag : BNFSlotTag) :
    lookupTagVal (mapP2Slots slots) tag =
      match toP2SlotRole? tag with
      | some rl => lookupRoleVal slots rl
      | none    => "" := by
  cases h : toP2SlotRole? tag with
  | some rl =>
    rw [← fromP2_of_toP2 h]
    exact lookupTagVal_mapP2Slots slots rl
  | none =>
    rw [toP2_none_eq_whComp h]
    induction slots with
    | nil => rfl
    | cons hd tl ih =>
      unfold mapP2Slots lookupTagVal
      simp only [List.map_cons, List.find?_cons]
      have hne : (fromP2SlotRole hd.1 == .whComp) = false := by cases hd.1 <;> rfl
      rw [hne]
      exact ih

/--
  **`F-P3A-01` Side-Condition Semantic Equivalence**:
  For ALL `27` generator rules `r`, ALL `ScopeEnv`, ALL `slots`, and ALL child `NodeSummary` lists,
  `P3B`'s independent `checkSide` evaluates identically to `P2.ruleSignature.checkSideCond`!
-/
theorem f_p3a_01_universal_sidecond_equivalence
    (r : FrozenGenRule) (env : ScopeEnv)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).checkSide env (mapP2Slots slots) (sums.map mapP2Summary) =
    (ruleSignature r).checkSideCond env slots sums := by
  cases r <;> dsimp [fromP2Rule, frozenProdSig, ruleSignature]
  all_goals
    cases sums with
    | nil => simp [toP2SlotRole?]
    | cons c1 rest1 =>
      cases rest1 with
      | nil => simp [toP2SlotRole?]
      | cons c2 rest2 =>
        cases rest2 <;> simp [mapP2Summary, toP2SlotRole?]

/--
  **`F-P3A-01` Intrinsic-Obligation Semantic Equivalence**:
  For ALL `27` generator rules `r`, ALL `ClauseLocus`, ALL `slots`, and ALL child `NodeSummary` lists,
  `P3B`'s independent `intrinsicObls` produces the EXACT same `List ObligationSpec` as `P2.ruleSignature`!
-/
theorem f_p3a_01_universal_intrinsicObls_equivalence
    (r : FrozenGenRule) (loc : ClauseLocus)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).intrinsicObls loc (mapP2Slots slots) (sums.map mapP2Summary) =
    (ruleSignature r).intrinsicObls loc slots sums := by
  cases r <;> dsimp [fromP2Rule, frozenProdSig, ruleSignature]
  all_goals
    cases sums with
    | nil => simp [toP2SlotRole?]
    | cons c1 rest1 =>
      cases rest1 with
      | nil => simp [mapP2Summary, toP2SlotRole?]
      | cons c2 rest2 =>
        cases rest2 with
        | nil => rcases c1 with ⟨_, _, _ | ⟨eId, oId⟩, _⟩ <;> simp [mapP2Summary, toP2SlotRole?]
        | cons c3 rest3 => simp [mapP2Summary, toP2SlotRole?]

/--
  **Summary Homomorphism (`mkSum` Projection Consistency)**:
  For all `27` generator rules, `P3B`'s `mkSum` agrees with `mapP2Summary ∘ P2.mkSummary` on all
  semantic fields (`cohortId`, `designId`, `expOutPair`, `embeddedKey`).
-/
theorem f_p3a_01_universal_summary_equivalence
    (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    let s3 := (frozenProdSig (fromP2Rule r)).mkSum (mapP2Slots slots) (sums.map mapP2Summary)
    let s2 := mapP2Summary ((ruleSignature r).mkSummary slots sums)
    s3.cohortId = s2.cohortId ∧
    s3.designId = s2.designId ∧
    s3.expOutPair = s2.expOutPair ∧
    s3.embeddedKey = s2.embeddedKey := by
  cases r <;> dsimp [fromP2Rule, frozenProdSig, ruleSignature, mapP2Summary]
  all_goals
    cases sums with
    | nil => simp [toP2SlotRole?]
    | cons c1 rest1 =>
      cases rest1 <;> simp [mapP2Summary, toP2SlotRole?]

end BrocaOmega.P3B
