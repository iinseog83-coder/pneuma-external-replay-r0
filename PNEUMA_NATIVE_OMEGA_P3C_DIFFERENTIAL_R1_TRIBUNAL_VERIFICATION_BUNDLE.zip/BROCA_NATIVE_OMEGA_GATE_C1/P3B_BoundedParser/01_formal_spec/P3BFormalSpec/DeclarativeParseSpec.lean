/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` Bounded Exhaustive Parser & `BridgeSound`)
  01_formal_spec/P3BFormalSpec/DeclarativeParseSpec.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2FormalSpec` & `P3FormalSpec`)

  Gate A Deliverable:
  Defines the algorithm-independent declarative parsing specification `ValidParse_GFrozen`
  directly from `Architecture Freeze R0` (`S0-R2`, `S0-R2.1`, `S0-R2.2`, `Gate C0-R1`, `P0-A05`):
    1. All 34 frozen productions (`27` generator `G-01`~`G-16` + envelopes, `7` parser-only traps `T1`~`T5` + envelopes).
    2. `ConcreteParseTree` carrying explicit `readingAlt : Nat` (`1..altCount`) so `T2`'s two
       semantic readings (`alt=1` non-factive vs `alt=2` factive presupposition) are distinct
       first-class parse trees without increasing the 21 canonical rule IDs!
    3. Independent side-condition, summary, and intrinsic-obligation specifications (never calling
       `P2.ruleSignature` or `parseAllBounded` — strictly non-circular!).
    4. Exact slot-level `P3-A` lexical validity (`LexicallyValid ∧ NumericallyWellFormed ∧ EntityCatalogBound`).
-/
import P2FormalSpec
import P3FormalSpec

namespace BrocaOmega.P3B

open BrocaOmega.P2
open BrocaOmega.P3A

/-! ### 1. Closed 34-Production Enumeration of `G_parse = G_gen ∪ G_trap` -/

inductive FrozenParseProd where
  -- (A) 8 Generator Structural Wrappers (`S0-R2.1` §II.1)
  | Env_DocSingle
  | Env_ScopedInitial
  | Env_ScopedRepeat
  | Env_ScopedAssoc
  | Env_ScopedContrastMeta
  | Env_LiftAssoc
  | Env_LiftMeta
  | Env_EmbeddedCausal
  -- (B) 19 Generator Core & Document Productions (`G-01` ~ `G-16`)
  | Gen_G01_DescIncidence
  | Gen_G02a_DescMeanSD
  | Gen_G02b_DescMedianIQR
  | Gen_G03_AssocUnadj
  | Gen_G04_AssocTemp
  | Gen_G05_CompRD
  | Gen_G06a_IntervDirectional
  | Gen_G06b_IntervNeutral
  | Gen_G07_MetaNotStatSig
  | Gen_G08_MetaEquiv
  | Gen_G09_MetaNonEstab
  | Gen_G10_MetaUnresolved
  | Gen_G11_QuantZero
  | Gen_G12_QuantProperPart
  | Gen_G13_QuantAtLeastOne
  | Gen_G14_AssocAdj
  | Gen_G15a_DocConjAtomic
  | Gen_G15b_DocConjDiscourse
  | Gen_G16_DocContrastive
  -- (C) 7 Parser-Only Trap Wrappers & Productions (`T1` ~ `T5`, `P0-A05` §2)
  | Env_DocTrapScoped
  | Env_ScopedTrap
  | Trap_T1_AllNot
  | Trap_T2_ConfirmThat
  | Trap_T3_WhPresup
  | Trap_T4_BarePlural
  | Trap_T5_UnscopedDoc
  deriving DecidableEq, Repr

def allFrozenParseProds : List FrozenParseProd :=
  [ .Env_DocSingle, .Env_ScopedInitial, .Env_ScopedRepeat, .Env_ScopedAssoc,
    .Env_ScopedContrastMeta, .Env_LiftAssoc, .Env_LiftMeta, .Env_EmbeddedCausal,
    .Gen_G01_DescIncidence, .Gen_G02a_DescMeanSD, .Gen_G02b_DescMedianIQR,
    .Gen_G03_AssocUnadj, .Gen_G04_AssocTemp, .Gen_G05_CompRD,
    .Gen_G06a_IntervDirectional, .Gen_G06b_IntervNeutral, .Gen_G07_MetaNotStatSig,
    .Gen_G08_MetaEquiv, .Gen_G09_MetaNonEstab, .Gen_G10_MetaUnresolved,
    .Gen_G11_QuantZero, .Gen_G12_QuantProperPart, .Gen_G13_QuantAtLeastOne,
    .Gen_G14_AssocAdj, .Gen_G15a_DocConjAtomic, .Gen_G15b_DocConjDiscourse,
    .Gen_G16_DocContrastive,
    .Env_DocTrapScoped, .Env_ScopedTrap,
    .Trap_T1_AllNot, .Trap_T2_ConfirmThat, .Trap_T3_WhPresup,
    .Trap_T4_BarePlural, .Trap_T5_UnscopedDoc ]

theorem allFrozenParseProds_nodup_and_complete (p : FrozenParseProd) :
    p ∈ allFrozenParseProds := by
  cases p <;> decide

/-! ### 2. Independent Summary, Side-Condition & Obligation Signature of `G_parse` -/

structure ParseSummary where
  cohortId      : Option String := none
  designId      : Option String := none
  expOutPair    : Option (String × String) := none
  embeddedKey   : Option String := none
  startsWithInOrWithin : Bool := false
  deriving DecidableEq, Repr

def lookupTagVal (slots : List (BNFSlotTag × String)) (t : BNFSlotTag) : String :=
  match slots.find? (fun p => p.1 == t) with
  | some (_, v) => v
  | none        => ""

def clauseOverrideOfIdx : Nat → Option ClauseLocus
  | 1 => some .clause1
  | 2 => some .clause2
  | _ => none

structure FrozenProdSpec where
  ownerRule     : Option CanonicalRuleId
  isGenerator   : Bool
  lhs           : BNFNonterm
  rhs           : List BNFSymbol
  checkSide     : ScopeEnv → List (BNFSlotTag × String) → List ParseSummary → Bool
  intrinsicObls : ClauseLocus → List (BNFSlotTag × String) → List ParseSummary → List ObligationSpec
  mkSum         : List (BNFSlotTag × String) → List ParseSummary → ParseSummary

/-- Reading count of a `FrozenParseProd` (`1` for wrappers & single-reading rules, `2` for `T1`, `T2`, `T4`). -/
def FrozenParseProd.altCount (p : FrozenParseProd) : Nat :=
  match p with
  | .Trap_T1_AllNot      => 2
  | .Trap_T2_ConfirmThat => 2
  | .Trap_T4_BarePlural  => 2
  | _                    => 1

/--
  Independent Declarative Production Specification derived directly from `Architecture Freeze R0`
  (`S0-R2`, `S0-R2.1`, `S0-R2.2`, `Gate C0-R1`, `P0-A05`).
  Does NOT call `P2.ruleSignature`!
-/
def frozenProdSig : FrozenParseProd → FrozenProdSpec
  | .Env_DocSingle =>
    { ownerRule := none, isGenerator := true, lhs := .controlledDocument,
      rhs := [.nonterm .scopedInitial 1, .term "."],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Env_ScopedInitial =>
    { ownerRule := none, isGenerator := true, lhs := .scopedInitial,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .atomicCore 0],
      checkSide := fun env s _ => lookupTagVal s .cohort == env.cohortId,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupTagVal s .cohort }],
      mkSum := fun s ch =>
        { cohortId := some (lookupTagVal s .cohort)
          expOutPair := match ch with | [c] => c.expOutPair | _ => none
          startsWithInOrWithin := true } }

  | .Env_ScopedRepeat =>
    { ownerRule := none, isGenerator := true, lhs := .scopedRepeat,
      rhs := [.term "Within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .atomicCore 0],
      checkSide := fun env s _ => lookupTagVal s .design == env.expectedDesignHead,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := "resolve:" ++ lookupTagVal s .design }],
      mkSum := fun s ch =>
        { designId := some (lookupTagVal s .design)
          expOutPair := match ch with | [c] => c.expOutPair | _ => none
          startsWithInOrWithin := true } }

  | .Env_ScopedAssoc =>
    { ownerRule := none, isGenerator := true, lhs := .scopedAssoc,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .assocCore 0],
      checkSide := fun env s _ => lookupTagVal s .cohort == env.cohortId,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupTagVal s .cohort }],
      mkSum := fun s ch =>
        { cohortId := some (lookupTagVal s .cohort)
          expOutPair := match ch with | [c] => c.expOutPair | _ => none
          startsWithInOrWithin := true } }

  | .Env_ScopedContrastMeta =>
    { ownerRule := none, isGenerator := true, lhs := .scopedContrastMeta,
      rhs := [.term "within this same ", .lexSlot .designNoun .design, .term ", ", .nonterm .metaNonEstabCore 0],
      checkSide := fun env s _ => lookupTagVal s .design == env.expectedDesignHead,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := "resolve:" ++ lookupTagVal s .design }],
      mkSum := fun s ch =>
        { designId := some (lookupTagVal s .design)
          expOutPair := match ch with | [c] => c.expOutPair | _ => none
          startsWithInOrWithin := true } }

  | .Env_LiftAssoc =>
    { ownerRule := none, isGenerator := true, lhs := .atomicCore,
      rhs := [.nonterm .assocCore 0],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ ch => match ch with | [c] => c | _ => {} }

  | .Env_LiftMeta =>
    { ownerRule := none, isGenerator := true, lhs := .atomicCore,
      rhs := [.nonterm .metaNonEstabCore 0],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ ch => match ch with | [c] => c | _ => {} }

  | .Env_EmbeddedCausal =>
    { ownerRule := none, isGenerator := true, lhs := .embeddedCausal,
      rhs := [.lexSlot .expLevel .activeExp, .term " ", .lexSlot .intervVerbPres .verb, .term " ", .lexSlot .outTerm .outcome],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun s _ =>
        let act := lookupTagVal s .activeExp
        let vb  := lookupTagVal s .verb
        let out := lookupTagVal s .outcome
        { expOutPair := some (act, out)
          embeddedKey := some (act ++ ":" ++ vb ++ ":" ++ out) } }

  | .Gen_G01_DescIncidence =>
    { ownerRule := some .G01, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "over ", .lexSlot .followUpWindow .window,
               .term ", the cumulative incidence of ", .lexSlot .eventTerm .eventA,
               .term " was ", .lexSlot .numericLit .numK,
               .term " of ", .lexSlot .numericLit .numN,
               .term " patients (", .lexSlot .numericLit .numPct, .term "%)" ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descIncidence,
           target := lookupTagVal s .window ++ ":" ++ lookupTagVal s .eventA ++ ":" ++
                     lookupTagVal s .numK ++ "/" ++ lookupTagVal s .numN ++ "=" ++ lookupTagVal s .numPct }],
      mkSum := fun _ _ => {} }

  | .Gen_G02a_DescMeanSD =>
    { ownerRule := some .G02, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the mean ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (SD ", .lexSlot .numericLit .numDisp1, .term ")" ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descDistribution,
           target := "mean_sd:" ++ lookupTagVal s .measure ++ ":" ++ lookupTagVal s .numEst ++ ":" ++ lookupTagVal s .numDisp1 }],
      mkSum := fun _ _ => {} }

  | .Gen_G02b_DescMedianIQR =>
    { ownerRule := some .G02, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the median ", .lexSlot .measureTerm .measure,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (IQR ", .lexSlot .numericLit .numDisp1,
               .term " to ", .lexSlot .numericLit .numDisp2, .term ")" ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descDistribution,
           target := "median_iqr:" ++ lookupTagVal s .measure ++ ":" ++ lookupTagVal s .numEst ++ ":" ++
                     lookupTagVal s .numDisp1 ++ ".." ++ lookupTagVal s .numDisp2 }],
      mkSum := fun _ _ => {} }

  | .Gen_G03_AssocUnadj =>
    { ownerRule := some .G03, isGenerator := true, lhs := .assocCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .assocMetricDir,
           target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .direction ++ ":" ++
                     lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome }],
      mkSum := fun s _ => { expOutPair := some (lookupTagVal s .activeExp, lookupTagVal s .outcome) } }

  | .Gen_G04_AssocTemp =>
    { ownerRule := some .G04, isGenerator := true, lhs := .assocCore,
      rhs := [ .lexSlot .eventTerm .eventA, .term " preceded ", .lexSlot .eventTerm .eventB,
               .term ", and comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ =>
        (lookupTagVal s .eventA != lookupTagVal s .eventB) &&
        (lookupTagVal s .activeExp != lookupTagVal s .refExp),
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .temporalPrecedence,
            target := lookupTagVal s .eventA ++ "<" ++ lookupTagVal s .eventB },
          { locus := loc, kind := .assocMetricDir,
            target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .direction ++ ":" ++
                      lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome } ],
      mkSum := fun s _ => { expOutPair := some (lookupTagVal s .activeExp, lookupTagVal s .outcome) } }

  | .Gen_G05_CompRD =>
    { ownerRule := some .G05, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the absolute risk difference in ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " percentage points (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .absRiskDiff,
           target := "RD:" ++ lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome }],
      mkSum := fun _ _ => {} }

  | .Gen_G06a_IntervDirectional =>
    { ownerRule := some .G06, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was estimated to ", .lexSlot .intervDirVerb .verb,
               .term " ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ", p = ", .lexSlot .numericLit .numPVal, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .identAssumption, target := lookupTagVal s .assumption },
          { locus := loc, kind := .intervDirectional,
            target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .verb ++ ":" ++
                      lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome } ],
      mkSum := fun _ _ => {} }

  | .Gen_G06b_IntervNeutral =>
    { ownerRule := some .G06, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "under ", .lexSlot .identAssump .assumption,
               .term ", the estimated causal ", .lexSlot .ratioMetric .metric1,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .numericLit .numEst,
               .term " (", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term "), which did not exclude no effect" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .identAssumption, target := lookupTagVal s .assumption },
          { locus := loc, kind := .intervNeutral,
            target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .activeExp ++ ":" ++
                      lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome } ],
      mkSum := fun _ _ => {} }

  | .Gen_G07_MetaNotStatSig =>
    { ownerRule := some .G07, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the observed ", .lexSlot .ratioMetric .metric1,
               .term " comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric2,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh,
               .term ") was not statistically significant at alpha = ",
               .lexSlot .numericLit .numAlpha ],
      checkSide := fun _ s _ =>
        (lookupTagVal s .metric1 == lookupTagVal s .metric2) &&
        (lookupTagVal s .activeExp != lookupTagVal s .refExp),
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .metaNotStatSig,
           target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .activeExp ++ ":" ++
                     lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome ++ ":" ++ lookupTagVal s .numAlpha }],
      mkSum := fun _ _ => {} }

  | .Gen_G08_MetaEquiv =>
    { ownerRule := some .G08, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " met prespecified equivalence margins (",
               .lexSlot .numericLit .numMarginLow, .term " to ", .lexSlot .numericLit .numMarginHigh,
               .term ") for ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% TOST CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .metaEquivMargins,
           target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .activeExp ++ ":" ++
                     lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome ++ ":" ++
                     lookupTagVal s .numMarginLow ++ ".." ++ lookupTagVal s .numMarginHigh }],
      mkSum := fun _ _ => {} }

  | .Gen_G09_MetaNonEstab =>
    { ownerRule := some .G09, isGenerator := true, lhs := .metaNonEstabCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not establish that ", .nonterm .embeddedCausal 0 ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s ch =>
        let embKey := match ch with | [c] => c.embeddedKey.getD "" | _ => ""
        [{ locus := loc, kind := .metaNonEstabNeg, target := lookupTagVal s .source ++ ":" ++ embKey }],
      mkSum := fun _ ch => { expOutPair := match ch with | [c] => c.expOutPair | _ => none } }

  | .Gen_G10_MetaUnresolved =>
    { ownerRule := some .G10, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "the analysis of ", .lexSlot .sourceId .source,
               .term " did not determine whether ", .nonterm .embeddedCausal 0 ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s ch =>
        let embKey := match ch with | [c] => c.embeddedKey.getD "" | _ => ""
        [{ locus := loc, kind := .metaUnresolvedPolar, target := lookupTagVal s .source ++ ":" ++ embKey }],
      mkSum := fun _ _ => {} }

  | .Gen_G11_QuantZero =>
    { ownerRule := some .G11, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "no ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantZeroNeg,
           target := lookupTagVal s .subgroup ++ ":" ++ lookupTagVal s .eventA }],
      mkSum := fun _ _ => {} }

  | .Gen_G12_QuantProperPart =>
    { ownerRule := some .G12, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "some, but not all, ", .lexSlot .subgroupPlural .subgroup,
               .term " patients developed ", .lexSlot .eventTerm .eventA ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantProperPart,
           target := lookupTagVal s .subgroup ++ ":" ++ lookupTagVal s .eventA }],
      mkSum := fun _ _ => {} }

  | .Gen_G13_QuantAtLeastOne =>
    { ownerRule := some .G13, isGenerator := true, lhs := .atomicCore,
      rhs := [ .term "at least one ", .lexSlot .subgroupSingular .subgroup,
               .term " patient developed ", .lexSlot .eventTerm .eventA ],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantExistential,
           target := lookupTagVal s .subgroup ++ ":" ++ lookupTagVal s .eventA }],
      mkSum := fun _ _ => {} }

  | .Gen_G14_AssocAdj =>
    { ownerRule := some .G14, isGenerator := true, lhs := .assocCore,
      rhs := [ .term "after adjustment for ", .lexSlot .covariateList .covariates,
               .term ", comparing ", .lexSlot .expLevel .activeExp,
               .term " versus ", .lexSlot .expLevel .refExp,
               .term " was ", .lexSlot .assocDir .direction,
               .term " associated with ", .lexSlot .outTerm .outcome,
               .term " (", .lexSlot .ratioMetric .metric1,
               .term " = ", .lexSlot .numericLit .numEst,
               .term ", ", .lexSlot .numericLit .numCILevel,
               .term "% CI ", .lexSlot .numericLit .numCILow,
               .term " to ", .lexSlot .numericLit .numCIHigh, .term ")" ],
      checkSide := fun _ s _ => lookupTagVal s .activeExp != lookupTagVal s .refExp,
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .covariateAdjustment, target := lookupTagVal s .covariates },
          { locus := loc, kind := .assocMetricDir,
            target := lookupTagVal s .metric1 ++ ":" ++ lookupTagVal s .direction ++ ":" ++
                      lookupTagVal s .activeExp ++ ":" ++ lookupTagVal s .refExp ++ ":" ++ lookupTagVal s .outcome } ],
      mkSum := fun s _ => { expOutPair := some (lookupTagVal s .activeExp, lookupTagVal s .outcome) } }

  | .Gen_G15a_DocConjAtomic =>
    { ownerRule := some .G15, isGenerator := true, lhs := .controlledDocument,
      rhs := [.nonterm .scopedInitial 1, .term ". ", .nonterm .scopedInitial 2, .term "."],
      checkSide := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (env.quoteIsolation == .sentenceAtomic) &&
          (c1.cohortId == some env.cohortId) &&
          (c2.cohortId == some env.cohortId)
        | _ => false,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Gen_G15b_DocConjDiscourse =>
    { ownerRule := some .G15, isGenerator := true, lhs := .controlledDocument,
      rhs := [.nonterm .scopedInitial 1, .term ". ", .nonterm .scopedRepeat 2, .term "."],
      checkSide := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (env.quoteIsolation == .discourseBound) &&
          (c1.cohortId == some env.cohortId) &&
          (c2.designId == some env.expectedDesignHead)
        | _ => false,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Gen_G16_DocContrastive =>
    { ownerRule := some .G16, isGenerator := true, lhs := .controlledDocument,
      rhs := [.nonterm .scopedAssoc 1, .term "; however, ", .nonterm .scopedContrastMeta 2, .term "."],
      checkSide := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (c1.cohortId == some env.cohortId) &&
          (c2.designId == some env.expectedDesignHead) &&
          c1.expOutPair.isSome &&
          (c1.expOutPair == c2.expOutPair)
        | _ => false,
      intrinsicObls := fun _ _ ch =>
        match ch with
        | [c1, _] =>
          match c1.expOutPair with
          | some (eId, oId) =>
            [{ locus := .clause2, kind := .contrastiveBoundary, target := eId ++ ":" ++ oId }]
          | none =>
            [{ locus := .clause2, kind := .contrastiveBoundary, target := "" }]
        | _ => [],
      mkSum := fun _ _ => {} }

  -- (C) Parser-Only Trap Productions (`G_trap = G_parse \ G_gen`, `P0-A05` §2)
  | .Env_DocTrapScoped =>
    { ownerRule := none, isGenerator := false, lhs := .controlledDocument,
      rhs := [.nonterm .scopedTrapClause 1, .term "."],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Env_ScopedTrap =>
    { ownerRule := none, isGenerator := false, lhs := .scopedTrapClause,
      rhs := [.term "In ", .lexSlot .cohortSpec .cohort, .term ", ", .nonterm .trapCore 0],
      checkSide := fun env s _ => lookupTagVal s .cohort == env.cohortId,
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupTagVal s .cohort }],
      mkSum := fun s _ => { cohortId := some (lookupTagVal s .cohort), startsWithInOrWithin := true } }

  | .Trap_T1_AllNot =>
    { ownerRule := some .T1, isGenerator := false, lhs := .trapCore,
      rhs := [.term "all ", .lexSlot .subgroupPlural .subgroup,
              .term " patients did not develop ", .lexSlot .eventTerm .eventA],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Trap_T2_ConfirmThat =>
    { ownerRule := some .T2, isGenerator := false, lhs := .trapCore,
      rhs := [.term "the analysis of ", .lexSlot .sourceId .source,
              .term " did not confirm that ", .nonterm .embeddedCausal 0],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ ch => { expOutPair := match ch with | [c] => c.expOutPair | _ => none } }

  | .Trap_T3_WhPresup =>
    { ownerRule := some .T3, isGenerator := false, lhs := .trapCore,
      rhs := [.term "the analysis of ", .lexSlot .sourceId .source,
              .term " did not ", .lexSlot .epistemicVerb .verb,
              .term " ", .lexSlot .whWord .whComp,
              .term " ", .nonterm .embeddedCausal 0],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ ch => { expOutPair := match ch with | [c] => c.expOutPair | _ => none } }

  | .Trap_T4_BarePlural =>
    { ownerRule := some .T4, isGenerator := false, lhs := .trapCore,
      rhs := [.lexSlot .subgroupPlural .subgroup,
              .term " patients developed ", .lexSlot .eventTerm .eventA],
      checkSide := fun _ _ _ => true,
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

  | .Trap_T5_UnscopedDoc =>
    { ownerRule := some .T5, isGenerator := false, lhs := .controlledDocument,
      rhs := [.nonterm .atomicCore 1, .term "."],
      checkSide := fun _ _ _ => true, -- Note: `AtomicCore` never begins with `"In "` or `"Within this same "`!
      intrinsicObls := fun _ _ _ => [],
      mkSum := fun _ _ => {} }

/-- Acyclicity Theorem across ALL 34 productions of `frozenProdSig` (`childNt.level < lhs.level`). -/
theorem frozenProdSig_child_level_lt (p : FrozenParseProd) (nt : BNFNonterm) (cIdx : Nat)
    (hmem : BNFSymbol.nonterm nt cIdx ∈ (frozenProdSig p).rhs) :
    nt.level < (frozenProdSig p).lhs.level := by
  cases p <;> simp [frozenProdSig] at hmem
  all_goals
    try (rcases hmem with ⟨rfl, _⟩ | ⟨rfl, _⟩ <;> decide)
    try (rcases hmem with ⟨rfl, _⟩; decide)

/-! ### 3. Concrete Parse Reading Tree (`ParsedReadingTree` with Explicit `readingAlt`) -/

mutual
  inductive ConcreteParseArg where
    | litTok   (text : String) (span : CodepointSpan)
    | slotTok  (sort : P3SlotSort) (tag : BNFSlotTag)
               (entityId : String) (lexeme : String) (span : CodepointSpan)
    | childSub (tree : ConcreteParseTree)

  inductive ConcreteParseTree where
    | mkTree
        (prod       : FrozenParseProd)
        (readingAlt : Nat)
        (locus      : ClauseLocus)
        (span       : CodepointSpan)
        (args       : List ConcreteParseArg)
end

-- Explicit structural equality & `DecidableEq` on `ConcreteParseTree` / `ConcreteParseArg`
mutual
  def parseArgEqBool : ConcreteParseArg → ConcreteParseArg → Bool
    | .litTok t1 sp1, .litTok t2 sp2 => (t1 == t2) && (sp1 == sp2)
    | .slotTok s1 tg1 id1 l1 sp1, .slotTok s2 tg2 id2 l2 sp2 =>
      (s1 == s2) && (tg1 == tg2) && (id1 == id2) && (l1 == l2) && (sp1 == sp2)
    | .childSub sub1, .childSub sub2 => parseTreeEqBool sub1 sub2
    | _, _ => false

  def parseArgListEqBool : List ConcreteParseArg → List ConcreteParseArg → Bool
    | [], [] => true
    | a1 :: r1, a2 :: r2 => parseArgEqBool a1 a2 && parseArgListEqBool r1 r2
    | _, _ => false

  def parseTreeEqBool : ConcreteParseTree → ConcreteParseTree → Bool
    | .mkTree p1 a1 l1 sp1 args1, .mkTree p2 a2 l2 sp2 args2 =>
      (p1 == p2) && (a1 == a2) && (l1 == l2) && (sp1 == sp2) && parseArgListEqBool args1 args2
end

mutual
  theorem parseArgEqBool_iff (x y : ConcreteParseArg) :
      parseArgEqBool x y = true ↔ x = y := by
    cases x <;> cases y <;> simp [parseArgEqBool, Bool.and_eq_true, beq_iff_eq, and_assoc]
    case childSub.childSub s1 s2 =>
      exact parseTreeEqBool_iff s1 s2

  theorem parseArgListEqBool_iff (xs ys : List ConcreteParseArg) :
      parseArgListEqBool xs ys = true ↔ xs = ys := by
    cases xs <;> cases ys <;> simp [parseArgListEqBool, Bool.and_eq_true]
    case cons.cons a1 r1 a2 r2 =>
      rw [parseArgEqBool_iff, parseArgListEqBool_iff]

  theorem parseTreeEqBool_iff (t1 t2 : ConcreteParseTree) :
      parseTreeEqBool t1 t2 = true ↔ t1 = t2 := by
    cases t1 with
    | mkTree p1 a1 l1 sp1 args1 =>
      cases t2 with
      | mkTree p2 a2 l2 sp2 args2 =>
        simp [parseTreeEqBool, Bool.and_eq_true, beq_iff_eq, parseArgListEqBool_iff, and_assoc]
end

instance : DecidableEq ConcreteParseTree := fun t1 t2 =>
  if h : parseTreeEqBool t1 t2 = true then
    isTrue ((parseTreeEqBool_iff t1 t2).mp h)
  else
    isFalse (fun heq => h ((parseTreeEqBool_iff t1 t2).mpr heq))

instance : BEq ConcreteParseTree where
  beq := parseTreeEqBool

def ConcreteParseTree.span : ConcreteParseTree → CodepointSpan
  | .mkTree _ _ _ sp _ => sp

def ConcreteParseTree.readingAlt : ConcreteParseTree → Nat
  | .mkTree _ alt _ _ _ => alt

def ConcreteParseTree.prod : ConcreteParseTree → FrozenParseProd
  | .mkTree p _ _ _ _ => p

mutual
  def reconstructParseSegChars : List ConcreteParseArg → List Char
    | [] => []
    | .litTok txt _ :: rest       => txt.toList ++ reconstructParseSegChars rest
    | .slotTok _ _ _ lex _ :: rest => lex.toList ++ reconstructParseSegChars rest
    | .childSub sub :: rest       => reconstructParseChars sub ++ reconstructParseSegChars rest

  def reconstructParseChars : ConcreteParseTree → List Char
    | .mkTree _ _ _ _ args => reconstructParseSegChars args
end

def reconstructParseYield (t : ConcreteParseTree) : String :=
  String.ofList (reconstructParseChars t)

/-! ### 4. Supported Character Domain & Declarative `ValidParse_GFrozen` (`Gate A / Gate C`) -/

/--
  Character-profile domain precondition for English `D_0` (`OutOfDomain` boundary):
  Non-empty raw byte sequence where every byte is printable 7-bit ASCII (`0x20..0x7E`).
  Crucially separated from `maxBytes` resource budget (`ResourceOverflow` ≠ `OutOfDomain`)!
-/
def StrictAsciiDomainSupported (rawBytes : List UInt8) : Prop :=
  0 < rawBytes.length ∧ ∀ b ∈ rawBytes, IsPrintableAsciiByte b

def strToAsciiBytes (s : String) : List UInt8 :=
  s.toList.map (fun c => UInt8.ofNat c.toNat)

/-- Declarative `P3-A` lexical validity of a `(sort, entityId, lexeme)` triple over an in-domain string. -/
def DeclarativeSlotValid (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (eid lex : String) : Prop :=
  let cand : RawSlotCandidate := { sort := srt, entityId := eid, rawBytes := strToAsciiBytes lex }
  cand.decodedStr = lex ∧
  LexicallyValid maxSlotBytes cand ∧
  NumericallyWellFormed numCfg cand ∧
  EntityCatalogBound cat cand

/-
  Algorithm-Free Declarative Parsing Relation (`ValidParseSegs` & `ValidParseNode`):
  Defines exact membership in `G_parse` (`G-01`~`G-16` ∪ `T1`~`T5`) with contiguous spans,
  `P3-A` lexical validity on every slot, preserved `readingAlt ∈ 1..altCount`, and side conditions.
-/
mutual
  def ValidParseSegs (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (cursor : Nat) (syms : List BNFSymbol) (args : List ConcreteParseArg)
      (endPos : Nat) (slots : List (BNFSlotTag × String)) (sums : List ParseSummary) : Prop :=
    match syms, args with
    | [], [] =>
      cursor ≤ Y.length ∧ endPos = cursor ∧ slots = [] ∧ sums = []
    | .term lit :: restSyms, .litTok txt sp :: restArgs =>
      txt = lit ∧
      sp.startCp = cursor ∧
      SpanMatches Y sp txt.toList ∧
      ValidParseSegs cat numCfg env Y loc sp.endCp restSyms restArgs endPos slots sums
    | .lexSlot srt tag :: restSyms, .slotTok aSrt aTag eid lex sp :: restArgs =>
      ∃ restSlots : List (BNFSlotTag × String),
        aSrt = srt ∧
        aTag = tag ∧
        sp.startCp = cursor ∧
        SpanMatches Y sp lex.toList ∧
        DeclarativeSlotValid cat numCfg Y.length srt eid lex ∧
        slots = (tag, eid) :: restSlots ∧
        ValidParseSegs cat numCfg env Y loc sp.endCp restSyms restArgs endPos restSlots sums
    | .nonterm childNt cIdx :: restSyms, .childSub sub :: restArgs =>
      ∃ (subSum : ParseSummary) (restSums : List ParseSummary),
        sub.span.startCp = cursor ∧
        ValidParseNode cat numCfg env Y ((clauseOverrideOfIdx cIdx).getD loc) childNt sub subSum ∧
        sums = subSum :: restSums ∧
        ValidParseSegs cat numCfg env Y loc sub.span.endCp restSyms restArgs endPos slots restSums
    | _, _ => False

  def ValidParseNode (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (env : ScopeEnv) (Y : List Char) (expectedLoc : ClauseLocus)
      (expectedNt : BNFNonterm) (tree : ConcreteParseTree) (outSum : ParseSummary) : Prop :=
    match tree with
    | .mkTree p alt loc sp args =>
      let sig := frozenProdSig p
      ∃ (slots : List (BNFSlotTag × String)) (sums : List ParseSummary),
        loc = expectedLoc ∧
        sig.lhs = expectedNt ∧
        1 ≤ alt ∧ alt ≤ p.altCount ∧
        ValidParseSegs cat numCfg env Y loc sp.startCp sig.rhs args sp.endCp slots sums ∧
        sig.checkSide env slots sums = true ∧
        outSum = sig.mkSum slots sums
end

/--
  **Root Declarative Frozen Parse Relation (`ValidParse_GFrozen`)**:
  Holds iff `rawBytes` is in the supported 7-bit printable ASCII domain, `tree` spans `[0, |Y|)`,
  and `tree` is a valid root `controlledDocument` parse tree at `clause1`.
-/
def ValidParse_GFrozen (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (rawBytes : List UInt8) (tree : ConcreteParseTree) : Prop :=
  let Y := (decodeAsciiBytes rawBytes).toList
  StrictAsciiDomainSupported rawBytes ∧
  tree.span = ⟨0, Y.length⟩ ∧
  ∃ sum : ParseSummary, ValidParseNode cat numCfg env Y .clause1 .controlledDocument tree sum

/-! ### 5. Yield Identity Theorem for `ValidParse_GFrozen` -/

mutual
  theorem validParseSegs_spanMatches
      {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {syms : List BNFSymbol}
      (args : List ConcreteParseArg)
      {slots : List (BNFSlotTag × String)} {sums : List ParseSummary}
      (h : ValidParseSegs cat numCfg env Y loc cursor syms args endPos slots sums) :
      SpanMatches Y ⟨cursor, endPos⟩ (reconstructParseSegChars args) := by
    match syms, args with
    | [], [] =>
      rcases h with ⟨hle, rfl, _, _⟩
      simpa [reconstructParseSegChars] using spanMatches_empty hle
    | .term _ :: _, .litTok txt sp :: restArgs =>
      rcases h with ⟨_, hstart, hspan, hrest⟩
      have hih := validParseSegs_spanMatches restArgs hrest
      rcases sp with ⟨sCp, eCp⟩
      dsimp at hstart
      subst hstart
      simpa [reconstructParseSegChars] using spanMatches_concat hspan hih
    | .lexSlot _ _ :: _, .slotTok _ _ _ lex sp :: restArgs =>
      rcases h with ⟨_, _, _, hstart, hspan, _, _, hrest⟩
      have hih := validParseSegs_spanMatches restArgs hrest
      rcases sp with ⟨sCp, eCp⟩
      dsimp at hstart
      subst hstart
      simpa [reconstructParseSegChars] using spanMatches_concat hspan hih
    | .nonterm _ _ :: _, .childSub sub :: restArgs =>
      rcases h with ⟨_, _, hstart, hsub, _, hrest⟩
      have hsub_sp := validParseNode_spanMatches sub hsub
      have hih := validParseSegs_spanMatches restArgs hrest
      cases sub with
      | mkTree p a l sp sargs =>
        rcases sp with ⟨sCp, eCp⟩
        dsimp [ConcreteParseTree.span] at hstart hsub_sp hrest hih
        subst hstart
        simpa [reconstructParseSegChars] using spanMatches_concat hsub_sp hih
    | [], _ :: _ => exact False.elim h
    | .term _ :: _, [] => exact False.elim h
    | .lexSlot _ _ :: _, [] => exact False.elim h
    | .nonterm _ _ :: _, [] => exact False.elim h
    | .term _ :: _, .slotTok _ _ _ _ _ :: _ => exact False.elim h
    | .term _ :: _, .childSub _ :: _ => exact False.elim h
    | .lexSlot _ _ :: _, .litTok _ _ :: _ => exact False.elim h
    | .lexSlot _ _ :: _, .childSub _ :: _ => exact False.elim h
    | .nonterm _ _ :: _, .litTok _ _ :: _ => exact False.elim h
    | .nonterm _ _ :: _, .slotTok _ _ _ _ _ :: _ => exact False.elim h

  theorem validParseNode_spanMatches
      {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {nt : BNFNonterm}
      (tree : ConcreteParseTree) {sum : ParseSummary}
      (h : ValidParseNode cat numCfg env Y loc nt tree sum) :
      SpanMatches Y tree.span (reconstructParseChars tree) := by
    cases tree with
    | mkTree p alt l sp args =>
      rcases h with ⟨slots, sums, _, _, _, _, hsegs, _, _⟩
      simpa [reconstructParseChars, ConcreteParseTree.span] using
        validParseSegs_spanMatches args hsegs
end

theorem validParse_GFrozen_yield_eq
    {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {env : ScopeEnv} {rawBytes : List UInt8} {tree : ConcreteParseTree}
    (h : ValidParse_GFrozen cat numCfg env rawBytes tree) :
    reconstructParseYield tree = decodeAsciiBytes rawBytes := by
  rcases h with ⟨_, hroot_sp, sum, hnode⟩
  have hm := validParseNode_spanMatches tree hnode
  rw [hroot_sp] at hm
  have hchars := spanMatches_full_eq hm
  unfold reconstructParseYield
  rw [hchars, String.ofList_toList]

end BrocaOmega.P3B
