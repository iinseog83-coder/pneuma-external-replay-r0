/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01` & `BridgeSound`)
  02_detached_checker/P3BDetachedChecker.lean
-/
import P3BDetachedChecker.BoundedParser
import P3BDetachedChecker.LexicalReplayBridge
