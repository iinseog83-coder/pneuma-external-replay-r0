/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`PO-C1-01`: Bounded Exhaustive Parser Soundness & Completeness)
  02_detached_checker/P3BDetachedChecker/BoundedParser.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  Gate B & Gate C Deliverable:
  1. Formal `ResourceBudget` (`maxBytes`, `maxSteps`, `maxForestNodes`, `maxReadings`) as part of
     the explicit parser contract.
  2. Strict 3-way `BoundedParseResult`:
       - `enumerated (trees)`       : Exhaustive parse enumeration completed within budget
       - `outOfDomain (diag)`       : Raw bytes outside 7-bit printable ASCII domain (`≠ ¬ValidParse`)
       - `resourceOverflow (reason)`: Formal budget exceeded (`fail-closed`, partial trees discarded)
  3. Duplicate-free deterministic enumeration (`NoDupTrees`) preserving `T2`'s two semantic readings
     (`readingAlt = 1` vs `readingAlt = 2`) and `T1` / `T4` dual readings without adding rule IDs.
  4. Machine-checked `PO-C1-01` Soundness, Bounded Exhaustive Completeness, `OutOfDomain` boundary
     soundness, and `ResourceOverflow` fail-closed separation.
-/
import P3BFormalSpec
import P3DetachedChecker

namespace BrocaOmega.P3B

open BrocaOmega.P2
open BrocaOmega.P3A

/-! ### 1. Formal Resource Budget & 3-Way Bounded Parse Result (`Gate B`) -/

/--
  Formal resource budget governing `parseAllBounded`.
  Every dimension is actively metered and enforced fail-closed during parsing.
-/
structure ResourceBudget where
  maxBytes       : Nat
  maxSteps       : Nat
  maxForestNodes : Nat
  maxReadings    : Nat
  deriving DecidableEq, Repr

/-- Standard reference budget for single- and two-clause controlled clinical sentences (`≤ 512` bytes). -/
def defaultParseBudget : ResourceBudget :=
  { maxBytes       := 512
    maxSteps       := 4000
    maxForestNodes := 512
    maxReadings    := 16 }

/-- Domain-boundary rejection diagnostic (`rawBytes` outside supported 7-bit printable ASCII profile). -/
inductive OutOfDomainDiag where
  | emptyInput
  | nonPrintableAsciiByte (byteVal : UInt8)
  deriving DecidableEq, Repr

/-- Resource-budget exhaustion reason (strictly distinct from grammatical non-derivability!). -/
inductive OverflowReason where
  | maxBytesExceeded       (actual maxBytes : Nat)
  | maxStepsExceeded       (maxSteps : Nat)
  | maxForestNodesExceeded (maxForestNodes : Nat)
  | maxReadingsExceeded    (actual maxReadings : Nat)
  deriving DecidableEq, Repr

/--
  Strict 3-state outcome of `parseAllBounded`:
  - `enumerated T`       : `T` is the sound, complete, duplicate-free set of all `ValidParse_GFrozen` trees
                           (`T = []` iff input is in-domain and has zero valid parses).
  - `outOfDomain d`      : `¬ StrictAsciiDomainSupported rawBytes` (makes no claim on `G_parse` outside domain).
  - `resourceOverflow b` : Budget `b` exhausted; partial trees discarded fail-closed.
-/
inductive BoundedParseResult where
  | enumerated       (trees : List ConcreteParseTree)
  | outOfDomain      (diag : OutOfDomainDiag)
  | resourceOverflow (reason : OverflowReason)
  deriving DecidableEq

/-! ### 2. Generic List, Range, and Duplicate-Free Forest Helpers -/

def flatMapList {α β : Type} : List α → (α → List β) → List β
  | [], _ => []
  | x :: xs, f => f x ++ flatMapList xs f

theorem mem_flatMapList_iff {α β : Type} (xs : List α) (f : α → List β) (b : β) :
    b ∈ flatMapList xs f ↔ ∃ a ∈ xs, b ∈ f a := by
  induction xs with
  | nil => simp [flatMapList]
  | cons x rest ih => simp [flatMapList, ih]

def rangeClosed (lo hi : Nat) : List Nat :=
  if hi < lo then []
  else (List.range (hi - lo + 1)).map (fun i => lo + i)

theorem mem_rangeClosed_iff (lo hi m : Nat) :
    m ∈ rangeClosed lo hi ↔ lo ≤ m ∧ m ≤ hi := by
  unfold rangeClosed
  by_cases hlt : hi < lo
  · rw [if_pos hlt]
    simp
    omega
  · rw [if_neg hlt]
    simp only [List.mem_map, List.mem_range]
    constructor
    · rintro ⟨i, _, rfl⟩
      omega
    · rintro ⟨hlo, hhi⟩
      exact ⟨m - lo, by omega, by omega⟩

/-- Duplicate-freeness predicate over `List ConcreteParseTree`. -/
def NoDupTrees : List ConcreteParseTree → Prop
  | [] => True
  | t :: ts => t ∉ ts ∧ NoDupTrees ts

/-- Deterministic order-preserving deduplication (`[alt=1, alt=2]` order preserved). -/
def dedupTrees : List ConcreteParseTree → List ConcreteParseTree
  | [] => []
  | t :: ts => t :: (dedupTrees ts).filter (fun x => !parseTreeEqBool x t)

theorem mem_dedupTrees_iff (xs : List ConcreteParseTree) (x : ConcreteParseTree) :
    x ∈ dedupTrees xs ↔ x ∈ xs := by
  induction xs with
  | nil => rfl
  | cons t ts ih =>
    unfold dedupTrees
    simp only [List.mem_cons, List.mem_filter]
    by_cases hxt : x = t
    · subst x
      simp
    · have hneq : (!parseTreeEqBool x t) = true := by
        cases hb : parseTreeEqBool x t
        · rfl
        · exfalso; exact hxt ((parseTreeEqBool_iff x t).mp hb)
      simp [hxt, hneq, ih]

private theorem noDupTrees_filter (p : ConcreteParseTree → Bool) (xs : List ConcreteParseTree)
    (h : NoDupTrees xs) : NoDupTrees (xs.filter p) := by
  induction xs with
  | nil => trivial
  | cons x ts ih =>
    rcases h with ⟨hx_not, hts⟩
    unfold List.filter
    cases hp : p x
    · exact ih hts
    · refine ⟨?_, ih hts⟩
      intro hmem
      exact hx_not (List.mem_filter.mp hmem).1

theorem dedupTrees_nodup (xs : List ConcreteParseTree) : NoDupTrees (dedupTrees xs) := by
  induction xs with
  | nil => trivial
  | cons t ts ih =>
    unfold dedupTrees
    refine ⟨?_, noDupTrees_filter _ _ ih⟩
    intro hmem
    have hf := (List.mem_filter.mp hmem).2
    have hrefl : parseTreeEqBool t t = true := (parseTreeEqBool_iff t t).mpr rfl
    rw [hrefl] at hf
    contradiction

/-! ### 3. Domain Check, Slot Enumeration & Split-Point Lookahead Equivalence -/

def checkAsciiDomainOnly (rawBytes : List UInt8) : Except OutOfDomainDiag Unit :=
  if rawBytes.isEmpty then
    .error .emptyInput
  else
    match findBadAsciiByte rawBytes with
    | some bad => .error (.nonPrintableAsciiByte bad)
    | none     => .ok ()

theorem checkAsciiDomainOnly_ok_iff (rawBytes : List UInt8) :
    checkAsciiDomainOnly rawBytes = .ok () ↔ StrictAsciiDomainSupported rawBytes := by
  unfold checkAsciiDomainOnly StrictAsciiDomainSupported
  cases rawBytes with
  | nil => simp
  | cons b bs =>
    have hne : (b :: bs).isEmpty = false := rfl
    rw [if_neg (by simp [hne])]
    cases hbad : findBadAsciiByte (b :: bs) with
    | some bad =>
      constructor
      · intro h; contradiction
      · rintro ⟨_, hall⟩
        have hnone := (findBadAsciiByte_eq_none_iff (b :: bs)).mpr hall
        rw [hbad] at hnone
        contradiction
    | none =>
      have hall := (findBadAsciiByte_eq_none_iff (b :: bs)).mp hbad
      exact ⟨fun _ => ⟨by simp, hall⟩, fun _ => rfl⟩

theorem checkAsciiDomainOnly_err_sound (rawBytes : List UInt8) (d : OutOfDomainDiag)
    (herr : checkAsciiDomainOnly rawBytes = .error d) :
    ¬ StrictAsciiDomainSupported rawBytes := by
  intro hsup
  have hok := (checkAsciiDomainOnly_ok_iff rawBytes).mpr hsup
  rw [herr] at hok
  contradiction

def eqCharsBool : List Char → List Char → Bool
  | [], [] => true
  | c1 :: r1, c2 :: r2 => (c1.val == c2.val) && eqCharsBool r1 r2
  | _, _ => false

theorem eqCharsBool_iff (xs ys : List Char) :
    eqCharsBool xs ys = true ↔ xs = ys := by
  induction xs generalizing ys with
  | nil =>
    cases ys <;> simp [eqCharsBool]
  | cons x rx ih =>
    cases ys with
    | nil => simp [eqCharsBool]
    | cons y ry =>
      unfold eqCharsBool
      rw [Bool.and_eq_true, beq_iff_eq, ← Char.ext_iff, ih]
      simp

def eqStrBool (s1 s2 : String) : Bool :=
  eqCharsBool s1.toList s2.toList

theorem eqStrBool_iff (s1 s2 : String) :
    eqStrBool s1 s2 = true ↔ s1 = s2 := by
  unfold eqStrBool
  rw [eqCharsBool_iff, String.ext_iff]

def fastSpanMatchesBool (Y : List Char) (sp : CodepointSpan) (seg : List Char) : Bool :=
  (sp.endCp == sp.startCp + seg.length) &&
  (sp.endCp ≤ Y.length) &&
  eqCharsBool ((Y.drop sp.startCp).take seg.length) seg

theorem fastSpanMatchesBool_iff (Y : List Char) (sp : CodepointSpan) (seg : List Char) :
    fastSpanMatchesBool Y sp seg = true ↔ SpanMatches Y sp seg := by
  have h1 : fastSpanMatchesBool Y sp seg = true ↔ checkSpanMatchesBool Y sp seg = true := by
    unfold fastSpanMatchesBool checkSpanMatchesBool
    simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq, eqCharsBool_iff]
  rw [h1]
  exact ⟨checkSpanMatchesBool_sound, spanMatches_implies_checkBool⟩

/-- Finite candidate entity IDs for `(srt, lex)` determined by the 3 closed lexical regimes of `P3-A`. -/
def candidateSlotEntityIds (cat : ClosedEntityCatalog) (srt : P3SlotSort) (lex : String) : List String :=
  match srt.regime with
  | .openEntityCatalog =>
    (cat.entries.filter (fun e => (e.sort == srt) && eqStrBool e.lexeme lex)).map (·.entityId)
  | .closedFunctionalEnum =>
    (closedFunctionalEntries.filter (fun p => (p.1 == srt) && eqStrBool p.2.2 lex)).map (fun p => p.2.1)
  | .canonicalDecimal =>
    [lex]

/-- Executable slot validator delegating directly to `BrocaOmega.P3A.evalLexicalSlot`. -/
def checkSlotValidBool (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (eid lex : String) : Bool :=
  let cand : RawSlotCandidate := { sort := srt, entityId := eid, rawBytes := strToAsciiBytes lex }
  eqStrBool cand.decodedStr lex &&
  match evalLexicalSlot cat numCfg maxSlotBytes cand with
  | .ok _    => true
  | .error _ => false

theorem checkSlotValidBool_iff (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (eid lex : String) :
    checkSlotValidBool cat numCfg maxSlotBytes srt eid lex = true ↔
      DeclarativeSlotValid cat numCfg maxSlotBytes srt eid lex := by
  unfold checkSlotValidBool DeclarativeSlotValid
  dsimp only
  rw [Bool.and_eq_true, eqStrBool_iff]
  let cand : RawSlotCandidate := { sort := srt, entityId := eid, rawBytes := strToAsciiBytes lex }
  constructor
  · rintro ⟨hdec, hok_b⟩
    cases hev : evalLexicalSlot cat numCfg maxSlotBytes cand with
    | error e => rw [hev] at hok_b; contradiction
    | ok payload =>
      have hs := evalLexicalSlot_sound cat numCfg maxSlotBytes cand payload hev
      exact ⟨hdec, hs.2.1, hs.2.2.1, hs.2.2.2⟩
  · rintro ⟨hdec, hLex, hNum, hBound⟩
    rcases evalLexicalSlot_complete cat numCfg maxSlotBytes cand hLex hNum hBound with ⟨payload, hev⟩
    refine ⟨hdec, ?_⟩
    rw [hev]

def validSlotEntityIds (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (lex : String) : List String :=
  (candidateSlotEntityIds cat srt lex).filter (fun eid =>
    checkSlotValidBool cat numCfg maxSlotBytes srt eid lex)

theorem mem_validSlotEntityIds_iff (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (srt : P3SlotSort) (eid lex : String) :
    eid ∈ validSlotEntityIds cat numCfg maxSlotBytes srt lex ↔
      DeclarativeSlotValid cat numCfg maxSlotBytes srt eid lex := by
  unfold validSlotEntityIds
  rw [List.mem_filter, checkSlotValidBool_iff]
  constructor
  · exact And.right
  · intro hdsv
    refine ⟨?_, hdsv⟩
    rcases hdsv with ⟨hdec, _, hNum, hBound⟩
    unfold candidateSlotEntityIds EntityCatalogBound at *
    have hrefl_lex : eqStrBool lex lex = true := (eqStrBool_iff lex lex).mpr rfl
    cases hreg : srt.regime with
    | openEntityCatalog =>
      rw [hreg] at hBound
      dsimp at hBound ⊢
      rcases hBound with ⟨_, hmem⟩
      rw [hdec] at hmem
      rw [List.mem_map]
      refine ⟨⟨srt, eid, lex⟩, ?_, rfl⟩
      rw [List.mem_filter]
      exact ⟨hmem, by simp [hrefl_lex]⟩
    | closedFunctionalEnum =>
      rw [hreg] at hBound
      dsimp at hBound ⊢
      rw [hdec] at hBound
      rw [List.mem_map]
      refine ⟨(srt, eid, lex), ?_, rfl⟩
      rw [List.mem_filter]
      exact ⟨hBound, by simp [hrefl_lex]⟩
    | canonicalDecimal =>
      dsimp
      have hsrt : srt = .numericLit := by
        cases hs : srt <;> simp [hs, P3SlotSort.regime] at hreg
        rfl
      rcases hNum hsrt with ⟨heid_eq, _⟩
      dsimp at heid_eq
      rw [hdec] at heid_eq
      simp [heid_eq]

/-- Span-monotonicity lemma (`cursor ≤ endPos ∧ endPos ≤ Y.length`) for any `ValidParseSegs`. -/
theorem validParseSegs_bounds
    {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
    {cursor endPos : Nat} {syms : List BNFSymbol}
    {args : List ConcreteParseArg} {slots : List (BNFSlotTag × String)} {sums : List ParseSummary}
    (h : ValidParseSegs cat numCfg env Y loc cursor syms args endPos slots sums) :
    cursor ≤ endPos ∧ endPos ≤ Y.length := by
  have hsp := validParseSegs_spanMatches args h
  rcases hsp with ⟨hend, pre, post, hy, hpre⟩
  dsimp at hend hpre
  have hlen : Y.length = pre.length + (reconstructParseSegChars args).length + post.length := by
    rw [hy, List.length_append, List.length_append]
  omega

/--
  Sound & Complete Split-Point Lookahead (`candidateSplitPositions`):
  - When `restSyms = []`, the split MUST equal `endPos`.
  - When `restSyms = .term lit :: _`, `Y` MUST match `lit` right at `mid` with `mid + |lit| ≤ endPos`.
  - Otherwise enumerates `rangeClosed cursor endPos`.
-/
def candidateSplitPositions (Y : List Char) (cursor endPos : Nat) (restSyms : List BNFSymbol) : List Nat :=
  match restSyms with
  | [] =>
    if cursor ≤ endPos then [endPos] else []
  | .term lit :: _ =>
    let lcs := lit.toList
    (rangeClosed cursor endPos).filter (fun mid =>
      (mid + lcs.length ≤ endPos) && eqCharsBool ((Y.drop mid).take lcs.length) lcs)
  | _ =>
    rangeClosed cursor endPos

theorem validParseSegs_mem_candidateSplitPositions
    {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
    {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
    {cursor mid endPos : Nat} {restSyms : List BNFSymbol}
    {restArgs : List ConcreteParseArg} {slots : List (BNFSlotTag × String)} {sums : List ParseSummary}
    (hcur : cursor ≤ mid)
    (hrest : ValidParseSegs cat numCfg env Y loc mid restSyms restArgs endPos slots sums) :
    mid ∈ candidateSplitPositions Y cursor endPos restSyms := by
  have ⟨hmid_end, _⟩ := validParseSegs_bounds hrest
  cases restSyms with
  | nil =>
    cases restArgs with
    | nil =>
      rcases hrest with ⟨_, hend_eq, _, _⟩
      subst endPos
      simp [candidateSplitPositions, hcur]
    | cons _ _ => exact False.elim hrest
  | cons sym tailSyms =>
    cases sym with
    | term lit =>
      cases restArgs with
      | nil => exact False.elim hrest
      | cons a tailArgs =>
        cases a with
        | litTok txt spLit =>
          rcases hrest with ⟨htxt, hstart, hsp, htail⟩
          subst txt
          have ⟨htail_le, _⟩ := validParseSegs_bounds htail
          have hchk := spanMatches_implies_checkBool hsp
          unfold checkSpanMatchesBool at hchk
          simp [Bool.and_eq_true] at hchk
          rcases hchk with ⟨⟨hsp_end, _⟩, htake⟩
          rw [hstart] at hsp_end htake
          have hlen_end : mid + lit.toList.length ≤ endPos := by omega
          unfold candidateSplitPositions
          rw [List.mem_filter, mem_rangeClosed_iff]
          refine ⟨⟨hcur, hmid_end⟩, ?_⟩
          have heq_b : eqCharsBool ((Y.drop mid).take lit.toList.length) lit.toList = true :=
            (eqCharsBool_iff _ _).mpr htake
          simp [hlen_end, heq_b]
        | slotTok _ _ _ _ _ => exact False.elim hrest
        | childSub _ => exact False.elim hrest
    | lexSlot _ _ =>
      unfold candidateSplitPositions
      exact (mem_rangeClosed_iff cursor endPos mid).mpr ⟨hcur, hmid_end⟩
    | nonterm _ _ =>
      unfold candidateSplitPositions
      exact (mem_rangeClosed_iff cursor endPos mid).mpr ⟨hcur, hmid_end⟩

/-! ### 4. Pure Level-Indexed Reference Enumerator & Exact Soundness + Completeness Proof -/

def enumSegsWith
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig) (Y : List Char)
    (childEnum : ClauseLocus → BNFNonterm → Nat → Nat → List (ConcreteParseTree × ParseSummary))
    (loc : ClauseLocus) (cursor : Nat) (syms : List BNFSymbol) (endPos : Nat) :
    List (List ConcreteParseArg × List (BNFSlotTag × String) × List ParseSummary) :=
  match syms with
  | [] =>
    if (cursor ≤ Y.length) && (endPos == cursor) then
      [([], [], [])]
    else
      []
  | .term lit :: restSyms =>
    let lcs := lit.toList
    let sp : CodepointSpan := ⟨cursor, cursor + lcs.length⟩
    if fastSpanMatchesBool Y sp lcs then
      (enumSegsWith cat numCfg Y childEnum loc sp.endCp restSyms endPos).map fun (rArgs, rSlots, rSums) =>
        (.litTok lit sp :: rArgs, rSlots, rSums)
    else
      []
  | .lexSlot srt tag :: restSyms =>
    if endPos ≤ Y.length then
      flatMapList (candidateSplitPositions Y cursor endPos restSyms) fun mid =>
        let sliceCs := (Y.drop cursor).take (mid - cursor)
        let lex := String.ofList sliceCs
        let sp : CodepointSpan := ⟨cursor, mid⟩
        if fastSpanMatchesBool Y sp lex.toList then
          let validEids := validSlotEntityIds cat numCfg Y.length srt lex
          let tails := enumSegsWith cat numCfg Y childEnum loc mid restSyms endPos
          flatMapList validEids fun eid =>
            tails.map fun (rArgs, rSlots, rSums) =>
              (.slotTok srt tag eid lex sp :: rArgs, (tag, eid) :: rSlots, rSums)
        else
          []
    else
      []
  | .nonterm childNt cIdx :: restSyms =>
    let childLoc := (clauseOverrideOfIdx cIdx).getD loc
    flatMapList (candidateSplitPositions Y cursor endPos restSyms) fun mid =>
      let children := childEnum childLoc childNt cursor mid
      let tails := enumSegsWith cat numCfg Y childEnum loc mid restSyms endPos
      flatMapList children fun (subTree, subSum) =>
        tails.map fun (rArgs, rSlots, rSums) =>
          (.childSub subTree :: rArgs, rSlots, subSum :: rSums)

def enumNodeRef : Nat → ClosedEntityCatalog → NumericGateConfig → ScopeEnv → List Char →
    ClauseLocus → BNFNonterm → Nat → Nat → List (ConcreteParseTree × ParseSummary)
  | 0, _, _, _, _, _, _, _, _ => []
  | fuel + 1, cat, numCfg, env, Y, expectedLoc, expectedNt, startPos, endPos =>
    flatMapList allFrozenParseProds fun p =>
      let sig := frozenProdSig p
      if sig.lhs == expectedNt then
        let segResults := enumSegsWith cat numCfg Y (enumNodeRef fuel cat numCfg env Y)
                            expectedLoc startPos sig.rhs endPos
        flatMapList segResults fun (args, slots, sums) =>
          if sig.checkSide env slots sums then
            let outSum := sig.mkSum slots sums
            (rangeClosed 1 p.altCount).map fun alt =>
              (ConcreteParseTree.mkTree p alt expectedLoc ⟨startPos, endPos⟩ args, outSum)
          else
            []
      else
        []

theorem mem_enumSegsWith_iff
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig) (env : ScopeEnv) (Y : List Char)
    (childEnum : ClauseLocus → BNFNonterm → Nat → Nat → List (ConcreteParseTree × ParseSummary))
    (syms : List BNFSymbol)
    (hChild : ∀ (cLoc : ClauseLocus) (cNt : BNFNonterm),
      (∃ cIdx, BNFSymbol.nonterm cNt cIdx ∈ syms) →
      ∀ (sPos ePos : Nat) (sub : ConcreteParseTree) (subSum : ParseSummary),
        (sub, subSum) ∈ childEnum cLoc cNt sPos ePos ↔
          (sub.span = ⟨sPos, ePos⟩ ∧ ValidParseNode cat numCfg env Y cLoc cNt sub subSum))
    (loc : ClauseLocus) (cursor endPos : Nat)
    (args : List ConcreteParseArg) (slots : List (BNFSlotTag × String)) (sums : List ParseSummary) :
    (args, slots, sums) ∈ enumSegsWith cat numCfg Y childEnum loc cursor syms endPos ↔
      ValidParseSegs cat numCfg env Y loc cursor syms args endPos slots sums := by
  induction syms generalizing cursor args slots sums with
  | nil =>
    unfold enumSegsWith ValidParseSegs
    cases args with
    | nil =>
      by_cases hcond : ((cursor ≤ Y.length) && (endPos == cursor)) = true
      · rw [if_pos hcond]
        simp [Bool.and_eq_true, beq_iff_eq] at hcond
        simp [hcond.1, hcond.2]
      · rw [if_neg hcond]
        simp [Bool.and_eq_true, beq_iff_eq] at hcond
        constructor
        · intro hm; simp at hm
        · rintro ⟨hle, hend, _, _⟩
          exact False.elim (hcond hle hend)
    | cons _ _ =>
      by_cases hcond : ((cursor ≤ Y.length) && (endPos == cursor)) = true
      · rw [if_pos hcond]; simp
      · rw [if_neg hcond]; simp
  | cons sym restSyms ih =>
    have hChildRest : ∀ (cLoc : ClauseLocus) (cNt : BNFNonterm),
        (∃ cIdx, BNFSymbol.nonterm cNt cIdx ∈ restSyms) →
        ∀ (sPos ePos : Nat) (sub : ConcreteParseTree) (subSum : ParseSummary),
          (sub, subSum) ∈ childEnum cLoc cNt sPos ePos ↔
            (sub.span = ⟨sPos, ePos⟩ ∧ ValidParseNode cat numCfg env Y cLoc cNt sub subSum) := by
      intro cLoc cNt ⟨cIdx, hm⟩
      exact hChild cLoc cNt ⟨cIdx, List.Mem.tail sym hm⟩
    cases sym with
    | term lit =>
      unfold enumSegsWith
      dsimp only
      let sp : CodepointSpan := ⟨cursor, cursor + lit.toList.length⟩
      constructor
      · intro hmem
        by_cases hchk : fastSpanMatchesBool Y sp lit.toList = true
        · rw [if_pos hchk, List.mem_map] at hmem
          rcases hmem with ⟨⟨rArgs, rSlots, rSums⟩, hm_tail, heq⟩
          injection heq with ha h1
          injection h1 with hsl hsm
          subst args; subst slots; subst sums
          have hsp : SpanMatches Y sp lit.toList := (fastSpanMatchesBool_iff Y sp lit.toList).mp hchk
          have hvalid_tail := (ih hChildRest sp.endCp rArgs rSlots rSums).mp hm_tail
          exact ⟨rfl, rfl, hsp, hvalid_tail⟩
        · rw [if_neg hchk] at hmem
          simp at hmem
      · intro hval
        cases args with
        | nil => exact False.elim hval
        | cons a rArgs =>
          cases a with
          | litTok txt sp0 =>
            rcases hval with ⟨htxt, hstart, hsp0, hrest⟩
            subst txt
            have hend0 : sp0.endCp = cursor + lit.toList.length := by
              rcases hsp0 with ⟨he, _⟩
              omega
            have hsp_eq : sp0 = sp := by
              cases sp0
              dsimp at hstart hend0
              subst hstart; subst hend0
              rfl
            subst sp0
            have hchk : fastSpanMatchesBool Y sp lit.toList = true :=
              (fastSpanMatchesBool_iff Y sp lit.toList).mpr hsp0
            rw [if_pos hchk, List.mem_map]
            exact ⟨(rArgs, slots, sums), (ih hChildRest sp.endCp rArgs slots sums).mpr hrest, rfl⟩
          | slotTok _ _ _ _ _ => exact False.elim hval
          | childSub _ => exact False.elim hval
    | lexSlot srt tag =>
      unfold enumSegsWith
      dsimp only
      constructor
      · intro hmem
        by_cases hend_le : endPos ≤ Y.length
        · rw [if_pos hend_le, mem_flatMapList_iff] at hmem
          rcases hmem with ⟨mid, _, hmid_mem⟩
          let lex := String.ofList ((Y.drop cursor).take (mid - cursor))
          let sp : CodepointSpan := ⟨cursor, mid⟩
          by_cases hchk : fastSpanMatchesBool Y sp lex.toList = true
          · rw [if_pos hchk, mem_flatMapList_iff] at hmid_mem
            rcases hmid_mem with ⟨eid, heid_mem, hmap_mem⟩
            rw [List.mem_map] at hmap_mem
            rcases hmap_mem with ⟨⟨rArgs, rSlots, rSums⟩, hm_tail, heq⟩
            injection heq with ha h1
            injection h1 with hsl hsm
            subst args; subst slots; subst sums
            have hsp : SpanMatches Y sp lex.toList := (fastSpanMatchesBool_iff Y sp lex.toList).mp hchk
            have hdsv := (mem_validSlotEntityIds_iff cat numCfg Y.length srt eid lex).mp heid_mem
            have hvalid_tail := (ih hChildRest mid rArgs rSlots rSums).mp hm_tail
            exact ⟨rSlots, rfl, rfl, rfl, hsp, hdsv, rfl, hvalid_tail⟩
          · rw [if_neg hchk] at hmid_mem
            simp at hmid_mem
        · rw [if_neg hend_le] at hmem
          simp at hmem
      · intro hval
        cases args with
        | nil => exact False.elim hval
        | cons a rArgs =>
          cases a with
          | litTok _ _ => exact False.elim hval
          | childSub _ => exact False.elim hval
          | slotTok aSrt aTag eid lex0 sp0 =>
            rcases hval with ⟨rSlots, hsrt, htag, hstart, hsp0, hdsv, hslots, hrest⟩
            subst aSrt; subst aTag; subst slots
            have ⟨_, hend_le⟩ := validParseSegs_bounds hrest
            rw [if_pos hend_le, mem_flatMapList_iff]
            have hcur_le : cursor ≤ sp0.endCp := by
              rcases hsp0 with ⟨he, _⟩
              omega
            have hmid_cand := validParseSegs_mem_candidateSplitPositions hcur_le hrest
            refine ⟨sp0.endCp, hmid_cand, ?_⟩
            have hchk0 := spanMatches_implies_checkBool hsp0
            unfold checkSpanMatchesBool at hchk0
            simp [Bool.and_eq_true] at hchk0
            rcases hchk0 with ⟨⟨hsp0_end, _⟩, htake0⟩
            have hlen_diff : sp0.endCp - cursor = lex0.toList.length := by omega
            have hslice_eq : (Y.drop cursor).take (sp0.endCp - cursor) = lex0.toList := by
              rw [hlen_diff, ← hstart]
              exact htake0
            have hlex_eq : String.ofList ((Y.drop cursor).take (sp0.endCp - cursor)) = lex0 := by
              rw [hslice_eq, String.ofList_toList]
            have hsp_eq : (⟨cursor, sp0.endCp⟩ : CodepointSpan) = sp0 := by
              cases sp0
              dsimp at hstart
              subst hstart
              rfl
            rw [hlex_eq, hsp_eq]
            have hchk_sp0 : fastSpanMatchesBool Y sp0 lex0.toList = true :=
              (fastSpanMatchesBool_iff Y sp0 lex0.toList).mpr hsp0
            rw [if_pos hchk_sp0, mem_flatMapList_iff]
            refine ⟨eid, (mem_validSlotEntityIds_iff cat numCfg Y.length srt eid lex0).mpr hdsv, ?_⟩
            rw [List.mem_map]
            exact ⟨(rArgs, rSlots, sums), (ih hChildRest sp0.endCp rArgs rSlots sums).mpr hrest, rfl⟩
    | nonterm childNt cIdx =>
      unfold enumSegsWith
      dsimp only
      let childLoc := (clauseOverrideOfIdx cIdx).getD loc
      have hChildHere := hChild childLoc childNt ⟨cIdx, List.Mem.head restSyms⟩
      constructor
      · intro hmem
        rw [mem_flatMapList_iff] at hmem
        rcases hmem with ⟨mid, _, hmid_mem⟩
        rw [mem_flatMapList_iff] at hmid_mem
        rcases hmid_mem with ⟨⟨subTree, subSum⟩, hsub_mem, hmap_mem⟩
        rw [List.mem_map] at hmap_mem
        rcases hmap_mem with ⟨⟨rArgs, rSlots, rSums⟩, hm_tail, heq⟩
        injection heq with ha h1
        injection h1 with hsl hsm
        subst args; subst slots; subst sums
        rcases (hChildHere cursor mid subTree subSum).mp hsub_mem with ⟨hsub_sp, hsub_valid⟩
        have hvalid_tail := (ih hChildRest mid rArgs rSlots rSums).mp hm_tail
        refine ⟨subSum, rSums, ?_, hsub_valid, rfl, ?_⟩
        · rw [hsub_sp]
        · rw [hsub_sp]
          exact hvalid_tail
      · intro hval
        cases args with
        | nil => exact False.elim hval
        | cons a rArgs =>
          cases a with
          | litTok _ _ => exact False.elim hval
          | slotTok _ _ _ _ _ => exact False.elim hval
          | childSub subTree =>
            rcases hval with ⟨subSum, rSums, hstart, hsub_valid, hsums_eq, hrest⟩
            subst sums
            have hsub_sp_match := validParseNode_spanMatches subTree hsub_valid
            have hcur_le : cursor ≤ subTree.span.endCp := by
              rcases hsub_sp_match with ⟨he, _⟩
              omega
            have hmid_cand := validParseSegs_mem_candidateSplitPositions hcur_le hrest
            rw [mem_flatMapList_iff]
            refine ⟨subTree.span.endCp, hmid_cand, ?_⟩
            rw [mem_flatMapList_iff]
            have hsp_eq : subTree.span = ⟨cursor, subTree.span.endCp⟩ := by
              cases hsp : subTree.span
              rw [hsp] at hstart
              dsimp at hstart
              subst hstart
              rfl
            refine ⟨(subTree, subSum), (hChildHere cursor subTree.span.endCp subTree subSum).mpr ⟨hsp_eq, hsub_valid⟩, ?_⟩
            rw [List.mem_map]
            exact ⟨(rArgs, slots, rSums), (ih hChildRest subTree.span.endCp rArgs slots rSums).mpr hrest, rfl⟩

/--
  **Exact Stratification Soundness & Completeness of `enumNodeRef`**:
  Whenever `expectedNt.level < fuel`, `enumNodeRef fuel` enumerates ALL and ONLY
  `(tree, outSum)` pairs satisfying `tree.span = ⟨startPos, endPos⟩ ∧ ValidParseNode`.
-/
theorem mem_enumNodeRef_iff
    (fuel : Nat) (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (Y : List Char)
    (expectedLoc : ClauseLocus) (expectedNt : BNFNonterm)
    (hlvl : expectedNt.level < fuel)
    (startPos endPos : Nat) (tree : ConcreteParseTree) (outSum : ParseSummary) :
    (tree, outSum) ∈ enumNodeRef fuel cat numCfg env Y expectedLoc expectedNt startPos endPos ↔
      (tree.span = ⟨startPos, endPos⟩ ∧
       ValidParseNode cat numCfg env Y expectedLoc expectedNt tree outSum) := by
  induction fuel generalizing expectedLoc expectedNt startPos endPos tree outSum with
  | zero => omega
  | succ k ih =>
    unfold enumNodeRef
    rw [mem_flatMapList_iff]
    constructor
    · rintro ⟨p, _, hp_mem⟩
      dsimp only at hp_mem
      by_cases hlhs : ((frozenProdSig p).lhs == expectedNt) = true
      · rw [if_pos hlhs, mem_flatMapList_iff] at hp_mem
        rcases hp_mem with ⟨⟨args, slots, sums⟩, hseg_mem, hside_mem⟩
        dsimp only at hside_mem
        have hlhs_eq : (frozenProdSig p).lhs = expectedNt := beq_iff_eq.mp hlhs
        have hChild : ∀ (cLoc : ClauseLocus) (cNt : BNFNonterm),
            (∃ cIdx, BNFSymbol.nonterm cNt cIdx ∈ (frozenProdSig p).rhs) →
            ∀ (sPos ePos : Nat) (sub : ConcreteParseTree) (subSum : ParseSummary),
              (sub, subSum) ∈ enumNodeRef k cat numCfg env Y cLoc cNt sPos ePos ↔
                (sub.span = ⟨sPos, ePos⟩ ∧ ValidParseNode cat numCfg env Y cLoc cNt sub subSum) := by
          intro cLoc cNt ⟨cIdx, hmem_rhs⟩ sPos ePos sub subSum
          have hlt_p := frozenProdSig_child_level_lt p cNt cIdx hmem_rhs
          have hlt_k : cNt.level < k := by
            rw [hlhs_eq] at hlt_p
            omega
          exact ih cLoc cNt hlt_k sPos ePos sub subSum
        have hsegs := (mem_enumSegsWith_iff cat numCfg env Y _ (frozenProdSig p).rhs hChild expectedLoc startPos endPos args slots sums).mp hseg_mem
        by_cases hside : (frozenProdSig p).checkSide env slots sums = true
        · rw [if_pos hside, List.mem_map] at hside_mem
          rcases hside_mem with ⟨alt, halt_mem, heq⟩
          injection heq with htree hout
          subst tree; subst outSum
          rcases (mem_rangeClosed_iff 1 p.altCount alt).mp halt_mem with ⟨ha1, ha2⟩
          exact ⟨rfl, slots, sums, rfl, hlhs_eq, ha1, ha2, hsegs, hside, rfl⟩
        · rw [if_neg hside] at hside_mem
          simp at hside_mem
      · rw [if_neg hlhs] at hp_mem
        simp at hp_mem
    · rintro ⟨hsp_eq, hnode⟩
      cases tree with
      | mkTree p alt loc sp args =>
        dsimp [ConcreteParseTree.span] at hsp_eq
        subst sp
        rcases hnode with ⟨slots, sums, hloc, hlhs_eq, ha1, ha2, hsegs, hside, hout⟩
        subst loc; subst outSum
        refine ⟨p, allFrozenParseProds_nodup_and_complete p, ?_⟩
        have hlhs_b : ((frozenProdSig p).lhs == expectedNt) = true := beq_iff_eq.mpr hlhs_eq
        dsimp only
        rw [if_pos hlhs_b, mem_flatMapList_iff]
        have hChild : ∀ (cLoc : ClauseLocus) (cNt : BNFNonterm),
            (∃ cIdx, BNFSymbol.nonterm cNt cIdx ∈ (frozenProdSig p).rhs) →
            ∀ (sPos ePos : Nat) (sub : ConcreteParseTree) (subSum : ParseSummary),
              (sub, subSum) ∈ enumNodeRef k cat numCfg env Y cLoc cNt sPos ePos ↔
                (sub.span = ⟨sPos, ePos⟩ ∧ ValidParseNode cat numCfg env Y cLoc cNt sub subSum) := by
          intro cLoc cNt ⟨cIdx, hmem_rhs⟩ sPos ePos sub subSum
          have hlt_p := frozenProdSig_child_level_lt p cNt cIdx hmem_rhs
          have hlt_k : cNt.level < k := by
            rw [hlhs_eq] at hlt_p
            omega
          exact ih cLoc cNt hlt_k sPos ePos sub subSum
        have hseg_mem := (mem_enumSegsWith_iff cat numCfg env Y _ (frozenProdSig p).rhs hChild expectedLoc startPos endPos args slots sums).mpr hsegs
        refine ⟨(args, slots, sums), hseg_mem, ?_⟩
        dsimp only
        rw [if_pos hside, List.mem_map]
        exact ⟨alt, (mem_rangeClosed_iff 1 p.altCount alt).mpr ⟨ha1, ha2⟩, rfl⟩

/-! ### 5. Metered Bounded Exhaustive Parser (`parseAllBounded`) & Exact Ref Congruence -/

structure MeterState where
  stepsUsed       : Nat
  forestNodesUsed : Nat
  deriving DecidableEq, Repr

def tickStep (budget : ResourceBudget) (st : MeterState) : Except OverflowReason MeterState :=
  let next := st.stepsUsed + 1
  if budget.maxSteps < next then
    .error (.maxStepsExceeded budget.maxSteps)
  else
    .ok { st with stepsUsed := next }

def tickForestNodes (budget : ResourceBudget) (count : Nat) (st : MeterState) :
    Except OverflowReason MeterState :=
  let next := st.forestNodesUsed + count
  if budget.maxForestNodes < next then
    .error (.maxForestNodesExceeded budget.maxForestNodes)
  else
    .ok { st with forestNodesUsed := next }

def flatMapMetered {α β : Type} : List α →
    (α → MeterState → Except OverflowReason (List β × MeterState)) →
    MeterState → Except OverflowReason (List β × MeterState)
  | [], _, st => .ok ([], st)
  | x :: rest, f, st =>
    match f x st with
    | .error e => .error e
    | .ok (ys, st1) =>
      match flatMapMetered rest f st1 with
      | .error e => .error e
      | .ok (zs, st2) => .ok (ys ++ zs, st2)

theorem flatMapMetered_eq_flatMapList {α β : Type} (xs : List α)
    (f : α → MeterState → Except OverflowReason (List β × MeterState))
    (g : α → List β)
    (hfg : ∀ x ∈ xs, ∀ st res st', f x st = .ok (res, st') → res = g x)
    (st : MeterState) (out : List β) (stFinal : MeterState)
    (hok : flatMapMetered xs f st = .ok (out, stFinal)) :
    out = flatMapList xs g := by
  induction xs generalizing st out stFinal with
  | nil =>
    unfold flatMapMetered flatMapList at *
    injection hok with hp
    injection hp with hout _
    exact hout.symm
  | cons x rest ih =>
    unfold flatMapMetered at hok
    cases hfx : f x st with
    | error e => rw [hfx] at hok; contradiction
    | ok pair1 =>
      rw [hfx] at hok
      rcases pair1 with ⟨ys, st1⟩
      dsimp at hok
      cases hrest : flatMapMetered rest f st1 with
      | error e => rw [hrest] at hok; contradiction
      | ok pair2 =>
        rw [hrest] at hok
        rcases pair2 with ⟨zs, st2⟩
        dsimp at hok
        injection hok with hpair
        injection hpair with hout _
        subst out
        have hys := hfg x (List.Mem.head rest) st ys st1 hfx
        have hzs := ih (fun y hy => hfg y (List.Mem.tail x hy)) st1 zs st2 hrest
        simp [flatMapList, hys, hzs]

def enumSegsMetered
    (budget : ResourceBudget) (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig) (Y : List Char)
    (childMetered : ClauseLocus → BNFNonterm → Nat → Nat → MeterState →
      Except OverflowReason (List (ConcreteParseTree × ParseSummary) × MeterState))
    (loc : ClauseLocus) (cursor : Nat) (syms : List BNFSymbol) (endPos : Nat)
    (st : MeterState) :
    Except OverflowReason (List (List ConcreteParseArg × List (BNFSlotTag × String) × List ParseSummary) × MeterState) :=
  match tickStep budget st with
  | .error e => .error e
  | .ok st1 =>
    match syms with
    | [] =>
      if (cursor ≤ Y.length) && (endPos == cursor) then
        .ok ([([], [], [])], st1)
      else
        .ok ([], st1)
    | .term lit :: restSyms =>
      let lcs := lit.toList
      let sp : CodepointSpan := ⟨cursor, cursor + lcs.length⟩
      if fastSpanMatchesBool Y sp lcs then
        match enumSegsMetered budget cat numCfg Y childMetered loc sp.endCp restSyms endPos st1 with
        | .error e => .error e
        | .ok (tails, st2) =>
          .ok (tails.map (fun (rArgs, rSlots, rSums) => (.litTok lit sp :: rArgs, rSlots, rSums)), st2)
      else
        .ok ([], st1)
    | .lexSlot srt tag :: restSyms =>
      if endPos ≤ Y.length then
        flatMapMetered (candidateSplitPositions Y cursor endPos restSyms)
          (fun mid stMid =>
            let sliceCs := (Y.drop cursor).take (mid - cursor)
            let lex := String.ofList sliceCs
            let sp : CodepointSpan := ⟨cursor, mid⟩
            if fastSpanMatchesBool Y sp lex.toList then
              let validEids := validSlotEntityIds cat numCfg Y.length srt lex
              match validEids with
              | [] => .ok ([], stMid)
              | _ :: _ =>
                match enumSegsMetered budget cat numCfg Y childMetered loc mid restSyms endPos stMid with
                | .error e => .error e
                | .ok (tails, stTail) =>
                  let built := flatMapList validEids fun eid =>
                    tails.map fun (rArgs, rSlots, rSums) =>
                      (.slotTok srt tag eid lex sp :: rArgs, (tag, eid) :: rSlots, rSums)
                  .ok (built, stTail)
            else
              .ok ([], stMid))
          st1
      else
        .ok ([], st1)
    | .nonterm childNt cIdx :: restSyms =>
      let childLoc := (clauseOverrideOfIdx cIdx).getD loc
      flatMapMetered (candidateSplitPositions Y cursor endPos restSyms)
        (fun mid stMid =>
          match childMetered childLoc childNt cursor mid stMid with
          | .error e => .error e
          | .ok (children, stChild) =>
            match children with
            | [] => .ok ([], stChild)
            | _ :: _ =>
              match enumSegsMetered budget cat numCfg Y childMetered loc mid restSyms endPos stChild with
              | .error e => .error e
              | .ok (tails, stTail) =>
                let built := flatMapList children fun (subTree, subSum) =>
                  tails.map fun (rArgs, rSlots, rSums) =>
                    (.childSub subTree :: rArgs, rSlots, subSum :: rSums)
                .ok (built, stTail))
        st1

def enumNodeMetered : Nat → ResourceBudget → ClosedEntityCatalog → NumericGateConfig →
    ScopeEnv → List Char → ClauseLocus → BNFNonterm → Nat → Nat → MeterState →
    Except OverflowReason (List (ConcreteParseTree × ParseSummary) × MeterState)
  | 0, budget, _, _, _, _, _, _, _, _, st =>
    match tickStep budget st with
    | .error e => .error e
    | .ok st1  => .ok ([], st1)
  | fuel + 1, budget, cat, numCfg, env, Y, expectedLoc, expectedNt, startPos, endPos, st =>
    match tickStep budget st with
    | .error e => .error e
    | .ok st0 =>
      flatMapMetered allFrozenParseProds
        (fun p stProd =>
          let sig := frozenProdSig p
          if sig.lhs == expectedNt then
            match enumSegsMetered budget cat numCfg Y (enumNodeMetered fuel budget cat numCfg env Y)
                    expectedLoc startPos sig.rhs endPos stProd with
            | .error e => .error e
            | .ok (segResults, stSeg) =>
              flatMapMetered segResults
                (fun (args, slots, sums) stAlt =>
                  if sig.checkSide env slots sums then
                    let outSum := sig.mkSum slots sums
                    let alts := rangeClosed 1 p.altCount
                    match tickForestNodes budget alts.length stAlt with
                    | .error e => .error e
                    | .ok stNodes =>
                      let built := alts.map fun alt =>
                        (ConcreteParseTree.mkTree p alt expectedLoc ⟨startPos, endPos⟩ args, outSum)
                      .ok (built, stNodes)
                  else
                    .ok ([], stAlt))
                stSeg
          else
            .ok ([], stProd))
        st0

theorem enumSegsMetered_eq_ref
    (budget : ResourceBudget) (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig) (Y : List Char)
    (childMetered : ClauseLocus → BNFNonterm → Nat → Nat → MeterState →
      Except OverflowReason (List (ConcreteParseTree × ParseSummary) × MeterState))
    (childRef : ClauseLocus → BNFNonterm → Nat → Nat → List (ConcreteParseTree × ParseSummary))
    (hChild : ∀ cLoc cNt sPos ePos st res st',
      childMetered cLoc cNt sPos ePos st = .ok (res, st') → res = childRef cLoc cNt sPos ePos)
    (loc : ClauseLocus) (cursor : Nat) (syms : List BNFSymbol) (endPos : Nat)
    (st st' : MeterState)
    (res : List (List ConcreteParseArg × List (BNFSlotTag × String) × List ParseSummary))
    (hok : enumSegsMetered budget cat numCfg Y childMetered loc cursor syms endPos st = .ok (res, st')) :
    res = enumSegsWith cat numCfg Y childRef loc cursor syms endPos := by
  induction syms generalizing cursor st st' res with
  | nil =>
    unfold enumSegsMetered at hok
    unfold enumSegsWith
    cases ht : tickStep budget st with
    | error e => rw [ht] at hok; contradiction
    | ok st1 =>
      rw [ht] at hok
      dsimp at hok
      by_cases hc : ((cursor ≤ Y.length) && (endPos == cursor)) = true
      · rw [if_pos hc] at hok ⊢
        injection hok with hp; injection hp with hres _; exact hres.symm
      · rw [if_neg hc] at hok ⊢
        injection hok with hp; injection hp with hres _; exact hres.symm
  | cons sym restSyms ih =>
    unfold enumSegsMetered at hok
    unfold enumSegsWith
    cases ht : tickStep budget st with
    | error e => rw [ht] at hok; contradiction
    | ok st1 =>
      rw [ht] at hok
      dsimp at hok
      cases sym with
      | term lit =>
        dsimp only at hok ⊢
        let sp : CodepointSpan := ⟨cursor, cursor + lit.toList.length⟩
        by_cases hchk : fastSpanMatchesBool Y sp lit.toList = true
        · rw [if_pos hchk] at hok ⊢
          cases hrec : enumSegsMetered budget cat numCfg Y childMetered loc sp.endCp restSyms endPos st1 with
          | error e => rw [hrec] at hok; contradiction
          | ok pair2 =>
            rw [hrec] at hok
            rcases pair2 with ⟨tails, st2⟩
            dsimp at hok
            injection hok with hp
            injection hp with hres _
            subst res
            rw [ih sp.endCp st1 st2 tails hrec]
        · rw [if_neg hchk] at hok ⊢
          injection hok with hp; injection hp with hres _; exact hres.symm
      | lexSlot srt tag =>
        dsimp only at hok ⊢
        by_cases hend : endPos ≤ Y.length
        · rw [if_pos hend] at hok ⊢
          refine flatMapMetered_eq_flatMapList _ _ _ ?_ st1 res st' hok
          intro mid _ stMid resMid stMid' hmid_ok
          let lex := String.ofList ((Y.drop cursor).take (mid - cursor))
          let sp : CodepointSpan := ⟨cursor, mid⟩
          by_cases hchk : fastSpanMatchesBool Y sp lex.toList = true
          · rw [if_pos hchk] at hmid_ok ⊢
            cases hv : validSlotEntityIds cat numCfg Y.length srt (String.ofList ((Y.drop cursor).take (mid - cursor))) with
            | nil =>
              rw [hv] at hmid_ok
              dsimp at hmid_ok
              injection hmid_ok with hp; injection hp with hres_mid _; exact hres_mid.symm
            | cons vhead vtail =>
              rw [hv] at hmid_ok
              dsimp only at hmid_ok
              cases hrec : enumSegsMetered budget cat numCfg Y childMetered loc mid restSyms endPos stMid with
              | error e => rw [hrec] at hmid_ok; contradiction
              | ok pairTail =>
                rw [hrec] at hmid_ok
                rcases pairTail with ⟨tails, stTail⟩
                dsimp at hmid_ok
                injection hmid_ok with hp
                injection hp with hres_mid _
                subst resMid
                rw [ih mid stMid stTail tails hrec]
          · rw [if_neg hchk] at hmid_ok ⊢
            injection hmid_ok with hp; injection hp with hres_mid _; exact hres_mid.symm
        · rw [if_neg hend] at hok ⊢
          injection hok with hp; injection hp with hres _; exact hres.symm
      | nonterm childNt cIdx =>
        dsimp only at hok ⊢
        refine flatMapMetered_eq_flatMapList _ _ _ ?_ st1 res st' hok
        intro mid _ stMid resMid stMid' hmid_ok
        let childLoc := (clauseOverrideOfIdx cIdx).getD loc
        cases hch : childMetered childLoc childNt cursor mid stMid with
        | error e => rw [hch] at hmid_ok; contradiction
        | ok pairChild =>
          rw [hch] at hmid_ok
          rcases pairChild with ⟨children, stChild⟩
          dsimp at hmid_ok
          have hch_eq := hChild childLoc childNt cursor mid stMid children stChild hch
          cases hc_list : children with
          | nil =>
            rw [hc_list] at hmid_ok hch_eq
            rw [← hch_eq]
            dsimp [flatMapList] at hmid_ok ⊢
            injection hmid_ok with hp; injection hp with hres_mid _; exact hres_mid.symm
          | cons chead ctail =>
            rw [hc_list] at hmid_ok hch_eq
            dsimp only at hmid_ok
            cases hrec : enumSegsMetered budget cat numCfg Y childMetered loc mid restSyms endPos stChild with
            | error e => rw [hrec] at hmid_ok; contradiction
            | ok pairTail =>
              rw [hrec] at hmid_ok
              rcases pairTail with ⟨tails, stTail⟩
              dsimp at hmid_ok
              injection hmid_ok with hp
              injection hp with hres_mid _
              subst resMid
              rw [← hch_eq, ih mid stChild stTail tails hrec]

theorem enumNodeMetered_eq_ref
    (fuel : Nat) (budget : ResourceBudget) (cat : ClosedEntityCatalog)
    (numCfg : NumericGateConfig) (env : ScopeEnv) (Y : List Char)
    (expectedLoc : ClauseLocus) (expectedNt : BNFNonterm) (startPos endPos : Nat)
    (st st' : MeterState) (res : List (ConcreteParseTree × ParseSummary))
    (hok : enumNodeMetered fuel budget cat numCfg env Y expectedLoc expectedNt startPos endPos st = .ok (res, st')) :
    res = enumNodeRef fuel cat numCfg env Y expectedLoc expectedNt startPos endPos := by
  induction fuel generalizing expectedLoc expectedNt startPos endPos st st' res with
  | zero =>
    unfold enumNodeMetered at hok
    unfold enumNodeRef
    cases ht : tickStep budget st with
    | error e => rw [ht] at hok; contradiction
    | ok st1 =>
      rw [ht] at hok
      injection hok with hp
      injection hp with hres _
      exact hres.symm
  | succ k ih =>
    unfold enumNodeMetered at hok
    unfold enumNodeRef
    cases ht : tickStep budget st with
    | error e => rw [ht] at hok; contradiction
    | ok st0 =>
      rw [ht] at hok
      dsimp at hok
      refine flatMapMetered_eq_flatMapList _ _ _ ?_ st0 res st' hok
      intro p _ stProd resProd stProd' hp_ok
      dsimp only at hp_ok ⊢
      by_cases hlhs : ((frozenProdSig p).lhs == expectedNt) = true
      · rw [if_pos hlhs] at hp_ok ⊢
        cases hseg : enumSegsMetered budget cat numCfg Y (enumNodeMetered k budget cat numCfg env Y)
                       expectedLoc startPos (frozenProdSig p).rhs endPos stProd with
        | error e => rw [hseg] at hp_ok; contradiction
        | ok pairSeg =>
          rw [hseg] at hp_ok
          rcases pairSeg with ⟨segResults, stSeg⟩
          dsimp at hp_ok
          have hseg_eq := enumSegsMetered_eq_ref budget cat numCfg Y
            (enumNodeMetered k budget cat numCfg env Y)
            (enumNodeRef k cat numCfg env Y)
            (fun cL cN sP eP s0 r0 s1 h0 => ih cL cN sP eP s0 s1 r0 h0)
            expectedLoc startPos (frozenProdSig p).rhs endPos stProd stSeg segResults hseg
          rw [← hseg_eq]
          refine flatMapMetered_eq_flatMapList _ _ _ ?_ stSeg resProd stProd' hp_ok
          rintro ⟨args, slots, sums⟩ _ stAlt resAlt stAlt' halt_ok
          dsimp only at halt_ok ⊢
          by_cases hside : (frozenProdSig p).checkSide env slots sums = true
          · rw [if_pos hside] at halt_ok ⊢
            cases hnf : tickForestNodes budget (rangeClosed 1 p.altCount).length stAlt with
            | error e => rw [hnf] at halt_ok; contradiction
            | ok stNodes =>
              rw [hnf] at halt_ok
              dsimp at halt_ok
              injection halt_ok with hp
              injection hp with hres_alt _
              exact hres_alt.symm
          · rw [if_neg hside] at halt_ok ⊢
            injection halt_ok with hp; injection hp with hres_alt _; exact hres_alt.symm
      · rw [if_neg hlhs] at hp_ok ⊢
        injection hp_ok with hp; injection hp with hres_prod _; exact hres_prod.symm

/--
  **Top-Level Bounded Exhaustive Parser (`parseAllBounded` — `PO-C1-01`)**:
  1. Checks character-profile domain (`OutOfDomain` iff `¬ StrictAsciiDomainSupported`).
  2. Enforces `budget.maxBytes` (`ResourceOverflow`, NOT `OutOfDomain`).
  3. Runs metered exhaustive enumeration across all 34 `G_parse` productions (`maxSteps`, `maxForestNodes`).
  4. Deduplicates in deterministic order and enforces `budget.maxReadings` fail-closed.
-/
def parseAllBounded (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) : BoundedParseResult :=
  match checkAsciiDomainOnly rawBytes with
  | .error d => .outOfDomain d
  | .ok () =>
    if budget.maxBytes < rawBytes.length then
      .resourceOverflow (.maxBytesExceeded rawBytes.length budget.maxBytes)
    else
      let Y := (decodeAsciiBytes rawBytes).toList
      let initState : MeterState := { stepsUsed := 0, forestNodesUsed := 0 }
      match enumNodeMetered 5 budget cat numCfg env Y .clause1 .controlledDocument 0 Y.length initState with
      | .error ov => .resourceOverflow ov
      | .ok (rawPairs, _) =>
        let uniqueTrees := dedupTrees (rawPairs.map Prod.fst)
        if budget.maxReadings < uniqueTrees.length then
          .resourceOverflow (.maxReadingsExceeded uniqueTrees.length budget.maxReadings)
        else
          .enumerated uniqueTrees

/-! ### 6. Gate C Formal Theorems (`PO-C1-01`: Termination, Soundness, Completeness, Fail-Closed) -/

/-- **Gate C.1 (`parseAllBounded_terminates`)**: Total deterministic termination on all inputs & budgets. -/
theorem parseAllBounded_terminates
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) :
    ∃ res : BoundedParseResult, parseAllBounded cat numCfg env budget rawBytes = res :=
  ⟨_, rfl⟩

/--
  **Gate C.2 (`parseAllBounded_outOfDomain_sound`)**:
  `OutOfDomain(d)` proves strictly that `rawBytes` violates `StrictAsciiDomainSupported`
  (it never falsely claims grammatical non-derivability outside the supported character profile).
-/
theorem parseAllBounded_outOfDomain_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (d : OutOfDomainDiag)
    (hood : parseAllBounded cat numCfg env budget rawBytes = .outOfDomain d) :
    ¬ StrictAsciiDomainSupported rawBytes := by
  unfold parseAllBounded at hood
  cases hdom : checkAsciiDomainOnly rawBytes with
  | error d' =>
    exact checkAsciiDomainOnly_err_sound rawBytes d' hdom
  | ok u =>
    rw [hdom] at hood
    dsimp at hood
    split at hood
    · contradiction
    · split at hood
      · contradiction
      · split at hood <;> contradiction

/--
  **Gate C.3 (`parseAllBounded_enumerated_sound_and_complete` — Core `PO-C1-01` Theorem)**:
  Whenever `parseAllBounded ... = .enumerated T`, ALL of the following hold simultaneously:
  1. `StrictAsciiDomainSupported rawBytes` and `rawBytes.length ≤ budget.maxBytes`.
  2. `T.length ≤ budget.maxReadings`.
  3. `NoDupTrees T` (zero duplicate parse trees).
  4. **Exact Soundness & Bounded Exhaustive Completeness**:
     `∀ τ : ConcreteParseTree, τ ∈ T ↔ ValidParse_GFrozen cat numCfg env rawBytes τ`.
-/
theorem parseAllBounded_enumerated_sound_and_complete
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree)
    (henum : parseAllBounded cat numCfg env budget rawBytes = .enumerated T) :
    StrictAsciiDomainSupported rawBytes ∧
    rawBytes.length ≤ budget.maxBytes ∧
    T.length ≤ budget.maxReadings ∧
    NoDupTrees T ∧
    (∀ τ : ConcreteParseTree, τ ∈ T ↔ ValidParse_GFrozen cat numCfg env rawBytes τ) := by
  unfold parseAllBounded at henum
  cases hdom : checkAsciiDomainOnly rawBytes with
  | error d => rw [hdom] at henum; contradiction
  | ok u =>
    rw [hdom] at henum
    dsimp at henum
    have hsup := (checkAsciiDomainOnly_ok_iff rawBytes).mp hdom
    by_cases hbytes : budget.maxBytes < rawBytes.length
    · rw [if_pos hbytes] at henum; contradiction
    · rw [if_neg hbytes] at henum
      let Y := (decodeAsciiBytes rawBytes).toList
      let initState : MeterState := { stepsUsed := 0, forestNodesUsed := 0 }
      cases hmet : enumNodeMetered 5 budget cat numCfg env Y .clause1 .controlledDocument 0 Y.length initState with
      | error ov => rw [hmet] at henum; contradiction
      | ok pairOut =>
        rw [hmet] at henum
        rcases pairOut with ⟨rawPairs, stFinal⟩
        dsimp at henum
        by_cases hread : budget.maxReadings < (dedupTrees (rawPairs.map Prod.fst)).length
        · rw [if_pos hread] at henum; contradiction
        · rw [if_neg hread] at henum
          injection henum with hT
          subst T
          have href_eq := enumNodeMetered_eq_ref 5 budget cat numCfg env Y
            .clause1 .controlledDocument 0 Y.length initState stFinal rawPairs hmet
          have hlvl : BNFNonterm.controlledDocument.level < 5 := by decide
          refine ⟨hsup, by omega, by omega, dedupTrees_nodup _, ?_⟩
          intro τ
          rw [mem_dedupTrees_iff, List.mem_map]
          unfold ValidParse_GFrozen
          constructor
          · rintro ⟨⟨t0, sum0⟩, hmem_raw, rfl⟩
            rw [href_eq] at hmem_raw
            rcases (mem_enumNodeRef_iff 5 cat numCfg env Y .clause1 .controlledDocument hlvl 0 Y.length t0 sum0).mp hmem_raw with ⟨hsp, hnode⟩
            exact ⟨hsup, hsp, sum0, hnode⟩
          · rintro ⟨_, hsp, sum0, hnode⟩
            refine ⟨(τ, sum0), ?_, rfl⟩
            rw [href_eq]
            exact (mem_enumNodeRef_iff 5 cat numCfg env Y .clause1 .controlledDocument hlvl 0 Y.length τ sum0).mpr ⟨hsp, hnode⟩

/-- **Gate C.3a (`parseAllBounded_sound`)**: Soundness corollary (`τ ∈ T → ValidParse_GFrozen`). -/
theorem parseAllBounded_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (T : List ConcreteParseTree)
    (henum : parseAllBounded cat numCfg env budget rawBytes = .enumerated T) :
    ∀ τ ∈ T, ValidParse_GFrozen cat numCfg env rawBytes τ :=
  fun τ hmem => ((parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes T henum).2.2.2.2 τ).mp hmem

/--
  **Gate C.3b (`parseAllBounded_empty_sound`)**:
  Returning `.enumerated []` proves BOTH that `rawBytes` is in-domain AND that NO valid parse exists in `G_parse`.
-/
theorem parseAllBounded_empty_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (hempty : parseAllBounded cat numCfg env budget rawBytes = .enumerated []) :
    StrictAsciiDomainSupported rawBytes ∧
    ∀ τ : ConcreteParseTree, ¬ ValidParse_GFrozen cat numCfg env rawBytes τ := by
  have hall := parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes [] hempty
  refine ⟨hall.1, ?_⟩
  intro τ hval
  have hmem := (hall.2.2.2.2 τ).mpr hval
  simp at hmem

/-! ### 7. Sealed Admission Gate & `ResourceOverflow` Fail-Closed Proof (`Gate C.5`) -/

inductive ParseGateReject where
  | domainRejected     (diag : OutOfDomainDiag)
  | overflowFailClosed (reason : OverflowReason)
  | zeroValidParses
  deriving DecidableEq, Repr

/--
  Sealed proof-carrying parse-forest witness (`private mk ::`).
  Cannot be constructed from `OutOfDomain`, `ResourceOverflow`, or `enumerated []`.
-/
structure CertifiedParseForest (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) where
  private mk ::
  trees       : List ConcreteParseTree
  hNonEmpty   : trees ≠ []
  hNoDup      : NoDupTrees trees
  hExactSet   : ∀ τ, τ ∈ trees ↔ ValidParse_GFrozen cat numCfg env rawBytes τ

def admitBoundedParse (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8) :
    Except ParseGateReject (CertifiedParseForest cat numCfg env budget rawBytes) :=
  match h : parseAllBounded cat numCfg env budget rawBytes with
  | .outOfDomain d      => .error (.domainRejected d)
  | .resourceOverflow b => .error (.overflowFailClosed b)
  | .enumerated T       =>
    if hne : T = [] then
      .error .zeroValidParses
    else
      let hc := parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes T h
      .ok ⟨T, hne, hc.2.2.2.1, hc.2.2.2.2⟩

/--
  **Gate C.5 (`resourceOverflow_failClosed`)**:
  Whenever `parseAllBounded` hits `ResourceOverflow(b)`, `admitBoundedParse` deterministically
  fails closed (`.error (.overflowFailClosed b)`), discarding partial results and never issuing
  a `CertifiedParseForest` or conflating overflow with `enumerated []`.
-/
theorem resourceOverflow_failClosed
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget) (rawBytes : List UInt8)
    (b : OverflowReason)
    (hov : parseAllBounded cat numCfg env budget rawBytes = .resourceOverflow b) :
    admitBoundedParse cat numCfg env budget rawBytes = .error (.overflowFailClosed b) ∧
    (∀ T, parseAllBounded cat numCfg env budget rawBytes ≠ .enumerated T) := by
  refine ⟨?_, ?_⟩
  · unfold admitBoundedParse
    split
    · rename_i d heq
      rw [hov] at heq; contradiction
    · rename_i b' heq
      rw [hov] at heq
      injection heq with hb
      rw [hb]
    · rename_i T heq
      rw [hov] at heq; contradiction
  · intro T heq
    rw [hov] at heq
    contradiction

end BrocaOmega.P3B
