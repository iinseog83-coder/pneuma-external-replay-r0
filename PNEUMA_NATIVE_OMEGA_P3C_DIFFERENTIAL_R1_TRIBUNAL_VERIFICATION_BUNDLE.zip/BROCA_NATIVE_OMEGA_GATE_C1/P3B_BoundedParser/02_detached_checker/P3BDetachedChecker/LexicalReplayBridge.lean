/-
  BROCA-NATIVE Ω — AUTH-C1-P3-B (`Gate D`: `BridgeSound` & `ProjectionFaithful` Across Actual Frozen `P3-A` & `P2`)
  02_detached_checker/P3BDetachedChecker/LexicalReplayBridge.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2` & `P3-A`, zero `sorry`, zero `native_decide`)

  Gate D Deliverable:
  1. Directly imports and binds the ACTUAL frozen definitions:
       - `BrocaOmega.P3A.CertifiedLexicalSlot`
       - `BrocaOmega.P3A.admitLexicalSlot`
       - `BrocaOmega.P2.UntrustedDerivCert`
       - `BrocaOmega.P2.replayDerivation`
  2. Restricts `lowerToP2Cert` to `LexicallyCertifiedDerivTree` whose slot leaves carry sealed
     `P3A.CertifiedLexicalSlot` (`private mk ::`) witnesses — uncertified slots cannot be lowered!
  3. Defines full tree-recursive `ProjectionFaithful x π` preserving parent-child hierarchy, sibling
     order, `SlotSort`, `SlotRole`, `entityId`, `lexeme`, `CodepointSpan`, global pre-order span list,
     and node/global obligation `(oblId, locus, kind, target)` correspondence, with sound & complete
     boolean checker `checkProjectionFaithfulBool`.
  4. Proves `lowerToP2Cert_projectionFaithful`, `BridgeSound`, `BridgeSound_rawBytes`, and the
     3-module end-to-end unification theorem `BridgeSound_mem_enumerated_forest`.
-/
import P3BDetachedChecker.BoundedParser
import P2DetachedChecker

namespace BrocaOmega.P3B

open BrocaOmega.P2
open BrocaOmega.P3A

/-! ### 1. Exact Summary & Sort Inverse Lemmas for `P2` ↔ `P3-A` ↔ `P3-B` -/

theorem fromP2_of_toP2Sort {srt : P3SlotSort} {p2s : SlotSort}
    (h : toP2SlotSort? srt = some p2s) : srt = fromP2SlotSort p2s := by
  cases srt <;> simp [toP2SlotSort?] at h <;> subst p2s <;> rfl

theorem fromP2Rule_mkSum_eq_mapP2Summary
    (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    (frozenProdSig (fromP2Rule r)).mkSum (mapP2Slots slots) (sums.map mapP2Summary) =
    mapP2Summary ((ruleSignature r).mkSummary slots sums) := by
  cases r <;> dsimp [fromP2Rule, frozenProdSig, ruleSignature, mapP2Summary]
  all_goals
    cases sums with
    | nil => simp [toP2SlotRole?]
    | cons c1 rest1 =>
      cases rest1 <;> simp [mapP2Summary, toP2SlotRole?]

theorem fromP2Rule_altCount_eq_one (r : FrozenGenRule) :
    (fromP2Rule r).altCount = 1 := by
  cases r <;> rfl

theorem fromP2Rule_isGenerator (r : FrozenGenRule) :
    (frozenProdSig (fromP2Rule r)).isGenerator = true := by
  cases r <;> rfl

/-! ### 2. `LexicallyCertifiedDerivTree` (Restricted to Sealed `P3A.CertifiedLexicalSlot` Witnesses) -/

/--
  Lexical slot leaf carrying a kernel-sealed `BrocaOmega.P3A.CertifiedLexicalSlot` witness (`private mk ::`).
  Cannot be constructed unless `BrocaOmega.P3A.admitLexicalSlot` succeeded on `(p3Sort, entityId, lexeme)`.
-/
structure CertifiedBridgeSlot (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) where
  lexeme     : String
  entityId   : String
  p3Sort     : P3SlotSort
  p2Sort     : SlotSort
  p2Role     : SlotRole
  span       : CodepointSpan
  witness    : BrocaOmega.P3A.CertifiedLexicalSlot cat numCfg maxSlotBytes
                 { sort := p3Sort, entityId := entityId, rawBytes := strToAsciiBytes lexeme }
  hDecodedEq : ({ sort := p3Sort, entityId := entityId, rawBytes := strToAsciiBytes lexeme } : RawSlotCandidate).decodedStr = lexeme
  hSortProj  : toP2SlotSort? p3Sort = some p2Sort

def CertifiedBridgeSlot.rawCand {cat numCfg maxSlotBytes}
    (s : CertifiedBridgeSlot cat numCfg maxSlotBytes) : RawSlotCandidate :=
  { sort := s.p3Sort, entityId := s.entityId, rawBytes := strToAsciiBytes s.lexeme }

theorem certifiedBridgeSlot_declarativeValid {cat numCfg maxSlotBytes}
    (s : CertifiedBridgeSlot cat numCfg maxSlotBytes) :
    DeclarativeSlotValid cat numCfg maxSlotBytes s.p3Sort s.entityId s.lexeme :=
  ⟨s.hDecodedEq, s.witness.hLexValid, s.witness.hNumValid, s.witness.hCatBound⟩

mutual
  inductive CertifiedSegArg (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (maxSlotBytes : Nat) where
    | litSpan   (claimedText : String) (span : CodepointSpan)
    | certSlot  (slot : CertifiedBridgeSlot cat numCfg maxSlotBytes)
    | childNode (sub : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)

  /--
    Derivation tree whose terminal slots are ALL sealed `P3-A` `CertifiedBridgeSlot`s.
    This is the ONLY input type accepted by `lowerToP2Cert`.
  -/
  inductive LexicallyCertifiedDerivTree (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (maxSlotBytes : Nat) where
    | mkCertNode
        (nodeId            : Nat)
        (genRule           : FrozenGenRule)
        (span              : CodepointSpan)
        (claimedDischarged : List ObligationToken)
        (segArgs           : List (CertifiedSegArg cat numCfg maxSlotBytes))
end

/-! ### 3. Direct Structural Observables on `LexicallyCertifiedDerivTree` -/

mutual
  def AllSegSlotsP3ACertified {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → Prop
    | [] => True
    | .litSpan _ _ :: rest => AllSegSlotsP3ACertified rest
    | .certSlot s :: rest =>
      (LexicallyValid maxSlotBytes s.rawCand ∧
       NumericallyWellFormed numCfg s.rawCand ∧
       EntityCatalogBound cat s.rawCand ∧
       s.rawCand.decodedStr = s.lexeme ∧
       toP2SlotSort? s.p3Sort = some s.p2Sort) ∧
      AllSegSlotsP3ACertified rest
    | .childNode sub :: rest =>
      AllTreeSlotsP3ACertified sub ∧ AllSegSlotsP3ACertified rest

  /-- Every slot leaf in `x` satisfies `P3-A`'s `LexicallyValid ∧ NumericallyWellFormed ∧ EntityCatalogBound`. -/
  def AllTreeSlotsP3ACertified {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → Prop
    | .mkCertNode _ _ _ _ args => AllSegSlotsP3ACertified args
end

mutual
  theorem allSegSlots_hold {cat numCfg maxSlotBytes}
      (args : List (CertifiedSegArg cat numCfg maxSlotBytes)) :
      AllSegSlotsP3ACertified args := by
    cases args with
    | nil => trivial
    | cons a rest =>
      cases a with
      | litSpan _ _ => exact allSegSlots_hold rest
      | certSlot s =>
        exact ⟨⟨s.witness.hLexValid, s.witness.hNumValid, s.witness.hCatBound,
                s.hDecodedEq, s.hSortProj⟩,
               allSegSlots_hold rest⟩
      | childNode sub =>
        exact ⟨allTreeSlots_hold sub, allSegSlots_hold rest⟩

  theorem allTreeSlots_hold {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) :
      AllTreeSlotsP3ACertified x := by
    cases x with
    | mkCertNode _ _ _ _ args => exact allSegSlots_hold args
end

mutual
  def reconstructCertSegChars {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List Char
    | [] => []
    | .litSpan txt _ :: rest => txt.toList ++ reconstructCertSegChars rest
    | .certSlot s :: rest    => s.lexeme.toList ++ reconstructCertSegChars rest
    | .childNode sub :: rest => reconstructCertChars sub ++ reconstructCertSegChars rest

  def reconstructCertChars {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → List Char
    | .mkCertNode _ _ _ _ args => reconstructCertSegChars args
end

def reconstructCertYield {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) : String :=
  String.ofList (reconstructCertChars x)

mutual
  def collectCertSegObls {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List ObligationToken
    | [] => []
    | .litSpan _ _ :: rest   => collectCertSegObls rest
    | .certSlot _ :: rest    => collectCertSegObls rest
    | .childNode sub :: rest => collectCertClaimedObls sub ++ collectCertSegObls rest

  def collectCertClaimedObls {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → List ObligationToken
    | .mkCertNode _ _ _ claimed args => claimed ++ collectCertSegObls args
end

def ObligationsConservedOnCert {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) (deltaIn : List ObligationToken) : Prop :=
  NoDupOblIds deltaIn ∧
  NoDupOblIds (collectCertClaimedObls x) ∧
  MultisetEq (collectCertClaimedObls x) deltaIn

mutual
  def collectCertSegSpans {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List CodepointSpan
    | [] => []
    | .litSpan _ sp :: rest  => sp :: collectCertSegSpans rest
    | .certSlot s :: rest    => s.span :: collectCertSegSpans rest
    | .childNode sub :: rest => collectCertSpans sub ++ collectCertSegSpans rest

  /-- Pre-order sequence of all node, literal, and slot `CodepointSpan`s in `x`. -/
  def collectCertSpans {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → List CodepointSpan
    | .mkCertNode _ _ sp _ args => sp :: collectCertSegSpans args
end

mutual
  def collectP2SegSpans : List UntrustedSegArg → List CodepointSpan
    | [] => []
    | .litSpan _ sp :: rest  => sp :: collectP2SegSpans rest
    | .slotLeaf tok :: rest  => tok.span :: collectP2SegSpans rest
    | .childNode sub :: rest => collectP2Spans sub ++ collectP2SegSpans rest

  /-- Pre-order sequence of all node, literal, and slot `CodepointSpan`s in `π : UntrustedDerivCert`. -/
  def collectP2Spans : UntrustedDerivCert → List CodepointSpan
    | .mkNode _ _ sp _ args => sp :: collectP2SegSpans args
end

/- Direct lifting of `LexicallyCertifiedDerivTree` to `P3-B`'s `ConcreteParseTree`. -/
mutual
  def certSegsToParseArgs {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → ClauseLocus → List RuleSegment → List ConcreteParseArg
    | .litSpan txt sp :: as, loc, .lit _ :: rs =>
      .litTok txt sp :: certSegsToParseArgs as loc rs
    | .certSlot s :: as, loc, .slot _ _ :: rs =>
      .slotTok s.p3Sort (fromP2SlotRole s.p2Role) s.entityId s.lexeme s.span ::
        certSegsToParseArgs as loc rs
    | .childNode sub :: as, loc, .child _ locOpt :: rs =>
      .childSub (certTreeToParseTree sub (locOpt.getD loc)) ::
        certSegsToParseArgs as loc rs
    | _, _, _ => []

  def certTreeToParseTree {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → ClauseLocus → ConcreteParseTree
    | .mkCertNode _ r sp _ args, loc =>
      .mkTree (fromP2Rule r) 1 loc sp (certSegsToParseArgs args loc (ruleSignature r).segments)
end

/- Direct `P3-B` Locus & Target Obligation Binding on `x` using `frozenProdSig.intrinsicObls`! -/
mutual
  def synthCertSegSlotsSums {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List RuleSegment →
      Option (List (BNFSlotTag × String) × List ParseSummary)
    | [], [] => some ([], [])
    | .litSpan _ _ :: as, .lit _ :: rs => synthCertSegSlotsSums as rs
    | .certSlot s :: as, .slot _ expectedRole :: rs =>
      match synthCertSegSlotsSums as rs with
      | some (slots, sums) => some ((fromP2SlotRole expectedRole, s.entityId) :: slots, sums)
      | none => none
    | .childNode sub :: as, .child _ _ :: rs =>
      match synthCertNodeSummary sub, synthCertSegSlotsSums as rs with
      | some subSum, some (slots, sums) => some (slots, subSum :: sums)
      | _, _ => none
    | _, _ => none

  def synthCertNodeSummary {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → Option ParseSummary
    | .mkCertNode _ r _ _ args =>
      match synthCertSegSlotsSums args (ruleSignature r).segments with
      | some (slots, sums) => some ((frozenProdSig (fromP2Rule r)).mkSum slots sums)
      | none => none
end

mutual
  def CertSegLocusTargetBound {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → ClauseLocus → List RuleSegment → Prop
    | [], _, [] => True
    | .litSpan _ _ :: as, loc, .lit _ :: rs => CertSegLocusTargetBound as loc rs
    | .certSlot _ :: as, loc, .slot _ _ :: rs => CertSegLocusTargetBound as loc rs
    | .childNode sub :: as, loc, .child _ locOpt :: rs =>
      CertNodeLocusTargetBound sub (locOpt.getD loc) ∧ CertSegLocusTargetBound as loc rs
    | _, _, _ => False

  def CertNodeLocusTargetBound {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → ClauseLocus → Prop
    | .mkCertNode _ r _ claimed args, loc =>
      ∃ (slots : List (BNFSlotTag × String)) (sums : List ParseSummary),
        synthCertSegSlotsSums args (ruleSignature r).segments = some (slots, sums) ∧
        claimed.map (·.spec) = (frozenProdSig (fromP2Rule r)).intrinsicObls loc slots sums ∧
        (∀ o ∈ claimed, o.spec.locus = loc ∨ (r = .G16_DocContrastive ∧ o.spec.locus = .clause2)) ∧
        CertSegLocusTargetBound args loc (ruleSignature r).segments
end

def LocusTargetBoundOnCert {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) : Prop :=
  CertNodeLocusTargetBound x .clause1

/-! ### 4. Restricted Lowering (`lowerToP2Cert`) & Full `ProjectionFaithful(x, π)` Relation -/

def lowerBridgeSlot {cat numCfg maxSlotBytes}
    (s : CertifiedBridgeSlot cat numCfg maxSlotBytes) : SlotToken :=
  { sort     := s.p2Sort
    role     := s.p2Role
    entityId := s.entityId
    lexeme   := s.lexeme
    span     := s.span }

mutual
  def lowerSegArgs {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List UntrustedSegArg
    | [] => []
    | .litSpan txt sp :: rest => .litSpan txt sp :: lowerSegArgs rest
    | .certSlot s :: rest     => .slotLeaf (lowerBridgeSlot s) :: lowerSegArgs rest
    | .childNode sub :: rest  => .childNode (lowerToP2Cert sub) :: lowerSegArgs rest

  /--
    Restricted lowering into `BrocaOmega.P2.UntrustedDerivCert`.
    Type-restricted to `LexicallyCertifiedDerivTree` so uncertified slots CANNOT be passed!
  -/
  def lowerToP2Cert {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → BrocaOmega.P2.UntrustedDerivCert
    | .mkCertNode nid r sp claimed args =>
      .mkNode nid r.toCode sp claimed (lowerSegArgs args)
end

/-
  Full Structural Projection Faithfulness (`SegProjectionFaithful` & `NodeProjectionFaithful`):
  Enforces 1-to-1 preservation of parent-child tree structure, sibling order, rule codes,
  `SlotSort`, `SlotRole`, `entityId`, `lexeme`, `CodepointSpan`, and `ObligationToken`s
  (`oblId`, `locus`, `kind`, `target`).
-/
mutual
  def SegProjectionFaithful {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List UntrustedSegArg → Prop
    | [], [] => True
    | .litSpan txt sp :: restX, .litSpan pTxt pSp :: restP =>
      pTxt = txt ∧ pSp = sp ∧ SegProjectionFaithful restX restP
    | .certSlot s :: restX, .slotLeaf tok :: restP =>
      tok.sort = s.p2Sort ∧
      toP2SlotSort? s.p3Sort = some tok.sort ∧
      tok.role = s.p2Role ∧
      tok.entityId = s.entityId ∧
      tok.lexeme = s.lexeme ∧
      tok.span = s.span ∧
      SegProjectionFaithful restX restP
    | .childNode subX :: restX, .childNode subP :: restP =>
      NodeProjectionFaithful subX subP ∧ SegProjectionFaithful restX restP
    | _, _ => False

  def NodeProjectionFaithful {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → UntrustedDerivCert → Prop
    | .mkCertNode nid r sp claimed args, .mkNode pNid rawCode pSp pClaimed pArgs =>
      pNid = nid ∧
      decodeFrozenRule rawCode = some r ∧
      pSp = sp ∧
      pClaimed = claimed ∧
      SegProjectionFaithful args pArgs
end

/--
  **Top-Level `ProjectionFaithful x π` (`Gate D`)**:
  Combines full tree-structural faithfulness with global pre-order span-sequence and
  obligation-sequence preservation.
-/
def ProjectionFaithful {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
    (π : BrocaOmega.P2.UntrustedDerivCert) : Prop :=
  NodeProjectionFaithful x π ∧
  collectCertSpans x = collectP2Spans π ∧
  collectCertClaimedObls x = collectClaimedObls π

/- Computable boolean verifier for `ProjectionFaithful` (used in adversarial tamper tests). -/
mutual
  def checkSegProjectionFaithfulBool {cat numCfg maxSlotBytes} :
      List (CertifiedSegArg cat numCfg maxSlotBytes) → List UntrustedSegArg → Bool
    | [], [] => true
    | .litSpan txt sp :: restX, .litSpan pTxt pSp :: restP =>
      (pTxt == txt) && (pSp == sp) && checkSegProjectionFaithfulBool restX restP
    | .certSlot s :: restX, .slotLeaf tok :: restP =>
      (tok.sort == s.p2Sort) &&
      (toP2SlotSort? s.p3Sort == some tok.sort) &&
      (tok.role == s.p2Role) &&
      (tok.entityId == s.entityId) &&
      (tok.lexeme == s.lexeme) &&
      (tok.span == s.span) &&
      checkSegProjectionFaithfulBool restX restP
    | .childNode subX :: restX, .childNode subP :: restP =>
      checkNodeProjectionFaithfulBool subX subP && checkSegProjectionFaithfulBool restX restP
    | _, _ => false

  def checkNodeProjectionFaithfulBool {cat numCfg maxSlotBytes} :
      LexicallyCertifiedDerivTree cat numCfg maxSlotBytes → UntrustedDerivCert → Bool
    | .mkCertNode nid r sp claimed args, .mkNode pNid rawCode pSp pClaimed pArgs =>
      (pNid == nid) &&
      (decodeFrozenRule rawCode == some r) &&
      (pSp == sp) &&
      (pClaimed == claimed) &&
      checkSegProjectionFaithfulBool args pArgs
end

def checkProjectionFaithfulBool {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
    (π : BrocaOmega.P2.UntrustedDerivCert) : Bool :=
  checkNodeProjectionFaithfulBool x π &&
  (collectCertSpans x == collectP2Spans π) &&
  (collectCertClaimedObls x == collectClaimedObls π)

mutual
  theorem checkSegProjectionFaithfulBool_iff {cat numCfg maxSlotBytes}
      (xs : List (CertifiedSegArg cat numCfg maxSlotBytes)) (ps : List UntrustedSegArg) :
      checkSegProjectionFaithfulBool xs ps = true ↔ SegProjectionFaithful xs ps := by
    cases xs with
    | nil =>
      cases ps <;> simp [checkSegProjectionFaithfulBool, SegProjectionFaithful]
    | cons ax rx =>
      cases ps with
      | nil => simp [checkSegProjectionFaithfulBool, SegProjectionFaithful]
      | cons ap rp =>
        cases ax <;> cases ap <;>
          simp [checkSegProjectionFaithfulBool, SegProjectionFaithful, Bool.and_eq_true, beq_iff_eq, and_assoc]
        case litSpan.litSpan =>
          intro _ _; exact checkSegProjectionFaithfulBool_iff rx rp
        case certSlot.slotLeaf =>
          intro _ _ _ _ _ _; exact checkSegProjectionFaithfulBool_iff rx rp
        case childNode.childNode sx sp_sub =>
          rw [checkNodeProjectionFaithfulBool_iff sx sp_sub, checkSegProjectionFaithfulBool_iff rx rp]

  theorem checkNodeProjectionFaithfulBool_iff {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) (π : UntrustedDerivCert) :
      checkNodeProjectionFaithfulBool x π = true ↔ NodeProjectionFaithful x π := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        simp [checkNodeProjectionFaithfulBool, NodeProjectionFaithful,
              Bool.and_eq_true, beq_iff_eq, and_assoc, checkSegProjectionFaithfulBool_iff]
end

theorem checkProjectionFaithfulBool_iff {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) (π : UntrustedDerivCert) :
    checkProjectionFaithfulBool x π = true ↔ ProjectionFaithful x π := by
  unfold checkProjectionFaithfulBool ProjectionFaithful
  simp [Bool.and_eq_true, beq_iff_eq, and_assoc, checkNodeProjectionFaithfulBool_iff]

/-! ### 5. Structural Preservation Lemmas Under `NodeProjectionFaithful` & `lowerToP2Cert` -/

mutual
  theorem nodeProjectionFaithful_spans {cat numCfg maxSlotBytes}
      {xs : List (CertifiedSegArg cat numCfg maxSlotBytes)} {ps : List UntrustedSegArg}
      (h : SegProjectionFaithful xs ps) :
      collectCertSegSpans xs = collectP2SegSpans ps := by
    cases xs with
    | nil =>
      cases ps with
      | nil => rfl
      | cons _ _ => simp [SegProjectionFaithful] at h
    | cons ax rx =>
      cases ps with
      | nil => cases ax <;> simp [SegProjectionFaithful] at h
      | cons ap rp =>
        cases ax <;> cases ap
        case litSpan.litSpan txt sp pTxt pSp =>
          rcases h with ⟨_, rfl, hr⟩
          simp [collectCertSegSpans, collectP2SegSpans, nodeProjectionFaithful_spans hr]
        case certSlot.slotLeaf s tok =>
          rcases h with ⟨_, _, _, _, _, hsp, hr⟩
          simp [collectCertSegSpans, collectP2SegSpans, hsp, nodeProjectionFaithful_spans hr]
        case childNode.childNode sx sp_sub =>
          rcases h with ⟨hsub, hr⟩
          simp [collectCertSegSpans, collectP2SegSpans,
                treeProjectionFaithful_spans hsub, nodeProjectionFaithful_spans hr]
        all_goals exact False.elim h

  theorem treeProjectionFaithful_spans {cat numCfg maxSlotBytes}
      {x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes} {π : UntrustedDerivCert}
      (h : NodeProjectionFaithful x π) :
      collectCertSpans x = collectP2Spans π := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases h with ⟨_, _, rfl, _, hargs⟩
        simp [collectCertSpans, collectP2Spans, nodeProjectionFaithful_spans hargs]
end

mutual
  theorem segProjectionFaithful_obls {cat numCfg maxSlotBytes}
      {xs : List (CertifiedSegArg cat numCfg maxSlotBytes)} {ps : List UntrustedSegArg}
      (h : SegProjectionFaithful xs ps) :
      collectCertSegObls xs = collectSegClaimedObls ps := by
    cases xs with
    | nil =>
      cases ps with
      | nil => rfl
      | cons _ _ => simp [SegProjectionFaithful] at h
    | cons ax rx =>
      cases ps with
      | nil => cases ax <;> simp [SegProjectionFaithful] at h
      | cons ap rp =>
        cases ax <;> cases ap
        case litSpan.litSpan =>
          rcases h with ⟨_, _, hr⟩
          simpa [collectCertSegObls, collectSegClaimedObls] using segProjectionFaithful_obls hr
        case certSlot.slotLeaf =>
          rcases h with ⟨_, _, _, _, _, _, hr⟩
          simpa [collectCertSegObls, collectSegClaimedObls] using segProjectionFaithful_obls hr
        case childNode.childNode sx sp_sub =>
          rcases h with ⟨hsub, hr⟩
          simp [collectCertSegObls, collectSegClaimedObls,
                treeProjectionFaithful_obls hsub, segProjectionFaithful_obls hr]
        all_goals exact False.elim h

  theorem treeProjectionFaithful_obls {cat numCfg maxSlotBytes}
      {x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes} {π : UntrustedDerivCert}
      (h : NodeProjectionFaithful x π) :
      collectCertClaimedObls x = collectClaimedObls π := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases h with ⟨_, _, _, rfl, hargs⟩
        simp [collectCertClaimedObls, collectClaimedObls, segProjectionFaithful_obls hargs]
end

mutual
  theorem segProjectionFaithful_yield {cat numCfg maxSlotBytes}
      {xs : List (CertifiedSegArg cat numCfg maxSlotBytes)} {ps : List UntrustedSegArg}
      (h : SegProjectionFaithful xs ps) :
      reconstructCertSegChars xs = reconstructSegYield ps := by
    cases xs with
    | nil =>
      cases ps with
      | nil => rfl
      | cons _ _ => simp [SegProjectionFaithful] at h
    | cons ax rx =>
      cases ps with
      | nil => cases ax <;> simp [SegProjectionFaithful] at h
      | cons ap rp =>
        cases ax <;> cases ap
        case litSpan.litSpan =>
          rcases h with ⟨rfl, _, hr⟩
          simp [reconstructCertSegChars, reconstructSegYield, segProjectionFaithful_yield hr]
        case certSlot.slotLeaf =>
          rcases h with ⟨_, _, _, _, hlex, _, hr⟩
          simp [reconstructCertSegChars, reconstructSegYield, hlex, segProjectionFaithful_yield hr]
        case childNode.childNode sx sp_sub =>
          rcases h with ⟨hsub, hr⟩
          simp [reconstructCertSegChars, reconstructSegYield,
                treeProjectionFaithful_yield hsub, segProjectionFaithful_yield hr]
        all_goals exact False.elim h

  theorem treeProjectionFaithful_yield {cat numCfg maxSlotBytes}
      {x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes} {π : UntrustedDerivCert}
      (h : NodeProjectionFaithful x π) :
      reconstructCertChars x = reconstructYieldChars π := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases h with ⟨_, _, _, _, hargs⟩
        simp [reconstructCertChars, reconstructYieldChars, segProjectionFaithful_yield hargs]
end

mutual
  theorem lowerSegArgs_faithful {cat numCfg maxSlotBytes}
      (args : List (CertifiedSegArg cat numCfg maxSlotBytes)) :
      SegProjectionFaithful args (lowerSegArgs args) := by
    cases args with
    | nil => trivial
    | cons a rest =>
      cases a with
      | litSpan txt sp =>
        exact ⟨rfl, rfl, lowerSegArgs_faithful rest⟩
      | certSlot s =>
        exact ⟨rfl, s.hSortProj, rfl, rfl, rfl, rfl, lowerSegArgs_faithful rest⟩
      | childNode sub =>
        exact ⟨lowerNode_faithful sub, lowerSegArgs_faithful rest⟩

  theorem lowerNode_faithful {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) :
      NodeProjectionFaithful x (lowerToP2Cert x) := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      exact ⟨rfl, decode_toCode_id r, rfl, rfl, lowerSegArgs_faithful args⟩
end

/-- **Gate D.1 (`lowerToP2Cert_projectionFaithful`)**: `lowerToP2Cert x` ALWAYS satisfies `ProjectionFaithful`! -/
theorem lowerToP2Cert_projectionFaithful {cat numCfg maxSlotBytes}
    (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes) :
    ProjectionFaithful x (lowerToP2Cert x) := by
  have hn := lowerNode_faithful x
  exact ⟨hn, treeProjectionFaithful_spans hn, treeProjectionFaithful_obls hn⟩

/-! ### 6. Core Inductive Lifting Theorems (`P2` Replay + `ProjectionFaithful` ⟹ `P3-B` `ValidParseNode` & `LocusTargetBoundOnCert`) -/

mutual
  theorem lift_synthSlotsSums {cat numCfg maxSlotBytes}
      (args : List (CertifiedSegArg cat numCfg maxSlotBytes))
      {pArgs : List UntrustedSegArg} {segs : List RuleSegment}
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (hfaith : SegProjectionFaithful args pArgs)
      (hsynth : synthSegSlotsSums segs pArgs = some (slots, sums)) :
      synthCertSegSlotsSums args segs = some (mapP2Slots slots, sums.map mapP2Summary) := by
    cases args with
    | nil =>
      cases pArgs with
      | nil =>
        cases segs with
        | nil =>
          simp [synthSegSlotsSums] at hsynth
          rcases hsynth with ⟨rfl, rfl⟩
          rfl
        | cons _ _ => simp [synthSegSlotsSums] at hsynth
      | cons _ _ => simp [SegProjectionFaithful] at hfaith
    | cons ax rx =>
      cases pArgs with
      | nil => cases ax <;> simp [SegProjectionFaithful] at hfaith
      | cons ap rp =>
        cases segs with
        | nil => simp [synthSegSlotsSums] at hsynth
        | cons seg rsegs =>
          cases ax <;> cases ap
          case litSpan.litSpan =>
            rcases hfaith with ⟨_, _, hrf⟩
            cases seg with
            | lit _ =>
              simpa [synthCertSegSlotsSums, synthSegSlotsSums] using lift_synthSlotsSums rx hrf hsynth
            | slot _ _ => simp [synthSegSlotsSums] at hsynth
            | child _ _ => simp [synthSegSlotsSums] at hsynth
          case certSlot.slotLeaf s tok =>
            rcases hfaith with ⟨_, _, _, heid, _, _, hrf⟩
            cases seg with
            | lit _ => simp [synthSegSlotsSums] at hsynth
            | child _ _ => simp [synthSegSlotsSums] at hsynth
            | slot expectedSort expectedRole =>
              unfold synthSegSlotsSums at hsynth
              cases hrec : synthSegSlotsSums rsegs rp with
              | none => rw [hrec] at hsynth; contradiction
              | some pair =>
                rw [hrec] at hsynth
                rcases pair with ⟨rSlots, rSums⟩
                dsimp at hsynth
                injection hsynth with hp
                injection hp with hsl hsm
                subst slots; subst sums
                have hih := lift_synthSlotsSums rx hrf hrec
                simp [synthCertSegSlotsSums, hih, mapP2Slots, heid]
          case childNode.childNode subX subP =>
            rcases hfaith with ⟨hsubf, hrf⟩
            cases seg with
            | lit _ => simp [synthSegSlotsSums] at hsynth
            | slot _ _ => simp [synthSegSlotsSums] at hsynth
            | child _ _ =>
              unfold synthSegSlotsSums at hsynth
              cases hsub_s : synthNodeSummary subP with
              | none => rw [hsub_s] at hsynth; contradiction
              | some subSum =>
                rw [hsub_s] at hsynth
                cases hrec : synthSegSlotsSums rsegs rp with
                | none => rw [hrec] at hsynth; contradiction
                | some pair =>
                  rw [hrec] at hsynth
                  rcases pair with ⟨rSlots, rSums⟩
                  dsimp at hsynth
                  injection hsynth with hp
                  injection hp with hsl hsm
                  subst slots; subst sums
                  have hsub_ih := lift_synthNodeSummary subX hsubf hsub_s
                  have hrec_ih := lift_synthSlotsSums rx hrf hrec
                  simp [synthCertSegSlotsSums, hsub_ih, hrec_ih]
          all_goals exact False.elim hfaith

  theorem lift_synthNodeSummary {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
      {π : UntrustedDerivCert} {sum : NodeSummary}
      (hfaith : NodeProjectionFaithful x π)
      (hsynth : synthNodeSummary π = some sum) :
      synthCertNodeSummary x = some (mapP2Summary sum) := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases hfaith with ⟨_, hdec, _, _, hargs⟩
        unfold synthNodeSummary at hsynth
        rw [hdec] at hsynth
        dsimp at hsynth
        cases hseg : synthSegSlotsSums (ruleSignature r).segments pArgs with
        | none => rw [hseg] at hsynth; contradiction
        | some pair =>
          rw [hseg] at hsynth
          rcases pair with ⟨slots, sums⟩
          dsimp at hsynth
          injection hsynth with hsum
          subst sum
          have hih := lift_synthSlotsSums args hargs hseg
          simp [synthCertNodeSummary, hih, fromP2Rule_mkSum_eq_mapP2Summary]
end

mutual
  theorem lift_segLocusBound {cat numCfg maxSlotBytes}
      (args : List (CertifiedSegArg cat numCfg maxSlotBytes))
      {pArgs : List UntrustedSegArg} {loc : ClauseLocus} {segs : List RuleSegment}
      (hfaith : SegProjectionFaithful args pArgs)
      (hlb : SegLocusTargetBound loc segs pArgs) :
      CertSegLocusTargetBound args loc segs := by
    cases args with
    | nil =>
      cases pArgs with
      | nil =>
        cases segs with
        | nil => trivial
        | cons sg _ => cases sg <;> simp [SegLocusTargetBound] at hlb
      | cons _ _ => simp [SegProjectionFaithful] at hfaith
    | cons ax rx =>
      cases pArgs with
      | nil => cases ax <;> simp [SegProjectionFaithful] at hfaith
      | cons ap rp =>
        cases segs with
        | nil => simp [SegLocusTargetBound] at hlb
        | cons seg rsegs =>
          cases ax <;> cases ap
          case litSpan.litSpan =>
            rcases hfaith with ⟨_, _, hrf⟩
            cases seg with
            | lit _ => exact lift_segLocusBound rx hrf hlb
            | slot _ _ => exact False.elim hlb
            | child _ _ => exact False.elim hlb
          case certSlot.slotLeaf =>
            rcases hfaith with ⟨_, _, _, _, _, _, hrf⟩
            cases seg with
            | slot _ _ => exact lift_segLocusBound rx hrf hlb
            | lit _ => exact False.elim hlb
            | child _ _ => exact False.elim hlb
          case childNode.childNode subX subP =>
            rcases hfaith with ⟨hsubf, hrf⟩
            cases seg with
            | child _ locOpt =>
              rcases hlb with ⟨hsub_lb, hrest_lb⟩
              exact ⟨lift_nodeLocusBound subX hsubf hsub_lb, lift_segLocusBound rx hrf hrest_lb⟩
            | lit _ => exact False.elim hlb
            | slot _ _ => exact False.elim hlb
          all_goals exact False.elim hfaith

  theorem lift_nodeLocusBound {cat numCfg maxSlotBytes}
      (x : LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
      {π : UntrustedDerivCert} {loc : ClauseLocus}
      (hfaith : NodeProjectionFaithful x π)
      (hlb : NodeLocusTargetBound loc π) :
      CertNodeLocusTargetBound x loc := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases hfaith with ⟨_, hdec, _, rfl, hargs⟩
        rcases hlb with ⟨r', slots, sums, hdec', hsynth, hobls, hloc_mem, hseg_lb⟩
        rw [hdec] at hdec'
        injection hdec' with hr_eq
        subst r'
        refine ⟨mapP2Slots slots, sums.map mapP2Summary,
                lift_synthSlotsSums args hargs hsynth, ?_, hloc_mem,
                lift_segLocusBound args hargs hseg_lb⟩
        rw [f_p3a_01_universal_intrinsicObls_equivalence r loc slots sums]
        exact hobls
end

mutual
  theorem lift_validSegChain_to_validParseSegs {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {cursor endPos : Nat}
      (args : List (CertifiedSegArg cat numCfg Y.length))
      {pArgs : List UntrustedSegArg} {segs : List RuleSegment}
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (hfaith : SegProjectionFaithful args pArgs)
      (hchain : ValidSegChain env Y loc cursor segs pArgs endPos slots sums) :
      ValidParseSegs cat numCfg env Y loc cursor
        (segs.map fromP2RuleSegment) (certSegsToParseArgs args loc segs)
        endPos (mapP2Slots slots) (sums.map mapP2Summary) := by
    cases args with
    | nil =>
      cases pArgs with
      | nil =>
        cases segs with
        | nil =>
          rcases hchain with ⟨hle, hend, rfl, rfl⟩
          exact ⟨hle, hend, rfl, rfl⟩
        | cons sg _ => cases sg <;> simp [ValidSegChain] at hchain
      | cons _ _ => simp [SegProjectionFaithful] at hfaith
    | cons ax rx =>
      cases pArgs with
      | nil => cases ax <;> simp [SegProjectionFaithful] at hfaith
      | cons ap rp =>
        cases segs with
        | nil => simp [ValidSegChain] at hchain
        | cons seg rsegs =>
          cases ax <;> cases ap
          case litSpan.litSpan txt sp pTxt pSp =>
            rcases hfaith with ⟨rfl, rfl, hrf⟩
            cases seg with
            | lit expectedLit =>
              rcases hchain with ⟨htxt, hstart, hsp, hrest⟩
              exact ⟨htxt, hstart, hsp, lift_validSegChain_to_validParseSegs rx hrf hrest⟩
            | slot _ _ => exact False.elim hchain
            | child _ _ => exact False.elim hchain
          case certSlot.slotLeaf s tok =>
            rcases hfaith with ⟨hsort_tok, hsort_p3, hrole_tok, heid_tok, hlex_tok, hsp_tok, hrf⟩
            cases seg with
            | lit _ => exact False.elim hchain
            | child _ _ => exact False.elim hchain
            | slot expectedSort expectedRole =>
              rcases hchain with ⟨rSlots, htok_s, htok_r, _, hstart, hsp, hslots_eq, hrest⟩
              subst slots
              have hp3_eq : s.p3Sort = fromP2SlotSort expectedSort := by
                rw [htok_s] at hsort_p3
                exact fromP2_of_toP2Sort hsort_p3
              have hrole_eq : s.p2Role = expectedRole := by
                rw [← hrole_tok, htok_r]
              rw [hsp_tok] at hstart hsp hrest
              rw [hlex_tok] at hsp
              have hdsv : DeclarativeSlotValid cat numCfg Y.length (fromP2SlotSort expectedSort) s.entityId s.lexeme := by
                rw [← hp3_eq]
                exact certifiedBridgeSlot_declarativeValid s
              refine ⟨mapP2Slots rSlots, hp3_eq, congrArg fromP2SlotRole hrole_eq,
                      hstart, hsp, hdsv, ?_, lift_validSegChain_to_validParseSegs rx hrf hrest⟩
              simp [mapP2Slots, heid_tok]
          case childNode.childNode subX subP =>
            rcases hfaith with ⟨hsubf, hrf⟩
            cases seg with
            | lit _ => exact False.elim hchain
            | slot _ _ => exact False.elim hchain
            | child childCat locOpt =>
              rcases hchain with ⟨subSum, rSums, hstart, hsub_deriv, hsums_eq, hrest⟩
              subst sums
              have hsub_parse := lift_validNodeDeriv_to_validParseNode subX hsubf hsub_deriv
              have hloc_eq : (clauseOverrideOfIdx (fromP2LocusOpt locOpt)).getD loc = locOpt.getD loc := by
                rw [clauseOverrideOfIdx_fromP2LocusOpt]
              cases subX with
              | mkCertNode sNid sR sSp sCl sArgs =>
                cases subP with
                | mkNode pNid pRc pSp pCl pArgs_sub =>
                  rcases hsubf with ⟨_, _, rfl, _, _⟩
                  dsimp [certTreeToParseTree, ConcreteParseTree.span] at hstart hrest hsub_parse ⊢
                  refine ⟨mapP2Summary subSum, rSums.map mapP2Summary, hstart, ?_, rfl,
                          lift_validSegChain_to_validParseSegs rx hrf hrest⟩
                  rw [hloc_eq]
                  exact hsub_parse
          all_goals exact False.elim hfaith

  theorem lift_validNodeDeriv_to_validParseNode {cat : ClosedEntityCatalog} {numCfg : NumericGateConfig}
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {expectedCat : NontermCat}
      (x : LexicallyCertifiedDerivTree cat numCfg Y.length)
      {π : UntrustedDerivCert} {outSum : NodeSummary}
      (hfaith : NodeProjectionFaithful x π)
      (hderiv : ValidNodeDeriv env Y loc expectedCat π outSum) :
      ValidParseNode cat numCfg env Y loc (fromP2Nonterm expectedCat)
        (certTreeToParseTree x loc) (mapP2Summary outSum) := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases hfaith with ⟨_, hdec, rfl, _, hargs⟩
        rcases hderiv with ⟨r', slots, sums, hdec', hlhs, hsegs, hside, _, hout⟩
        rw [hdec] at hdec'
        injection hdec' with hr_eq
        subst r'; subst outSum
        have ⟨hlhs_corr, hrhs_corr⟩ := f_p3a_01_p2_ruleSignature_matches_p3b_interleaved r
        have hsegs_parse := lift_validSegChain_to_validParseSegs args hargs hsegs
        rw [hrhs_corr] at hsegs_parse
        have hside_parse : (frozenProdSig (fromP2Rule r)).checkSide env (mapP2Slots slots) (sums.map mapP2Summary) = true := by
          rw [f_p3a_01_universal_sidecond_equivalence r env slots sums]
          exact hside
        have halt_le : 1 ≤ (fromP2Rule r).altCount := by
          rw [fromP2Rule_altCount_eq_one r]; decide
        refine ⟨mapP2Slots slots, sums.map mapP2Summary, rfl, ?_, by decide, halt_le,
                hsegs_parse, hside_parse, ?_⟩
        · rw [← hlhs_corr, hlhs]
        · exact (fromP2Rule_mkSum_eq_mapP2Summary r slots sums).symm
end

/-! ### 7. Master Gate D Theorems (`BridgeSound` & End-to-End 3-Module Unification) -/

/--
  **Master Theorem `BridgeSound` (`Gate D`)**:
  Directly connects `BrocaOmega.P3A.CertifiedLexicalSlot`, `ProjectionFaithful x π`, and
  `BrocaOmega.P2.replayDerivation env Y deltaIn π = .accepted wP2`, lifting ALL lexical,
  grammatical, span-yield, locus-target, and linear multiset guarantees back onto the
  ORIGINAL `x : LexicallyCertifiedDerivTree`!
-/
theorem BridgeSound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (x : LexicallyCertifiedDerivTree cat numCfg Y.toList.length)
    (π : BrocaOmega.P2.UntrustedDerivCert)
    (wP2 : BrocaOmega.P2.CertifiedDerivation env Y deltaIn)
    (hFaithful : ProjectionFaithful x π)
    (hReplay : BrocaOmega.P2.replayDerivation env Y deltaIn π = .accepted wP2) :
    let τ_x := certTreeToParseTree x .clause1
    AllTreeSlotsP3ACertified x ∧
    reconstructCertYield x = Y ∧
    ObligationsConservedOnCert x deltaIn ∧
    LocusTargetBoundOnCert x ∧
    collectCertSpans x = collectP2Spans π ∧
    (frozenProdSig τ_x.prod).isGenerator = true ∧
    τ_x.span = ⟨0, Y.toList.length⟩ ∧
    (∃ sum3 : ParseSummary,
      ValidParseNode cat numCfg env Y.toList .clause1 .controlledDocument τ_x sum3) := by
  rcases BrocaOmega.P2.replayDerivation_sound env Y deltaIn π wP2 hReplay with
    ⟨_, hValidDeriv, hYieldP2, hOblP2, hLocusP2⟩
  rcases hFaithful with ⟨hNodeF, hSpansEq, hOblsEq⟩
  have hYieldX : reconstructCertYield x = Y := by
    unfold reconstructCertYield
    rw [treeProjectionFaithful_yield hNodeF]
    exact hYieldP2
  have hOblX : ObligationsConservedOnCert x deltaIn := by
    rcases hOblP2 with ⟨hnd1, hnd2, hms⟩
    unfold ObligationsConservedOnCert
    rw [hOblsEq]
    exact ⟨hnd1, hnd2, hms⟩
  have hLocusX : LocusTargetBoundOnCert x :=
    lift_nodeLocusBound x hNodeF hLocusP2
  rcases hValidDeriv with ⟨hRootSp, sum2, hNodeDeriv⟩
  have hParseNode := lift_validNodeDeriv_to_validParseNode x hNodeF hNodeDeriv
  have hGenAndSp :
      (frozenProdSig (certTreeToParseTree x .clause1).prod).isGenerator = true ∧
      (certTreeToParseTree x .clause1).span = ⟨0, Y.toList.length⟩ := by
    cases x with
    | mkCertNode nid r sp claimed args =>
      cases π with
      | mkNode pNid rawCode pSp pClaimed pArgs =>
        rcases hNodeF with ⟨_, _, hpSp, _, _⟩
        dsimp at hRootSp
        rw [hpSp] at hRootSp
        exact ⟨fromP2Rule_isGenerator r, hRootSp⟩
  exact ⟨allTreeSlots_hold x, hYieldX, hOblX, hLocusX, hSpansEq,
         hGenAndSp.1, hGenAndSp.2, mapP2Summary sum2, hParseNode⟩

/--
  **3-Module End-to-End Unification Theorem (`BridgeSound_mem_enumerated_forest`)**:
  Combines:
  1. `P3-A` raw-byte ingress (`admitStrictAsciiIngress`) + `CertifiedLexicalSlot` slot witnesses on `x`,
  2. `ProjectionFaithful x π`,
  3. `P2` derivation replay (`replayDerivation env wIng.decoded deltaIn π = .accepted wP2`), AND
  4. `P3-B` bounded exhaustive parsing (`parseAllBounded ... rawBytes = .enumerated T`),
  proving `ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree x .clause1)` AND
  membership `certTreeToParseTree x .clause1 ∈ T`!
-/
theorem BridgeSound_mem_enumerated_forest
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (budget : ResourceBudget)
    (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (wIng : BrocaOmega.P3A.VerifiedIngressText maxIngressBytes)
    (hIng : BrocaOmega.P3A.admitStrictAsciiIngress maxIngressBytes rawBytes = .ok wIng)
    (deltaIn : List ObligationToken)
    (x : LexicallyCertifiedDerivTree cat numCfg wIng.decoded.toList.length)
    (π : BrocaOmega.P2.UntrustedDerivCert)
    (wP2 : BrocaOmega.P2.CertifiedDerivation env wIng.decoded deltaIn)
    (hFaithful : ProjectionFaithful x π)
    (hReplay : BrocaOmega.P2.replayDerivation env wIng.decoded deltaIn π = .accepted wP2) :
    let τ_x := certTreeToParseTree x .clause1
    ValidParse_GFrozen cat numCfg env rawBytes τ_x ∧
    (∀ T : List ConcreteParseTree,
      parseAllBounded cat numCfg env budget rawBytes = .enumerated T → τ_x ∈ T) := by
  have ⟨hRawEq, hStrict⟩ := BrocaOmega.P3A.admitStrictAsciiIngress_sound maxIngressBytes rawBytes wIng hIng
  have hDom : StrictAsciiDomainSupported rawBytes := ⟨hStrict.1, hStrict.2.2⟩
  have hbs := BridgeSound cat numCfg env wIng.decoded deltaIn x π wP2 hFaithful hReplay
  rcases hbs with ⟨_, _, _, _, _, _, hSp, sum3, hParseNode⟩
  have hDecEq : wIng.decoded = decodeAsciiBytes rawBytes := by
    rw [wIng.hDecoded, hRawEq]
  have hValidGF : ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree x .clause1) := by
    unfold ValidParse_GFrozen
    rw [← hDecEq]
    exact ⟨hDom, hSp, sum3, hParseNode⟩
  refine ⟨hValidGF, ?_⟩
  intro T henum
  exact ((parseAllBounded_enumerated_sound_and_complete cat numCfg env budget rawBytes T henum).2.2.2.2 _).mpr hValidGF

/-! ### 8. Executable End-to-End Slot-Certification + Replay Gate (`verifyBridgedDerivation`) -/

inductive BridgeRejectDiag where
  | ingressRejected       (diag : LexicalRejectDiag)
  | forgedOrTrapRuleCode  (nodeId rawRuleCode : Nat)
  | nonAsciiSlotLexeme    (nodeId : Nat) (lexeme : String)
  | slotLexicalRejected   (nodeId : Nat) (diag : LexicalRejectDiag)
  | projectionTampered
  | p2ReplayRejected      (diag : CEGESReplayDiag)
  deriving DecidableEq, Repr

/-- Certifies a single untrusted `P2.SlotToken` through `BrocaOmega.P3A.admitLexicalSlot`! -/
def certifySlotToken (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (maxSlotBytes : Nat) (nodeId : Nat) (tok : SlotToken) :
    Except BridgeRejectDiag (CertifiedBridgeSlot cat numCfg maxSlotBytes) :=
  let p3s := fromP2SlotSort tok.sort
  let cand : RawSlotCandidate :=
    { sort := p3s, entityId := tok.entityId, rawBytes := strToAsciiBytes tok.lexeme }
  if hdec_b : eqStrBool cand.decodedStr tok.lexeme = true then
    match BrocaOmega.P3A.admitLexicalSlot cat numCfg maxSlotBytes cand with
    | .rejected d => .error (.slotLexicalRejected nodeId d)
    | .accepted w =>
      .ok { lexeme     := tok.lexeme
            entityId   := tok.entityId
            p3Sort     := p3s
            p2Sort     := tok.sort
            p2Role     := tok.role
            span       := tok.span
            witness    := w
            hDecodedEq := (eqStrBool_iff cand.decodedStr tok.lexeme).mp hdec_b
            hSortProj  := toP2SlotSort_fromP2SlotSort tok.sort }
  else
    .error (.nonAsciiSlotLexeme nodeId tok.lexeme)

mutual
  def certifySegArgs (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (maxSlotBytes : Nat) (nodeId : Nat) :
      List UntrustedSegArg →
      Except BridgeRejectDiag (List (CertifiedSegArg cat numCfg maxSlotBytes))
    | [] => .ok []
    | .litSpan txt sp :: rest =>
      match certifySegArgs cat numCfg maxSlotBytes nodeId rest with
      | .error e => .error e
      | .ok rCert => .ok (.litSpan txt sp :: rCert)
    | .slotLeaf tok :: rest =>
      match certifySlotToken cat numCfg maxSlotBytes nodeId tok with
      | .error e => .error e
      | .ok sCert =>
        match certifySegArgs cat numCfg maxSlotBytes nodeId rest with
        | .error e => .error e
        | .ok rCert => .ok (.certSlot sCert :: rCert)
    | .childNode sub :: rest =>
      match certifyDerivTree cat numCfg maxSlotBytes sub with
      | .error e => .error e
      | .ok subCert =>
        match certifySegArgs cat numCfg maxSlotBytes nodeId rest with
        | .error e => .error e
        | .ok rCert => .ok (.childNode subCert :: rCert)

  /--
    Walks an untrusted `UntrustedDerivCert` and enforces `BrocaOmega.P3A.admitLexicalSlot`
    on EVERY slot leaf before constructing `LexicallyCertifiedDerivTree`.
  -/
  def certifyDerivTree (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
      (maxSlotBytes : Nat) :
      UntrustedDerivCert →
      Except BridgeRejectDiag (LexicallyCertifiedDerivTree cat numCfg maxSlotBytes)
    | .mkNode nid rawCode sp claimed args =>
      match decodeFrozenRule rawCode with
      | none => .error (.forgedOrTrapRuleCode nid rawCode)
      | some r =>
        match certifySegArgs cat numCfg maxSlotBytes nid args with
        | .error e => .error e
        | .ok certArgs => .ok (.mkCertNode nid r sp claimed certArgs)
end

/-- Sealed end-to-end witness combining `P3-A`, `ProjectionFaithful`, `P2` Replay, and `P3-B` `ValidParse_GFrozen`. -/
structure CertifiedBridgedDerivation (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (deltaIn : List ObligationToken) where
  private mk ::
  ingressWitness : BrocaOmega.P3A.VerifiedIngressText maxIngressBytes
  certTree       : LexicallyCertifiedDerivTree cat numCfg ingressWitness.decoded.toList.length
  loweredCert    : BrocaOmega.P2.UntrustedDerivCert
  replayWitness  : BrocaOmega.P2.CertifiedDerivation env ingressWitness.decoded deltaIn
  hFaithful      : ProjectionFaithful certTree loweredCert
  hSlotsValid    : AllTreeSlotsP3ACertified certTree
  hYieldEq       : reconstructCertYield certTree = ingressWitness.decoded
  hOblConserved  : ObligationsConservedOnCert certTree deltaIn
  hLocusBound    : LocusTargetBoundOnCert certTree
  hValidParse    : ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree certTree .clause1)

/--
  **End-to-End Bridged Verification Gate (`verifyBridgedDerivation`)**:
  1. Validates `rawBytes` via `BrocaOmega.P3A.admitStrictAsciiIngress`.
  2. Certifies all slots of `rawCandidate` via `BrocaOmega.P3A.admitLexicalSlot` (`certifyDerivTree`).
  3. Lowers `certTree` via `lowerToP2Cert` (preserving `ProjectionFaithful`) AND verifies
     `checkProjectionFaithfulBool certTree rawCandidate` so any projection tampering is rejected!
  4. Replays `loweredCert` via `BrocaOmega.P2.replayDerivation`.
-/
def verifyBridgedDerivation
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (deltaIn : List ObligationToken) (rawCandidate : BrocaOmega.P2.UntrustedDerivCert) :
    Except BridgeRejectDiag (CertifiedBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn) :=
  match hIng : BrocaOmega.P3A.admitStrictAsciiIngress maxIngressBytes rawBytes with
  | .error d => .error (.ingressRejected d)
  | .ok wIng =>
    match certifyDerivTree cat numCfg wIng.decoded.toList.length rawCandidate with
    | .error e => .error e
    | .ok x =>
      if checkProjectionFaithfulBool x rawCandidate then
        let π := lowerToP2Cert x
        let hFaith := lowerToP2Cert_projectionFaithful x
        match hRep : BrocaOmega.P2.replayDerivation env wIng.decoded deltaIn π with
        | .rejected d => .error (.p2ReplayRejected d)
        | .accepted wP2 =>
          let hbs := BridgeSound cat numCfg env wIng.decoded deltaIn x π wP2 hFaith hRep
          let hgf := (BridgeSound_mem_enumerated_forest cat numCfg env defaultParseBudget
                        maxIngressBytes rawBytes wIng hIng deltaIn x π wP2 hFaith hRep).1
          .ok ⟨wIng, x, π, wP2, hFaith, hbs.1, hbs.2.1, hbs.2.2.1, hbs.2.2.2.1, hgf⟩
      else
        .error .projectionTampered

theorem verifyBridgedDerivation_sound
    (cat : ClosedEntityCatalog) (numCfg : NumericGateConfig)
    (env : ScopeEnv) (maxIngressBytes : Nat) (rawBytes : List UInt8)
    (deltaIn : List ObligationToken) (rawCandidate : BrocaOmega.P2.UntrustedDerivCert)
    (w : CertifiedBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn)
    (_hok : verifyBridgedDerivation cat numCfg env maxIngressBytes rawBytes deltaIn rawCandidate = .ok w) :
    ProjectionFaithful w.certTree w.loweredCert ∧
    AllTreeSlotsP3ACertified w.certTree ∧
    reconstructCertYield w.certTree = w.ingressWitness.decoded ∧
    ObligationsConservedOnCert w.certTree deltaIn ∧
    LocusTargetBoundOnCert w.certTree ∧
    ValidParse_GFrozen cat numCfg env rawBytes (certTreeToParseTree w.certTree .clause1) :=
  ⟨w.hFaithful, w.hSlotsValid, w.hYieldEq, w.hOblConserved, w.hLocusBound, w.hValidParse⟩

end BrocaOmega.P3B
