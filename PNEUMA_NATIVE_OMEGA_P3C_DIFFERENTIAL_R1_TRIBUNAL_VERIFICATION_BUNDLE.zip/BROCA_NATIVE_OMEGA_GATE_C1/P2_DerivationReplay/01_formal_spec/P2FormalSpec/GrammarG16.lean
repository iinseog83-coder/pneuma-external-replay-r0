/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2FormalSpec/GrammarG16.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)
  Defines the frozen `Architecture Freeze R0` (`S0-R2.1` / `S0-R2.2` / `Gate C0-R1`)
  16-rule controlled generator grammar (`G-01` ~ `G-16`), acyclic nonterminal stratification,
  typed terminal slots, reserved syncategorematic keyword barrier, and untrusted certificate AST.
-/
import P2FormalSpec.ObligationLedger

namespace BrocaOmega.P2

/-- Quote-isolation discourse contract from `S0-R2.2` (`F-R2.1-05`). -/
inductive QuoteIsolationMode where
  | sentenceAtomic
  | discourseBound
  deriving DecidableEq, Repr

/-- Persistent scope environment `Γ_env` (`F-R1.1-02`). -/
structure ScopeEnv where
  cohortId           : String
  expectedDesignHead : String
  quoteIsolation     : QuoteIsolationMode
  deriving DecidableEq, Repr

/-- Half-open codepoint span `[startCp, endCp)`. -/
structure CodepointSpan where
  startCp : Nat
  endCp   : Nat
  deriving DecidableEq, Repr

/-- Strictly stratified acyclic nonterminal categories (`catRank` strictly increases toward root). -/
inductive NontermCat where
  | embeddedCausal      -- Rank 0: `<ExpLevel> <IntervVerbPres> <OutTerm>`
  | assocCore           -- Rank 1: Association cores (`G-03`, `G-04`, `G-14`)
  | metaNonEstabCore    -- Rank 1: Non-establishment core (`G-09`)
  | atomicCore          -- Rank 2: All single-clause cores (`G-01` ~ `G-14`)
  | scopedInitial       -- Rank 3: `"In <CohortSpec>, <AtomicCore>"`
  | scopedRepeat        -- Rank 3: `"Within this same <DesignNoun>, <AtomicCore>"`
  | scopedAssoc         -- Rank 3: `"In <CohortSpec>, <AssocCore>"`
  | scopedContrastMeta  -- Rank 3: `"within this same <DesignNoun>, <MetaNonEstabCore>"`
  | documentRoot        -- Rank 4: Root `ControlledDocument` (`DocSingle`, `G-15`, `G-16`)
  deriving DecidableEq, Repr

/-- Rank function witnessing that `G_gen` is a finite-depth DAG (zero cycles). -/
def NontermCat.rank : NontermCat → Nat
  | .embeddedCausal     => 0
  | .assocCore          => 1
  | .metaNonEstabCore   => 1
  | .atomicCore         => 2
  | .scopedInitial      => 3
  | .scopedRepeat       => 3
  | .scopedAssoc        => 3
  | .scopedContrastMeta => 3
  | .documentRoot       => 4

/-- Closed typed terminal slot categories in `G-01` ~ `G-16`. -/
inductive SlotSort where
  | cohortSpec
  | designNoun
  | followUpWindow
  | eventTerm
  | measureTerm
  | expLevel
  | outTerm
  | sourceId
  | identAssump
  | subgroupPlural
  | subgroupSingular
  | covariateList
  | assocDir         -- Closed: "positively" | "inversely"
  | ratioMetric      -- Closed: "risk ratio" | "odds ratio" | "hazard ratio"
  | intervDirVerb    -- Closed: "increase" | "reduce"
  | intervVerbPres   -- Closed: "causes" | "increases" | "reduces"
  | numericLit       -- Validated decimal/integer literal string
  deriving DecidableEq, Repr

/-- Positional role tag within a grammar production for deterministic obligation target assembly. -/
inductive SlotRole where
  | cohort
  | design
  | window
  | eventA
  | eventB
  | measure
  | activeExp
  | refExp
  | outcome
  | source
  | assumption
  | subgroup
  | covariates
  | direction
  | metric1
  | metric2
  | verb
  | numK
  | numN
  | numPct
  | numEst
  | numDisp1
  | numDisp2
  | numCILevel
  | numCILow
  | numCIHigh
  | numPVal
  | numAlpha
  | numMarginLow
  | numMarginHigh
  deriving DecidableEq, Repr

/-- Typed terminal slot token submitted inside an untrusted derivation certificate. -/
structure SlotToken where
  sort     : SlotSort
  role     : SlotRole
  entityId : String
  lexeme   : String
  span     : CodepointSpan
  deriving DecidableEq, Repr

/-! ### Reserved Syncategorematic Barrier & Printable ASCII Checks -/

def isPrintableAsciiChar (c : Char) : Bool :=
  ((0x20 : UInt32) ≤ c.val) && (c.val ≤ (0x7E : UInt32))

def isPrintableAsciiStr (s : String) : Bool :=
  !s.isEmpty && s.toList.all isPrintableAsciiChar

/-- Pure `List Char` contiguous sublist test (`needle` occurs in `haystack`). -/
def isPrefixChars : List Char → List Char → Bool
  | [], _ => true
  | _ :: _, [] => false
  | n :: ns, h :: hs => (n == h) && isPrefixChars ns hs

def containsSubstrChars (needle : List Char) : List Char → Bool
  | [] => needle.isEmpty
  | h :: hs => isPrefixChars needle (h :: hs) || containsSubstrChars needle hs

def containsSubstr (s sub : String) : Bool :=
  containsSubstrChars sub.toList s.toList

/-- Reserved structural delimiters forbidden inside open entity/phrase slots (`S0-R2.1` Barrier). -/
def forbiddenSlotDelimiters : List String :=
  [ ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same" ]

def isDigitChar (c : Char) : Bool :=
  (('0' : Char).val ≤ c.val) && (c.val ≤ ('9' : Char).val)

def isValidNumericSurface (s : String) : Bool :=
  let cs := s.toList
  match cs with
  | [] => false
  | '-' :: '0' :: rest =>
    -- Forbid `-0` and `-0.0...` (`F-C0-01` negative zero surface check)
    if rest.all (fun c => c == '0' || c == '.') then false
    else rest.all (fun c => isDigitChar c || c == '.')
  | '-' :: d :: rest =>
    isDigitChar d && rest.all (fun c => isDigitChar c || c == '.')
  | d :: rest =>
    isDigitChar d && rest.all (fun c => isDigitChar c || c == '.')

/-- Validates that a `SlotToken` lexeme obeys ASCII, closed-class, numeric, and keyword-barrier rules. -/
def isValidSlotLexeme (sort : SlotSort) (lex : String) : Bool :=
  if !isPrintableAsciiStr lex then false
  else
    match sort with
    | .assocDir       => (lex == "positively") || (lex == "inversely")
    | .ratioMetric    => (lex == "risk ratio") || (lex == "odds ratio") || (lex == "hazard ratio")
    | .intervDirVerb  => (lex == "increase") || (lex == "reduce")
    | .intervVerbPres => (lex == "causes") || (lex == "increases") || (lex == "reduces")
    | .numericLit     => isValidNumericSurface lex
    | _               => forbiddenSlotDelimiters.all (fun bad => !containsSubstr lex bad)

/-! ### Frozen Canonical Generator Rules (`G-01` ~ `G-16` + Structural Envelopes) -/

/--
  Closed enumeration of ALL legal generator rules in `Architecture Freeze R0`.
  Note: Trap rules `T1`~`T5` (IDs `901`~`905`) and unknown IDs are NOT in `FrozenGenRule`,
  so `decodeFrozenRule` deterministically rejects them (`forgedOrTrapRuleId`).
-/
inductive FrozenGenRule where
  | DocSingle               -- ID 1:   ScopedInitial(s₁) "."
  | G15_DocConjAtomic       -- ID 150: ScopedInitial(s₁) ". " ScopedInitial(s₂) "."
  | G15_DocConjDiscourse    -- ID 151: ScopedInitial(s₁) ". " ScopedRepeat(s₂) "."
  | G16_DocContrastive      -- ID 160: ScopedAssoc(s₁) "; however, " ScopedContrastMeta(s₂) "."
  | ScopedInitial           -- ID 201: "In " CohortSpec ", " AtomicCore
  | ScopedRepeatDiscourse   -- ID 202: "Within this same " DesignNoun ", " AtomicCore
  | ScopedAssoc             -- ID 203: "In " CohortSpec ", " AssocCore
  | ScopedContrastMeta      -- ID 204: "within this same " DesignNoun ", " MetaNonEstabCore
  | LiftAssocToAtomic       -- ID 210: AssocCore -> AtomicCore
  | LiftMetaToAtomic        -- ID 211: MetaNonEstabCore -> AtomicCore
  | EmbeddedCausal          -- ID 301: ExpLevel " " IntervVerbPres " " OutTerm
  | G01_DescIncidence       -- ID 10
  | G02a_DescMeanSD         -- ID 20
  | G02b_DescMedianIQR      -- ID 21
  | G03_AssocUnadj          -- ID 30
  | G04_AssocTemp           -- ID 40
  | G05_CompRD              -- ID 50
  | G06a_IntervDirectional  -- ID 60
  | G06b_IntervNeutral      -- ID 61
  | G07_MetaNotStatSig      -- ID 70
  | G08_MetaEquiv           -- ID 80
  | G09_MetaNonEstab        -- ID 90
  | G10_MetaUnresolved      -- ID 100
  | G11_QuantZero           -- ID 110
  | G12_QuantProperPart     -- ID 120
  | G13_QuantAtLeastOne     -- ID 130
  | G14_AssocAdj            -- ID 140
  deriving DecidableEq, Repr

/-- Canonical numeric encoding of `FrozenGenRule` (used in untrusted `DerivationCert` wire format). -/
def FrozenGenRule.toCode : FrozenGenRule → Nat
  | .DocSingle              => 1
  | .G01_DescIncidence      => 10
  | .G02a_DescMeanSD        => 20
  | .G02b_DescMedianIQR     => 21
  | .G03_AssocUnadj         => 30
  | .G04_AssocTemp          => 40
  | .G05_CompRD             => 50
  | .G06a_IntervDirectional => 60
  | .G06b_IntervNeutral     => 61
  | .G07_MetaNotStatSig     => 70
  | .G08_MetaEquiv          => 80
  | .G09_MetaNonEstab       => 90
  | .G10_MetaUnresolved     => 100
  | .G11_QuantZero          => 110
  | .G12_QuantProperPart    => 120
  | .G13_QuantAtLeastOne    => 130
  | .G14_AssocAdj           => 140
  | .G15_DocConjAtomic      => 150
  | .G15_DocConjDiscourse   => 151
  | .G16_DocContrastive     => 160
  | .ScopedInitial          => 201
  | .ScopedRepeatDiscourse  => 202
  | .ScopedAssoc            => 203
  | .ScopedContrastMeta     => 204
  | .LiftAssocToAtomic      => 210
  | .LiftMetaToAtomic       => 211
  | .EmbeddedCausal         => 301

/-- Decodes untrusted rule code `rawCode : Nat` into `Option FrozenGenRule`. -/
def decodeFrozenRule : Nat → Option FrozenGenRule
  | 1   => some .DocSingle
  | 10  => some .G01_DescIncidence
  | 20  => some .G02a_DescMeanSD
  | 21  => some .G02b_DescMedianIQR
  | 30  => some .G03_AssocUnadj
  | 40  => some .G04_AssocTemp
  | 50  => some .G05_CompRD
  | 60  => some .G06a_IntervDirectional
  | 61  => some .G06b_IntervNeutral
  | 70  => some .G07_MetaNotStatSig
  | 80  => some .G08_MetaEquiv
  | 90  => some .G09_MetaNonEstab
  | 100 => some .G10_MetaUnresolved
  | 110 => some .G11_QuantZero
  | 120 => some .G12_QuantProperPart
  | 130 => some .G13_QuantAtLeastOne
  | 140 => some .G14_AssocAdj
  | 150 => some .G15_DocConjAtomic
  | 151 => some .G15_DocConjDiscourse
  | 160 => some .G16_DocContrastive
  | 201 => some .ScopedInitial
  | 202 => some .ScopedRepeatDiscourse
  | 203 => some .ScopedAssoc
  | 204 => some .ScopedContrastMeta
  | 210 => some .LiftAssocToAtomic
  | 211 => some .LiftMetaToAtomic
  | 301 => some .EmbeddedCausal
  | _   => none

theorem decode_toCode_id (r : FrozenGenRule) : decodeFrozenRule r.toCode = some r := by
  cases r <;> rfl

/-- Ordered production segment: fixed literal terminal, typed slot leaf, or typed child subtree. -/
inductive RuleSegment where
  | lit   (text : String)
  | slot  (sort : SlotSort) (role : SlotRole)
  | child (cat : NontermCat) (locusOverride : Option ClauseLocus)
  deriving DecidableEq, Repr

/-- Summary metadata synthesized bottom-up from children for cross-slot/cross-clause side conditions. -/
structure NodeSummary where
  cohortIdOpt   : Option String := none
  designIdOpt   : Option String := none
  expOutPairOpt : Option (String × String) := none
  embeddedKey   : Option String := none
  deriving DecidableEq, Repr

def lookupRoleVal (slots : List (SlotRole × String)) (r : SlotRole) : String :=
  match slots.find? (fun p => p.1 == r) with
  | some (_, v) => v
  | none        => ""

/-- Complete declarative signature of a `FrozenGenRule`. -/
structure RuleSignature where
  lhsCat        : NontermCat
  segments      : List RuleSegment
  intrinsicObls : ClauseLocus → List (SlotRole × String) → List NodeSummary → List ObligationSpec
  checkSideCond : ScopeEnv → List (SlotRole × String) → List NodeSummary → Bool
  mkSummary     : List (SlotRole × String) → List NodeSummary → NodeSummary

/-- Master Frozen Rule Table (`G-01` ~ `G-16` + Structural Envelopes). -/
def ruleSignature : FrozenGenRule → RuleSignature
  | .DocSingle =>
    { lhsCat := .documentRoot
      segments := [.child .scopedInitial (some .clause1), .lit "."]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G15_DocConjAtomic =>
    { lhsCat := .documentRoot
      segments := [ .child .scopedInitial (some .clause1),
                    .lit ". ",
                    .child .scopedInitial (some .clause2),
                    .lit "." ]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (env.quoteIsolation == .sentenceAtomic) &&
          (c1.cohortIdOpt == some env.cohortId) &&
          (c2.cohortIdOpt == some env.cohortId)
        | _ => false
      mkSummary := fun _ _ => {} }

  | .G15_DocConjDiscourse =>
    { lhsCat := .documentRoot
      segments := [ .child .scopedInitial (some .clause1),
                    .lit ". ",
                    .child .scopedRepeat (some .clause2),
                    .lit "." ]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (env.quoteIsolation == .discourseBound) &&
          (c1.cohortIdOpt == some env.cohortId) &&
          (c2.designIdOpt == some env.expectedDesignHead)
        | _ => false
      mkSummary := fun _ _ => {} }

  | .G16_DocContrastive =>
    { lhsCat := .documentRoot
      segments := [ .child .scopedAssoc (some .clause1),
                    .lit "; however, ",
                    .child .scopedContrastMeta (some .clause2),
                    .lit "." ]
      intrinsicObls := fun _ _ ch =>
        match ch with
        | [c1, _] =>
          match c1.expOutPairOpt with
          | some (eId, oId) =>
            [{ locus := .clause2, kind := .contrastiveBoundary, target := eId ++ ":" ++ oId }]
          | none => [{ locus := .clause2, kind := .contrastiveBoundary, target := "" }]
        | _ => []
      checkSideCond := fun env _ ch =>
        match ch with
        | [c1, c2] =>
          (c1.cohortIdOpt == some env.cohortId) &&
          (c2.designIdOpt == some env.expectedDesignHead) &&
          c1.expOutPairOpt.isSome &&
          (c1.expOutPairOpt == c2.expOutPairOpt)
        | _ => false
      mkSummary := fun _ _ => {} }

  | .ScopedInitial =>
    { lhsCat := .scopedInitial
      segments := [.lit "In ", .slot .cohortSpec .cohort, .lit ", ", .child .atomicCore none]
      intrinsicObls := fun loc slots _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupRoleVal slots .cohort }]
      checkSideCond := fun env slots _ =>
        lookupRoleVal slots .cohort == env.cohortId
      mkSummary := fun slots ch =>
        { cohortIdOpt := some (lookupRoleVal slots .cohort)
          expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .ScopedRepeatDiscourse =>
    { lhsCat := .scopedRepeat
      segments := [.lit "Within this same ", .slot .designNoun .design, .lit ", ", .child .atomicCore none]
      intrinsicObls := fun loc slots _ =>
        [{ locus := loc, kind := .scopeAnchor, target := "resolve:" ++ lookupRoleVal slots .design }]
      checkSideCond := fun env slots _ =>
        lookupRoleVal slots .design == env.expectedDesignHead
      mkSummary := fun slots ch =>
        { designIdOpt := some (lookupRoleVal slots .design)
          expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .ScopedAssoc =>
    { lhsCat := .scopedAssoc
      segments := [.lit "In ", .slot .cohortSpec .cohort, .lit ", ", .child .assocCore none]
      intrinsicObls := fun loc slots _ =>
        [{ locus := loc, kind := .scopeAnchor, target := lookupRoleVal slots .cohort }]
      checkSideCond := fun env slots _ =>
        lookupRoleVal slots .cohort == env.cohortId
      mkSummary := fun slots ch =>
        { cohortIdOpt := some (lookupRoleVal slots .cohort)
          expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .ScopedContrastMeta =>
    { lhsCat := .scopedContrastMeta
      segments := [.lit "within this same ", .slot .designNoun .design, .lit ", ", .child .metaNonEstabCore none]
      intrinsicObls := fun loc slots _ =>
        [{ locus := loc, kind := .scopeAnchor, target := "resolve:" ++ lookupRoleVal slots .design }]
      checkSideCond := fun env slots _ =>
        lookupRoleVal slots .design == env.expectedDesignHead
      mkSummary := fun slots ch =>
        { designIdOpt := some (lookupRoleVal slots .design)
          expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .LiftAssocToAtomic =>
    { lhsCat := .atomicCore
      segments := [.child .assocCore none]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ ch => match ch with | [c] => c | _ => {} }

  | .LiftMetaToAtomic =>
    { lhsCat := .atomicCore
      segments := [.child .metaNonEstabCore none]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ ch => match ch with | [c] => c | _ => {} }

  | .EmbeddedCausal =>
    { lhsCat := .embeddedCausal
      segments := [.slot .expLevel .activeExp, .lit " ", .slot .intervVerbPres .verb, .lit " ", .slot .outTerm .outcome]
      intrinsicObls := fun _ _ _ => []
      checkSideCond := fun _ _ _ => true
      mkSummary := fun slots _ =>
        let act := lookupRoleVal slots .activeExp
        let vb  := lookupRoleVal slots .verb
        let out := lookupRoleVal slots .outcome
        { expOutPairOpt := some (act, out)
          embeddedKey := some (act ++ ":" ++ vb ++ ":" ++ out) } }

  | .G01_DescIncidence =>
    { lhsCat := .atomicCore
      segments := [ .lit "over ", .slot .followUpWindow .window,
                    .lit ", the cumulative incidence of ", .slot .eventTerm .eventA,
                    .lit " was ", .slot .numericLit .numK,
                    .lit " of ", .slot .numericLit .numN,
                    .lit " patients (", .slot .numericLit .numPct, .lit "%)" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descIncidence,
           target := lookupRoleVal s .window ++ ":" ++ lookupRoleVal s .eventA ++ ":" ++
                     lookupRoleVal s .numK ++ "/" ++ lookupRoleVal s .numN ++ "=" ++ lookupRoleVal s .numPct }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G02a_DescMeanSD =>
    { lhsCat := .atomicCore
      segments := [ .lit "the mean ", .slot .measureTerm .measure,
                    .lit " was ", .slot .numericLit .numEst,
                    .lit " (SD ", .slot .numericLit .numDisp1, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descDistribution,
           target := "mean_sd:" ++ lookupRoleVal s .measure ++ ":" ++ lookupRoleVal s .numEst ++ ":" ++ lookupRoleVal s .numDisp1 }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G02b_DescMedianIQR =>
    { lhsCat := .atomicCore
      segments := [ .lit "the median ", .slot .measureTerm .measure,
                    .lit " was ", .slot .numericLit .numEst,
                    .lit " (IQR ", .slot .numericLit .numDisp1,
                    .lit " to ", .slot .numericLit .numDisp2, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .descDistribution,
           target := "median_iqr:" ++ lookupRoleVal s .measure ++ ":" ++ lookupRoleVal s .numEst ++ ":" ++
                     lookupRoleVal s .numDisp1 ++ ".." ++ lookupRoleVal s .numDisp2 }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G03_AssocUnadj =>
    { lhsCat := .assocCore
      segments := [ .lit "comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .assocDir .direction,
                    .lit " associated with ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .assocMetricDir,
           target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .direction ++ ":" ++
                     lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome }]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun s _ =>
        { expOutPairOpt := some (lookupRoleVal s .activeExp, lookupRoleVal s .outcome) } }

  | .G04_AssocTemp =>
    { lhsCat := .assocCore
      segments := [ .slot .eventTerm .eventA, .lit " preceded ", .slot .eventTerm .eventB,
                    .lit ", and comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .assocDir .direction,
                    .lit " associated with ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .temporalPrecedence,
            target := lookupRoleVal s .eventA ++ "<" ++ lookupRoleVal s .eventB },
          { locus := loc, kind := .assocMetricDir,
            target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .direction ++ ":" ++
                      lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome } ]
      checkSideCond := fun _ s _ =>
        (lookupRoleVal s .eventA != lookupRoleVal s .eventB) &&
        (lookupRoleVal s .activeExp != lookupRoleVal s .refExp)
      mkSummary := fun s _ =>
        { expOutPairOpt := some (lookupRoleVal s .activeExp, lookupRoleVal s .outcome) } }

  | .G05_CompRD =>
    { lhsCat := .atomicCore
      segments := [ .lit "the absolute risk difference in ", .slot .outTerm .outcome,
                    .lit " comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .numericLit .numEst,
                    .lit " percentage points (", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .absRiskDiff,
           target := "RD:" ++ lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome }]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun _ _ => {} }

  | .G06a_IntervDirectional =>
    { lhsCat := .atomicCore
      segments := [ .lit "under ", .slot .identAssump .assumption,
                    .lit ", comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was estimated to ", .slot .intervDirVerb .verb,
                    .lit " ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh,
                    .lit ", p = ", .slot .numericLit .numPVal, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .identAssumption, target := lookupRoleVal s .assumption },
          { locus := loc, kind := .intervDirectional,
            target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .verb ++ ":" ++
                      lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome } ]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun _ _ => {} }

  | .G06b_IntervNeutral =>
    { lhsCat := .atomicCore
      segments := [ .lit "under ", .slot .identAssump .assumption,
                    .lit ", the estimated causal ", .slot .ratioMetric .metric1,
                    .lit " for ", .slot .outTerm .outcome,
                    .lit " comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .numericLit .numEst,
                    .lit " (", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh,
                    .lit "), which did not exclude no effect" ]
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .identAssumption, target := lookupRoleVal s .assumption },
          { locus := loc, kind := .intervNeutral,
            target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .activeExp ++ ":" ++
                      lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome } ]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun _ _ => {} }

  | .G07_MetaNotStatSig =>
    { lhsCat := .atomicCore
      segments := [ .lit "the observed ", .slot .ratioMetric .metric1,
                    .lit " comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " for ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric2,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh,
                    .lit ") was not statistically significant at alpha = ",
                    .slot .numericLit .numAlpha ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .metaNotStatSig,
           target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .activeExp ++ ":" ++
                     lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome ++ ":" ++ lookupRoleVal s .numAlpha }]
      checkSideCond := fun _ s _ =>
        (lookupRoleVal s .metric1 == lookupRoleVal s .metric2) &&
        (lookupRoleVal s .activeExp != lookupRoleVal s .refExp)
      mkSummary := fun _ _ => {} }

  | .G08_MetaEquiv =>
    { lhsCat := .atomicCore
      segments := [ .lit "comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " met prespecified equivalence margins (",
                    .slot .numericLit .numMarginLow, .lit " to ", .slot .numericLit .numMarginHigh,
                    .lit ") for ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% TOST CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .metaEquivMargins,
           target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .activeExp ++ ":" ++
                     lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome ++ ":" ++
                     lookupRoleVal s .numMarginLow ++ ".." ++ lookupRoleVal s .numMarginHigh }]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun _ _ => {} }

  | .G09_MetaNonEstab =>
    { lhsCat := .metaNonEstabCore
      segments := [ .lit "the analysis of ", .slot .sourceId .source,
                    .lit " did not establish that ", .child .embeddedCausal none ]
      intrinsicObls := fun loc s ch =>
        let embKey := match ch with | [c] => c.embeddedKey.getD "" | _ => ""
        [{ locus := loc, kind := .metaNonEstabNeg,
           target := lookupRoleVal s .source ++ ":" ++ embKey }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ ch =>
        { expOutPairOpt := match ch with | [c] => c.expOutPairOpt | _ => none } }

  | .G10_MetaUnresolved =>
    { lhsCat := .atomicCore
      segments := [ .lit "the analysis of ", .slot .sourceId .source,
                    .lit " did not determine whether ", .child .embeddedCausal none ]
      intrinsicObls := fun loc s ch =>
        let embKey := match ch with | [c] => c.embeddedKey.getD "" | _ => ""
        [{ locus := loc, kind := .metaUnresolvedPolar,
           target := lookupRoleVal s .source ++ ":" ++ embKey }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G11_QuantZero =>
    { lhsCat := .atomicCore
      segments := [ .lit "no ", .slot .subgroupPlural .subgroup,
                    .lit " patients developed ", .slot .eventTerm .eventA ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantZeroNeg,
           target := lookupRoleVal s .subgroup ++ ":" ++ lookupRoleVal s .eventA }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G12_QuantProperPart =>
    { lhsCat := .atomicCore
      segments := [ .lit "some, but not all, ", .slot .subgroupPlural .subgroup,
                    .lit " patients developed ", .slot .eventTerm .eventA ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantProperPart,
           target := lookupRoleVal s .subgroup ++ ":" ++ lookupRoleVal s .eventA }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G13_QuantAtLeastOne =>
    { lhsCat := .atomicCore
      segments := [ .lit "at least one ", .slot .subgroupSingular .subgroup,
                    .lit " patient developed ", .slot .eventTerm .eventA ]
      intrinsicObls := fun loc s _ =>
        [{ locus := loc, kind := .quantExistential,
           target := lookupRoleVal s .subgroup ++ ":" ++ lookupRoleVal s .eventA }]
      checkSideCond := fun _ _ _ => true
      mkSummary := fun _ _ => {} }

  | .G14_AssocAdj =>
    { lhsCat := .assocCore
      segments := [ .lit "after adjustment for ", .slot .covariateList .covariates,
                    .lit ", comparing ", .slot .expLevel .activeExp,
                    .lit " versus ", .slot .expLevel .refExp,
                    .lit " was ", .slot .assocDir .direction,
                    .lit " associated with ", .slot .outTerm .outcome,
                    .lit " (", .slot .ratioMetric .metric1,
                    .lit " = ", .slot .numericLit .numEst,
                    .lit ", ", .slot .numericLit .numCILevel,
                    .lit "% CI ", .slot .numericLit .numCILow,
                    .lit " to ", .slot .numericLit .numCIHigh, .lit ")" ]
      intrinsicObls := fun loc s _ =>
        [ { locus := loc, kind := .covariateAdjustment, target := lookupRoleVal s .covariates },
          { locus := loc, kind := .assocMetricDir,
            target := lookupRoleVal s .metric1 ++ ":" ++ lookupRoleVal s .direction ++ ":" ++
                      lookupRoleVal s .activeExp ++ ":" ++ lookupRoleVal s .refExp ++ ":" ++ lookupRoleVal s .outcome } ]
      checkSideCond := fun _ s _ => lookupRoleVal s .activeExp != lookupRoleVal s .refExp
      mkSummary := fun s _ =>
        { expOutPairOpt := some (lookupRoleVal s .activeExp, lookupRoleVal s .outcome) } }

/-! ### Acyclicity Proof of Frozen Generator Grammar (`rank` Strictly Decreases to Children) -/

theorem child_rank_lt_lhs_rank (r : FrozenGenRule) (cat : NontermCat) (locOpt : Option ClauseLocus)
    (hmem : RuleSegment.child cat locOpt ∈ (ruleSignature r).segments) :
    cat.rank < (ruleSignature r).lhsCat.rank := by
  cases r <;> simp [ruleSignature] at hmem
  all_goals
    try (rcases hmem with ⟨rfl, _⟩ | ⟨rfl, _⟩ <;> decide)
    try (rcases hmem with ⟨rfl, _⟩; decide)

/-! ### Untrusted Derivation Certificate AST (Submitted by Untrusted Generator) -/

mutual
  /-- Argument item corresponding to a `RuleSegment` inside `UntrustedDerivCert`. -/
  inductive UntrustedSegArg where
    | litSpan (claimedText : String) (span : CodepointSpan)
    | slotLeaf (tok : SlotToken)
    | childNode (sub : UntrustedDerivCert)
    deriving Repr

  /-- Untrusted concrete syntax derivation tree submitted to `replayDerivation`. -/
  inductive UntrustedDerivCert where
    | mkNode
        (nodeId            : Nat)
        (rawRuleCode       : Nat)
        (span              : CodepointSpan)
        (claimedDischarged : List ObligationToken)
        (segArgs           : List UntrustedSegArg)
    deriving Repr
end

/-! ### Bottom-Up Yield & Discharged Obligation Collectors -/

mutual
  def reconstructSegYield : List UntrustedSegArg → List Char
    | [] => []
    | .litSpan txt _ :: rest => txt.toList ++ reconstructSegYield rest
    | .slotLeaf tok :: rest  => tok.lexeme.toList ++ reconstructSegYield rest
    | .childNode sub :: rest => reconstructYieldChars sub ++ reconstructSegYield rest

  def reconstructYieldChars : UntrustedDerivCert → List Char
    | .mkNode _ _ _ _ args => reconstructSegYield args
end

/-- Bottom-up reconstructed surface string from the derivation tree's terminals & slots. -/
def reconstructYield (cert : UntrustedDerivCert) : String :=
  String.ofList (reconstructYieldChars cert)

mutual
  def collectSegClaimedObls : List UntrustedSegArg → List ObligationToken
    | [] => []
    | .litSpan _ _ :: rest   => collectSegClaimedObls rest
    | .slotLeaf _ :: rest    => collectSegClaimedObls rest
    | .childNode sub :: rest => collectClaimedObls sub ++ collectSegClaimedObls rest

  /-- Collects all `ObligationToken`s across the entire derivation tree in pre-order. -/
  def collectClaimedObls : UntrustedDerivCert → List ObligationToken
    | .mkNode _ _ _ claimed args => claimed ++ collectSegClaimedObls args
end

end BrocaOmega.P2
