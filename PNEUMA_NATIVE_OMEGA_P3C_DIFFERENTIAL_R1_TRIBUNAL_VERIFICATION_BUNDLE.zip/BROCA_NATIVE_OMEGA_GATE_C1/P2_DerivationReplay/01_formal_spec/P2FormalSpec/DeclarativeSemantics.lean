/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2FormalSpec/DeclarativeSemantics.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)
  Defines the algorithm-independent declarative reference relations (`Prop`):
    1. `ValidGrammarDerivation` (Frozen G-01..G-16 rule membership, sort typing, acyclic hierarchy & side conditions)
    2. `ExactSpanPartition` & `SpanMatches` (Gap-free, overlap-free span partition & `Yield(π) = Y`)
    3. `LocusTargetBound` (Every node's obligations match the intrinsic rule, clause locus & slot targets)
    4. `ObligationsConserved` (No-dup IDs & exact free-commutative-monoid multiset equality with `Δ_in`)
-/
import P2FormalSpec.GrammarG16

namespace BrocaOmega.P2

/-! ### 1. Exact Prefix-Slice Algebra (`SpanMatches`) -/

/--
  `SpanMatches Y sp seg` holds iff `Y` decomposes as `pre ++ seg ++ post` where
  `pre.length = sp.startCp` and `sp.endCp = sp.startCp + seg.length`.
  Guarantees `0 ≤ startCp ≤ endCp ≤ Y.length` and exact character-slice identity.
-/
def SpanMatches (Y : List Char) (sp : CodepointSpan) (seg : List Char) : Prop :=
  sp.endCp = sp.startCp + seg.length ∧
  ∃ pre post : List Char, Y = pre ++ seg ++ post ∧ pre.length = sp.startCp

theorem spanMatches_empty {Y : List Char} {pos : Nat} (hle : pos ≤ Y.length) :
    SpanMatches Y ⟨pos, pos⟩ [] := by
  refine ⟨by simp, Y.take pos, Y.drop pos, ?_, ?_⟩
  · simp [List.take_append_drop]
  · exact List.length_take_of_le hle

private theorem append_eq_of_eq_len {α : Type} {l₁ r₁ l₂ r₂ : List α}
    (heq : l₁ ++ r₁ = l₂ ++ r₂) (hlen : l₁.length = l₂.length) :
    l₁ = l₂ ∧ r₁ = r₂ := by
  induction l₁ generalizing l₂ with
  | nil =>
    cases l₂ with
    | nil => exact ⟨rfl, heq⟩
    | cons _ _ => simp at hlen
  | cons x xs ih =>
    cases l₂ with
    | nil => simp at hlen
    | cons y ys =>
      simp at heq hlen
      have ⟨hxs, hrs⟩ := ih heq.2 hlen
      rw [heq.1, hxs]
      exact ⟨rfl, hrs⟩

/-- Contiguous Span Composition: `[a, b)` matching `s₁` + `[b, c)` matching `s₂` => `[a, c)` matches `s₁ ++ s₂`! -/
theorem spanMatches_concat {Y : List Char} {a b c : Nat} {s₁ s₂ : List Char}
    (h₁ : SpanMatches Y ⟨a, b⟩ s₁) (h₂ : SpanMatches Y ⟨b, c⟩ s₂) :
    SpanMatches Y ⟨a, c⟩ (s₁ ++ s₂) := by
  rcases h₁ with ⟨hb, pre₁, post₁, hy₁, hlen₁⟩
  rcases h₂ with ⟨hc, pre₂, post₂, hy₂, hlen₂⟩
  change b = a + s₁.length at hb
  change c = b + s₂.length at hc
  change pre₁.length = a at hlen₁
  change pre₂.length = b at hlen₂
  have hcomb : (pre₁ ++ s₁) ++ post₁ = pre₂ ++ (s₂ ++ post₂) := by
    calc
      (pre₁ ++ s₁) ++ post₁ = pre₁ ++ s₁ ++ post₁ := rfl
      _ = Y := hy₁.symm
      _ = pre₂ ++ s₂ ++ post₂ := hy₂
      _ = pre₂ ++ (s₂ ++ post₂) := by rw [List.append_assoc]
  have hlen_eq : (pre₁ ++ s₁).length = pre₂.length := by
    rw [List.length_append, hlen₁, hlen₂, hb]
  have ⟨_, hpost⟩ := append_eq_of_eq_len hcomb hlen_eq
  refine ⟨?_, pre₁, post₂, ?_, hlen₁⟩
  · change c = a + (s₁ ++ s₂).length
    rw [List.length_append]
    omega
  · calc
      Y = (pre₁ ++ s₁) ++ post₁ := hy₁
      _ = (pre₁ ++ s₁) ++ (s₂ ++ post₂) := by rw [hpost]
      _ = pre₁ ++ (s₁ ++ s₂) ++ post₂ := by simp [List.append_assoc]

/-- Root Span Completeness: matching `[0, Y.length)` forces exact whole-string identity `seg = Y`! -/
theorem spanMatches_full_eq {Y seg : List Char}
    (h : SpanMatches Y ⟨0, Y.length⟩ seg) : seg = Y := by
  rcases h with ⟨hend, pre, post, hy, hpre_len⟩
  dsimp at hend hpre_len
  cases pre with
  | cons _ _ => simp at hpre_len
  | nil =>
    simp at hy hend
    have hlen_y : Y.length = seg.length + post.length := by
      rw [hy, List.length_append]
    have hpost_len : post.length = 0 := by omega
    cases post with
    | cons _ _ => simp at hpost_len
    | nil =>
      simp at hy
      exact hy.symm

/-- Soundness of computable slice check `checkSpanMatchesBool`. -/
def checkSpanMatchesBool (Y : List Char) (sp : CodepointSpan) (seg : List Char) : Bool :=
  decide (sp.endCp = sp.startCp + seg.length) &&
  decide (sp.endCp ≤ Y.length) &&
  decide (((Y.drop sp.startCp).take seg.length) = seg)

theorem checkSpanMatchesBool_sound {Y : List Char} {sp : CodepointSpan} {seg : List Char}
    (hok : checkSpanMatchesBool Y sp seg = true) : SpanMatches Y sp seg := by
  unfold checkSpanMatchesBool at hok
  simp [Bool.and_eq_true] at hok
  rcases hok with ⟨⟨hend, hle_end⟩, htake⟩
  have hstart_le : sp.startCp ≤ Y.length := by omega
  refine ⟨hend, Y.take sp.startCp, (Y.drop sp.startCp).drop seg.length, ?_, List.length_take_of_le hstart_le⟩
  have h1 : Y = Y.take sp.startCp ++ Y.drop sp.startCp := (List.take_append_drop sp.startCp Y).symm
  have h2 : Y.drop sp.startCp = seg ++ (Y.drop sp.startCp).drop seg.length := by
    have htd := (List.take_append_drop seg.length (Y.drop sp.startCp)).symm
    rw [htake] at htd
    exact htd
  calc
    Y = Y.take sp.startCp ++ (seg ++ (Y.drop sp.startCp).drop seg.length) :=
      h1.trans (congrArg (Y.take sp.startCp ++ ·) h2)
    _ = Y.take sp.startCp ++ seg ++ (Y.drop sp.startCp).drop seg.length := by
      rw [← List.append_assoc]

theorem spanMatches_implies_checkBool {Y : List Char} {sp : CodepointSpan} {seg : List Char}
    (h : SpanMatches Y sp seg) : checkSpanMatchesBool Y sp seg = true := by
  rcases h with ⟨hend, pre, post, hy, hpre_len⟩
  unfold checkSpanMatchesBool
  have hlen_y : Y.length = pre.length + seg.length + post.length := by
    rw [hy, List.length_append, List.length_append]
  have hbound : sp.startCp + seg.length ≤ Y.length := by omega
  have hdrop : Y.drop sp.startCp = seg ++ post := by
    rw [hy, List.append_assoc, ← hpre_len]
    exact List.drop_left
  have htake : (Y.drop sp.startCp).take seg.length = seg := by
    rw [hdrop]
    exact List.take_left
  simp [hend, hbound, htake]

/-! ### 2. Declarative Reference Relations (`Prop`) for Grammar, Spans, Locus & Obligations -/

/-
  Declarative Reference Relations (`Prop`):
  `ValidSegChain` and `ValidNodeDeriv` specify valid typing, contiguous non-overlapping spans,
  exact literal/slot slices against `Y`, rule side conditions, and `LocusTargetBound` by
  structural recursion over the finite certificate AST.
-/
mutual
  def ValidSegChain (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (cursor : Nat) (segs : List RuleSegment) (args : List UntrustedSegArg)
      (endPos : Nat) (slots : List (SlotRole × String)) (sums : List NodeSummary) : Prop :=
    match segs, args with
    | [], [] =>
      cursor ≤ Y.length ∧ endPos = cursor ∧ slots = [] ∧ sums = []
    | .lit txt :: restSegs, .litSpan claimed sp :: restArgs =>
      claimed = txt ∧
      sp.startCp = cursor ∧
      SpanMatches Y sp claimed.toList ∧
      ValidSegChain env Y loc sp.endCp restSegs restArgs endPos slots sums
    | .slot expectedSort expectedRole :: restSegs, .slotLeaf tok :: restArgs =>
      ∃ restSlots : List (SlotRole × String),
        tok.sort = expectedSort ∧
        tok.role = expectedRole ∧
        isValidSlotLexeme expectedSort tok.lexeme = true ∧
        tok.span.startCp = cursor ∧
        SpanMatches Y tok.span tok.lexeme.toList ∧
        slots = (expectedRole, tok.entityId) :: restSlots ∧
        ValidSegChain env Y loc tok.span.endCp restSegs restArgs endPos restSlots sums
    | .child cat locOpt :: restSegs, .childNode sub :: restArgs =>
      ∃ (subSum : NodeSummary) (restSums : List NodeSummary),
        (match sub with | .mkNode _ _ sp _ _ => sp.startCp) = cursor ∧
        ValidNodeDeriv env Y (locOpt.getD loc) cat sub subSum ∧
        sums = subSum :: restSums ∧
        ValidSegChain env Y loc
          (match sub with | .mkNode _ _ sp _ _ => sp.endCp) restSegs restArgs endPos slots restSums
    | _, _ => False

  def ValidNodeDeriv (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (expectedCat : NontermCat) (cert : UntrustedDerivCert) (outSum : NodeSummary) : Prop :=
    match cert with
    | .mkNode _ rawCode sp claimed args =>
      ∃ (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary),
        decodeFrozenRule rawCode = some r ∧
        (ruleSignature r).lhsCat = expectedCat ∧
        ValidSegChain env Y loc sp.startCp (ruleSignature r).segments args sp.endCp slots sums ∧
        (ruleSignature r).checkSideCond env slots sums = true ∧
        claimed.map (·.spec) = (ruleSignature r).intrinsicObls loc slots sums ∧
        outSum = (ruleSignature r).mkSummary slots sums
end

/-- Root-level Valid Grammar & Span Derivation over `Y`. -/
def ValidGrammarDerivation (env : ScopeEnv) (Y : String) (cert : UntrustedDerivCert) : Prop :=
  (match cert with | .mkNode _ _ sp _ _ => sp = ⟨0, Y.toList.length⟩) ∧
  ∃ sum : NodeSummary, ValidNodeDeriv env Y.toList .clause1 .documentRoot cert sum

/- Pure structural extraction of slot `(role, entityId)` pairs and child `NodeSummary` values from `UntrustedDerivCert`. -/
mutual
  def synthSegSlotsSums : List RuleSegment → List UntrustedSegArg →
      Option (List (SlotRole × String) × List NodeSummary)
    | [], [] => some ([], [])
    | .lit _ :: rs, .litSpan _ _ :: as => synthSegSlotsSums rs as
    | .slot _ expectedRole :: rs, .slotLeaf tok :: as =>
      match synthSegSlotsSums rs as with
      | some (slots, sums) => some ((expectedRole, tok.entityId) :: slots, sums)
      | none => none
    | .child _ _ :: rs, .childNode sub :: as =>
      match synthNodeSummary sub, synthSegSlotsSums rs as with
      | some subSum, some (slots, sums) => some (slots, subSum :: sums)
      | _, _ => none
    | _, _ => none

  def synthNodeSummary : UntrustedDerivCert → Option NodeSummary
    | .mkNode _ rawCode _ _ args =>
      match decodeFrozenRule rawCode with
      | none => none
      | some r =>
        match synthSegSlotsSums (ruleSignature r).segments args with
        | some (slots, sums) => some ((ruleSignature r).mkSummary slots sums)
        | none => none
end

/-
  Explicit Structural Predicate: Every node's `claimedDischarged` specs match:
  1. Exact syntactic `ClauseLocus` licensing (`clause1` vs `clause2`), AND
  2. Exact rule-intrinsic `(locus, kind, target)` obligation list synthesized from its own slots & children!
-/
mutual
  def SegLocusTargetBound (loc : ClauseLocus) :
      List RuleSegment → List UntrustedSegArg → Prop
    | [], [] => True
    | .lit _ :: rs, .litSpan _ _ :: as => SegLocusTargetBound loc rs as
    | .slot _ _ :: rs, .slotLeaf _ :: as => SegLocusTargetBound loc rs as
    | .child _ locOpt :: rs, .childNode sub :: as =>
        NodeLocusTargetBound (locOpt.getD loc) sub ∧ SegLocusTargetBound loc rs as
    | _, _ => False

  def NodeLocusTargetBound (loc : ClauseLocus) : UntrustedDerivCert → Prop
    | .mkNode _ rawCode _ claimed args =>
      ∃ (r : FrozenGenRule) (slots : List (SlotRole × String)) (sums : List NodeSummary),
        decodeFrozenRule rawCode = some r ∧
        synthSegSlotsSums (ruleSignature r).segments args = some (slots, sums) ∧
        claimed.map (·.spec) = (ruleSignature r).intrinsicObls loc slots sums ∧
        (∀ o ∈ claimed, o.spec.locus = loc ∨ (r = .G16_DocContrastive ∧ o.spec.locus = .clause2)) ∧
        SegLocusTargetBound loc (ruleSignature r).segments args
end

/-- Root-level Locus & Target Binding Predicate (`LocusTargetBound`). -/
def LocusTargetBound (cert : UntrustedDerivCert) : Prop :=
  NodeLocusTargetBound .clause1 cert

/-- Linear Obligation Conservation (`ObligationsConserved`): duplicate-free IDs & exact multiset equality! -/
def ObligationsConserved (cert : UntrustedDerivCert) (deltaIn : List ObligationToken) : Prop :=
  NoDupOblIds deltaIn ∧
  NoDupOblIds (collectClaimedObls cert) ∧
  MultisetEq (collectClaimedObls cert) deltaIn

/-! ### 3. Fundamental Structural Theorems on `ValidNodeDeriv` (Yield & Locus-Target Invariants) -/

mutual
  theorem validSegChain_spanMatches
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {segs : List RuleSegment}
      (args : List UntrustedSegArg)
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (h : ValidSegChain env Y loc cursor segs args endPos slots sums) :
      SpanMatches Y ⟨cursor, endPos⟩ (reconstructSegYield args) := by
    match segs, args with
    | [], [] =>
      rcases h with ⟨hle, rfl, _, _⟩
      simpa [reconstructSegYield] using spanMatches_empty hle
    | .lit txt :: restSegs, .litSpan claimed sp :: restArgs =>
      rcases h with ⟨_, hstart, hspan, hrest⟩
      have hih := validSegChain_spanMatches restArgs hrest
      rcases sp with ⟨sCp, eCp⟩
      dsimp at hstart
      subst hstart
      simpa [reconstructSegYield] using spanMatches_concat hspan hih
    | .slot expectedSort expectedRole :: restSegs, .slotLeaf tok :: restArgs =>
      rcases h with ⟨restSlots, _, _, _, hstart, hspan, _, hrest⟩
      have hih := validSegChain_spanMatches restArgs hrest
      rcases tok with ⟨srt, rl, eid, lex, ⟨sCp, eCp⟩⟩
      dsimp at hstart
      subst hstart
      simpa [reconstructSegYield] using spanMatches_concat hspan hih
    | .child cat locOpt :: restSegs, .childNode sub :: restArgs =>
      rcases h with ⟨subSum, restSums, hstart, hsub, _, hrest⟩
      have hsub_span := validNodeDeriv_spanMatches sub hsub
      have hih := validSegChain_spanMatches restArgs hrest
      cases sub with
      | mkNode nid rc sp cl sargs =>
        rcases sp with ⟨sCp, eCp⟩
        dsimp at hstart hsub_span hih
        subst hstart
        simpa [reconstructSegYield] using spanMatches_concat hsub_span hih
    | [], _ :: _ => exact False.elim h
    | .lit _ :: _, [] => exact False.elim h
    | .slot _ _ :: _, [] => exact False.elim h
    | .child _ _ :: _, [] => exact False.elim h
    | .lit _ :: _, .slotLeaf _ :: _ => exact False.elim h
    | .lit _ :: _, .childNode _ :: _ => exact False.elim h
    | .slot _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .slot _ _ :: _, .childNode _ :: _ => exact False.elim h
    | .child _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .child _ _ :: _, .slotLeaf _ :: _ => exact False.elim h

  theorem validNodeDeriv_spanMatches
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {cat : NontermCat}
      (cert : UntrustedDerivCert) {sum : NodeSummary}
      (h : ValidNodeDeriv env Y loc cat cert sum) :
      SpanMatches Y (match cert with | .mkNode _ _ sp _ _ => sp) (reconstructYieldChars cert) := by
    cases cert with
    | mkNode nid rawCode sp claimed args =>
      rcases h with ⟨r, slots, sums, _, _, hsegs, _, _, _⟩
      simpa [reconstructYieldChars] using validSegChain_spanMatches args hsegs
end

/-- Theorem: Any `ValidGrammarDerivation` reconstructs the EXACT target string `Y` (`Yield(π) = Y`)! -/
theorem validGrammarDerivation_yield_eq
    {env : ScopeEnv} {Y : String} {cert : UntrustedDerivCert}
    (h : ValidGrammarDerivation env Y cert) :
    reconstructYield cert = Y := by
  rcases h with ⟨hroot_sp, sum, hderiv⟩
  have hmatch := validNodeDeriv_spanMatches cert hderiv
  cases cert with
  | mkNode nid rc sp cl args =>
    dsimp at hroot_sp hmatch
    rw [hroot_sp] at hmatch
    have hchars : reconstructYieldChars (.mkNode nid rc sp cl args) = Y.toList :=
      spanMatches_full_eq hmatch
    unfold reconstructYield
    rw [hchars, String.ofList_toList]

theorem intrinsicObls_locus_valid (r : FrozenGenRule) (loc : ClauseLocus)
    (slots : List (SlotRole × String)) (sums : List NodeSummary) :
    ∀ s ∈ (ruleSignature r).intrinsicObls loc slots sums,
      s.locus = loc ∨ (r = .G16_DocContrastive ∧ s.locus = .clause2) := by
  intro s hs
  cases r <;> simp [ruleSignature] at hs
  all_goals
    try (subst hs; left; rfl)
  · -- G16_DocContrastive
    split at hs
    · split at hs
      · simp at hs; subst hs; right; exact ⟨rfl, rfl⟩
      · simp at hs; subst hs; right; exact ⟨rfl, rfl⟩
    · simp at hs
  · -- G04_AssocTemp
    rcases hs with h1 | h2
    · subst h1; left; rfl
    · subst h2; left; rfl
  · -- G06a_IntervDirectional
    rcases hs with h1 | h2
    · subst h1; left; rfl
    · subst h2; left; rfl
  · -- G06b_IntervNeutral
    rcases hs with h1 | h2
    · subst h1; left; rfl
    · subst h2; left; rfl
  · -- G14_AssocAdj
    rcases hs with h1 | h2
    · subst h1; left; rfl
    · subst h2; left; rfl

mutual
  theorem validSegChain_synth_eq
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {segs : List RuleSegment}
      (args : List UntrustedSegArg)
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (h : ValidSegChain env Y loc cursor segs args endPos slots sums) :
      synthSegSlotsSums segs args = some (slots, sums) := by
    match segs, args with
    | [], [] =>
      rcases h with ⟨_, _, rfl, rfl⟩
      rfl
    | .lit _ :: _, .litSpan _ _ :: restArgs =>
      rcases h with ⟨_, _, _, hrest⟩
      simpa [synthSegSlotsSums] using validSegChain_synth_eq restArgs hrest
    | .slot _ _ :: _, .slotLeaf _ :: restArgs =>
      rcases h with ⟨restSlots, _, _, _, _, _, rfl, hrest⟩
      have hih := validSegChain_synth_eq restArgs hrest
      simp [synthSegSlotsSums, hih]
    | .child _ _ :: _, .childNode sub :: restArgs =>
      rcases h with ⟨subSum, restSums, _, hsub, rfl, hrest⟩
      have hsub_eq := validNodeDeriv_synth_eq sub hsub
      have hih := validSegChain_synth_eq restArgs hrest
      simp [synthSegSlotsSums, hsub_eq, hih]
    | [], _ :: _ => exact False.elim h
    | .lit _ :: _, [] => exact False.elim h
    | .slot _ _ :: _, [] => exact False.elim h
    | .child _ _ :: _, [] => exact False.elim h
    | .lit _ :: _, .slotLeaf _ :: _ => exact False.elim h
    | .lit _ :: _, .childNode _ :: _ => exact False.elim h
    | .slot _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .slot _ _ :: _, .childNode _ :: _ => exact False.elim h
    | .child _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .child _ _ :: _, .slotLeaf _ :: _ => exact False.elim h

  theorem validNodeDeriv_synth_eq
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {cat : NontermCat}
      (cert : UntrustedDerivCert) {sum : NodeSummary}
      (h : ValidNodeDeriv env Y loc cat cert sum) :
      synthNodeSummary cert = some sum := by
    cases cert with
    | mkNode nid rawCode sp claimed args =>
      rcases h with ⟨r, slots, sums, hrule, _, hsegs, _, _, rfl⟩
      have hseg_eq := validSegChain_synth_eq args hsegs
      simp [synthNodeSummary, hrule, hseg_eq]
end

mutual
  theorem validSegChain_locusBound
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      {cursor endPos : Nat} {segs : List RuleSegment}
      (args : List UntrustedSegArg)
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (h : ValidSegChain env Y loc cursor segs args endPos slots sums) :
      SegLocusTargetBound loc segs args := by
    match segs, args with
    | [], [] => trivial
    | .lit _ :: _, .litSpan _ _ :: restArgs =>
      rcases h with ⟨_, _, _, hrest⟩
      exact validSegChain_locusBound restArgs hrest
    | .slot _ _ :: _, .slotLeaf _ :: restArgs =>
      rcases h with ⟨_, _, _, _, _, _, _, hrest⟩
      exact validSegChain_locusBound restArgs hrest
    | .child _ _ :: _, .childNode sub :: restArgs =>
      rcases h with ⟨_, _, _, hsub, _, hrest⟩
      exact ⟨validNodeDeriv_locusBound sub hsub, validSegChain_locusBound restArgs hrest⟩
    | [], _ :: _ => exact False.elim h
    | .lit _ :: _, [] => exact False.elim h
    | .slot _ _ :: _, [] => exact False.elim h
    | .child _ _ :: _, [] => exact False.elim h
    | .lit _ :: _, .slotLeaf _ :: _ => exact False.elim h
    | .lit _ :: _, .childNode _ :: _ => exact False.elim h
    | .slot _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .slot _ _ :: _, .childNode _ :: _ => exact False.elim h
    | .child _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .child _ _ :: _, .slotLeaf _ :: _ => exact False.elim h

  theorem validNodeDeriv_locusBound
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {cat : NontermCat}
      (cert : UntrustedDerivCert) {sum : NodeSummary}
      (h : ValidNodeDeriv env Y loc cat cert sum) :
      NodeLocusTargetBound loc cert := by
    cases cert with
    | mkNode nid rawCode sp claimed args =>
      rcases h with ⟨r, slots, sums, hrule, _, hsegs, _, hlocus, _⟩
      refine ⟨r, slots, sums, hrule, validSegChain_synth_eq args hsegs, hlocus, ?_, validSegChain_locusBound args hsegs⟩
      intro o ho
      have hspec_mem : o.spec ∈ claimed.map (·.spec) := List.mem_map_of_mem (f := (·.spec)) ho
      rw [hlocus] at hspec_mem
      exact intrinsicObls_locus_valid r loc slots sums o.spec hspec_mem
end

theorem validGrammarDerivation_implies_locusTargetBound
    {env : ScopeEnv} {Y : String} {cert : UntrustedDerivCert}
    (h : ValidGrammarDerivation env Y cert) :
    LocusTargetBound cert := by
  rcases h with ⟨_, _, hderiv⟩
  exact validNodeDeriv_locusBound cert hderiv

end BrocaOmega.P2
