/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2FormalSpec/ObligationLedger.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)
  Formalizes free commutative monoid multiset accounting (`F-R1.1-01`),
  clause-locus and target-bound linear obligations (`Locus-Bound Obligation Discharge`),
  and decidable multiset conservation without weakening or unlicensed contraction.
-/

namespace BrocaOmega.P2

/-- Syntactic clause locus (`s₁` vs `s₂`) within the bounded max-2-clause document hierarchy. -/
inductive ClauseLocus where
  | clause1
  | clause2
  deriving DecidableEq, Repr

/-- Semantic/grammatical obligation sorts across frozen rules `G-01` ~ `G-16`. -/
inductive OblKind where
  | scopeAnchor           -- Cohort/scope anchoring at clause s₁ or s₂ (`F-R1.1-02`)
  | descIncidence         -- G-01 cumulative incidence count/window obligation
  | descDistribution      -- G-02 summary/dispersion obligation
  | assocMetricDir        -- G-03 / G-04 / G-14 association metric & direction obligation
  | temporalPrecedence    -- G-04 non-commutative temporal order obligation (t_a ≺ t_b)
  | absRiskDiff           -- G-05 RD comparative obligation
  | identAssumption       -- G-06a / G-06b explicit causal identification assumption H_id
  | intervDirectional     -- G-06a statistically supported directional estimation obligation
  | intervNeutral         -- G-06b null-crossing neutral causal estimation obligation
  | metaNotStatSig        -- G-07 non-significance status obligation
  | metaEquivMargins      -- G-08 prespecified TOST equivalence margin obligation
  | metaNonEstabNeg       -- G-09 unary non-establishment negation obligation
  | metaUnresolvedPolar   -- G-10 polar question non-resolution obligation
  | quantZeroNeg          -- G-11 universal zero-incidence negation obligation (`no ...`)
  | quantProperPart       -- G-12 non-empty proper subset obligation (`some, but not all`)
  | quantExistential      -- G-13 pure existential obligation (`at least one`)
  | covariateAdjustment   -- G-14 covariate adjustment set Z obligation
  | contrastiveBoundary   -- G-16 licensed contrastive discourse boundary obligation
  deriving DecidableEq, Repr

/--
  Structural locus-and-target specification of an obligation.
  Computed deterministically by each grammar rule from its syntactic `ClauseLocus` and verified slot payloads.
-/
structure ObligationSpec where
  locus  : ClauseLocus
  kind   : OblKind
  target : String
  deriving DecidableEq, Repr

/--
  Numbered linear obligation token in `Δ_in`.
  Combines a unique `oblId : Nat` with its required `spec : ObligationSpec`.
-/
structure ObligationToken where
  oblId : Nat
  spec  : ObligationSpec
  deriving DecidableEq, Repr

/-! ### Free Commutative Monoid `(ℕ^(𝒪), +, 0)` Multiset Accounting -/

/-- Exact occurrence count of element `a` in list `xs` (free commutative monoid multiplicity). -/
def countOcc {α : Type} [DecidableEq α] (a : α) : List α → Nat
  | [] => 0
  | x :: xs => (if x = a then 1 else 0) + countOcc a xs

@[simp]
theorem countOcc_nil {α : Type} [DecidableEq α] (a : α) :
    countOcc a ([] : List α) = 0 := rfl

@[simp]
theorem countOcc_cons {α : Type} [DecidableEq α] (a x : α) (xs : List α) :
    countOcc a (x :: xs) = (if x = a then 1 else 0) + countOcc a xs := rfl

theorem countOcc_append {α : Type} [DecidableEq α] (a : α) (xs ys : List α) :
    countOcc a (xs ++ ys) = countOcc a xs + countOcc a ys := by
  induction xs with
  | nil => simp
  | cons x rest ih =>
    simp [ih, Nat.add_assoc]

theorem countOcc_eq_zero_of_not_mem {α : Type} [DecidableEq α] {a : α} {xs : List α}
    (hnot : a ∉ xs) : countOcc a xs = 0 := by
  induction xs with
  | nil => rfl
  | cons x rest ih =>
    have hx : x ≠ a := fun heq => hnot (heq ▸ List.Mem.head rest)
    have hrest : a ∉ rest := fun hm => hnot (List.Mem.tail x hm)
    simp [hx, ih hrest]

theorem mem_of_countOcc_pos {α : Type} [DecidableEq α] {a : α} {xs : List α}
    (hpos : 0 < countOcc a xs) : a ∈ xs := by
  induction xs with
  | nil => simp at hpos
  | cons x rest ih =>
    simp at hpos
    by_cases hx : x = a
    · subst hx; exact List.Mem.head rest
    · simp [hx] at hpos
      exact List.Mem.tail x (ih hpos)

/--
  Exact Multiset Equality in the Free Commutative Monoid `(ℕ^(α), +, 0)`:
  Every element `a : α` has the exact same multiplicity in `xs` and `ys`.
-/
def MultisetEq {α : Type} [DecidableEq α] (xs ys : List α) : Prop :=
  ∀ a : α, countOcc a xs = countOcc a ys

theorem multisetEq_refl {α : Type} [DecidableEq α] (xs : List α) : MultisetEq xs xs :=
  fun _ => rfl

theorem multisetEq_symm {α : Type} [DecidableEq α] {xs ys : List α} (h : MultisetEq xs ys) :
    MultisetEq ys xs :=
  fun a => (h a).symm

theorem multisetEq_trans {α : Type} [DecidableEq α] {xs ys zs : List α}
    (h₁ : MultisetEq xs ys) (h₂ : MultisetEq ys zs) : MultisetEq xs zs :=
  fun a => (h₁ a).trans (h₂ a)

/-- Computable boolean check for `MultisetEq` by testing all elements in `xs ++ ys`. -/
def checkMultisetEqBool {α : Type} [DecidableEq α] (xs ys : List α) : Bool :=
  (xs ++ ys).all (fun a => decide (countOcc a xs = countOcc a ys))

theorem list_all_iff {α : Type} (p : α → Bool) (l : List α) :
    l.all p = true ↔ ∀ x ∈ l, p x = true := by
  induction l with
  | nil => simp
  | cons hd tl ih =>
    simp [List.all, Bool.and_eq_true, ih]

theorem checkMultisetEqBool_iff {α : Type} [DecidableEq α] (xs ys : List α) :
    checkMultisetEqBool xs ys = true ↔ MultisetEq xs ys := by
  unfold checkMultisetEqBool MultisetEq
  rw [list_all_iff]
  constructor
  · intro hall a
    by_cases hmem : a ∈ xs ++ ys
    · exact of_decide_eq_true (hall a hmem)
    · have hx : a ∉ xs := fun hx => hmem (List.mem_append_left ys hx)
      have hy : a ∉ ys := fun hy => hmem (List.mem_append_right xs hy)
      rw [countOcc_eq_zero_of_not_mem hx, countOcc_eq_zero_of_not_mem hy]
  · intro h a _
    exact decide_eq_true (h a)

instance {α : Type} [DecidableEq α] (xs ys : List α) : Decidable (MultisetEq xs ys) :=
  if h : checkMultisetEqBool xs ys = true then
    isTrue ((checkMultisetEqBool_iff xs ys).mp h)
  else
    isFalse (fun hm => h ((checkMultisetEqBool_iff xs ys).mpr hm))

/-- Duplicate-freeness on obligation IDs (`oblId` appears at most once). -/
def NoDupOblIds (obls : List ObligationToken) : Prop :=
  ∀ id : Nat, countOcc id (obls.map (·.oblId)) ≤ 1

def checkNoDupOblIdsBool (obls : List ObligationToken) : Bool :=
  let ids := obls.map (·.oblId)
  ids.all (fun id => decide (countOcc id ids ≤ 1))

theorem checkNoDupOblIdsBool_iff (obls : List ObligationToken) :
    checkNoDupOblIdsBool obls = true ↔ NoDupOblIds obls := by
  unfold checkNoDupOblIdsBool NoDupOblIds
  dsimp
  rw [list_all_iff]
  constructor
  · intro hall id
    by_cases hm : id ∈ obls.map (·.oblId)
    · exact of_decide_eq_true (hall id hm)
    · rw [countOcc_eq_zero_of_not_mem hm]
      omega
  · intro h id _
    exact decide_eq_true (h id)

instance (obls : List ObligationToken) : Decidable (NoDupOblIds obls) :=
  if h : checkNoDupOblIdsBool obls = true then
    isTrue ((checkNoDupOblIdsBool_iff obls).mp h)
  else
    isFalse (fun hn => h ((checkNoDupOblIdsBool_iff obls).mpr hn))

end BrocaOmega.P2
