/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2ProofObligations/PO_C1_02_ReplaySoundness.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `sorry`, zero custom `axiom`)

  Canonical Proof Obligation Export Ledger for `AUTH-C1-P2`:
  - `PO_C1_02_GrammarAcyclicRank`
  - `PO_C1_02_DerivationReplaySoundness`
  - `PO_C1_02_DerivationReplayCompleteness`
  - `PO_C1_02_CounterexampleSuiteVerified`
  - Explicit authorization & HELD locks preserving upstream/downstream isolation.
-/
import P2FormalSpec
import P2DetachedChecker
import P2Counterexamples

namespace BrocaOmega.P2.ProofObligations

/--
  **PO-C1-02a (`GrammarAcyclicRank`)**:
  Every child nonterminal referenced by any rule in frozen `G-01` ~ `G-16` has strictly
  smaller stratification rank than the rule's LHS category (`0 ≤ rank ≤ 4`), proving DAG acyclicity.
-/
theorem PO_C1_02_GrammarAcyclicRank
    (r : FrozenGenRule) (cat : NontermCat) (locOpt : Option ClauseLocus)
    (hmem : RuleSegment.child cat locOpt ∈ (ruleSignature r).segments) :
    cat.rank < (ruleSignature r).lhsCat.rank :=
  child_rank_lt_lhs_rank r cat locOpt hmem

/--
  **PO-C1-02 (`DerivationReplaySoundness`) — Master Theorem of `AUTH-C1-P2`**:
  $$
  \operatorname{replayDerivation}(\Gamma_{\mathrm{env}}, Y, \Delta_{\mathrm{in}}, \pi) = \operatorname{accepted}(w)
  \implies
  w.\pi = \pi \land
  \operatorname{ValidGrammarDerivation}(\Gamma_{\mathrm{env}}, Y, \pi) \land
  \operatorname{reconstructYield}(\pi) = Y \land
  \operatorname{ObligationsConserved}(\pi, \Delta_{\mathrm{in}}) \land
  \operatorname{LocusTargetBound}(\pi)
  $$
-/
theorem PO_C1_02_DerivationReplaySoundness
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert) (w : CertifiedDerivation env Y deltaIn)
    (hAcc : replayDerivation env Y deltaIn cert = .accepted w) :
    w.cert = cert ∧
    ValidGrammarDerivation env Y cert ∧
    reconstructYield cert = Y ∧
    ObligationsConserved cert deltaIn ∧
    LocusTargetBound cert :=
  replayDerivation_sound env Y deltaIn cert w hAcc

/--
  **PO-C1-02b (`DerivationReplayCompleteness`) — Non-Vacuity / Relative Completeness**:
  Every derivation tree satisfying `ValidGrammarDerivation` and `ObligationsConserved`
  is accepted by `replayDerivation` with witness bound to the exact input certificate.
-/
theorem PO_C1_02_DerivationReplayCompleteness
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert)
    (hValid : ValidGrammarDerivation env Y cert)
    (hObl : ObligationsConserved cert deltaIn) :
    ∃ w : CertifiedDerivation env Y deltaIn,
      replayDerivation env Y deltaIn cert = .accepted w ∧ w.cert = cert :=
  replayDerivation_complete env Y deltaIn cert hValid hObl

/--
  **PO-C1-02c (`CounterexampleSuiteVerified`)**:
  All 24 symmetric `(PC, CE)` test cases (`12` positive controls + `12` adversarial mutations)
  evaluate to `true` under Lean's kernel reduction (`decide`, zero `native_decide`).
-/
theorem PO_C1_02_CounterexampleSuiteVerified :
    Counterexamples.allP2Cases.all Counterexamples.P2TestCase.runCheck = true :=
  Counterexamples.allP2Cases_verified

/-! ### Explicit Scope & Authorization Locks (`Gate C1-P2` Isolation Boundaries) -/

inductive TrackGateStatus where
  | scopedSourceVerifiedLocal
  | heldExternalKernelReplay
  | notAuthorized
  deriving DecidableEq, Repr

def status_P1_PO_C1_04a_ExternalAdmission : TrackGateStatus := .heldExternalKernelReplay
def status_P1_C_Int128FastPath            : TrackGateStatus := .notAuthorized
def status_P2_PO_C1_02_DerivationReplay   : TrackGateStatus := .scopedSourceVerifiedLocal
def status_P3_SurfaceCanonicalizerParser  : TrackGateStatus := .notAuthorized
def status_P4_ClinicalEvidenceCalculus    : TrackGateStatus := .notAuthorized
def status_P5_SnapshotHashAdmission       : TrackGateStatus := .notAuthorized
def status_Pneuma_S3_S4_Integration       : TrackGateStatus := .notAuthorized

end BrocaOmega.P2.ProofObligations
