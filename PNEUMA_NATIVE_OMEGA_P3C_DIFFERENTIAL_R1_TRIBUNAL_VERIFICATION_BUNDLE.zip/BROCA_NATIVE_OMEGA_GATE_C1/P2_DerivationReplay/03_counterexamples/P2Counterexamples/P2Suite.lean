/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2Counterexamples/P2Suite.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies, zero `native_decide`)

  12 Symmetric `(PC, CE)` Contract Pairs (24 executable & kernel-proved test vectors)
  exercising every soundness invariant of `replayDerivation`:
    01. Forged / Trap Rule ID (`T2 = 902`) vs valid `G-03`
    02. Fixed structural terminal polarity tampering vs valid `G-09`
    03. 1-char surface string `Y` mutation (`"128.4"` -> `"128.5"`) vs valid `G-02a`
    04. Span contiguity gap/overlap shift vs valid `G-01`
    05. Duplicate obligation ID contraction (`oblId` discharged twice) vs valid `G-04`
    06. Unconsumed mandatory negation obligation (weakening) vs valid `G-11`
    07. Unlicensed extra obligation injected at node vs valid `G-12`
    08. Clause-Locus Swap (`clause1` <-> `clause2`, multiset preserved!) vs valid `G-15` (`sentenceAtomic`)
    09. Target-Payload Swap (locus & multiset preserved, metric forged!) vs valid `G-14`
    10. Illegal nested recursion (`G-15` inside `G-15`) vs valid flat `G-15` (`discourseBound`)
    11. Cross-clause exposure/outcome mismatch in contrastive `G-16` vs valid `G-16`
    12. Reserved syncategorematic keyword (`"did not"`) smuggled in slot vs valid `G-06a`
-/
import P2DetachedChecker

namespace BrocaOmega.P2.Counterexamples

/-! ### Test-Fixture Helpers (Untrusted Certificate Assembly for Test Vectors Only) -/

/- Raw unspanned tree used ONLY inside `P2Counterexamples` to compute canonical test fixtures. -/
instance : Inhabited ObligationToken where
  default := { oblId := 0, spec := { locus := .clause1, kind := .scopeAnchor, target := "" } }

mutual
  inductive RawTestArg where
    | lit (txt : String)
    | slot (sort : SlotSort) (role : SlotRole) (entityId : String) (lex : String)
    | child (node : RawTestNode)

  inductive RawTestNode where
    | mk (nodeId : Nat) (rawCode : Nat) (claimed : List ObligationToken) (args : List RawTestArg)
end

mutual
  def buildSpannedArgs (cursor : Nat) : List RawTestArg → Nat × List UntrustedSegArg
    | [] => (cursor, [])
    | .lit txt :: rest =>
      let next := cursor + txt.toList.length
      let (endPos, tailArgs) := buildSpannedArgs next rest
      (endPos, .litSpan txt ⟨cursor, next⟩ :: tailArgs)
    | .slot srt rl eid lex :: rest =>
      let next := cursor + lex.toList.length
      let (endPos, tailArgs) := buildSpannedArgs next rest
      (endPos, .slotLeaf ⟨srt, rl, eid, lex, ⟨cursor, next⟩⟩ :: tailArgs)
    | .child sub :: rest =>
      let (subEnd, subCert) := buildSpannedNode cursor sub
      let (endPos, tailArgs) := buildSpannedArgs subEnd rest
      (endPos, .childNode subCert :: tailArgs)

  def buildSpannedNode (cursor : Nat) : RawTestNode → Nat × UntrustedDerivCert
    | .mk nid rc claimed args =>
      let (endPos, spArgs) := buildSpannedArgs cursor args
      (endPos, .mkNode nid rc ⟨cursor, endPos⟩ claimed spArgs)
end

def mkFixture (raw : RawTestNode) : String × UntrustedDerivCert :=
  let (_, cert) := buildSpannedNode 0 raw
  (reconstructYield cert, cert)

/-- Standard environments for `sentenceAtomic` and `discourseBound` contracts. -/
def envAtomic : ScopeEnv :=
  { cohortId := "cohort_primary"
    expectedDesignHead := "design_rct"
    quoteIsolation := .sentenceAtomic }

def envDiscourse : ScopeEnv :=
  { cohortId := "cohort_primary"
    expectedDesignHead := "design_rct"
    quoteIsolation := .discourseBound }

def envObsDiscourse : ScopeEnv :=
  { cohortId := "cohort_primary"
    expectedDesignHead := "design_obs"
    quoteIsolation := .discourseBound }

/-- Descriptor for unified table execution & differential oracle export. -/
structure P2TestCase where
  caseId       : String
  pairGroup    : String
  isPositive   : Bool
  env          : ScopeEnv
  surfaceText  : String
  deltaIn      : List ObligationToken
  cert         : UntrustedDerivCert
  expectedPass : Bool
  expectedDiag : Option CEGESReplayDiag

def P2TestCase.runCheck (tc : P2TestCase) : Bool :=
  let out := replayDerivation tc.env tc.surfaceText tc.deltaIn tc.cert
  match tc.expectedPass, tc.expectedDiag with
  | true, none      => out.isAccepted
  | false, some exp => decide (out.diag? = some exp)
  | _, _            => false

/-! ### Pair 01: Forged / Trap Rule ID (`T2 = 902`) vs Valid `G-03` -/

def obls01 : List ObligationToken :=
  [ { oblId := 1, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 2, spec := { locus := .clause1, kind := .assocMetricDir,
                            target := "hr:inversely:exp_intensive:exp_std:out_mi" } } ]

def rawG03Node (ruleCode : Nat) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls01[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 210 []
            [ .child (.mk 4 ruleCode [obls01[1]!]
                [ .lit "comparing ",
                  .slot .expLevel .activeExp "exp_intensive" "intensive therapy",
                  .lit " versus ",
                  .slot .expLevel .refExp "exp_std" "standard care",
                  .lit " was ",
                  .slot .assocDir .direction "inversely" "inversely",
                  .lit " associated with ",
                  .slot .outTerm .outcome "out_mi" "myocardial infarction",
                  .lit " (",
                  .slot .ratioMetric .metric1 "hr" "hazard ratio",
                  .lit " = ",
                  .slot .numericLit .numEst "0.78" "0.78",
                  .lit ", ",
                  .slot .numericLit .numCILevel "95" "95",
                  .lit "% CI ",
                  .slot .numericLit .numCILow "0.65" "0.65",
                  .lit " to ",
                  .slot .numericLit .numCIHigh "0.94" "0.94",
                  .lit ")" ]) ]) ]),
      .lit "." ]

def pc01 : P2TestCase :=
  let (y, c) := mkFixture (rawG03Node 30)
  { caseId := "PC-P2-01", pairGroup := "PAIR-01-RULE-ID", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls01, cert := c,
    expectedPass := true, expectedDiag := none }

def ce01 : P2TestCase :=
  let (y, _) := mkFixture (rawG03Node 30)
  let (_, cTrap) := mkFixture (rawG03Node 902) -- Trap Rule T2 = 902
  { caseId := "CE-P2-01", pairGroup := "PAIR-01-RULE-ID", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls01, cert := cTrap,
    expectedPass := false, expectedDiag := some (.forgedOrTrapRuleId 4 902) }

/-! ### Pair 02: Fixed Structural Terminal Tampering vs Valid `G-09` -/

def obls02 : List ObligationToken :=
  [ { oblId := 10, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 11, spec := { locus := .clause1, kind := .metaNonEstabNeg,
                             target := "src_trialA:exp_intensive:reduces:out_stroke" } } ]

def rawG09Node (bridgeLit : String) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls02[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 211 []
            [ .child (.mk 4 90 [obls02[1]!]
                [ .lit "the analysis of ",
                  .slot .sourceId .source "src_trialA" "Trial-A",
                  .lit bridgeLit,
                  .child (.mk 5 301 []
                    [ .slot .expLevel .activeExp "exp_intensive" "intensive therapy",
                      .lit " ",
                      .slot .intervVerbPres .verb "reduces" "reduces",
                      .lit " ",
                      .slot .outTerm .outcome "out_stroke" "stroke" ]) ]) ]) ]),
      .lit "." ]

def pc02 : P2TestCase :=
  let (y, c) := mkFixture (rawG09Node " did not establish that ")
  { caseId := "PC-P2-02", pairGroup := "PAIR-02-FIXED-TERMINAL", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls02, cert := c,
    expectedPass := true, expectedDiag := none }

def ce02 : P2TestCase :=
  let (yTampered, cTampered) := mkFixture (rawG09Node " established that ")
  { caseId := "CE-P2-02", pairGroup := "PAIR-02-FIXED-TERMINAL", isPositive := false,
    env := envAtomic, surfaceText := yTampered, deltaIn := obls02, cert := cTampered,
    expectedPass := false,
    expectedDiag := some (.fixedTerminalMismatch 4 " did not establish that " " established that ") }

/-! ### Pair 03: 1-Character Surface `Y` Mutation (`"128.4"` -> `"128.5"`) vs Valid `G-02a` -/

def obls03 : List ObligationToken :=
  [ { oblId := 20, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 21, spec := { locus := .clause1, kind := .descDistribution,
                             target := "mean_sd:meas_sbp:128.4:14.2" } } ]

def rawG02aNode : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls03[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 20 [obls03[1]!]
            [ .lit "the mean ",
              .slot .measureTerm .measure "meas_sbp" "systolic blood pressure",
              .lit " was ",
              .slot .numericLit .numEst "128.4" "128.4",
              .lit " (SD ",
              .slot .numericLit .numDisp1 "14.2" "14.2",
              .lit ")" ]) ]),
      .lit "." ]

def pc03 : P2TestCase :=
  let (y, c) := mkFixture rawG02aNode
  { caseId := "PC-P2-03", pairGroup := "PAIR-03-YIELD-1CHAR", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls03, cert := c,
    expectedPass := true, expectedDiag := none }

def ce03 : P2TestCase :=
  let (_, c) := mkFixture rawG02aNode
  -- Exact same length `Y`, mutating `"128.4"` to `"128.5"` at codepoint span `[60, 65)`!
  let yMutated := "In the primary cohort, the mean systolic blood pressure was 128.5 (SD 14.2)."
  { caseId := "CE-P2-03", pairGroup := "PAIR-03-YIELD-1CHAR", isPositive := false,
    env := envAtomic, surfaceText := yMutated, deltaIn := obls03, cert := c,
    expectedPass := false, expectedDiag := some (.spanSliceMismatch 3 ⟨60, 65⟩) }

/-! ### Pair 04: Span Contiguity Gap/Overlap Attack vs Valid `G-01` -/

def obls04 : List ObligationToken :=
  [ { oblId := 30, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 31, spec := { locus := .clause1, kind := .descIncidence,
                             target := "win_24m:evt_hf:18/200=9.0" } } ]

def rawG01Node : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls04[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 10 [obls04[1]!]
            [ .lit "over ",
              .slot .followUpWindow .window "win_24m" "24 months",
              .lit ", the cumulative incidence of ",
              .slot .eventTerm .eventA "evt_hf" "heart failure",
              .lit " was ",
              .slot .numericLit .numK "18" "18",
              .lit " of ",
              .slot .numericLit .numN "200" "200",
              .lit " patients (",
              .slot .numericLit .numPct "9.0" "9.0",
              .lit "%)" ]) ]),
      .lit "." ]

def pc04 : P2TestCase :=
  let (y, c) := mkFixture rawG01Node
  { caseId := "PC-P2-04", pairGroup := "PAIR-04-SPAN-GAP", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls04, cert := c,
    expectedPass := true, expectedDiag := none }

/-- Mutates the final `.lit "."` at root node `1` to start 1 codepoint late (gap at end of sentence). -/
def introduceRootDotGap : UntrustedDerivCert → UntrustedDerivCert
  | .mkNode nid rc sp cl [sub, .litSpan "." ⟨s, e⟩] =>
    .mkNode nid rc sp cl [sub, .litSpan "." ⟨s + 1, e⟩]
  | c => c

def ce04 : P2TestCase :=
  let (y, c) := mkFixture rawG01Node
  let len := y.toList.length
  { caseId := "CE-P2-04", pairGroup := "PAIR-04-SPAN-GAP", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls04, cert := introduceRootDotGap c,
    expectedPass := false, expectedDiag := some (.spanStartDiscontinuity 1 (len - 1) len) }

/-! ### Pair 05: Duplicate Obligation ID Contraction Attack vs Valid `G-04` -/

def obls05 : List ObligationToken :=
  [ { oblId := 40, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 41, spec := { locus := .clause1, kind := .temporalPrecedence, target := "evt_aki<evt_ckd" } },
    { oblId := 42, spec := { locus := .clause1, kind := .assocMetricDir,
                             target := "rr:positively:exp_aki:exp_noaki:out_ckd" } } ]

def rawG04Node (scopeOblId : Nat) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [{ oblId := scopeOblId, spec := obls05[0]!.spec }]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 210 []
            [ .child (.mk 4 40 [obls05[1]!, obls05[2]!]
                [ .slot .eventTerm .eventA "evt_aki" "acute kidney injury",
                  .lit " preceded ",
                  .slot .eventTerm .eventB "evt_ckd" "chronic kidney disease",
                  .lit ", and comparing ",
                  .slot .expLevel .activeExp "exp_aki" "prior AKI",
                  .lit " versus ",
                  .slot .expLevel .refExp "exp_noaki" "no prior AKI",
                  .lit " was ",
                  .slot .assocDir .direction "positively" "positively",
                  .lit " associated with ",
                  .slot .outTerm .outcome "out_ckd" "renal progression",
                  .lit " (",
                  .slot .ratioMetric .metric1 "rr" "risk ratio",
                  .lit " = ",
                  .slot .numericLit .numEst "2.10" "2.10",
                  .lit ", ",
                  .slot .numericLit .numCILevel "95" "95",
                  .lit "% CI ",
                  .slot .numericLit .numCILow "1.50" "1.50",
                  .lit " to ",
                  .slot .numericLit .numCIHigh "2.94" "2.94",
                  .lit ")" ]) ]) ]),
      .lit "." ]

def pc05 : P2TestCase :=
  let (y, c) := mkFixture (rawG04Node 40)
  { caseId := "PC-P2-05", pairGroup := "PAIR-05-DUP-OBL-ID", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls05, cert := c,
    expectedPass := true, expectedDiag := none }

def ce05 : P2TestCase :=
  -- Reuses `oblId := 41` on `ScopedInitial` so `oblId = 41` is discharged TWICE in `collectClaimedObls`!
  let (y, cDup) := mkFixture (rawG04Node 41)
  { caseId := "CE-P2-05", pairGroup := "PAIR-05-DUP-OBL-ID", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls05, cert := cDup,
    expectedPass := false, expectedDiag := some .duplicateOblIdDischarged }

/-! ### Pair 06: Unconsumed Mandatory Negation Obligation (Weakening) vs Valid `G-11` -/

def obls06 : List ObligationToken :=
  [ { oblId := 50, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 51, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_lowrisk:evt_dka" } } ]

def rawG11Node : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls06[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 110 [obls06[1]!]
            [ .lit "no ",
              .slot .subgroupPlural .subgroup "sub_lowrisk" "low-risk",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_dka" "diabetic ketoacidosis" ]) ]),
      .lit "." ]

def pc06 : P2TestCase :=
  let (y, c) := mkFixture rawG11Node
  { caseId := "PC-P2-06", pairGroup := "PAIR-06-UNCONSUMED-OBL", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls06, cert := c,
    expectedPass := true, expectedDiag := none }

def ce06 : P2TestCase :=
  let (y, c) := mkFixture rawG11Node
  let extraNeg : ObligationToken :=
    { oblId := 52, spec := { locus := .clause1, kind := .metaNonEstabNeg, target := "src_A:x:causes:y" } }
  { caseId := "CE-P2-06", pairGroup := "PAIR-06-UNCONSUMED-OBL", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls06 ++ [extraNeg], cert := c,
    expectedPass := false, expectedDiag := some .obligationMultisetMismatch }

/-! ### Pair 07: Unlicensed Extra Obligation Injected at Node vs Valid `G-12` -/

def obls07 : List ObligationToken :=
  [ { oblId := 60, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 61, spec := { locus := .clause1, kind := .quantProperPart, target := "sub_elderly:evt_ edema" } } ]

-- Clean ASCII entityId `"evt_edema"`:
def obls07Clean : List ObligationToken :=
  [ { oblId := 60, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 61, spec := { locus := .clause1, kind := .quantProperPart, target := "sub_elderly:evt_edema" } } ]

def extraRogueObl07 : ObligationToken :=
  { oblId := 62, spec := { locus := .clause1, kind := .quantExistential, target := "sub_elderly:evt_edema" } }

def rawG12Node (claimedAtG12 : List ObligationToken) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls07Clean[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 120 claimedAtG12
            [ .lit "some, but not all, ",
              .slot .subgroupPlural .subgroup "sub_elderly" "elderly",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_edema" "peripheral edema" ]) ]),
      .lit "." ]

def pc07 : P2TestCase :=
  let (y, c) := mkFixture (rawG12Node [obls07Clean[1]!])
  { caseId := "PC-P2-07", pairGroup := "PAIR-07-UNLICENSED-OBL", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls07Clean, cert := c,
    expectedPass := true, expectedDiag := none }

def ce07 : P2TestCase :=
  let (y, cRogue) := mkFixture (rawG12Node [obls07Clean[1]!, extraRogueObl07])
  { caseId := "CE-P2-07", pairGroup := "PAIR-07-UNLICENSED-OBL", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls07Clean ++ [extraRogueObl07], cert := cRogue,
    expectedPass := false,
    expectedDiag := some (.locusOrTargetOblMismatch 3
      [obls07Clean[1]!.spec] [obls07Clean[1]!.spec, extraRogueObl07.spec]) }

/-! ### Pair 08: Clause-Locus Swap Attack (`clause1` <-> `clause2`, Multiset Preserved!) vs Valid `G-15` -/

def obls08Valid : List ObligationToken :=
  [ { oblId := 70, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 71, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_lowrisk:evt_hypo" } },
    { oblId := 72, spec := { locus := .clause2, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 73, spec := { locus := .clause2, kind := .quantExistential, target := "sub_frail:evt_syncope" } } ]

-- Swapped obligations: `quantZeroNeg` placed at `clause2` and `quantExistential` placed at `clause1`!
def obls08Swapped : List ObligationToken :=
  [ { oblId := 70, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 71, spec := { locus := .clause2, kind := .quantZeroNeg, target := "sub_lowrisk:evt_hypo" } },
    { oblId := 72, spec := { locus := .clause2, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 73, spec := { locus := .clause1, kind := .quantExistential, target := "sub_frail:evt_syncope" } } ]

def rawG15LocusNode (s1Obl s2Obl : ObligationToken) : RawTestNode :=
  .mk 1 150 []
    [ .child (.mk 2 201 [obls08Valid[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 110 [s1Obl]
            [ .lit "no ",
              .slot .subgroupPlural .subgroup "sub_lowrisk" "low-risk",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_hypo" "severe hypoglycemia" ]) ]),
      .lit ". ",
      .child (.mk 4 201 [obls08Valid[2]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 5 130 [s2Obl]
            [ .lit "at least one ",
              .slot .subgroupSingular .subgroup "sub_frail" "frail",
              .lit " patient developed ",
              .slot .eventTerm .eventA "evt_syncope" "syncope" ]) ]),
      .lit "." ]

def pc08 : P2TestCase :=
  let (y, c) := mkFixture (rawG15LocusNode obls08Valid[1]! obls08Valid[3]!)
  { caseId := "PC-P2-08", pairGroup := "PAIR-08-CLAUSE-LOCUS-SWAP", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls08Valid, cert := c,
    expectedPass := true, expectedDiag := none }

def ce08 : P2TestCase :=
  -- Global multiset of `cSwap` equals `obls08Swapped`! Only `LocusTargetBound` catches the locus swap at node 3!
  let (y, cSwap) := mkFixture (rawG15LocusNode obls08Swapped[1]! obls08Swapped[3]!)
  { caseId := "CE-P2-08", pairGroup := "PAIR-08-CLAUSE-LOCUS-SWAP", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := obls08Swapped, cert := cSwap,
    expectedPass := false,
    expectedDiag := some (.locusOrTargetOblMismatch 3 [obls08Valid[1]!.spec] [obls08Swapped[1]!.spec]) }

/-! ### Pair 09: Target-Payload Swap Attack (Locus & Multiset Preserved!) vs Valid `G-14` -/

def obls09Valid : List ObligationToken :=
  [ { oblId := 80, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 81, spec := { locus := .clause1, kind := .covariateAdjustment, target := "cov_age_hba1c" } },
    { oblId := 82, spec := { locus := .clause1, kind := .assocMetricDir,
                             target := "hr:inversely:exp_glp1:exp_dpp4:out_mace" } } ]

def forgedAssocObl09 : ObligationToken :=
  { oblId := 82, spec := { locus := .clause1, kind := .assocMetricDir,
                           target := "or:inversely:exp_glp1:exp_dpp4:out_mace" } } -- `"or"` instead of `"hr"`!

def rawG14Node (assocObl : ObligationToken) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls09Valid[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 210 []
            [ .child (.mk 4 140 [obls09Valid[1]!, assocObl]
                [ .lit "after adjustment for ",
                  .slot .covariateList .covariates "cov_age_hba1c" "age and baseline HbA1c",
                  .lit ", comparing ",
                  .slot .expLevel .activeExp "exp_glp1" "GLP-1 therapy",
                  .lit " versus ",
                  .slot .expLevel .refExp "exp_dpp4" "DPP-4 therapy",
                  .lit " was ",
                  .slot .assocDir .direction "inversely" "inversely",
                  .lit " associated with ",
                  .slot .outTerm .outcome "out_mace" "major cardiovascular events",
                  .lit " (",
                  .slot .ratioMetric .metric1 "hr" "hazard ratio",
                  .lit " = ",
                  .slot .numericLit .numEst "0.82" "0.82",
                  .lit ", ",
                  .slot .numericLit .numCILevel "95" "95",
                  .lit "% CI ",
                  .slot .numericLit .numCILow "0.70" "0.70",
                  .lit " to ",
                  .slot .numericLit .numCIHigh "0.96" "0.96",
                  .lit ")" ]) ]) ]),
      .lit "." ]

def pc09 : P2TestCase :=
  let (y, c) := mkFixture (rawG14Node obls09Valid[2]!)
  { caseId := "PC-P2-09", pairGroup := "PAIR-09-TARGET-SWAP", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls09Valid, cert := c,
    expectedPass := true, expectedDiag := none }

def ce09 : P2TestCase :=
  let (y, cTargetSwap) := mkFixture (rawG14Node forgedAssocObl09)
  let deltaForged := [obls09Valid[0]!, obls09Valid[1]!, forgedAssocObl09]
  { caseId := "CE-P2-09", pairGroup := "PAIR-09-TARGET-SWAP", isPositive := false,
    env := envAtomic, surfaceText := y, deltaIn := deltaForged, cert := cTargetSwap,
    expectedPass := false,
    expectedDiag := some (.locusOrTargetOblMismatch 4
      [obls09Valid[1]!.spec, obls09Valid[2]!.spec]
      [obls09Valid[1]!.spec, forgedAssocObl09.spec]) }

/-! ### Pair 10: Illegal Recursive `G-15` Nesting (`documentRoot` Inside `G-15`) vs Flat `G-15` -/

def obls10 : List ObligationToken :=
  [ { oblId := 90, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 91, spec := { locus := .clause1, kind := .quantZeroNeg, target := "sub_armA:evt_sepsis" } },
    { oblId := 92, spec := { locus := .clause2, kind := .scopeAnchor, target := "resolve:design_rct" } },
    { oblId := 93, spec := { locus := .clause2, kind := .quantExistential, target := "sub_armB:evt_rash" } } ]

def rawG15DiscourseValid : RawTestNode :=
  .mk 1 151 []
    [ .child (.mk 2 201 [obls10[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 110 [obls10[1]!]
            [ .lit "no ",
              .slot .subgroupPlural .subgroup "sub_armA" "intervention-arm",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_sepsis" "sepsis" ]) ]),
      .lit ". ",
      .child (.mk 4 202 [obls10[2]!]
        [ .lit "Within this same ",
          .slot .designNoun .design "design_rct" "randomized trial",
          .lit ", ",
          .child (.mk 5 130 [obls10[3]!]
            [ .lit "at least one ",
              .slot .subgroupSingular .subgroup "sub_armB" "control-arm",
              .lit " patient developed ",
              .slot .eventTerm .eventA "evt_rash" "injection-site rash" ]) ]),
      .lit "." ]

def rawG15NestedIllegal : RawTestNode :=
  .mk 1 151 []
    [ .child (.mk 2 201 [obls10[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 110 [obls10[1]!]
            [ .lit "no ",
              .slot .subgroupPlural .subgroup "sub_armA" "intervention-arm",
              .lit " patients developed ",
              .slot .eventTerm .eventA "evt_sepsis" "sepsis" ]) ]),
      .lit ". ",
      -- Illegal recursive `G15_DocConjDiscourse` (code 151, `documentRoot`) placed where `scopedRepeat` is required!
      .child rawG15DiscourseValid,
      .lit "." ]

def pc10 : P2TestCase :=
  let (y, c) := mkFixture rawG15DiscourseValid
  { caseId := "PC-P2-10", pairGroup := "PAIR-10-ACYCLIC-G15", isPositive := true,
    env := envDiscourse, surfaceText := y, deltaIn := obls10, cert := c,
    expectedPass := true, expectedDiag := none }

def ce10 : P2TestCase :=
  let (yNested, cNested) := mkFixture rawG15NestedIllegal
  { caseId := "CE-P2-10", pairGroup := "PAIR-10-ACYCLIC-G15", isPositive := false,
    env := envDiscourse, surfaceText := yNested, deltaIn := obls10, cert := cNested,
    expectedPass := false,
    expectedDiag := some (.nontermCatMismatch 1 .scopedRepeat .documentRoot) }

/-! ### Pair 11: Cross-Clause Exposure/Outcome Mismatch in `G-16` (`; however,`) vs Valid `G-16` -/

def obls11 (c2OutId : String) : List ObligationToken :=
  [ { oblId := 100, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 101, spec := { locus := .clause1, kind := .assocMetricDir,
                              target := "hr:inversely:exp_sglt2:exp_placebo:out_hosp" } },
    { oblId := 102, spec := { locus := .clause2, kind := .scopeAnchor, target := "resolve:design_obs" } },
    { oblId := 103, spec := { locus := .clause2, kind := .metaNonEstabNeg,
                              target := "src_regB:exp_sglt2:reduces:" ++ c2OutId } },
    { oblId := 104, spec := { locus := .clause2, kind := .contrastiveBoundary,
                              target := "exp_sglt2:out_hosp" } } ]

def rawG16Node (c2OutId c2OutLex : String) : RawTestNode :=
  let obls := obls11 c2OutId
  .mk 1 160 [obls[4]!]
    [ .child (.mk 2 203 [obls[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 30 [obls[1]!]
            [ .lit "comparing ",
              .slot .expLevel .activeExp "exp_sglt2" "SGLT2 inhibition",
              .lit " versus ",
              .slot .expLevel .refExp "exp_placebo" "placebo",
              .lit " was ",
              .slot .assocDir .direction "inversely" "inversely",
              .lit " associated with ",
              .slot .outTerm .outcome "out_hosp" "heart-failure hospitalization",
              .lit " (",
              .slot .ratioMetric .metric1 "hr" "hazard ratio",
              .lit " = ",
              .slot .numericLit .numEst "0.74" "0.74",
              .lit ", ",
              .slot .numericLit .numCILevel "95" "95",
              .lit "% CI ",
              .slot .numericLit .numCILow "0.61" "0.61",
              .lit " to ",
              .slot .numericLit .numCIHigh "0.89" "0.89",
              .lit ")" ]) ]),
      .lit "; however, ",
      .child (.mk 4 204 [obls[2]!]
        [ .lit "within this same ",
          .slot .designNoun .design "design_obs" "observational study",
          .lit ", ",
          .child (.mk 5 90 [obls[3]!]
            [ .lit "the analysis of ",
              .slot .sourceId .source "src_regB" "Registry-B",
              .lit " did not establish that ",
              .child (.mk 6 301 []
                [ .slot .expLevel .activeExp "exp_sglt2" "SGLT2 inhibition",
                  .lit " ",
                  .slot .intervVerbPres .verb "reduces" "reduces",
                  .lit " ",
                  .slot .outTerm .outcome c2OutId c2OutLex ]) ]) ]),
      .lit "." ]

def pc11 : P2TestCase :=
  let (y, c) := mkFixture (rawG16Node "out_hosp" "heart-failure hospitalization")
  { caseId := "PC-P2-11", pairGroup := "PAIR-11-G16-SIDE-COND", isPositive := true,
    env := envObsDiscourse, surfaceText := y, deltaIn := obls11 "out_hosp", cert := c,
    expectedPass := true, expectedDiag := none }

def ce11 : P2TestCase :=
  let (yMismatch, cMismatch) := mkFixture (rawG16Node "out_mortality" "all-cause mortality")
  { caseId := "CE-P2-11", pairGroup := "PAIR-11-G16-SIDE-COND", isPositive := false,
    env := envObsDiscourse, surfaceText := yMismatch, deltaIn := obls11 "out_mortality", cert := cMismatch,
    expectedPass := false, expectedDiag := some (.sideConditionFailed 1 .G16_DocContrastive) }

/-! ### Pair 12: Syncategorematic Reserved Keyword Smuggling (`"did not"`) vs Valid `G-06a` -/

def obls12 : List ObligationToken :=
  [ { oblId := 110, spec := { locus := .clause1, kind := .scopeAnchor, target := "cohort_primary" } },
    { oblId := 111, spec := { locus := .clause1, kind := .identAssumption, target := "assump_exch" } },
    { oblId := 112, spec := { locus := .clause1, kind := .intervDirectional,
                              target := "rr:reduce:exp_insulin:exp_oral:out_micro" } } ]

def rawG06aNode (activeLex : String) : RawTestNode :=
  .mk 1 1 []
    [ .child (.mk 2 201 [obls12[0]!]
        [ .lit "In ",
          .slot .cohortSpec .cohort "cohort_primary" "the primary cohort",
          .lit ", ",
          .child (.mk 3 60 [obls12[1]!, obls12[2]!]
            [ .lit "under ",
              .slot .identAssump .assumption "assump_exch" "conditional exchangeability",
              .lit ", comparing ",
              .slot .expLevel .activeExp "exp_insulin" activeLex,
              .lit " versus ",
              .slot .expLevel .refExp "exp_oral" "oral monotherapy",
              .lit " was estimated to ",
              .slot .intervDirVerb .verb "reduce" "reduce",
              .lit " ",
              .slot .outTerm .outcome "out_micro" "microvascular progression",
              .lit " (",
              .slot .ratioMetric .metric1 "rr" "risk ratio",
              .lit " = ",
              .slot .numericLit .numEst "0.72" "0.72",
              .lit ", ",
              .slot .numericLit .numCILevel "95" "95",
              .lit "% CI ",
              .slot .numericLit .numCILow "0.58" "0.58",
              .lit " to ",
              .slot .numericLit .numCIHigh "0.89" "0.89",
              .lit ", p = ",
              .slot .numericLit .numPVal "0.002" "0.002",
              .lit ")" ]) ]),
      .lit "." ]

def pc12 : P2TestCase :=
  let (y, c) := mkFixture (rawG06aNode "early insulin")
  { caseId := "PC-P2-12", pairGroup := "PAIR-12-KEYWORD-BARRIER", isPositive := true,
    env := envAtomic, surfaceText := y, deltaIn := obls12, cert := c,
    expectedPass := true, expectedDiag := none }

def ce12 : P2TestCase :=
  let (yLeak, cLeak) := mkFixture (rawG06aNode "early insulin did not")
  { caseId := "CE-P2-12", pairGroup := "PAIR-12-KEYWORD-BARRIER", isPositive := false,
    env := envAtomic, surfaceText := yLeak, deltaIn := obls12, cert := cLeak,
    expectedPass := false,
    expectedDiag := some (.invalidSlotLexemeOrKeywordLeak 3 .expLevel "early insulin did not") }

/-! ### Complete 24-Vector Suite & Kernel-Checked Compile-Time Proofs (Zero `native_decide`) -/

def allP2Cases : List P2TestCase :=
  [ pc01, ce01, pc02, ce02, pc03, ce03, pc04, ce04,
    pc05, ce05, pc06, ce06, pc07, ce07, pc08, ce08,
    pc09, ce09, pc10, ce10, pc11, ce11, pc12, ce12 ]

set_option maxRecDepth 16384 in
theorem pc01_verified : pc01.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce01_verified : ce01.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc02_verified : pc02.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce02_verified : ce02.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc03_verified : pc03.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce03_verified : ce03.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc04_verified : pc04.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce04_verified : ce04.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc05_verified : pc05.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce05_verified : ce05.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc06_verified : pc06.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce06_verified : ce06.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc07_verified : pc07.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce07_verified : ce07.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc08_verified : pc08.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce08_verified : ce08.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc09_verified : pc09.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce09_verified : ce09.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc10_verified : pc10.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce10_verified : ce10.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc11_verified : pc11.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce11_verified : ce11.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem pc12_verified : pc12.runCheck = true := by decide
set_option maxRecDepth 16384 in
theorem ce12_verified : ce12.runCheck = true := by decide

theorem allP2Cases_verified : allP2Cases.all P2TestCase.runCheck = true := by
  simp [allP2Cases, List.all,
        pc01_verified, ce01_verified, pc02_verified, ce02_verified,
        pc03_verified, ce03_verified, pc04_verified, ce04_verified,
        pc05_verified, ce05_verified, pc06_verified, ce06_verified,
        pc07_verified, ce07_verified, pc08_verified, ce08_verified,
        pc09_verified, ce09_verified, pc10_verified, ce10_verified,
        pc11_verified, ce11_verified, pc12_verified, ce12_verified]

end BrocaOmega.P2.Counterexamples
