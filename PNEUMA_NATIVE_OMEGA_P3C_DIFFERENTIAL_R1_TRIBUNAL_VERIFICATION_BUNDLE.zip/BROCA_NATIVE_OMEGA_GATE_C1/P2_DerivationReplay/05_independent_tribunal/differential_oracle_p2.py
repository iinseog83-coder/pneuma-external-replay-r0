#!/usr/bin/env python3
"""
BROCA-NATIVE OMEGA — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
05_independent_tribunal/differential_oracle_p2.py

Clean-room Python 3.11 differential oracle for `AUTH-C1-P2`:
1. Independently implements `G-01` ~ `G-16` frozen rule table, rank acyclicity,
   contiguous codepoint span verification, syncategorematic keyword barrier,
   `LocusTargetBound` node-local obligation checking, and `collections.Counter`
   free-commutative-monoid multiset conservation.
2. Executes `p2_tribunal_runner.exe --json` and checks 100% exact decision AND
   diagnostic-tag parity on all 24 `(PC, CE)` vectors.
3. Runs 240 deterministic adversarial fuzz mutations (`seed = 20261122`) over
   positive certificates and verifies 0 false acceptances.
"""

from __future__ import annotations

import copy
import json
import pathlib
import random
import subprocess
import sys
from collections import Counter
from typing import Any

FORBIDDEN_DELIMITERS = [
    ". ", ";", "however", "did not", "establish", "determine", "confirm",
    "whether", " that ", "preceded", "comparing", "versus",
    "after adjustment for", "Within this same", "within this same",
]

CAT_RANK = {
    "embeddedCausal": 0,
    "assocCore": 1,
    "metaNonEstabCore": 1,
    "atomicCore": 2,
    "scopedInitial": 3,
    "scopedRepeat": 3,
    "scopedAssoc": 3,
    "scopedContrastMeta": 3,
    "documentRoot": 4,
}


def is_printable_ascii(s: str) -> bool:
    return len(s) > 0 and all(0x20 <= ord(c) <= 0x7E for c in s)


def is_valid_numeric_surface(s: str) -> bool:
    if not s:
        return False
    if s.startswith("-0"):
        rest = s[2:]
        if all(c in ("0", ".") for c in rest):
            return False
        return all(c.isdigit() or c == "." for c in rest)
    if s.startswith("-"):
        if len(s) < 2 or not s[1].isdigit():
            return False
        return all(c.isdigit() or c == "." for c in s[2:])
    return s[0].isdigit() and all(c.isdigit() or c == "." for c in s[1:])


def is_valid_slot_lexeme(sort_name: str, lex: str) -> bool:
    if not is_printable_ascii(lex):
        return False
    if sort_name == "assocDir":
        return lex in ("positively", "inversely")
    if sort_name == "ratioMetric":
        return lex in ("risk ratio", "odds ratio", "hazard ratio")
    if sort_name == "intervDirVerb":
        return lex in ("increase", "reduce")
    if sort_name == "intervVerbPres":
        return lex in ("causes", "increases", "reduces")
    if sort_name == "numericLit":
        return is_valid_numeric_surface(lex)
    return all(bad not in lex for bad in FORBIDDEN_DELIMITERS)


def lookup_role(slots: list[tuple[str, str]], role: str) -> str:
    for r, v in slots:
        if r == role:
            return v
    return ""


def get_rule_spec(code: int) -> dict[str, Any] | None:
    """Clean-room frozen G-01 ~ G-16 rule table."""
    table: dict[int, dict[str, Any]] = {
        1: {
            "name": "DocSingle",
            "lhs": "documentRoot",
            "segs": [("child", "scopedInitial", "clause1"), ("lit", ".")],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        150: {
            "name": "G15_DocConjAtomic",
            "lhs": "documentRoot",
            "segs": [
                ("child", "scopedInitial", "clause1"),
                ("lit", ". "),
                ("child", "scopedInitial", "clause2"),
                ("lit", "."),
            ],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: (
                len(ch) == 2
                and env["quoteIsolation"] == "sentenceAtomic"
                and ch[0].get("cohort") == env["cohortId"]
                and ch[1].get("cohort") == env["cohortId"]
            ),
            "sum": lambda s, ch: {},
        },
        151: {
            "name": "G15_DocConjDiscourse",
            "lhs": "documentRoot",
            "segs": [
                ("child", "scopedInitial", "clause1"),
                ("lit", ". "),
                ("child", "scopedRepeat", "clause2"),
                ("lit", "."),
            ],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: (
                len(ch) == 2
                and env["quoteIsolation"] == "discourseBound"
                and ch[0].get("cohort") == env["cohortId"]
                and ch[1].get("design") == env["expectedDesignHead"]
            ),
            "sum": lambda s, ch: {},
        },
        160: {
            "name": "G16_DocContrastive",
            "lhs": "documentRoot",
            "segs": [
                ("child", "scopedAssoc", "clause1"),
                ("lit", "; however, "),
                ("child", "scopedContrastMeta", "clause2"),
                ("lit", "."),
            ],
            "obls": lambda loc, s, ch: (
                [
                    {
                        "locus": "clause2",
                        "kind": "contrastiveBoundary",
                        "target": (
                            f"{ch[0]['expOut'][0]}:{ch[0]['expOut'][1]}"
                            if ch[0].get("expOut") is not None
                            else ""
                        ),
                    }
                ]
                if len(ch) == 2
                else []
            ),
            "side": lambda env, s, ch: (
                len(ch) == 2
                and ch[0].get("cohort") == env["cohortId"]
                and ch[1].get("design") == env["expectedDesignHead"]
                and ch[0].get("expOut") is not None
                and ch[0].get("expOut") == ch[1].get("expOut")
            ),
            "sum": lambda s, ch: {},
        },
        201: {
            "name": "ScopedInitial",
            "lhs": "scopedInitial",
            "segs": [("lit", "In "), ("slot", "cohortSpec", "cohort"), ("lit", ", "), ("child", "atomicCore", None)],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "scopeAnchor", "target": lookup_role(s, "cohort")}],
            "side": lambda env, s, ch: lookup_role(s, "cohort") == env["cohortId"],
            "sum": lambda s, ch: {"cohort": lookup_role(s, "cohort"), "expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        202: {
            "name": "ScopedRepeatDiscourse",
            "lhs": "scopedRepeat",
            "segs": [("lit", "Within this same "), ("slot", "designNoun", "design"), ("lit", ", "), ("child", "atomicCore", None)],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "scopeAnchor", "target": "resolve:" + lookup_role(s, "design")}],
            "side": lambda env, s, ch: lookup_role(s, "design") == env["expectedDesignHead"],
            "sum": lambda s, ch: {"design": lookup_role(s, "design"), "expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        203: {
            "name": "ScopedAssoc",
            "lhs": "scopedAssoc",
            "segs": [("lit", "In "), ("slot", "cohortSpec", "cohort"), ("lit", ", "), ("child", "assocCore", None)],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "scopeAnchor", "target": lookup_role(s, "cohort")}],
            "side": lambda env, s, ch: lookup_role(s, "cohort") == env["cohortId"],
            "sum": lambda s, ch: {"cohort": lookup_role(s, "cohort"), "expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        204: {
            "name": "ScopedContrastMeta",
            "lhs": "scopedContrastMeta",
            "segs": [("lit", "within this same "), ("slot", "designNoun", "design"), ("lit", ", "), ("child", "metaNonEstabCore", None)],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "scopeAnchor", "target": "resolve:" + lookup_role(s, "design")}],
            "side": lambda env, s, ch: lookup_role(s, "design") == env["expectedDesignHead"],
            "sum": lambda s, ch: {"design": lookup_role(s, "design"), "expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        210: {
            "name": "LiftAssocToAtomic",
            "lhs": "atomicCore",
            "segs": [("child", "assocCore", None)],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: ch[0] if len(ch) == 1 else {},
        },
        211: {
            "name": "LiftMetaToAtomic",
            "lhs": "atomicCore",
            "segs": [("child", "metaNonEstabCore", None)],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: ch[0] if len(ch) == 1 else {},
        },
        301: {
            "name": "EmbeddedCausal",
            "lhs": "embeddedCausal",
            "segs": [("slot", "expLevel", "activeExp"), ("lit", " "), ("slot", "intervVerbPres", "verb"), ("lit", " "), ("slot", "outTerm", "outcome")],
            "obls": lambda loc, s, ch: [],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {
                "expOut": (lookup_role(s, "activeExp"), lookup_role(s, "outcome")),
                "embKey": f"{lookup_role(s, 'activeExp')}:{lookup_role(s, 'verb')}:{lookup_role(s, 'outcome')}",
            },
        },
        10: {
            "name": "G01_DescIncidence",
            "lhs": "atomicCore",
            "segs": [
                ("lit", "over "), ("slot", "followUpWindow", "window"),
                ("lit", ", the cumulative incidence of "), ("slot", "eventTerm", "eventA"),
                ("lit", " was "), ("slot", "numericLit", "numK"),
                ("lit", " of "), ("slot", "numericLit", "numN"),
                ("lit", " patients ("), ("slot", "numericLit", "numPct"), ("lit", "%)"),
            ],
            "obls": lambda loc, s, ch: [{
                "locus": loc, "kind": "descIncidence",
                "target": f"{lookup_role(s, 'window')}:{lookup_role(s, 'eventA')}:{lookup_role(s, 'numK')}/{lookup_role(s, 'numN')}={lookup_role(s, 'numPct')}",
            }],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        20: {
            "name": "G02a_DescMeanSD",
            "lhs": "atomicCore",
            "segs": [
                ("lit", "the mean "), ("slot", "measureTerm", "measure"),
                ("lit", " was "), ("slot", "numericLit", "numEst"),
                ("lit", " (SD "), ("slot", "numericLit", "numDisp1"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [{
                "locus": loc, "kind": "descDistribution",
                "target": f"mean_sd:{lookup_role(s, 'measure')}:{lookup_role(s, 'numEst')}:{lookup_role(s, 'numDisp1')}",
            }],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        30: {
            "name": "G03_AssocUnadj",
            "lhs": "assocCore",
            "segs": [
                ("lit", "comparing "), ("slot", "expLevel", "activeExp"),
                ("lit", " versus "), ("slot", "expLevel", "refExp"),
                ("lit", " was "), ("slot", "assocDir", "direction"),
                ("lit", " associated with "), ("slot", "outTerm", "outcome"),
                ("lit", " ("), ("slot", "ratioMetric", "metric1"),
                ("lit", " = "), ("slot", "numericLit", "numEst"),
                ("lit", ", "), ("slot", "numericLit", "numCILevel"),
                ("lit", "% CI "), ("slot", "numericLit", "numCILow"),
                ("lit", " to "), ("slot", "numericLit", "numCIHigh"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [{
                "locus": loc, "kind": "assocMetricDir",
                "target": f"{lookup_role(s, 'metric1')}:{lookup_role(s, 'direction')}:{lookup_role(s, 'activeExp')}:{lookup_role(s, 'refExp')}:{lookup_role(s, 'outcome')}",
            }],
            "side": lambda env, s, ch: lookup_role(s, "activeExp") != lookup_role(s, "refExp"),
            "sum": lambda s, ch: {"expOut": (lookup_role(s, "activeExp"), lookup_role(s, "outcome"))},
        },
        40: {
            "name": "G04_AssocTemp",
            "lhs": "assocCore",
            "segs": [
                ("slot", "eventTerm", "eventA"), ("lit", " preceded "), ("slot", "eventTerm", "eventB"),
                ("lit", ", and comparing "), ("slot", "expLevel", "activeExp"),
                ("lit", " versus "), ("slot", "expLevel", "refExp"),
                ("lit", " was "), ("slot", "assocDir", "direction"),
                ("lit", " associated with "), ("slot", "outTerm", "outcome"),
                ("lit", " ("), ("slot", "ratioMetric", "metric1"),
                ("lit", " = "), ("slot", "numericLit", "numEst"),
                ("lit", ", "), ("slot", "numericLit", "numCILevel"),
                ("lit", "% CI "), ("slot", "numericLit", "numCILow"),
                ("lit", " to "), ("slot", "numericLit", "numCIHigh"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [
                {"locus": loc, "kind": "temporalPrecedence", "target": f"{lookup_role(s, 'eventA')}<{lookup_role(s, 'eventB')}"},
                {"locus": loc, "kind": "assocMetricDir", "target": f"{lookup_role(s, 'metric1')}:{lookup_role(s, 'direction')}:{lookup_role(s, 'activeExp')}:{lookup_role(s, 'refExp')}:{lookup_role(s, 'outcome')}"},
            ],
            "side": lambda env, s, ch: lookup_role(s, "eventA") != lookup_role(s, "eventB") and lookup_role(s, "activeExp") != lookup_role(s, "refExp"),
            "sum": lambda s, ch: {"expOut": (lookup_role(s, "activeExp"), lookup_role(s, "outcome"))},
        },
        60: {
            "name": "G06a_IntervDirectional",
            "lhs": "atomicCore",
            "segs": [
                ("lit", "under "), ("slot", "identAssump", "assumption"),
                ("lit", ", comparing "), ("slot", "expLevel", "activeExp"),
                ("lit", " versus "), ("slot", "expLevel", "refExp"),
                ("lit", " was estimated to "), ("slot", "intervDirVerb", "verb"),
                ("lit", " "), ("slot", "outTerm", "outcome"),
                ("lit", " ("), ("slot", "ratioMetric", "metric1"),
                ("lit", " = "), ("slot", "numericLit", "numEst"),
                ("lit", ", "), ("slot", "numericLit", "numCILevel"),
                ("lit", "% CI "), ("slot", "numericLit", "numCILow"),
                ("lit", " to "), ("slot", "numericLit", "numCIHigh"),
                ("lit", ", p = "), ("slot", "numericLit", "numPVal"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [
                {"locus": loc, "kind": "identAssumption", "target": lookup_role(s, "assumption")},
                {"locus": loc, "kind": "intervDirectional", "target": f"{lookup_role(s, 'metric1')}:{lookup_role(s, 'verb')}:{lookup_role(s, 'activeExp')}:{lookup_role(s, 'refExp')}:{lookup_role(s, 'outcome')}"},
            ],
            "side": lambda env, s, ch: lookup_role(s, "activeExp") != lookup_role(s, "refExp"),
            "sum": lambda s, ch: {},
        },
        90: {
            "name": "G09_MetaNonEstab",
            "lhs": "metaNonEstabCore",
            "segs": [("lit", "the analysis of "), ("slot", "sourceId", "source"), ("lit", " did not establish that "), ("child", "embeddedCausal", None)],
            "obls": lambda loc, s, ch: [{
                "locus": loc, "kind": "metaNonEstabNeg",
                "target": f"{lookup_role(s, 'source')}:{ch[0].get('embKey', '') if len(ch) == 1 else ''}",
            }],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {"expOut": ch[0].get("expOut") if len(ch) == 1 else None},
        },
        110: {
            "name": "G11_QuantZero",
            "lhs": "atomicCore",
            "segs": [("lit", "no "), ("slot", "subgroupPlural", "subgroup"), ("lit", " patients developed "), ("slot", "eventTerm", "eventA")],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "quantZeroNeg", "target": f"{lookup_role(s, 'subgroup')}:{lookup_role(s, 'eventA')}"}],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        120: {
            "name": "G12_QuantProperPart",
            "lhs": "atomicCore",
            "segs": [("lit", "some, but not all, "), ("slot", "subgroupPlural", "subgroup"), ("lit", " patients developed "), ("slot", "eventTerm", "eventA")],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "quantProperPart", "target": f"{lookup_role(s, 'subgroup')}:{lookup_role(s, 'eventA')}"}],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        130: {
            "name": "G13_QuantAtLeastOne",
            "lhs": "atomicCore",
            "segs": [("lit", "at least one "), ("slot", "subgroupSingular", "subgroup"), ("lit", " patient developed "), ("slot", "eventTerm", "eventA")],
            "obls": lambda loc, s, ch: [{"locus": loc, "kind": "quantExistential", "target": f"{lookup_role(s, 'subgroup')}:{lookup_role(s, 'eventA')}"}],
            "side": lambda env, s, ch: True,
            "sum": lambda s, ch: {},
        },
        140: {
            "name": "G14_AssocAdj",
            "lhs": "assocCore",
            "segs": [
                ("lit", "after adjustment for "), ("slot", "covariateList", "covariates"),
                ("lit", ", comparing "), ("slot", "expLevel", "activeExp"),
                ("lit", " versus "), ("slot", "expLevel", "refExp"),
                ("lit", " was "), ("slot", "assocDir", "direction"),
                ("lit", " associated with "), ("slot", "outTerm", "outcome"),
                ("lit", " ("), ("slot", "ratioMetric", "metric1"),
                ("lit", " = "), ("slot", "numericLit", "numEst"),
                ("lit", ", "), ("slot", "numericLit", "numCILevel"),
                ("lit", "% CI "), ("slot", "numericLit", "numCILow"),
                ("lit", " to "), ("slot", "numericLit", "numCIHigh"), ("lit", ")"),
            ],
            "obls": lambda loc, s, ch: [
                {"locus": loc, "kind": "covariateAdjustment", "target": lookup_role(s, "covariates")},
                {"locus": loc, "kind": "assocMetricDir", "target": f"{lookup_role(s, 'metric1')}:{lookup_role(s, 'direction')}:{lookup_role(s, 'activeExp')}:{lookup_role(s, 'refExp')}:{lookup_role(s, 'outcome')}"},
            ],
            "side": lambda env, s, ch: lookup_role(s, "activeExp") != lookup_role(s, "refExp"),
            "sum": lambda s, ch: {"expOut": (lookup_role(s, "activeExp"), lookup_role(s, "outcome"))},
        },
    }
    return table.get(code)


def check_span(y: str, sp: dict[str, int], seg: str) -> bool:
    s, e = sp["startCp"], sp["endCp"]
    return e == s + len(seg) and e <= len(y) and y[s:e] == seg


def py_reconstruct_yield(cert: dict[str, Any]) -> str:
    parts: list[str] = []
    for arg in cert["segArgs"]:
        if arg["argKind"] == "litSpan":
            parts.append(arg["claimedText"])
        elif arg["argKind"] == "slotLeaf":
            parts.append(arg["lexeme"])
        elif arg["argKind"] == "childNode":
            parts.append(py_reconstruct_yield(arg["sub"]))
    return "".join(parts)


def py_collect_obls(cert: dict[str, Any]) -> list[dict[str, Any]]:
    out = list(cert["claimedDischarged"])
    for arg in cert["segArgs"]:
        if arg["argKind"] == "childNode":
            out.extend(py_collect_obls(arg["sub"]))
    return out


def py_replay_segs(
    env: dict[str, Any],
    y: str,
    loc: str,
    cursor: int,
    segs: list[tuple[Any, ...]],
    args: list[dict[str, Any]],
) -> tuple[bool, str, tuple[int, list[tuple[str, str]], list[dict[str, Any]]] | None]:
    if not segs and not args:
        if cursor <= len(y):
            return True, "NONE", (cursor, [], [])
        return False, "cursorOutOfBounds", None
    if not segs or not args:
        return False, "segmentArityOrKindMismatch", None

    seg, rest_segs = segs[0], segs[1:]
    arg, rest_args = args[0], args[1:]

    if seg[0] == "lit" and arg["argKind"] == "litSpan":
        txt = seg[1]
        claimed = arg["claimedText"]
        sp = arg["span"]
        if claimed != txt:
            return False, "fixedTerminalMismatch", None
        if sp["startCp"] != cursor:
            return False, "spanStartDiscontinuity", None
        if not check_span(y, sp, claimed):
            return False, "spanSliceMismatch", None
        return py_replay_segs(env, y, loc, sp["endCp"], rest_segs, rest_args)

    if seg[0] == "slot" and arg["argKind"] == "slotLeaf":
        exp_sort, exp_role = seg[1], seg[2]
        if arg["sort"] != exp_sort or arg["role"] != exp_role:
            return False, "invalidSlotSortOrRole", None
        if not is_valid_slot_lexeme(exp_sort, arg["lexeme"]):
            return False, "invalidSlotLexemeOrKeywordLeak", None
        sp = arg["span"]
        if sp["startCp"] != cursor:
            return False, "spanStartDiscontinuity", None
        if not check_span(y, sp, arg["lexeme"]):
            return False, "spanSliceMismatch", None
        ok, tag, sub = py_replay_segs(env, y, loc, sp["endCp"], rest_segs, rest_args)
        if not ok or sub is None:
            return False, tag, None
        end_pos, rest_slots, sums = sub
        return True, "NONE", (end_pos, [(exp_role, arg["entityId"])] + rest_slots, sums)

    if seg[0] == "child" and arg["argKind"] == "childNode":
        cat, loc_override = seg[1], seg[2]
        sub_cert = arg["sub"]
        if sub_cert["span"]["startCp"] != cursor:
            return False, "spanStartDiscontinuity", None
        child_loc = loc_override if loc_override is not None else loc
        ok_c, tag_c, child_sum = py_replay_node(env, y, child_loc, cat, sub_cert)
        if not ok_c or child_sum is None:
            return False, tag_c, None
        ok_r, tag_r, sub = py_replay_segs(env, y, loc, sub_cert["span"]["endCp"], rest_segs, rest_args)
        if not ok_r or sub is None:
            return False, tag_r, None
        end_pos, slots, rest_sums = sub
        return True, "NONE", (end_pos, slots, [child_sum] + rest_sums)

    return False, "segmentArityOrKindMismatch", None


def py_replay_node(
    env: dict[str, Any],
    y: str,
    loc: str,
    expected_cat: str,
    cert: dict[str, Any],
) -> tuple[bool, str, dict[str, Any] | None]:
    rule = get_rule_spec(cert["rawRuleCode"])
    if rule is None:
        return False, "forgedOrTrapRuleId", None
    if rule["lhs"] != expected_cat:
        return False, "nontermCatMismatch", None
    # Verify rank acyclicity explicitly on rule definition
    for seg in rule["segs"]:
        if seg[0] == "child":
            assert CAT_RANK[seg[1]] < CAT_RANK[rule["lhs"]], "Rank acyclicity violated!"

    sp = cert["span"]
    ok, tag, seg_res = py_replay_segs(env, y, loc, sp["startCp"], rule["segs"], cert["segArgs"])
    if not ok or seg_res is None:
        return False, tag, None
    end_pos, slots, sums = seg_res
    if end_pos != sp["endCp"]:
        return False, "nodeEndSpanMismatch", None
    if not rule["side"](env, slots, sums):
        return False, "sideConditionFailed", None
    expected_specs = rule["obls"](loc, slots, sums)
    actual_specs = [
        {"locus": o["locus"], "kind": o["kind"], "target": o["target"]}
        for o in cert["claimedDischarged"]
    ]
    if actual_specs != expected_specs:
        return False, "locusOrTargetOblMismatch", None
    return True, "NONE", rule["sum"](slots, sums)


def obl_key(o: dict[str, Any]) -> tuple[int, str, str, str]:
    return (o["oblId"], o["locus"], o["kind"], o["target"])


def py_replay_derivation(
    env: dict[str, Any],
    y: str,
    delta_in: list[dict[str, Any]],
    cert: dict[str, Any],
) -> tuple[bool, str]:
    in_ids = [o["oblId"] for o in delta_in]
    if len(in_ids) != len(set(in_ids)):
        return False, "inputOblIdsNotUnique"
    if cert["span"] != {"startCp": 0, "endCp": len(y)}:
        return False, "rootSpanNotFullText"
    ok, tag, _ = py_replay_node(env, y, "clause1", "documentRoot", cert)
    if not ok:
        return False, tag
    claimed_all = py_collect_obls(cert)
    claimed_ids = [o["oblId"] for o in claimed_all]
    if len(claimed_ids) != len(set(claimed_ids)):
        return False, "duplicateOblIdDischarged"
    if Counter(obl_key(o) for o in claimed_all) != Counter(obl_key(o) for o in delta_in):
        return False, "obligationMultisetMismatch"
    return True, "NONE"


def run_adversarial_fuzz(positive_cases: list[dict[str, Any]], trials: int = 240) -> tuple[int, int]:
    rng = random.Random(20261122)
    rejected_count = 0
    for i in range(trials):
        base = copy.deepcopy(positive_cases[i % len(positive_cases)])
        env = base["env"]
        y = base["surfaceText"]
        delta = base["deltaIn"]
        cert = base["cert"]
        mode = i % 6
        if mode == 0:
            # Forge root or child rule code
            cert["rawRuleCode"] = rng.choice([901, 902, 903, 999, 777])
        elif mode == 1:
            # Mutate 1 character in surface text Y
            idx = rng.randrange(len(y))
            replacement = "X" if y[idx] != "X" else "Z"
            y = y[:idx] + replacement + y[idx + 1 :]
        elif mode == 2:
            # Shift root endCp or first child startCp
            cert["span"]["endCp"] += 1
        elif mode == 3:
            # Drop or add obligation in deltaIn (multiset violation)
            delta.append({"oblId": 99999 + i, "locus": "clause1", "kind": "quantZeroNeg", "target": "x:y"})
        elif mode == 4:
            # Swap locus on an obligation in both deltaIn and root/child
            if delta:
                delta[0]["locus"] = "clause2" if delta[0]["locus"] == "clause1" else "clause1"
        elif mode == 5:
            # Duplicate obligation ID in deltaIn
            if delta:
                delta.append(copy.deepcopy(delta[0]))

        ok, _ = py_replay_derivation(env, y, delta, cert)
        if not ok:
            rejected_count += 1
    return rejected_count, trials


def main() -> int:
    root_dir = pathlib.Path(__file__).resolve().parent.parent
    exe_path = root_dir / ".lake" / "build" / "bin" / "p2_tribunal_runner.exe"
    if not exe_path.exists():
        print(f"ERROR: Missing executable {exe_path}", file=sys.stderr)
        return 2

    proc = subprocess.run([str(exe_path), "--json"], capture_output=True, text=True, check=True)
    cases: list[dict[str, Any]] = json.loads(proc.stdout)

    print("==========================================================================")
    print("PYTHON 3.11 INDEPENDENT DIFFERENTIAL ORACLE — BROCA-NATIVE OMEGA P2")
    print(f"Loaded {len(cases)} serialized vectors from Lean p2_tribunal_runner.exe")
    print("==========================================================================")

    mismatches = 0
    positives: list[dict[str, Any]] = []
    for tc in cases:
        py_acc, py_tag = py_replay_derivation(tc["env"], tc["surfaceText"], tc["deltaIn"], tc["cert"])
        lean_acc = tc["leanAccepted"]
        lean_tag = tc["leanDiagTag"]
        yield_ok = (py_reconstruct_yield(tc["cert"]) == tc["surfaceText"]) if py_acc else True
        parity = (py_acc == lean_acc) and (py_tag == lean_tag) and yield_ok
        mark = "PARITY_OK" if parity else "MISMATCH"
        print(
            f"[{mark}] {tc['caseId']} | Lean=({lean_acc}, {lean_tag}) "
            f"| Python=({py_acc}, {py_tag})"
        )
        if not parity:
            mismatches += 1
        if tc["isPositive"]:
            positives.append(tc)

    rej_fuzz, total_fuzz = run_adversarial_fuzz(positives, trials=240)
    print("--------------------------------------------------------------------------")
    print(f"Suite Differential Parity : {len(cases) - mismatches} / {len(cases)} EXACT MATCH")
    print(f"Adversarial Fuzz Trials   : {rej_fuzz} / {total_fuzz} REJECTED (seed=20261122)")
    print("==========================================================================")
    if mismatches == 0 and rej_fuzz == total_fuzz:
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
