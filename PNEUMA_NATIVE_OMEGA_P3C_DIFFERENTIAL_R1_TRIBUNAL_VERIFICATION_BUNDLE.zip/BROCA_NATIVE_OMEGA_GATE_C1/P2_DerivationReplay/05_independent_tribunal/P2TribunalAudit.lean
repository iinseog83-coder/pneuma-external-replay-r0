/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  05_independent_tribunal/P2TribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  1. `#print axioms` audit across all exported `PO-C1-02` theorems and foundational lemmas.
  2. Executable CLI test runner (`p2_tribunal_runner`) supporting both human-readable
     table verification and `--json` vector serialization for the independent Python 3.11
     differential oracle (`differential_oracle_p2.py`).
-/
import P2FormalSpec
import P2DetachedChecker
import P2Counterexamples
import P2ProofObligations

/-! ### 1. Compile-Time Kernel Axiom Footprint Audit (`#print axioms`) -/

#print axioms BrocaOmega.P2.ProofObligations.PO_C1_02_GrammarAcyclicRank
#print axioms BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplaySoundness
#print axioms BrocaOmega.P2.ProofObligations.PO_C1_02_DerivationReplayCompleteness
#print axioms BrocaOmega.P2.ProofObligations.PO_C1_02_CounterexampleSuiteVerified
#print axioms BrocaOmega.P2.validGrammarDerivation_yield_eq
#print axioms BrocaOmega.P2.validGrammarDerivation_implies_locusTargetBound
#print axioms BrocaOmega.P2.spanMatches_concat
#print axioms BrocaOmega.P2.spanMatches_full_eq
#print axioms BrocaOmega.P2.checkMultisetEqBool_iff
#print axioms BrocaOmega.P2.checkNoDupOblIdsBool_iff

namespace BrocaOmega.P2.Tribunal

open BrocaOmega.P2
open BrocaOmega.P2.Counterexamples

/-! ### 2. Deterministic Diagnostic Tag & Minimal Pure JSON Serializer -/

def diagCategoryTag : CEGESReplayDiag → String
  | .forgedOrTrapRuleId _ _            => "forgedOrTrapRuleId"
  | .nontermCatMismatch _ _ _          => "nontermCatMismatch"
  | .segmentArityOrKindMismatch _      => "segmentArityOrKindMismatch"
  | .fixedTerminalMismatch _ _ _       => "fixedTerminalMismatch"
  | .invalidSlotSortOrRole _           => "invalidSlotSortOrRole"
  | .invalidSlotLexemeOrKeywordLeak _ _ _ => "invalidSlotLexemeOrKeywordLeak"
  | .spanStartDiscontinuity _ _ _      => "spanStartDiscontinuity"
  | .spanSliceMismatch _ _             => "spanSliceMismatch"
  | .cursorOutOfBounds _ _ _           => "cursorOutOfBounds"
  | .nodeEndSpanMismatch _ _ _         => "nodeEndSpanMismatch"
  | .sideConditionFailed _ _           => "sideConditionFailed"
  | .locusOrTargetOblMismatch _ _ _    => "locusOrTargetOblMismatch"
  | .rootSpanNotFullText _ _           => "rootSpanNotFullText"
  | .inputOblIdsNotUnique              => "inputOblIdsNotUnique"
  | .duplicateOblIdDischarged          => "duplicateOblIdDischarged"
  | .obligationMultisetMismatch        => "obligationMultisetMismatch"

def escapeJsonChars : List Char → List Char
  | [] => []
  | '"' :: cs  => '\\' :: '"' :: escapeJsonChars cs
  | '\\' :: cs => '\\' :: '\\' :: escapeJsonChars cs
  | '\n' :: cs => '\\' :: 'n' :: escapeJsonChars cs
  | c :: cs    => c :: escapeJsonChars cs

def jStr (s : String) : String :=
  "\"" ++ String.ofList (escapeJsonChars s.toList) ++ "\""

def jBool (b : Bool) : String := if b then "true" else "false"

def jList (items : List String) : String :=
  "[" ++ String.intercalate "," items ++ "]"

def locusToStr : ClauseLocus → String
  | .clause1 => "clause1"
  | .clause2 => "clause2"

def oblKindToStr : OblKind → String
  | .scopeAnchor          => "scopeAnchor"
  | .descIncidence        => "descIncidence"
  | .descDistribution     => "descDistribution"
  | .assocMetricDir       => "assocMetricDir"
  | .temporalPrecedence   => "temporalPrecedence"
  | .absRiskDiff          => "absRiskDiff"
  | .identAssumption      => "identAssumption"
  | .intervDirectional    => "intervDirectional"
  | .intervNeutral        => "intervNeutral"
  | .metaNotStatSig       => "metaNotStatSig"
  | .metaEquivMargins     => "metaEquivMargins"
  | .metaNonEstabNeg      => "metaNonEstabNeg"
  | .metaUnresolvedPolar  => "metaUnresolvedPolar"
  | .quantZeroNeg         => "quantZeroNeg"
  | .quantProperPart      => "quantProperPart"
  | .quantExistential     => "quantExistential"
  | .covariateAdjustment  => "covariateAdjustment"
  | .contrastiveBoundary  => "contrastiveBoundary"

def slotSortToStr : SlotSort → String
  | .cohortSpec       => "cohortSpec"
  | .designNoun       => "designNoun"
  | .followUpWindow   => "followUpWindow"
  | .eventTerm        => "eventTerm"
  | .measureTerm      => "measureTerm"
  | .expLevel         => "expLevel"
  | .outTerm          => "outTerm"
  | .sourceId         => "sourceId"
  | .identAssump      => "identAssump"
  | .subgroupPlural   => "subgroupPlural"
  | .subgroupSingular => "subgroupSingular"
  | .covariateList    => "covariateList"
  | .assocDir         => "assocDir"
  | .ratioMetric      => "ratioMetric"
  | .intervDirVerb    => "intervDirVerb"
  | .intervVerbPres   => "intervVerbPres"
  | .numericLit       => "numericLit"

def slotRoleToStr : SlotRole → String
  | .cohort        => "cohort"
  | .design        => "design"
  | .window        => "window"
  | .eventA        => "eventA"
  | .eventB        => "eventB"
  | .measure       => "measure"
  | .activeExp     => "activeExp"
  | .refExp        => "refExp"
  | .outcome       => "outcome"
  | .source        => "source"
  | .assumption    => "assumption"
  | .subgroup      => "subgroup"
  | .covariates    => "covariates"
  | .direction     => "direction"
  | .metric1       => "metric1"
  | .metric2       => "metric2"
  | .verb          => "verb"
  | .numK          => "numK"
  | .numN          => "numN"
  | .numPct        => "numPct"
  | .numEst        => "numEst"
  | .numDisp1      => "numDisp1"
  | .numDisp2      => "numDisp2"
  | .numCILevel    => "numCILevel"
  | .numCILow      => "numCILow"
  | .numCIHigh     => "numCIHigh"
  | .numPVal       => "numPVal"
  | .numAlpha      => "numAlpha"
  | .numMarginLow  => "numMarginLow"
  | .numMarginHigh => "numMarginHigh"

def spanToJson (sp : CodepointSpan) : String :=
  "{\"startCp\":" ++ toString sp.startCp ++ ",\"endCp\":" ++ toString sp.endCp ++ "}"

def oblTokToJson (o : ObligationToken) : String :=
  "{\"oblId\":" ++ toString o.oblId ++
  ",\"locus\":" ++ jStr (locusToStr o.spec.locus) ++
  ",\"kind\":" ++ jStr (oblKindToStr o.spec.kind) ++
  ",\"target\":" ++ jStr o.spec.target ++ "}"

mutual
  def segArgToJson : UntrustedSegArg → String
    | .litSpan txt sp =>
      "{\"argKind\":\"litSpan\",\"claimedText\":" ++ jStr txt ++
      ",\"span\":" ++ spanToJson sp ++ "}"
    | .slotLeaf tok =>
      "{\"argKind\":\"slotLeaf\",\"sort\":" ++ jStr (slotSortToStr tok.sort) ++
      ",\"role\":" ++ jStr (slotRoleToStr tok.role) ++
      ",\"entityId\":" ++ jStr tok.entityId ++
      ",\"lexeme\":" ++ jStr tok.lexeme ++
      ",\"span\":" ++ spanToJson tok.span ++ "}"
    | .childNode sub =>
      "{\"argKind\":\"childNode\",\"sub\":" ++ certToJson sub ++ "}"

  def certToJson : UntrustedDerivCert → String
    | .mkNode nid rc sp claimed args =>
      "{\"nodeId\":" ++ toString nid ++
      ",\"rawRuleCode\":" ++ toString rc ++
      ",\"span\":" ++ spanToJson sp ++
      ",\"claimedDischarged\":" ++ jList (claimed.map oblTokToJson) ++
      ",\"segArgs\":" ++ jList (args.map segArgToJson) ++ "}"
end

def envToJson (e : ScopeEnv) : String :=
  let qMode := match e.quoteIsolation with
    | .sentenceAtomic => "sentenceAtomic"
    | .discourseBound => "discourseBound"
  "{\"cohortId\":" ++ jStr e.cohortId ++
  ",\"expectedDesignHead\":" ++ jStr e.expectedDesignHead ++
  ",\"quoteIsolation\":" ++ jStr qMode ++ "}"

def testCaseToJson (tc : P2TestCase) : String :=
  let out := replayDerivation tc.env tc.surfaceText tc.deltaIn tc.cert
  let dTag := match out.diag? with
    | none => "NONE"
    | some d => diagCategoryTag d
  "{\"caseId\":" ++ jStr tc.caseId ++
  ",\"pairGroup\":" ++ jStr tc.pairGroup ++
  ",\"isPositive\":" ++ jBool tc.isPositive ++
  ",\"env\":" ++ envToJson tc.env ++
  ",\"surfaceText\":" ++ jStr tc.surfaceText ++
  ",\"deltaIn\":" ++ jList (tc.deltaIn.map oblTokToJson) ++
  ",\"cert\":" ++ certToJson tc.cert ++
  ",\"leanAccepted\":" ++ jBool out.isAccepted ++
  ",\"leanDiagTag\":" ++ jStr dTag ++ "}"

end BrocaOmega.P2.Tribunal

def main (args : List String) : IO UInt32 := do
  let cases := BrocaOmega.P2.Counterexamples.allP2Cases
  if args.contains "--json" then
    IO.println (BrocaOmega.P2.Tribunal.jList (cases.map BrocaOmega.P2.Tribunal.testCaseToJson))
    return 0
  else
    IO.println "=========================================================================="
    IO.println "BROCA-NATIVE OMEGA — AUTH-C1-P2 DETACHED DERIVATION REPLAY VERIFICATION"
    IO.println "Target Obligation : PO-C1-02 (Derivation Replay Soundness & Completeness)"
    IO.println "Toolchain         : Lean 4.33.1 Core (Init only, 0 external deps, 0 sorry)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for tc in cases do
      let ok := tc.runCheck
      let out := BrocaOmega.P2.replayDerivation tc.env tc.surfaceText tc.deltaIn tc.cert
      let statusStr := if ok then "PASS" else "FAIL"
      let outcomeStr := match out with
        | .accepted w =>
          s!"ACCEPTED (reconstructYield == Y: {BrocaOmega.P2.reconstructYield w.cert == tc.surfaceText})"
        | .rejected d =>
          s!"REJECTED ({BrocaOmega.P2.Tribunal.diagCategoryTag d})"
      IO.println s!"[{statusStr}] {tc.caseId} ({tc.pairGroup}) => {outcomeStr}"
      if ok then
        passCount := passCount + 1
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"SUMMARY: {passCount} / {cases.length} symmetric (PC, CE) vectors verified."
    IO.println "P1 External Replay Status : HELD (PO_C1_04A_FINAL_EXTERNAL_ADMISSION_HELD)"
    IO.println "P1-C / P3..P5 / Pneuma-S3 : NOT_AUTHORIZED"
    IO.println "=========================================================================="
    if passCount == cases.length then
      return 0
    else
      return 1
