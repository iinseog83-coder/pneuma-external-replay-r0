/-
  BROCA-NATIVE Ω — Gate C1-P2 (`PO-C1-02`: Derivation Replay Soundness)
  P2DetachedChecker/ReplayChecker.lean
  Pure Lean 4.33.1 Core (`Init` only, zero external dependencies)

  Implements the detached Bottom-Up Span-Yield & Locus-Bound Obligation Replay Kernel:
  1. Strict architectural separation between proof-carrying `ReplayOutcome.accepted (w)`
     (`CertifiedDerivation` with `private mk ::`) and non-authoritative structured
     diagnostics `ReplayOutcome.rejected (diag : CEGESReplayDiag)`.
  2. Total recursive verification of frozen `G-01` ~ `G-16` rules, contiguous spans,
     keyword barriers, clause-locus/target-bound obligations, and linear multiset conservation.
  3. Machine-checked `replayDerivation_sound` (`PO-C1-02`) and `replayDerivation_complete`.
-/
import P2FormalSpec

namespace BrocaOmega.P2

/-! ### 1. Non-Authoritative Structured CEGES Refutation Diagnostics -/

/--
  Structured diagnostic emitted on rejection to guide outer untrusted CEGES repair.
  Carries zero proof authority and cannot construct `CertifiedDerivation`.
-/
inductive CEGESReplayDiag where
  | forgedOrTrapRuleId            (nodeId : Nat) (rawRuleCode : Nat)
  | nontermCatMismatch            (nodeId : Nat) (expected actual : NontermCat)
  | segmentArityOrKindMismatch    (nodeId : Nat)
  | fixedTerminalMismatch         (nodeId : Nat) (expected claimed : String)
  | invalidSlotSortOrRole         (nodeId : Nat)
  | invalidSlotLexemeOrKeywordLeak (nodeId : Nat) (sort : SlotSort) (lexeme : String)
  | spanStartDiscontinuity        (nodeId : Nat) (expectedCursor actualStart : Nat)
  | spanSliceMismatch             (nodeId : Nat) (span : CodepointSpan)
  | cursorOutOfBounds             (nodeId : Nat) (cursor textLen : Nat)
  | nodeEndSpanMismatch           (nodeId : Nat) (expectedEnd actualEnd : Nat)
  | sideConditionFailed           (nodeId : Nat) (rule : FrozenGenRule)
  | locusOrTargetOblMismatch      (nodeId : Nat) (expected actual : List ObligationSpec)
  | rootSpanNotFullText           (actual : CodepointSpan) (expectedLen : Nat)
  | inputOblIdsNotUnique
  | duplicateOblIdDischarged
  | obligationMultisetMismatch
  deriving DecidableEq, Repr

/-! ### 2. Sealed Proof-Carrying Witness & Replay Outcome -/

/--
  Sealed proof-carrying witness for an accepted `UntrustedDerivCert`.
  `private mk ::` ensures no external code can forge an instance without passing `replayDerivation`.
-/
structure CertifiedDerivation (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken) where
  private mk ::
  cert        : UntrustedDerivCert
  hValidDeriv : ValidGrammarDerivation env Y cert
  hYieldEq    : reconstructYield cert = Y
  hOblConserv : ObligationsConserved cert deltaIn
  hLocusBound : LocusTargetBound cert

/-- Outcome of detached derivation replay: proof-carrying `accepted` vs diagnostic `rejected`. -/
inductive ReplayOutcome (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken) where
  | accepted (witness : CertifiedDerivation env Y deltaIn)
  | rejected (diag : CEGESReplayDiag)

def ReplayOutcome.isAccepted {env : ScopeEnv} {Y : String} {deltaIn : List ObligationToken} :
    ReplayOutcome env Y deltaIn → Bool
  | .accepted _ => true
  | .rejected _ => false

def ReplayOutcome.diag? {env : ScopeEnv} {Y : String} {deltaIn : List ObligationToken} :
    ReplayOutcome env Y deltaIn → Option CEGESReplayDiag
  | .accepted _ => none
  | .rejected d => some d

/-! ### 3. Proof-Carrying Bottom-Up Segment & Node Replay Kernel -/

mutual
  /--
    Verifies a production's `RuleSegment` list against `UntrustedSegArg` list from `cursor`,
    synthesizing `(endPos, slots, childSummaries)` together with a proof of `ValidSegChain`.
  -/
  def replaySegs (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (nodeId : Nat) (cursor : Nat) (segs : List RuleSegment) (args : List UntrustedSegArg) :
      Except CEGESReplayDiag
        { res : Nat × List (SlotRole × String) × List NodeSummary //
          ValidSegChain env Y loc cursor segs args res.1 res.2.1 res.2.2 } :=
    match segs, args with
    | [], [] =>
      if hle : cursor ≤ Y.length then
        .ok ⟨(cursor, [], []), ⟨hle, rfl, rfl, rfl⟩⟩
      else
        .error (.cursorOutOfBounds nodeId cursor Y.length)

    | .lit txt :: restSegs, .litSpan claimed sp :: restArgs =>
      if htxt : claimed = txt then
        if hstart : sp.startCp = cursor then
          if hslice : checkSpanMatchesBool Y sp claimed.toList = true then
            match replaySegs env Y loc nodeId sp.endCp restSegs restArgs with
            | .error e => .error e
            | .ok subRes =>
              let endPos := subRes.1.1
              let slots  := subRes.1.2.1
              let sums   := subRes.1.2.2
              .ok ⟨(endPos, slots, sums),
                    ⟨htxt, hstart, checkSpanMatchesBool_sound hslice, subRes.2⟩⟩
          else
            .error (.spanSliceMismatch nodeId sp)
        else
          .error (.spanStartDiscontinuity nodeId cursor sp.startCp)
      else
        .error (.fixedTerminalMismatch nodeId txt claimed)

    | .slot expectedSort expectedRole :: restSegs, .slotLeaf tok :: restArgs =>
      if hsr : tok.sort = expectedSort ∧ tok.role = expectedRole then
        if hlex : isValidSlotLexeme expectedSort tok.lexeme = true then
          if hstart : tok.span.startCp = cursor then
            if hslice : checkSpanMatchesBool Y tok.span tok.lexeme.toList = true then
              match replaySegs env Y loc nodeId tok.span.endCp restSegs restArgs with
              | .error e => .error e
              | .ok subRes =>
                let endPos    := subRes.1.1
                let restSlots := subRes.1.2.1
                let sums      := subRes.1.2.2
                .ok ⟨(endPos, (expectedRole, tok.entityId) :: restSlots, sums),
                      ⟨restSlots, hsr.1, hsr.2, hlex, hstart,
                       checkSpanMatchesBool_sound hslice, rfl, subRes.2⟩⟩
            else
              .error (.spanSliceMismatch nodeId tok.span)
          else
            .error (.spanStartDiscontinuity nodeId cursor tok.span.startCp)
        else
          .error (.invalidSlotLexemeOrKeywordLeak nodeId expectedSort tok.lexeme)
      else
        .error (.invalidSlotSortOrRole nodeId)

    | .child cat locOpt :: restSegs, .childNode sub :: restArgs =>
      let childStart := match sub with | .mkNode _ _ sp _ _ => sp.startCp
      let childEnd   := match sub with | .mkNode _ _ sp _ _ => sp.endCp
      if hstart : childStart = cursor then
        match replayNode env Y (locOpt.getD loc) cat sub with
        | .error e => .error e
        | .ok childRes =>
          match replaySegs env Y loc nodeId childEnd restSegs restArgs with
          | .error e => .error e
          | .ok subRes =>
            let endPos   := subRes.1.1
            let slots    := subRes.1.2.1
            let restSums := subRes.1.2.2
            .ok ⟨(endPos, slots, childRes.1 :: restSums),
                  ⟨childRes.1, restSums, hstart, childRes.2, rfl, subRes.2⟩⟩
      else
        .error (.spanStartDiscontinuity nodeId cursor childStart)

    | _, _ =>
      .error (.segmentArityOrKindMismatch nodeId)

  /--
    Verifies a single node of `UntrustedDerivCert` against `expectedCat` and `loc`,
    synthesizing its `NodeSummary` together with a proof of `ValidNodeDeriv`.
  -/
  def replayNode (env : ScopeEnv) (Y : List Char) (loc : ClauseLocus)
      (expectedCat : NontermCat) (cert : UntrustedDerivCert) :
      Except CEGESReplayDiag { sum : NodeSummary // ValidNodeDeriv env Y loc expectedCat cert sum } :=
    match cert with
    | .mkNode nodeId rawCode sp claimed args =>
      match hdec : decodeFrozenRule rawCode with
      | none => .error (.forgedOrTrapRuleId nodeId rawCode)
      | some r =>
        let sig := ruleSignature r
        if hcat : sig.lhsCat = expectedCat then
          match replaySegs env Y loc nodeId sp.startCp sig.segments args with
          | .error e => .error e
          | .ok segRes =>
            let endPos := segRes.1.1
            let slots  := segRes.1.2.1
            let sums   := segRes.1.2.2
            if hend : endPos = sp.endCp then
              if hside : sig.checkSideCond env slots sums = true then
                let expectedSpecs := sig.intrinsicObls loc slots sums
                let actualSpecs   := claimed.map (·.spec)
                if hlocus : actualSpecs = expectedSpecs then
                  have hsegs' : ValidSegChain env Y loc sp.startCp sig.segments args sp.endCp slots sums := by
                    rw [← hend]
                    exact segRes.2
                  .ok ⟨sig.mkSummary slots sums,
                        ⟨r, slots, sums, hdec, hcat, hsegs', hside, hlocus, rfl⟩⟩
                else
                  .error (.locusOrTargetOblMismatch nodeId expectedSpecs actualSpecs)
              else
                .error (.sideConditionFailed nodeId r)
            else
              .error (.nodeEndSpanMismatch nodeId endPos sp.endCp)
        else
          .error (.nontermCatMismatch nodeId expectedCat sig.lhsCat)
end

/--
  Top-Level Detached Derivation Replay Verifier (`Gate C1-P2`).
  Verifies:
  1. Duplicate-freeness of `deltaIn` obligation IDs (`NoDupOblIds deltaIn`).
  2. Root span covers `[0, Y.toList.length)` (`rootSpanNotFullText`).
  3. Full recursive `G-01`~`G-16` grammar, contiguous span-yield, and locus-target obligations (`replayNode`).
  4. Duplicate-freeness of discharged obligation IDs (`NoDupOblIds (collectClaimedObls cert)`).
  5. Exact free-commutative-monoid multiset equality (`MultisetEq (collectClaimedObls cert) deltaIn`).
-/
def replayDerivation (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert) : ReplayOutcome env Y deltaIn :=
  if hNoDupIn : checkNoDupOblIdsBool deltaIn = true then
    match cert with
    | .mkNode nid rc rootSp cl args =>
      let certVal := UntrustedDerivCert.mkNode nid rc rootSp cl args
      if hRootSp : rootSp = ⟨0, Y.toList.length⟩ then
        match replayNode env Y.toList .clause1 .documentRoot certVal with
        | .error diag => .rejected diag
        | .ok nodeRes =>
          let claimedAll := collectClaimedObls certVal
          if hNoDupClaim : checkNoDupOblIdsBool claimedAll = true then
            if hMulti : checkMultisetEqBool claimedAll deltaIn = true then
              have hValid : ValidGrammarDerivation env Y certVal :=
                ⟨hRootSp, nodeRes.1, nodeRes.2⟩
              have hYield : reconstructYield certVal = Y :=
                validGrammarDerivation_yield_eq hValid
              have hObl : ObligationsConserved certVal deltaIn :=
                ⟨(checkNoDupOblIdsBool_iff deltaIn).mp hNoDupIn,
                 (checkNoDupOblIdsBool_iff claimedAll).mp hNoDupClaim,
                 (checkMultisetEqBool_iff claimedAll deltaIn).mp hMulti⟩
              have hLocus : LocusTargetBound certVal :=
                validGrammarDerivation_implies_locusTargetBound hValid
              .accepted ⟨certVal, hValid, hYield, hObl, hLocus⟩
            else
              .rejected .obligationMultisetMismatch
          else
            .rejected .duplicateOblIdDischarged
      else
        .rejected (.rootSpanNotFullText rootSp Y.toList.length)
  else
    .rejected .inputOblIdsNotUnique

/-! ### 4. Main Soundness (`PO-C1-02`) & Relative Completeness Theorems -/

/--
  Lemma: Witness binding (`replayDerivation` never substitutes a different certificate).
-/
theorem replayDerivation_witness_cert_eq
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert) (w : CertifiedDerivation env Y deltaIn)
    (hAcc : replayDerivation env Y deltaIn cert = .accepted w) :
    w.cert = cert := by
  cases cert with
  | mkNode nid rc rootSp cl args =>
    unfold replayDerivation at hAcc
    dsimp at hAcc
    split at hAcc
    · split at hAcc
      · split at hAcc
        · contradiction
        · split at hAcc
          · split at hAcc
            · injection hAcc with hw
              rw [← hw]
            · contradiction
          · contradiction
      · contradiction
    · contradiction

/--
  **Theorem `PO-C1-02` (`replayDerivation_sound`) — Derivation Replay Soundness**:
  Whenever `replayDerivation env Y deltaIn cert = .accepted w`, the exact submitted `cert`
  satisfies all four declarative guarantees:
  1. `ValidGrammarDerivation env Y cert`
  2. `reconstructYield cert = Y`
  3. `ObligationsConserved cert deltaIn`
  4. `LocusTargetBound cert`
-/
theorem replayDerivation_sound
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken)
    (cert : UntrustedDerivCert) (w : CertifiedDerivation env Y deltaIn)
    (hAcc : replayDerivation env Y deltaIn cert = .accepted w) :
    w.cert = cert ∧
    ValidGrammarDerivation env Y cert ∧
    reconstructYield cert = Y ∧
    ObligationsConserved cert deltaIn ∧
    LocusTargetBound cert := by
  have hcert : w.cert = cert := replayDerivation_witness_cert_eq env Y deltaIn cert w hAcc
  refine ⟨hcert, ?_, ?_, ?_, ?_⟩
  · exact hcert ▸ w.hValidDeriv
  · exact hcert ▸ w.hYieldEq
  · exact hcert ▸ w.hOblConserv
  · exact hcert ▸ w.hLocusBound

/-! ### 5. Relative Completeness (`ValidGrammarDerivation ∧ ObligationsConserved ⟹ accepted`) -/

mutual
  theorem replaySegs_complete
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus}
      (nodeId : Nat) {cursor endPos : Nat} {segs : List RuleSegment}
      (args : List UntrustedSegArg)
      {slots : List (SlotRole × String)} {sums : List NodeSummary}
      (h : ValidSegChain env Y loc cursor segs args endPos slots sums) :
      ∃ subRes,
        replaySegs env Y loc nodeId cursor segs args = .ok subRes ∧
        subRes.1 = (endPos, slots, sums) := by
    match segs, args with
    | [], [] =>
      rcases h with ⟨hle, hend, hslots, hsums⟩
      subst endPos; subst slots; subst sums
      refine ⟨⟨(cursor, [], []), ⟨hle, rfl, rfl, rfl⟩⟩, ?_, rfl⟩
      simp [replaySegs, hle]
    | .lit txt :: restSegs, .litSpan claimed sp :: restArgs =>
      rcases h with ⟨htxt, hstart, hspan, hrest⟩
      subst claimed
      have hslice : checkSpanMatchesBool Y sp txt.toList = true :=
        spanMatches_implies_checkBool hspan
      rcases replaySegs_complete nodeId restArgs hrest with ⟨subRes, hrec, hval⟩
      rcases subRes with ⟨⟨eP, sls, sms⟩, hprf⟩
      dsimp at hval
      injection hval with h1 h2
      injection h2 with h3 h4
      subst eP; subst sls; subst sms
      refine ⟨⟨(endPos, slots, sums), ⟨rfl, hstart, checkSpanMatchesBool_sound hslice, hprf⟩⟩, ?_, rfl⟩
      simp [replaySegs, hstart, hslice, hrec]
    | .slot expectedSort expectedRole :: restSegs, .slotLeaf tok :: restArgs =>
      rcases h with ⟨restSlots, hsort, hrole, hlex, hstart, hspan, hslots_eq, hrest⟩
      subst slots; subst expectedSort; subst expectedRole
      have hslice : checkSpanMatchesBool Y tok.span tok.lexeme.toList = true :=
        spanMatches_implies_checkBool hspan
      rcases replaySegs_complete nodeId restArgs hrest with ⟨subRes, hrec, hval⟩
      rcases subRes with ⟨⟨eP, sls, sms⟩, hprf⟩
      dsimp at hval
      injection hval with h1 h2
      injection h2 with h3 h4
      subst eP; subst sls; subst sms
      refine ⟨⟨(endPos, (tok.role, tok.entityId) :: restSlots, sums),
              ⟨restSlots, rfl, rfl, hlex, hstart, checkSpanMatchesBool_sound hslice, rfl, hprf⟩⟩, ?_, rfl⟩
      simp [replaySegs, hlex, hstart, hslice, hrec]
    | .child cat locOpt :: restSegs, .childNode sub :: restArgs =>
      rcases h with ⟨subSum, restSums, hstart, hsub, hsums_eq, hrest⟩
      subst sums
      rcases replayNode_complete sub hsub with ⟨childRes, hchild, hchild_val⟩
      rcases childRes with ⟨cSum, hcPrf⟩
      dsimp at hchild_val
      subst cSum
      rcases replaySegs_complete nodeId restArgs hrest with ⟨subRes, hrec, hval⟩
      rcases subRes with ⟨⟨eP, sls, sms⟩, hprf⟩
      dsimp at hval
      injection hval with h1 h2
      injection h2 with h3 h4
      subst eP; subst sls; subst sms
      cases sub with
      | mkNode sNid sRc sSp sCl sArgs =>
        dsimp at hstart hrest hprf hrec
        refine ⟨⟨(endPos, slots, subSum :: restSums),
                ⟨subSum, restSums, hstart, hcPrf, rfl, hprf⟩⟩, ?_, rfl⟩
        unfold replaySegs
        dsimp
        rw [dif_pos hstart, hchild]
        dsimp
        rw [hrec]
    | [], _ :: _ => exact False.elim h
    | .lit _ :: _, [] => exact False.elim h
    | .slot _ _ :: _, [] => exact False.elim h
    | .child _ _ :: _, [] => exact False.elim h
    | .lit _ :: _, .slotLeaf _ :: _ => exact False.elim h
    | .lit _ :: _, .childNode _ :: _ => exact False.elim h
    | .slot _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .slot _ _ :: _, .childNode _ :: _ => exact False.elim h
    | .child _ _ :: _, .litSpan _ _ :: _ => exact False.elim h
    | .child _ _ :: _, .slotLeaf _ :: _ => exact False.elim h

  theorem replayNode_complete
      {env : ScopeEnv} {Y : List Char} {loc : ClauseLocus} {expectedCat : NontermCat}
      (cert : UntrustedDerivCert) {outSum : NodeSummary}
      (h : ValidNodeDeriv env Y loc expectedCat cert outSum) :
      ∃ nodeRes,
        replayNode env Y loc expectedCat cert = .ok nodeRes ∧
        nodeRes.1 = outSum := by
    cases cert with
    | mkNode nodeId rawCode sp claimed args =>
      rcases h with ⟨r, slots, sums, hrule, hcat, hsegs, hside, hlocus, hout⟩
      subst outSum
      rcases replaySegs_complete nodeId args hsegs with ⟨segRes, hseg_ok, hseg_val⟩
      rcases segRes with ⟨⟨eP, sls, sms⟩, hseg_prf⟩
      dsimp at hseg_val
      injection hseg_val with h1 h2
      injection h2 with h3 h4
      subst eP; subst sls; subst sms
      unfold replayNode
      split
      · rename_i hnone
        rw [hrule] at hnone
        contradiction
      · rename_i r' hsome
        have hr_eq : r' = r := by
          rw [hrule] at hsome
          injection hsome with h_eq
          exact h_eq.symm
        subst r'
        dsimp
        rw [dif_pos hcat, hseg_ok]
        dsimp
        rw [dif_pos rfl, dif_pos hside, dif_pos hlocus]
        exact ⟨_, rfl, rfl⟩
end

/--
  **Relative Completeness (`replayDerivation_complete`)**:
  Every derivation certificate satisfying `ValidGrammarDerivation` and `ObligationsConserved`
  is deterministically accepted by `replayDerivation` (confirming non-vacuity of `replayDerivation_sound`).
-/
theorem replayDerivation_complete
    (env : ScopeEnv) (Y : String) (deltaIn : List ObligationToken) (cert : UntrustedDerivCert)
    (hValid : ValidGrammarDerivation env Y cert)
    (hObl : ObligationsConserved cert deltaIn) :
    ∃ w : CertifiedDerivation env Y deltaIn,
      replayDerivation env Y deltaIn cert = .accepted w ∧ w.cert = cert := by
  cases cert with
  | mkNode nid rc rootSp cl args =>
    rcases hValid with ⟨hRootSp, sum, hNode⟩
    dsimp at hRootSp
    subst rootSp
    rcases hObl with ⟨hNoDupIn, hNoDupClaim, hMulti⟩
    have hInBool : checkNoDupOblIdsBool deltaIn = true :=
      (checkNoDupOblIdsBool_iff deltaIn).mpr hNoDupIn
    have hClaimBool :
        checkNoDupOblIdsBool (collectClaimedObls (.mkNode nid rc ⟨0, Y.toList.length⟩ cl args)) = true :=
      (checkNoDupOblIdsBool_iff _).mpr hNoDupClaim
    have hMultiBool :
        checkMultisetEqBool (collectClaimedObls (.mkNode nid rc ⟨0, Y.toList.length⟩ cl args)) deltaIn = true :=
      (checkMultisetEqBool_iff _ deltaIn).mpr hMulti
    rcases replayNode_complete (.mkNode nid rc ⟨0, Y.toList.length⟩ cl args) hNode with ⟨nodeRes, hNodeOk, _⟩
    unfold replayDerivation
    simp [hInBool, hNodeOk, hClaimBool, hMultiBool]

end BrocaOmega.P2
