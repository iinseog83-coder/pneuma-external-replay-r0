/-
  BROCA-NATIVE Ω — Gate C1-P1
  05_independent_tribunal/TribunalAudit.lean
  Compile-time `#print axioms` audit + executable `P1-D` adversarial / positive-control runner.
-/
import ProofObligations

open BrocaOmega.P1
open BrocaOmega.P1.Checker
open BrocaOmega.P1.Counterexamples
open BrocaOmega.P1.Obligations

-- Compile-time Axiom Footprint Audit (logged by Lean compiler during build):
#print axioms P1_ExactRat_CanonicalZero
#print axioms P1_ExactRat_ExtensionalUniqueness
#print axioms P1_ValidRoundAwz_Iff_RoundHalfAway
#print axioms P1_ValidRoundAwz_Iff_NearestIntMetric
#print axioms P1_ValidRoundAwz_Unique
#print axioms P1_RoundHalfAway_SignSymmetry
#print axioms P1_RoundHalfAway_ZeroCanonical
#print axioms P1_ExactHalfway_TiesAwayFromZero
#print axioms P1_DetachedGate_Sound
#print axioms P1_DetachedGate_Complete
#print axioms allP1TestCases_pass

def main : IO Unit := do
  IO.println "=== BROCA-NATIVE OMEGA : GATE C1-P1 TRIBUNAL AUDIT RUNNER ==="
  IO.println s!"Total P1-D Paired Cases: {allP1TestCases.length}"
  let mut passedCount : Nat := 0
  for tc in allP1TestCases do
    let ok := runSingleCase tc
    if ok then
      passedCount := passedCount + 1
    let actual := checkOutcomeTag tc.rawNum tc.rawDen tc.rawToken tc.expectedScale tc.maxScale
    IO.println s!"[{if ok then "PASS" else "FAIL"}] {tc.testId} ({tc.role}) | input=({tc.rawNum}/{tc.rawDen}, scale={tc.rawToken.scale10}, neg={tc.rawToken.negSign}, absM={tc.rawToken.absMantissa}) -> {repr actual}"
  IO.println s!"Summary: {passedCount}/{allP1TestCases.length} cases matched exact expected outcome."
  if passedCount == allP1TestCases.length then
    IO.println "P1_SUITE_EXECUTION_STATUS: ALL_20_CASES_MATCHED_EXACT_SPEC"
  else
    throw (IO.userError "P1 suite mismatch detected")
