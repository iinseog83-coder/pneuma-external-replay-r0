/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`Gate B` & `Gate C` Sealed Provenance Gate)
  02_detached_checker/P3CProvenanceChecker/SealedProvenanceGate.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`)

  Implements:
    1. `CertifiedSemanticConsensus (ctx : ProvenanceContext)` (`private mk ::`):
       Type-indexed proof-carrying consensus witness whose private constructor is reachable ONLY
       from an actual `.consensus` execution of `PneumaOmega.P3C.certifySemanticConsensus` on `ctx`!
    2. `mintCertifiedConsensus (ctx : ProvenanceContext) : ProvenanceMintOutcome ctx`:
       Total 5-way provenance-minting gate directly wrapping `certifySemanticConsensus` without
       duplicating `P3-C` normalization logic.
    3. `UntrustedConsensusClaim` & `verifyUntrustedConsensusClaim`:
       Detached deterministic whitebox replay verifier blocking all `A1`~`A5` external attacks
       (public `.consensus` forgery, canonical/tree substitution, raw-byte/scopeEnv substitution,
       budget/catalog/numCfg substitution, and failure-outcome laundering) with pinpoint diagnostics.
    4. Core Soundness, Input-Binding, Consensus-Preservation, Fail-Closed, Singleton-Uniqueness,
       Replay-Faithfulness, and Authority-Separation theorems (`PO-R1-01` ~ `PO-R1-06`).
-/
import P3CProvenanceSpec

namespace PneumaOmega.P3C.ProvenanceR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C

/-! ### 1. Sealed Proof-Carrying Semantic Consensus Type (`CertifiedSemanticConsensus` — `Gate B`) -/

/--
  **Sealed Proof-Carrying Semantic Consensus (`CertifiedSemanticConsensus ctx`)**:
  - Indexed by the exact 5-component `ctx : ProvenanceContext` (`catalog`, `numCfg`, `scopeEnv`, `budget`, `rawBytes`).
  - Sealed via `private mk ::` so external callers cannot invoke its constructor directly.
  - Carries the machine-checked execution-provenance witness `hExecProvenance` proving that
    `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` actually returned `.consensus trees canonical`!
  - Zero public mutators exist; moreover `certifiedSemanticConsensus_unique` proves that for any `ctx`,
    at most ONE `CertifiedSemanticConsensus ctx` value exists (`c₁ = c₂`)!
-/
structure CertifiedSemanticConsensus (ctx : ProvenanceContext) where
  private mk ::
  trees           : List ConcreteParseTree
  canonical       : CanonicalMeaning
  hExecProvenance :
    certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes =
      .consensus trees canonical
  deriving DecidableEq

/--
  **Proof-Irrelevant Canonical Uniqueness (`certifiedSemanticConsensus_unique`)**:
  Even if two `CertifiedSemanticConsensus ctx` witnesses exist for the same `ctx`, they are
  provably IDENTICAL (`c₁ = c₂`), preventing any internal field or proof substitution!
-/
theorem certifiedSemanticConsensus_unique {ctx : ProvenanceContext}
    (c₁ c₂ : CertifiedSemanticConsensus ctx) :
    c₁ = c₂ := by
  rcases c₁ with ⟨t1, m1, h1⟩
  rcases c₂ with ⟨t2, m2, h2⟩
  have heq : SemanticNormOutcome.consensus t1 m1 = SemanticNormOutcome.consensus t2 m2 :=
    h1.symm.trans h2
  injection heq with ht hm
  subst t2; subst m2
  rfl

/-! ### 2. Total 5-Way Minting Gate (`mintCertifiedConsensus`) -/

/--
  5-way outcome of `mintCertifiedConsensus ctx`:
  Mints `CertifiedSemanticConsensus ctx` ONLY on `.consensus`, and carries explicit negative
  execution-provenance proofs on all 4 failure branches!
-/
inductive ProvenanceMintOutcome (ctx : ProvenanceContext) where
  | admitted
      (cert : CertifiedSemanticConsensus ctx)
  | rejectedAmbiguous
      (trees   : List ConcreteParseTree)
      (witness : AmbiguityRefutationWitness)
      (hExec   : runP3COnContext ctx = .ambiguousReadings trees witness)
  | rejectedExtractionFailure
      (trees : List ConcreteParseTree)
      (err   : ForestExtractionError)
      (hExec : runP3COnContext ctx = .semanticExtractionFailure trees err)
  | rejectedTrapPolicy
      (trees     : List ConcreteParseTree)
      (candidate : CanonicalMeaning)
      (diag      : TrapPolicyDiag)
      (hExec     : runP3COnContext ctx = .trapPolicyRejected trees candidate diag)
  | rejectedUpstream
      (diag  : UpstreamParseDiag)
      (hExec : runP3COnContext ctx = .upstreamRejected diag)

/--
  **Primary Provenance-Minting Gate (`mintCertifiedConsensus`)**:
  Evaluates frozen `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` and mints the sealed
  `CertifiedSemanticConsensus ctx` iff `.consensus` is genuinely produced.
-/
def mintCertifiedConsensus (ctx : ProvenanceContext) : ProvenanceMintOutcome ctx :=
  match h : certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes with
  | .consensus T c                 => .admitted ⟨T, c, h⟩
  | .ambiguousReadings T w         => .rejectedAmbiguous T w h
  | .semanticExtractionFailure T e => .rejectedExtractionFailure T e h
  | .trapPolicyRejected T c d      => .rejectedTrapPolicy T c d h
  | .upstreamRejected d            => .rejectedUpstream d h

/-! ### 3. Detached Whitebox Replay Verifier Against `A1` ~ `A5` Untrusted Claims -/

/--
  Untrusted external claim submitted across a module/serialization boundary (`A1` ~ `A5` surface):
  Pairs a claimed `ProvenanceContext` with a raw public `SemanticNormOutcome`.
-/
structure UntrustedConsensusClaim where
  claimedCtx     : ProvenanceContext
  claimedOutcome : SemanticNormOutcome
  deriving DecidableEq

/-- Exports an authentic `CertifiedSemanticConsensus ctx` to an external claim bundle. -/
def exportUntrustedClaim {ctx : ProvenanceContext} (cert : CertifiedSemanticConsensus ctx) :
    UntrustedConsensusClaim :=
  { claimedCtx     := ctx
    claimedOutcome := .consensus cert.trees cert.canonical }

/-- Pinpoint rejection reasons mapped directly to Threat Vectors `A1` ~ `A5`. -/
inductive ProvenanceRejectReason where
  | rawBytesMismatch                                        -- `A3`: Input string/bytes tampered
  | scopeEnvMismatch                                        -- `A3`: `ScopeEnv` tampered
  | budgetMismatch                                          -- `A4`: `ResourceBudget` tampered
  | catalogMismatch                                         -- `A4`: `ClosedEntityCatalog` tampered
  | numCfgMismatch                                          -- `A4`: `NumericGateConfig` tampered
  | nonConsensusOutcomeSubmitted                            -- `A5`: Non-consensus outcome submitted
  | forgedConsensusOnAmbiguousInput                         -- `A1`/`A5`: Forged `.consensus` on `T1`/`T2`/`T4`
  | forgedConsensusOnExtractionFailure (d : ExtractionFailureDiag) -- `A1`/`A5`: Forged on extraction error
  | forgedConsensusOnTrapRejected      (d : TrapPolicyDiag) -- `A1`/`A5`: Forged on `T3`/`T5`/trap
  | forgedConsensusOnUpstreamRejected  (d : UpstreamParseDiag) -- `A1`/`A5`: Forged on OOD/Overflow/`[]`
  | substitutedCanonicalMeaning                             -- `A2`: Canonical meaning `c' ≠ c` substituted
  | substitutedParseForest                                  -- `A2`: Parse forest `T' ≠ T` substituted
  deriving DecidableEq, Repr

/-- Checks exact 5-field context match (`claimedCtx == targetCtx`) with pinpoint `A3`/`A4` diagnostics. -/
def checkContextMatch (targetCtx claimedCtx : ProvenanceContext) : Option ProvenanceRejectReason :=
  if !eqBytesBool targetCtx.rawBytes claimedCtx.rawBytes then
    some .rawBytesMismatch
  else if !eqScopeEnvBool targetCtx.scopeEnv claimedCtx.scopeEnv then
    some .scopeEnvMismatch
  else if !eqBudgetBool targetCtx.budget claimedCtx.budget then
    some .budgetMismatch
  else if !eqCatalogBool targetCtx.catalog claimedCtx.catalog then
    some .catalogMismatch
  else if !eqNumCfgBool targetCtx.numCfg claimedCtx.numCfg then
    some .numCfgMismatch
  else
    none

theorem checkContextMatch_none_iff (targetCtx claimedCtx : ProvenanceContext) :
    checkContextMatch targetCtx claimedCtx = none ↔ claimedCtx = targetCtx := by
  cases targetCtx with
  | mk cat1 num1 env1 bud1 bs1 =>
    cases claimedCtx with
    | mk cat2 num2 env2 bud2 bs2 =>
      unfold checkContextMatch
      dsimp only
      by_cases hbs : eqBytesBool bs1 bs2 = true
      · rw [hbs]
        by_cases henv : eqScopeEnvBool env1 env2 = true
        · rw [henv]
          by_cases hbud : eqBudgetBool bud1 bud2 = true
          · rw [hbud]
            by_cases hcat : eqCatalogBool cat1 cat2 = true
            · rw [hcat]
              by_cases hnum : eqNumCfgBool num1 num2 = true
              · rw [hnum]
                have e1 := ((eqBytesBool_iff _ _).mp hbs).symm
                have e2 := ((eqScopeEnvBool_iff _ _).mp henv).symm
                have e3 := ((eqBudgetBool_iff _ _).mp hbud).symm
                have e4 := ((eqCatalogBool_iff _ _).mp hcat).symm
                have e5 := ((eqNumCfgBool_iff _ _).mp hnum).symm
                subst bs2; subst env2; subst bud2; subst cat2; subst num2
                simp
              · have hnf : eqNumCfgBool num1 num2 = false := Bool.eq_false_iff.mpr hnum
                rw [hnf]; simp
                rintro _ rfl; exact False.elim (hnum ((eqNumCfgBool_iff _ _).mpr rfl))
            · have hcf : eqCatalogBool cat1 cat2 = false := Bool.eq_false_iff.mpr hcat
              rw [hcf]; simp
              rintro rfl; exact False.elim (hcat ((eqCatalogBool_iff _ _).mpr rfl))
          · have hbf : eqBudgetBool bud1 bud2 = false := Bool.eq_false_iff.mpr hbud
            rw [hbf]; simp
            rintro rfl rfl rfl rfl; exact False.elim (hbud ((eqBudgetBool_iff _ _).mpr rfl))
        · have hef : eqScopeEnvBool env1 env2 = false := Bool.eq_false_iff.mpr henv
          rw [hef]; simp
          rintro rfl rfl rfl; exact False.elim (henv ((eqScopeEnvBool_iff _ _).mpr rfl))
      · have hbsf : eqBytesBool bs1 bs2 = false := Bool.eq_false_iff.mpr hbs
        rw [hbsf]; simp
        rintro rfl rfl rfl rfl rfl
        exact hbs ((eqBytesBool_iff _ _).mpr rfl)

/--
  Pure non-dependent whitebox claim checker (`verifyClaimPure`) for zero-overhead kernel WHNF
  evaluation, paired with the proof-carrying `verifyUntrustedConsensusClaim` gate below.
-/
def verifyClaimPure (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim) :
    Except ProvenanceRejectReason (List ConcreteParseTree × CanonicalMeaning) :=
  match checkContextMatch targetCtx claim.claimedCtx with
  | some reason => .error reason
  | none =>
    match claim.claimedOutcome with
    | .consensus claimedTrees claimedCanon =>
      match certifySemanticConsensus targetCtx.catalog targetCtx.numCfg targetCtx.scopeEnv
              targetCtx.budget targetCtx.rawBytes with
      | .ambiguousReadings _ _           => .error .forgedConsensusOnAmbiguousInput
      | .semanticExtractionFailure _ err => .error (.forgedConsensusOnExtractionFailure err.diag)
      | .trapPolicyRejected _ _ d        => .error (.forgedConsensusOnTrapRejected d)
      | .upstreamRejected d              => .error (.forgedConsensusOnUpstreamRejected d)
      | .consensus actualTrees actualCanon =>
        if !canonicalMeaningEqBool actualCanon claimedCanon then
          .error .substitutedCanonicalMeaning
        else if !parseTreeListEqBool actualTrees claimedTrees then
          .error .substitutedParseForest
        else
          .ok (actualTrees, actualCanon)
    | _ => .error .nonConsensusOutcomeSubmitted

/--
  Forest-level whitebox consensus verifier (`verifyForestConsensusPure`):
  Directly checks an untrusted `(targetForest, claimedCanon)` pair against `P3-C`'s `evalForestPure`,
  pinpointing `forgedConsensusOnExtractionFailure` on malformed/bad-anchor parse trees (`A5c`).
-/
def verifyForestConsensusPure (env : ScopeEnv) (targetForest : List ConcreteParseTree)
    (claimedCanon : CanonicalMeaning) : Except ProvenanceRejectReason CanonicalMeaning :=
  match evalForestPure env targetForest with
  | .ambiguousReadings _ _           => .error .forgedConsensusOnAmbiguousInput
  | .semanticExtractionFailure _ err => .error (.forgedConsensusOnExtractionFailure err.diag)
  | .trapPolicyRejected _ _ d        => .error (.forgedConsensusOnTrapRejected d)
  | .upstreamRejected d              => .error (.forgedConsensusOnUpstreamRejected d)
  | .consensus _ actualCanon =>
    if !canonicalMeaningEqBool actualCanon claimedCanon then
      .error .substitutedCanonicalMeaning
    else
      .ok actualCanon

/--
  **Detached Whitebox Replay Verifier (`verifyUntrustedConsensusClaim` — `Gate B` / `PO-R1-06`)**:
  Independently verifies that `claim.claimedCtx = targetCtx`, recomputes `certifySemanticConsensus`
  on `targetCtx`, verifies exact equality of `claimedCanon` and `claimedTrees`, and returns a
  sealed `CertifiedSemanticConsensus targetCtx` iff every check succeeds!
-/
def verifyUntrustedConsensusClaim (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim) :
    Except ProvenanceRejectReason (CertifiedSemanticConsensus targetCtx) :=
  match checkContextMatch targetCtx claim.claimedCtx with
  | some reason => .error reason
  | none =>
    match claim.claimedOutcome with
    | .consensus claimedTrees claimedCanon =>
      match h : certifySemanticConsensus targetCtx.catalog targetCtx.numCfg targetCtx.scopeEnv
                  targetCtx.budget targetCtx.rawBytes with
      | .ambiguousReadings _ _           => .error .forgedConsensusOnAmbiguousInput
      | .semanticExtractionFailure _ err => .error (.forgedConsensusOnExtractionFailure err.diag)
      | .trapPolicyRejected _ _ d        => .error (.forgedConsensusOnTrapRejected d)
      | .upstreamRejected d              => .error (.forgedConsensusOnUpstreamRejected d)
      | .consensus actualTrees actualCanon =>
        if !canonicalMeaningEqBool actualCanon claimedCanon then
          .error .substitutedCanonicalMeaning
        else if !parseTreeListEqBool actualTrees claimedTrees then
          .error .substitutedParseForest
        else
          .ok ⟨actualTrees, actualCanon, h⟩
    | _ => .error .nonConsensusOutcomeSubmitted

theorem verifyUntrustedConsensusClaim_proj_eq (targetCtx : ProvenanceContext)
    (claim : UntrustedConsensusClaim) :
    (verifyUntrustedConsensusClaim targetCtx claim).map (fun c => (c.trees, c.canonical)) =
      verifyClaimPure targetCtx claim := by
  unfold verifyUntrustedConsensusClaim verifyClaimPure
  cases checkContextMatch targetCtx claim.claimedCtx with
  | some _ => rfl
  | none =>
    cases claim.claimedOutcome with
    | ambiguousReadings _ _ => rfl
    | semanticExtractionFailure _ _ => rfl
    | trapPolicyRejected _ _ _ => rfl
    | upstreamRejected _ => rfl
    | consensus ct cc =>
      dsimp only
      split
      · rename_i _ _ heq; rw [heq]; rfl
      · rename_i _ _ heq; rw [heq]; rfl
      · rename_i _ _ _ heq; rw [heq]; rfl
      · rename_i _ heq; rw [heq]; rfl
      · rename_i atrees acanon heq
        conv => rhs; rw [heq]
        dsimp only
        by_cases hc : (!canonicalMeaningEqBool acanon cc) = true
        · rw [if_pos hc, if_pos hc]; rfl
        · rw [if_neg hc, if_neg hc]
          by_cases ht : (!parseTreeListEqBool atrees ct) = true
          · rw [if_pos ht, if_pos ht]; rfl
          · rw [if_neg ht, if_neg ht]; rfl

/-! ### 4. Core `Gate C` Theorems (`PO-R1-01` ~ `PO-R1-06`) -/

/--
  **Theorem `PO-R1-01` (`construction_soundness`)**:
  Any inhabitant `cert : CertifiedSemanticConsensus ctx` guarantees that executing actual frozen
  `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` returns `.consensus cert.trees cert.canonical`,
  and `mintCertifiedConsensus ctx` returns `.admitted cert`!
-/
theorem construction_soundness (ctx : ProvenanceContext) (cert : CertifiedSemanticConsensus ctx) :
    ExecProvenanceSpec ctx cert.trees cert.canonical ∧
    mintCertifiedConsensus ctx = .admitted cert := by
  refine ⟨cert.hExecProvenance, ?_⟩
  unfold mintCertifiedConsensus
  split
  · rename_i T0 c0 h0
    have heq : CertifiedSemanticConsensus.mk T0 c0 h0 = cert :=
      certifiedSemanticConsensus_unique _ _
    rw [heq]
  · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
  · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
  · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
  · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction

/--
  **Theorem `PO-R1-02a` (`input_binding_replay_rejects_context_mismatch`)**:
  Whenever `claim.claimedCtx ≠ targetCtx` (whether `rawBytes`, `scopeEnv`, `budget`, `catalog`,
  or `numCfg` differs), `verifyUntrustedConsensusClaim targetCtx claim` deterministically REJECTS!
-/
theorem input_binding_replay_rejects_context_mismatch
    (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim)
    (hne : claim.claimedCtx ≠ targetCtx) :
    ∃ reason : ProvenanceRejectReason,
      verifyUntrustedConsensusClaim targetCtx claim = .error reason := by
  unfold verifyUntrustedConsensusClaim
  cases hcm : checkContextMatch targetCtx claim.claimedCtx with
  | some r => exact ⟨r, rfl⟩
  | none =>
    have heq := (checkContextMatch_none_iff targetCtx claim.claimedCtx).mp hcm
    exact False.elim (hne heq)

/--
  **Theorem `PO-R1-03` (`consensus_preservation_sound`)**:
  Every `cert : CertifiedSemanticConsensus ctx` entails the full `DeclarativeConsensusContract`:
  bounded exhaustive `P3-B` parse set, `T ≠ []`, `NoDupTrees`, `TrapPolicyPermitsForest`,
  `IsCanonicalNorm`, universal reading `SemEq` equivalence, AND relative `Denotes` preservation
  under `ExtensionalContrastiveWorld W` (explicitly preserving `ExtensionalContrastiveWorld`!).
-/
theorem consensus_preservation_sound (ctx : ProvenanceContext)
    (cert : CertifiedSemanticConsensus ctx) :
    DeclarativeConsensusContract ctx cert.trees cert.canonical := by
  have ⟨hp, hsup, hne, hnodup, hexact, htrap, hcanon, ⟨pairs, hext, hmap, hcons, hall⟩⟩ :=
    certifySemanticConsensus_sound ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes
      cert.trees cert.canonical cert.hExecProvenance
  refine ⟨hp, hsup, hne, hnodup, hexact, htrap, hcanon, ⟨pairs, hext, hmap, hcons, ?_⟩⟩
  intro p hp_mem
  rcases hall p hp_mem with ⟨hext_p, hsem_p⟩
  refine ⟨hext_p, hsem_p, ?_⟩
  intro W hExtW
  exact semEq_sound_for_denotes hsem_p W hExtW

/--
  **Theorem `PO-R1-04` (`fail_closed_all_non_consensus_outcomes`)**:
  Whenever `certifySemanticConsensus` on `ctx` returns ANY of the 4 non-consensus outcomes
  (`.ambiguousReadings`, `.semanticExtractionFailure`, `.trapPolicyRejected`, `.upstreamRejected`),
  `CertifiedSemanticConsensus ctx` is **mathematically uninhabited (`CertifiedSemanticConsensus ctx → False`)**,
  AND `verifyUntrustedConsensusClaim ctx claim` rejects EVERY untrusted `claim`!
-/
theorem fail_closed_all_non_consensus_outcomes (ctx : ProvenanceContext) :
    ((∀ T w, runP3COnContext ctx = .ambiguousReadings T w →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ T e, runP3COnContext ctx = .semanticExtractionFailure T e →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ T c d, runP3COnContext ctx = .trapPolicyRejected T c d →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ d, runP3COnContext ctx = .upstreamRejected d →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r))) := by
  have helper :
      (∀ T c, runP3COnContext ctx ≠ .consensus T c) →
      (CertifiedSemanticConsensus ctx → False) ∧
      (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r) := by
    intro hno
    refine ⟨?_, ?_⟩
    · intro cert
      exact hno cert.trees cert.canonical cert.hExecProvenance
    · intro cl
      unfold verifyUntrustedConsensusClaim
      cases checkContextMatch ctx cl.claimedCtx with
      | some r => exact ⟨r, rfl⟩
      | none =>
        cases cl.claimedOutcome with
        | ambiguousReadings _ _ => exact ⟨.nonConsensusOutcomeSubmitted, rfl⟩
        | semanticExtractionFailure _ _ => exact ⟨.nonConsensusOutcomeSubmitted, rfl⟩
        | trapPolicyRejected _ _ _ => exact ⟨.nonConsensusOutcomeSubmitted, rfl⟩
        | upstreamRejected _ => exact ⟨.nonConsensusOutcomeSubmitted, rfl⟩
        | consensus ct cc =>
          dsimp only
          split
          · exact ⟨.forgedConsensusOnAmbiguousInput, rfl⟩
          · rename_i err _; exact ⟨.forgedConsensusOnExtractionFailure err.diag, rfl⟩
          · rename_i d _; exact ⟨.forgedConsensusOnTrapRejected d, rfl⟩
          · rename_i d _; exact ⟨.forgedConsensusOnUpstreamRejected d, rfl⟩
          · rename_i atrees acanon hcon
            exact False.elim (hno atrees acanon hcon)
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro T w h; apply helper; intro T' c' hc; rw [h] at hc; contradiction
  · intro T e h; apply helper; intro T' c' hc; rw [h] at hc; contradiction
  · intro T c d h; apply helper; intro T' c' hc; rw [h] at hc; contradiction
  · intro d h; apply helper; intro T' c' hc; rw [h] at hc; contradiction

/--
  **Theorem `PO-R1-05` (`no_authority_escalation_to_P4_or_P5`)**:
  1. `P4ClinicalTruthCert` and `P5FinalCertifiedOutput` remain uninhabited (`NOT_AUTHORIZED`), so
     no function `CertifiedSemanticConsensus ctx → P5FinalCertifiedOutput` can ever produce a `P5` output.
  2. Even for an inhabited `cert : CertifiedSemanticConsensus ctx` whose canonical meaning is a
     descriptive `G-01` incidence claim, there exist extensional clinical worlds `(W_true, W_false)`
     where `Denotes W_true` holds while `¬ Denotes W_false` — proving `CertifiedSemanticConsensus`
     certifies **provenance of linguistic consensus ONLY**, never clinical/empirical truth!
-/
theorem no_authority_escalation_to_P4_or_P5
    (ctx : ProvenanceContext) (cert : CertifiedSemanticConsensus ctx)
    (coh win ev k n pct : String)
    (hCanon : cert.canonical =
      normalizeMeaning (.scopedAtom (.cohortBound coh) "x_init" (.descIncidence win ev k n pct) [])) :
    (P5FinalCertifiedOutput → False) ∧
    (P4ClinicalTruthCert cert.canonical → False) ∧
    (∃ (W_true W_false : SemanticWorld),
       ExtensionalContrastiveWorld W_true ∧
       ExtensionalContrastiveWorld W_false ∧
       Denotes W_true (embedCanonical cert.canonical) ∧
       ¬ Denotes W_false (embedCanonical cert.canonical)) := by
  refine ⟨p5FinalCertifiedOutput_uninhabited, p4ClinicalTruthCert_uninhabited cert.canonical, ?_⟩
  rw [hCanon]
  exact consensus_does_not_certify_empirical_truth coh win ev k n pct

/--
  **Theorem `PO-R1-06` (`replay_faithfulness_iff`)**:
  Exact two-way correspondence between `CertifiedSemanticConsensus` and `verifyUntrustedConsensusClaim`:
  1. **Soundness**: `verifyUntrustedConsensusClaim targetCtx claim = .ok cert` implies
     `claim = exportUntrustedClaim cert`, `ExecProvenanceSpec targetCtx cert.trees cert.canonical`,
     and `mintCertifiedConsensus targetCtx = .admitted cert`.
  2. **Completeness**: For every authentic `cert : CertifiedSemanticConsensus targetCtx`,
     `verifyUntrustedConsensusClaim targetCtx (exportUntrustedClaim cert) = .ok cert`!
-/
theorem replay_faithfulness_iff (targetCtx : ProvenanceContext) :
    (∀ (claim : UntrustedConsensusClaim) (cert : CertifiedSemanticConsensus targetCtx),
       verifyUntrustedConsensusClaim targetCtx claim = .ok cert →
       claim = exportUntrustedClaim cert ∧
       ExecProvenanceSpec targetCtx cert.trees cert.canonical ∧
       mintCertifiedConsensus targetCtx = .admitted cert) ∧
    (∀ (cert : CertifiedSemanticConsensus targetCtx),
       verifyUntrustedConsensusClaim targetCtx (exportUntrustedClaim cert) = .ok cert) := by
  refine ⟨?_, ?_⟩
  · intro claim cert hok
    rcases claim with ⟨cCtx, cOut⟩
    unfold verifyUntrustedConsensusClaim at hok
    dsimp only at hok
    cases hcm : checkContextMatch targetCtx cCtx with
    | some _ => rw [hcm] at hok; contradiction
    | none =>
      rw [hcm] at hok
      have hctx_eq : cCtx = targetCtx := (checkContextMatch_none_iff targetCtx cCtx).mp hcm
      subst cCtx
      cases cOut with
      | ambiguousReadings _ _ => contradiction
      | semanticExtractionFailure _ _ => contradiction
      | trapPolicyRejected _ _ _ => contradiction
      | upstreamRejected _ => contradiction
      | consensus ct cc =>
        dsimp only at hok
        split at hok
        · contradiction
        · contradiction
        · contradiction
        · contradiction
        · rename_i atrees acanon hexec
          by_cases hc : (!canonicalMeaningEqBool acanon cc) = true
          · rw [if_pos hc] at hok; contradiction
          · rw [if_neg hc] at hok
            by_cases ht : (!parseTreeListEqBool atrees ct) = true
            · rw [if_pos ht] at hok; contradiction
            · rw [if_neg ht] at hok
              injection hok with hcert
              subst cert
              have hc_true : canonicalMeaningEqBool acanon cc = true :=
                by cases hb : canonicalMeaningEqBool acanon cc <;> simp_all
              have ht_true : parseTreeListEqBool atrees ct = true :=
                by cases hb : parseTreeListEqBool atrees ct <;> simp_all
              have hcc : acanon = cc := (canonicalMeaningEqBool_iff _ _).mp hc_true
              have hct : atrees = ct := (parseTreeListEqBool_iff _ _).mp ht_true
              subst cc; subst ct
              have ⟨hex, hmint⟩ := construction_soundness targetCtx ⟨atrees, acanon, hexec⟩
              exact ⟨rfl, hex, hmint⟩
  · intro cert
    unfold verifyUntrustedConsensusClaim exportUntrustedClaim
    dsimp only
    have hcm : checkContextMatch targetCtx targetCtx = none :=
      (checkContextMatch_none_iff targetCtx targetCtx).mpr rfl
    rw [hcm]
    dsimp only
    split
    · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
    · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
    · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
    · rename_i h0; rw [cert.hExecProvenance] at h0; contradiction
    · rename_i atrees acanon h0
      have heq_out : SemanticNormOutcome.consensus cert.trees cert.canonical =
                     SemanticNormOutcome.consensus atrees acanon :=
        cert.hExecProvenance.symm.trans h0
      injection heq_out with ht hc
      subst atrees; subst acanon
      have hcb : canonicalMeaningEqBool cert.canonical cert.canonical = true :=
        (canonicalMeaningEqBool_iff _ _).mpr rfl
      have htb : parseTreeListEqBool cert.trees cert.trees = true :=
        (parseTreeListEqBool_iff _ _).mpr rfl
      rw [hcb, htb]
      exact congrArg Except.ok (certifiedSemanticConsensus_unique _ _)

end PneumaOmega.P3C.ProvenanceR1
