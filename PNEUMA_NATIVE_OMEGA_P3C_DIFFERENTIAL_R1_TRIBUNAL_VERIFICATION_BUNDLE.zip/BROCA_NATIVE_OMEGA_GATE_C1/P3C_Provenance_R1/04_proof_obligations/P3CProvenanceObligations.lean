/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1
  Root export for `P3CProvenanceObligations`
-/
import P3CProvenanceObligations.PO_R1_01_To_07
