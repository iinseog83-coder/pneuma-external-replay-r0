/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`Gate C`: Canonical Proof Obligations `PO-R1-01` ~ `PO-R1-07`)
  04_proof_obligations/P3CProvenanceObligations/PO_R1_01_To_07.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`, zero `native_decide`)

  Exports the seven standalone machine-checked theorems mandated by `Gate C`:
    - `PO_R1_01_ConstructionSoundness`
    - `PO_R1_02_InputBinding`
    - `PO_R1_03_ConsensusPreservation`
    - `PO_R1_04_FailClosed`
    - `PO_R1_05_NoAuthorityEscalation`
    - `PO_R1_06_ReplayFaithfulness`
    - `PO_R1_07_ProvenanceNonVacuity`
  Plus `PO_R1_All24AttackVectorsVerified` and explicit governance/scope boundary lock `R1GovernanceStatus`.
-/
import P3CProvenanceAttacks

namespace PneumaOmega.P3C.ProvenanceR1.Obligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

/-! ### `PO-R1-01` — Construction Soundness -/

/--
  **`PO-R1-01` (`Construction Soundness`)**:
  Every inhabitant `cert : CertifiedSemanticConsensus ctx` guarantees that executing actual frozen
  `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` produces `.consensus cert.trees cert.canonical`,
  that `mintCertifiedConsensus ctx = .admitted cert`, and that `cert` is the unique witness for `ctx`.
-/
theorem PO_R1_01_ConstructionSoundness (ctx : ProvenanceContext)
    (cert : CertifiedSemanticConsensus ctx) :
    certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes =
      .consensus cert.trees cert.canonical ∧
    mintCertifiedConsensus ctx = .admitted cert ∧
    (∀ cert' : CertifiedSemanticConsensus ctx, cert' = cert) := by
  have ⟨hexec, hmint⟩ := construction_soundness ctx cert
  exact ⟨hexec, hmint, fun cert' => certifiedSemanticConsensus_unique cert' cert⟩

/-! ### `PO-R1-02` — Input Binding (All 5 Context Components + Header-Spoof Protection) -/

/--
  **`PO-R1-02` (`Input Binding`)**:
  1. Any mismatch between `claim.claimedCtx` and `targetCtx` (across `rawBytes`, `scopeEnv`, `budget`,
     `catalog`, or `numCfg`) causes `verifyUntrustedConsensusClaim targetCtx claim` to reject.
  2. In particular, exporting an authentic `cert : CertifiedSemanticConsensus ctx₁` and replaying it
     against ANY distinct `ctx₂ ≠ ctx₁` is deterministically rejected.
  3. Even if an attacker overwrites `claimedCtx := ctx₂` while transplanting `(cert.trees, cert.canonical)`
     from `ctx₁`, `verifyUntrustedConsensusClaim ctx₂` admits ONLY if `certifySemanticConsensus` on `ctx₂`
     itself genuinely produces the exact same `.consensus cert.trees cert.canonical`!
-/
theorem PO_R1_02_InputBinding :
    (∀ (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim),
       claim.claimedCtx ≠ targetCtx →
       ∃ r : ProvenanceRejectReason, verifyUntrustedConsensusClaim targetCtx claim = .error r) ∧
    (∀ {ctx₁ ctx₂ : ProvenanceContext} (cert₁ : CertifiedSemanticConsensus ctx₁),
       ctx₁ ≠ ctx₂ →
       ∃ r : ProvenanceRejectReason,
         verifyUntrustedConsensusClaim ctx₂ (exportUntrustedClaim cert₁) = .error r) ∧
    (∀ {ctx₁ ctx₂ : ProvenanceContext} (cert₁ : CertifiedSemanticConsensus ctx₁)
       (cert₂ : CertifiedSemanticConsensus ctx₂),
       verifyUntrustedConsensusClaim ctx₂
         { claimedCtx := ctx₂, claimedOutcome := .consensus cert₁.trees cert₁.canonical } = .ok cert₂ →
       ExecProvenanceSpec ctx₂ cert₁.trees cert₁.canonical ∧
       cert₂.trees = cert₁.trees ∧
       cert₂.canonical = cert₁.canonical) := by
  refine ⟨input_binding_replay_rejects_context_mismatch, ?_, ?_⟩
  · intro ctx₁ ctx₂ cert₁ hne
    exact input_binding_replay_rejects_context_mismatch ctx₂ (exportUntrustedClaim cert₁) hne
  · intro ctx₁ ctx₂ cert₁ cert₂ hok
    have ⟨hcl, hexec₂, _⟩ := (replay_faithfulness_iff ctx₂).1
      { claimedCtx := ctx₂, claimedOutcome := .consensus cert₁.trees cert₁.canonical } cert₂ hok
    unfold exportUntrustedClaim at hcl
    injection hcl with _ hout
    injection hout with ht hc
    rw [← ht, ← hc] at hexec₂
    exact ⟨hexec₂, ht.symm, hc.symm⟩

/-! ### `PO-R1-03` — Consensus Preservation (Explicitly Retaining `ExtensionalContrastiveWorld`) -/

/--
  **`PO-R1-03` (`Consensus Preservation`)**:
  Every `cert : CertifiedSemanticConsensus ctx` entails the full declarative consensus contract,
  including bounded exhaustive `P3-B` parsing, `TrapPolicyPermitsForest`, `IsCanonicalNorm`,
  universal reading `SemEq`, AND relative `Denotes` preservation across all `W` satisfying
  `ExtensionalContrastiveWorld W` (`Mandate §PO-R1-03`: never dropping `ExtensionalContrastiveWorld`).
-/
theorem PO_R1_03_ConsensusPreservation (ctx : ProvenanceContext)
    (cert : CertifiedSemanticConsensus ctx) :
    DeclarativeConsensusContract ctx cert.trees cert.canonical :=
  consensus_preservation_sound ctx cert

/-! ### `PO-R1-04` — Fail-Closed Across All 4 Non-Consensus Outcomes -/

/--
  **`PO-R1-04` (`Fail-Closed`)**:
  Whenever `certifySemanticConsensus` on `ctx` returns `.ambiguousReadings`,
  `.semanticExtractionFailure`, `.trapPolicyRejected`, or `.upstreamRejected`,
  `CertifiedSemanticConsensus ctx` is uninhabited (`→ False`) AND `verifyUntrustedConsensusClaim ctx`
  rejects EVERY untrusted claim `cl`!
-/
theorem PO_R1_04_FailClosed (ctx : ProvenanceContext) :
    ((∀ T w, runP3COnContext ctx = .ambiguousReadings T w →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ T e, runP3COnContext ctx = .semanticExtractionFailure T e →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ T c d, runP3COnContext ctx = .trapPolicyRejected T c d →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r)) ∧
     (∀ d, runP3COnContext ctx = .upstreamRejected d →
        (CertifiedSemanticConsensus ctx → False) ∧
        (∀ cl, ∃ r, verifyUntrustedConsensusClaim ctx cl = .error r))) :=
  fail_closed_all_non_consensus_outcomes ctx

/-! ### `PO-R1-05` — No Authority Escalation to `P4` Clinical Truth or `P5` Final Admission -/

/--
  **`PO-R1-05` (`No Authority Escalation`)**:
  1. `P5FinalCertifiedOutput` and `P4ClinicalTruthCert c` are uninhabited (`NOT_AUTHORIZED`).
  2. Even for our concrete inhabited `certG01 : CertifiedSemanticConsensus ctxG01`, there exist
     two admissible extensional clinical worlds `(W_true, W_false)` such that `certG01.canonical`
     denotes `True` in `W_true` and `False` in `W_false` — proving `CertifiedSemanticConsensus`
     certifies linguistic consensus provenance ONLY, never empirical truth!
-/
theorem PO_R1_05_NoAuthorityEscalation :
    (P5FinalCertifiedOutput → False) ∧
    (∀ c : CanonicalMeaning, P4ClinicalTruthCert c → False) ∧
    (∃ (W_true W_false : SemanticWorld),
       ExtensionalContrastiveWorld W_true ∧
       ExtensionalContrastiveWorld W_false ∧
       Denotes W_true (embedCanonical certG01.canonical) ∧
       ¬ Denotes W_false (embedCanonical certG01.canonical)) := by
  have ⟨hp5, _, hworlds⟩ := no_authority_escalation_to_P4_or_P5 ctxG01 certG01
    "coh_primary" "win_12m" "ev_stroke" "42" "500" "8.4" certG01_canonical_eq
  exact ⟨hp5, p4ClinicalTruthCert_uninhabited, hworlds⟩

/-! ### `PO-R1-06` — Replay Faithfulness (Exact Two-Way Correspondence) -/

/--
  **`PO-R1-06` (`Replay Faithfulness`)**:
  1. For any `cert : CertifiedSemanticConsensus targetCtx`,
     `verifyUntrustedConsensusClaim targetCtx claim = .ok cert ↔ claim = exportUntrustedClaim cert`.
  2. Existential replay characterization: `(∃ cert, verifyUntrustedConsensusClaim targetCtx claim = .ok cert)`
     holds iff `claim = { claimedCtx := targetCtx, claimedOutcome := .consensus T c }` where
     `ExecProvenanceSpec targetCtx T c` holds!
-/
theorem PO_R1_06_ReplayFaithfulness (targetCtx : ProvenanceContext) :
    (∀ (claim : UntrustedConsensusClaim) (cert : CertifiedSemanticConsensus targetCtx),
       verifyUntrustedConsensusClaim targetCtx claim = .ok cert ↔
         claim = exportUntrustedClaim cert) ∧
    (∀ (claim : UntrustedConsensusClaim),
       (∃ cert : CertifiedSemanticConsensus targetCtx,
          verifyUntrustedConsensusClaim targetCtx claim = .ok cert) ↔
       (∃ (T : List ConcreteParseTree) (c : CanonicalMeaning),
          claim = { claimedCtx := targetCtx, claimedOutcome := .consensus T c } ∧
          ExecProvenanceSpec targetCtx T c)) := by
  have ⟨hsound, hcomp⟩ := replay_faithfulness_iff targetCtx
  refine ⟨?_, ?_⟩
  · intro claim cert
    constructor
    · intro hok
      exact (hsound claim cert hok).1
    · intro hcl
      rw [hcl]
      exact hcomp cert
  · intro claim
    constructor
    · rintro ⟨cert, hok⟩
      have ⟨hcl, hexec, _⟩ := hsound claim cert hok
      exact ⟨cert.trees, cert.canonical, hcl, hexec⟩
    · rintro ⟨T, c, hcl, hexec⟩
      cases hm : mintCertifiedConsensus targetCtx with
      | admitted cert =>
        have hcon : SemanticNormOutcome.consensus cert.trees cert.canonical =
                    SemanticNormOutcome.consensus T c :=
          cert.hExecProvenance.symm.trans hexec
        injection hcon with ht hc
        have hexp : claim = exportUntrustedClaim cert := by
          rw [hcl]
          unfold exportUntrustedClaim
          rw [ht, hc]
        refine ⟨cert, ?_⟩
        rw [hexp]
        exact hcomp cert
      | rejectedAmbiguous _ _ h0 =>
        unfold ExecProvenanceSpec at hexec; unfold runP3COnContext at h0
        rw [hexec] at h0; contradiction
      | rejectedExtractionFailure _ _ h0 =>
        unfold ExecProvenanceSpec at hexec; unfold runP3COnContext at h0
        rw [hexec] at h0; contradiction
      | rejectedTrapPolicy _ _ _ h0 =>
        unfold ExecProvenanceSpec at hexec; unfold runP3COnContext at h0
        rw [hexec] at h0; contradiction
      | rejectedUpstream _ h0 =>
        unfold ExecProvenanceSpec at hexec; unfold runP3COnContext at h0
        rw [hexec] at h0; contradiction

/-! ### `PO-R1-07` — Provenance Non-Vacuity on Concrete `G`-Series Witnesses -/

/--
  **`PO-R1-07` (`Provenance Non-Vacuity`)**:
  Concrete `G`-series witnesses (`ctxG01`, `ctxG11`, `ctxG15a`, `ctxG15b`) constructively inhabit
  `CertifiedSemanticConsensus` via the public `mintCertifiedConsensus` gate, round-trip `.ok`
  through `verifyUntrustedConsensusClaim`, exhibit `G-15a`/`G-15b` paraphrase convergence, and
  enforce strict cross-input rejection (`ctxG01 → ctxG11`)!
-/
theorem PO_R1_07_ProvenanceNonVacuity :
    ∃ (c01 : CertifiedSemanticConsensus ctxG01)
      (c11 : CertifiedSemanticConsensus ctxG11)
      (c15a : CertifiedSemanticConsensus ctxG15a)
      (c15b : CertifiedSemanticConsensus ctxG15b),
      mintCertifiedConsensus ctxG01 = .admitted c01 ∧
      mintCertifiedConsensus ctxG11 = .admitted c11 ∧
      mintCertifiedConsensus ctxG15a = .admitted c15a ∧
      mintCertifiedConsensus ctxG15b = .admitted c15b ∧
      verifyUntrustedConsensusClaim ctxG01 (exportUntrustedClaim c01) = .ok c01 ∧
      verifyUntrustedConsensusClaim ctxG15b (exportUntrustedClaim c15b) = .ok c15b ∧
      c01.canonical = expectedCanonG01 ∧
      c15a.canonical = c15b.canonical ∧
      (∃ r : ProvenanceRejectReason,
         verifyUntrustedConsensusClaim ctxG11 (exportUntrustedClaim c01) = .error r) := by
  refine ⟨certG01, certG11, certG15a, certG15b,
          (construction_soundness ctxG01 certG01).2,
          (construction_soundness ctxG11 certG11).2,
          (construction_soundness ctxG15a certG15a).2,
          (construction_soundness ctxG15b certG15b).2,
          (replay_faithfulness_iff ctxG01).2 certG01,
          (replay_faithfulness_iff ctxG15b).2 certG15b,
          certG01_canonical_eq,
          certG15_paraphrase_convergence,
          ?_⟩
  have hne : ctxG01 ≠ ctxG11 := by decide
  exact input_binding_replay_rejects_context_mismatch ctxG11 (exportUntrustedClaim certG01) hne

/-! ### `Gate D` Master Suite Theorem & Explicit Scope/Authority Status Lock -/

theorem PO_R1_All24AttackVectorsVerified :
    allR1AttackCases.length = 24 ∧
    ∀ c ∈ allR1AttackCases, c.passed = true ∧ c.actualVerdict = c.expectedVerdict :=
  allR1AttackCases_pass

/--
  Explicit Governance & Scope Boundary Record (`Mandate §2, §4, & §Gate F`):
  Preserves `P3-C`'s `AUTHORIZATION_QUALIFIED` classification unchanged, keeps `F-P3C-02`
  held for a separate future act, keeps out-of-kernel binary/memory tamper `HELD`, keeps external
  independent host replay `HELD`, and keeps `P4`/`P5` `NOT_AUTHORIZED`.
-/
inductive R1GovernanceStatus where
  | f_p3c_01_scoped_provenance_bound_in_r1
  | legacy_p3c_authorization_qualified_unchanged
  | f_p3c_02_semantic_scope_held
  | out_of_kernel_binary_memory_tamper_held
  | external_independent_host_replay_held
  | p4_p5_authority_not_authorized
  deriving DecidableEq, Repr

end PneumaOmega.P3C.ProvenanceR1.Obligations
