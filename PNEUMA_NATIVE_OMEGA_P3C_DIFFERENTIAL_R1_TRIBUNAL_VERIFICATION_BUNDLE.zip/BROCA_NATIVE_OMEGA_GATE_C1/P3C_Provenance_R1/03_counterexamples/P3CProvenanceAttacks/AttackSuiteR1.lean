/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`Gate D` & `PO-R1-07` Positive/Adversarial Attack Suite)
  03_counterexamples/P3CProvenanceAttacks/AttackSuiteR1.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`, zero `native_decide`)

  Implements:
    1. Exact equivalence bridge (`verifyClaimPure_error_iff`, `verifyClaimPure_ok_iff`) linking
       fast kernel `Bool` evaluation to proof-carrying `verifyUntrustedConsensusClaim`.
    2. Constructive non-vacuity extraction (`extractAdmittedCert` via `mintCertifiedConsensus`,
       NEVER invoking `private CertifiedSemanticConsensus.mk`) yielding concrete inhabited
       witnesses `certG01`, `certG11`, `certG15a`, `certG15b`, `certG16` (`PO-R1-07`).
    3. 24-Vector Symmetric `(PC, CE)` Suite (`12` pairs) covering all 12 `Gate D` requirements
       across Threat Classes `A1` ~ `A6`, mapped 1-to-1 to `(caseId, threatId, targetTheorem,
       expectedVerdict, actualVerdict, passed)` and proved via Lean kernel `decide` (`0` `native_decide`).
-/
import P3CProvenanceChecker
import P3CCounterexamples

namespace PneumaOmega.P3C.ProvenanceR1.Attacks

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1

/-! ### 1. Exact Equivalence Bridge Between `verifyClaimPure` and `verifyUntrustedConsensusClaim` -/

theorem verifyClaimPure_error_iff (targetCtx : ProvenanceContext)
    (claim : UntrustedConsensusClaim) (r : ProvenanceRejectReason) :
    verifyClaimPure targetCtx claim = .error r ↔
      verifyUntrustedConsensusClaim targetCtx claim = .error r := by
  rw [← verifyUntrustedConsensusClaim_proj_eq]
  cases verifyUntrustedConsensusClaim targetCtx claim with
  | error e => simp [Except.map]
  | ok c    => simp [Except.map]

theorem verifyClaimPure_ok_iff (targetCtx : ProvenanceContext)
    (claim : UntrustedConsensusClaim) (T : List ConcreteParseTree) (c : CanonicalMeaning) :
    verifyClaimPure targetCtx claim = .ok (T, c) ↔
      ∃ cert : CertifiedSemanticConsensus targetCtx,
        verifyUntrustedConsensusClaim targetCtx claim = .ok cert ∧
        cert.trees = T ∧ cert.canonical = c := by
  rw [← verifyUntrustedConsensusClaim_proj_eq]
  cases verifyUntrustedConsensusClaim targetCtx claim with
  | error e => simp [Except.map]
  | ok cert => simp [Except.map]

/-! ### 2. Canonical `ProvenanceContext` Fixtures Across `G`-Series, `T1`~`T5`, and Edge Inputs -/

def mkStdCtx (env : ScopeEnv) (budget : ResourceBudget) (s : String) : ProvenanceContext :=
  { catalog  := p3cTestCatalog
    numCfg   := frozenR22NumericConfig
    scopeEnv := env
    budget   := budget
    rawBytes := strToAsciiBytes s }

def ctxG01   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG01
def ctxG03   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG03
def ctxG05   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG05
def ctxG07   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG07
def ctxG09   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG09
def ctxG10   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG10
def ctxG11   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG11
def ctxG12   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG12
def ctxG13   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG13
def ctxG14   : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG14
def ctxG15a  : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sG15a_AB
def ctxG15b  : ProvenanceContext := mkStdCtx envDiscourse defaultParseBudget sG15b_BA
def ctxG16   : ProvenanceContext := mkStdCtx envDiscourse defaultParseBudget sG16

-- Dual-reading traps (`T1`, `T2`, `T4`) -> `AmbiguousReadings`
def ctxT1    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT1_AllNot
def ctxT2    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT2_ConfirmThat
def ctxT4    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT4_BarePlural

-- Single-reading traps (`T3`, `T5`) -> `TrapPolicyRejected`
def ctxT3    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT3_WhWhy
def ctxT5    : ProvenanceContext := mkStdCtx envAtomic defaultParseBudget sT5_Unscoped

-- Contrastive anchor mismatch (`out_mi` vs `out_death`) -> `SemanticExtractionFailure`
def sG16_BadAnchor : String :=
  "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality."

def ctxG16BadAnchor : ProvenanceContext := mkStdCtx envDiscourse defaultParseBudget sG16_BadAnchor

-- Upstream failure contexts (`OutOfDomain`, `ResourceOverflow`, `Enumerated []`)
def ctxNonAscii : ProvenanceContext :=
  { catalog  := p3cTestCatalog
    numCfg   := frozenR22NumericConfig
    scopeEnv := envAtomic
    budget   := defaultParseBudget
    rawBytes := [0x49, 0x6E, 0x20, 0xC3, 0xA9] }

def ctxT2Overflow : ProvenanceContext :=
  mkStdCtx envAtomic { defaultParseBudget with maxReadings := 1 } sT2_ConfirmThat

def ctxEmptyParse : ProvenanceContext :=
  mkStdCtx envAtomic defaultParseBudget sBadMultiDotG01

-- Tampered contexts for `A3` / `A4` substitution tests
def ctxG16AtomicEnv : ProvenanceContext :=
  { ctxG16 with scopeEnv := envAtomic }

def ctxG16BadDesignEnv : ProvenanceContext :=
  { ctxG16 with scopeEnv := envMismatchedDesign }

def ctxG14TinyBytesBudget : ProvenanceContext :=
  { ctxG14 with budget := { defaultParseBudget with maxBytes := 16 } }

def ctxG03EmptyCatalog : ProvenanceContext :=
  { ctxG03 with catalog := { entries := [] } }

def ctxG03TightNumCfg : ProvenanceContext :=
  { ctxG03 with numCfg := { maxIntDigits := 1, maxFracDigits := 1 } }

/-! ### 3. Concrete Non-Vacuity Witnesses (`PO-R1-07`) via Public `mintCertifiedConsensus` Gate -/

def expectedCanonG11 : CanonicalMeaning :=
  normalizeMeaning (.scopedAtom (.cohortBound "coh_primary") "x_init"
    (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) [])

def expectedCanonG15Conj : CanonicalMeaning :=
  normalizeMeaning (.symConj
    (.scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.negExistential "sub_dm_pl" "ev_stroke")) [])
    (.scopedAtom (.cohortBound "coh_primary") "x_init" (.quantClaim (.existentialPos "sub_hr_sg" "ev_aki")) []))

private theorem isConsensusSingleEq_consensus_eq {T : List ConcreteParseTree}
    {c expected : CanonicalMeaning}
    (h : isConsensusSingleEq (.consensus T c) expected = true) :
    c = expected := by
  unfold isConsensusSingleEq at h
  cases T with
  | nil => contradiction
  | cons t rest =>
    cases rest with
    | nil => exact (canonicalMeaningEqBool_iff c expected).mp h
    | cons _ _ => contradiction

/--
  Extracts a sealed `CertifiedSemanticConsensus ctx` strictly from the public `mintCertifiedConsensus`
  gate given a `decide`-verified consensus check (`NEVER` calling `private CertifiedSemanticConsensus.mk`).
-/
def extractAdmittedCert (ctx : ProvenanceContext) (expected : CanonicalMeaning)
    (hok : isConsensusSingleEq (runP3COnContext ctx) expected = true) :
    CertifiedSemanticConsensus ctx :=
  match mintCertifiedConsensus ctx with
  | .admitted cert => cert
  | .rejectedAmbiguous _ _ hExec =>
    False.elim (by have h1 := hok; unfold isConsensusSingleEq at h1; rw [hExec] at h1; contradiction)
  | .rejectedExtractionFailure _ _ hExec =>
    False.elim (by have h1 := hok; unfold isConsensusSingleEq at h1; rw [hExec] at h1; contradiction)
  | .rejectedTrapPolicy _ _ _ hExec =>
    False.elim (by have h1 := hok; unfold isConsensusSingleEq at h1; rw [hExec] at h1; contradiction)
  | .rejectedUpstream _ hExec =>
    False.elim (by have h1 := hok; unfold isConsensusSingleEq at h1; rw [hExec] at h1; contradiction)

theorem extractAdmittedCert_canonical_eq (ctx : ProvenanceContext) (expected : CanonicalMeaning)
    (hok : isConsensusSingleEq (runP3COnContext ctx) expected = true) :
    (extractAdmittedCert ctx expected hok).canonical = expected := by
  unfold extractAdmittedCert
  split
  · rename_i cert _
    have h1 : isConsensusSingleEq (.consensus cert.trees cert.canonical) expected = true := by
      rw [← cert.hExecProvenance]; exact hok
    exact isConsensusSingleEq_consensus_eq h1
  · rename_i hRun _; exfalso; have h1 := hok; unfold isConsensusSingleEq at h1; rw [hRun] at h1; contradiction
  · rename_i hRun _; exfalso; have h1 := hok; unfold isConsensusSingleEq at h1; rw [hRun] at h1; contradiction
  · rename_i hRun _; exfalso; have h1 := hok; unfold isConsensusSingleEq at h1; rw [hRun] at h1; contradiction
  · rename_i hRun _; exfalso; have h1 := hok; unfold isConsensusSingleEq at h1; rw [hRun] at h1; contradiction

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem ctxG01_consensus_ok : isConsensusSingleEq (runP3COnContext ctxG01) expectedCanonG01 = true := by decide

set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in
theorem ctxG11_consensus_ok : isConsensusSingleEq (runP3COnContext ctxG11) expectedCanonG11 = true := by decide

set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in
theorem ctxG15a_consensus_ok : isConsensusSingleEq (runP3COnContext ctxG15a) expectedCanonG15Conj = true := by decide

set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in
theorem ctxG15b_consensus_ok : isConsensusSingleEq (runP3COnContext ctxG15b) expectedCanonG15Conj = true := by decide

/-- Concrete inhabited `CertifiedSemanticConsensus ctxG01` witness (`PO-R1-07`). -/
def certG01 : CertifiedSemanticConsensus ctxG01 :=
  extractAdmittedCert ctxG01 expectedCanonG01 ctxG01_consensus_ok

/-- Concrete inhabited `CertifiedSemanticConsensus ctxG11` witness (`PO-R1-07`). -/
def certG11 : CertifiedSemanticConsensus ctxG11 :=
  extractAdmittedCert ctxG11 expectedCanonG11 ctxG11_consensus_ok

/-- Concrete inhabited `CertifiedSemanticConsensus ctxG15a` witness (`PO-R1-07`). -/
def certG15a : CertifiedSemanticConsensus ctxG15a :=
  extractAdmittedCert ctxG15a expectedCanonG15Conj ctxG15a_consensus_ok

/-- Concrete inhabited `CertifiedSemanticConsensus ctxG15b` witness (`PO-R1-07`). -/
def certG15b : CertifiedSemanticConsensus ctxG15b :=
  extractAdmittedCert ctxG15b expectedCanonG15Conj ctxG15b_consensus_ok

theorem certG01_canonical_eq : certG01.canonical = expectedCanonG01 :=
  extractAdmittedCert_canonical_eq ctxG01 expectedCanonG01 ctxG01_consensus_ok

theorem certG15_paraphrase_convergence : certG15a.canonical = certG15b.canonical := by
  have h1 := extractAdmittedCert_canonical_eq ctxG15a expectedCanonG15Conj ctxG15a_consensus_ok
  have h2 := extractAdmittedCert_canonical_eq ctxG15b expectedCanonG15Conj ctxG15b_consensus_ok
  exact h1.trans h2.symm

/-! ### 4. Deterministic Verdict Formatting & Helpers for 24-Vector `Gate D` Suite -/

def formatRejectReason : ProvenanceRejectReason → String
  | .rawBytesMismatch                        => "REJECT:rawBytesMismatch"
  | .scopeEnvMismatch                        => "REJECT:scopeEnvMismatch"
  | .budgetMismatch                          => "REJECT:budgetMismatch"
  | .catalogMismatch                         => "REJECT:catalogMismatch"
  | .numCfgMismatch                          => "REJECT:numCfgMismatch"
  | .nonConsensusOutcomeSubmitted            => "REJECT:nonConsensusOutcomeSubmitted"
  | .forgedConsensusOnAmbiguousInput         => "REJECT:forgedConsensusOnAmbiguousInput"
  | .forgedConsensusOnExtractionFailure (.invalidContrastiveAnchor _) =>
      "REJECT:forgedConsensusOnExtractionFailure(invalidContrastiveAnchor)"
  | .forgedConsensusOnExtractionFailure (.unsupportedReadingAlt _ _) =>
      "REJECT:forgedConsensusOnExtractionFailure(unsupportedReadingAlt)"
  | .forgedConsensusOnExtractionFailure (.unresolvedAnaphoricScope _ _) =>
      "REJECT:forgedConsensusOnExtractionFailure(unresolvedAnaphoricScope)"
  | .forgedConsensusOnExtractionFailure _    =>
      "REJECT:forgedConsensusOnExtractionFailure(other)"
  | .forgedConsensusOnTrapRejected .whFactivePresuppositionForbidden =>
      "REJECT:forgedConsensusOnTrapRejected(whFactivePresuppositionForbidden)"
  | .forgedConsensusOnTrapRejected .unscopedClauseForbidden =>
      "REJECT:forgedConsensusOnTrapRejected(unscopedClauseForbidden)"
  | .forgedConsensusOnTrapRejected _         =>
      "REJECT:forgedConsensusOnTrapRejected(parserOnlyTrap)"
  | .forgedConsensusOnUpstreamRejected (.outOfDomain _) =>
      "REJECT:forgedConsensusOnUpstreamRejected(outOfDomain)"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow _) =>
      "REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow)"
  | .forgedConsensusOnUpstreamRejected .emptyParseSet =>
      "REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)"
  | .substitutedCanonicalMeaning             => "REJECT:substitutedCanonicalMeaning"
  | .substitutedParseForest                  => "REJECT:substitutedParseForest"

def evalReplayVerdict (targetCtx : ProvenanceContext) (claim : UntrustedConsensusClaim) : String :=
  match verifyClaimPure targetCtx claim with
  | .ok (trees, _) => "ADMIT:consensus(trees=" ++ toString trees.length ++ ")"
  | .error r       => formatRejectReason r

/-- Mint-then-export roundtrip verdict on a valid `ProvenanceContext` (`PC` path). -/
def evalAuthenticRoundtripVerdict (ctx : ProvenanceContext) : String :=
  match runP3COnContext ctx with
  | .consensus T c => evalReplayVerdict ctx { claimedCtx := ctx, claimedOutcome := .consensus T c }
  | _              => "MINT_FAILED"

/-- Forged `.consensus` claim using `forgedTrees` and `forgedCanon` against `targetCtx`. -/
def evalForgedConsensusVerdict (targetCtx claimedCtx : ProvenanceContext)
    (forgedTrees : List ConcreteParseTree) (forgedCanon : CanonicalMeaning) : String :=
  evalReplayVerdict targetCtx
    { claimedCtx     := claimedCtx
      claimedOutcome := .consensus forgedTrees forgedCanon }

/-- Forest-level consensus provenance verdict (`evalForestPure`-backed `A5c` check). -/
def evalForestVerdict (env : ScopeEnv) (targetForest : List ConcreteParseTree)
    (claimedCanon : CanonicalMeaning) : String :=
  match verifyForestConsensusPure env targetForest claimedCanon with
  | .ok _    => "ADMIT:forestConsensus"
  | .error r => formatRejectReason r

/-! ### 5. The 24 Symmetric `(PC, CE)` `Gate D` Vectors (`12` Pairs Across `A1` ~ `A6`) -/

-- PAIR-R1-01 (`A1`): Authentic `G-01` Mint+Replay vs Public `SemanticNormOutcome.consensus [] c` Forgery
def act_pc01 : String := evalAuthenticRoundtripVerdict ctxG01
def act_ce01 : String :=
  evalReplayVerdict ctxG01
    { claimedCtx     := ctxG01
      claimedOutcome := fabricatePublicOutcomeWithoutExecution [] expectedCanonG01 }

-- PAIR-R1-02 (`A2`): Authentic `G-15b` Mint+Replay (`c_15b = c_15a`) vs Canonical & Forest Substitution
def act_pc02 : String :=
  if isConsensusSingleEq (runP3COnContext ctxG15b) expectedCanonG15Conj then
    evalAuthenticRoundtripVerdict ctxG15b
  else "CANON_MISMATCH"

def act_ce02 : String :=
  match runP3COnContext ctxG15b with
  | .consensus trees15b _ =>
    evalForgedConsensusVerdict ctxG15b ctxG15b trees15b expectedCanonG01 ++ " & " ++
    evalForgedConsensusVerdict ctxG15b ctxG15b [synthTreeG15a_AB] expectedCanonG15Conj
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-03 (`A3a`): Authentic `G-11` Mint+Replay vs Cross-Input `G-01 -> G-11` Reuse & Header Spoofing
def act_pc03 : String := evalAuthenticRoundtripVerdict ctxG11
def act_ce03 : String :=
  match runP3COnContext ctxG01 with
  | .consensus trees01 canon01 =>
    evalForgedConsensusVerdict ctxG11 ctxG01 trees01 canon01 ++ " & " ++
    evalForgedConsensusVerdict ctxG11 ctxG11 trees01 canon01
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-04 (`A3b`): Authentic `G-16` (`envDiscourse`) vs `ScopeEnv` Tampering (`envAtomic` & `envMismatchedDesign`)
def act_pc04 : String := evalAuthenticRoundtripVerdict ctxG16
def act_ce04 : String :=
  match runP3COnContext ctxG16 with
  | .consensus trees16 canon16 =>
    evalForgedConsensusVerdict ctxG16AtomicEnv ctxG16 trees16 canon16 ++ " & " ++
    evalForgedConsensusVerdict ctxG16BadDesignEnv ctxG16BadDesignEnv trees16 canon16
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-05 (`A4a`): Authentic `G-14` (`defaultParseBudget`) vs Reduced `ResourceBudget` (`maxBytes := 16`)
def act_pc05 : String := evalAuthenticRoundtripVerdict ctxG14
def act_ce05 : String :=
  match runP3COnContext ctxG14 with
  | .consensus trees14 canon14 =>
    evalForgedConsensusVerdict ctxG14TinyBytesBudget ctxG14 trees14 canon14 ++ " & " ++
    evalForgedConsensusVerdict ctxG14TinyBytesBudget ctxG14TinyBytesBudget trees14 canon14
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-06 (`A4b`): Authentic `G-03` vs Tampered `ClosedEntityCatalog` & `NumericGateConfig`
def act_pc06 : String := evalAuthenticRoundtripVerdict ctxG03
def act_ce06 : String :=
  match runP3COnContext ctxG03 with
  | .consensus trees03 canon03 =>
    evalForgedConsensusVerdict ctxG03EmptyCatalog ctxG03 trees03 canon03 ++ " & " ++
    evalForgedConsensusVerdict ctxG03TightNumCfg ctxG03 trees03 canon03
  | _ => "UNEXPECTED_NON_CONSENSUS"

-- PAIR-R1-07 (`A5a`): Authentic `G-09` vs `T1`·`T2`·`T4` `AmbiguousReadings` Forgery Bypass
def act_pc07 : String := evalAuthenticRoundtripVerdict ctxG09
def act_ce07 : String :=
  evalForgedConsensusVerdict ctxT1 ctxT1 [synthTreeG15a_AB] expectedCanonG11 ++ " & " ++
  evalForgedConsensusVerdict ctxT2 ctxT2 [synthTruncatedT2Alt1] expectedCanonG09 ++ " & " ++
  evalForgedConsensusVerdict ctxT4 ctxT4 [synthTreeG15a_AB] expectedCanonG11

-- PAIR-R1-08 (`A5b`): Authentic `G-10` & `G-12` vs `T3` & `T5` `TrapPolicyRejected` Forgery Bypass
def act_pc08 : String :=
  evalAuthenticRoundtripVerdict ctxG10 ++ " & " ++ evalAuthenticRoundtripVerdict ctxG12

def act_ce08 : String :=
  evalForgedConsensusVerdict ctxT3 ctxT3 [synthTruncatedT2Alt1] expectedCanonG10 ++ " & " ++
  evalForgedConsensusVerdict ctxT5 ctxT5 [synthTreeG15a_AB] expectedCanonG11

-- PAIR-R1-09 (`A5c`): Authentic `G-13` vs `SemanticExtractionFailure` (`BadAnchor` & `alt=3`) Disguised as Consensus
def act_pc09 : String := evalAuthenticRoundtripVerdict ctxG13
def act_ce09 : String :=
  evalForestVerdict envDiscourse [synthBadAnchorG16Tree] expectedCanonG09 ++ " & " ++
  evalForestVerdict envAtomic [synthInvalidAlt3Tree] expectedCanonG11 ++ " & " ++
  evalReplayVerdict ctxG13 { claimedCtx := ctxG13, claimedOutcome := evalForestPure envDiscourse [synthBadAnchorG16Tree] }

-- PAIR-R1-10 (`A5d`): Authentic `G-05` vs `UpstreamRejected (.outOfDomain)` (`ctxNonAscii`) Disguised as Consensus
def act_pc10 : String := evalAuthenticRoundtripVerdict ctxG05
def act_ce10 : String :=
  evalForgedConsensusVerdict ctxNonAscii ctxNonAscii [synthTreeG15a_AB] expectedCanonG01

-- PAIR-R1-11 (`A5e`): Authentic `G-07` vs `ResourceOverflow` (`ctxT2Overflow`) & `EmptyParseSet` (`ctxEmptyParse`) Disguise
def act_pc11 : String := evalAuthenticRoundtripVerdict ctxG07
def act_ce11 : String :=
  evalForgedConsensusVerdict ctxT2Overflow ctxT2Overflow [synthTruncatedT2Alt1] expectedCanonG09 ++ " & " ++
  evalForgedConsensusVerdict ctxEmptyParse ctxEmptyParse [synthTreeG15a_AB] expectedCanonG01

-- PAIR-R1-12 (`A6`): Authentic `certG01` Holds in `W_true` vs Fails in `W_false` (No `P4`/`P5` Truth Escalation)
def wClinicalTrue : SemanticWorld :=
  { patientDomain := fun _ _ => [], patientEventHolds := fun _ _ _ => false,
    genericLawHolds := fun _ _ _ => false, eventTimestamp := fun _ _ => 0,
    factTableHolds := fun _ _ => true, presupHolds := fun _ _ => true,
    contrastiveCoheres := fun _ _ _ _ => true }

def wClinicalFalse : SemanticWorld :=
  { patientDomain := fun _ _ => [], patientEventHolds := fun _ _ _ => false,
    genericLawHolds := fun _ _ _ => false, eventTimestamp := fun _ _ => 0,
    factTableHolds := fun _ _ => false, presupHolds := fun _ _ => true,
    contrastiveCoheres := fun _ _ _ _ => true }

def act_pc12 : String :=
  if evalDenotation wClinicalTrue (embedCanonical expectedCanonG01) then
    "DENOTES_W_TRUE:true(LinguisticConsensusScope)"
  else "UNEXPECTED_FALSE"

def act_ce12 : String :=
  if !evalDenotation wClinicalFalse (embedCanonical expectedCanonG01) then
    "DENOTES_W_FALSE:false(P4_P5_EscalationBlocked)"
  else "UNEXPECTED_TRUE"

/-! ### 6. Expected Verdicts & Pure Kernel `decide` Proofs for All 24 Vectors (`0` `native_decide`) -/

def exp_pc01 : String := "ADMIT:consensus(trees=1)"
def exp_ce01 : String := "REJECT:substitutedParseForest"

def exp_pc02 : String := "ADMIT:consensus(trees=1)"
def exp_ce02 : String := "REJECT:substitutedCanonicalMeaning & REJECT:substitutedParseForest"

def exp_pc03 : String := "ADMIT:consensus(trees=1)"
def exp_ce03 : String := "REJECT:rawBytesMismatch & REJECT:substitutedCanonicalMeaning"

def exp_pc04 : String := "ADMIT:consensus(trees=1)"
def exp_ce04 : String := "REJECT:scopeEnvMismatch & REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)"

def exp_pc05 : String := "ADMIT:consensus(trees=1)"
def exp_ce05 : String := "REJECT:budgetMismatch & REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow)"

def exp_pc06 : String := "ADMIT:consensus(trees=1)"
def exp_ce06 : String := "REJECT:catalogMismatch & REJECT:numCfgMismatch"

def exp_pc07 : String := "ADMIT:consensus(trees=1)"
def exp_ce07 : String := "REJECT:forgedConsensusOnAmbiguousInput & REJECT:forgedConsensusOnAmbiguousInput & REJECT:forgedConsensusOnAmbiguousInput"

def exp_pc08 : String := "ADMIT:consensus(trees=1) & ADMIT:consensus(trees=1)"
def exp_ce08 : String := "REJECT:forgedConsensusOnTrapRejected(whFactivePresuppositionForbidden) & REJECT:forgedConsensusOnTrapRejected(unscopedClauseForbidden)"

def exp_pc09 : String := "ADMIT:consensus(trees=1)"
def exp_ce09 : String := "REJECT:forgedConsensusOnExtractionFailure(invalidContrastiveAnchor) & REJECT:forgedConsensusOnExtractionFailure(unsupportedReadingAlt) & REJECT:nonConsensusOutcomeSubmitted"

def exp_pc10 : String := "ADMIT:consensus(trees=1)"
def exp_ce10 : String := "REJECT:forgedConsensusOnUpstreamRejected(outOfDomain)"

def exp_pc11 : String := "ADMIT:consensus(trees=1)"
def exp_ce11 : String := "REJECT:forgedConsensusOnUpstreamRejected(resourceOverflow) & REJECT:forgedConsensusOnUpstreamRejected(emptyParseSet)"

def exp_pc12 : String := "DENOTES_W_TRUE:true(LinguisticConsensusScope)"
def exp_ce12 : String := "DENOTES_W_FALSE:false(P4_P5_EscalationBlocked)"

set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc01_ok : eqStrBool act_pc01 exp_pc01 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce01_ok : eqStrBool act_ce01 exp_ce01 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_pc02_ok : eqStrBool act_pc02 exp_pc02 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_ce02_ok : eqStrBool act_ce02 exp_ce02 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc03_ok : eqStrBool act_pc03 exp_pc03 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce03_ok : eqStrBool act_ce03 exp_ce03 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_pc04_ok : eqStrBool act_pc04 exp_pc04 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_ce04_ok : eqStrBool act_ce04 exp_ce04 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc05_ok : eqStrBool act_pc05 exp_pc05 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce05_ok : eqStrBool act_ce05 exp_ce05 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc06_ok : eqStrBool act_pc06 exp_pc06 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce06_ok : eqStrBool act_ce06 exp_ce06 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc07_ok : eqStrBool act_pc07 exp_pc07 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_ce07_ok : eqStrBool act_ce07 exp_ce07 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc08_ok : eqStrBool act_pc08 exp_pc08 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce08_ok : eqStrBool act_ce08 exp_ce08 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_pc09_ok : eqStrBool act_pc09 exp_pc09 = true := by decide
set_option maxHeartbeats 1600000 in
set_option maxRecDepth 16384 in theorem r1_ce09_ok : eqStrBool act_ce09 exp_ce09 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc10_ok : eqStrBool act_pc10 exp_pc10 = true := by decide
set_option maxHeartbeats 800000 in
set_option maxRecDepth 16384 in theorem r1_ce10_ok : eqStrBool act_ce10 exp_ce10 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_pc11_ok : eqStrBool act_pc11 exp_pc11 = true := by decide
set_option maxHeartbeats 1200000 in
set_option maxRecDepth 16384 in theorem r1_ce11_ok : eqStrBool act_ce11 exp_ce11 = true := by decide
set_option maxRecDepth 16384 in theorem r1_pc12_ok : eqStrBool act_pc12 exp_pc12 = true := by decide
set_option maxRecDepth 16384 in theorem r1_ce12_ok : eqStrBool act_ce12 exp_ce12 = true := by decide

/-! ### 7. Structured 24-Row `Gate D` Audit Table & Master Theorem (`allR1SuiteCases_pass`) -/

structure R1AttackCase where
  caseId          : String
  polarity        : String
  threatId        : ProvenanceThreatId
  targetTheorem   : String
  description     : String
  expectedVerdict : String
  actualVerdict   : String
  deriving Repr

def R1AttackCase.passed (c : R1AttackCase) : Bool :=
  eqStrBool c.actualVerdict c.expectedVerdict

def mkR1Case (cid pol : String) (tid : ProvenanceThreatId) (thm desc exp act : String) : R1AttackCase :=
  { caseId          := cid
    polarity        := pol
    threatId        := tid
    targetTheorem   := thm
    description     := desc
    expectedVerdict := exp
    actualVerdict   := act }

def allR1AttackCases : List R1AttackCase :=
  [ mkR1Case "PC-R1-01" "PC" .A1_PublicConstructorForgery     "PO-R1-01 / PO-R1-06 / PO-R1-07" "Authentic G-01 mintCertifiedConsensus + replay roundtrip" exp_pc01 act_pc01,
    mkR1Case "CE-R1-01" "CE" .A1_PublicConstructorForgery     "PO-R1-01 / PO-R1-06"            "Public SemanticNormOutcome.consensus [] c forgery without P3-C execution" exp_ce01 act_ce01,
    mkR1Case "PC-R1-02" "PC" .A2_ResultSubstitution           "PO-R1-03 / PO-R1-06 / PO-R1-07" "Authentic G-15b discourse mint + paraphrase convergence with G-15a" exp_pc02 act_pc02,
    mkR1Case "CE-R1-02" "CE" .A2_ResultSubstitution           "PO-R1-01 / PO-R1-06"            "Substituted canonical meaning (c_G01) & substituted parse forest ([tau_15a]) on G-15b" exp_ce02 act_ce02,
    mkR1Case "PC-R1-03" "PC" .A3_InputOrEnvSubstitution       "PO-R1-02 / PO-R1-06"            "Authentic G-11 universal-negative mint + replay roundtrip" exp_pc03 act_pc03,
    mkR1Case "CE-R1-03" "CE" .A3_InputOrEnvSubstitution       "PO-R1-02 / PO-R1-06"            "Cross-input G-01 consensus reused on G-11 (rawBytesMismatch & header spoof)" exp_ce03 act_ce03,
    mkR1Case "PC-R1-04" "PC" .A3_InputOrEnvSubstitution       "PO-R1-02 / PO-R1-03"            "Authentic G-16 contrastive discourse mint under envDiscourse" exp_pc04 act_pc04,
    mkR1Case "CE-R1-04" "CE" .A3_InputOrEnvSubstitution       "PO-R1-02 / PO-R1-04"            "G-16 consensus reused under envAtomic & spoofed under envMismatchedDesign" exp_ce04 act_ce04,
    mkR1Case "PC-R1-05" "PC" .A4_BudgetOrCatalogSubstitution  "PO-R1-02 / PO-R1-06"            "Authentic G-14 covariate-adjusted mint under defaultParseBudget" exp_pc05 act_pc05,
    mkR1Case "CE-R1-05" "CE" .A4_BudgetOrCatalogSubstitution  "PO-R1-02 / PO-R1-04"            "G-14 consensus reused under reduced maxBytes=16 budget & spoofed overflow" exp_ce05 act_ce05,
    mkR1Case "PC-R1-06" "PC" .A4_BudgetOrCatalogSubstitution  "PO-R1-02 / PO-R1-06"            "Authentic G-03 unadjusted association mint under p3cTestCatalog" exp_pc06 act_pc06,
    mkR1Case "CE-R1-06" "CE" .A4_BudgetOrCatalogSubstitution  "PO-R1-02 / PO-R1-06"            "G-03 consensus reused under empty catalog & tightened NumericGateConfig" exp_ce06 act_ce06,
    mkR1Case "PC-R1-07" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-09 non-established meta-claim mint + replay" exp_pc07 act_pc07,
    mkR1Case "CE-R1-07" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "Forged consensus on dual-reading traps T1, T2, and T4 (AmbiguousReadings)" exp_ce07 act_ce07,
    mkR1Case "PC-R1-08" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-10 polar-whether & G-12 proper-part mint + replay" exp_pc08 act_pc08,
    mkR1Case "CE-R1-08" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "Forged consensus on single-reading traps T3 (why) & T5 (unscoped)" exp_ce08 act_ce08,
    mkR1Case "PC-R1-09" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-13 existential-positive mint + replay" exp_pc09 act_pc09,
    mkR1Case "CE-R1-09" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "SemanticExtractionFailure (bad anchor & alt=3) disguised as consensus & raw failure submit" exp_ce09 act_ce09,
    mkR1Case "PC-R1-10" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-05 ASCII risk-difference mint + replay" exp_pc10 act_pc10,
    mkR1Case "CE-R1-10" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "Non-ASCII OutOfDomain (0xC3) disguised as consensus" exp_ce10 act_ce10,
    mkR1Case "PC-R1-11" "PC" .A5_FailureOutcomeLaundering     "PO-R1-03 / PO-R1-06"            "Authentic G-07 not-stat-sig mint + replay" exp_pc11 act_pc11,
    mkR1Case "CE-R1-11" "CE" .A5_FailureOutcomeLaundering     "PO-R1-04 / PO-R1-06"            "ResourceOverflow (maxReadings=1 on T2) & Enumerated [] (1..25%) disguised as consensus" exp_ce11 act_ce11,
    mkR1Case "PC-R1-12" "PC" .A6_P4P5AuthorityEscalation      "PO-R1-03 / PO-R1-05"            "Certified G-01 consensus denotes true in extensional clinical world W_true" exp_pc12 act_pc12,
    mkR1Case "CE-R1-12" "CE" .A6_P4P5AuthorityEscalation      "PO-R1-05"                       "Same certified G-01 consensus denotes false in W_false (blocks P4/P5 escalation)" exp_ce12 act_ce12 ]

private theorem r1_list_all_eq_true {α : Type} (p : α → Bool) (xs : List α) :
    xs.all p = true ↔ ∀ x ∈ xs, p x = true := by
  induction xs with
  | nil => simp [List.all]
  | cons a rest ih =>
    simp only [List.all, Bool.and_eq_true, ih]
    constructor
    · rintro ⟨ha, hrest⟩ x hx
      rcases List.mem_cons.mp hx with rfl | hm
      · exact ha
      · exact hrest x hm
    · intro hall
      exact ⟨hall a (List.Mem.head rest), fun x hx => hall x (List.Mem.tail a hx)⟩

theorem allR1AttackCases_pass :
    allR1AttackCases.length = 24 ∧
    ∀ c ∈ allR1AttackCases, c.passed = true ∧ c.actualVerdict = c.expectedVerdict := by
  have hall : ∀ c ∈ allR1AttackCases, c.passed = true := by
    apply (r1_list_all_eq_true R1AttackCase.passed allR1AttackCases).mp
    dsimp only [allR1AttackCases, mkR1Case, R1AttackCase.passed, List.all]
    rw [r1_pc01_ok, r1_ce01_ok, r1_pc02_ok, r1_ce02_ok, r1_pc03_ok, r1_ce03_ok,
        r1_pc04_ok, r1_ce04_ok, r1_pc05_ok, r1_ce05_ok, r1_pc06_ok, r1_ce06_ok,
        r1_pc07_ok, r1_ce07_ok, r1_pc08_ok, r1_ce08_ok, r1_pc09_ok, r1_ce09_ok,
        r1_pc10_ok, r1_ce10_ok, r1_pc11_ok, r1_ce11_ok, r1_pc12_ok, r1_ce12_ok]
    rfl
  refine ⟨rfl, ?_⟩
  intro c hc
  have hp := hall c hc
  exact ⟨hp, (eqStrBool_iff c.actualVerdict c.expectedVerdict).mp hp⟩

end PneumaOmega.P3C.ProvenanceR1.Attacks
