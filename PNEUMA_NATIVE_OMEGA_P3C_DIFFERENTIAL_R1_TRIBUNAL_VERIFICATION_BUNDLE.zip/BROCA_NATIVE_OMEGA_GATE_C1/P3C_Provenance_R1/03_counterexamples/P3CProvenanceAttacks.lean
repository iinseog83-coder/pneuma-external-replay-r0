/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1
  Root export for `P3CProvenanceAttacks`
-/
import P3CProvenanceAttacks.AttackSuiteR1
