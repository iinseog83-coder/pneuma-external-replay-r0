/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`F-P3C-01` Threat Model & Context Specification)
  01_formal_spec/P3CProvenanceSpec/ThreatModelAndContext.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`)

  Gate 0 & Gate A Deliverables:
    1. Absorbs frozen `PneumaOmega.P3C` (`SemanticNormOutcome`, `certifySemanticConsensus`,
       `certifySemanticConsensus_sound`) without modifying a single byte of `P1`~`P3-C`.
    2. Explicitly exhibits why `F-P3C-01` arose: `SemanticNormOutcome.consensus` is publicly
       constructible without executing `certifySemanticConsensus` (`untrustedPublicConsensusForgeable`).
    3. Defines the full 5-component `ProvenanceContext` (`catalog`, `numCfg`, `scopeEnv`, `budget`,
       `rawBytes`) with pure `Bool` field comparators and proven `..._iff` equivalence lemmas.
    4. Models all six `Gate A` threat classes (`A1`~`A6`) and explicitly separates in-kernel Lean
       API guarantees from out-of-kernel binary/memory tamper boundaries (`HELD_OUT_OF_KERNEL_RUNTIME`).
    5. Defines algorithm-free declarative provenance & semantic preservation predicates
       (`ExecProvenanceSpec`, `DeclarativeConsensusContract`), keeping `ExtensionalContrastiveWorld`
       explicit and separating `P4` clinical truth / `P5` final admission (`NOT_AUTHORIZED`).
-/
import P3CDetachedChecker

namespace PneumaOmega.P3C.ProvenanceR1

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C

/-! ### 1. `Gate 0` & `Gate A1` Diagnosis: Public Constructibility of Raw `SemanticNormOutcome.consensus` -/

/--
  Demonstrates `Gate A1` (`F-P3C-01`): In frozen `P3-C`, `SemanticNormOutcome.consensus` is a
  public constructor, so an untrusted caller can fabricate `.consensus T c` on `T = []` or on
  arbitrary unverified `(T, c)` without ever invoking `certifySemanticConsensus`!
-/
def fabricatePublicOutcomeWithoutExecution (T : List ConcreteParseTree) (c : CanonicalMeaning) :
    SemanticNormOutcome :=
  SemanticNormOutcome.consensus T c

theorem public_outcome_allows_unverified_empty_trees (c : CanonicalMeaning) :
    ∃ out : SemanticNormOutcome, out = .consensus [] c :=
  ⟨fabricatePublicOutcomeWithoutExecution [] c, rfl⟩

/-! ### 2. Explicit `Gate A` Threat Taxonomy (`A1` ~ `A6`) & Security-Model Scope Boundary -/

inductive ProvenanceThreatId where
  | A1_PublicConstructorForgery
  | A2_ResultSubstitution
  | A3_InputOrEnvSubstitution
  | A4_BudgetOrCatalogSubstitution
  | A5_FailureOutcomeLaundering
  | A6_P4P5AuthorityEscalation
  deriving DecidableEq, Repr

/--
  Distinguishes what Lean 4 type/proof encapsulation guarantees vs out-of-kernel operational
  threats (`Mandate §Gate B & §4`: never overclaim binary/memory protection from `private mk`!).
-/
inductive SecurityAssuranceBoundary where
  | verifiedInLeanTypedKernelAPI
  | heldOutOfKernelBinaryMemoryRuntimeTamper
  deriving DecidableEq, Repr

/-! ### 3. Full 5-Component Verification Context (`ProvenanceContext`) & Fast `Bool` Equality -/

/--
  Complete input context `i` bound to `PneumaOmega.P3C.certifySemanticConsensus`:
  `(catalog, numCfg, scopeEnv, budget, rawBytes)`.
-/
structure ProvenanceContext where
  catalog  : ClosedEntityCatalog
  numCfg   : NumericGateConfig
  scopeEnv : ScopeEnv
  budget   : ResourceBudget
  rawBytes : List UInt8
  deriving DecidableEq, Repr

/-- Evaluates frozen `PneumaOmega.P3C.certifySemanticConsensus` on `ctx` without duplicating `P3-C`. -/
def runP3COnContext (ctx : ProvenanceContext) : SemanticNormOutcome :=
  certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes

def eqBytesBool : List UInt8 → List UInt8 → Bool
  | [], [] => true
  | b1 :: r1, b2 :: r2 => (b1 == b2) && eqBytesBool r1 r2
  | _, _ => false

theorem eqBytesBool_iff (xs ys : List UInt8) :
    eqBytesBool xs ys = true ↔ xs = ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp [eqBytesBool]
  | cons x rxs ih =>
    cases ys with
    | nil => simp [eqBytesBool]
    | cons y rys =>
      unfold eqBytesBool
      rw [Bool.and_eq_true, beq_iff_eq, ih]
      simp

def eqCatalogEntryBool (e1 e2 : CatalogEntry) : Bool :=
  (e1.sort == e2.sort) && eqStrBool e1.entityId e2.entityId && eqStrBool e1.lexeme e2.lexeme

theorem eqCatalogEntryBool_iff (e1 e2 : CatalogEntry) :
    eqCatalogEntryBool e1 e2 = true ↔ e1 = e2 := by
  cases e1 with
  | mk s1 id1 lx1 =>
    cases e2 with
    | mk s2 id2 lx2 =>
      unfold eqCatalogEntryBool
      dsimp only
      rw [Bool.and_eq_true, Bool.and_eq_true, beq_iff_eq, eqStrBool_iff, eqStrBool_iff]
      constructor
      · rintro ⟨⟨rfl, rfl⟩, rfl⟩; rfl
      · intro h; injection h with hs hid hlx; exact ⟨⟨hs, hid⟩, hlx⟩

def eqCatalogEntriesBool : List CatalogEntry → List CatalogEntry → Bool
  | [], [] => true
  | x :: xs, y :: ys => eqCatalogEntryBool x y && eqCatalogEntriesBool xs ys
  | _, _ => false

theorem eqCatalogEntriesBool_iff (xs ys : List CatalogEntry) :
    eqCatalogEntriesBool xs ys = true ↔ xs = ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp [eqCatalogEntriesBool]
  | cons x rxs ih =>
    cases ys with
    | nil => simp [eqCatalogEntriesBool]
    | cons y rys =>
      unfold eqCatalogEntriesBool
      rw [Bool.and_eq_true, eqCatalogEntryBool_iff, ih]
      simp

def eqCatalogBool (c1 c2 : ClosedEntityCatalog) : Bool :=
  eqCatalogEntriesBool c1.entries c2.entries

theorem eqCatalogBool_iff (c1 c2 : ClosedEntityCatalog) :
    eqCatalogBool c1 c2 = true ↔ c1 = c2 := by
  cases c1 with
  | mk es1 =>
    cases c2 with
    | mk es2 =>
      unfold eqCatalogBool
      dsimp only
      rw [eqCatalogEntriesBool_iff]
      exact ⟨fun h => by rw [h], fun h => by injection h⟩

def eqScopeEnvBool (e1 e2 : ScopeEnv) : Bool :=
  eqStrBool e1.cohortId e2.cohortId &&
  eqStrBool e1.expectedDesignHead e2.expectedDesignHead &&
  (e1.quoteIsolation == e2.quoteIsolation)

theorem eqScopeEnvBool_iff (e1 e2 : ScopeEnv) :
    eqScopeEnvBool e1 e2 = true ↔ e1 = e2 := by
  cases e1 with
  | mk c1 d1 q1 =>
    cases e2 with
    | mk c2 d2 q2 =>
      unfold eqScopeEnvBool
      dsimp only
      rw [Bool.and_eq_true, Bool.and_eq_true, eqStrBool_iff, eqStrBool_iff, beq_iff_eq]
      constructor
      · rintro ⟨⟨rfl, rfl⟩, rfl⟩; rfl
      · intro h; injection h with hc hd hq; exact ⟨⟨hc, hd⟩, hq⟩

def eqBudgetBool (b1 b2 : ResourceBudget) : Bool :=
  (b1.maxBytes == b2.maxBytes) &&
  (b1.maxSteps == b2.maxSteps) &&
  (b1.maxForestNodes == b2.maxForestNodes) &&
  (b1.maxReadings == b2.maxReadings)

theorem eqBudgetBool_iff (b1 b2 : ResourceBudget) :
    eqBudgetBool b1 b2 = true ↔ b1 = b2 := by
  cases b1 with
  | mk mb1 ms1 mn1 mr1 =>
    cases b2 with
    | mk mb2 ms2 mn2 mr2 =>
      unfold eqBudgetBool
      dsimp only
      simp only [Bool.and_eq_true, beq_iff_eq]
      constructor
      · rintro ⟨⟨⟨rfl, rfl⟩, rfl⟩, rfl⟩; rfl
      · intro h; injection h with h1 h2 h3 h4; exact ⟨⟨⟨h1, h2⟩, h3⟩, h4⟩

def eqNumCfgBool (n1 n2 : NumericGateConfig) : Bool :=
  (n1.maxIntDigits == n2.maxIntDigits) &&
  (n1.maxFracDigits == n2.maxFracDigits)

theorem eqNumCfgBool_iff (n1 n2 : NumericGateConfig) :
    eqNumCfgBool n1 n2 = true ↔ n1 = n2 := by
  cases n1 with
  | mk i1 f1 =>
    cases n2 with
    | mk i2 f2 =>
      unfold eqNumCfgBool
      dsimp only
      rw [Bool.and_eq_true, beq_iff_eq, beq_iff_eq]
      constructor
      · rintro ⟨rfl, rfl⟩; rfl
      · intro h; injection h with hi hf; exact ⟨hi, hf⟩

def parseTreeListEqBool : List ConcreteParseTree → List ConcreteParseTree → Bool
  | [], [] => true
  | t1 :: r1, t2 :: r2 => parseTreeEqBool t1 t2 && parseTreeListEqBool r1 r2
  | _, _ => false

theorem parseTreeListEqBool_iff (xs ys : List ConcreteParseTree) :
    parseTreeListEqBool xs ys = true ↔ xs = ys := by
  induction xs generalizing ys with
  | nil => cases ys <;> simp [parseTreeListEqBool]
  | cons x rxs ih =>
    cases ys with
    | nil => simp [parseTreeListEqBool]
    | cons y rys =>
      unfold parseTreeListEqBool
      rw [Bool.and_eq_true, parseTreeEqBool_iff, ih]
      simp

/-! ### 4. Declarative Provenance & Consensus Contract (`Gate A` / `Gate C`) -/

/--
  **Declarative Execution-Provenance Relation (`ExecProvenanceSpec`)**:
  `T` and `c` are authentically produced by executing frozen `PneumaOmega.P3C.certifySemanticConsensus`
  on the exact 5-component context `ctx`.
-/
def ExecProvenanceSpec (ctx : ProvenanceContext) (T : List ConcreteParseTree) (c : CanonicalMeaning) : Prop :=
  certifySemanticConsensus ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes =
    .consensus T c

/--
  **Declarative End-to-End Semantic Consensus Contract (`DeclarativeConsensusContract`)**:
  Conjoins bounded exhaustive parse enumeration (`P3-B`), independent `R0` trap-policy compliance,
  canonical fixed-point normality, universal reading consensus across `T`, and relative model-theoretic
  denotation preservation under `ExtensionalContrastiveWorld W` (`Mandate §PO-R1-03`).
-/
def DeclarativeConsensusContract (ctx : ProvenanceContext)
    (T : List ConcreteParseTree) (c : CanonicalMeaning) : Prop :=
  parseAllBounded ctx.catalog ctx.numCfg ctx.scopeEnv ctx.budget ctx.rawBytes = .enumerated T ∧
  StrictAsciiDomainSupported ctx.rawBytes ∧
  T ≠ [] ∧
  NoDupTrees T ∧
  (∀ τ : ConcreteParseTree, τ ∈ T ↔
     ValidParse_GFrozen ctx.catalog ctx.numCfg ctx.scopeEnv ctx.rawBytes τ) ∧
  TrapPolicyPermitsForest T ∧
  IsCanonicalNorm (embedCanonical c) ∧
  (∃ pairs : List (ConcreteParseTree × RawSemanticTerm),
     extractAllMeanings ctx.scopeEnv T = .ok pairs ∧
     pairs.map Prod.fst = T ∧
     UniversalConsensus pairs c ∧
     ∀ p ∈ pairs,
       extractRawMeaning ctx.scopeEnv p.1 = .ok p.2 ∧
       SemEq (embedCanonical c) p.2 ∧
       (∀ W : SemanticWorld, ExtensionalContrastiveWorld W →
          (Denotes W (embedCanonical c) ↔ Denotes W p.2)))

/-! ### 5. Downstream `P4` / `P5` Non-Escalation Boundary Interfaces (`A6` / `PO-R1-05`) -/

/--
  Uninhabited / unconstructible `P4` Clinical Fact Authorization Token (`NOT_AUTHORIZED` in `R1`):
  Requires universal empirical truth across admissible clinical evidence models — a property NOT
  entailed by linguistic semantic consensus!
-/
structure P4ClinicalTruthCert (c : CanonicalMeaning) where
  private mk ::
  hNotAuthorizedLock : False
  hUniversalTruth    : ∀ W : SemanticWorld, ExtensionalContrastiveWorld W → Denotes W (embedCanonical c)

/--
  Uninhabited / unconstructible `P5` Final `CertifiedOutput` Admission Token (`NOT_AUTHORIZED` in `R1`):
  Cannot be constructed from `CertifiedSemanticConsensus` without future `P4` + `P5` authorization!
-/
structure P5FinalCertifiedOutput where
  private mk ::
  hNotAuthorizedLock : False

theorem p4ClinicalTruthCert_uninhabited (c : CanonicalMeaning) :
    P4ClinicalTruthCert c → False :=
  fun cert => cert.hNotAuthorizedLock

theorem p5FinalCertifiedOutput_uninhabited :
    P5FinalCertifiedOutput → False :=
  fun cert => cert.hNotAuthorizedLock

end PneumaOmega.P3C.ProvenanceR1
