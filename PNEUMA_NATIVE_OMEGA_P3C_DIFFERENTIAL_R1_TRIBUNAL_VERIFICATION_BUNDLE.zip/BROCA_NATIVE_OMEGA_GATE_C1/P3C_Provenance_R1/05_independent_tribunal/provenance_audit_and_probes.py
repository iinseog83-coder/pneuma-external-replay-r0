#!/usr/bin/env python3
"""
PNEUMA-NATIVE OMEGA — AUTH-P3C-PROVENANCE-R1 (`Gate B`, `Gate D`, `Gate E`)
05_independent_tribunal/provenance_audit_and_probes.py

Honest Engineering Classification (`Mandate §Gate E`):
  - Part 1 (`run_compiler_encapsulation_probes`):
      Executes 5 external `lake env lean` compiler probes in an OS temporary directory
      (zero files written inside any workspace/project directory), verifying:
        * `PROBE-CTRL-01` : Valid R1 consumer via public `mintCertifiedConsensus` (`exit 0`).
        * `PROBE-NEG-01a` : Direct `CertifiedSemanticConsensus.mk` invocation fails with private/unknown error.
        * `PROBE-NEG-01b` : Anonymous constructor `⟨T, c, h⟩ : CertifiedSemanticConsensus ctx` fails outside gate.
        * `PROBE-NEG-02`  : Passing `CertifiedSemanticConsensus ctxG01` where `ctxG11` is expected fails with
                            `Application type mismatch`.
        * `PROBE-NEG-03`  : Passing/constructing `P5FinalCertifiedOutput` from `certG01` fails with type/privacy error.
      Explicitly verifies zero syntax/import errors so failures stem strictly from encapsulation/typing!
  - Part 2 (`run_cross_language_claim_harness`):
      Evaluates 120 serialized untrusted claim bundles through both a clean-room Python 3.11
      reference model of `verifyUntrustedConsensusClaim` and `p3c_provenance_r1_runner.exe --eval-claims-batch`.
      Explicitly classified as a **Cross-Language Reference Harness** (NOT claimed as an independent R0 oracle).
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Tuple

R1_ROOT = Path(__file__).resolve().parent.parent
RUNNER_EXE = R1_ROOT / ".lake" / "build" / "bin" / "p3c_provenance_r1_runner.exe"


# ---------------------------------------------------------------------------
# 1. Canonical Sentence & Reference Fixture Table (Mirroring Frozen `P3-C`)
# ---------------------------------------------------------------------------

SENTENCES: Dict[str, str] = {
    "G01": "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (8.4%).",
    "G03": "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92).",
    "G05": "In the primary cohort, the absolute risk difference in myocardial infarction comparing intensive therapy versus standard care was -3.2 percentage points (95% CI -5.1 to -1.3).",
    "G07": "In the primary cohort, the observed hazard ratio comparing intensive therapy versus standard care for myocardial infarction (hazard ratio = 0.94, 95% CI 0.79 to 1.12) was not statistically significant at alpha = 0.05.",
    "G09": "In the primary cohort, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction.",
    "G10": "In the primary cohort, the analysis of Trial-A did not determine whether intensive therapy reduces myocardial infarction.",
    "G11": "In the primary cohort, no diabetic patients developed stroke.",
    "G12": "In the primary cohort, some, but not all, diabetic patients developed stroke.",
    "G14": "In the primary cohort, after adjustment for age and baseline risk, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92).",
    "G15a": "In the primary cohort, no diabetic patients developed stroke. In the primary cohort, at least one high-risk patient developed acute kidney injury.",
    "G15b": "In the primary cohort, at least one high-risk patient developed acute kidney injury. Within this same study, no diabetic patients developed stroke.",
    "G16": "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces myocardial infarction.",
    "T1": "In the primary cohort, all diabetic patients did not develop stroke.",
    "T2": "In the primary cohort, the analysis of Trial-A did not confirm that intensive therapy reduces myocardial infarction.",
    "T3": "In the primary cohort, the analysis of Trial-A did not determine why intensive therapy reduces myocardial infarction.",
    "T4": "In the primary cohort, diabetic patients developed stroke.",
    "T5": "no diabetic patients developed stroke.",
    "G16_BAD_ANCHOR": "In the primary cohort, comparing intensive therapy versus standard care was inversely associated with myocardial infarction (hazard ratio = 0.75, 95% CI 0.61 to 0.92); however, within this same study, the analysis of Trial-A did not establish that intensive therapy reduces all-cause mortality.",
    "BAD_MULTIDOT": "In the primary cohort, over 12 months, the cumulative incidence of stroke was 42 of 500 patients (1..25%).",
}

# Canonical item count & canonical group IDs for the 12 valid reference tags:
REF_CANON_GROUP: Dict[str, Tuple[str, int]] = {
    "G01": ("CANON_G01", 1),
    "G03": ("CANON_G03", 1),
    "G05": ("CANON_G05", 1),
    "G07": ("CANON_G07", 1),
    "G09": ("CANON_G09", 1),
    "G10": ("CANON_G10", 1),
    "G11": ("CANON_G11", 1),
    "G12": ("CANON_G12", 1),
    "G14": ("CANON_G14", 1),
    "G15a": ("CANON_G15_CONJ", 2),  # G-15a & G-15b converge to identical 2-item canonical conjunction!
    "G15b": ("CANON_G15_CONJ", 2),
    "G16": ("CANON_G16", 1),
}

DISCOURSE_ONLY_TAGS = {"G15b", "G16", "G16_BAD_ANCHOR"}
ATOMIC_ONLY_TAGS = {"G15a"}
USES_STROKE_TAGS = {"G01", "G11", "G12", "G15a", "G15b", "T1", "T4", "T5"}
MULTI_DIGIT_NUM_TAGS = {"G01", "G03", "G05", "G07", "G14", "G16", "G16_BAD_ANCHOR"}


def ascii_hex(s: str) -> str:
    return s.encode("ascii").hex()


# ---------------------------------------------------------------------------
# 2. Clean-Room Python Reference Model of `verifyUntrustedConsensusClaim`
# ---------------------------------------------------------------------------

def eval_p3c_reference_target(
    env_tag: str,
    max_b: int,
    max_r: int,
    cat_tag: str,
    num_tag: str,
    hex_payload: str,
    tag_hint: str,
) -> Tuple[str, str, int]:
    """
    Returns `(outcome_kind, detail_or_canon_group, item_count)` for our structured 120-vector space.
    """
    raw = bytes.fromhex(hex_payload)
    if len(raw) == 0:
        return ("UPSTREAM", "OOD_EMPTY", 0)
    for b in raw:
        if b < 0x20 or b > 0x7E:
            return ("UPSTREAM", f"OOD_BYTE({b})", 0)
    if len(raw) > max_b:
        return ("UPSTREAM", f"OVF_BYTES({len(raw)}>{max_b})", 0)

    if cat_tag == "empty":
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if cat_tag == "drop_stroke" and tag_hint in USES_STROKE_TAGS:
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if num_tag == "tight_1_1" and tag_hint in MULTI_DIGIT_NUM_TAGS:
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if tag_hint == "BAD_MULTIDOT":
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)

    # Quote-isolation & scope/anchor grammar gates enforced at parse time by P3-B (`DeclarativeParseSpec.lean`):
    if tag_hint in DISCOURSE_ONLY_TAGS and env_tag in {"atomic", "bad_cohort", "bad_design"}:
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if tag_hint in ATOMIC_ONLY_TAGS and env_tag in {"discourse", "bad_design", "bad_cohort"}:
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if tag_hint != "T5" and env_tag == "bad_cohort":
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)
    if tag_hint == "G16_BAD_ANCHOR":
        return ("UPSTREAM", "EMPTY_PARSE_SET", 0)

    # Dual-reading traps (`T1`, `T2`, `T4`) have 2 readings in P3-B:
    if tag_hint in {"T1", "T2", "T4"}:
        if max_r < 2:
            return ("UPSTREAM", f"OVF_READINGS(2>{max_r})", 0)
        return ("AMBIGUOUS", "DUAL_READING", 0)

    if max_r < 1:
        return ("UPSTREAM", f"OVF_READINGS(1>{max_r})", 0)

    # Single-reading traps (`T3`, `T5`):
    if tag_hint == "T3":
        return ("TRAP", "WH_FACTIVE", 0)
    if tag_hint == "T5":
        return ("TRAP", "UNSCOPED", 0)

    canon_grp, n_items = REF_CANON_GROUP[tag_hint]
    return ("CONSENSUS", canon_grp, n_items)


def eval_python_reference_row(
    t_env: str, t_max_b: int, t_max_r: int, t_cat: str, t_num: str, t_hex: str, t_tag: str,
    c_env: str, c_max_b: int, c_max_r: int, c_cat: str, c_num: str, c_hex: str,
    claim_mode: str, ref_tag: str,
) -> str:
    # Step 1: 5-field ProvenanceContext match (`checkContextMatch` exact order)
    if t_hex != c_hex:
        return "REJECT|RAW_BYTES_MISMATCH"
    if t_env != c_env:
        return "REJECT|SCOPE_ENV_MISMATCH"
    if (t_max_b != c_max_b) or (t_max_r != c_max_r):
        return "REJECT|BUDGET_MISMATCH"
    if t_cat != c_cat:
        return "REJECT|CATALOG_MISMATCH"
    if t_num != c_num:
        return "REJECT|NUM_CFG_MISMATCH"

    # Step 2: Check claimedOutcome constructor
    t_kind, t_detail, t_items = eval_p3c_reference_target(
        t_env, t_max_b, t_max_r, t_cat, t_num, t_hex, t_tag
    )
    if claim_mode == "SUBMIT_RAW_TARGET":
        if t_kind != "CONSENSUS":
            return "REJECT|NON_CONSENSUS_OUTCOME"
        return f"ADMIT|trees=1|items={t_items}"

    # All other modes submit `.consensus claimedTrees claimedCanon`:
    if t_kind == "AMBIGUOUS":
        return "REJECT|FORGED_ON_AMBIGUOUS"
    if t_kind == "EXTRACTION":
        return f"REJECT|FORGED_ON_EXTRACTION:{t_detail}"
    if t_kind == "TRAP":
        return f"REJECT|FORGED_ON_TRAP:{t_detail}"
    if t_kind == "UPSTREAM":
        return f"REJECT|FORGED_ON_UPSTREAM:{t_detail}"

    # Target genuinely reached `.consensus actualTrees actualCanon`:
    ref_canon_grp, _ = REF_CANON_GROUP[ref_tag]
    if t_detail != ref_canon_grp:
        return "REJECT|SUBSTITUTED_CANONICAL_MEANING"

    if claim_mode == "FORGE_EMPTY_TREES":
        return "REJECT|SUBSTITUTED_PARSE_FOREST"
    if claim_mode == "SUBST_TREES_SYNTH15A":
        # Note: synthTreeG15a_AB has dummy spans `sp0 = (0, 1)`, never equal to real parsed spans!
        return "REJECT|SUBSTITUTED_PARSE_FOREST"
    if claim_mode == "SUBST_CANON_ONLY":
        # `claimedTrees == actualTrees` and `t_detail == ref_canon_grp`:
        return f"ADMIT|trees=1|items={t_items}"
    if claim_mode == "AUTH_FROM_REF":
        # Trees match iff target parse tree == ref parse tree (same sentence & env):
        if t_tag != ref_tag:
            return "REJECT|SUBSTITUTED_PARSE_FOREST"
        return f"ADMIT|trees=1|items={t_items}"

    raise ValueError(f"Unknown claim_mode: {claim_mode}")


# ---------------------------------------------------------------------------
# 3. Build 120 Deterministic Serialized Claim Vectors Across `A1` ~ `A5`
# ---------------------------------------------------------------------------

def generate_120_claim_rows() -> List[Tuple[List[str], str]]:
    rows: List[Tuple[List[str], str]] = []
    idx = 0

    def add_row(
        t_env: str, t_max_b: int, t_max_r: int, t_cat: str, t_num: str, t_hex: str, t_tag: str,
        c_env: str, c_max_b: int, c_max_r: int, c_cat: str, c_num: str, c_hex: str,
        claim_mode: str, ref_tag: str,
    ) -> None:
        nonlocal idx
        idx += 1
        rid = f"R1B-{idx:03d}"
        cols = [
            rid,
            t_env, str(t_max_b), str(t_max_r), t_cat, t_num, t_hex,
            c_env, str(c_max_b), str(c_max_r), c_cat, c_num, c_hex,
            claim_mode, ref_tag,
        ]
        exp = eval_python_reference_row(
            t_env, t_max_b, t_max_r, t_cat, t_num, t_hex, t_tag,
            c_env, c_max_b, c_max_r, c_cat, c_num, c_hex,
            claim_mode, ref_tag,
        )
        rows.append((cols, f"{rid}\t{exp}"))

    valid_tags = ["G01", "G03", "G05", "G07", "G09", "G10", "G11", "G12", "G14", "G15a", "G15b", "G16"]

    # Group 1 (24 rows): Authentic roundtrips across all 12 valid G-series tags x 2 valid budgets
    for tag in valid_tags:
        env = "discourse" if tag in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tag])
        add_row(env, 512, 8, "full", "r22", hx, tag, env, 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tag)
        add_row(env, 420, 4, "full", "r22", hx, tag, env, 420, 4, "full", "r22", hx, "AUTH_FROM_REF", tag)

    # Group 2 (16 rows): `A1` Direct public `.consensus [] c` empty-forest forgery
    for tag in valid_tags:
        env = "discourse" if tag in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tag])
        add_row(env, 512, 8, "full", "r22", hx, tag, env, 512, 8, "full", "r22", hx, "FORGE_EMPTY_TREES", tag)
    for trap_tag in ["T1", "T2", "T3", "T5"]:
        hx = ascii_hex(SENTENCES[trap_tag])
        add_row("atomic", 512, 8, "full", "r22", hx, trap_tag, "atomic", 512, 8, "full", "r22", hx, "FORGE_EMPTY_TREES", "G01")

    # Group 3 (20 rows): `A2` Canonical meaning & parse-forest substitutions (incl. G15a <-> G15b!)
    subst_pairs = [
        ("G01", "G11"), ("G03", "G05"), ("G07", "G09"), ("G09", "G10"), ("G11", "G12"),
        ("G14", "G03"), ("G15a", "G01"), ("G15b", "G01"), ("G16", "G09"), ("G10", "G09"),
    ]
    for tgt, wrong_ref in subst_pairs:
        env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tgt])
        add_row(env, 512, 8, "full", "r22", hx, tgt, env, 512, 8, "full", "r22", hx, "SUBST_CANON_ONLY", wrong_ref)
    # Parse-forest substitutions (including G15a tree transplanted onto G15b despite identical canonical form!):
    add_row("discourse", 512, 8, "full", "r22", ascii_hex(SENTENCES["G15b"]), "G15b",
            "discourse", 512, 8, "full", "r22", ascii_hex(SENTENCES["G15b"]), "AUTH_FROM_REF", "G15a")
    add_row("atomic", 512, 8, "full", "r22", ascii_hex(SENTENCES["G15a"]), "G15a",
            "atomic", 512, 8, "full", "r22", ascii_hex(SENTENCES["G15a"]), "AUTH_FROM_REF", "G15b")
    for tgt in ["G01", "G03", "G09", "G11", "G14", "G15a", "G15b", "G16"]:
        env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tgt])
        add_row(env, 512, 8, "full", "r22", hx, tgt, env, 512, 8, "full", "r22", hx, "SUBST_TREES_SYNTH15A", tgt)

    # Group 4 (20 rows): `A3` Raw-byte & `ScopeEnv` substitution + header-spoofed variants
    byte_swaps = [("G01", "G11"), ("G11", "G01"), ("G03", "G14"), ("G09", "G10"), ("G15b", "G16")]
    for tgt, clm in byte_swaps:
        t_env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        c_env = "discourse" if clm in DISCOURSE_ONLY_TAGS else "atomic"
        t_hx = ascii_hex(SENTENCES[tgt])
        c_hx = ascii_hex(SENTENCES[clm])
        # Direct replay with mismatched claimed bytes:
        add_row(t_env, 512, 8, "full", "r22", t_hx, tgt, c_env, 512, 8, "full", "r22", c_hx, "AUTH_FROM_REF", clm)
        # Header-spoofed replay (`claimedCtx` overwritten to `targetCtx`):
        add_row(t_env, 512, 8, "full", "r22", t_hx, tgt, t_env, 512, 8, "full", "r22", t_hx, "AUTH_FROM_REF", clm)

    # ScopeEnv mismatches & spoofed bad_design / bad_cohort:
    for tgt in ["G01", "G09", "G11", "G15b", "G16"]:
        hx = ascii_hex(SENTENCES[tgt])
        good_env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        alt_env = "atomic" if good_env == "discourse" else "discourse"
        add_row(alt_env, 512, 8, "full", "r22", hx, tgt, good_env, 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
    for tgt in ["G15b", "G16"]:
        hx = ascii_hex(SENTENCES[tgt])
        add_row("bad_design", 512, 8, "full", "r22", hx, tgt, "bad_design", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
    for tgt in ["G01", "G09", "G11"]:
        hx = ascii_hex(SENTENCES[tgt])
        add_row("bad_cohort", 512, 8, "full", "r22", hx, tgt, "bad_cohort", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)

    # Group 5 (20 rows): `A4` Budget, Catalog, and NumericGateConfig mismatches + header-spoofed variants
    for tgt in ["G01", "G03", "G09", "G14", "G16"]:
        env = "discourse" if tgt in DISCOURSE_ONLY_TAGS else "atomic"
        hx = ascii_hex(SENTENCES[tgt])
        # Mismatched budget header:
        add_row(env, 16, 8, "full", "r22", hx, tgt, env, 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
        # Spoofed tiny budget header -> OVF_BYTES:
        add_row(env, 16, 8, "full", "r22", hx, tgt, env, 16, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
    for tgt in ["G01", "G11", "G15a"]:
        hx = ascii_hex(SENTENCES[tgt])
        add_row("atomic", 512, 8, "drop_stroke", "r22", hx, tgt, "atomic", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
        add_row("atomic", 512, 8, "drop_stroke", "r22", hx, tgt, "atomic", 512, 8, "drop_stroke", "r22", hx, "AUTH_FROM_REF", tgt)
    for tgt in ["G01", "G03"]:
        hx = ascii_hex(SENTENCES[tgt])
        add_row("atomic", 512, 8, "full", "tight_1_1", hx, tgt, "atomic", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", tgt)
        add_row("atomic", 512, 8, "full", "tight_1_1", hx, tgt, "atomic", 512, 8, "full", "tight_1_1", hx, "AUTH_FROM_REF", tgt)

    # Group 6 (20 rows): `A5` Failure-outcome laundering (`T1`~`T5`, extraction error, OOD, overflow, empty parse, raw submit)
    for trap_tag, ref_g in [("T1", "G11"), ("T2", "G09"), ("T4", "G11"), ("T3", "G10"), ("T5", "G11")]:
        hx = ascii_hex(SENTENCES[trap_tag])
        add_row("atomic", 512, 8, "full", "r22", hx, trap_tag, "atomic", 512, 8, "full", "r22", hx, "AUTH_FROM_REF", ref_g)
        add_row("atomic", 512, 8, "full", "r22", hx, trap_tag, "atomic", 512, 8, "full", "r22", hx, "SUBMIT_RAW_TARGET", ref_g)

    # Extraction failure (`G16_BAD_ANCHOR`):
    hx_bad_anc = ascii_hex(SENTENCES["G16_BAD_ANCHOR"])
    add_row("discourse", 512, 8, "full", "r22", hx_bad_anc, "G16_BAD_ANCHOR",
            "discourse", 512, 8, "full", "r22", hx_bad_anc, "AUTH_FROM_REF", "G16")
    add_row("discourse", 512, 8, "full", "r22", hx_bad_anc, "G16_BAD_ANCHOR",
            "discourse", 512, 8, "full", "r22", hx_bad_anc, "SUBMIT_RAW_TARGET", "G16")

    # Upstream OutOfDomain (empty, 0xC3 UTF-8, 0x00 NUL, 0x7F DEL):
    for bad_hex in ["", "496e20c3a9", "496e0061", "496e7f61"]:
        add_row("atomic", 512, 8, "full", "r22", bad_hex, "G01",
                "atomic", 512, 8, "full", "r22", bad_hex, "AUTH_FROM_REF", "G01")

    # Upstream ResourceOverflow (`maxReadings=1` on `T1` and `T2`) & EmptyParseSet (`BAD_MULTIDOT`):
    for ovf_tag in ["T1", "T2"]:
        hx = ascii_hex(SENTENCES[ovf_tag])
        add_row("atomic", 512, 1, "full", "r22", hx, ovf_tag,
                "atomic", 512, 1, "full", "r22", hx, "AUTH_FROM_REF", "G09")
    hx_mdot = ascii_hex(SENTENCES["BAD_MULTIDOT"])
    add_row("atomic", 512, 8, "full", "r22", hx_mdot, "BAD_MULTIDOT",
            "atomic", 512, 8, "full", "r22", hx_mdot, "AUTH_FROM_REF", "G01")
    add_row("atomic", 512, 8, "full", "r22", hx_mdot, "BAD_MULTIDOT",
            "atomic", 512, 8, "full", "r22", hx_mdot, "SUBMIT_RAW_TARGET", "G01")

    assert len(rows) == 120, f"Expected 120 rows, got {len(rows)}"
    return rows


# ---------------------------------------------------------------------------
# 4. External Compiler Access-Restriction & Type-Isolation Probes (`Gate B`)
# ---------------------------------------------------------------------------

PROBES = [
    {
        "probeId": "PROBE-CTRL-01",
        "expectExitZero": True,
        "requiredSubstrings": [],
        "forbiddenSubstrings": ["error:"],
        "purpose": "Positive control: external consumer imports P3CProvenanceObligations and reads certG01.canonical",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def validConsumerCanonical : PneumaOmega.P3C.CanonicalMeaning :=
  certG01.canonical
""",
    },
    {
        "probeId": "PROBE-NEG-01a",
        "expectExitZero": False,
        "requiredSubstrings": ["CertifiedSemanticConsensus.mk"],
        "forbiddenSubstrings": ["unknown module prefix", "expected token"],
        "purpose": "Negative probe A1 (named constructor): external caller cannot invoke private CertifiedSemanticConsensus.mk",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def forgeViaNamedMk (h : PneumaOmega.P3C.certifySemanticConsensus ctxG01.catalog ctxG01.numCfg ctxG01.scopeEnv ctxG01.budget ctxG01.rawBytes = .consensus certG01.trees certG01.canonical) :
    CertifiedSemanticConsensus ctxG01 :=
  CertifiedSemanticConsensus.mk certG01.trees certG01.canonical h
""",
    },
    {
        "probeId": "PROBE-NEG-01b",
        "expectExitZero": False,
        "requiredSubstrings": ["private", "CertifiedSemanticConsensus"],
        "forbiddenSubstrings": ["unknown module prefix", "expected token"],
        "purpose": "Negative probe A1 (anonymous constructor): external caller cannot forge CertifiedSemanticConsensus via anonymous ⟨...⟩",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def forgeViaAnonCtor : CertifiedSemanticConsensus ctxG01 :=
  ⟨certG01.trees, certG01.canonical, certG01.hExecProvenance⟩
""",
    },
    {
        "probeId": "PROBE-NEG-02",
        "expectExitZero": False,
        "requiredSubstrings": ["Application type mismatch", "ctxShortA", "ctxShortB"],
        "forbiddenSubstrings": ["unknown module prefix", "expected token", "timeout"],
        "purpose": "Negative probe A3/A4 (type-indexed input binding): CertifiedSemanticConsensus ctxShortA is rejected where ctxShortB is expected",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def ctxShortA : ProvenanceContext := { ctxG03EmptyCatalog with rawBytes := [0x41] }
def ctxShortB : ProvenanceContext := { ctxG03EmptyCatalog with rawBytes := [0x42] }

def consumeBOnly (c : CertifiedSemanticConsensus ctxShortB) : PneumaOmega.P3C.CanonicalMeaning :=
  c.canonical

def illegalCrossInputTransfer (c : CertifiedSemanticConsensus ctxShortA) : PneumaOmega.P3C.CanonicalMeaning :=
  consumeBOnly c
""",
    },
    {
        "probeId": "PROBE-NEG-03",
        "expectExitZero": False,
        "requiredSubstrings": ["Type mismatch", "P5FinalCertifiedOutput", "CertifiedSemanticConsensus"],
        "forbiddenSubstrings": ["unknown module prefix", "expected token"],
        "purpose": "Negative probe A6 (no P4/P5 authority escalation): CertifiedSemanticConsensus cannot inhabit P5FinalCertifiedOutput",
        "code": """import P3CProvenanceObligations
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks

def illegalEscalateToP5 : P5FinalCertifiedOutput :=
  certG01
""",
    },
]


def run_compiler_encapsulation_probes() -> List[Dict[str, object]]:
    results: List[Dict[str, object]] = []
    with tempfile.TemporaryDirectory(prefix="pneuma_r1_probes_") as tmpdir:
        tmp_path = Path(tmpdir)
        for p in PROBES:
            probe_file = tmp_path / f"{p['probeId'].replace('-', '_')}.lean"
            probe_file.write_text(p["code"], encoding="utf-8")
            proc = subprocess.run(
                ["lake", "env", "lean", str(probe_file)],
                cwd=str(R1_ROOT),
                capture_output=True,
                text=True,
                encoding="utf-8",
            )
            combined = (proc.stdout + "\n" + proc.stderr).strip()
            # Mask local temp path and user profile in diagnostic excerpt:
            sanitized = combined.replace(str(probe_file), f"<TEMP_PROBE>/{probe_file.name}")
            user_home = os.path.expanduser("~")
            if user_home:
                sanitized = sanitized.replace(user_home, "<USER_HOME>")

            exit_ok = (proc.returncode == 0) if p["expectExitZero"] else (proc.returncode != 0)
            req_ok = all(sub in sanitized for sub in p["requiredSubstrings"])
            forb_ok = all(sub not in sanitized for sub in p["forbiddenSubstrings"])
            passed = exit_ok and req_ok and forb_ok

            results.append({
                "probeId": p["probeId"],
                "purpose": p["purpose"],
                "expectExitZero": p["expectExitZero"],
                "actualExitCode": proc.returncode,
                "passed": passed,
                "compilerOutput": sanitized,
            })
    return results


def run_cross_language_claim_harness() -> Dict[str, object]:
    rows = generate_120_claim_rows()
    tsv_text = "\n".join("\t".join(cols) for cols, _ in rows) + "\n"
    tsv_sha256 = hashlib.sha256(tsv_text.encode("utf-8")).hexdigest().upper()

    with tempfile.TemporaryDirectory(prefix="pneuma_r1_batch_") as tmpdir:
        tsv_path = Path(tmpdir) / "r1_claims_120.tsv"
        tsv_path.write_text(tsv_text, encoding="utf-8")
        proc = subprocess.run(
            [str(RUNNER_EXE), "--eval-claims-batch", str(tsv_path)],
            cwd=str(R1_ROOT),
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        if proc.returncode != 0:
            raise RuntimeError(f"Runner failed with exit {proc.returncode}: {proc.stderr}")

    lean_lines = [ln.strip() for ln in proc.stdout.splitlines() if ln.strip()]
    if len(lean_lines) != len(rows):
        raise RuntimeError(f"Line count mismatch: Lean={len(lean_lines)} vs Python={len(rows)}")

    mismatches = []
    admit_count = 0
    reject_count = 0
    for idx, ((_, py_expected), lean_actual) in enumerate(zip(rows, lean_lines), start=1):
        if "\tADMIT|" in lean_actual:
            admit_count += 1
        elif "\tREJECT|" in lean_actual:
            reject_count += 1
        if py_expected != lean_actual:
            mismatches.append({
                "index": idx,
                "pythonExpected": py_expected,
                "leanActual": lean_actual,
            })

    return {
        "harnessClassification": "CROSS_LANGUAGE_REFERENCE_HARNESS_NOT_INDEPENDENT_ORACLE",
        "totalClaimVectors": len(rows),
        "admittedVectors": admit_count,
        "rejectedVectors": reject_count,
        "mismatchCount": len(mismatches),
        "batchTsvSha256": tsv_sha256,
        "mismatches": mismatches,
    }


def main() -> int:
    print("==========================================================================")
    print("PNEUMA-NATIVE OMEGA — AUTH-P3C-PROVENANCE-R1 PROBES & CLAIM REPLAY HARNESS")
    print("==========================================================================")

    probe_results = run_compiler_encapsulation_probes()
    all_probes_ok = True
    for pr in probe_results:
        status = "PASS" if pr["passed"] else "FAIL"
        if not pr["passed"]:
            all_probes_ok = False
        print(f"[{status}] {pr['probeId']} (exit={pr['actualExitCode']}) — {pr['purpose']}")
        if pr["compilerOutput"]:
            first_line = pr["compilerOutput"].splitlines()[0]
            print(f"       compiler: {first_line}")

    batch_summary = run_cross_language_claim_harness()
    print("--------------------------------------------------------------------------")
    print(f"Harness Type      : {batch_summary['harnessClassification']}")
    print(f"Total TSV Claims  : {batch_summary['totalClaimVectors']} "
          f"(admitted={batch_summary['admittedVectors']}, rejected={batch_summary['rejectedVectors']})")
    print(f"Batch TSV SHA-256 : {batch_summary['batchTsvSha256']}")
    print(f"Lean-Python Diff  : {batch_summary['mismatchCount']} mismatches")
    print("==========================================================================")

    if "--json" in sys.argv:
        print("JSON_SUMMARY_BEGIN")
        print(json.dumps({"probes": probe_results, "claimHarness": batch_summary}, indent=2))
        print("JSON_SUMMARY_END")

    if (not all_probes_ok) or (batch_summary["mismatchCount"] != 0):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
