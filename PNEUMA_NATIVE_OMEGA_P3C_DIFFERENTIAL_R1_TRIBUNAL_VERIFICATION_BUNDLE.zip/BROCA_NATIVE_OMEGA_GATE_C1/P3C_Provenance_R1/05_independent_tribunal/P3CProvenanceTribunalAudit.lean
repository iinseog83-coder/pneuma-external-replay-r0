/-
  PNEUMA-NATIVE Ω — AUTH-P3C-PROVENANCE-R1 (`Gate E` Tribunal Audit & Serialized Claim Replay CLI)
  05_independent_tribunal/P3CProvenanceTribunalAudit.lean
  Pure Lean 4.33.1 Core (`Init` + read-only frozen `P2`, `P3-A`, `P3-B`, `P3-C`, zero `sorry`, zero `native_decide`)

  1. Emits `#print axioms` on all exported `PO-R1-01` ~ `PO-R1-07` theorems and bridge lemmas
     (`0` `sorryAx`, `0` `Lean.ofReduceBool`, `0` custom axioms).
  2. Provides CLI executable `p3c_provenance_r1_runner`:
     - Default mode               : executes and displays all 24 symmetric `(PC, CE)` `Gate D`
                                    vectors with `(caseId, threatId, targetTheorem, expected, actual)`.
     - `--export-fixed-json`      : exports JSON array of all 24 `Gate D` vectors.
     - `--eval-claims-batch <tsv>`: evaluates serialized untrusted claim bundles through the actual
                                    proof-carrying `verifyUntrustedConsensusClaim` gate for 1:1
                                    cross-language reference harness verification (`Gate E`).
-/
import P3CProvenanceObligations

open BrocaOmega.P2
open BrocaOmega.P3A
open BrocaOmega.P3B
open PneumaOmega.P3C
open PneumaOmega.P3C.Counterexamples
open PneumaOmega.P3C.ProvenanceR1
open PneumaOmega.P3C.ProvenanceR1.Attacks
open PneumaOmega.P3C.ProvenanceR1.Obligations

/-! ### 1. Kernel Axiom Fingerprint Audit (`#print axioms`) -/

#print axioms PO_R1_01_ConstructionSoundness
#print axioms PO_R1_02_InputBinding
#print axioms PO_R1_03_ConsensusPreservation
#print axioms PO_R1_04_FailClosed
#print axioms PO_R1_05_NoAuthorityEscalation
#print axioms PO_R1_06_ReplayFaithfulness
#print axioms PO_R1_07_ProvenanceNonVacuity
#print axioms PO_R1_All24AttackVectorsVerified
#print axioms certifiedSemanticConsensus_unique
#print axioms verifyClaimPure_error_iff
#print axioms verifyClaimPure_ok_iff

/-! ### 2. Deterministic Serialization for Cross-Language Reference Harness (`Gate E`) -/

private def renderThreatId : ProvenanceThreatId → String
  | .A1_PublicConstructorForgery    => "A1_PublicConstructorForgery"
  | .A2_ResultSubstitution          => "A2_ResultSubstitution"
  | .A3_InputOrEnvSubstitution      => "A3_InputOrEnvSubstitution"
  | .A4_BudgetOrCatalogSubstitution => "A4_BudgetOrCatalogSubstitution"
  | .A5_FailureOutcomeLaundering    => "A5_FailureOutcomeLaundering"
  | .A6_P4P5AuthorityEscalation     => "A6_P4P5AuthorityEscalation"

private def renderBatchReject : ProvenanceRejectReason → String
  | .rawBytesMismatch                                 => "RAW_BYTES_MISMATCH"
  | .scopeEnvMismatch                                 => "SCOPE_ENV_MISMATCH"
  | .budgetMismatch                                   => "BUDGET_MISMATCH"
  | .catalogMismatch                                  => "CATALOG_MISMATCH"
  | .numCfgMismatch                                   => "NUM_CFG_MISMATCH"
  | .nonConsensusOutcomeSubmitted                     => "NON_CONSENSUS_OUTCOME"
  | .forgedConsensusOnAmbiguousInput                  => "FORGED_ON_AMBIGUOUS"
  | .forgedConsensusOnExtractionFailure (.invalidContrastiveAnchor _) =>
      "FORGED_ON_EXTRACTION:BAD_ANCHOR"
  | .forgedConsensusOnExtractionFailure (.unresolvedAnaphoricScope f e) =>
      s!"FORGED_ON_EXTRACTION:ANAPHORA({f}!={e})"
  | .forgedConsensusOnExtractionFailure (.mismatchedScopeCohort f e) =>
      s!"FORGED_ON_EXTRACTION:COHORT({f}!={e})"
  | .forgedConsensusOnExtractionFailure (.unsupportedReadingAlt _ a) =>
      s!"FORGED_ON_EXTRACTION:BAD_ALT({a})"
  | .forgedConsensusOnExtractionFailure (.malformedParseNode _ d) =>
      s!"FORGED_ON_EXTRACTION:MALFORMED({d})"
  | .forgedConsensusOnTrapRejected .whFactivePresuppositionForbidden =>
      "FORGED_ON_TRAP:WH_FACTIVE"
  | .forgedConsensusOnTrapRejected .unscopedClauseForbidden =>
      "FORGED_ON_TRAP:UNSCOPED"
  | .forgedConsensusOnTrapRejected (.parserOnlyTrapProduction _) =>
      "FORGED_ON_TRAP:PARSER_ONLY"
  | .forgedConsensusOnTrapRejected .wrapperTrapEnvelope =>
      "FORGED_ON_TRAP:WRAPPER"
  | .forgedConsensusOnUpstreamRejected .emptyParseSet =>
      "FORGED_ON_UPSTREAM:EMPTY_PARSE_SET"
  | .forgedConsensusOnUpstreamRejected (.outOfDomain .emptyInput) =>
      "FORGED_ON_UPSTREAM:OOD_EMPTY"
  | .forgedConsensusOnUpstreamRejected (.outOfDomain (.nonPrintableAsciiByte b)) =>
      s!"FORGED_ON_UPSTREAM:OOD_BYTE({b.toNat})"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow (.maxBytesExceeded act lim)) =>
      s!"FORGED_ON_UPSTREAM:OVF_BYTES({act}>{lim})"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow (.maxStepsExceeded lim)) =>
      s!"FORGED_ON_UPSTREAM:OVF_STEPS({lim})"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow (.maxForestNodesExceeded lim)) =>
      s!"FORGED_ON_UPSTREAM:OVF_NODES({lim})"
  | .forgedConsensusOnUpstreamRejected (.resourceOverflow (.maxReadingsExceeded act lim)) =>
      s!"FORGED_ON_UPSTREAM:OVF_READINGS({act}>{lim})"
  | .substitutedCanonicalMeaning                      => "SUBSTITUTED_CANONICAL_MEANING"
  | .substitutedParseForest                           => "SUBSTITUTED_PARSE_FOREST"

private def hexDigitVal (c : Char) : Option Nat :=
  if ('0' ≤ c) && (c ≤ '9') then some (c.toNat - '0'.toNat)
  else if ('a' ≤ c) && (c ≤ 'f') then some (10 + (c.toNat - 'a'.toNat))
  else if ('A' ≤ c) && (c ≤ 'F') then some (10 + (c.toNat - 'A'.toNat))
  else none

private def decodeHexChars : List Char → Option (List UInt8)
  | [] => some []
  | c1 :: c2 :: rest =>
    match hexDigitVal c1, hexDigitVal c2, decodeHexChars rest with
    | some v1, some v2, some tail => some (UInt8.ofNat (v1 * 16 + v2) :: tail)
    | _, _, _ => none
  | [_] => none

private def stripCR (s : String) : String :=
  String.ofList (s.toList.filter (fun c => c != '\r'))

private def parseNatSimple (s : String) : Nat :=
  s.toNat?.getD 0

private def resolveEnvTag : String → ScopeEnv
  | "discourse"  => envDiscourse
  | "bad_design" => envMismatchedDesign
  | "bad_cohort" => { cohortId := "coh_other", expectedDesignHead := "des_study", quoteIsolation := .sentenceAtomic }
  | _            => envAtomic

private def resolveCatalogTag : String → ClosedEntityCatalog
  | "empty" => { entries := [] }
  | "drop_stroke" =>
      { entries := p3cTestCatalog.entries.filter (fun e => !(e.entityId == "ev_stroke")) }
  | _ => p3cTestCatalog

private def resolveNumCfgTag : String → NumericGateConfig
  | "tight_1_1" => { maxIntDigits := 1, maxFracDigits := 1 }
  | _           => frozenR22NumericConfig

private def resolveRefContext : String → ProvenanceContext
  | "G01"   => ctxG01
  | "G03"   => ctxG03
  | "G05"   => ctxG05
  | "G07"   => ctxG07
  | "G09"   => ctxG09
  | "G10"   => ctxG10
  | "G11"   => ctxG11
  | "G12"   => ctxG12
  | "G14"   => ctxG14
  | "G15a"  => ctxG15a
  | "G15b"  => ctxG15b
  | "G16"   => ctxG16
  | _       => ctxG01

private def buildCtxFromCols (envTag maxBStr maxRStr catTag numTag hexPayload : String) :
    Option ProvenanceContext :=
  match decodeHexChars hexPayload.toList with
  | none => none
  | some rawBytes =>
    some { catalog  := resolveCatalogTag catTag
           numCfg   := resolveNumCfgTag numTag
           scopeEnv := resolveEnvTag envTag
           budget   := { defaultParseBudget with
                           maxBytes    := parseNatSimple maxBStr
                           maxReadings := parseNatSimple maxRStr }
           rawBytes := rawBytes }

private def buildClaimedOutcome (targetCtx : ProvenanceContext) (claimMode refTag : String) :
    SemanticNormOutcome :=
  let refOut := runP3COnContext (resolveRefContext refTag)
  let (refTrees, refCanon) :=
    match refOut with
    | .consensus T c => (T, c)
    | _              => ([], expectedCanonG01)
  match claimMode with
  | "AUTH_FROM_REF"     => .consensus refTrees refCanon
  | "FORGE_EMPTY_TREES" => fabricatePublicOutcomeWithoutExecution [] refCanon
  | "SUBST_CANON_ONLY"  =>
    match runP3COnContext targetCtx with
    | .consensus actualT _ => .consensus actualT refCanon
    | _                    => .consensus [synthTreeG15a_AB] refCanon
  | "SUBST_TREES_SYNTH15A" => .consensus [synthTreeG15a_AB] refCanon
  | "SUBMIT_RAW_TARGET" => runP3COnContext targetCtx
  | _                   => .consensus refTrees refCanon

private def evalClaimBatchLine (line : String) : Option String :=
  let clean := stripCR line
  if clean.isEmpty then none
  else
    match clean.splitOn "\t" with
    | [rowId,
       tEnv, tMaxB, tMaxR, tCat, tNum, tHex,
       cEnv, cMaxB, cMaxR, cCat, cNum, cHex,
       claimMode, refTag] =>
      match buildCtxFromCols tEnv tMaxB tMaxR tCat tNum tHex,
            buildCtxFromCols cEnv cMaxB cMaxR cCat cNum cHex with
      | some targetCtx, some claimedCtx =>
        let out := buildClaimedOutcome targetCtx claimMode refTag
        let claim : UntrustedConsensusClaim := { claimedCtx := claimedCtx, claimedOutcome := out }
        -- Invoke the ACTUAL proof-carrying `verifyUntrustedConsensusClaim` gate:
        match verifyUntrustedConsensusClaim targetCtx claim with
        | .ok cert   => some s!"{rowId}\tADMIT|trees={cert.trees.length}|items={cert.canonical.items.length}"
        | .error err => some s!"{rowId}\tREJECT|{renderBatchReject err}"
      | _, _ => some s!"{rowId}\tERR:INVALID_HEX"
    | _ => some "ERR:MALFORMED_LINE"

private def exportFixedJson : String :=
  let rows := allR1AttackCases.map fun c =>
    s!"  \{\"caseId\": \"{c.caseId}\", \"polarity\": \"{c.polarity}\", \"threatId\": \"{renderThreatId c.threatId}\", \"targetTheorem\": \"{c.targetTheorem}\", \"expectedVerdict\": \"{c.expectedVerdict}\", \"actualVerdict\": \"{c.actualVerdict}\", \"passed\": {c.passed}}"
  "[\n" ++ String.intercalate ",\n" rows ++ "\n]"

def main (args : List String) : IO UInt32 := do
  match args with
  | ["--export-fixed-json"] =>
    IO.println exportFixedJson
    return 0
  | ["--eval-claims-batch", path] =>
    let content ← IO.FS.readFile path
    for line in content.splitOn "\n" do
      match evalClaimBatchLine line with
      | some out => IO.println out
      | none     => pure ()
    return 0
  | _ =>
    IO.println "=========================================================================="
    IO.println "PNEUMA-NATIVE OMEGA — AUTH-P3C-PROVENANCE-R1 (PROOF-CARRYING CONSENSUS)"
    IO.println "Scope     : F-P3C-01 Public Result Provenance Binding (P3C_Provenance_R1)"
    IO.println "Toolchain : Lean 4.33.1 Core (Init + Frozen P2/P3-A/P3-B/P3-C, 0 sorry)"
    IO.println "=========================================================================="
    let mut passCount : Nat := 0
    for c in allR1AttackCases do
      let status := if c.passed then "PASS" else "FAIL"
      if c.passed then passCount := passCount + 1
      IO.println s!"[{status}] {c.caseId} | {renderThreatId c.threatId} | {c.targetTheorem} | exp={c.expectedVerdict} | act={c.actualVerdict}"
    IO.println "--------------------------------------------------------------------------"
    IO.println s!"TOTAL R1 GATE-D VECTORS : {passCount}/{allR1AttackCases.length} PASSED"
    if passCount == allR1AttackCases.length then
      return 0
    else
      return 1
